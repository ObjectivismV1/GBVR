@echo off
rem Ghostbusters VR V4 - Install (runs program_files\tools\gbvr_manager.ps1)
if not exist "%~dp0program_files\tools\gbvr_manager.ps1" (
  echo This file was started from inside the zip.
  echo Please close this window, right-click the zip, choose "Extract All",
  echo then open the extracted folder and run INSTALL.cmd again.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0program_files\tools\gbvr_manager.ps1" -Action Install
echo.
pause
