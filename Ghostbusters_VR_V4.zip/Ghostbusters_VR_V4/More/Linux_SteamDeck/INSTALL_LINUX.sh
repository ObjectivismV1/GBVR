#!/usr/bin/env bash
# Ghostbusters VR probe - Install on Linux / Steam Deck (runs gbvr_linux.sh)
cd "$(dirname "$(readlink -f "$0")")" || exit 1
if [ ! -f gbvr_linux.sh ]; then
  echo "gbvr_linux.sh is missing. Unzip the whole zip first, then run this file from the unzipped folder."
  exit 1
fi
bash gbvr_linux.sh install "$@"
