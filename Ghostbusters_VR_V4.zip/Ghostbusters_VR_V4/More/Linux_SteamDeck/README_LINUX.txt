GHOSTBUSTERS VR V4 - LINUX / STEAM DECK
==========================================

HONEST STATUS (read this first)
- The mod was built and tested on Windows 11 (Quest 3 through Virtual Desktop and SteamVR).
- The Linux route below has NOT been run with the game yet. The install scripts are tested on a pretend Steam folder
  (install, check, logs, remove, put-back of backups). Whether the mod works inside Proton is exactly what your first
  report will show. If it does not work, nothing is harmed: run REMOVE_LINUX.sh and you are back to normal.
- The game itself is Windows-only on Steam, so on Linux it always runs through Proton.

WHAT YOU NEED
- Ghostbusters: The Video Game Remastered, installed from Steam and started ONCE with Proton (this creates its Proton folder).
- A way to get VR to your headset. Pick one (see "HEADSET" below).
- A terminal. On Steam Deck: switch to Desktop Mode (Steam button > Power > Switch to Desktop), then open Konsole.

INSTALL (about 3 minutes)
1. Unzip the zip. Open the "More" folder, then "Linux_SteamDeck" and open a terminal there (file manager: right-click > Open Terminal Here).
2. Run:
       bash INSTALL_LINUX.sh
   It finds the game by itself (normal Steam, Flatpak Steam, other Steam libraries, SD card). It makes a backup of
   anything it replaces and writes a list of what it installed. If it cannot find the game it asks for the folder, or you can run:
       bash INSTALL_LINUX.sh --game-dir "/path/to/steamapps/common/Ghostbusters The Video Game Remastered"
3. In Steam: right-click the game > Properties > General > Launch Options. Paste:
       WINEDLLOVERRIDES="d3d11=n,b" %command%
   This line is what makes Proton load the mod. Without it the mod does nothing.
4. Start your VR stream (HEADSET section), then start the game from Steam. Put the headset on.
5. Controls and menu are in the guide (same as Windows). Open the menu with the left hand beside the left ear + left grip.

HEADSET (pick one)
A) WiVRn (Quest 2 / 3 / 3S and others). Open source, made for Linux, no SteamVR needed.
   - Install the WiVRn server (Flatpak on most distros; on Arch the "wivrn-dashboard" package) and the WiVRn app on the headset.
   - In the WiVRn dashboard set "OpenVR compatibility library" to xrizer. The mod talks OpenVR, xrizer turns it into OpenXR.
   - The dashboard shows the Steam Launch Options for Proton games. Paste THOSE in front of the mod's line, all on one line:
         <what the WiVRn dashboard shows> WINEDLLOVERRIDES="d3d11=n,b" %command%
   - Use a recent Proton (Proton 11 or Proton-GE). Wired network cable from the PC to the router helps a lot.
B) ALVR + SteamVR for Linux. Works with Quest, but SteamVR on Linux with newer Proton can be unreliable.
C) Steam Link + SteamVR for Linux (Quest app). Same warning as B.
D) Virtual Desktop does NOT exist on Linux (its PC program is Windows-only). That is the Windows route only.
Steam Deck note: the Deck's graphics chip is too weak for this game in VR. It is fine for the flat game; do not expect good VR.

IF SOMETHING GOES WRONG
- Check what is installed:   bash CHECK_INSTALL_LINUX.sh
- Collect everything for me: bash COLLECT_LOGS_LINUX.sh      (makes one zip in your Downloads folder; send that zip)
- For the very first try, add  PROTON_LOG=1  at the front of the Launch Options line. The collect script then
  includes the Proton log too. Take it out again afterwards (it makes a big file).
- Typical problems:
    * Game starts flat, no VR picture: the Launch Options line is missing or has a typo.
    * Black headset / SteamVR errors: send the zip; it contains the SteamVR, OpenVR and OpenXR files I need.
    * Game does not start at all: run REMOVE_LINUX.sh, start the game once to confirm it works, then try again and send the zip.

REMOVE
       bash REMOVE_LINUX.sh
It deletes only the files it installed, puts back any file it moved aside, and restores the game's frame-limit settings.
Then delete the Launch Options line in Steam (or leave it; it does nothing without the mod).

OTHER MODS
- The intro-skip mod (winmm.dll + GhostbustersNoIntro.asi) is not touched by these scripts. If you use it on Linux, add
  winmm=n,b to the override:   WINEDLLOVERRIDES="d3d11=n,b;winmm=n,b" %command%   (not tested).
- Mods that also bring their own d3d11.dll (ReShade, DXVK copies) cannot both be the game's d3d11.dll. The installer moves the other one aside and puts it back on removal.
