#!/usr/bin/env bash
# Ghostbusters VR probe - Linux / Steam Deck helper (install, remove, check, collect logs).
# Called by INSTALL_LINUX.sh, REMOVE_LINUX.sh, CHECK_INSTALL_LINUX.sh and COLLECT_LOGS_LINUX.sh.
# It does the same job as tools/gbvr_manager.ps1 on Windows: copies the mod files next to ghost.exe, keeps a
# backup of anything it replaces, and puts everything back on removal. It only ever deletes files it installed
# itself (tracked by SHA-256 in gbvr_manifest.txt, the same manifest format the Windows installer uses).
#
# HONEST STATUS: this has not been run with the game under Proton yet. The script logic is tested on a fake
# Steam folder; whether the mod works inside Proton is what the first Linux report will show.
#
# Usage:  bash gbvr_linux.sh install|remove|check|collect [--game-dir /path/to/game/folder]

set -u

ACTION="${1:-}"
[ $# -gt 0 ] && shift
GAME_DIR="${GAME_DIR:-}"
while [ $# -gt 0 ]; do
  case "$1" in
    --game-dir) GAME_DIR="${2:-}"; shift 2 || shift ;;
    --game-dir=*) GAME_DIR="${1#--game-dir=}"; shift ;;
    -h|--help) ACTION=help; shift ;;
    *) echo "Unknown option: $1"; exit 2 ;;
  esac
done

APPID=1449280
EXPECTED_EXE_HASH="ea5edecb590ace8efa2274df354ad266ada95a3100dbe6cabc5a5fb34a225038"
MANIFEST_NAME="gbvr_manifest.txt"

if [ -t 1 ]; then RED=$'\033[31m'; GRN=$'\033[32m'; YEL=$'\033[33m'; RST=$'\033[0m'; else RED=; GRN=; YEL=; RST=; fi
say()  { printf '%s\n' "$*"; }
ok()   { printf '%s%s%s\n' "$GRN" "$*" "$RST"; }
warn() { printf '%s%s%s\n' "$YEL" "$*" "$RST"; }
bad()  { printf '%s%s%s\n' "$RED" "$*" "$RST"; }

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
LINUX_DIR="$(dirname "$SELF")"
PKG_DIR="$(cd "$LINUX_DIR/../../program_files" 2>/dev/null && pwd)"   # 1.7.227: the files live in program_files, two folders up from here
TOOLS_DIR="$PKG_DIR/tools"
VERSION="unknown"
if [ -f "$PKG_DIR/VERSION.txt" ]; then VERSION="$(head -n1 "$PKG_DIR/VERSION.txt" | tr -d '\r')"; fi

sha() {
  local out
  if command -v sha256sum >/dev/null 2>&1; then out="$(sha256sum "$1" | cut -d' ' -f1)"
  elif command -v shasum >/dev/null 2>&1; then out="$(shasum -a 256 "$1" | cut -d' ' -f1)"
  else out="nohash"; fi
  printf '%s\n' "$out" | tr 'A-Z' 'a-z'
}

usage() {
  cat <<EOF
Ghostbusters VR V4 (build $VERSION) - Linux / Steam Deck helper
  bash gbvr_linux.sh install   [--game-dir DIR]   copy the mod into the game folder
  bash gbvr_linux.sh remove    [--game-dir DIR]   take the mod out again
  bash gbvr_linux.sh check     [--game-dir DIR]   show what is installed
  bash gbvr_linux.sh collect   [--game-dir DIR]   gather logs into one zip in Downloads
Normally you just run INSTALL_LINUX.sh (or REMOVE_LINUX.sh, ...) from the unzipped folder.
EOF
}

# ---- finding the game --------------------------------------------------------------------------
steam_roots() {
  local r
  for r in "$HOME/.steam/steam" "$HOME/.local/share/Steam" "$HOME/.steam/root" \
           "$HOME/.var/app/com.valvesoftware.Steam/.local/share/Steam" \
           "$HOME/snap/steam/common/.local/share/Steam"; do
    if [ -d "$r/steamapps" ]; then (cd "$r" && pwd -P); fi
  done | awk '!seen[$0]++'
}

steam_libraries() {
  local r v
  steam_roots | while IFS= read -r r; do
    printf '%s\n' "$r"
    v="$r/steamapps/libraryfolders.vdf"
    if [ -f "$v" ]; then sed -n 's/^[[:space:]]*"path"[[:space:]]*"\(.*\)".*/\1/p' "$v"; fi
  done | awk 'NF && !seen[$0]++'
}

find_game_dir() {
  local d lib g
  for d in "$PKG_DIR" "$(dirname "$PKG_DIR")" "$(dirname "$(dirname "$PKG_DIR")")"; do
    if [ -f "$d/ghost.exe" ]; then (cd "$d" && pwd -P); return 0; fi
  done
  while IFS= read -r lib; do
    [ -d "$lib/steamapps/common" ] || continue
    for g in "$lib"/steamapps/common/*/; do
      if [ -f "${g}ghost.exe" ]; then (cd "$g" && pwd -P); return 0; fi
    done
  done < <(steam_libraries)
  return 1
}

GAME=""
resolve_game() {
  if [ -n "$GAME_DIR" ]; then
    GAME_DIR="${GAME_DIR/#\~/$HOME}"
    if [ -f "$GAME_DIR/ghost.exe" ]; then GAME="$(cd "$GAME_DIR" && pwd -P)"; return 0; fi
    bad "ghost.exe was not found in: $GAME_DIR"
    exit 1
  fi
  GAME="$(find_game_dir)" || GAME=""
  if [ -z "$GAME" ]; then
    echo
    warn "Could not find the game automatically."
    say  "In Steam: right-click the game > Manage > Browse local files, then copy that folder's path."
    if [ -t 0 ]; then
      local p
      read -r -p "Paste the game folder path here: " p
      p="${p%\"}"; p="${p#\"}"; p="${p%\'}"; p="${p#\'}"; p="${p/#\~/$HOME}"
      if [ -n "$p" ] && [ -f "$p/ghost.exe" ]; then GAME="$(cd "$p" && pwd -P)"; return 0; fi
      bad "ghost.exe was not found in: $p"
    else
      say "Run again with:  bash gbvr_linux.sh $ACTION --game-dir /path/to/the/game/folder"
    fi
    exit 1
  fi
}

# Steam keeps each game's Windows-style "C:" drive in steamapps/compatdata/<appid>/pfx (the Proton prefix).
STEAMAPPS=""; PREFIX=""
derive_paths() {
  local sa
  sa="$(cd "$GAME/../.." 2>/dev/null && pwd -P)" || sa=""
  if [ -n "$sa" ] && [ "$(basename "$sa")" = "steamapps" ]; then STEAMAPPS="$sa"; fi
  if [ -n "$STEAMAPPS" ] && [ -d "$STEAMAPPS/compatdata/$APPID/pfx" ]; then PREFIX="$STEAMAPPS/compatdata/$APPID/pfx"; fi
}

# ---- game settings.ini (inside the Proton prefix) ------------------------------------------------
find_settings_ini() {
  [ -n "$PREFIX" ] || return 1
  local c
  for c in "$PREFIX"/drive_c/users/*/AppData/Local/GHOSTBUSTERS*/settings.ini; do
    [ -f "$c" ] || continue
    if ini_get "$c" lockTo30Hz >/dev/null 2>&1; then printf '%s\n' "$c"; return 0; fi
  done
  return 1
}

ini_get() {   # ini_get <file> <key>  -> prints the value, exit 3 if the key is missing
  command -v python3 >/dev/null 2>&1 || return 4
  python3 - "$1" "$2" <<'PY'
import re, sys
path, key = sys.argv[1:3]
b = open(path, 'rb').read()
if b[:2] == b'\xff\xfe': t = b[2:].decode('utf-16-le')
elif b[:3] == b'\xef\xbb\xbf': t = b[3:].decode('utf-8', 'replace')
else: t = b.decode('latin-1')
m = re.search(r'^[ \t]*' + re.escape(key) + r'[ \t]*=[ \t]*([^\r\n]*)', t, re.I | re.M)
if not m: sys.exit(3)
print(m.group(1).strip())
PY
}

ini_set() {   # ini_set <file> <key> <value>  (only an existing key is changed; the file's encoding is kept)
  command -v python3 >/dev/null 2>&1 || return 4
  python3 - "$1" "$2" "$3" <<'PY'
import re, sys
path, key, val = sys.argv[1:4]
b = open(path, 'rb').read()
if b[:2] == b'\xff\xfe': enc, bom, body = 'utf-16-le', b'\xff\xfe', b[2:]
elif b[:3] == b'\xef\xbb\xbf': enc, bom, body = 'utf-8', b'\xef\xbb\xbf', b[3:]
else: enc, bom, body = 'latin-1', b'', b
t = body.decode(enc)
pat = re.compile(r'^([ \t]*' + re.escape(key) + r'[ \t]*=[ \t]*)[^\r\n]*', re.I | re.M)
if not pat.search(t): sys.exit(3)
open(path, 'wb').write(bom + pat.sub(lambda m: m.group(1) + val, t).encode(enc))
PY
}

# ---- manifest ------------------------------------------------------------------------------------
M_VERSION=""; M_FILES=(); M_BACKUPS=(); M_SETTINGS=()
read_manifest() {
  M_VERSION=""; M_FILES=(); M_BACKUPS=(); M_SETTINGS=()
  local path="$GAME/$MANIFEST_NAME" line kind rest
  [ -f "$path" ] || return 1
  while IFS= read -r line || [ -n "$line" ]; do
    line="${line%$'\r'}"
    kind="${line%%|*}"; rest="${line#*|}"
    case "$kind" in
      version) M_VERSION="$rest" ;;
      file)    M_FILES+=("$rest") ;;
      backup)  M_BACKUPS+=("$rest") ;;
      setting) M_SETTINGS+=("$rest") ;;
    esac
  done < "$path"
  return 0
}

game_running() {
  # Wine/Proton names the process after the exe; the second test looks for a process STARTED as ...ghost.exe
  # (shells, grep and this script are left out so the words "ghost.exe" in their own command line do not count)
  pgrep -x 'ghost.exe' >/dev/null 2>&1 && return 0
  ps -eo args= 2>/dev/null | grep -iE '^([a-z]:\\|/).*ghost\.exe( |$)' \
    | grep -vE '^[^ ]*/?(ba|z|da|fi)?sh( |$)|^grep|^pgrep|gbvr_linux|_LINUX\.sh' | grep -q .
}

assert_closed() {
  if game_running; then
    bad "The game is running. Close it first (it saves its settings when it exits), then run this again."
    exit 1
  fi
}

remove_markers() {
  local n
  for n in gbvr_start_pending.txt gbvr_dxgi11_off.txt gbvr_picture_off.txt gbvr_run.txt gbvr_health.txt; do
    rm -f "$GAME/$n"
  done
}

check_exe() {
  EXE_OK=0
  local h; h="$(sha "$GAME/ghost.exe")"
  if [ "$h" = "$EXPECTED_EXE_HASH" ]; then EXE_OK=1; fi
  EXE_HASH="$h"
}

is_steamos() { [ -r /etc/os-release ] && grep -qiE '^ID=steamos|^VARIANT_ID=steamdeck' /etc/os-release; }

LAUNCH_HELP() {
  cat <<'EOF'

LAST STEP (one time, in Steam):
  1. Steam > right-click Ghostbusters: The Video Game Remastered > Properties > General > Launch Options
  2. Paste this line:

       WINEDLLOVERRIDES="d3d11=n,b" %command%

     That tells Proton to load the mod's d3d11.dll from the game folder. Without it the mod is ignored.
  3. Using WiVRn? Paste the launch options its dashboard shows IN FRONT of that line, on the same line.
     Example shape:   <WiVRn options> WINEDLLOVERRIDES="d3d11=n,b" %command%
  4. Using the intro-skip mod as well? Use  WINEDLLOVERRIDES="d3d11=n,b;winmm=n,b"  (not tested).
  5. Optional for the very first test only: add  PROTON_LOG=1  in front. It writes ~/steam-1449280.log,
     which COLLECT_LOGS_LINUX.sh then includes. Remove it afterwards (it makes a big file).
EOF
}

# ---- Install ---------------------------------------------------------------------------------------
do_install() {
  assert_closed
  [ -d "$PKG_DIR/bin" ] || { bad "The bin folder is missing next to this script. Unzip the whole zip first."; exit 1; }
  say "Game folder: $GAME"
  if [ -n "$PREFIX" ]; then say "Proton prefix: $PREFIX"; else warn "No Proton prefix found yet (start the game once from Steam with Proton, then run this again for the game settings step)."; fi
  if is_steamos; then say "SteamOS / Steam Deck detected. Run this in Desktop Mode."; fi

  if [ ! -w "$GAME" ]; then bad "The game folder is not writable: $GAME"; exit 1; fi

  check_exe
  if [ "$EXE_OK" = 1 ]; then ok "ghost.exe matches the game build this mod was made for."
  else warn "ghost.exe is NOT the build this mod was made for (SHA-256 $EXE_HASH). The mod will not touch the camera. Install can continue."; fi

  local stamp; stamp="$(date +%Y%m%d-%H%M%S)"
  local old_files=() old_backups=() old_settings=()
  if read_manifest; then
    say "Removing the previously installed mod ${M_VERSION:-?} first..."
    old_files=("${M_FILES[@]+"${M_FILES[@]}"}"); old_backups=("${M_BACKUPS[@]+"${M_BACKUPS[@]}"}"); old_settings=("${M_SETTINGS[@]+"${M_SETTINGS[@]}"}")
    local e n h
    for e in "${old_files[@]+"${old_files[@]}"}"; do
      n="${e%%|*}"; h="${e#*|}"
      if [ -f "$GAME/$n" ] && [ "$(sha "$GAME/$n")" = "$(printf '%s' "$h" | tr 'A-Z' 'a-z')" ]; then rm -f "$GAME/$n"; fi
    done
  fi

  local backups=("${old_backups[@]+"${old_backups[@]}"}") installed=() f name dest bak
  for f in "$PKG_DIR"/bin/*; do
    [ -f "$f" ] || continue
    name="$(basename "$f")"; dest="$GAME/$name"
    if [ -f "$dest" ] && [ "$(sha "$dest")" = "$(sha "$f")" ]; then
      say "$name is already the same file; keeping it."
    else
      if [ -e "$dest" ]; then
        bak="$name.gbvr_backup_$stamp"
        mv -- "$dest" "$GAME/$bak"
        backups+=("$name|$bak")
        warn "Existing $name was moved to $bak (restored on removal)."
      fi
      cp -- "$f" "$dest"
    fi
    installed+=("$name")
  done

  # Game settings this probe needs (tools/settings_to_apply.txt, key=value lines). Optional: the probe also
  # switches the 30 FPS limit off by itself while the game runs.
  local setting_lines=() wanted="$TOOLS_DIR/settings_to_apply.txt" ini line key val cur orig e2
  if [ -f "$wanted" ]; then
    ini="$(find_settings_ini)" || ini=""
    if [ -z "$ini" ]; then
      ok "Game settings file not found (or python3 is missing). That is OK: the mod switches the 30 FPS limit off by itself while the game runs."
      for e2 in "${old_settings[@]+"${old_settings[@]}"}"; do setting_lines+=("setting|$e2"); done
    else
      cp -- "$ini" "$ini.gbvr_backup_$stamp"
      while IFS= read -r line || [ -n "$line" ]; do
        line="${line%$'\r'}"
        if [[ "$line" =~ ^[[:space:]]*([^=#[:space:]]+)[[:space:]]*=[[:space:]]*([^[:space:]]*)[[:space:]]*$ ]]; then
          key="${BASH_REMATCH[1]}"; val="${BASH_REMATCH[2]}"
          cur="$(ini_get "$ini" "$key")" || { warn "Game setting $key not found in settings.ini; left unchanged."; continue; }
          orig="$cur"
          for e2 in "${old_settings[@]+"${old_settings[@]}"}"; do
            if [ "${e2%%|*}" = "$key" ]; then orig="$(printf '%s' "$e2" | cut -d'|' -f2)"; fi
          done
          ini_set "$ini" "$key" "$val" && { setting_lines+=("setting|$key|$orig|$ini"); say "Game setting $key=$val (was $cur; original $orig restored on removal)"; }
        fi
      done < "$wanted"
    fi
  fi

  {
    echo "version|$VERSION"
    for name in "${installed[@]+"${installed[@]}"}"; do echo "file|$name|$(sha "$GAME/$name")"; done
    for e2 in "${backups[@]+"${backups[@]}"}"; do echo "backup|$e2"; done
    for e2 in "${setting_lines[@]+"${setting_lines[@]}"}"; do echo "$e2"; done
  } > "$GAME/$MANIFEST_NAME"

  remove_markers
  ok "V4 (build $VERSION) installed."
  LAUNCH_HELP
  echo
  say "Then: start your VR streaming (see README_LINUX.txt), start the game from Steam, and put the headset on."
  say "After playing: close the game and run COLLECT_LOGS_LINUX.sh, then send the zip."
}

# ---- Remove ------------------------------------------------------------------------------------------
do_remove() {
  assert_closed
  if ! read_manifest; then say "Nothing to remove: no mod manifest in the game folder."; exit 0; fi
  local e key orig ini cur n h
  for e in "${M_SETTINGS[@]+"${M_SETTINGS[@]}"}"; do
    key="$(printf '%s' "$e" | cut -d'|' -f1)"; orig="$(printf '%s' "$e" | cut -d'|' -f2)"; ini="$(printf '%s' "$e" | cut -d'|' -f3-)"
    if [ -n "$ini" ] && [ -f "$ini" ]; then
      cur="$(ini_get "$ini" "$key")" || cur=""
      if [ "$cur" = "0" ]; then ini_set "$ini" "$key" "$orig" && say "Restored game setting $key=$orig"
      else warn "Kept game setting $key=$cur (changed since install)."; fi
    fi
  done
  for e in "${M_FILES[@]+"${M_FILES[@]}"}"; do
    n="${e%%|*}"; h="${e#*|}"
    if [ -f "$GAME/$n" ]; then
      if [ "$(sha "$GAME/$n")" = "$(printf '%s' "$h" | tr 'A-Z' 'a-z')" ]; then rm -f "$GAME/$n"; say "Removed $n"
      else warn "Kept $n: it was changed after install, so it is not ours to delete."; fi
    fi
  done
  local orig_name bak_name
  for e in "${M_BACKUPS[@]+"${M_BACKUPS[@]}"}"; do
    orig_name="${e%%|*}"; bak_name="${e#*|}"
    if [ -e "$GAME/$bak_name" ] && [ ! -e "$GAME/$orig_name" ]; then mv -- "$GAME/$bak_name" "$GAME/$orig_name"; say "Restored original $orig_name"; fi
  done
  rm -f "$GAME/$MANIFEST_NAME"
  remove_markers
  ok "V4 mod removed. Your logs were kept."
  say "Also remove the Launch Options line in Steam (Properties > General), or leave it: it does nothing without the mod."
}

# ---- Logs location -------------------------------------------------------------------------------------
log_dirs() {
  printf '%s\n' "$GAME"
  if [ -n "$PREFIX" ]; then
    local d
    for d in "$PREFIX"/drive_c/users/*/Documents/GhostbustersVR_logs; do [ -d "$d" ] && printf '%s\n' "$d"; done
  fi
}

newest() {   # newest <dir> <glob> <count>: the newest matching files, one per line (safe with spaces in paths)
  local f
  for f in "$1"/$2; do [ -f "$f" ] && printf '%s\n' "$f"; done | while IFS= read -r f; do printf '%s\t%s\n' "$(stat -c %Y "$f")" "$f"; done | sort -rn | head -n "$3" | cut -f2-
}

show_logs() {
  local d f
  local found=0
  while IFS= read -r d; do
    while IFS= read -r f; do
      if [ "$found" = 0 ]; then say "Newest logs (send the top one after a test):"; found=1; fi
      say "  $f  ($(date -r "$f" '+%Y-%m-%d %H:%M'))"
    done < <(newest "$d" 'gbvr_probe_*.log' 3)
  done < <(log_dirs)
  if [ "$found" = 0 ]; then say "No mod logs yet (they appear after the game starts with the mod installed)."; fi
}

# ---- Check -----------------------------------------------------------------------------------------------
do_check() {
  say "Game folder: $GAME"
  if [ -n "$PREFIX" ]; then say "Proton prefix: $PREFIX"; else warn "No Proton prefix found for app $APPID (start the game once from Steam with Proton)."; fi
  check_exe
  if [ "$EXE_OK" = 1 ]; then ok "ghost.exe: the build this mod was made for."; else warn "ghost.exe: a different build (SHA-256 $EXE_HASH)."; fi
  local e n h p
  if read_manifest; then
    say "V4 mod: version ${M_VERSION:-?} installed."
    for e in "${M_FILES[@]+"${M_FILES[@]}"}"; do
      n="${e%%|*}"; h="${e#*|}"; p="$GAME/$n"
      if [ ! -f "$p" ]; then bad "  $n: MISSING"
      elif [ "$(sha "$p")" = "$(printf '%s' "$h" | tr 'A-Z' 'a-z')" ]; then ok "  $n: OK"
      else warn "  $n: CHANGED by something else (another mod?)"; fi
    done
    for e in "${M_BACKUPS[@]+"${M_BACKUPS[@]}"}"; do say "  backup kept: ${e#*|} (original ${e%%|*})"; done
  else
    say "V4 mod: not installed (no manifest)."
    if [ -f "$GAME/d3d11.dll" ]; then warn "Note: a d3d11.dll from something else is in the game folder."; fi
  fi
  local ini; ini="$(find_settings_ini)" || ini=""
  if [ -n "$ini" ]; then
    say "Game frame limit: lockTo30Hz=$(ini_get "$ini" lockTo30Hz)  lockTo60Hz=$(ini_get "$ini" lockTo60Hz)  (0 and 0 = up to 120 FPS)"
  else say "Game settings.ini not found (start the game once to create it)."; fi
  if game_running; then say "The game is running right now."; fi
  for n in gbvr_dxgi11_off.txt gbvr_picture_off.txt; do
    if [ -f "$GAME/$n" ]; then warn "Note: $n is present - a safety switch was tripped by an earlier start. Installing again clears it."; fi
  done
  for n in gbvr_last_crash.txt gbvr_run.txt gbvr_health.txt; do
    if [ -f "$GAME/$n" ]; then warn "Note: $n is present - an earlier run did not end cleanly. Run COLLECT_LOGS_LINUX.sh and send the zip."; fi
  done
  say ""
  say "VR side:"
  if [ -f "$HOME/.config/openxr/1/active_runtime.json" ]; then say "  OpenXR runtime: $(grep -o '"library_path"[^,}]*' "$HOME/.config/openxr/1/active_runtime.json" | head -1)"; else say "  OpenXR active runtime: not set (fine if you use SteamVR)"; fi
  if [ -f "$HOME/.config/openvr/openvrpaths.vrpath" ]; then say "  SteamVR / OpenVR paths file: found"; else say "  SteamVR / OpenVR paths file: not found (SteamVR has not run on this account)"; fi
  if command -v wivrn-server >/dev/null 2>&1 || command -v wivrn-dashboard >/dev/null 2>&1 || { command -v flatpak >/dev/null 2>&1 && flatpak list 2>/dev/null | grep -qi wivrn; }; then say "  WiVRn: found"; else say "  WiVRn: not found"; fi
  say ""
  show_logs
}

# ---- Collect logs ----------------------------------------------------------------------------------------
downloads_dir() {
  local d=""
  if command -v xdg-user-dir >/dev/null 2>&1; then d="$(xdg-user-dir DOWNLOAD 2>/dev/null)"; fi
  [ -n "$d" ] && [ -d "$d" ] || d="$HOME/Downloads"
  mkdir -p "$d" 2>/dev/null || d="$HOME"
  printf '%s\n' "$d"
}

tail_copy() { [ -f "$1" ] && tail -n "$3" "$1" > "$2" 2>/dev/null; }

do_collect() {
  local stamp tmp n=0 d f dl out
  stamp="$(date +%Y%m%d-%H%M%S)"
  tmp="$(mktemp -d "${TMPDIR:-/tmp}/gbvr_report_$stamp.XXXXXX")" || { bad "Could not make a temporary folder."; exit 1; }
  mkdir -p "$tmp/steamvr" "$tmp/system"
  while IFS= read -r d; do
    local tag; tag="$(basename "$d")"
    while IFS= read -r f; do cp -- "$f" "$tmp/" && n=$((n+1)); done < <(newest "$d" 'gbvr_probe_*.log' 3)
    while IFS= read -r f; do cp -- "$f" "$tmp/"; done < <(newest "$d" 'gbvr_watch_*.log' 3)
    while IFS= read -r f; do cp -- "$f" "$tmp/"; done < <(newest "$d" 'gbvr_picture_*.jpg' 14)
    if [ -f "$d/gbvr_crash.dmp" ] && [ "$(stat -c %s "$d/gbvr_crash.dmp")" -lt 41943040 ]; then cp -- "$d/gbvr_crash.dmp" "$tmp/"; fi
    for f in gbvr_last_crash.txt gbvr_crumbs_last.txt gbvr_crumbs.bin gbvr_run.txt gbvr_health.txt gbvr_settings.txt gbvr_manifest.txt gbvr_start_pending.txt gbvr_dxgi11_off.txt gbvr_picture_off.txt; do
      [ -f "$d/$f" ] && cp -- "$d/$f" "$tmp/${tag}_$f"
    done
  done < <(log_dirs)
  [ -f "$PKG_DIR/gbvr_freeze_report.txt" ] && cp -- "$PKG_DIR/gbvr_freeze_report.txt" "$tmp/"

  {
    echo "Collected: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "V4 package: $VERSION"
    echo "Game folder: $GAME"
    echo "Proton prefix: ${PREFIX:-none}"
    echo "ghost.exe SHA-256: $(sha "$GAME/ghost.exe")  (expected $EXPECTED_EXE_HASH)"
    echo; echo "--- uname"; uname -a
    echo; echo "--- os-release"; cat /etc/os-release 2>/dev/null
    echo; echo "--- session"; echo "XDG_SESSION_TYPE=${XDG_SESSION_TYPE:-?} XDG_CURRENT_DESKTOP=${XDG_CURRENT_DESKTOP:-?}"
    echo; echo "--- GPU"; (lspci 2>/dev/null | grep -iE 'vga|3d|display') || echo "lspci not available"
    command -v nvidia-smi >/dev/null 2>&1 && { echo; echo "--- nvidia-smi"; nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv 2>&1; }
    echo; echo "--- Vulkan"; (vulkaninfo --summary 2>/dev/null | head -40) || echo "vulkaninfo not available"
    echo; echo "--- memory"; free -h 2>/dev/null
    if [ -n "$STEAMAPPS" ]; then
      echo; echo "--- Proton version used for this game"
      cat "$STEAMAPPS/compatdata/$APPID/version" 2>/dev/null || echo "not found"
      cat "$STEAMAPPS/compatdata/$APPID/config_info" 2>/dev/null | head -5
    fi
    echo; echo "--- running VR-related programs"
    ps -eo pid,comm,args 2>/dev/null | grep -iE 'steamvr|vrserver|vrcompositor|vrmonitor|wivrn|alvr|monado|ghost\.exe|xrizer|opencomposite' | grep -v grep | cut -c1-220
    echo; echo "--- game folder listing"; ls -la "$GAME" 2>/dev/null
  } > "$tmp/system/system_info.txt" 2>&1

  local sv
  for sv in "$HOME/.local/share/Steam" "$HOME/.steam/steam" "$HOME/.var/app/com.valvesoftware.Steam/.local/share/Steam"; do
    if [ -d "$sv/logs" ]; then
      for f in vrserver.txt vrstartup.txt vrcompositor.txt vrmonitor.txt vrclient_ghost.txt vrdashboard.txt; do tail_copy "$sv/logs/$f" "$tmp/steamvr/$f" 3000; done
      break
    fi
  done
  [ -f "$HOME/.config/openvr/openvrpaths.vrpath" ] && cp -- "$HOME/.config/openvr/openvrpaths.vrpath" "$tmp/steamvr/"
  [ -f "$HOME/.config/openvr/steamvr.vrsettings" ] && cp -- "$HOME/.config/openvr/steamvr.vrsettings" "$tmp/steamvr/"
  [ -f "$HOME/.config/openxr/1/active_runtime.json" ] && cp -- "$HOME/.config/openxr/1/active_runtime.json" "$tmp/steamvr/"
  tail_copy "$HOME/steam-$APPID.log" "$tmp/system/proton_steam-$APPID.log" 6000

  dl="$(downloads_dir)"
  out="$dl/gbvr_report_$stamp"
  if command -v zip >/dev/null 2>&1; then
    (cd "$tmp" && zip -qr "$out.zip" .) && out="$out.zip"
  elif command -v python3 >/dev/null 2>&1; then
    python3 - "$tmp" "$out.zip" <<'PY' && out="$out.zip"
import os, sys, zipfile
src, dst = sys.argv[1:3]
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(src):
        for f in files:
            p = os.path.join(root, f); z.write(p, os.path.relpath(p, src))
PY
  else
    tar -czf "$out.tar.gz" -C "$tmp" . && out="$out.tar.gz"
  fi
  rm -rf "$tmp"
  echo
  ok "Done. Please send me this file ($n log(s) inside):"
  ok "  $out"
  say "  (it is in your Downloads folder)"
}

# ---- main ---------------------------------------------------------------------------------------------------
case "$ACTION" in
  install|remove|check|collect) ;;
  help|"") usage; [ "$ACTION" = help ] && exit 0 || exit 2 ;;
  *) usage; exit 2 ;;
esac

resolve_game
derive_paths
case "$ACTION" in
  install) do_install ;;
  remove)  do_remove ;;
  check)   do_check ;;
  collect) do_collect ;;
esac
