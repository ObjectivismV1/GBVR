@echo off
cd /d "%~dp0"
call "%~dp0BUILD_1.7.120.cmd"
exit /b %errorlevel%
