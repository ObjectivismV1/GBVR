Building Ghostbusters VR V4 (build 1.7.226) from source

Linux (how the shipped DLL is made):
  SYSROOT=/usr/x86_64-w64-mingw32 bash build_cross.sh      (clang 18 + lld + mingw-w64 headers/import libraries)
  -> build/1.7.226/d3d11.dll
  Tests (no game needed):  bash tests/run_all.sh
  Player zip:              Ghostbusters_VR_V4.zip contains the compiled DLL and ready-to-run INSTALL.cmd.

Windows (convenience, not used for releases, not checked on a Windows PC for this version):
  BUILD.cmd  (Visual Studio 2019/2022 with the C++ tools)  -> build\1.7.120\d3d11.dll (historical output path)
