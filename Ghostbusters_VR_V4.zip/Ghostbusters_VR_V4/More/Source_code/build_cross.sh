#!/usr/bin/env bash
# Cross-build used to produce the shipped DLLs (Linux host, clang 18 + lld,
# mingw-w64 headers, import libraries generated from mingw-w64 .def files).
# Freestanding: imports only KERNEL32, USER32 and msvcrt.dll (always present).
# 0.30: auto-import is refused at link time. A C runtime function that the
# import library only offers as data (msvcrt's floor, for example) would
# otherwise be "called" through a runtime pseudo relocation that nothing in
# this DLL applies - 0.29 shipped like that and crashed in the overlay code.
#
# Usage: SYSROOT=/path/to/mingw-sysroot ./build_cross.sh
# On Windows use BUILD.cmd (Visual Studio) instead.
set -euo pipefail
cd "$(dirname "$0")"
SYSROOT="${SYSROOT:?set SYSROOT to a mingw-w64 sysroot with include/ and lib/}"
MH=third_party/minhook
COMMON=(--target=x86_64-w64-windows-gnu -isystem "$SYSROOT/include" -I"$MH/include" -Isrc
        -Ithird_party/openvr/headers -O2 -fno-strict-aliasing -ffreestanding -fno-stack-protector -mno-stack-arg-probe
        -fno-math-errno -funwind-tables -fasynchronous-unwind-tables -D_WIN32_WINNT=0x0A00 -DWIN32_LEAN_AND_MEAN -DNDEBUG -Wall -Wno-unused-function
        -Wno-unused-variable -Wno-missing-braces)

build() {  # $1 = headtrack (0/1), $2 = output dir
  local ht=$1 out=$2 obj; obj=$(mktemp -d)
  mkdir -p "$out"
  for f in $MH/src/buffer.c $MH/src/hook.c $MH/src/trampoline.c $MH/src/hde/hde64.c; do
    clang "${COMMON[@]}" -std=c11 -w -c "$f" -o "$obj/$(basename "$f" .c).o"
  done
  local cpp=(src/proxy.cpp src/log.cpp src/engine_hooks.cpp src/render_hooks.cpp)
  if [ "$ht" = 1 ]; then
    cpp+=(src/headtrack.cpp src/stereo.cpp src/exit_guard.cpp src/settings.cpp src/modes.cpp src/mouse.cpp src/menu.cpp src/hud.cpp src/shot.cpp src/controllers.cpp src/haptics.cpp src/sysinfo.cpp src/modscan.cpp src/xinput_bridge.cpp src/handmodel.cpp src/safety.cpp src/flatview.cpp src/eyeaa.cpp src/monitorview.cpp src/flatcursor.cpp src/heldmenu.cpp src/flatglow.cpp src/vrmenu.cpp src/arms.cpp src/steamvr_diag.cpp src/audio.cpp src/damage.cpp src/hosetex.cpp)
    clang "${COMMON[@]}" -std=c11 -DGBVR_HEADTRACK=1 -Wno-unused-const-variable -c src/vr_openvr.c -o "$obj/vr_openvr.o"
  fi
  for f in "${cpp[@]}"; do
    clang++ "${COMMON[@]}" -std=c++17 -fno-exceptions -fno-rtti -fno-threadsafe-statics \
      -DGBVR_HEADTRACK="$ht" -c "$f" -o "$obj/$(basename "$f" .cpp).o"
  done
  clang --target=x86_64-w64-windows-gnu -nostdlib -shared -fuse-ld=lld \
    -Wl,--entry=DllMain -Wl,--subsystem,windows -Wl,--dynamicbase -Wl,--nxcompat -Wl,--high-entropy-va \
    -Wl,--disable-auto-import -Wl,--disable-runtime-pseudo-reloc \
    -o "$out/d3d11.dll" "$obj"/*.o src/exports.def -L"$SYSROOT/lib" -lkernel32 -luser32 -lmsvcrt
  rm -rf "$obj"
  echo "built $out/d3d11.dll"
}

build 0 build/0.16R
build 1 build/1.7.226

# 0.93: the outside watcher (a separate small exe, installed next to the DLL)
buildwatch() {  # $1 = output dir
  local out=$1 obj; obj=$(mktemp -d); mkdir -p "$out"
  clang "${COMMON[@]}" -std=c11 -Wall -c src/watch.c -o "$obj/watch.o"
  clang --target=x86_64-w64-windows-gnu -nostdlib -fuse-ld=lld -Wl,--entry=start -Wl,--subsystem,windows -Wl,--dynamicbase -Wl,--nxcompat \
    -Wl,--disable-auto-import -Wl,--disable-runtime-pseudo-reloc -o "$out/gbvr_watch.exe" "$obj/watch.o" -L"$SYSROOT/lib" -lkernel32 -lmsvcrt
  rm -rf "$obj"
  echo "built $out/gbvr_watch.exe"
}
buildwatch build/1.7.226
