# Review of 1.7.41 against the latest supplied probe

Inputs: Ghostbusters_VR_Probe_1.7.41.zip, gbvr_report_20261023-015904.zip, and the screenshot of Claude's claims. The newest log in the report runs 1.7.40; the report cannot demonstrate 1.7.41 behavior.

| Claim | Evidence and result |
| --- | --- |
| Boson Dart on the gun-hand grip | Present in controllers.cpp as the game's LT secondary-fire input. Missing explicit gameplay/item gates and a release requirement after blocked actions. Added those gates, tracking-loss handling and tests. Proton gun only; left trigger capture/slam is unchanged. |
| Speed increase without game run | 1.7.41 defaults and settings migration set sprint_game=0. The report used sprint_game=1, so its zero boost ticks do not test this path. Fixed relative-offset reference drift and reset it for a new physics body/player. The final speed gain remains unverified in gameplay. |
| No yellow found-item markers | Implemented: collect_marker defaults to 0 and migrates to 0 from the report's older settings. The optional switch remains available. |
| Remove leftover ghost bars | 1.7.41 used a low-health/released-capture heuristic. Replaced it with the verified CCharacter death state and the game's actual trap-completion event. Disabled spatial trap guessing when the completion hook works: the report hid a still-living 74% ghost near a trap. |
| Earlier features retained | Boss parts counted as held 1,358 times; 30 slam helper calls were accepted. PKE scans finished; gun bar rendered. Trap launches/carry were exercised. Knockdown was not exercised (zero intercepted calls); health-bar damage response was not exercised (logged player health remained 100). |

## Additional concrete issue fixed

The report traversed about 3,688 actors twice per eye pair, around 834 microseconds per scan on average. The actor census and PKE source scan now run once per shared stereo pair. The eye-specific attachment, player health and input work still runs for both eyes. This removes duplicate work; it does not establish 90 FPS. The report's measured application rate was often 55-70 pairs/s while the display ran at 90 Hz.

## Binary evidence for ghost lifecycle

Verified against the supplied ghost.exe (SHA-256 ea5edecb590ace8efa2274df354ad266ada95a3100dbe6cabc5a5fb34a225038):

- Script `CCharacter::isDead` wrapper RVA 0x84D20 calls 0x7B170, which asks vtable slot 0x328. All listed enemy tables point that slot to 0x7B100; it returns the character state at +0xB874 (nonzero = dead).
- GhostTrap's update at RVA 0xF3FAB calls 0xBC080 with its caught ghost from trap+0x628. Completion dispatches gotTrappedEvent at ghost+0xDFA0. The new hook only records the event, then runs the complete original function.
- Hook prologue and death-state getter bytes are checked at runtime, with game identity required. The layout verification script checks the call chain and instructions against the executable.
- Confirmed caught actors remain suppressed while in the actor list. A record expires after an absent scan or world change, permitting pointer reuse. Living ghosts are not hidden merely for having low health.

## Validation limits

Native math/input tests and Windows cross-build checks can verify implementation, signatures and packaging. Visual placement, actual Boson shots, speed gain and frame rate require the next headset run. No current report claims to test the newly built 1.7.42.

Results: all 59 native test programs passed. The complete executable-layout check passed, including the added trap/death call-chain checks. Both DLL variants and the watcher EXE cross-built successfully. Package scripts now default to the current version and preserve the menu music when rebuilding from an extracted release.
