# 1.7.100 - body keeps its size, life bar only on a real gun, soft empty hands (built on 1.7.99)

Requests: "make sure the health bar follows the gun and does not stay on the hand", "make sure the full model works without the gun in it and both hands look and feel good when no weapon or PKE is in it", "the body changes size and affects the whole model view randomly while playing - fix it and make sure the viewmodel is not disturbed".

## Changes
- Body size (`bodymath.h scale_hold`): the body scale is camera eye height / the model's eye height, and the model's eye height is a running measurement (histogram peak, restarted for every new model instance). Every change of that peak resized the whole body, arms and hands with it. Now a drift under 1.5 % is ignored and a bigger, lasting one is followed at 1 % per second; a new character takes its scale at once. `BODYSCALE` log (40 lines): when the target moved, what is drawn, and the range drawn so far. The viewmodel (gun, its size, the hand-to-gun hold) is not touched.
- Life bar: drawn only while the game's gun was placed at the controller in the last 0.15 s (`engine_gun_placed`). Hidden when the gun is hidden, in a cut-scene, or on the back (`GUNBAR life bar hidden: ... not drawn at the hand` once, three times at most). When the probe does not place the gun (game_place, hooks off) the old rule applies.
- Empty hands: a hand with nothing in it (right hand with the gun on the back or nothing equipped; the left hand as before) takes the finger shape the left hand got in 1.7.98: knuckle and middle joint carry the bend (0.46-0.50 / 0.48-0.50), the fingertip at most 14 degrees. Before, only the left hand had it. A hand on the gun and a hand on the PKE are unchanged.

## Not known / not done
- Untested in a headset. The cause of the size change is the most likely one found in the code, not a measured one: the 1.7.98 report has no log of the body scale over time. If it still happens, `BODYSCALE` and the `BODY` summary lines in the next report show it.
- The life bar still sits at the controller plus its offsets (it does not read the gun model's own matrix).
