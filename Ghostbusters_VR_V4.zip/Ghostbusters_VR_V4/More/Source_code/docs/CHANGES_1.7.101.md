# 1.7.101 - model changes, GUNGONE, PERF (built on 1.7.100)

Requests (with the report gbvr_report_20261027-144513 and a 110 s video): "some fingers and models will change as the story progresses - make sure those changes are accounted for", "it randomly disappears while using it - you will see it in the video", "see if you can improve performance and get up to 90 fps by any means necessary".

## What the report and the video show
- The 1.7.99 gun rules worked: the gun stayed holstered until the game allowed it (`HOLSTER gun ready`, hand buzz), was put away in a forced walk (`HOLSTER gun put away #1 ... item 5`), and the player drew it by the gesture.
- The gun (and the right hand with it) vanished once for about 0.9 s at video 36.0 s (log about 41 s) with no holster event; the left hand let go of the gun at the same moment (`two hands` 1 -> 0 between the GUNHAND lines of 40.4 s and 41.4 s). The existing log cannot say which exit of the gun hook was taken (`GUNGAP` shows 0 no-hand episodes), so 1.7.101 adds `GUNGONE`.
- Both controllers lost tracking once for about 15 s at the end (`CONTROLLERS tracked: left=0 right=0`, flat screen): everything disappears then, which is the headset / Virtual Desktop, not the mod.
- Body size: one `BODYSCALE` line (target 1.000 -> 1.021, camera eye 5.50 ft, model eye 5.39 ft); drawn 1.000 held. No visible size jumps in the video were matched to it.
- HOLSTERPOSE: the game's own barrel direction of the stowed gun pointed 0.95/0.29/-0.14, i.e. NOT the way the body faces, so "back" taken from it (used since 1.7.99) can point sideways. See the fix below.

## Changes
- Model change (`model_gen_poll`): the arm layer counts every time it looks at a new skeleton (`arms_revalidations`; it finds the arm and finger bones by name again each time). When that happens (not more than 3 times in 5 s) the gun holds of all weapons, the PKE hold, the hand follow, the draw window and the body-size hold are dropped and taken again from the new model. Log: `MODELCHANGE #n`.
- `GUNGONE t=.. the gun was not at your hand for N ms (the first cause ...)`: the gun hook counts which exit it took (stale aim sample, no hand, no hold, no relation, unreadable) and logs it when the gun comes back after more than 250 ms. Holstered, PKE-out and cut-scene gaps are not counted.
- `PERF` line in the player log about every 20 s: delivered Hz against the headset's, work per eye pair (avg / max / budget), wait, picture level, and the whole-run steady / late / hitch share.
- The holstered gun's "back" now comes from the body's heading (not from the stowed gun's barrel, which can point sideways).

## Not known / not done
- Untested in a headset. The cause of the 0.9 s vanish is NOT known; `GUNGONE` will name it.
- 90 fps: no frame-time data exists in the player log yet (diagnostics are off), so nothing was changed blind. The `PERF` lines of the next report show where the time goes. The headset reports 90 Hz; picture level 2 draws a larger picture than level 1.
