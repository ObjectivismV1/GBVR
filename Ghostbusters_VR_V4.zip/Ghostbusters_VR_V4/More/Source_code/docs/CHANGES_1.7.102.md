# 1.7.102 - the PERF frame-rate line really reaches the player log (built on 1.7.101)

Request: "check frame drops happening too and see if they can be cleaned and optimized".

## What the report shows (1.7.100 run, Quest 3, Virtual Desktop 90 Hz, RTX 4080 SUPER)
- SteamVR: 10900 presents, 0 dropped, 2302 reprojected (about 21%). Reprojected means a frame came late and SteamVR showed the last one again, adjusted to your head. Nothing was lost.
- SteamVR's own average for the game: CPU 6.6 ms and GPU 5.6 ms per frame, against 11.1 ms available at 90 Hz. So on average the PC is fast enough; the late frames are spikes, not steady load.
- The compositor logs bursts of `WaitForAcquire timed out` (Virtual Desktop's shared picture not taken in time), 328 presents during those bursts, half reprojected. That is the Virtual Desktop side of the link.
- The 60 fps screen recording shows duplicate frames 6-14% of the time during play, which matches the reprojection share.

## Found: the 1.7.101 PERF line could not reach players
It was written inside the diagnostics-only report, and downloads run with diagnostics off, so no frame-time data would have appeared in any player report.

## Changes
- `stereo_perf_light()`: a compact PERF line every 30 s in every build. Delivered Hz against the headset's, game work per eye pair (avg / max / budget / count over budget), wait, picture level, late and hitch frames in this 30 s window, longest gap, and the whole-run share. It only reads the counters and resets its own window maxima, takes no game state, changes nothing in the picture.

## Not done on purpose
- No speed change was made blind: averages are well under budget, so the cause is spikes, and the mod's own spikes cannot be told from the link's without the new PERF lines. The next report will show whether the late frames line up with game work above budget (the mod / game side) or happen with work well under budget (the Virtual Desktop link).
- Things the player can try meanwhile (settings, not mod changes): lower Virtual Desktop bitrate or use its "Sliced" encoding, 5 GHz / Wi-Fi 6 router close by, picture level 1 in the mod menu.
