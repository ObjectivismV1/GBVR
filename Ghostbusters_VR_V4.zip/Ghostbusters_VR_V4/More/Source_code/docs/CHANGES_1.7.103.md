# 1.7.103 - game finger poses, PKE hold, round ghost ring, trap by its top (built on 1.7.102)

## Requests (from the 1.7.102 report)
- Off hand supporting the gun, and the PKE hand, used the mod's animation instead of the game's.
- PKE sometimes disappears when turning.
- Put the game-style health circle back on the ghost, at the same locked position as the mod's bar; remove unneeded VR menu settings.
- Ring must stay on the ghost; follow the game's looking-at-ghost logic.
- Grab the trap by the handle, natural position, easier throw; check the game's animation for traps.
- Left hand bends as if holding the gun when it is not.

## Changes
- Fingers: new `leftFingerKeep` in armcore `curl_hand`: the non-gun hand blends toward the game's own bend. Full game pose while the PKE is out; otherwise follows the wrap amount. Setting `game_fingers`, default on. Log: GAMEFINGERS.
- Left-hand "gun hold" shape now needs a really drawn gun (`engine_gun_placed`) and no PKE / holster.
- PKE: PKEGONE tracker (logs how long and the first cause when the PKE was not at your hand); a short miss (aim/busy causes, up to 150 ms) keeps the last pose.
- Ring: round ring on the focused (`kFlagFocus`, from the ring pick / held ghost lock) ghost, drawn in eye space at the bar's locked position. The game's own ring is a flat HUD sprite, hidden when this is on. Setting `ghost_ring`, default on. It is the mod's drawing, not the game's art.
- Trap: the game's attach table (0x1400d39a0) holds the trap (item 4) at bone `R_Trap` - the RIGHT hand. The mod keeps the trap in the left hand, now turned with the wrist and hung from its top. Throw: hand only has to move 0.40 speed, arm distance 0.05, cooldown 0.35 s. Setting `trap_hold`. Logs: TRAPSHAPE, TRAPCARRY.
- Menu cut to 4 tabs / 13 rows (Start: height, recenter, objectives; Play: snap turn, sprint toggle, left-handed, seated, vignette; View: ghost health, HUD, sharpness, buzz; Help). Hidden settings keep their defaults and stay editable in gbvr_settings.txt.

## Frame rate finding
First PERF run: 71.4 of 90 Hz delivered, game work about 5.5 ms per eye pair, wait about 8.5 ms. Not the mod's work; cause (link / pacing) not found yet.

## Untested in a headset
Everything above. Unknown: where the trap's handle really is (assumed model top), whether the game's left-hand pose during the PKE looks right, why the PKE vanishes (no evidence yet), the 6-8 cm hand/gun gap.
