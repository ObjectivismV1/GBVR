# 1.7.104 - PKE aim, steady off-hand, empty-hand fingers (built on 1.7.103)

## Requests (from the 1.7.103 report)
- "PKE isn't aligned with the controller, it is pulled to the right."
- "Fix all, and off-hand shakes a lot when holding the weapon and walking / sprinting."
- "Left hand middle finger is always down; when the right hand does not have a gun, fingers don't work."
- "PKE and off-hand still don't have anything" (the game's own animation: not found in the data, see below).
- "Check trap as well."

## Changes
- PKE alignment (`pke_align`, default on; new `src/pkealignmath.h`, `armcore.h`, `engine_hooks.cpp`): the hand<->controller relation is captured once from whatever pose the arm solve had, so the PKE's angle to the controller was arbitrary. The PKE's long (front) axis from the locked R_PKE hold is now turned (smallest turn, at most 70 deg) into the controller's centre plane; pitch and roll stay. The meter's centre is moved sideways onto the controller (hand target shifted, at most 9 cm). Log: PKEALIGN. Tests: `test_pkealign` (math) and `test_fingers` 5e (whole arm path on the fake model: 20 deg lean -> 0, hand moved the 4.7 cm asked for).
- Steady off-hand (`fore_steady`, default on; new `src/foregripmath.h`): the gun's place came from the last gun placement and the left hand from the newest controller sample, so walking / sprinting (world moves up to 17 cm per frame at a sprint) moved the hand along the barrel. The gun's place is now rebuilt from the controller of the same sample plus the gun's fixed offset in the controller's axes (slowly averaged, reset at once if the offset jumps by more than ~10 cm = another weapon). On top: a small smoothing of the along-barrel distance (tau 0.05 s, 0.10 s while walking) and the hand's roll steadied toward the right controller's. Log: LEFTHAND (old vs new vs drawn step, standing vs walking). Test: `test_foregrip` (old way jumps 0.17 ft per frame, new way 0).
- Empty right hand (`empty_fingers`, default on): when the gun is holstered or not placed for 0.25 s the right hand uses the free-finger rules (thumb included, full range) instead of the gun-hand rules (animation grip kept, thumb skipped). Test: `test_fingers` 5d (pinkie 0 -> 190 deg with grip squeezed).
- Left hand with the PKE out: 1.7.103 kept the game pose at 100 % (frozen). Now it rests in the game pose but eases (0.12 s) to the controller's fingers when grip or trigger is squeezed.
- Logs: FINGERPOSE (per finger: game bend, asked, drawn, skipped passes), LEFTHAND, PKEALIGN; the TRAP lines (controllers + damage: `TRAP `, TRAPLAUNCH, TRAPFLIGHT) added to the player-log keep list (TRAPCARRY / TRAPSHAPE were already).

## Findings
- Left middle finger: all four left fingers sit at the game's fixed pose (index 146, middle 157, ring 152, pinkie 129 deg total; right 125/170/166/144). The middle is the most closed one, and with 1.7.103's full keep it never moved while the PKE was out. Root cause for "always down" otherwise not found (bones exist, base bend measured); FINGERPOSE will show whether any finger's pass is skipped.
- The game's finger numbers never change in this build (0 before the model change at 15.64 s, then constant): there is no animated finger / hand pose for the PKE or off hand in the data.
- Trap: no trap use in the 1.7.103 report (and the TRAP lines were not in the player log). No change to the trap code; the keep list now records take / carry / throw.
- Frame rate (PERF 71.5 / 63.7 of 90 Hz): SteamVR reports app CPU 6.4 ms, GPU 5.5 ms, AvgSubmitsPerFrame 0.81; the mod's own work is not the limit. Not changed.

## Untested in a headset
Everything above. Unknown: whether the PKE's "front" (tip) axis is what looks aligned to you, the real size of the sideways shift, whether the steady off-hand removes the walking shake completely.
