# 1.7.105 - the left hand takes hold of the gun (built on 1.7.104)

## Requests
- "just make the off hand grab the gun like in the other mod vr video, figure it out"
- "make sure it changes as the gun does, because the gun model changes as you get more stuff"
- "make it look natural and make sure the transition looks good"

## Changes
- Fore grab (`fore_grab`, default on; settings file only, no menu row; new `src/foregrabmath.h`, `armcore.h`, `engine_hooks.cpp`):
  - Squeeze the left grip with the hand near the barrel: the hand takes hold (within 24 cm of the grip point) and is kept ON the gun until it is pulled more than 37 cm away or the grip is released / the gun is put away.
  - While holding, the hand's place along the barrel only changes when the real hand moves more than 9 cm beyond the held place (a dead zone), so thumb pushes, walking and tracking noise do not move it. A clear slide follows, trailing by the dead zone.
  - The grip point is rebuilt from the gun's CURRENT place and length (gunLenFt) every frame, so upgrades that lengthen or change the gun move the hand with it. A different weapon, or a length change of more than 12 %, drops the hold and the next squeeze takes hold on the new gun (log: GRAB the gun changed).
  - Transitions: the hold weight eases in over about 0.1 s and out over about 0.15 s; the sideways/along correction decays over about 0.12 s on release, so there is no pop; the soft distance fade and the 1.0 ft "too far" gate are replaced by the eased grab weight while holding (gate 1.7 ft); the hand lines up with the barrel (35 % more than before) and its roll follows the gun (up to 0.9); a short buzz (35 ms) in the left hand when it takes hold.
  - Fix found by the new test: the arm pass's "did anything change" signature did not include the grab weight or `fore_steady`; both are in it now.
- Logs: `GRAB` lines (took hold: % along the gun, cm, item, distance of the real hand; let go: why, how long; gun changed: item and length before / after) plus a 30 s summary; the prefix is in the player-log keep list.
- Tests: `test_foregrab` (take hold / jitter / slide / release / re-grab / length range / gun moves), `test_armcore` (a hand 1.1 ft away is left alone with the grab off, comes on with the grab weight rising 0.1 -> 1.0 with no step above 0.22 ft).

## Not known
- The other mod's video frames available did not show a left hand on the gun, so this is a standard VR grab, not a copy of it.
- Untested in a headset: whether the 24 / 37 cm take-hold and let-go distances and the 9 cm dead zone feel right, and how it looks on each weapon and after upgrades.
