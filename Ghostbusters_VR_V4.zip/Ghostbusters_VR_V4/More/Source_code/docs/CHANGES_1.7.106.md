# 1.7.106 - the game's own health ring, on bosses too (built on 1.7.105)

## Requests
- "make sure health bar shows up on bosses too and check your in game health setting to make sure everything is good"
- "make sure its the og game health bar"

## What was wrong
- The game has ONE enemy health display: the ring (class CEnemyHealthBar, update 0x24D450, draw 0x24D810). It reads the player's "focus" (a locked target or the PKE's target) and the focus's health (+0xB860 / +0xB868). The headset view never gets a lock, so the probe answers the ring's two questions for the ghost you look at (ring_assist).
- Since 1.7.17 the game's ring was hidden (ring_mode=1) and the probe drew its own bars; since 1.7.103 its own round ring (ghost_ring). That is the mod's drawing, not the game's art.
- Bosses never got a ring or bar: the pick and the bars both asked the game "can the player lock onto this" (virtual +0x360), which a boss's body does not say yes to, both stopped at 45 / 60 m, and both aimed at the bounds centre, which is far from the line of sight for a huge body. The class table does contain the bosses (COrreryBoss, CStayPuftBoss, CGolem, CAzetlor, CLibrarian, CSpiderWitch, CArchitect, CNightmare).

## Changes
- `og_health` (default on, settings file only): the game's own ring is drawn and is the ghost / boss health display. `ring_mode` and `ghost_ring` only matter with `og_health=0` (the 1.7.103 rules, unchanged).
- Bosses (new `src/bossringmath.h`, tested in `tests/test_bossring.cpp`): a boss = a name in the boss list, or any enemy with 1000+ maximum health (the game's tweak data: ghosts 150, Architect 1600, Chairman 1000). It gets the ring by the size of its body: angle from the gaze to the edge of its bounds sphere, up to 450 m, no lock test. The ring sits on the body's centre while the centre is in front of you, sliding smoothly to the point you are looking at as the centre leaves the view. A ghost nearer your gaze wins over a boss (4 degrees of preference). A boss needs a sign it is really there first (hit lately, held in the stream, drawn lately, or a clear line from the game's own line-of-sight test), because the game keeps enemies that are not in the level yet in its list at full health.
- Fallback: hud.cpp records when the game's ring was last drawn on the screen (placed in the eye picture, its spot inside the 1280x720 overlay). If a ghost or boss has the ring and the game's ring was not on the screen for 0.6 s, the probe's round ring covers it (log RINGOG). Because 1.7.16 reported that the game's ring never showed in the headset, this is a safety net, not a second ring: when the game's ring is on the screen the probe's is not drawn.
- The VR menu row "Ghost health" now switches `ring_assist` (the game's ring on what you look at) instead of `hbar`.
- Logs (all in the player log): `BOSS` (each boss the first time: health, size, distance, game's lock verdict, present or not, why; a 30 s summary), `RINGOG` (game's ring on the screen / off the screen / not placed, fallback frames), plus RINGDRAW / RINGFORCE / RINGPICK / RINGGONE / BARSEEN added to the player-log keep list.
- Health settings checked: the player's life bar on the gun (gun_hp_bar, 13 / -4 / -5 cm) reads the same two fields as the game's own focus health (+0xB860 / +0xB868; the game's 0x14007B470 is exactly cur / max), shows only with the proton wand in hand and reads 100 % in the 1.7.103 log; hbar / hbar_size_pct / hbar_alpha_pct / hbar_digits / hbar_gate / hbar_smart / ring_clear_gone belong to the probe's own bars and are unchanged.

## Not known / untested in a headset
- Whether the game's own ring shows in the headset now (it did not in the 1.7.16 report; no log since has the answer). The RINGOG line will say. If it does not, the round ring shows instead and the log says why.
- Whether bosses' health at +0xB860 / +0xB868 behaves like a ghost's (the game's own focus-health code reads the same fields for any target, so it should), and which of the bosses really count as present: the BOSS lines will show it.
- The ring's place on a huge body (gaze-following) and its size on screen.
