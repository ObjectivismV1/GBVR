# 1.7.108

Built from 1.7.106 (1.7.107 was made in another chat and its source was not available here, so its wall fix is redone below).

- **Health ring behind walls (setting `ring_wall`, on).** An ordinary ghost only gets the ring with a clear line from the headset, or while you hit or hold it. A big enemy that is not a named boss (1000+ health, e.g. CBipedLarge, often parked in another room) needs a hit/hold, or "drawn by the game" plus a strict clear line. Log line `RINGWALL`.
- **Show my objectives** (VR pages in the hand) now opens the game's pause menu. From the pages the game is only frozen, so the old request tapped no Start and nothing happened.
- **Holster never affects menus.** Trigger + grip can no longer draw / holster while a menu is up, and the holstered-gun trigger block applies only in real play (the gun gate holsters the gun whenever a menu is up).
- **Off-hand grab follows the real hand more closely**: dead zone 9 cm -> 4.6 cm, takes hold within 30 cm (was 24), lets go beyond 49 cm (was 37).
