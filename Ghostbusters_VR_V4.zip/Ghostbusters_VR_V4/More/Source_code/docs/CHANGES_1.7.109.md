# 1.7.109

- **Off-hand grab wraps AROUND the barrel (setting `grab_wrap`, on; `grab_wrap_deg` 30).** Before, the held hand pointed along the barrel like a fist beside it. Now the palm lies on the barrel, the thumb points to the muzzle, the fingers go round it (leaning 30 degrees toward the muzzle so the wrist is not bent hard). The hand sits on the side of the barrel your real hand is on (under it by default, never over the top). Fades in with the grab. `grab_wrap=0` brings back the 1.7.108 look. Log line `GRABWRAP`.
- **Fingers on the barrel**: closes to a barrel-sized grip (about 65 %), not the game's own closed fist (it buried the fingertips in the palm); the fingertip joint bends too (before it stayed nearly straight); thumb relaxed along the barrel.
- **Trigger finger (setting `trigger_finger_deg`, 40, was fixed 55):** the gun hand's index finger no longer curls so far into the palm at a full pull.
- Not headset-tested. The orientation was checked in a test (fingers point across the barrel, hand moves round it as your real hand moves) but the look can only be judged in the headset.
