# 1.7.113
- two_hand_line (default 0): the gun aims by the RIGHT controller only. The off hand sliding along the barrel no longer moves the front. Weight/sway steadiness with two hands is unchanged. 1 = old aim along the line between the hands.
- health_any (default 1): the game's can-lock test no longer decides alone. A ghost you hit, hold, or that the game drew this moment gets the health ring / bar. New log fields: RINGFOLLOW (overrides hit/held/drawn), BARVIS (drawn), summary renamed RINGLOCK (RINGGONE lines were capped at 40 and swallowed the summary).
- VR menu: Play page "Grab beam: click on, click off" (capture_tap), View page "Ghost health as bars (off = round ring)" (health_style).
- grab_orbit_follow_pct default 10 (hand sits more on top of the barrel).
- Quiet log keeps RINGLOCK, BARVIS, BARS frame=, BARGATE.
