# 1.7.114
- Gun hand thumb stays on the handle (game pose); gun_finger_open_pct default 20. Fixes the main hand looking like it floats beside the handle (right grip squeeze was 0 percent all session, so the open-finger code straightened the thumb).
