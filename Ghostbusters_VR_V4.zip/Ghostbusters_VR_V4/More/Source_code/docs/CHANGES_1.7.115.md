# 1.7.115
- fore_near_cm (default 14): free left hand within that distance of the barrel takes hold without a grip squeeze.
- Removed the "game drew it" shortcut for ghost health (it showed health for ghosts not yet spawned). Hit / held ghosts still get health.
