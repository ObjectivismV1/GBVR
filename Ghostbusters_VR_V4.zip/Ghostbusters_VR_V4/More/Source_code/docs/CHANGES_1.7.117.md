# 1.7.117

- Knock-down keeps the gun: `gungate::raw_knock` ignores a forced move shorter than 6 s while a gun is equipped (src/gungatemath.h, controllers.cpp). Log: `HOLSTER knock-down #n`.
- Controller compatibility (src/ctlprofile.h, wired in vr_openvr.c `hand_read`): Touch-style output is bit-identical to 1.7.116 (tests/test_ctlprofile.cpp, 576-case grid).
  - Valve Index (real Valve maker only): edge-push click (>= 70 % deflection at press time) is dropped until release; quick right-grip tap (<= 0.25 s, no trigger, outside the pack zone, in a level, no menu) = A tap.
  - Vive wand: trackpad = stick; lower pad click (y < -0.5, |x| < 0.8) = A, latched until release; elsewhere = stick click.
  - Windows MR: stick axis 2, trackpad click = A.
  - Other / unknown: stick axis from `Prop_AxisNType` (joystick, then trackpad), else the axis that actually moves; trackpad-only gets the lower-pad A.
  - Grip analog follows the grip button where the controller has no analog grip; axis 2 is never read as grip when it is the stick.
  - Settings-file overrides `controller_layout`, `stick_axis`.
  - No IVRInput (legacy input only, same as before).
- Logs: `CONTROLLERLAYOUT` (axis types, supported buttons, stick axis, counters), HEADSET adds maker/tracking/registered type. Pimax parallel-projection hint.
- VR menu (View): "Resolution (restart the game)" shows the real picture size and steps a ladder of 1080 / 1440 / 1800 / 2160 / 2880 lines at the monitor shape (picturemath `lines_size`, `ladder_step`). New setting `picture_lines` (0 = follow picture_level; 720..2880); 2160 and 2880 keep using picture_level 2 / 3, smaller sizes set picture_lines with level 2. Choosing clears the memory-guard keep level. Log: `PICTURE WxH chosen in the VR menu`, HOOK line shows picture_lines.
- New install (no gbvr_settings.txt) starts at picture_lines=1440; an existing file is untouched (a missing picture_lines key stays 0 = follow picture_level).
