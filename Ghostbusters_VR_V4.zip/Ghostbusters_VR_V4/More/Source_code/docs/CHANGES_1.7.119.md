# 1.7.119

## Ghost health before the first hit
- Reported: no ring or bar on ghosts in the level before the Stay Puft fight. Cause (from the 1.7.118 report): since 1.7.114 a ghost got health only after a hit or hold, because the game's own can-lock test says no in VR and ghosts that have not spawned had to stay blocked. A real report had 0 hits counted in 100 s.
- New rule (ghostmovemath.h, tests/test_ghostmove.cpp): a ghost the game drew in the last frames AND that moved more than 0.6 ft in the last 2 s counts as out, for the ring and the bars. A ghost standing still where the level put it (not spawned) still gets nothing. Needs health_any=1 (default).
- Log: HEALTHFLY line.
- Untested in-game.

# 1.7.119

- Knock-down keeps the gun: `gungate::raw_knock` ignores a forced move shorter than 6 s while a gun is equipped (src/gungatemath.h, controllers.cpp). Log: `HOLSTER knock-down #n`.
- Controller compatibility (src/ctlprofile.h, wired in vr_openvr.c `hand_read`): Touch-style output is bit-identical to 1.7.116 (tests/test_ctlprofile.cpp, 576-case grid).
  - Valve Index (real Valve maker only): edge-push click (>= 70 % deflection at press time) is dropped until release; quick right-grip tap (<= 0.25 s, no trigger, outside the pack zone, in a level, no menu) = A tap.
  - Vive wand: trackpad = stick; lower pad click (y < -0.5, |x| < 0.8) = A, latched until release; elsewhere = stick click.
  - Windows MR: stick axis 2, trackpad click = A.
  - Other / unknown: stick axis from `Prop_AxisNType` (joystick, then trackpad), else the axis that actually moves; trackpad-only gets the lower-pad A.
  - Grip analog follows the grip button where the controller has no analog grip; axis 2 is never read as grip when it is the stick.
  - Settings-file overrides `controller_layout`, `stick_axis`.
  - No IVRInput (legacy input only, same as before).
- Logs: `CONTROLLERLAYOUT` (axis types, supported buttons, stick axis, counters), HEADSET adds maker/tracking/registered type. Pimax parallel-projection hint.
- VR menu (View): "Resolution (restart the game)" shows the real picture size and steps a ladder of 1080 / 1440 / 1800 / 2160 / 2880 lines at the monitor shape (picturemath `lines_size`, `ladder_step`). New setting `picture_lines` (0 = follow picture_level; 720..2880); 2160 and 2880 keep using picture_level 2 / 3, smaller sizes set picture_lines with level 2. Choosing clears the memory-guard keep level. Log: `PICTURE WxH chosen in the VR menu`, HOOK line shows picture_lines.
- New install (no gbvr_settings.txt) starts at picture_lines=1440; an existing file is untouched (a missing picture_lines key stays 0 = follow picture_level).


## Crash safety and gun memory
- Crash step-backs (safetymath.h / safety.cpp) are per run only: a RunOver table is consulted when settings are saved, so saved settings are never lowered. First crash: menu_fast + diag off. Second: + wand / body-follow / arm IK off. Third: picture cap 2. Fourth+: picture cap 1, hand model off, real models off.
- Settings rev 158 migration: when wand_to_hand AND menu_fast are both saved as 0 (the old crash step-back signature, seen in a real report) it restores them and full_body / arm_ik / body_follow to 1.
- Gun gate: DrawMemory keeps drawn/holstered state across gate loss; the first gun of a session is auto-drawn (restore_on_gain returns 0 when uninitialised).
- Not adopted from the ChatGPT candidate: armcore.h / wand-hide changes (unverified).
- Hotel crash (d3d11.dll access violation in post-processing) unexplained; same signature as 0.80.
