# 1.7.139
- Reset the PKE's R_PKE grip after a half-second absence or actor change; the next draw uses a fresh hand relation.
- Smooth enemy health markers in world space for both bars and the circular ring, with a small lag cap and immediate teleport reset.
- Leave the neck visible beneath the hidden first-person head to cover the open collar; headset visual check remains pending.
- Log physical right-stick capture clicks without remapping buttons. The supplied 1.7.138 report did not include a capture click, so beam grabbing still needs an in-game retest.
- 80 host tests pass. No claim of a Hotel crash fix.

# 1.7.138
- Preserve the higher of native and assisted PKE alignment. Target actor origins may differ from native scan points; assistance must never lower the game's accepted aim.
- Visibility, activation, range, cooldown, manual trigger and story logic remain under existing checks. Architect drafting-room report requires an in-game retest and logs if it persists.
- Regression cases cover native-aligned/offset targets and tracked aim assistance.

# Documentation review (2026-10-30; DLL remains 1.7.137)
- README and player guide reconciled with current controls, player-health behavior, offhand release and supported gear.
- Clarified that head-following flashlight and near-head trigger toggle are not in this DLL. No binary or control changes.

# 1.7.137

- Player-health gun strip now accepts gun inventory items 1, 2, 3 and 7. It stays hidden for empty hand, trap, PKE, light, holster and missing weapon.
- Use the same 0.25 s placement freshness as held offhand to avoid a momentary between-shot disappearance.
- Enemy-health small-hit accumulation from 1.7.135 remains.

# 1.7.136

- Reset the old support-hand blend and sliding offset on a weapon style or geometry change. The new native grip eases in with the existing support blend.
- Controller tracking and gameplay inputs remain unchanged.

# 1.7.135

- Accumulate small health drops per enemy between actor scans so weak and continuous firing modes can activate health displays after a confirmed hit.
- Healing resets the baseline. Wall, spawn and trap gates remain.
- Added regression for repeated weak damage and healing.

# 1.7.134

- Smooth small alternating surface-height changes in the rendered eye-height ramp; real steps, jumps and gameplay motion remain native.
- Reset ramp history after actor changes or teleports.
- Added uneven-ground, step and teleport regression checks.

# 1.7.133

- Remove pitch-triggered full-body hiding. Chest, shoulders, hips and legs remain visible.
- Collapse only neck/head into a chest-anchored point, independent of displaced cutscene neck poses.
- Regression sweep checks 360 pitch/yaw cases and repeated render passes against the full-body pose, preserving every non-neck bone.
- Reload input, sounds and steam remain unchanged.

# 1.7.132

- PKE tracked alignment is reapplied after native target enumeration refills the record, as well as in scan_ok. Remove redundant owner/slot guards on the first record’s angle update; the meter is already verified as locally owned by placement, and the game still determines the selected slot.
- With pke_close_help, a locked target within 8 feet and 12 degrees of the headset reticle may use the gaze angle while also in front of the meter. Visibility, target state, trigger and cooldown remain native checks. No automatic scan or target fabrication. The report showed correct model pitch but continued 55-68 degree scan errors nearby.
- Existing installs migrate once to health wall checks enabled. Hit/held ghosts no longer bypass ring wall checks; bars immediately require a direct clear line without the near-side/thin-wall fallback or 0.3 s through-wall grace. Movement/render timestamps alone no longer activate ordinary enemy health before spawn. Boss health also gets the strict wall check.
- Cached health bars are rebased from their capture head pose into the current head pose when read. This fixes head-relative sliding/bouncing while actor scans reuse a recent result.
- Reload/vent input retains its gameplay action. In hand-lock mode, the rendered upper body uses a private pre-reload pose through the reload input and a 1.5-second animation tail; controller/head tracking and the live game animation locals remain intact. A weapon/skeleton change discards that render cache. The tracked gun-hand relation is also preserved through reload so native weapon animation cannot rotate it. Sounds and steam still receive the original reload action.
- Tests cover close-reticle acceptance/rejection, bar rebasing after head translation/yaw, and preserving upper-body render placement without changing game animation locals. Full 79-test host suite passes. Live gameplay confirmation is pending.

# 1.7.131

- The supplied 1.7.130 report records PKE pitch 78.6 degrees above the controller, still unchanged despite pke_pitch_deg=0. The pitch guard rejected any correction above 70 degrees. Permit upright holds up to 100 degrees, keeping the reverse-axis guard and centre compensation.
- The report records an unscanned collectible 4.3 feet away and 66 degrees off the scan line. Before the game checks its locked scan target, recompute its alignment from the fresh tracked controller origin/direction. Only the local player’s held meter in VR hand-aim/easy-scan mode is affected. The original visibility, target-state, cooldown and range checks still run; no target is created and no scan is started automatically.
- hand_lock=1 now stays rigid while firing and when firing/support is released. It previously forced weight/recoil on during a one-handed shot, then snapped back to rigid on release.
- Tests cover the reported 78.6-degree hold, +/-89-degree holds, close/far tracked scan angles, invalid directions, and 1,000 firing/support transitions without recoil/pose drift. Full host suite passes; live gameplay confirmation pending.

# 1.7.130

- Additional validation: 10,000 simulated solver frames with changing weapon lengths, native support offsets, body yaw/scale, grip/release and tracking loss. Held wrist stayed at its native target (within 0.005 game feet); right-arm matrices matched the native-grip-disabled baseline, and fully released poses matched it. No non-finite bone matrices.
- All seven decoded controller cases (Touch, Index, Index emulation, Vive, WMR, generic and unknown) passed deliberate grip/hold/release/re-grip with persistent touch and proximity. The complete 79-test host suite passed. These are software simulations, not an in-game test of each weapon or controller. No runtime code changed during this validation.

- While a confirmed support grab is held, the left wrist position and orientation come from the current game animation relative to the native weapon hand, then follow that hand in VR. This replaces the guessed cylinder radius, overhand orbit, and controller-dependent slide for the normal wrapped grip.
- The hand uses the animation’s own fingers at full grip. It blends back to controller tracking on release. The input/grab release rule from 1.7.129 is retained.
- The source relationship is rebuilt from untouched local bones every pass, so weapon animation and upgrade changes update it without carrying a stale old grip. The previous procedural grip remains a fallback for missing/implausible native poses.
- Regression checks translated/turned/scaled body placement, different weapon lengths and native support offsets, stationary held attachment despite controller motion, and wrist orientation. Host tests pass; appearance across actual game weapons still needs headset verification.
- PKE scanning is still unresolved; no PKE scan changes in this build.

# 1.7.129

- Player feedback confirms two-hand steering works in 1.7.128, but the proximity fallback kept steering without grab. In two_hand_line=1, both the aim hold and visible barrel hold now require the grip button. Letting go cancels aim support on the next controller poll even if the hand stays by the barrel. The visible hand eases away using its existing animation fade.
- The three-poll engagement debounce and distance hysteresis are retained; legacy two_hand_line=0 retains proximity steadiness.
- Regression covers near-hand/no-grip, deliberate grip engagement, release while still near, re-grip, and lost pose. PKE unchanged. Host tests pass; live Index confirmation pending.

# 1.7.128

- Toxin’s new 1.7.127 report confirms the old saved settings file still contains two_hand_line=0, overriding the new code default. The log confirms left-hand barrel holds, so the missing aim response is the saved setting.
- Raise settings_rev to 159 and change an existing two_hand_line=0 to 1 once on upgrade. The setting remains writable: changing it back to 0 after the upgrade keeps right-controller-only aim. Fresh installs already start at 1.
- PKE behavior unchanged. Host tests pass; in-headset check pending.

# 1.7.127

- The supplied Valve Index report is from 1.7.126. It records a tracked left hand taking hold of the barrel and confirms support, but two_hand_line=0 prevented that hold from steering the beam.
- The default is now two_hand_line=1: once the existing three-poll hold is confirmed, the two-hand pose drives the wand, beam, and aiming together. An explicit two_hand_line=0 retains right-controller-only aim. No PKE behavior changed.
- Host tests pass; headset verification pending.

# 1.7.126

- The upper body bends in its own facing direction when the headset turns while looking down, avoiding the sideways chest twist.
- On a steep look down in normal full-body mode, the chest and lower body geometry temporarily give the camera clearance while the arms keep tracking. A 50/35 degree hysteresis avoids toggling on tiny head movements. Scripted cutscenes and PKE mode retain their existing behavior.
- Keith’s supplied Hotel crash report is from 1.7.120 and records an access violation in the Windows system d3d11.dll while the game was simulating. This change does not establish or claim a crash fix; needs a current-build report if it recurs.
- Host tests pass; in-headset verification pending.

# 1.7.125

- The 1.7.124 cutscene blend no longer averages body rotation matrices element by element. It fades the turn angle, scale and eye offset into the game pose as a rigid transform. This keeps the basis full-length even through a 180-degree turn.
- The new 1.7.124 report confirms the DLL and cutscene path ran. Its PKE grip stayed about 9 cm from the drawn hand while the item was visible, but PKEGONE reported several 0.25-2.38 s gaps where the game did not draw the meter. No verified cause for that visibility loss or the reported vertical drift has been identified.

# 1.7.124

- Detected scripted/forced cutscenes now activate the existing cinematic blend even with keep_control=1 (the public default). Body, arms, pack/hose, and gun yield together to the game animation, then ease back together. Headset camera tracking and the Stay Puft scene-view escape rule stay in place.
- The cutscene detector has no game-provided cutscene flag. It engages on a sustained forced move or scene jump; stationary scripted scenes without these signals still need a real game report.

# 1.7.123

- While the left stick is actively walking, head-follow body turning starts at 10 degrees and settles near 5 degrees; previously the default 75-degree standing setting yielded a walking start around 41 degrees. Standing, snap turns, and scripted camera guards retain their behavior. Existing walk_head stick rotation remains enabled.
- Tests cover the reported 20-degree head turn while moving and the unchanged standing case. Live headset verification pending.

# 1.7.122

- Offhand steadiness accepts a recent barrel hold from the existing render arm solver on any controller type, even when SteamVR's legacy grip bit is missing. It does not fake a button press or change the original grip bindings.
- Proximity fallback requires a drawn gun, active hand poses, and the fore_grab setting. It drops when the hand leaves the barrel, the rendering hook stops, a menu opens, or a trap/PKE is held. Controller layout and original manual grip behavior are preserved.
- The offhand report from Valve Index showed repeated visual GRAB holds while the GUNHAND counter stayed at two hands 0; this bridges those two paths. Live device verification is pending.

# 1.7.121

- The fixed Stay Puft scene view releases after deliberate walking away from its anchor, letting the normal player camera resume after the Times Square cutscene. The scene view remains active during its scripted phase.

# 1.7.120

- Boss ring: a named boss that moves (ghostmovemath.h) or while the Stay Puft fight scene is on counts as present (20 s latch like a hit), so the short one-hit phase before the fight gets its ring. Log: BOSS data field byMove, BOSSNOW wording.
- Right arm with nothing equipped (itCur == 0, firehouse infirmary): arm_drive no longer solves from the game's (stale) wand matrix (gr = 7); the hand follows the controller alone, like the PKE hold. Log: ARMNOGUN.
- quietlog whitelist: HEALTHFLY (it was filtered out of the 1.7.119 reports), ARMNOGUN, BODYWHOLE / BODYDRAW / BODYREL.
- Untested in-game.

# 1.7.120

## Ghost health before the first hit
- Reported: no ring or bar on ghosts in the level before the Stay Puft fight. Cause (from the 1.7.118 report): since 1.7.114 a ghost got health only after a hit or hold, because the game's own can-lock test says no in VR and ghosts that have not spawned had to stay blocked. A real report had 0 hits counted in 100 s.
- New rule (ghostmovemath.h, tests/test_ghostmove.cpp): a ghost the game drew in the last frames AND that moved more than 0.6 ft in the last 2 s counts as out, for the ring and the bars. A ghost standing still where the level put it (not spawned) still gets nothing. Needs health_any=1 (default).
- Log: HEALTHFLY line.
- Untested in-game.

# 1.7.119

- Knock-down keeps the gun: `gungate::raw_knock` ignores a forced move shorter than 6 s while a gun is equipped (src/gungatemath.h, controllers.cpp). Log: `HOLSTER knock-down #n`.
- Controller compatibility (src/ctlprofile.h, wired in vr_openvr.c `hand_read`): Touch-style output is bit-identical to 1.7.116 (tests/test_ctlprofile.cpp, 576-case grid).
  - Valve Index (real Valve maker only): edge-push click (>= 70 % deflection at press time) is dropped until release; quick right-grip tap (<= 0.25 s, no trigger, outside the pack zone, in a level, no menu) = A tap.
  - Vive wand: trackpad = stick; lower pad click (y < -0.5, |x| < 0.8) = A, latched until release; elsewhere = stick click.
  - Windows MR: stick axis 2, trackpad click = A.
  - Other / unknown: stick axis from `Prop_AxisNType` (joystick, then trackpad), else the axis that actually moves; trackpad-only gets the lower-pad A.
  - Grip analog follows the grip button where the controller has no analog grip; axis 2 is never read as grip when it is the stick.
  - Settings-file overrides `controller_layout`, `stick_axis`.
  - No IVRInput (legacy input only, same as before).
- Logs: `CONTROLLERLAYOUT` (axis types, supported buttons, stick axis, counters), HEADSET adds maker/tracking/registered type. Pimax parallel-projection hint.
- VR menu (View): "Resolution (restart the game)" shows the real picture size and steps a ladder of 1080 / 1440 / 1800 / 2160 / 2880 lines at the monitor shape (picturemath `lines_size`, `ladder_step`). New setting `picture_lines` (0 = follow picture_level; 720..2880); 2160 and 2880 keep using picture_level 2 / 3, smaller sizes set picture_lines with level 2. Choosing clears the memory-guard keep level. Log: `PICTURE WxH chosen in the VR menu`, HOOK line shows picture_lines.
- New install (no gbvr_settings.txt) starts at picture_lines=1440; an existing file is untouched (a missing picture_lines key stays 0 = follow picture_level).


## Crash safety and gun memory
- Crash step-backs (safetymath.h / safety.cpp) are per run only: a RunOver table is consulted when settings are saved, so saved settings are never lowered. First crash: menu_fast + diag off. Second: + wand / body-follow / arm IK off. Third: picture cap 2. Fourth+: picture cap 1, hand model off, real models off.
- Settings rev 158 migration: when wand_to_hand AND menu_fast are both saved as 0 (the old crash step-back signature, seen in a real report) it restores them and full_body / arm_ik / body_follow to 1.
- Gun gate: DrawMemory keeps drawn/holstered state across gate loss; the first gun of a session is auto-drawn (restore_on_gain returns 0 when uninitialised).
- Not adopted from the ChatGPT candidate: armcore.h / wand-hide changes (unverified).
- Hotel crash (d3d11.dll access violation in post-processing) unexplained; same signature as 0.80.
