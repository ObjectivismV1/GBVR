# 1.7.140 (V1.2)

Evidence: Keith's gbvr_report_20261031-202003.zip (1.7.139, seated, Quest). Two crashes, identical: c0000005 at ghost.exe+0x50376a reading address 8.
ghost.exe+0x44C040(id) is the game's Steam achievement call; it loads the manager pointer at 0x2A867B0 and indexes it (0x503760: [rcx+8]).
That manager is only created when SteamAPI_Init succeeds (0x44C080, else it prints "SteamAPI_Init() failed" and leaves the pointer null).
All three runs log launchedBySteam=0 and there is no steam_appid.txt in the game folder, so the game had no Steam API and crashed on the first achievement.

- New hook on 0x44C040 (bytes checked): with a null manager it returns false and logs STEAMSTATS instead of crashing. With Steam it calls the game as before.
- Measure my height: when seated play is on, a head height under 1.35 m is refused (reason 4). Keith's seated measure set the world size to 90 %.
- MEASURE / CALIBRATE / SEATED / STEAMSTATS lines now reach the player log.
- The third run's "character moves normally / I see through its head" and floating PKE are the safety step-back after two crashes (full_body, arm_ik, wand_to_hand, body_follow off for one run): expected to stop once the crash is gone.

Host tests and layout check only; not run in the game.
