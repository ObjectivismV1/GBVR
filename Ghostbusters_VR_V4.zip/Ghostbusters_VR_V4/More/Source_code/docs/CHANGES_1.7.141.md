# 1.7.141 (V1.3)

Discord (Nov 5): Flashgordon007 and Gunshine (HOTAS) could not move with the left stick until every USB game device was unplugged.

The VR controllers answer as XInput pad 0. The game reads a slot through DirectInput instead of XInput when a DirectInput device holds it, so a HOTAS / joystick / wheel in slot 0
means slot 0 is never asked through XInput. The 1.7.92 DirectInput takeover only fired when the game made no XInput calls at all; the game still polls XInput for slots 1-3, so it never fired.

- XInput calls for slot 0 are counted on their own.
- New rule (padmath.h di_takeover_should_arm_slot0): VR pad live for 2 checks, a DirectInput device in slot 0, and no XInput call for slot 0 since the last check -> the existing takeover
  closes the game's DirectInput devices (Unacquire/Release, the game's own pad-gone function) so the game's next scan takes XInput slot 0 = the VR controllers. At most 6 tries a run.
- Log: DITAKEOVER armed (1.7.141) ... and the existing DITAKEOVER line naming each closed device.
- Tests: 8 new checks in test_pad.cpp. Not run in the game.
