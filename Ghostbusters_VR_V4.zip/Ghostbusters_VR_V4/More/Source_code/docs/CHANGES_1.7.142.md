# 1.7.142 (V1.4)

Evidence: the YouTube review "Finally, A GOOD Ghostbusters VR Game!" (17 min, Quest). Watched as frame sheets every 3 s, with close-ups where something looked wrong.
The voice-over (first 2.5 minutes) has no complaints. The visible problem was Stay Puft's full health ring on his chest for the whole "Escort Ecto-1 in pursuit of Stay Puft" walk
(14:27 to 16:48), while he is far ahead and can't be fought.

Cause: the 1.7.119 rule (a named boss that moves counts as engaged, so the roof phase that ends in one hit shows a ring) had no distance limit. Logs from earlier reports:
escort / street 84-130 m, roof phase 43-44 m, real fight 57-71 m (engaged by hits and the fight scene).

- bossringmath.h move_range_m() = 60, moving_counts(moving, distM). The fight scene rule and the lost-health / held rules are unchanged.
- Log: "BOSS <name> moves N m away (more than 60 m): no ring ..." (6 lines at most).
- Tests: 6 new checks in test_bossring.cpp. Not run in the game.
