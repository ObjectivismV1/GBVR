# 1.7.143 (V1.5)

Evidence: the YouTube review video. Early on (0:54, 3:15) the gun is in the hand; later it is not: the PKE floats above / beside the hand at 12:30 and 12:48, the hand slides down
the gun at 13:00, and at 15:03 and 16:45 the gun sits 20-30 cm above the hand. Matches iiizoneriii's report (hand and PKE apart, the gap changes over time) and the GUNSLIP lines of
earlier reports (the drawn hand 6-54 cm from where the controller puts the gun, axes exact, arm not stretched).

Cause: handprop HandFollower (hand <-> controller relation) locks after 5 steady samples and is never updated for the life of the player actor. gun_ctl_follow (1.7.78) puts the
gun on the CONTROLLER through it, and the PKE uses it whenever its hand is rebuilt from the controller. The capture call after a lock even received the controller-carried hand,
so nothing could correct it.

- handprop.h HandDrift / drift_step(): once locked, compare the ARM SOLVE's hand with the relation; a difference over 3 cm (or ~10 degrees) that stays steady for 20 samples
  (fast swings excluded: the 1.7.78 reason) eases the relation into the drawn hand, 12 % per sample, until within ~6 mm.
- Gun: called with the hand before it is replaced by the controller-carried one; not during a reload hold.
- PKE: called next to the three handFollow captures.
- Log: PROPDRIFT (whitelisted) once per easing.
- Tests: drift_step cases in test_handprop.cpp. Not run in the game.
