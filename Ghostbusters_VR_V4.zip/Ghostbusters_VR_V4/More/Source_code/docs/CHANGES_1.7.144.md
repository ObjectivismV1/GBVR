# 1.7.144 (V1.5.1)

Stress test of the 1.7.143 drift_step (tests/test_handdrift_stress.cpp, now part of run_all): simulated sessions up to 2 hours at 90 arm passes a second with slow drift
(2 cm/min, the video), 25 cm steps (level loads), 15 degree rotation steps, constant fast swings with the arm trailing, 3 cm walking bob, 5 mm tracking noise, world size
90 / 115 %, non-finite arm frames, and everything at once.

1.7.143 FAILED two: with 5 mm per-sample noise the "steady" test (6 mm between raw samples) was never met, so the gap grew to 20 cm; the 2-hour mixed run had a 30 cm p99 and
took 38 s to settle. Fix: the drawn hand's relation is smoothed first (ema 0.15, ~80 ms); steadiness is judged on the smoothed one, a raw sample more than 3 cm from it (a fast
swing) stops the check, a jump over 15 cm restarts the smoothing, and the relation eases toward the SMOOTHED hand (no jitter is passed on to the gun).

1.7.144 results (gap between the placed hold and the drawn hand while steady): every scenario p95 <= 3.2 cm, p99 <= 3.6 cm, settle after a 25-30 cm step <= 2.1 s,
no false corrections with no drift (0 relocks, p99 0.4 cm), about 0.2 microseconds a call. Not run in the game.
