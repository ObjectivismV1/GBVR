# 1.7.145 (part of V1.3)

User request: when the in-game VR settings are open, the PC monitor should keep the game view so people watching can see how it works, not the menu pasted over everything.

- render_hooks.cpp: with the VR settings open the PC window first draws its normal picture (monitorview_present: the headset view; or flatview in flat mode), then
  monitorview_menu_present(sc, inset=1) draws the pages on top as a panel, 62 % of the window, centred, without clearing. Only when there is no game view (monitorview
  returned 0) does the menu fill the window as in 1.7.90.
- The pointer (its own SteamVR overlay in the headset, so never in the copied picture) is drawn as a small yellow dot at the same place on the PC panel (vrmenu_pointer()).
- MONITORVIEW log line says which way it is drawn. Headset picture unchanged. Not run in the game.
