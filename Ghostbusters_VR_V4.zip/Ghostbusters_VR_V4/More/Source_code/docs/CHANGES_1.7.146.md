# 1.7.146 (V1.3.1)

Discord (Nov 8): gamerdood35 "the left hand getting twisted up"; Keith "PKE and proton pack still hovering above the hand".

Twist: armmath.h twist_about() returns the hand's turn about the forearm wrapped to -180..180 deg; forearm_roll gave the forearm 50 % of it. Past 180 deg (hand under the barrel,
palm up) the angle jumps +180 -> -180, so the forearm's share jumped +90 -> -90 deg in one frame (a half-turn flip, the skin between elbow and wrist twisted). Proven by a test that
turns the hand 150 -> 210 deg: the old code flips, the new one does not.
- forearm_roll_cont(): the angle is kept continuous from the last frame (nearest th + k*360, reset after 30 calls without the arm, or beyond a whole turn) and the forearm's share
  is capped at 100 deg. ARMROLL log line counts wraps and caps (now in the player log).

Hover: no new cause found in code or the logs on hand (they show the PKE locked ~9 cm from the drawn hand bone). The arm reach / wrist-miss summaries (REACH, ARMS frame=) were
filtered out of the player log; they are now kept so the next report shows whether the drawn hand falls short of the controller.
Tests 81/81, layout ALL PASS. Not run in the game.
