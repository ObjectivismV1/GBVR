# 1.7.147 (V1.3.2) LOCK TO THE HAND

Keith (V1.3, Nov 8): PKE and proton gun still hover above the hand. Request: lock them to the hand.

Two paths still put the props on the CONTROLLER instead of the drawn hand:
- Gun: gun_ctl_follow (1.7.78, default 1): gun = controller x a locked hand<->controller relation. 1.7.143 eased that relation toward the hand, but only while steady.
  Now default 0 (code default and a one-time settings migration, rev 161): gun = the arm solve's hand (moved on with the controller since the solve) x the game's own hand->gun hold.
- PKE: with pke_hold_rpke (default) the meter's own hold is often not there (Keith's 1.7.139 log: 15579 of 22816 placements "rebuilt-from-controller"); those frames used a hand
  rebuilt from the controller through a relation taken once. Now, when the drawn hand pair exists, the locked grip goes on the DRAWN hand; the controller-rebuilt hand is only used
  when there is no drawn hand at all. PKEHELD counts it ("on the drawn hand without its hold").

Tests 81/81 (incl. the 2-hour drift stress test), layout ALL PASS, DLL builds. Not run in the game.
