# 1.7.148 (V1.3.3)

Request: "add the hose from the gun to the pack FROM THE GAME, don't make your own, make it look good and follow the gun"; "make sure the grab animation looks good".

Hose (read from ghost.exe): the hose is a skinned model instance at actor+0xD7B0 of the same class as the body (0x30FD10 / 0x312490 / 0x3149F0 read its +0x2088 / +0x7930,
the body's skeleton offsets). The player's update poses it with the body's animation (0x38E270(anim = actor+0xD428, actor, hose instance, ...)); its world matrix
actor+0x24758 is an attach point on the pack (0xD54A9), pushed at 0xD257F (after the wand at 0xD2470 in the same render function). So in the game it meets the gun the
animation holds; in VR the gun is elsewhere, which is why the mod hid it (hose_off 1) and drew a cord of its own (cord_physics).
- hosemath.h: longest bone chain, smooth weights 0 (pack end) .. 1 (gun end) by length, the model-space move Dm that takes the game's gun to the drawn gun
  (inv(gunGame x inv(hoseGame)) x (gunDraw x inv(hoseDraw))), and a per-bone blend (nlerp turn, linear size / position). tests/test_hose.cpp: the gun end lands exactly on
  the drawn gun, the pack end does not move, no segment stretches past 2.5x, half weight = half the turn, a half-turn and bad matrices are safe.
- arms.cpp arms_hose_follow(): checks the instance like the body (skeleton bone count = instance's, parents before children, readable) and that one end of the chain is
  within 1.5 ft of the game's own gun (else nothing is written). Keeps the game's own pose (never rebuilt; the copy is used when the cache still holds our last bend:
  second eye / no new game pose). HOSEBONES logs the hose's bone names; HOSE logs success / why not.
- engine_hooks.cpp: the wand push records the game / drawn gun; the hose push (body_push which 2) bends the hose when that gun is from this render (< 50 ms).
  The game's hose is HIDDEN whenever it was not bent within 0.25 s (except when the game places the gun or a cutscene runs), so it can never hang in the wrong place.
- Defaults: hose_off 0, cord_physics 0 (code defaults and a one-time settings migration, rev 162). hose_off 1 still hides it.

Grab: the finger curl easing now staggers per finger (close: thumb / index 40 ms .. little finger 66 ms; open: little finger first), so a squeeze rolls in like a real grab.

Tests 82/82, layout ALL PASS, DLL builds. Not run in the game: whether the hose's skeleton reads as expected is unknown until a log (HOSEBONES / HOSE lines) comes back.
