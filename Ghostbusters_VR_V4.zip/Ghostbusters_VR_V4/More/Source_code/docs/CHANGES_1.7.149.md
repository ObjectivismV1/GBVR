# 1.7.149 (V1.3.4)

Request: "don't hide, just make it work; make sure the hose always works and is from the game; keep all in-game animation".

- The mod no longer hides the game's hose when it could not bend it (the 1.7.148 safety); only hose_off 1 hides it. Not bent = the game's own pose (cutscenes, game-placed gun,
  PKE out with the gun stowed: the hose is where the game animates it, to the game's gun).
- The hose follows every gun the mod draws: in the hand (before the view-model size, so the hose keeps its thickness) and the holstered gun (hose_gun_note()).
- hosemath longest_chain accepts parents in any order (loop / out-of-range refused); tests added.
- The chain's nearer end is always moved with the gun, even when it is more than 1.5 ft from the game's gun (counted only), so the game's own offset to the gun is kept.
- The bend starts from the game's animated hose every frame, so the game's own hose motion is kept.
Tests 82/82, layout ALL PASS. Not run in the game.
