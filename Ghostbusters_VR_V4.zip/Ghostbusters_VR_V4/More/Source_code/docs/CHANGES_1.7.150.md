# 1.7.150 (V1.3.5) recheck of 1.7.140-1.7.149 and stress test

Found by re-reading the code:
1. Forearm roll (1.7.146): the "continuous angle" memory could be left a whole turn off by one tracking glitch (a jump over 180 deg in a frame); the forearm then stayed
   twisted by up to 100 deg until the hand went round again. Replaced by a memory-free rule: the forearm's share fades out between 120 and 175 deg of turn (zero on both
   sides of the wrap). Test: two whole turns each way in 0.1 deg steps, largest step < 0.01 rad; identical to the old share below 120 deg; a glitch leaves nothing behind.
2. Hose with the PKE out: the game's PKE view marks the player's parts "mirror only"; the mod overrode that for body and pack but not the hose (kSiteHose was excluded
   because the hose used to be hidden anyway). The hose is now kept visible like the pack.
3. Hose with body_follow off (e.g. the crash-safety step-back): body_push returned before the bend. The hose push now always tries the bend (with the game's own matrix
   as the draw matrix when body_push did not change it).
4. Hose and the PKE: the wand slot can hold the PKE; the hose must never be bent to it. hose_gun_note is skipped while the PKE is held, and the bend is refused (game's
   pose kept, nothing hidden) when the hose's end is more than 2.5 ft from the game's gun (the gun is stowed then).
5. Hose shape: the plain blend put most of the move into the middle (stress test: segments up to 3.6x, others folded). even_out() slides the chain's bones along the
   bent line so every segment keeps its share of the length. Stress test now: 99 % of segments <= 2.3x with the gun thrown up to 3 ft / any angle from the game's gun on
   a 3 ft hose (far beyond play); both ends exact.
6. Monitor: with monitor_view off the VR settings still filled the window; now always a panel.
7. STEAMSTATS hook: checked that the caller (0x1F3E53) ignores the return value.

New: hosemath Keeper / bend() (the game's pose kept apart from ours; the same code runs in the game and in the tests), tests/test_hose_stress.cpp (60000 frames: two eyes
identical, no piling up through pauses, pack end fixed, gun end within 0.00002 ft, PKE-out and broken matrices leave the game's exact pose, 2.5 microseconds a call).
Not run in the game.
