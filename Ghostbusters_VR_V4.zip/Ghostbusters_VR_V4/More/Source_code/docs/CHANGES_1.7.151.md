# 1.7.151 (V1.3.6)

Report: "fix the in-game cutscenes, the player switches places quickly and it is very disorienting" (the in-game ones, not the 2D videos);
"can the ambient light in the 2D scenes be the colour of the screen ... whatever is being played in the corner".

## Cutscenes
Evidence (report logs, e.g. 1.7.139 20261031-195018): during a cutscene the flat screen alternates with short 3D stretches:
2D 9.3 s -> 3D 83 frames -> 2D 3.2 s -> 3D ... -> 2D 4.8 s -> 3D 51 frames -> 2D. Each 3D stretch is the game's play camera between two
shots; the mod showed it in first person inside the character (in another place each time), with a CINE "jump" logged next to it.
1. cutholdmath.h (new, pure, tested): once the 2D screen is up, a frame of the play camera is only shown in 3D when the play camera has
   passed every check without a break (0.25 s) for cut_hold_ms (2000). Until then hk_prepare_impl treats the frame like any refused camera:
   the game's own unmodified picture goes to the 2D screen (same path as before: nothing hidden, nothing changed in the game).
   No wait: within 2.5 s of the game's pause flag, or when the move stick is pushed past half / a trigger is pulled. While 3D is up it does nothing.
2. cut_fade (1): forcedmath counts a jump of the character (> 5 ft in a frame); when that happens in 3D the existing fade-up-from-black
   (stereo fade_in, as used for the Stay Puft station) is started. Not in the Stay Puft scene-arms mode.
Known cost: after a loading screen or a cutscene the first 2 s of play are on the 2D screen unless the stick is pushed / a trigger pulled.
Log: CUTHOLD lines (each hold start / end, and a summary with the longest shot kept 2D).

## Glow
The steady glow was one white halo tinted with one slow colour (tau 6 s, 0.05 / s) at a fixed brightness. New (flat_glow_corners 1, steady glow only):
four layers = the same halo with its alpha multiplied by a corner share (smoothstep, the four add up to 1), each sent once and then only tinted
(SetOverlayColor: no re-sent pictures, the cause of the 1.0 flashing) with corner_target(mean of that corner's 60 % x 60 % of the picture):
stronger hue (at most 20 % white), brightness 45..100 % with the picture, tau 1.3 s, at most 0.45 / s per channel.
vr_openvr.c: the glow overlay became an array of 5 (0 = the single glow as before, 1..4 corners); the old two functions call index 0.
If any corner layer is refused all four are hidden and the single glow is used for the rest of the session (GLOWCORNERS line).

## Tests
test_cuthold (the report's sequence), test_cuthold_stress (60 million frames, 200000 random cutscene / play / menu episodes, 0 rule breaks),
test_glowcorners (shares add to 1, corner colours, 200000 random pictures: all colours in range, no step over the cap).
Not run in the game.
