# 1.7.152 (V1.3.7) logic check of 1.7.151 + stress test

Found by re-reading the 1.7.151 code against the rest of the mod:
1. The wait applied after ANY 2D screen. A short scripted camera in the middle of play (> 12 frames, so the 2D screen comes up) would have cost
   2 s on the 2D screen with the VR controls in menu mode. Now: no wait when 3D was shown less than 2 s ago (cuthold Hold::last3D / quickRun).
   A held shot does not count as "3D shown", so cutscene shots separated by short 2D shots are still held.
2. No wait within 2.5 s of a frame refused for the headset pose (headset off / tracking lost is not a cutscene).
3. The trigger ended the wait. On the 2D screen the trigger is the click people skip cutscenes with -> stick only.
4. cut_fade used forced::teleports, which counts a run of jumps once (only when not already "forced"): the 2nd, 3rd cut of a row did not fade.
   New forced::jumpsAll counts every jump (no change to the forced logic). Also required speed > 80 ft/s: 5 ft covered during a long hitch
   while running is not a jump.
5. follow_post (body turns toward the head) had already published its push when the hold refused the frame. The pad is not given to the game
   while the 2D screen is up, so it had no effect, but the hold now calls follow_stop() like the lost-pose path.
6. Corner glow: a single SteamVR error on any call (also a plain move) switched the corners off for the session. Now the corner layers are hidden
   and tried again; 3 failures in a row before the single glow takes over. Sort order: top-left / bottom-right 0, top-right / bottom-left 1
   (coplanar neighbours no longer share an order; the screen stays 2, nothing else uses 0 or 1).
Checked and left: fade is cleared when a 2D screen comes (enter_flat_mode) and removed by force after 0.7 s; suspended frames feed no safety counter;
the hold uses the same refused-frame path as every other gate; the glow overlay hide / destroy paths cover all 5 layers; imports of the DLL unchanged.

Stress: test_cuthold_stress rewritten against an independent model: 450000 runs / 135 million frames over three waits (2 s, random, off), six kinds
of episode (short shot, long play, after a menu, with the stick, blip in play, hitch in 3D), far into a long session, plus 4 million frames with
NaN / infinite / backward / jumping clocks. 0 rule breaks with g++ and clang++.
Not run in the game.
