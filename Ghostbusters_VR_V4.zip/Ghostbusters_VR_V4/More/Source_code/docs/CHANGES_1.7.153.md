# 1.7.153 (V1.3.8) FPS limit, anti-aliasing

Request: "add FPS limit option, add it to the VR menu, see if you can improve performance in any way, add anti-aliasing or DLSS".

## FPS limit (vr_fps_cap; VR menu > View > FPS limit)
The setting existed since 1.7.33 but had no menu row and only acted when the headset's rate EQUALLED the limit (where WaitGetPoses already limits):
it never did anything useful. Report logs show why a limit matters: game work per eye pair 12.5-15 ms against 11.1 ms at 90 Hz -> 55..76 pairs/s,
"late" on 40 % of frames. Held at a steady 45 the compositor's reprojection has an even input.
- ratecap.h: options Off/30/36/40/45/60/72/80/90/120; divisor(displayHz, limit) = show a new pair on every Nth headset frame (rounded so the result is
  never above the limit); sleep_ticks(): sleep until 0.15 of a frame past the (N-1)th headset frame since the LAST PAIR'S WaitGetPoses returned; the
  normal WaitGetPoses then ends on the Nth. The reference is the wait itself, so it cannot drift against vsync. Never more than N-1 frames of sleep.
- stereo.cpp: runs only between pairs, in 3D (not on the 2D screen, not for the chest camera). Sleep uses a high-resolution waitable timer for all but
  1.5 ms, then yields (plain Sleep can overshoot 15 ms); without that timer it only yields.
- The rate / budget checks know the limit (g_capDiv): work budget = N periods, PERFADVICE target = headset rate / N, PerfWatch (which can lower the
  picture level for the next start) compares against rate / N. Otherwise a 45 limit would have looked like "the PC cannot keep up".

## Smooth edges (eye_aa, eye_aa_sharp_pct; VR menu > View)
New src/eyeaa.cpp. After the eye picture is copied (and the hand models drawn) one full-screen draw writes a filtered copy into a second texture; that one is
submitted (also by the frozen-world path). Filter: fast post-process edge smoothing (blend along the local edge direction where the brightness contrast
is high) and, on non-edge pixels, a light unsharp step clamped to the neighbours' range. State saved / restored as in flatview.cpp; shaders compiled
with d3dcompiler_47.dll at first use; 3 failures switch it off; off = all its objects are released and the submit path is byte-for-byte the old one.
The PC window, chest camera and screenshots keep the plain pictures.
Checked here: the HLSL compiles with glslang's HLSL front end (both stages, both colour modes, several sharpen values); tests/test_eyeaa.cpp runs the
same arithmetic on the CPU (flat picture unchanged, a slanted hard edge becomes a ramp with the brightness kept and no halo, 576000 random pixels never
leave the range of the pixels read). NOT checked: Microsoft's compiler and a real graphics card.

## DLSS / performance
DLSS, FSR 2 and other temporal upscalers need per-pixel motion vectors and depth from the game's renderer plus jittered projection; not available to a
D3D11 wrapper for this engine. No change was made to how the game draws. Speed levers: Resolution and the FPS limit.

## Tests
test_ratecap_stress (12 million simulated pairs: 7 headset rates x every limit x light-to-heavy work with hitches: never faster than the limit, steady
when the work fits, never sleeps without a limit), test_eyeaa, test_capture updated. Not run in the game.
