# 1.7.154 (V1.3.9) the 1.7.151-153 features on every headset rate

"stress test all new features, make sure it works on all devices, a mod for everyone on any Hz level".
Checked each new feature for anything tied to one frame rate or headset:
1. FPS limit: the numbers assumed 72/80/90/120 Hz. New choices kHalf (2) / kThird (3) = every 2nd / 3rd headset frame on any rate. Numbers: divisor n is
   the largest whole n with headsetHz / n <= 1.10 x the number (75 Hz + 36 -> 37.5; 144 + 45 -> 48; 60 + 45 -> 30; 90 + 60 -> 45).
   Unknown rate (driver reports none / nonsense): numbers use sleep_ticks_free (timer, one interval since the last pair); half / third do nothing; logged.
2. cut_fade: "speed > 80 ft/s" is frame-rate dependent (the detector clamps dt to 0.5 s): at a low frame rate a real jump was missed. Now also any
   step over 15 ft (forced::lastStep).
3. eyeaa shader: two local names (rcp, red) renamed; rcp is an HLSL intrinsic's name. Re-checked with glslang's HLSL front end.
4. cuthold, corner glow: all time-based (seconds), nothing per-frame; stress now 15..240 FPS.
Stress: test_ratecap_stress 16.6 million simulated pairs (13 usual headset rates incl. 59.94 / 71.93 / 89.91 / 119.88 and random 50..240 Hz, every choice,
work from light to 2.75 headset frames, hitches, timer overshoot, start times far into a session) + every rate 50..240 Hz in 0.01 steps x every number
for the fitting rule; test_cuthold_stress 15..240 FPS.
Cannot be tested here: real headsets, SteamVR's reprojection at half rate, Microsoft's shader compiler, real graphics cards.
