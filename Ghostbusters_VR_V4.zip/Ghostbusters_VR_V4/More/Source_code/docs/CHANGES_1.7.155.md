# 1.7.155 (V1.3.10)

Report gbvr_report_20261110-151328 (1.7.154, Quest 3 via the Oculus driver, 96 Hz): "view model is overlapping with another view model, gun floats out of
hand when fired, one hand firing punishment is gone, the gun feels weightless and boring, make sure fps works".

1. Punishment / weight. controllers.cpp, hand_lock branch (hand_lock is forced on since 1.7.58):
   1.7.117: `if (firing && !twoOk && !pkeOut) { heaviness 1, twistLock 1 } else { rigid }` - a one-handed shot kept weight::step's climb / sway / kick.
   1.7.139 (the V1.1 source this tree continues): `wp = {0, 1}; punish = 0; reset()` for everything -> no weight, no punishment at all.
   Now weight::locked_params(): the gun always has its rotational weight (gun_heft_pct) and the one-handed punishment (gun_punish_pct); the PKE stays rigid;
   the position lag stays off (step_pos heaviness 0) so the grip is on the controller; the fatigue sag only counts while firing (nothing builds up while carrying).
   The arm solve and the gun placement both read the weighted wand pose, so hand and gun turn together.
   tests/test_weightlock.cpp: at rest <= 0.65 deg for 10 minutes with no build-up; one-handed 4 s burst up to 15 deg, two hands 0.4 deg; back on the hand
   after the shot; 2 h random play 20..240 FPS: 0 broken results.
2. FPS limit. The log proves the limiter: at "half rate" 36 sleeps of 4.3 ms, at "a third" 13.8 ms each (= (N-1+0.15) x 10.4 ms minus ~8 ms of work).
   The tester clicked through eleven values in the frozen menu and ended on 120 (= no limit at 96 Hz), so play ran unlimited (71 of 96, 50 % late frames).
   Menu value now shows the effect on the connected headset; FPSCAP status line every report window (target vs delivered).
3. eyeaa_apply ran before handmodel_vignette -> the vignette was missing from the filtered picture. Moved after it.
4. Not found: the overlap and the float when firing. GUNHAND (147 samples): drawn hand to controller 0.0 cm, gun placed by the locked hold every time
   (placed = exact), hose bent 10588 of 10590 calls. New FIREGUN line: gun-to-hand, hand-to-controller and the game's own hold against the locked one,
   trigger up vs down. WEIGHT / WEIGHT2 lines are now in the public log.
Not run in the game.
