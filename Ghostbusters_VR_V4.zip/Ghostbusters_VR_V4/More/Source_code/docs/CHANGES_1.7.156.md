# 1.7.156 (V1.3.11) gun / PKE float audit

Request: "triple check anything that could cause weapon float, like firing caused it; weapons and PKE, especially PKE".

## Found in the 1.7.154 report log (gbvr_report_20261110-151328)
t=160.4 s: health 71 -> 34 % while two-handing at a ghost -> FORCEDMOVE (3.6 .. 13.9 ft/s, stick 0) -> after 0.56 s `CINE start ... hands back to the game's
animation for the body, arms and gun (keep_control 1)` -> GUNHAND silent 161.4 .. 163.3 s -> CINE end. For two seconds body_push returned the game's own
placement (cb >= 0.999, before arm_drive: arms on the game's animation) and the wand push returned the game's own spot.
History: 1.7.79 keep_control (default on): `cine_blend()` returned 0 with it, "the game can no longer take the body, arms and gun back". 1.7.124 removed
that (`cine_blend` ignores keep_control) so scripted cutscenes blend; side effect: every hit / knock-down / cut hands everything over.
This is also the likely "player model switches places quickly" in in-game cutscenes (each cut = a jump = 1.5 s of the game's placement, then 0.7 s back).

## Changes
1. cine::Guard: new `jumpEngages`; engine sets engageSec = gungate::kKnockGraceS (6 s) and jumpEngages = 0 while keep_control is on (keep_control = 0: the
   1.7.26 rules, 0.55 s and jumps). 6 s is the gun gate's own "this is not a knock-down any more" time, so the guard and the holster agree.
2. forced::Detector: a jump needs speed > 60 ft/s or more than 15 ft in the frame (was: more than 5 ft in one update, whatever its length; a 0.25 s
   hitch while sprinting was a "jump").
3. GUNOUT (public log): gun_exit(k) on every exit of the wand push that does not place the gun (guard, switched off / no 3D, no aim, PKE out, stale aim,
   holstered, bad matrix, hidden no hand, hidden no hold, game's own spot); when a placement follows more than 0.3 s after the last one, one line with the
   counts - or "the game did not draw your gun at all".

## Audited, no change
- Controller -> aim pose: weight is rotation only (step_pos heaviness 0 returns the input), the PKE is rigid (locked_params), knock sway is rotation.
- Aim pose -> arm solve and -> gun placement read the same published sample (GUNHAND: "same sample" 10429, advanced 0).
- Gun: handprop::step locks the game's hold once (rigid), placed on the arm solve's hand; fallback / hidden / own-spot exits all 0 in the report.
- PKE (119.4 .. 123.2 s): placed 1076 = exact 1076, hand pair ok 1076 / missing 0, PKE to drawn hand 8.8 cm, to the controller grip 8.7 cm on every PKEGRIP
  line while the game's own hold moved 8.7 -> 15.7 cm; pose setter 2152 calls, "pose too old 0", stretched moments 0. One PROPDRIFT (6.6 cm at the draw, eased).
- Hose: bent 10588 of 10590 calls. Holster: no change of state in the log.
## Open
- 98.0 .. 107.5 s: no gun placement and no counted miss (PROPSTATUS placed and pkeNotHeld both pause): the game seems not to have pushed the player's wand /
  PKE at all. Cause unknown; GUNOUT will say.
- GUNHAND 98.01 s: drawn hand 11.0 cm from the aim grip in a two-hand hold (other two-hand samples 0.7 .. 3.7 cm). FIREGUN (1.7.155) measures it up / down.
Tests: test_cinekeep (the report's shove: old rules 115 frames handed over, new 0; knock-down 5.5 s; scripted walk engages after 6 s; cuts; sprint hitches;
3 h stress 20..240 FPS with 563 shoves and 615 cuts: 0 frames handed over). Not run in the game.
