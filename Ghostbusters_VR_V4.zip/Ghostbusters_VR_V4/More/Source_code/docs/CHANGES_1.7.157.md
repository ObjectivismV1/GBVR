# 1.7.157 (V1.3.12) the gun's life bar as a tube of liquid with a heart

Request: "make the health bar and heart on the gun (look for the existing one) with an effect like green liquid, it changes colour and goes down; make
sure it looks good; stress test, re-test".
The existing bar (1.7.37, handmodel.cpp, gunbarmath.h): two boxes on top of the gun at gun_hp_fwd/up/side_cm. Kept: the place, the offsets, when it shows.
New (gunbarmath.h, pure): Liquid state + step() (drain tau 0.16 s, heal 0.45 s, pale "just lost" part held 0.35 s then tau 0.30 s, slosh from a hit,
heart phase at 62..150 beats a minute), liquid_colour() (green / yellow / amber / red, no jumps), heart outline, build(): cradle + heart plate, two metal
collars, faintly tinted empty glass, the liquid (12-sided, darker at the heart's end, brighter on top, moving bulged surface), light streak, four bubbles,
pale lost part, extruded heart with a dome, a shine and the beat. 756..1008 vertices in the existing dynamic buffer (9000).
handmodel.cpp: state stepped once per picture pair (left eye) so both eyes match; reset after 2 s away; depth test and blend state set explicitly before
the draw (the weapon wheel could leave the depth test off); gun_hp_liquid (1; 0 = the old strip, code kept). GUNLIQUID log line every 30 s.
devtools/gunbar_preview.cpp: a software picture with the shader's shading rule (looked at: 100 / 75 / 50 / 30 / 12 / 0 % and a hit).
tests/test_gunliquid.cpp: colours, heart, outline, drain / heal rules, frame-rate independence (30..144 FPS within 2 %), bad input, and a 4 hour stress
(1.1 million frames 20..240 FPS, 4550 hits, 158143 whole meshes: every vertex finite, colours 0..1, inside a 2.2 x 1.6 x 12 cm box). Not run in the game.
