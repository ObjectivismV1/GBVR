# 1.7.159 (V1.3.14) / 1.7.158

Not tested in a headset yet.

- Ghost health is a glowing liquid vial now (same look as the gun's life tube: green, yellow, amber, red, drains, sloshes on a hit). `ghost_hp_liquid=0` brings the old bars back. The game's own ring stays hidden while the vial is on.
- PKE: the log showed the PKE's centre sitting about 8.7 cm below the controller after it was turned. The hand now also moves so the PKE's centre is on the controller (`pke_centre=1`; 0 = old look). The PKEALIGN log line shows the values before the move.
- FPS limit: Off, 45, 50, 60, 72, 80, 90, 100, 120. Each click skips numbers that would give the same result on your headset, so every click changes the real rate. The menu shows what you really get (e.g. "60 -> 45 FPS" on 90 Hz). Older saved values (half, third, 30/36/40) still work.
- Tests: test_ghostvial, FPS stress extended (92 pass), verify_layout ALL PASS.
- 1.7.159: fixed my own 1.7.158 centring (it moved the hand by the wrong amount). New test_pkecentre: 1,000,000 holds over 5 controller tilts, the long side is in the controller plane and the centre ends on the controller.
