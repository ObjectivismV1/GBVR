# 1.7.160 (V1.3.15)

Stay Puft rooftop fight checked against everything new since 1.7.150 (from the code and the 1.7.119 rooftop log; not tested in a headset).

- Fixed: Stay Puft's health vial was a thin line. From the roof he is 60+ m away; the bar size cap (1.30 m) made the new vial 1.7 deg x 0.4 deg (the old ring was 2.1 deg). The vial now keeps a smallest size in degrees of view: 4.3 deg on the ringed ghost / boss, 2.6 deg on the others. Near ghosts are unchanged.
- Checked, no change needed: the cut fade (1.7.151) is off on the rooftop stations (the station's own fade stays); the cutscene guard (1.7.156) never takes the arms there (scene arms skip it); the cord stays hidden; PKE centring, FPS limit, AA, gun tube and weight do not touch the rooftop view.
- Test: test_ghostvial checks vial size at 3 / 12 / 30 / 65 m.
