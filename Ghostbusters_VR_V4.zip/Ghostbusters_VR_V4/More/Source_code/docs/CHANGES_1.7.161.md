# 1.7.161 (V1.3.16)

Not tested in a headset yet.

- Gun health tube looks like part of the gun: it sits in a gun-metal channel (base plate, side rails, machined end blocks, steel straps, screws). The empty glass is dark smoked glass with one long reflection. The liquid glows softer and deeper. The heart is now an indicator lamp: a steel bezel and a red lens that lights up with each beat, with a small heart under the lens (grey when dead). Same health, colours, drain, slosh and heartbeat as before. Preview: devtools/gunbar_preview.cpp.
- 2D ambient light (the four-corner glow):
  - A new flat screen (a menu after a cutscene) used the last screen's colours and then drifted slowly; it now starts from its own picture's first reading.
  - Dark menus and dark scenes glowed blue (the old default colour); they now glow a faint neutral light.
  - Corner colours now come from the bright, vivid parts of each corner (like a TV's ambient light), not a plain average that washed everything to grey. A dark menu with orange writing glows orange.
  - Corners follow the picture faster (0.55 s instead of 1.3 s), so short cutscene shots get their own light.
  - The single glow (glow corners off) is unchanged.
- Note: in-engine cutscenes play in 3D (no screen, so no ambient light); the light is for anything on the 2D screen.
- Logs: GLOWCORNERS frame= line now has "new screens put straight in their own colours" and the follow time.
- Tests: test_glowcorners (orange-on-dark, black, grey), test_gunliquid (new mesh, 4-hour stress).
