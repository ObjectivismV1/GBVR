# 1.7.162 (V1.3.17)

Not tested in a headset yet.

- The liquid in the gun's health tube now has physics. Its surface stays level with the room as you tilt the gun, leans back when you swing or jerk the gun, overshoots and settles like water (about 2 sloshes a second, calm again in 2-3 s), and a hard swing stirs the surface and the bubbles. The health level itself never changes, only the surface.
- The ghosts' health vials have no physics (the test checks they are exactly the same).
- Safe: a recentre or tracking jump (over 0.5 m in a frame), a hitch, or a broken pose never shoves the liquid; it starts calm again.
- Setting: gun_hp_physics=1 (0 = still liquid).
- Log: GUNLIQUIDPHYS every 30 s (tilt now, largest tilt, how stirred, hard swings).
- Test: test_gunliquidphys (level at rest, tilts the right way, overshoot, swing, jumps, NaN, 4 hours of random play at 20..240 FPS, ghost vial unchanged).
