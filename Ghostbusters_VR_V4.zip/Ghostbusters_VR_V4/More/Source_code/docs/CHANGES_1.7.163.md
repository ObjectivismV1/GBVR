# 1.7.163 (V1.3.18)

Not tested in a headset yet.

- Ghost health vial and ring follow better: a new smoother predicts where a moving ghost is going, so the marker stays ON the ghost at any speed (test: a ghost flying 20 ft/s, the marker is 0.01 ft behind instead of 0.6 ft), and small shakes in the game's positions are calmed (to 17 % of the raw shake). Jumps and pauses still snap; the 0.6 ft lag cap stays.
- Fit tight: the ring and the vial lean halfway toward the ghost's own size (never under half / over 1.5 x the old size). A small far ghost no longer wears an oversized ring. The far-boss minimum size (1.7.160) stays.
- Smoother shapes: ring edges every 5 degrees (was 9), vial ends 12 slices (was 8), the vial's liquid surface is one gentle curve (was a zig-zag), the gun tube has 20 sides (was 12).
- Gun liquid physics calmer and smoother: 2.0 sloshes a second (was 2.2), more damping (0.15, was 0.11), 60 ms smoothing of the controller's motion (was 40 ms).
- Buffers: ghost bars 12000 vertices (was 9000), gun tube 4200.
- Tests: new test_healthfollow (speeds at 30/45/90/144 FPS, shaky hover, jumps, NaN, 2,000,000 frames of random flight); ghost vial, gun tube and gun physics tests rerun.
