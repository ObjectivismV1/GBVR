# 1.7.164 (V1.3.19)

"Check this (1.7.163 follow / fit) for all bosses". Not tested in a headset yet.

Found two problems with 1.7.163 on bosses, both fixed:
- Fit to size made boss health 16-50 % bigger. A boss's "radius" in the mod is not its body; it is a size chosen for the view (bossring::ring_radius = 7.5 % of the distance), so fitting to it was wrong. Boss bars are now marked (kFlagBoss) and keep their fixed boss size, with the far minimum from 1.7.160.
- The predicting follow does not suit bosses: a boss's marker point slides over its huge body as you look around (bossring::ring_point), so prediction would overshoot after each head turn. Bosses keep the calm 70 ms follow they had; normal ghosts keep the new predicting one.

Checked for every boss the mod knows: Stay Puft, the Orrery boss, Golem (and its base), Azetlor, the Librarian, the Spider Witch, the Architect, the Nightmare, and big-health bodies (CBipedLarge in the logs). Distances 4 to 449 m, ring style and bars, vial and old look: all finite, the vial readable (4.3 deg with the ring style, 2.6 deg without) and never filling the view. Normal ghosts are still fitted.

Only Stay Puft and CBipedLarge appear in the report logs so far; the other bosses are checked by the maths only.

Test: test_bosshealth.
