# 1.7.165 (V1.3.20)

"Stress test both (gun tube, ghost health) and make sure they work in all environments". Not tested in a headset yet.

Found and fixed:
- Crowded fights: with many ghosts at a big health size, the health buffer could overflow, and then EVERY ghost's health vanished for that frame (the build gave up). Now the farthest ones are left out until the rest fit; the nearest always keep their health.
- Left-handed play: the gun tube's sideways offset is now mirrored, so it stays on the side of the gun toward you.

New test test_healthenv (all pass):
- Gun tube: every place setting (forward 0-40 cm, up -10..15 cm, side -20..20 cm) x every health x random physics, slosh, heartbeat and time: 7020 meshes, all finite, inside their place on the gun, inside the draw buffer. Liquid always glows bright enough to read in dark levels; green when full, red when low. 6 hours at 20-240 FPS with hitches.
- Ghost health: 60,000 random scenes: 1-24 ghosts and bosses, health size 30-300 %, ring or bars, vial or old look, either eye with IPD up to 80 mm, 0.36-500 m, NaN positions, ghosts behind you. No overflow, nothing broken. Readable over a black sky and a white wall (black glass body + glowing rim) at every health.
- Follow: 200 runs at 20-240 FPS with 0-5 skipped scans: never more than the 0.6 ft cap away.
