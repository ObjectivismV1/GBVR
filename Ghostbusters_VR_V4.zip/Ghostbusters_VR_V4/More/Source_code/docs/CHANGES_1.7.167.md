# 1.7.167 (V1.3.22)

Not tested in a headset yet.

- "The health bar does not sit on the gun": the tube was placed from the bare controller (13 cm forward, 4 cm below, 5 cm left), but the game draws the gun where its own hand holds it (HANDGRIP). The tube now follows the drawn gun: each frame it measures how far the drawn gun's muzzle is from the controller's idea of the muzzle and moves the tube by that (smoothed, last value kept between measurements). New place: 25 cm forward / 6 cm up / centred, i.e. on top of the gun about 24 cm behind the muzzle (an old saved 13/-4/-5 is moved once). Settings gun_hp_on_gun=1 (0 = the controller only), gun_hp_fwd_cm / up / side to fine-tune. Log: GUNTUBE (the gap and how often it was measured).
- "I can see it through my hand": the game's hands are not in the mod's depth, so the tube was always drawn on top. Now a ball round each tracked hand (7 cm left, 6 cm right) cuts the tube wherever the hand is between your eye and it. Setting gun_hp_hand_cut=1. Log: GUNTUBE (how often a hand covered it). If the new shader fails to build, the tube is drawn as before (logged).
- "Improve the rig to follow the body": the chest now turns toward your hands too, not only toward where you look: up to 45 % of the way to the direction of your hands' midpoint, when both hands are in front of you and away from your chest. Setting body_hands_yaw=1. Log: BODYFOLLOW.
- Tests: test_bodyhands (every head direction, hands ahead / to the side / behind / at the chest, looking straight down, NaN; the hand-ball maths of the shader).
