# 1.7.168 (V1.3.23)

From the 1.7.165 video (5:02, looking down in the ballroom). Not tested in a headset yet.

- "Looking down, an overlapping viewmodel / body": the video shows the top of your own shoulders, the shirt collar and the neck seen from above, with the pack hose under them. The cause: body_out (10 cm) puts the whole avatar 10 cm in FRONT of your eye, so the neck sat ahead of the eye and looking down you looked onto it from behind. Real eyes sit in front of the neck. Now, from 20 deg down to 60 deg down, body_out fades out and the body slides 12 cm back instead: looking down you see your chest and legs from in front of the collar. Looking ahead (where body_out helps the arms reach) is unchanged.
- Setting body_down_back_cm (default 12, 0 = off). BODYDOWN log now shows it.
- Test: test_fullbody 14b checks the slide at 70 deg down (full) and 40 deg (half).
- Stress test (test_fullbody LOOKDOWN STRESS): 5760 poses, every pitch 0-89 deg, 8 headings, bend on/off, 2 eye heights. Looking 45+ deg down, the old settings put the neck / shoulder tops in view 580 times and the neck ahead of the eye 68 times; the new ones 0 and 0 (neck always at least 0.11 ft behind the eye). The body moves smoothly with the head (at most 1.5 cm per degree). A later or slower slide (15-70 deg was tried) left the neck in view at 45-55 deg, so 20-60 deg stays.
