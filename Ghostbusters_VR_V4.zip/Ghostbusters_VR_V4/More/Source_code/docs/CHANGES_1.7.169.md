# 1.7.169 (V1.3.24)

From the 1.7.165 Stay Puft rooftop video (5:06) and that session's log. Not tested in a headset yet.

- "Gun does not shoot straight": in the video the stream leaves the muzzle sideways (a straight white piece pointing off the building), then kinks toward Stay Puft. On the rooftop the mod forced the stream's start along its aim direction while the game sends the stream at Stay Puft. Now, on the rooftop station only, the stream is left to leave toward where the game sends it (no forced start, no kink). Setting station_beam_free=1 (0 = the old forcing). Everywhere else the stream still leaves along the barrel.
- New log STATIONAIM (every 5 s on the rooftop): how often the muzzle came from the drawn gun, the angle between the drawn barrel and the mod's aim, between the game's stream and the mod's aim, and how much the stream bends. This shows where the old kink came from.
- "Stay Puft fight looks bad": the rooftop view looks 86 deg down, and your own shoulders filled the bottom of the picture (two big dark shapes either side of the gun). On the rooftop the body now slides back a further 18 cm (on top of the 1.7.168 look-down slide). Setting station_back_cm (0-40).
- "Can't grab it": the log shows the left hand taking hold of the gun 10 times on the rooftop (held up to 10 s), so the cause is not in the data yet.
