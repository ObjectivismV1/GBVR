# 1.7.170 (V1.3.25)

From the 1.7.169 video + report (Stay Puft rooftop, left-handed test, FPS menu).

1. Circle health: with health_style = ring the ring is drawn again (the 1.7.158 vial was drawn first and hid it). Bars style still gets the vial.
2. Gun health tube: the gap to the drawn gun (~27 cm) is now kept in the controller's own frame and smoothed over 0.35 s (gunshift.h). Before, it was kept in eye space with 50 ms smoothing, so turning the hand made it bounce (simulated: 17-23 cm off, now 0.1-4 cm), and gaps just over the old 30 cm check were dropped (the tube floated off). Check is now 45 cm; a one-frame spike is held back, a real hold change is followed in ~1.4 s. GUNTUBE log has held-back / hold-change counts.
3. Floating: the last good controller aim is now kept up to 1 s (was 0.15 s), moved with the player, for the gun, PKE and arms (AIMHOLD log). When the game's hand pair is not ready (goggles, a fresh draw) the PKE is kept in the hand with its last hold on the controller instead of the game's own spot up to 1.7 m away (PKEREL log).
4. Left-handed: the arms hang from swapped shoulders (the game only has a right-hand gun hold, so it is the game's right arm and hand on your left side) - the gun arm no longer reaches across the body. ARMSWAP log. Unit test in test_armcore.
5. FPS limit: numbers that are not a whole share of the headset rate are paced (60 on 90 Hz = 1,2,1,2 frames); the menu offers every number below the headset rate (90 Hz: Off, 45, 50, 60, 72, 80). Whole shares (45 on 90) remain the smoothest. FPSCAP paced log.

Not tested in a headset.
