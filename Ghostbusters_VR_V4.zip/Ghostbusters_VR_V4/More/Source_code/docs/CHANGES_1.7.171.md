# 1.7.171 (V1.3.26)
- Ghost health ring / vial / bar: see-through (hbar_alpha_pct 100 -> 55, once for saved settings and as the new default) and the ring band is thinner (0.26 -> 0.16 of the radius, thinner rim and glow), so the ghost shows through it.
- Log read (1.7.170 report): gun to controller 0.0-0.5 cm in play; PKE to controller 6.4 cm (drawn hand 9.0 cm); PKEREL kept the PKE in the hand 4 times; no new floating cause found in the log (the roof float needs a video).
Not tested in a headset.
