# 1.7.172 (V1.3.27) - recheck, logic check and stress test of 1.7.170 / 1.7.171

Found by re-reading the code and by new stress tests (nothing here comes from a new video):

1. Left-handed arms (BUG, fixed): the swap measured the shoulders from matrices the mod itself had already moved. Whenever an arm was solved again on
   the same skeleton (the second eye of a pair, a moved target) that arm went BACK to its own shoulder - arms crossing again, possibly in one eye only.
   Shoulders are now worked out from the animation's local poses (fresh_shoulder) and the clavicle is rebuilt before the swap, so the swap happens
   exactly once however often the arms are solved. test_armcore: 6 repeated passes without the game rebuilding the pose.
2. FPS limit, paced numbers (BUG, fixed): with 50/60/72/80 on a 90 Hz headset the performance watchdog still compared the delivered rate with the full
   headset rate. 60 of 90 looked like "under 85 %" and, on a PC whose work is near one frame, could have lowered the picture size for the next start
   (SAFETY PERF) and written wrong RATE ADVICE. The watchdog and the advice now compare with the limit (g_capShare).
3. FPS limit, pacing (improved): a schedule instead of a fixed 1,2,1,2 pattern (ratecap::Pacer / frames_for). The pattern never made up a late pair, so
   a PC that sometimes needs two headset frames got clearly less than the number asked for. Stress test: 7 million pairs, 60-165 Hz and random rates,
   light / borderline / heavy work, hitches: never above the limit; within 0.75 % of it whenever the PC can make it; a slower PC is never slowed further.
4. FPS limit: a number within 10 % of the headset's rate (72 on a 75 Hz headset) is "no limit" again instead of a paced stutter three times a second.
5. Gun health tube (weakness, fixed): the 1.7.170 filter dropped every sample more than 6 cm off and waited for 0.6 s of agreeing samples. The 1.7.170
   report shows 37 % of samples dropped (noisy). With that noise a wrong first sample could stay for good (stress test: tube up to 42 cm off).
   Now every sample pulls a smoothed mean by a limited amount and the kept gap follows it: a wrong start heals in about a second, noise of 2-4.4 cm per
   axis leaves under 2 cm, one frame never moves the tube more than 4 mm.
6. PKE hold on the controller (weakness, fixed): a bad pose (far from the hand, squashed, not a number) could wipe the last good hold. The math is now
   in pkerelmath.h with its own test (200 000 random holds, exact round trip, rigid with the controller, bad input changes nothing). The "is this pose
   ours" check after the fallback now reads the fields back as the main path does.
7. Gun / PKE kept through a gap (logic, fixed): the player's position was re-read on every call, so an aim that was still there but no longer refreshed
   (0.15-1 s old) was not moved with the player and was dropped after 250 ms. Now remembered once per new sample; stale-but-present aims use the same hold.
8. Logging: AIMHOLD / PKEREL / ARMSWAP numbers are now in the always-on player log (they were only in the full-diagnostics log, so the 1.7.170 report
   could not show whether the fixes ran). FPSCAP says PACED plainly.

Host tests: 100 passed. Layout check: ALL PASS. Not tested in a headset.
