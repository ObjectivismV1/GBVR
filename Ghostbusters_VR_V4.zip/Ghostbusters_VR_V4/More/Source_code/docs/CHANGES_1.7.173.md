# 1.7.173 (V1.3.28) - from the 1.7.172 report (no video)
- Firing: gun_fire_fx=0 (new default): the trigger no longer adds recoil, climb, shake, kick or a slower follow to the gun in the hand. Resting weight stays. gun_fire_fx=1 = as before.
- Trap (the game's own trap button): trap_no_anim=1 (new default): the trap leaves from the off hand (the same path as a hand throw) instead of showing in the gun hand, and the game's throw animation is kept off the upper body for 1.5 s (the reload hold). TRAP log line.
- Left-handed: the swapped arms' elbows bend outward on their new side (the animation's elbow direction is mirrored; they bent toward the chest). Switching left-handed on / off resets the stored gun / PKE holds, hand follow and gun weight state (MODELCHANGE holds reset line).
  NOT fixed: the hands are still the game's right hand on the left and left hand on the right. A true left-handed look needs the whole body drawn mirrored.
- Ghost health: hbar_alpha_pct 55 -> 45.
Host tests 100 passed, layout ALL PASS. Not tested in a headset.
