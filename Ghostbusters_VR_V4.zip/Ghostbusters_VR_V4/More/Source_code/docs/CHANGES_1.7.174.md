# 1.7.174 (V1.3.29)
- LEFT-HANDED drawn properly (left_hand_draw=1, default). The game only has a right-hand gun hold and the gun / hose / PKE are placed through the right
  hand, so that solve is kept untouched (it is the hold the gun is drawn from). After it, each arm is solved once more for DRAWING at the other arm's
  target (armcore display_arm): the body's left arm + left hand at your left (gun) controller, turned by that controller like the left hand always is,
  fingers closed on the handle and the index finger on the trigger; the right arm + hand at your right controller with its finger tracking.
  Shoulders stay in place (the 1.7.170-173 shoulder swap is gone). If the free controller is not tracked the right arm goes back to the animation.
  test_armcore: 7 repeated passes (second eye, moved targets, native support), free controller lost, hand pair unchanged.
  Not known without a headset: how well the handle sits in the left fist, and the right hand's turn when it grabs the barrel.
- Double check of 1.7.173: the trap button also acts on a trap that is already out. Starting THAT trap from the hand would have carried a deployed trap
  away (up to ~10 ft). The button now only starts the trap from the hand when the trap state is idle (TRAP log lines say which).
Host tests 100 passed, layout ALL PASS. Not tested in a headset.
