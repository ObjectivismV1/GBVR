# 1.7.175 (V1.3.30)
- Trap: the game's own no-animation throw (deployTrap RVA 0xE3A40) is called on the game thread with the trap put at the off hand. No windup, no soft lock; 0.12 s wait, 0.3 s X hold and 1.1 s aim lock removed on this path (fallback keeps the old path). Hand closes round the trap.
- GripLock (gun) and PKE hold lock: stability measured from an anchor (1.5 mm / 1 deg for 20 samples), length gate 0.5 / 0.6 ft.
- Model change / handed toggle now also clears hand-move base, exact-wand sample, live holds, drift trackers, g_pkRel, PKE hand turn.
- armcore: left-handed no-target arm no longer cached as solved; shoulder slide clavicle rebuilt.
- Not done (from audits): wand_aim_read long-hold yaw, holstered-gun fallback, left-handed gun on controller, PKE left display mirror, trap handle tag.
