# 1.7.176 (V1.3.31)
- PKE tangled first draw: hand turn K was captured the instant the grip locked (log: turned 76.6 deg, centre 13 cm sideways); now 0.5 s after the lock.
- Gun health tube: lower (gun_hp_up_cm 6 -> 2, one-time migration), darker palette, dimmer glow/streak, follows the drawn gun faster (tau 0.25/0.10 s, was 0.45/0.20). Not a rigid anchor to the drawn gun's matrix yet.
- Left-handed: menu ear zone mirrored (right ear), trap hip zone and hip trap model on the right hip.
- Trap hold: trap centre 0.18 x radius from the controller point (was 0.55).
- Not done: free-hand pose/orientation in left-handed mode (not found from the video alone), rigid tube anchor, PKE left-hand display mirror.
