# 1.7.177 (V1.3.32)
- Trap throw check against the 1.7.175 log: plain X press threw at once from the hand (trap flew 4.4 m, no animation); the hip-grab throw fell back to the old delayed path (old animation hold stamp in the log) - most likely because the hand aim was stale (Stay Puft fight, forced move). Now the instant throw is used with a 1 s hand freshness, and with no hand position at all it still throws instantly from the game's own spot.
- TRAPDEPLOY log lines were dropped by the public log filter; whitelisted, plus a reason line whenever the instant throw is not used.
