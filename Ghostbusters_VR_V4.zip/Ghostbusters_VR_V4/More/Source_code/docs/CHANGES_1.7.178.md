# 1.7.178 (V1.3.33)
- Trap: a hip grab is no longer started while the trap is already out (state 3). The 19:15 log showed the carry fighting the game 503 times over a trap lying ~75 ft away (left-handed session).
- Health tube: the drawn-gun/controller offset is only learned while the controller is nearly still (< 0.25 m/s), held otherwise -> rigid with the gun; steel darker (0.07-0.17).
- Weight/punishment: gun_heft_pct default 150 (one-time from 100); new weight::Params.looseOne: one-handed the gun is looser (slower, more sway, bigger lag cap) without the trigger; no kick/climb. Fatigue sag one-handed. test_looseone.cpp.
- Firing: with gun_fire_fx=0 the upper body is held at its pre-fire pose (reloadHold path) while the trigger is down + 0.25 s, so the game's firing animation does not reach the view.
- Log seen: delivering 71 of 90 Hz, 43 % late (picture level 3) - PC load, not changed.
