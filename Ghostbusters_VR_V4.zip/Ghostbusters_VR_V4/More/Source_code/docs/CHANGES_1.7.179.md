# 1.7.179
Report 194301 (1.7.178): BODYSCALE showed the body size drifting 1.00 -> 0.93 within 6 s (the model's measured eye height went 5.65 -> 5.92 ft). The gun was drawn at 0.94x and the hands moved away from the controllers by 5-10 cm: that is the "float".
Fix: scale_hold band 1.5 % -> 5 %, follow rate 1 %/s -> 0.2 %/s. Test updated. Not tested in headset.
