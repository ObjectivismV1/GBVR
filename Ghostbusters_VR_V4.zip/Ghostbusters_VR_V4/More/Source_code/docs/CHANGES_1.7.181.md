# 1.7.181 - float hunt (7 read-only investigations)
PKE grip lock: a sample counts only when the game sent a new R_PKE (was per call, 4-6 per frame), 12 samples, draw window closed, 0.2-0.6 ft; a pause under 2 s (was 0.5 s) keeps the lock.
Body size: the model-eye histogram learns only in plain standing (not forced, cutscene, firing, walking). A left/right switch keeps the held body size.
Switch: applied-handedness value for the game/render threads (mirror arms, hip trap model, tube side); gun easing, tube gap filter and PKE drift tracker reset; hip trap model height = trap_hip_drop_cm.
Not done (reports exist): rigid tube on the drawn gun matrix, late-latched controller poses, left-hand roll / support-hand mirror, extra HANDLAG/SPIKE logs, FPS cap 80 on 90 Hz is uneven (try 45 or off). Not tested in headset.
Left-handed (display only, mirrorArms==1): left gun hand = mirror of the right hand's gun hold (knuckle frame), support hand solved as a mirrored left hand and wrapped, finger bends copied, PKE bone glue through the gun-hold hand. New log MIRRORHAND (how far the old look was off). tests/test_mirror.cpp. Only tested on a fake rig, not in headset.
