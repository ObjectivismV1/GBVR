# 1.7.183 - Stay Puft roof fight start
The log (1.7.178): the fight began at 35.29 s and the roof spot was placed at 36.7 s; for those 1.4 s the game's own camera showed a wall. The picture now goes black when the fight starts and stays black until the roof spot is placed (2 s at most), then fades up like any other jump (fade_in_ms). Needs cut_fade on (default). Log: FADEIN lines.
Not changed: arms / gun grips (the numbers in the 1.7.181 log are exact: gun 10.1 cm from the hand all session, hand 0.0 cm from the controller; a video of the current version is needed to see what looks wrong).
