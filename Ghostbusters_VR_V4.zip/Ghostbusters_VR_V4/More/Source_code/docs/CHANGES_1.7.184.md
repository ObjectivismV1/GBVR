# 1.7.184 - only the arms
Request: "gun fully visible, with the hose, and just arms, no flashlight or anything else on" the chest. The video of 1.7.177 shows a grey box with a yellow light on the chest (where the hose ends) from the upper-chest part of the body, which was kept (arms_shoulders 1, body_whole 1). Now arms_shoulders 0, arms_straps 0, body_whole 0 (settings migration rev 169): collapse_body keeps only the arms and clavicles; the same squash is already used in the Stay Puft floating-arms scene. The gun and its bent hose are separate models and are drawn as before.
To bring the chest back: arms_shoulders=1 and body_whole=1 in the settings file.
Logs: SKELETON / SKELBONE (the whole skeleton once: bone index, parent, name) are now in the player report, so any other bone of the body can be hidden by name next time.
Untested in a headset: the shoulder caps may show stretched triangles toward the hidden chest (the reason arms_shoulders was introduced in 0.73).
