# 1.7.185 (V1.3.40)

From the 1.7.184 report and the two Stay Puft videos.

- **Typo of 1.7.184 fixed**: a comment I added in proxy.cpp swallowed the rest of one line of default settings (fingers, real anchor, PKE attach, health bar, beam damage 100 % ...). A saved settings file hid it, a clean install would have lost them. New check `tests/lint_defaults.py` (part of run_all.sh) fails when a `g_ctl` assignment sits inside a `//` comment.
- **Roof fight black**: the held black ended after 2 s, about when the roof spot was found, so the wall could show again. It is now held up to 5 s (until the spot is placed). New log SCENEWAIT says why the spot takes about 2 s.
- **Health tube locked to the gun** (gun_hp_rigid=1): the tube takes the drawn gun's muzzle on every new game sample. The old filter learned the gap slowly and only while the hand was still, so each grab with the other hand (the game's hold moves the gun 5-7 cm) left the tube trailing. GUNRIGID log.
- **Logs now in the public report**: ARMSONLY, SHOULDERS, FADEIN, SCENEWAIT, GUNRIGID, BODYHIDE (30 s summary of the arms-only squash).
- Not changed: the legs, belt radio and trap still show when looking down in both videos. BODYHIDE will show whether the squash runs.
