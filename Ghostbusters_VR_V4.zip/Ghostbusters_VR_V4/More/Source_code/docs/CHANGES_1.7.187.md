# 1.7.187 - Epic Games Store support

Request: "add epic games support".

Not testable here: no Epic copy of ghost.exe was available. What is done, and what is not:
- Installer (INSTALL_PROBE.cmd): after the Steam libraries it looks for the Epic copy: the Epic Games Launcher's install records (ProgramData\Epic\EpicGamesLauncher\Data\Manifests\*.item and LauncherInstalled.dat) and the usual folders on every drive; ghost.exe is searched in the folder and up to 3 levels below it. Not found: the message now tells how to copy the folder from Steam or Epic. A ghost.exe that is not the Steam file is no longer called "the wrong version": the mod checks itself at start.
- Mod (proxy.cpp, sigcheck.h, sigtable.h): the game build was recognised by PE timestamp + image size, which an Epic copy would never match even with the same code. Now, when the header differs, ~515 code samples of 16 bytes (spread evenly over the code + every code RVA of layout.h, none under a relocation) of the analysed Steam exe must ALL be identical in memory: then the build is accepted (log GAMEBUILD ... running as the verified build). One difference keeps the mod off (as before) and the report gets GAMEBUILD lines: how many samples differ, the sections, and where each main hook site's bytes were found (moved by N bytes / not found), so a port can be made from the report. A Steam copy is unaffected: the header check passes first and the samples are not even read.
- COLLECT_LOGS: epic_install_record.txt (name, version, folder from the launcher's record).
- tests: test_sigcheck.cpp (accept / one changed byte / unreadable / wrong image), verify_layout.py checks the samples against the exe, tests/gen_sigtable.py makes sigtable.h.
- Still needed for Epic: SteamVR (the VR runtime) - Steam and SteamVR are free to install only for that. Launch the game from the Epic Launcher as usual. The Linux scripts still look for a Steam copy only.
- If the Epic code differs from the Steam code, the mod stays off until a port exists: send COLLECT_LOGS from one start (or ghost.exe from the Epic folder).
