# 1.7.188 (V1.3.43)
- Crash: the trap throw (the game's own deployTrap) ran inside the drawing; it now runs at the start of the simulation after the render queue is drained.
- Trap: turned half a turn about its flat face so the handle end is at the fist; hangs 0.82 x radius below the hand; the hold is re-applied right after every game simulation (the game put it back 2780 of 5566 frames).
- Health tube: pinned to the drawn gun muzzle's world point (converted to the current head space).
- Data: ACTORKINDS (enemy classes outside the known table that hold health) for the roof construction ghosts' missing bars.
- Not fixed: PKE dragged at start (no cause found in the report), roof construction ghost bars (needs ACTORKINDS data).
