# 1.7.189 (V1.3.44)
- Weapon wheel redrawn (gearmath.h build_wheel): smooth stroke font instead of 3x5 blocks, steel bezels, smoked glass, neon rims (cyan ready, green in hand, amber off, red locked), glowing liquid fill on the lit disc, centre ring in the lit disc's colour. Vertex buffer 9000 -> 20000.
