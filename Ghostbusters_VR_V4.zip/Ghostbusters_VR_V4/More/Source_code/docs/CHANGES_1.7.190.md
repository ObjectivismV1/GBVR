# 1.7.190 (V1.3.45)
- Roof fight knock-down: knock_comfort_on() now allows the soft knock-down when the roof view (floating arms) is active (the Times Square escort keeps the game's fall).
- Soft knock-down gains a light rumble (hap::kSrcKnock) and slower gun turn (low-pass on its rotation, tau 0.22 s x strength).
- armcore.h: with floating arms the squashed body's point is 0.35 ft back / 0.20 ft down (was 1.40 / 0.85): the stretched coat "wings".
- KNOCK log line now shows the roof view flag.
- Not done: damage hit reaction on the model, health tube (nothing visible in the video), off hand.
