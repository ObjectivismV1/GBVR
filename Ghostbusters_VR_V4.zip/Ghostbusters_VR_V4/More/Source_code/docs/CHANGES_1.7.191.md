# 1.7.191
- Health tube: no longer pinned to the game's (a tick old) muzzle sample; kept in the controller frame (no trailing while walking).
- Trap hold: hangs 0.45x radius (cap 0.45 ft) below the hand instead of 0.82x (cap 0.8).
- Soft knock-down (no game fall, slow walk, black edges, rumble) in the whole game, incl. Times Square; stuck rescue kept.
- Not done: the game's small hit-reaction animation (function not found).
- Review fixes: the stuck rescue also works in the Stay Puft level; the tube learns its gap only while the muzzle is still in the world (no swimming while walking).
