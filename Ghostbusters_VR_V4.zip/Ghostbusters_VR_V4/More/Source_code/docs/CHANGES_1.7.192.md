# 1.7.192
- Crosshair: the game's three reticle sprites are set to alpha 0 right before the HUD draw (hud.cpp hide_reticle).
- Stay Puft roof fight: the extra body pass (flashlight, walkie-talkie) is hidden too (mirror-only sites Body2/Body2b); the off hand does not take the barrel there (near-grab and grip-grab off in the scene).
- Hits: the 00:01 report shows 0 knock-backs / 0 big-hurt; a hit is a health drop plus a 0.6 s game move. The soft knock-down now also starts when the player's health drops (KNOCK hit #n).
- Stuck rescue works in the Stay Puft level; tube learns its gap only while the muzzle is still in the world.
- New log EYEPAIR (per-eye picture ages, roof fight vs elsewhere) for the blank right eye report. Not fixed yet.
