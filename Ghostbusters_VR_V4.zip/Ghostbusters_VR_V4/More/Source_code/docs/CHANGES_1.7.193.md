# 1.7.193
- Trap: carried rigid with the controller in all three turns (trapholdmath.h): handle end at the fist, body along minus the controller's up, flat face follows the controller's pointing; hangs 0.30 x radius (cap 0.30 ft) from the hand. Held by X or the grip as before.
- Stairs/eye follower: the fitted line overshot after a single floor step (about 20 % of the step); the target is now clamped to the window's feet heights (no bob after a curb).
- Tube: the world-motion gate is gunshift::StillGate (unit-tested: 0 mm error walking at up to 8 ft/s, 80 mm without it).
- tests/test_locomotion.cpp: smooth floor, thresholds, ramp, stairs up/down (45/90 Hz, uneven timing), walking into objects, tube while walking, trap hold over every orientation.
- Right eye blank in the roof fight: still no cause; EYEPAIR log from 1.7.192 is the data to wait for.
