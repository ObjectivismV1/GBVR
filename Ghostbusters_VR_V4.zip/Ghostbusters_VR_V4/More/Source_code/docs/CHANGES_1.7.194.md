# 1.7.194
- Hit reaction: RVA 0xCEC80 (the player's hit reaction, called by CGhostbuster::hurt) is skipped for the player when knock_comfort is on. Health is still lost. Log HITREACT.
- Soft knock-down no longer starts on a plain health drop (only on a real knock-back / big-hurt animation).
- Off hand in the Stay Puft roof fight snaps to the gun again (the 1.7.192 "stay free" change is reverted).

# 1.7.195 (audit fixes)
- hk_hit_react: not skipped when the player's health is <= 5 % (death / game over stay the game's).
- Stuck rescue: not during a forced move or cutscene; the stale impact is dropped after a rescue.
- hide_reticle: only with the 3D view on, and only when the three reticle sprites share one class.
- trapholdmath: the kept face direction is made perpendicular to the body direction again near the poles.
- Known, from the audit (not changed): the game's own stagger state (about 0.5 s of blocked movement after a hit, its end animation) and the boss's own hit animations (types 0x6E / 0x6F) are separate from the skipped call and still play.
