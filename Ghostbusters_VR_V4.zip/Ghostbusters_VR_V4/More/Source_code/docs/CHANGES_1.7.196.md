# 1.7.196 (V4)
- Body no longer spins while a ghost is held in the beam or a slam plays: the chest stops following the hands and twists at most 30 deg from the head (ramps in/out over 0.25 s). Setting body_calm_slam (file only, no menu row). Log: BODYCALM.
- Knock-down comfort (slower walk, slower arms, dark edges) lasts 4 s (knock_ms 3000 -> 4000 once).

# 1.7.197 (V4)
- Dying / dead (health about 0): the body is not drawn (the arms stay, like the roof fight) and the screen edges pulse red; a knock-down also pulses red instead of black. Setting down_vignette (file only).
- Health tube: the gap to the gun is learned once while the hand is still and then frozen (relearned only for another gun/hand/holster or a real 3 cm move). Housing darker, goo and heart brighter.
- Carried trap hangs 40 % as far below the fist (trap_hang_pct, file only).
- Roof fight: the free hand snaps to the gun from 32 cm (was 18).
- Log: DOWNED, SCENEGEAR (which draw sites the roof fight asks about: for the flashlight / walkie-talkie), BODYCALM, GUNTUBE lock.

# 1.7.198 (V4)
- Carried trap raised again: trap_hang_pct -30 (the trap's centre sits 2 cm ABOVE the fist, so the handle that is below the trap's top end is in the fist). Lower the number to raise it more, raise it to lower it (gbvr_settings.txt).

## 1.7.200
- Knock-down: edges black (dying stays red), arm lag tau 0.40, knock_ms migrated to 4000 (settings rev 174); logs KNOCKHIT / KNOCKWALK / KNOCKVIG / "comfort ended".
- Roof fight left hand: wrap fist only after a real grab; snap by nearness without grip; grab reach x1.3; SCENELEFT log.
- Roof props: SCENEPROPS hides body sub-meshes named flash/torch/radio/walkie/talk/comm/pda only in the roof fight; SUBMESH / SCENEKIDS logs list every sub-mesh and attached child.
- Hose: per-stage refusal counts and matrix data in HOSERELEARN (the real cause after a level change is still unknown).
- Right eye: ROOFEYE / ROOFVIEW / SAMEMOMENT / PAIRCOUNTS / VIEWDRAW logs (logging only).

## 1.7.201
- Knock-down effect only for the boss hit the game would knock down with: the game's hit reaction rotates a counter (RVA 0xE40CC4, runs while byte 0xE40CC8 is set); counter 3 = plain stagger, other values = knock-down; attacker == player never. Mirrored here (our own copy, since the skipped call froze the game's). KNOCKHIT logs the decision.
- Roof fight: left hand fingers never wrap the barrel (they follow your own grip/trigger), grab/snap unchanged.
- Roof props: wider sub-mesh name list (never arm/hand/glove/sleeve pieces).

## 1.7.202
- Roof fight: arms, the gun and the gun's hose only. The hose is no longer hidden there (still hidden while dying); every body sub-mesh that is not an arm / hand / glove / sleeve / torso-like piece is hidden (only if at least one arm/torso piece exists, so the arms cannot vanish by a wrong guess). SUBMESH lines now say keep_as_arm_or_torso.

## 1.7.203
- PKE drag when pulled out: the hand was tied to the controller 0.5 s after the hold lock (about 0.9 s after the pull-out). Now 0.05 s for a reused hold and 0.25 s for a freshly learned one. PKEDRAG logs the timing of each pull-out.

## 1.7.204 (from the 1.7.202 report)
- HOSE: refused every bone from the first call of the session (stage "a bone", 36 non-finite/huge numbers in the hose cache). blend_bone's NaN check included the padding 4th column of each matrix, which the game leaves with junk. Now only the 12 used numbers are checked.
- Knock-down edge: steady black at full strength (knock_dark_pct 100, migration rev 175); dying stays red and pulsing. KNOCKVIG summary logs the strongest level reached.
- Downed: the eye keeps its standing height while downed and 2 s after (not if the player was moved >3 ft, i.e. a respawn). DOWNEYE logs how far the actor dropped.

## 1.7.205
- Normal ghost knock-downs work like boss ones: the effect follows the game's own decision for EVERY hit type: its first test (RVA 0xCF8C0, bytes checked) says whether the hit gets any reaction, then the rotating counter rule (counter 3 / attacker is you = plain stagger). KNOCKHIT logs each hit as boss/ghost, knocks down or not.

## 1.7.206
- Roof fight: hose hidden again; no automatic snap of the free hand (and no wider reach).
- Boss health bar: wall test skipped for 20 s after you hit/hold a boss; CBipedLarge (kitchen boss) added to the boss list. New counters on the BOSS log line.
- GUNVIEW log (data only): gun position and barrel yaw in the head's frame, every 2 s, to find the "view model too far left" cause.

## 1.7.207
- Body centred under the head: the whole avatar body is moved sideways so the pelvis sits under the eye (smoothed; only as far as the hidden head can slide back, about 6 cm by default, so the avatar eyes stay on the camera). Log: BODYREL centre.
- Arms and legs checked by code reading: no left/right bug found.

## 1.7.208
- Head slide room 0.2 -> 0.45 ft so the 1.7.207 body centring can reach the full 10-14 cm while the avatar eyes stay exactly on the camera (hidden head only).

## 1.7.209
- Trap: the off hand makes a real fist round the trap handle (thumb 1.0, fingers 0.92, game pose never blended in).
- Enemy bars: an enemy hurt in the last 10 s keeps its bar (no wall test, range 90 m, not removed by the "gone" rule); BARMISS log says why a hurt enemy still has none.
- Player life tube on the gun is no longer cut by the hands (gun_hp_hand_cut default 0, one-time migration 176).
- Right eye (Stay Puft roof / walls): the second eye's world-sector query uses the first eye's point; ROOFVIEW now logs both eyes, EYEPAIR every 10 s.

## 1.7.210
- Roof fight: the off hand holding the barrel uses the normal wrap grip (palm on the barrel at the normal distance, fingers round it) instead of the plain hand placement. Free hand (no grip) is unchanged: still no snap, no game curl.

## 1.7.211
- Gun health tube: frame taken from the game's own drawn-gun sample (muzzle, barrel direction, up) instead of controller + frozen learned gap; falls back to the old placement if no fresh sample or if it disagrees (>45 cm / >25 deg). GUNFRAME log.
- Trap: off-hand glove rolled 30 deg to the right while the trap is held (eased); fist loosened to {1.0,.78,.82,.85,.86}. TRAPROLL log. Roll sign unverified.
- Roof fight: second eye gets a normal tick (no same-moment short tick) in the roof fight only; the wrap-pose fist no longer adds extra closing after take-hold.
- Body: while a ghost is held/slam, the chest follows the head when looking down (30 deg cap released 20..60 deg down); signed yaw difference fix.

## 1.7.212
- Trap hand: the glove now turns 30 deg about the handle line (the controller's up, the line the trap hangs along) instead of rolling about its pointing line, so the fist stays on the handle. The trap itself is untouched (it is placed from the raw controller pose).
- New test tests/test_trapchest.cpp (roll/yaw math over 200000 random poses, chest-cap release, signed wrap); all 107 tests also pass under g++ AddressSanitizer + UBSan.

## 1.7.213
- Neck hole: the squashed head bones gather at ONE point at the neck top (the head bone's own origin) instead of 0.1 ft below the upper chest bone, so the neck tube's top ring is no longer pulled down into the chest and the neck skin closes over. No mesh is hidden or folded into the chest. test_fullbody updated to check this.

## 1.7.214
- armcore.h wrap grip: the hand frame (pointing + up) is slerped as one rotation to the wrap pose instead of blending the two vectors separately. New tests/test_wristswing.cpp.

## 1.7.215
- armcore.h: wrap-gripped left wrist limited to 55 deg bend vs the solved forearm (the video showed the glove folded back ~90 deg on top of the barrel); the wrist moves round the palm point so the palm stays on the barrel. WRISTBEND log line. tests/test_wristlimit.cpp.
- 1.7.215 stress: the limit now keeps the best of several passes and falls back to turning only the hand when the forearm will not settle; 30000-frame stress incl. degenerate hands, gun straight up/down, flickering grab, odd world sizes, left-handed on/off: all finite, nothing else moves, 0 grips over the limit.

## 1.7.216
- engine_hooks.cpp: roof fight only: the head movement from the recenter point is pitched by the same aim_down turn as the picture and the hands (it was laid on the level axes), so lean / nod / look about move the eyes the way the view is turned. New tests/test_roofhead.cpp.

## 1.7.217
- Roof view placement uses stereo::robust_heading (the head UP column gives the heading when the head looks steeply up/down; the old yaw fell back to 0 = off-centre). Station keeps the mouth point. New ROOFAIM log (view-to-mouth angle, pitch, horizon roll, heading offset, head offset). tests/test_roofhead.cpp placement test: 40000 random head poses, looks exactly at the mouth, no roll.

## 1.7.218
- Stress / unusual events: robust_heading and Station::place reject NaN / infinite poses (a lost headset pose could be accepted as the roof view direction: found by tests/test_roofunusual.cpp, 200000 garbled cases, now 0). test_armcore: 20000 frames of garbled controller data, no broken bone written. All 111 test programs clean under address + undefined-behaviour checkers.

## 1.7.219
- Report 1.7.218 check: build ran, ROOFAIM present. Wrist-limit numbers were only in the pre-fight window: now in every SCENELEFT line (wrist bend last / passes / limited / hand-only). ROOFAIM also prints how far the pitched roof head movement moved each eye. ROOFAIM label fixed (headset position in the play space).

## 1.7.220
- Left hand (wrap grip): the orbit round the barrel is now chosen forearm-aware. Starting from the orbit you asked for, it tries nearby orbits (-30..135 deg, max 5 deg per frame, smooth) and keeps the one that bends the wrist least, so the glove stops folding back over the barrel. SCENELEFT logs "hand orbit moved X deg to cut the bend A -> B deg (moved of passes)".
- Roof (Stay Puft) view: once per fight, 3 s after the view is placed, if your head rests 12+ deg off the boss direction (turning under 12 deg/s for 0.8 s) the view re-centres itself the way your recenter does (comfort fade). Setting roof_auto_center (default 1, no menu row). Logged as ROOFAUTO. Logic is sceneview::AutoCenter, tested in tests/test_autocenter.cpp.

## 1.7.221
- Boson Dart (the proton gun's left trigger): sometimes the game played the charge sound and effect but did not launch the dart. The log of this session had no dart shots, so the cause is NOT proven. Likely cause: a light, slow or very short pull reached the game as a thin sliver of trigger values. Now (proton gun in hand, in play, not holstered, no menu) the left trigger is handed over as one clean press: full value from past 60 until let go below 30, held at least 110 ms, and a new pull only after 70 ms up (two quick taps stay two shots). Setting dart_clean_press (default 1, no menu row). Logged as DARTLT (pull length, peak, presses, stretched, dart hits the game reported). Logic: bosonmath.h CleanPress, tests/test_boson.cpp.
- Roof view auto-centre: the 1.7.220 re-centre came 29.8 s after placement because the heading of a head looking almost straight down jitters and kept restarting the resting timer. The heading is now smoothed, turning is measured over 0.3 s, waits 2 s after placement and 0.6 s of rest; still once per fight. Tests extended with a jittering head and a swinging head.
- Off-hand grip round the barrel: fingers a little tighter (0.40/0.70/0.74/0.76/0.72, was 0.30/0.62/0.66/0.68/0.64).
- Report analysis (1.7.220 log): the orbit search worked (wrist bend cut from 45-83 deg to 4-21 deg, hand moved 40-70 deg round); the roof view points 2-20 deg from the mouth with the head resting 10-40 deg turned; the auto re-centre ran once and was followed by the 3 s comfort fade.

## 1.7.222
- Boson Dart: 1.7.221 reshaped the left trigger into a clean full press and the dart stopped working. That reshaping is deleted (code, setting dart_clean_press, test). The left trigger goes to the game exactly as the controller gives it, as before 1.7.221. Only the DARTLT log lines stay (each pull: length, peak, what was sent, dart hits the game reported). The original "sometimes sound and effect but no dart" is still unexplained: no log so far contains a dart shot.

## 1.7.223
- Report 013125 (1.7.222): all four left-trigger pulls were with the right trigger held (stream firing), none produced a dart hit the game reported. The user: darts only shoot "after each failed attempt".
- Boson Dart: the game launches it on its "just pressed" answer for Secondary (query 0x1FC620 index 1, then its 0.25 s press timer at player+0x24864). The mod answered "just pressed" for 50 ms only. Now every pull is told "just pressed" at least ONCE (up to 400 ms after the pull); a pull the game already saw in the first 50 ms behaves exactly as before, so a dart that worked cannot be broken by this. Not proven to be the cause.
- New log DARTTRACE (first 14 pulls): every ~15 ms the time since the pull, right trigger, the player's action bits (+0xC7A8), press state (+0x24860), timers (+0x24864 / +0x24834), flag (+0x2485a), and how often the game asked held / released / just-pressed about Secondary and was told yes, plus how many pulls needed the late "just pressed". This will show exactly where a failing dart stops.
- Off-hand grip twisting on the barrel: the 1.7.220 orbit search re-chose the orbit every pass (up to 5 deg a pass), so the glove crept round the barrel whenever the hands moved. Now the orbit is picked once when the hand takes hold (best of the nearby orbits), stays while the wrist bend is under 38 deg (drifting back toward the wanted orbit at 0.1 deg a pass only where it stays under 38), and moves only when uncomfortable (0.3 deg a pass, 1 deg over 50 deg). Test: 3000 passes of 3 cm hand wobble moved the orbit 3.7 deg in all, 0.2 deg a pass at most.

## 1.7.224
- Gun health bar glitching while walking/firing (report 014315): the 1.7.211 "tube follows the drawn gun's frame" override is OFF (the drawn gun sways with the walk and fire: mean 3 cm, up to 27 cm from the controller). The tube is rigid with the controller again. The controller-frame gap is no longer learned or re-learned while the left stick is pushed (plus 0.5 s after): 17 lock releases in the log happened while walking. Before the first learn the nominal 25/2/0 cm place is used. The "gun is at hand" grace for this bar is 0.5 s (was 0.25). Logs: GUNTUBE 1.7.224 walking skips.
- PKE hand bend: the alignment turned the hand up to 57-67 deg to level the meter (the game's own PKE hand is 45-94 deg off the controller). The hand turn is now capped at pke_turn_max_deg (default 25, 90 = old full turn); the meter keeps the rest of its lean. Test added in test_pkealign.
- Boson Dart: while the left trigger is down with the proton gun the stream trigger is let go for the game (setting dart_pause_stream, default 1, no menu row). Data-based guess: every logged pull had RT held and the game only asked "held" for Secondary. Not proven. Log DARTPAUSE.
- Docs (1.7.224): README.txt rewritten as a clean "Version 4" guide (old notes moved to docs/README_HISTORY.txt), PLAYER_GUIDE.pdf rebuilt by tools/make_player_guide.py, installer / remover / Linux script messages say "V4" instead of "probe" (file names INSTALL_PROBE.cmd etc. unchanged so updates keep working). Controller family check re-run for 17 SteamVR controller type names (Touch, Index/Knuckles, Vive, WMR, Cosmos, Focus 3, Pico, Steam Frame, G2, PSVR2): all land on a sensible layout.

## 1.7.225
- Report 020752 (1.7.224 log) double-checked. Health bar: 6 lock releases in the run, all around dart pulls / item and trap changes (the drawn gun kicks 3+ cm on a dart while the controller is still, and the gap was re-learned, which moves the tube). The release now needs 6 cm for 40 still updates in a row (was 3 cm / 10). New walking log every 256 skipped draws.
- PKE pulled around when it first comes out: PKEDRAG showed the hand tied to the controller 7.04 s after the pull-out (the grip needed 12 game updates within 1.5 mm / 1 deg of each other; the game's hold keeps moving while the hand moves, 414 unsteady samples). The limit now loosens with time since the pull-out: 1.5 mm / 1 deg to 0.7 s, 5 mm / 3 deg to 1.5 s, 12 mm / 6 deg to 3 s, 25 mm / 10 deg after. PKEHOLD now logs the tier, the time and how far the hold moved between updates.
- PKE alignment ease-in: the hand turn and the 15 cm centring move used to start at full size on the first tied pass (a visible jump). They now ease in over pke_ease_ms (450) with a smoothstep, counted in game frames. Test in tests/test_fingers.cpp (5f): the old way jumps 47 mm at once, the new way moves at most 2.5 mm per pass.
- Boson Dart: DARTPAUSE worked (3 pauses of 109-172 ms in the run). The dart hit counter stayed 0 all run, so whether the dart now leaves the gun every time is still unproven.

## 1.7.226
- "Remove the hand animation for weapon change and any other hand-on-gun animation": the upper-body hold that the reload already used (the pose from just before is kept, the hand stays on the controller) now also runs for 1.2 s after the weapon changes (the game's draw / switch animation) and while the left trigger (alternate fire: dart, slime tether) is down plus 0.7 s. Setting gun_hand_no_anim (default 1, no menu row). Logged as HANDANIM. The held pose survives the item id change (armcore reload.item check skips the reset when switchHold). Tests: weapon change held vs not held (test_fullbody), 3000-pass random hold stress, all run under address+undefined sanitizers (g++).
- Not changed: the game's own finger pose of the free (support) hand, the PKE hand, the trap, cut-scenes.
- Stress: 111 host tests pass, sanitizers clean on armcore / fingers / pkealign / autocenter / fullbody / arm / body / bodyhands, layout check ALL PASS.


## Package folder layout (1.7.226 package)
The zip now shows only README.txt, PLAYER_GUIDE.pdf, INSTALL.cmd, REMOVE.cmd and COLLECT_LOGS.cmd at the top.
program_files holds the mod (bin, tools, VERSION.txt). More holds CHECK_INSTALL.cmd, Linux_SteamDeck and Source_code.
The installer scripts find the game from the new paths; the old *_PROBE.cmd names are gone. No mod code changed.
