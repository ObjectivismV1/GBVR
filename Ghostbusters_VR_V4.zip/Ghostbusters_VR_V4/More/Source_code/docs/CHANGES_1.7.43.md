# 1.7.43 release cleanup

User requested removal of diagnostic noise/unnecessary checks and a speed increase with no game sprint animation.

- Removed damage.cpp's native sprint tuning, timer observation and run-bit injection functions and calls. Removed controllers.cpp's injected Jump/Evade sprint branch. Removed the native sprint menu toggle. Legacy sprint_game, sprint_force, sprint_via_jump and easy_sprint settings are clamped to zero on normal load and profile load. The general position-based speed boost no longer depends on any native sprint option.
- Changed defaults and settings revision 133 migration to probe_data=0, diag_timing=0, wall_diag=0 and rig_auto_shots=0. Wall probes and automatic rig shots are retired configuration switches (range 0..0).
- Disabled automatic detailed frame samples, initial/repeated full dumps, timing/picture reports, per-call profiling accumulation, weapon shake measurements, grip-placement timelines, automatic float-check screenshots, memory breadcrumb-file creation, body-float dumps, the 320-word slam diagnostic scan and non-enemy RTTI/world-class learning in quiet mode.
- Central logging filters routine output before formatting/I/O. Quiet mode retains brief startup/session/error/crash messages. It does not delete previous reports or screenshots. Manual screenshot requests remain available.
- Runtime hook signature checks, game identity checks, valid-memory/pose checks, crash handling and controller conflict checks remain. Gameplay routines for speed measurement/adaptation, capture/slam, the new ghost lifecycle bar logic, player health, PKE and trap placement are retained.

Verification: all 60 native test executables passed; both DLL variants and the watcher cross-built. Source checks confirmed the native sprint code paths are absent and legacy settings cannot enable them. The user must still verify actual speed gain and appearance in the headset.
