# 1.7.44

- Support a distant active perspective camera only when it follows the previously confirmed player Ghostbuster. Check camera class, projection, finite eye/pivot and maximum distance. Apply the headset eye at the player and force tracked arms-only during that camera state, reverting immediately when it ends. Hide pack straps and the PKE body reveal in this state.
- The inventory-based in-game flag now requires a verified player actor, a fresh inventory publication, and a VR world view rather than a flat screen. This prevents old inventory state from making menu/video frames count as live gameplay.
- Silence mod beeps and diagnostic capture tones; lock menu song off, remove its switches and the MP3 from new installers. Preserve the game's own sound and its existing menu mute/restore.
- Turn the separate debugger watcher off by default. Keep it available for explicit `watch_game=1` diagnostics. Disable the remaining automatic HUD ring probe by default. Retain crash, signature, pointer and headset safety checks.
- Keep short transition logs (`SCENEVIEW`, suspended reason, flat screen, restored 3D) so a user log can identify a remaining scripted camera failure without a large probe.

## Limits

No attached log from the Stay Puft rooftop battle was provided; the most recent report predates this build. A scripted camera that changes to a non-perspective view, switches to a different actor, or does not render a new 3D game frame still uses the game's flat-screen presentation. A headset run is needed to prove the precise rooftop behavior.
