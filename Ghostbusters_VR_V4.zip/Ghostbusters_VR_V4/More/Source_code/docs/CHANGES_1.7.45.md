# 1.7.45

## Menu audio

Restore menu song playback, its toggle and volume controls, default 55%, and the original MP3 in the installer. Remove the 1.7.44 forced music-off assignment. Settings revision 135 enables the user's requested song again and restores the usual full-body IK baseline. Diagnostic beep code remains absent.

## Temporary Stay Puft view

The existing shared enemy scan publishes a nearby living CStayPuftBoss (known vtable RVA 0x7A0678, health/max fields and verified CCharacter death state). No separate actor-list scan is added. A distant verified player perspective camera plus that boss starts the encounter view. The view stays in floating arms for the encounter, including normal camera moments. Confirmed death, disappearance, range exit, world change or player change ends it. Data expires after half a second; a pause waits for fresh data without forgetting an active encounter.

The mode is not written into user settings. Scene changes commit at the first eye of a pair. The existing rig squashes non-arm body bones; pack/hose main-view visibility and generated straps are also suppressed. During the encounter only, the body and gun visual overrides bypass the forced-move cutscene guard, keeping the arms and gun tracked. Game simulation and attack logic remain unchanged.

## Diagnostic cleanup

The previous quiet build still had automatic capture requests for missing gun-hand targets, PKE equip/pings and HUD eye mismatches. These now require probe_data=1. The diagnostic rig samples also return immediately during quiet play. Manual capture and manual markers remain available. The outside watcher stays opt-in.

## Attached report reviewed

Input: gbvr_report_20261023-132154.zip. Probe versions: 1.7.43, two runs. Both exit normally with code 0. Executable SHA-256 matches the supported build. Headset: Quest 3, 90 Hz. Longer compositor session: 156051 presents, 0 dropped, 23869 reprojected (about 15.3%); average reported application CPU 8.811 ms / GPU 6.140 ms. These statistics do not establish a locked native 90 FPS. The quiet probe log lacks per-scene camera and gameplay counters, so it cannot verify the subsequent 1.7.44/45 camera fixes, grab/slam behavior, or individual IK transitions.

## Verification and runtime limits

Test the encounter sequence including start, normal camera within fight, death, absent boss, world/player changes, unrelated camera and pause/resume. Build both DLL variants and the watcher. Verify the supported executable layout. Exact rooftop behavior remains subject to a headset run: non-perspective views and frames without a renderable 3D camera retain the existing flat-screen path.
