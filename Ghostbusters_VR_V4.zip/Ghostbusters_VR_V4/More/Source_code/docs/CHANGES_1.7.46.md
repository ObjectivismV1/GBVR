# 1.7.46

## Eye-level fight station

The 1.7.45 report confirms the Stay Puft encounter override engaged. The prior camera still used the player actor's rooftop eye position, so arms-only alone did not solve looking down at the boss. The new station gets the boss's real `mouth` attachment through the verified original EntityAttachWorld function (the same function used by the boss at RVA 0x16A7BF, 0x16BAD6, 0x16C20C). The existing shared actor scan samples it at most ten times per second. No extra actor-list traversal is added.

On encounter entry, the station is placed at mouth height, on the boss-to-player horizontal ray. It moves closer when the original distance is over 50 ft (75% of the original horizontal distance, capped at 120 ft); original distances below 20 ft, above 1000 ft, invalid coordinates and vertical shifts over 500 ft are rejected. Its yaw faces the boss relative to the user's current tracked yaw. Pitch and roll are not changed. Actual headset translation and stereo eye separation continue normally.

Freeze the station within a boss stage to avoid following animation bob. Re-frame on the verified stage field change (D154, getter RVA 0x16F8E0) or explicit F9 recenter. Transition through the existing compositor fade at entry, exit or re-frame. Disable automatic game-camera following while the station is active; explicit snap and smooth stick turns remain available. Actual player/collision position and boss/game scripts are unchanged.

## Arm and weapon placement

Translate the player's render body matrix by exactly the station offset and account for its level heading. Anchor the floating-arm shoulders 17 cm left/right and 20 cm below the tracked head, 2 cm forward. The shoulder roots start from the native pose on every changed input, and then shift as a rigid subtree before solving elbows and wrists. Length scale is limited to 1.05 during this fight; up to 45 cm of shoulder slide keeps the controllers reachable. Outside the encounter, prior rig tuning and full-body IK resume.

The gun's 12-ft wrong-instance guard now measures distance after subtracting the known station translation, rather than rejecting the intended render offset. It still rejects unexplained distances. This keeps gun-hand alignment valid without relaxing instance identity checks.

## Other report findings

- Holding the last active encounter through unknown/stale boss data avoids the one-frame rooftop/full-body return seen on pause/resume in 1.7.45. A fresh confirmed end still restores the normal view.
- Allow a verified active CGhostbuster camera to establish the first published player, resolving the circular initial requirement for an already published player.
- Latest report: `gbvr_report_20261023-155628.zip`; current run `gbvr_probe_1.7.45_20261023-155427.log`. Clean exit. SteamVR latest session: 5437 presents, 0 dropped, 605 reprojected (~11.1%); reported application CPU 7.256 ms / GPU 5.196 ms. The driver also logs acquisition timeouts. Native 90 FPS and the new camera/aim behavior require a headset run.

## Verification

Extend the fake-model integration test to check head-relative shoulder placement, arm stretch <=105%, and repeated-application stability. Test station target height, facing, expected viewpoint translation, invalid/inside-boss rejection and weapon residual distance. Verify the game's actual mouth call site, mouth string, and boss stage getter against the supported executable, alongside existing layout checks.

A live headset playthrough is required to verify this station is clear of the building geometry and that projectiles/capture behave correctly with the new virtual origin. No new 1.7.46 headset screenshots or logs have been supplied yet. Short SCENEVIEW logs record stage, mouth, eye and yaw so framing can be diagnosed without verbose probes.

## Outside comfort reference

Meta's comfort guidance recommends avoiding sudden acceleration, rapid direction changes and unnatural camera motion. The implementation therefore keeps head tracking free, uses a level station without continuous camera steering, and fades viewpoint changes:
https://developers.meta.com/vr/design/comfort/
