# 1.7.49

Evidence: gbvr_report_20261023-194959.zip and MedalTVScreenRecording20261023194926741.mp4. Run 1.7.48 installed both knock hooks. No knockdown start event was recorded. The station used mouth (204,-217,-647.4), eye (192.1,-217,-626). The video at 12 seconds shows the view inside geometry and malformed visible model surfaces.

Remove attachment-derived camera translation and extra body yaw rotation. The station follows the verified normal player eye; the boss target provides horizontal facing only. This fixes the unsafe relocation, but does not claim the original eye-level-at-boss goal is met. Avoid further unverified teleport coordinates.

Remove the temporary head-relative clavicle relocation, cap arm length at native length and reduce shoulder slide to 15 cm during the encounter. Keep arms-only encounter lifecycle and all earlier features.

Fix knock_env expiry: expire by elapsed duration, not envelope strength. At elapsed zero the envelope legitimately has zero strength and must stay active. In-game testing is required to confirm animation interception and visible recovery effects.
