# 1.7.51 rooftop viewpoint correction

The 1.7.50 log reports eye=(187.7,-217.7,-567.4), at boss mouth height. The user reports that the camera was inside a building and the game's cable remained visible. Restore the player's rooftop eye height and keep only a three-foot outward and four-foot sideways offset from that eye. Angle the view toward the recorded boss mouth using a world-space pitch about the horizontal right axis, preserving headset tracking and the game's actor position. Existing arms-only and full-body restoration logic remains.

The rooftop rappel cable is a game model, distinct from the mod's own cord (already disabled during the fight). The small offset aims to move the cable out of the central sightline. The log alone cannot prove it is absent from the headset picture. The installation and log collection scripts remain unchanged.
