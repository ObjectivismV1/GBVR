# 1.7.52 render and physics separation

The Stay Puft pitch is applied to the temporary VR render basis after the tracked head pose. The actor's transform, velocity, game camera fields, collision and gravity are not edited. The level basis remains horizontal for controller hand aim and translation. The resulting render basis is also used for headset-aligned controller direction and visible weapon placement, so shots follow the visible gun; it does not rotate the game's world or change its physics rules.

Audit found that 1.7.51 published controller tips and grips from the already-offset VR camera, then added the same station delta again in the gun, PKE, arm targets and beam muzzle. Remove those extra shifts. The avatar base and original animation anchor each receive their single visual offset. A headset probe is still required to assess cable visibility and real-time arm/beam alignment.
