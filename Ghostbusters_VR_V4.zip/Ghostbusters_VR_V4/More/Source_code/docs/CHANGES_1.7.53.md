# 1.7.53 rooftop alignment

The 1.7.52 headset log confirms the scene station engaged at eye=(197.3,-9.1,-627.0), mouth=(203.2,-217.5,-645.6), with an 84.6 degree rendered pitch. The cable remains visible and the blaster must be pulled down to aim. The root of the latter mismatch is `head_aim_publish`: hand and gun transforms use the pitched rendered basis, but the game weapon direction still used the horizontal level basis. Rotate a copy of the level basis by the same scene pitch for controller aiming during this fight only. Game movement and physics keep their original basis.

Lift the temporary VR eye 1.25 feet, and increase its lateral clearance from 4 to 9 feet. The scene delta moves the visible body reference alongside the view; neither the actor's transform nor game world geometry changes. The rope is part of the game's scene, so its disappearance must be confirmed in a new headset run; the game model is not deleted or globally suppressed.
