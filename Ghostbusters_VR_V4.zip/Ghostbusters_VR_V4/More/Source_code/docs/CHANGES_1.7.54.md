# 1.7.54 rooftop position correction

Audit of 1.7.53 found its nine-foot sideways view shift contradicted the user's instruction to stay at the player spawn. Set the temporary VR view's X/Z to the unmodified first-person player eye and retain only the requested 1.25-foot visual lift. Recompute the yaw and pitch to the current boss mouth from that exact X/Z. The body render delta follows the view; the actor's world position, gravity, collision and physics remain unmodified. Keep the corrected controller aiming basis from 1.7.53.

The supported executable includes `CCable`, `cable_segment`, and a separate rappel harness model. Existing body and hose hiding does not identify the foreground rooftop cable. Skipping an unverified cable actor render function risks changing its simulation, so cable suppression remains unimplemented pending a current view capture and exact render-item identification.
