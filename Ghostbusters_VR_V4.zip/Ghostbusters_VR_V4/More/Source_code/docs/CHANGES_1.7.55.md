# 1.7.55 outward rooftop viewpoint and visible model heading

The 1.7.54 log confirms scene station eye=(192.4,-7.9,-626.3), boss mouth=(204.0,-217.0,-647.4), pitch 83.4 degrees. The rope is at the old spawn and the building obstructs aiming. Put the VR-only station ten feet horizontally toward the boss, at the same elevated rooftop height. This should leave the near cable behind the viewer without removing a physics actor. Recompute yaw and pitch from the new station.

The rendered body root previously used only torso `phi`, whereas the scene camera turned by `station.yawDelta`; add that yaw delta only to the model matrix transform in the temporary scene. The gun and tracked hand transforms still use the common pitched VR basis, with player actor/world physics unchanged. A headset test must confirm rope clearance and arm, gun, and beam alignment.
