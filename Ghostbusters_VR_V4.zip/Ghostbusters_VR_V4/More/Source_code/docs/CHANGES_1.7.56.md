# 1.7.56 Stay Puft sightline cleanup

- Retains the 1.7.55 rooftop station position: 10 ft outward at rooftop height.
- Station placement/recenter continues to derive horizontal facing directly from the current Stay Puft focus; a regression test now locks this behavior.
- Scripted fight shoulder roots move farther behind and slightly below the headset eye.
- The arms-only collapsed chest/legs are moved far behind and below only for floating scripted fight arms, clearing the center view.
- No game actor, rope/cable, collision, movement, or physics state is changed.
