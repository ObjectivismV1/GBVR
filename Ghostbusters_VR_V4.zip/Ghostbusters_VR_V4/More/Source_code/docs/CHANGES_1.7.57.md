# 1.7.57 stable hands, alt fire, and transition fixes

- Physical left trigger now always maps to the game's native LT so every equipped beam/weapon receives its real alternate-fire input.
- Capture/wrangle moved to normal right-stick click; Y-layer right-stick click remains Vent.
- Legacy boson_grip shortcut defaults off so alternate fire has one consistent physical control: left trigger.
- Gun hand-lock fits persist per equipped item and use controller-relative axes.
- PKE hand lock persists across model replacement and re-equip.
- Right-arm wrist target remains controller-driven across view-model swaps.
- Stay Puft rooftop floating-arm mode is latched through the fall/dialogue cinematic and only releases after a stable close normal camera returns.
- Flat/3D mode has longer camera-transition hysteresis to prevent momentary flicker.
- Near/far values are shared across both eyes in each stereo pair.
