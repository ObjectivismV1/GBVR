# 1.7.58 exact game-hand grip and reliable sprint

- Replaced guessed gun/PKE placement with the game hand's complete affine hand-to-prop transform.
- Per-weapon/PKE relation is locked after stable samples and survives view-model rebuilds and holster/draw.
- Strict fallback: short gaps hold the last exact pose; stale gaps leave game placement untouched.
- Legacy gun/PKE cm fit and wrist values are migrated/forced to zero.
- `grip_at_hand=1` and `hand_lock=1` are enforced.
- Sprint toggle is persistent and speed method is forced to the verified nudge method.
- 1.7.57 alt-fire/Capture/Vent mapping and camera/Stay Puft fixes are retained.
