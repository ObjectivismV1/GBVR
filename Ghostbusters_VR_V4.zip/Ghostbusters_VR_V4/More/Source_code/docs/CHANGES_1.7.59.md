# 1.7.59 exact grip bootstrap

The 1.7.58 video shows a transient right-hand separation and stationary PKE. Exact prop placement requires an arm-core game/final hand pair. Its right-hand pair is published only when the arm has a target; the PKE arm target in turn can depend on an already placed PKE. For a fresh controller aim, bootstrap a right-hand target when the gun arm solve fails or the PKE arm target is absent. The arm core then publishes its exact pair and the existing gun/PKE hooks use the game's affine relation. No guessed prop offset is added.

The supplied 30-second video contains weapon handling and menus but no knockdown occurrence. Its short log contains no knock event. Existing knock interception is preserved; a log of the actual falling event is required to identify the missing animation entry path.
