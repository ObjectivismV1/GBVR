# 1.7.60 knockdown player-camera coverage

Move fall detection and the fall-flag guard from the optional full-body IK
update to the verified player camera path. This path runs for the stereo view
when the game's player actor is valid, including when body following is off.
Continue guarding after each application tick. Report the big-hurt animation
indices and fall flag once per event to distinguish an animation route that
bypasses both the knockBack and fall-consumer hooks. Preserve the 1.7.59
PKE and gun-hand bootstrap, game physics, and all existing settings.

The supplied recording and logs contain no actual knockdown event. This
change requires an in-game reproduction to confirm that the fall animation
is absent and the comfort effect appears for its configured duration.
