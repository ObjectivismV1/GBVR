# 1.7.61 prop grip continuity

The 1.7.60 log confirms that build loaded, but with diagnostics off it contains
no prop placement counts and no knockdown event. In 1.7.58/60 a missing right
hand pair past 200 ms made the gun revert to its unmodified game pose, and a
missing PKE pair made its entity placement return without moving it. Capture
an exact prop-to-controller affine relation whenever an exact game hand pair
succeeds, keyed by weapon item for the gun and PKE object identity for the
meter. During missing rig frames, apply that relation to the fresh tracked
controller. Before first exact capture, use the existing controller aiming
placement rather than leaving a prop stationary. Add a single compact
PROPSTATUS sample with normal diagnostics disabled. Keep 1.7.60 knockdown
camera-path coverage.

Headset behavior and knockdown interception still require an in-game event.
