# 1.7.62 game-hand grip, moving PKE, sprint and knockdown fixes

- Gun and PKE placement are anchored from the game's own right-hand bone transform. The probe preserves the complete game prop-to-hand relation; there are no gun/PKE centimetre fit offsets or direct prop-to-controller fallback.
- A streamed/missing viewmodel reconstructs the hand first from its previously captured hand-to-controller relation, then reapplies the game's locked hand-to-prop relation. Viewmodel loads and holster/draw therefore cannot move the grip.
- Grip state persists across ordinary holster/redraw and model streaming, but is reset when the player actor genuinely changes so a new level/checkpoint cannot inherit a stale skeleton relation.
- PKE placement is reapplied after the game's PKE update/collect and after the current arm pass. The hand drives the PKE; the PKE no longer drives the hand, and no stale world-space PKE pose is held.
- Holstering the blaster no longer zeros the PKE triggers while the PKE is the active item.
- The 170% speed mechanic uses the nudge route and a physical L3 hold always refreshes the boost request. Toggle mode remains on until the player clicks L3 again; temporary menus/layers do not clear it.
- Knockdown keeps the original fall intercepted. Its VR replacement is the configured timed slow walk, dark vignette and worse gun aim; movement/aim are no longer tied to how long a big-hurt animation happens to report active.
- Left trigger remains native alternate fire for every weapon; normal right-stick click remains Capture/wrangle and Y-layer right-stick click remains Vent.
- Added compact always-on diagnostics for first exact gun/PKE game-hand capture, model-gap hand recovery, and first speed-boost request.
- Exact supported-game layout/signature verifier passes; all 62 native tests and all 62 ASan/UBSan test runs pass.
