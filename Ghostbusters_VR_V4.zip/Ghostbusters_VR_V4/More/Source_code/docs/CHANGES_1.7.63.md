# 1.7.63 quality/performance audit

- No new gun/PKE grip offsets or hand-placement guesses. The 1.7.62 game-hand transform remains authoritative.
- Removed obsolete reverse PKE -> arm state/work; the live direction is hand -> PKE.
- Profiling timers do no QPC work while diagnostics are off.
- VirtualQuery timing reuses a cached performance-counter frequency.
- Auto-quality no longer saves a lower picture level merely because SteamVR/Virtual Desktop delivered fewer frames. A resolution fallback requires measured game render pressure too.
- The older fast PERFADVICE path is advisory only; it cannot permanently reduce sharpness by itself.
- No speculative global texture-filter, render-scale, FOV, or near-plane changes were made. `texture_aniso` remains the existing tested sharpness path.

## Why this is conservative

Low delivered headset FPS can come from SteamVR/Virtual Desktop/compositor timing even when game render work is within budget. Lowering the game picture in that case sacrifices clarity without proving it fixes the bottleneck. 1.7.63 therefore protects sharpness unless the probe has measured evidence of game render pressure.

## Verification

- 62/62 final portable regression tests pass.
- Portable ASan/UBSan coverage is clean for the 1.7.63 logic changes.
- Exact target-game layout/signature verifier: ALL PASS.
- Final headset feel/FPS still requires a real 1.7.63 play-test.
