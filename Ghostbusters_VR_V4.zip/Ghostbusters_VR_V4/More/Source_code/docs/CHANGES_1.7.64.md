# 1.7.64 (built on 1.7.63)

- Life bar on the gun: moved 5 cm to the left and 4 cm lower (new gun_hp_side_cm -5, gun_hp_up_cm 3, which may now be negative). Menu: Fixes > "Life bar: left / right" and "Life bar: height" (the "forward" step stays in the settings file as gun_hp_fwd_cm).
- PKE grip self-check (pke_grip_heal, default 1): a new pull-out of the PKE starts from a clean grip; while the game's own PKE pose is fresh, the locked PKE->hand relation is compared with what the game shows, and a steady difference of more than 9 cm / 10 degrees for 20 samples makes the grip be captured again. Gun grip code is untouched.
- Belt copy of the PKE (cloth_pke, cloth_pke1: the device on the belly with the swinging cable seen in the 1.7.63 video) is squashed with the other unwanted body bones (hide_belt_pke, default 1).
- Always-on compact logging (the quiet log filter now lets these through): PKEGRIP (about once a second while the meter is in hand), PKEHELD (in/out of hand), PROPSTATUS, BELTPKE, GUNBAR (player health read and bar offsets), HANDGRIP, SETTINGS. Settings revision 139.
- Not changed: gun spawn and gloves, controls, speed, health bars on ghosts, intro skip, Deluxe settings, beam damage (100).

## Package addition (no code change)
- Linux / Steam Deck install route: `INSTALL_LINUX.sh`, `REMOVE_LINUX.sh`, `CHECK_INSTALL_LINUX.sh`, `COLLECT_LOGS_LINUX.sh`, `tools/gbvr_linux.sh`, `README_LINUX.txt`.
- The DLL is byte-identical to the first 1.7.64 zip (SHA-256 976b825c...). Only scripts and text were added.
- Tested here: the scripts against a pretend Steam library (path with spaces, UTF-16 settings.ini, another mod's d3d11.dll to back up, reinstall, remove, logs zip). Not tested: the mod inside Proton.
