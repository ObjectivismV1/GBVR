# 1.7.65 - player edition (built on 1.7.64)

Nothing here has been run in the game yet; it is built and unit-tested only.

## What changed
- In-VR menu: the developer items are gone. Removed: Test the controller buzz, Mark this moment, Cutscene guard, Same picture in both eyes, Menu follows my hand fast, Chest camera (both rows), Same hands in both eyes, Smart health bars. The Fixes tab is now called Extras (mirrors, life bar, wall hiding, VR FPS cap). Blink dash is no longer labelled experimental. The Help tab has no author notes any more. The footer says "VR mod <version>".
- Keyboard: only F4 (headset view), F9 / Ctrl+F9 (recenter / measure height) and F12 (menu) work. All other test keys (F1-F3, F5-F8, F11, Ctrl+F4, Shift+F4, Ctrl+F11, Ctrl+F12, Insert, Delete, Home, End, PageUp, PageDown, Pause, Ctrl+H) do nothing unless `probe_data=1` is in gbvr_settings.txt.
- Developer-only settings (watch_game, rig_view, chest_cam, diag_timing, damage_watch) are forced to 0 unless `probe_data=1`, also for profile files. The hidden menu items keep the same values as before (the defaults).
- Defaults now equal the author's settings file. The only default that changed is picture_level 3 -> 2 (the author plays at 2). Level 3 is still in the menu (View > Picture sharpness) for strong PCs. Life-bar position keeps the 1.7.64 move (side -5, height 3); the author's older file said height 7.
- Background logging is kept as it was (quiet by default; `probe_data=1` adds the heavy dumps).
- Not changed: gun and PKE placement, controls, speed, ghost health bars, beam damage (100), intro skip, Deluxe.

## Package
- README.txt is player-facing (install, controls, problems). No author notes.
- Author-only posting notes are in docs/PUBLISHING_NOTES.md (source only).

## Checks
- tests/run_all.sh: 62 of 62 passed.
- Built DLL checked: none of the removed menu strings are in it; the new ones are.

## Package addition (no code change)
- PLAYER_GUIDE.pdf (1 page, plain bullets: all the controls) is in the zip. The DLL is unchanged.

## Folder clean-up (no code change)
- Removed from the zip: SKIP_INTRO.cmd, RESTORE_INTRO.cmd and tools/skip_intro.ps1 (they never worked; the separate intro-skip mod winmm.dll + GhostbustersNoIntro.asi is not touched), CHECK_FREEZE.cmd (COLLECT_LOGS.cmd already writes the freeze report) and bin/gbvr_watch.exe (developer-only; the mod never starts it in the player edition).
- All Linux files now live in one linux/ folder (INSTALL / REMOVE / CHECK_INSTALL / COLLECT_LOGS scripts, gbvr_linux.sh, README_LINUX.txt). The zip root has only the four Windows .cmd files, README.txt, PLAYER_GUIDE.pdf and VERSION.txt.
- The watcher is still built from source (src/watch.c); it is just not packaged. The DLL is unchanged.
