# 1.7.66 - PKE stays in the hand, no gun at your feet at spawn, life bar lower (built on 1.7.65)

Nothing here has been run in the game yet; it is built and unit-tested only (63 of 63 tests).

## What the 1.7.65 video + report showed
- Spawn: the gun was drawn at the floor for about 0.8 s before the hands existed, then jumped into the hands.
- Gun -> PKE switch: a short hands-less gun, then nothing, then the PKE.
- PKE: it came out of the belt and sat far from the hand at first, then slid/popped. The log showed the PKE hold being frozen while the meter was still coming out (15 cm from the hand while the game's own hold was 8 cm; it then grew to 12.7 cm), and the old self-check only corrected after a 9 cm / 10 degree difference for 20 samples.
- Life bar on the gun was not low enough.

## What changed (each has its own switch in gbvr_settings.txt; all default 1)
- `pke_live_grip`: the PKE follows the hold the game shows right now (small changes are followed at once; a big jump is believed only after 8 steady samples, so a one-frame glitch is ignored). A new pull-out (meter away for 2 s) starts clean. 0 = the 1.7.65 frozen hold.
- `hide_gun_gap`: while the gun has no hand (spawn, weapon switch) it is not drawn at the game's own spot; it appears the moment the hand is ready. Hidden at most 1.5 s with no hand at all; a hand rebuilt from the controller is hidden only after 0.35 s and for at most 2.5 s. 0 = old behaviour.
- `gun_grip_heal`: for 10 s after the gun's hold is locked it is compared with what the game shows; a steady, clearly different hold (more than 4 cm or 6 degrees for 40 samples) is taken again, up to 3 times per weapon. 0 = old behaviour.
- Life bar on the gun: `gun_hp_up_cm` default 3 -> -4 (7 cm lower). Saved files are migrated once (settings revision 140). The menu slider (Extras > Life bar height) still works.

## More logging (quiet log, with times so a video can be lined up)
- `VMSWITCH t=` weapon/viewmodel switch (which item, whether its hold was already locked).
- `GUNGAP ended t=` how long the gun had no hand; `GUNGAP summary` at the end.
- `GUNGRIP lock taken / re-captured t=` per weapon.
- `PKEGRIP new pull-out / jump t=` and a once-a-second `PKEGRIP live` line: relation followed/held/jumps, hand scale drawn vs game, drawn hand to controller grip, PKE scale.

## Not changed
- Controls, speed, beam damage (100), Deluxe, intro skip (`winmm.dll` + `GhostbustersNoIntro.asi`), all other defaults. The new features have no menu items (player edition).

## Honest status
- Untested in the game. Root cause of the PKE looking off the glove is a best-supported guess (frozen hold); the new PKEGRIP live line (hand scale, drawn hand to controller) should settle it if it is still wrong.

## Checks
- tests/run_all.sh: 63 of 63 passed (new: tests/test_handlive.cpp for the live-hold logic).
