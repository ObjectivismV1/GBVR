# 1.7.67 - PKE no longer stretched or pulled; gun hand left as in 1.7.65 (built on 1.7.66)

Nothing here has been run in the game yet; it is built and unit-tested only (63 of 63 tests).

## What the 1.7.66 report showed
- The PKE log line (once a second) shows the drawn hand matrix changing size: average axis length 1.02-1.03 most of the time, but 1.18-1.38 at other moments, and the PKE's own axes then came out uneven (for example 1.21/0.91/1.81). The game's own hand stayed at 1.00. The PKE is placed through the drawn hand, so at those moments it was stretched and pushed out by the same factor: "PKE to the drawn hand" went from 13.0 cm to 17-25 cm while the game's own PKE-to-hand distance was 12.7 cm. That is the "pulled" PKE.
- While the hand moved fast (t=40-46 s) the game's own PKE-to-hand relation swung between 6.5 and 17.7 cm. The meter and the hand are sampled a moment apart, so a fast hand makes the relation noisy; 1.7.66 followed it at once.
- The two gun features of 1.7.66 never did anything in that run (0 hidden gaps, 0 re-grips), so the gun was the same as 1.7.65.

## What changed
- `pke_rigid_hand` (new, default 1): the PKE is placed through a clean copy of the drawn hand: the three axes are made perpendicular and the same length (the size of the last un-stretched moment), the position is kept. A stretched hand matrix can no longer stretch or push the meter. 0 = the hand as drawn.
- `pke_live_grip` (kept, default 1) now only adjusts the hand-to-meter relation while the hand is steady (under about 24 cm/s); while it moves fast the last good relation is kept. The meter eases to a new relation (about 27 cm/s at most) instead of jumping.
- `gun_grip_heal` and `hide_gun_gap` are now 0 by default and are switched off in saved settings (settings revision 141). The gun hand is exactly as in 1.7.65. Their log lines stay.
- Life bar on the gun: unchanged from 1.7.66 (7 cm lower than 1.7.65).

## More logging
- `PKEGRIP live`: the drawn hand's three axis lengths, longest/shortest, how much the arm was lengthened, the hand speed, how many updates were made while steady / kept while moving, how many moments were stretched.
- `GUNHAND` (new, once a second while the gun is held): the same hand numbers for the gun hand (does the hand change size while the gun is held?), the gun's drawn size and the drawn hand's distance to the controller grip.
- `GUNGAP summary` also carries the clean-hand numbers.

## Not changed
- Controls, speed, beam damage (100), Deluxe, intro skip (`winmm.dll` + `GhostbustersNoIntro.asi`), gun placement, all other defaults.

## Honest status
- Untested in the game. The cause of the hand changing size in the first place is not found yet; the new GUNHAND / PKEGRIP lines show whether it follows the arm being lengthened (arm_stretch_pct is 220 in the author's file). The glove itself is not changed by this version.

## Checks
- tests/run_all.sh: 63 of 63 passed (tests/test_handlive.cpp now also covers the clean hand frame).
