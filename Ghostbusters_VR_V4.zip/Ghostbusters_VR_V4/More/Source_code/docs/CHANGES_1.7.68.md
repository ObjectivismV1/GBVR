# 1.7.68 - the hand stays on the gun handle like at spawn (built on 1.7.67)

Untested in the game; built and unit-tested (63 of 63).

## What the 1.7.65 video showed (looked at frame by frame)
- Spawn (0-3 s): the glove wraps the gun's handle, high and natural. The equipped item was not known yet, so the game's hold of that moment was used every frame.
- After PKE -> gun (24-30 s): the hand sits at the bottom of the grip and then floats under the gun. The 1.7.66 log: the hold for item 1 was frozen 0.08 s after the item became known (VMSWITCH 13.39 s, lock 13.47 s), while the draw animation was still moving, and kept for good.

## Change
- `gun_live_grip` (new, default 1, settings revision 142): the hand-to-gun hold is the game's hold as the game shows it now, every frame, the same way it was at spawn. A one-frame glitch is ignored; a hold that changes and stays changed is followed after 8 samples. 0 = the old frozen hold.
- Logs: `GUNGRIP live` when the first hold is taken and when the game's hold changes.
- Everything from 1.7.67 stays (PKE clean hand, gun_grip_heal 0, hide_gun_gap 0, life bar lower).
