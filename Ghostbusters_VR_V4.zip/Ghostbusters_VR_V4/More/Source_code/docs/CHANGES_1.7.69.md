# 1.7.69 - one hold rule for gun and PKE, elbows bend, smooth stairs (built on 1.7.68)

Untested in the game; built and unit-tested (63 of 63).

- Gun: every equip, weapon switch or unholster (gun away more than 0.25 s) starts from the game's hold of that moment, then follows it every frame (gun_live_grip). No hold is carried over from an earlier draw, so it is the same each time.
- PKE: the same rule as the gun (`pke_steady_only` 0, default): the game's hold every fresh sample, glitches ignored, no easing. A new pull-out is anything after 0.5 s away (was 2 s). The clean hand from 1.7.67 stays (pke_rigid_hand 1). pke_steady_only 1 = the 1.7.67 steady-hand-only version.
- Elbow room (`arm_reach_pct`, default 120, menu Extras > Elbow room): the avatar's upper arm and forearm are 20 % longer along the limb at all times. Older logs show the controller 97-122 % of the avatar's arm length from its shoulder in normal play, so the arms were straight almost all the time; with the extra length the elbow bends when the hand is near you. The arm still stretches further only when the hand is out of reach (arm_stretch_pct). Shoulder pull / slide use the longer arm too.
- Stairs (`stairs_smooth_ms`, default 120, menu Extras > Smooth stairs): the eye hung on the character's feet, which jump up or down each stair. The eye height is now eased (about 0.12 s, never more than 1 ft behind; jumps over 3 ft snap). New STAIRS log line per flight of stairs: up/down, how far, how fast along the floor, sprint on/off - to see the "slow" part next time.
- Settings revision 143 sets these for saved files.
