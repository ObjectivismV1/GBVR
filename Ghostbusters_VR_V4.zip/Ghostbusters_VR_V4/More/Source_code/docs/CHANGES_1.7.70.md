# 1.7.70 - from the 1.7.69 video + log (built on 1.7.69)

Untested in the game; built and unit-tested (63 of 63).

## What the video and log showed
- PKE (video 59-73 s = log 26-40 s): the meter was drawn 40-60 cm in front of / above the empty fist, where the game's own scan animation holds it, while the log said the written pose was 13 cm from the hand. The probe wrote the meter's pose fields (+0x54/+0xF4, +0x4B8/+0x4C4), but the model is drawn from what the game's own setter (0x141E60, this + 4x4) sets. Those writes never reached the picture.
- Gun after PKE -> gun (video 74-80 s = log 41 s): the first "hold" after the switch was 70.8 cm (the draw animation, the gun still on its way from the back); 1.7.69 took it and held it for 0.26 s, so the gun floated sideways beside the hand.
- Hand: for several seconds after the PKE came out the drawn hand matrix had axes like 0.67/2.16/0.89 (stretched and sheared).

## Changes
- `pke_set_matrix` 1: the PKE pose is handed to the game through its own setter every time it is placed (and for the second eye of a pair), so the drawn model takes it. PKESET log line says whether the setter was found.
- Gun: a game hold farther than 25 cm from the hand is never used (draw / holster animation). The hold is kept per weapon (only real in-hand holds are stored), so switching or unholstering starts from that weapon's own hold at once. The very first draw of a weapon in a session is not drawn until the game's hold reaches the hand (a fraction of a second). PKE: holds over 30 cm are ignored the same way.
- `hand_clean` 1: a hand bone matrix that comes out stretched / sheared is made clean (same directions, perpendicular, the hand's normal size) before it is written, so the glove and fingers are not stretched.
- GUNGAP summary adds: setter calls, gun holds ignored, first-draw calls hidden, hand bones cleaned.
- Settings revision 144.
