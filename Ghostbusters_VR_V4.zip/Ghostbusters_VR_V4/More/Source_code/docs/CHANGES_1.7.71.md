# 1.7.71 - PKE moved where it is drawn, slime out of the gun, smooth stairs, steady gun when walking (built on 1.7.70)

Untested in the game; built and unit-tested (tests/run_all.sh: 65 test programs + the JPEG check, all pass).

## What the 1.7.70 video and log showed (video 0 s = log t 1048 s)
- Slime blower (video 0-3 s): the slime came out low on the right and flew off to the right while the gun in the hand pointed ahead. The proton stream asks for the attachment "tip" (moved onto the hand gun); the slime blower asks for something else, which was never moved.
- PKE (video 5-17 s = log 1052-1066 s): the meter stood upright 40-60 cm in front of the fist, at the same spot in the view whatever the hand did; now and then it flipped onto its side near the hand (the "glitching / pulled"). The log said "PKE to the drawn hand 13 cm" and "pose through the game setter 199864". So the setter (1.7.70) and the field writes still never reach the picture: the meter is drawn from another copy of the game's own pose.
- Stairs (STAIRS lines): up a flight at 2-6 ft/s along the floor (16-19 ft/s on the flat with sprint). The sprint boost moves you on by an extra step along the floor only, which on stairs pushes into the next riser.
- No errors, no crash, clean exit.

## Changes
- `pke_draw_swap` 1: the PKE is moved the way the gun is: when the game draws a matrix that IS its own pose of the meter (within 4 cm / ~5 degrees), the in-hand pose is drawn instead; once a draw call is recognised (12 matches) parts of the meter from the same call are carried along. PKEDRAW log line (every 30 s while the PKE is out): which game calls drew it, how often it was moved, or a NOTE when nothing matched.
- `slime_muzzle` 1: while the slime blower is in your hand, every attachment the game asks for on the game gun's barrel line is carried with the gun to your hand (the same exact move as the gun model). Pack, hose and body are left alone. SLIMEFIX log line: names and counts.
- `stairs_ramp` 1: a flight of stairs becomes a smooth slope for your eye (straight-line fit over 0.5 s; standing still = exact; 1 ft cap; big jumps snap). The eye speed on a test staircase is 2.5x steadier than 1.7.70.
- `stairs_lift` 1: going up stairs with sprint on, the extra step climbs with the stairs (plus 0.6 cm) instead of pushing into the riser. Jumps are not lifted. STAIRS line now also shows the stick push and the lifts.
- `gun_hold_smooth_ms` 150: small changes of the game's hold on the gun are eased (the walk animation made the gun and the left hand on its barrel tremble); a real change of hold or a new draw still snaps. GUNHAND line: two hands on/off, stick, how much the game's hold moves per update standing vs walking. GEARSHAKE (gun / PKE tremble per eye, standing vs walking, one vs two hands) is in the quiet log again.
- Packaging: tests/run_all.sh is shipped again (package.sh deleted it), BUILD_1.7.71.cmd/.ps1 and README_BUILD_1.7.71.txt added (BUILD.cmd called a file that was missing). README says 90 Hz.
- Settings revision 145.

## Not changed
Gun placement, PKE hold rule, controls, beam damage (game base), Deluxe settings, intro-skip mod.
