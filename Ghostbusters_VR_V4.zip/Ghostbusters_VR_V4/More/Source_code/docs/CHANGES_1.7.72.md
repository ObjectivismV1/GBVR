# 1.7.72 - PKE in the hand and slime out of the gun, read from the game's own code (built on 1.7.71)

Untested in the game; built, unit-tested (tests/run_all.sh) and checked against ghost.exe (tests/verify_layout.py: all pass, including the new 1.7.72 checks).

## The goal (from the 1.7.70 video)
- PKE: it stood 40-60 cm in front of your fist, fixed in your view, sometimes flipping. It must sit in the hand and follow it.
- Slime: it came out low on your right and went where your head looked. It must come out of the gun in your hand and go where the gun points, like the other fire modes.

## What the 1.7.71 log and ghost.exe showed
- PKE: the game draws the meter by PUSHING its entity pose (+0x54/+0xF4) and, with the goggles on, its second pose (+0x4B8/+0x4C4) onto the draw context's matrix stack (0x41360), not through the matrix product 1.7.71 watched (PKEDRAW: nothing). The player's update sets that entity every frame to "player position + a fixed offset turned by the aim" (0x2C3AB0): a pose fixed in front of the view - the floating PKE.
- Slime: the slime blower is its own entity (CGadgetTether). Its fire logic (0xAB320) starts the stream at its own attachment "slime" (where the game holds the gun) and ends it along the game's view (player+0xB550: the camera), so it went where your head looked. It never asks the player for an attachment, so 1.7.71's SLIMEFIX never ran.

## Changes
- PKE (`pke_draw_swap` 1): the two pushes of your meter are handed the in-hand pose at the moment the game pushes them (hook on 0x41360, pointer compare only). PKEPUSH line every 10 s and when the PKE goes away: pushes, whether the fields already held the in-hand pose, how far the game's pose was.
- Slime (`slime_muzzle` 1): the tether's "slime" attachment is carried from the game's gun to the gun in your hand (same exact move as the gun model). While its fire logic runs, the game-view pointer is hidden, so the game uses its other path: start + your aim (the live hand aim) x range - the way the proton stream has been handled since 1.7.27. Put back right after. SLIMEFIX line every 15 s.
- Removed: the 1.7.71 matrix-product PKE swap and the attachment-name slime path (both never fired).
- Kept from 1.7.71: smooth stairs, sprint lift on stairs, gun hold smoothing, packaging fixes.
- No settings change (revision 145).
