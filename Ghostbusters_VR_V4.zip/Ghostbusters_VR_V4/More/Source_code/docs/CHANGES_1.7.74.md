# 1.7.74 - PKE grip from the hand's own hold, slime tether data (built on 1.7.72 source + the 1.7.73 behaviour)

Untested in the game; built, unit-tested (tests/run_all.sh) and checked against ghost.exe (tests/verify_layout.py: all pass).

1.7.73 came as a DLL only (no source). Its behaviour is rebuilt here from its README, settings and log: frozen gun / PKE grips (its saved settings are kept: settings revision 146 -> 147 changes only the new keys), debounced two-hand hold, one slime-tether press per left-trigger squeeze.

## What the logs showed
- 1.7.72 / 1.7.73 PKEPUSH: every draw of the meter already had the in-hand pose. So the PKE IS drawn where the probe puts it; the pose itself was wrong.
- The grip was taken from the meter's ENTITY pose. ghost.exe: the player update sets that pose to "player position + a fixed offset turned by the aim" (0x2C3AB0), not to the hand. Its distance to the game's hand swung 8.5-17.3 cm in the 1.7.73 log, so a grip taken from it is wrong and moves with aim and walking ("does not follow the hand, gets pulled"). 1.7.73 froze that wrong grip.
- The meter as the hand really holds it is the second pose the player update writes (0x141E60 from 0xD6542): the animation's R_PKE attachment.
- Slime: SLIMEFIX shows the start carried to the hand gun and the game view hidden in every update; why the tether "does not work" is not in the log. New SLIMETETHER lines say what the tether's ray hits (including your own body) and when its end points change.

## Changes
- `pke_hold_rpke` 1: the PKE grip = R_PKE against the game's hand, only while it is within 25 cm of the hand and steady for 6 samples, then kept for the session (log PKEHOLD). Before that the last grip is used on the tracked hand.
- Two-hand hold: starts after 3 good polls in a row; once on, the left hand may drift 25 % farther before it lets go.
- `slime_lt_edge` 1: the slime blower's left trigger is one short press per squeeze.
- SLIMETETHER / SLIMEFIX: tether mode, ray hit (class, point, self-hits), end points, ray start, left-trigger presses, two-hand flips.
- Defaults now equal the 1.7.73 values: gun_live_grip 0, pke_live_grip 0, pke_grip_heal 0, gun_hold_smooth_ms 0.
