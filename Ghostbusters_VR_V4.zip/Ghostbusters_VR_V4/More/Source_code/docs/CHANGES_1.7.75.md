# 1.7.75 - the slime tether rope starts at the gun in your hand (built on 1.7.74)

Untested in the game; built, unit-tested (tests/run_all.sh) and checked against ghost.exe (tests/verify_layout.py: all pass, new 1.7.75 checks).

## What the user saw
The slime tether (left trigger) should shoot a rope that pulls things; it broke as soon as it hit.

## What ghost.exe shows
The slime blower (CGadgetTether, player+0x24D98) is its own entity. The player update places it every frame at the game's gun spot (SetTransform, vtable +0x58, called at 0xD5C97). 1.7.72-1.7.74 only moved its "slime" attachment reads to the gun in your hand; the entity, and everything that reads the entity (the rope's gun end, its physics), stayed at the game's gun spot 30-140 cm away. The two ends of the same rope disagreed, so it snapped.

## Change
- While the slime blower is in your hand, the game's own placement of it is carried from the game's gun to the gun in your hand before the game stores it. Everything (rope, shot start, effects) then agrees. The attachment carry of 1.7.72 steps aside while this works. The aim stays the live hand aim (1.7.72). SLIMEFIX line shows the placements.
- Everything else as 1.7.74 (PKE grip from the hand hold, two-hand debounce, one tether press per squeeze, 1.7.73 settings kept).
