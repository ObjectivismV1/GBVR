# 1.7.76 - slime rope anchors one per squeeze; the PKE hand turns with your controller (built on 1.7.75)

Untested in the game. Built, unit-tested (tests/run_all.sh) and checked against ghost.exe (tests/verify_layout.py: all pass, new 1.7.76 checks).

## What the user saw (1.7.75 video + log)
- The PKE is still "dragged" in the hand.
- The slime launcher still does not stick and make the rope.

## Slime rope - what ghost.exe shows
The player update calls the tether's rope step `AAF40(tether, 0)` every frame the alt-fire flag is set. Each call puts the ray's hit into one of the rope manager's two anchor slots (`[tether+0x5B8]`, slots at +0x25FA8, stride 0x98). A hit on an entity that already holds a slot lets the old rope go and stores the hit again; when both slots are used the rope is "complete" (manager let go, tether mode 3). A left-trigger squeeze lasts several frames, so ONE squeeze filled BOTH slots with the same thing: a rope from the bridge to the bridge, complete at once, pulling nothing.

### Change
- `slime_rope_fix` (default ON): the rope step is let through once per squeeze (a squeeze that has not anchored anything yet - nothing in the sights - keeps trying). The first squeeze at a target sets the first anchor, the next squeeze at another target sets the second and the rope forms. Aiming at the thing that already holds the first anchor is skipped (it would be a rope from it to itself).
- SLIMEROPE log lines: per squeeze - anchor set / rope complete / skipped, tether mode, what the sights hit, the two anchors before and after, the manager pointer before and after.

## PKE "dragged" - what the 1.7.75 log shows
"PKE to the drawn hand" stayed at 8.9 cm (the meter is stuck to the hand), but "PKE to the controller grip" swung from 5.5 to 9.4 cm: the HAND itself did not follow the controller rigidly. With the PKE out the hand's turn came from the game's animation (the wand rotation is the identity in that mode), not from your controller. And the meter was placed through the hand of the previous arm pass, one frame old.

### Change
- `pke_ctl_rigid` (default ON): once the PKE hold is steady, the relation hand <-> controller is captured once (from the hand exactly as it was) and kept. From then on the right hand's turn = your controller's turn x that fixed relation. The meter, placed relative to the hand, turns with the controller.
- The meter is placed through the hand of the last arm solve moved on by the way the controller has moved since (no more one-frame-old hand).
- `pke_fingers_anim` (default ON): with the PKE out the right hand keeps the game's own fingers around the handle (they used to follow your grip button, so the handle floated out of an open hand).
- The game's PKE pose setter works again (1.7.74 hooked it, which made the 1.7.70 setter look "not found": it now goes through the hook's trampoline).
- PKECTL log line (every ~10 s while the PKE is out): passes with the hand tied to the controller, how far the animation's own hand turn would have been from your controller (mean / last / max degrees), fingers kept, setter calls, how far the hand was moved on with the controller (mean / last / max cm).

## Not changed
Stairs, two-hand walking, gun, left hand, intro-skip mod, Deluxe settings, damage.
