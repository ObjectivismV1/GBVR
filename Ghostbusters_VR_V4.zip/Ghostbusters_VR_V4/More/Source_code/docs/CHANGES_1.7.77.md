# 1.7.77 - the gun follows the hand as it is now (built on 1.7.76)

Untested in the game. Built and unit-tested (tests/run_all.sh); verify_layout.py unchanged (no new game addresses).

## What the user saw
"Objects flicker sometimes and the gun lags a lot when trying to move with hands and body" (1.7.76 report, log only, no video).

## What the 1.7.76 log shows
- The gun is placed through the drawn hand of the last arm solve. In the PKE log of 1.7.76 that hand was on average 6 cm of controller movement behind the controller (up to much more in fast moves): the gun trails the controller by that much.
- From about 5 minutes in (after the first time the PKE was put away) the gun lost its hand 191 times for 60-1380 ms ("GUNGAP"); the once-a-second GUNHAND lines show the drawn hand 11, 25, 34 and 54 cm from the controller grip in those moments. The log did not say why the arm pass stopped producing a hand (quiet log): this version logs it.
- Slime rope (1.7.76): 22 SLIMEROPE lines show the intended pattern - first squeeze "ANCHOR SET", next squeeze "ROPE COMPLETE" (mode 2 -> 3). Not reported by the user this time; whether the rope pulls things is not confirmed.
- PKE (1.7.76): PKECTL shows the hand tied to the controller on thousands of passes; the user did not report the PKE this time.

## Change
- `gun_fresh_hand` (default ON): before the gun is placed, the hand of the last right-arm solve is moved on by the way the controller has moved since that solve (same rule the PKE got in 1.7.76), so the gun does not trail behind fast hands. Both eyes get the same gun pose (no per-eye difference). GUNHAND lines now end with: how many times it was moved, mean / last / most cm, age of the solve, same-sample / too-old / no-frame counts.
- GUNGAP ended lines now say what the arm code did in the gap: arm passes, replayed, with / without a right-hand target, solved, ik failed, bad space / length, no model, skipped, clamped.

## Not changed
Slime rope, PKE hand, stairs, two-hand shake, left hand, intro-skip mod, Deluxe settings, damage.
