# 1.7.78 - the gun sits on the controller (built on 1.7.77)

Untested in the game. Built and unit-tested (tests/run_all.sh); verify_layout.py unchanged.

## What the user saw
"Gun still lags and changes position, aim wrong, happened on stairs" (report 00:24). NOTE: that session's log is 1.7.76 (1.7.77 was not installed yet), so 1.7.77's fix was not in it.

## What the 1.7.76 log shows
- The gun is placed through the arm solve's hand. GUNHAND (once a second) shows that hand 5-54 cm from the controller grip in fast moves; those are the moments the gun trails / sits in the wrong place.
- When the arm solve gave no hand (GUNGAP: 8 s, 6 s, ... after the PKE was put away; 3.4 s while on the stairs) the gun used the locked hand<->controller relation instead (HandFollower, locked after 5 steady samples), which is rigid on the controller. So the gun switched between "on the controller" (gap) and "on the lagging arm hand" (no gap): the position change.

## Change
- `gun_ctl_follow` (default ON): once the weapon's hand<->controller relation is locked, the gun is placed through it ALWAYS (hand = locked relation x the controller now), whatever the arm solve made of the hand. The glove is still the arm solve's; the gun does not depend on it. Both eyes get the same pose. 1.7.77's `gun_fresh_hand` stays (it is used before the lock).
- GUNHAND lines end with how often it was used and how far the arm solve's hand was away (mean / now / most / over 3 cm). 1.7.77's GUNGAP detail (what the arm code did in a gap) is kept.
- Still unknown: why the arm solve stops giving a hand for seconds after the PKE. The next log's GUNGAP lines will name the failing step.

## Not changed
Slime rope, PKE hand, stairs, two-hand shake, left hand, intro-skip mod, Deluxe settings, damage.
