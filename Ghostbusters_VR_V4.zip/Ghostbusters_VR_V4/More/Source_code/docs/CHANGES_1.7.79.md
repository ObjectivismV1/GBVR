# 1.7.79 - the game can no longer take over the model (built on 1.7.78)

Untested in the game. Built and unit-tested (tests/run_all.sh); verify_layout.py unchanged.

## What the user saw
"The game keeps taking over the model, leaving me looking at the player character. Stop this no matter what. Seen going upstairs, on moving platforms, through portals and when loading into a level." Then: "the game reverts to its animations when this happens."

## Cause (from the code; the quiet log did not keep the CINE / FORCEDMOVE lines, so this is not seen in the report itself)
Two safety systems from older versions give the body back to the game when they think the game is moving the character:
- Cutscene guard (`cine_guard`, since 1.7.26): after a jump (portal, level load, respawn) or a long "forced" move (moving platform, stairs that the game moves faster than the stick) the probe stops changing the body, arms and gun, so the game's own animation shows.
- Forced-move fade: the eye match (body shifted to your eyes) fades to 0 in that state, so the model stays where the game had it and your head is no longer in it.

## Change
- New setting `keep_control` (default ON, also turned on for everybody by the settings migration, rev 151). While it is on:
  - the cutscene guard never releases the body, arms or gun (`cine_blend()` is always 0);
  - the eye-match fade is always 100%, so the body always sits at your eyes;
  - turn-follow / snap-turn keep working on platforms and stairs (they were paused during forced moves).
- Forced-move and cutscene DETECTION still runs (boost, dash and sprint still pause in forced moves, as before) and is logged.
- Log: CINE, FORCEDMOVE and CINESUM lines are now kept in the quiet log, with `keep_control` shown, so the next report shows when and why the game tried to take over.

## Not changed
Slime rope, PKE, gun placement, left hand, Stay Puft rooftop scene view, intro-skip mod, Deluxe settings, damage.

## Limit
If the game's own camera leaves the player (a real cutscene camera), the picture still follows the game's camera. This version only stops the probe from handing the body, arms and gun back.
