# 1.7.80 - safer installer, clearer instructions, public release kit (built on 1.7.79)

No gameplay change. The DLL is the 1.7.79 code with a new version number.

## 1.7.79 report (00:46-01:42 session, 1.7.79) - what it shows
- `keep_control` worked: 30 CINE start / end pairs (platforms and stairs "forced move", jumps from portals / level loads) and none of them let go of the body, arms or gun. 60 FORCEDMOVE lines, eye-match fade stayed 1.00.
- Two short suspends remain by design: "scripted camera does not follow the verified player" (3 frames, a portal / scripted cut) and "camera gate: non-perspective camera" (loading screens): the game's own picture shows for those frames only.
- Slime rope: ANCHOR SET -> ROPE COMPLETE in the log; PKE tied to the controller on 39,000+ passes.
- GUNGAP: 40 episodes, the arm code did not fail in any (ik failed 0, no target 0); the hand pair was just not read. The gun is placed through the locked controller relation (1.7.78), so no visible effect.
- No crash, no stall, clean exit.
- No video came with this report, so the "looking at the player character" fix could not be checked against a picture.

## Installer / instructions (tools/gbvr_manager.ps1, README) - NOT run on Windows here
- The report zip is written with normal "/" folder names (Windows PowerShell 5.1 Compress-Archive wrote "\", which Mac / Linux / zip tools showed as flat files). Falls back to Compress-Archive if that fails.
- Files from a downloaded zip are un-blocked before they are copied (no "from the internet" mark on the DLLs).
- A different game build now gets a clear message and what to do (verify files in Steam; use the Steam copy).
- After install: "SteamVR found / not found" check and NEXT STEPS (start SteamVR, start the game, controls, how to report, how to remove).
- COLLECT_LOGS says what is in the zip (no passwords, no save games).
- README rewritten: what you need, honest status, antivirus note, SmartScreen note, update, remove, troubleshooting.

## Packaging
- `PUBLIC=1 bash package.sh` builds `dist_public/` without the menu song (its licence is not known). Players can drop their own MP3 named gbvr_menu_music.mp3 in the game folder.
- `repo_kit/` + `make_release_kit.sh`: GitHub repository files, release notes, checksums, posting texts, step-by-step GitHub guide.
