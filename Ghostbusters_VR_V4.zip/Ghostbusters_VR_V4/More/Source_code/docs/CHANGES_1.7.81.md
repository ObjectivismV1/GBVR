# 1.7.81 - smooth turn (built on 1.7.80)

Untested in the game. Built and unit-tested (tests/run_all.sh, new smooth-turn tests written first and seen failing); verify_layout.py unchanged.

## What the user asked
"also add smooth turn and options for smooth and snap turn."

## What was there
Snap turn (flick the right stick) and "Right stick = snap turn" OFF, which only let the game's OWN stick turn through. The older logs (1.7.5-1.7.8) showed the game ignoring its stick in some states (GAMECAM lines), so "smooth" was unreliable.

## Change
- **Smooth turn made by the mod.** With Snap turn OFF, holding the right stick sideways turns the picture steadily (same mechanism as a snap, in small steps every frame); the body follows like after a snap. The game's own stick turn is switched off meanwhile (otherwise it would turn you twice).
  - 20 % dead zone, straight ramp to full speed, a push that is mostly up/down is not a turn, a long frame counts as 50 ms at most (no swing), speed limited to 30..360 deg/s. Pure math: `follow::smooth_deg` in followmath.h, tests in tests/test_follow.cpp.
  - Blocked the same way snap is (menus, weapon wheel, D layer, cutscene guard).
- **Menu (Play tab):** "Snap turn (off = smooth turn)" (default ON, unchanged), "Snap angle" (30), new **"Smooth turn speed"** (30-360 deg/s, default 120). To make room (a page holds 8 rows) "Buzz strength" moved from Play to the Sound tab; its setting is unchanged.
- New settings: `turn_smooth_dps` (120), `turn_smooth_own` (1; set 0 in gbvr_settings.txt to get the old game-stick smooth turn back; no menu row). Settings revision 152.
- Rooftop scene station (Stay Puft): with smooth turn it uses the same speed setting instead of a fixed 90 deg/s.
- Smooth mode counts like snap mode for "the body follows": no pause of the body-follow while your stick is held.
- Log: `TURNSMOOTH` (first turn, and after 200 frames: degrees, speed, head and game heading) and the `TURNPAD` line now says SNAP / SMOOTH (made by the mod) and counts polls, turning polls and degrees asked. TURNPAD / TURNSNAP / TURNSMOOTH are kept in the quiet log.

## Not changed
Snap turn default and behaviour, body-follow, walking, gun, PKE, slime, installer, intro-skip mod, Deluxe settings, damage.

## Test in the game
Play tab: turn Snap turn off. Hold the right stick right and left; let go. Walk while turning. Try 60 and 240 deg/s. Then turn snap back on and make sure snap still works. Note: if the picture or body "fights" the turn, send the log (TURNSMOOTH / TURNPAD lines) and a video.
