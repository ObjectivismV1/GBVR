# 1.7.82 - found by watching a YouTuber's video of the mod (built on 1.7.81)

## What the video showed (watched frame by frame)
- **Fixed:** while a cutscene is on the flat 2D screen the game's PKE ring (the big circle) was still drawn on top of the scene (14:05-14:21 and others). It is now hidden whenever the flat screen is up.
- Peter walking ahead at 13:49-15:01 is a normal first-person scene, not the model takeover.
- **Not fixed, cause not proven:** the flat cutscene panel has a pale grey-blue surround instead of black (0:24-0:28, 14:04). The code sends black frames and fades the SteamVR grid away, so this should be black. Your older logs did not keep the lines that say whether that worked, so 1.7.82 now keeps FLATVOID / FLATBLACK / FLATLOOK / FLATFROZEN / FLATGLOW lines in the log. A test to try: set the TV glow to 0 and see if the pale surround goes away.
- Not changed: the panel looks tilted/curved. That is the curve setting (default 40) plus head roll in the recording; no bug shown.

## Code
- `hud::ring_allowed()` in hudmath.h (tested in tests/test_hud.cpp); hud.cpp uses it.
- Quiet log keeps the flat-screen lines (quietlogmath.h + test).
