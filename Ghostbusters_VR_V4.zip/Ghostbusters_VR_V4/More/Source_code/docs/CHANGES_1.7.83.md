# 1.7.83 - the PKE now scans things held close to it (built on 1.7.82)

## What the video showed
YouTuber's video: 8:19-8:26 (big pink slime wall splat, Scan prompt up, nothing for several seconds), 9:16-9:17 (pink item on the floor right beside the meter, ring on it, no prompt), 9:35-9:37 (white splat next to the meter, no prompt). In all of them the meter is held right at the thing.

## Why (from the game's rules, not proven by a log: the old reports did not keep the scan lines)
The game checks the angle between the meter's own line and the thing (cone 18 deg; the mod made it 30). A hand-held meter sits about 2 ft beside / below the line to what you look at. Far away that does not matter; at arm's length it is 45-60 degrees, so the cone misses the thing.

## The change
- The cone now grows as the nearest scannable thing gets close to the meter: atan(2 ft / distance). 3 ft: 34 deg, 2 ft: 45 deg, 1 ft: 63 deg, cap 70 deg. Far things: unchanged (the setting).
- Setting `pke_close_help` (1 = on, 0 = the 1.7.82 cone). File only, no menu row. On by default (migration 153).
- Math: `pkeasy::close_cone_deg`, `effective_cone_deg` (tests/test_pkeeasy.cpp, includes a smoothness check).
- Logs now kept in the quiet log: PKECLOSE (when the wider cone starts / ends, and a summary), PKEEASY / PKESCAN / PKEPING / PKEWHY summaries (why a scan did not run), PKESCAN trigger lines.

## Not changed / untested
- Needs the trigger held (the scan is never automatic). A scan still takes about 2 pings (~4 s), which is the game's own timing.
- Not tested in the headset. If it still fails, the next report's PKEWHY lines will say which rule (cone, range, line of sight, cooldown) said no.
- The game's own lock needs a clear line; a thing behind a wall is still blocked.
