# 1.7.84 - the menu shows the whole live 3D world (built on 1.7.83)

## What you asked
The in-game VR menu should show the entire 3D world around you (not only what was in front), just pause the game, and both eyes should show the same image at the same size.

## Why it was not so
The menu used the game's own pause menu. While that is up the game draws NO 3D picture at all, so the only thing the mod could keep behind it was the last picture of each eye: a still picture of what was in front of you when you opened it. Turn your head and the rest was black, and each eye's still picture was its own stored copy.

## The change
- The menu gesture (left hand beside the head + left grip, F12, B) now opens the VR settings pages in your left hand OVER THE LIVE WORLD. The game is only frozen (the same freeze the old floating menu used; no Start press, no pause menu): the 3D world keeps being drawn around you in both eyes as always, so you can look all around, and the two eyes are the normal live pair.
- Close: the same gesture, F12, B, the A button of the pointing hand, or "Close menu".
- "Game menu >" on the pages' bottom row closes them and opens the game's own pause menu in the hand (save, load, quit) as before.
- If the game is already in a flat screen (cutscene, loading) or not running, the game's own pause menu is used as before.
- Setting `held_live` (1 = this, 0 = the 1.7.83 way). File only. On by default (migration 154).
- Logs kept: HELDLIVE (opened / closed / summary) and FROZENEYES (sizes and poses of the two still pictures when the game's own pause menu is used).

## Not tested in the headset
- The freeze is the old floating menu's (proven for many versions), but the pages in the hand over the live world are new. If the world keeps moving behind the menu, or the pages jump, send the report: the HELDLIVE and FREEZE lines say what happened.
- With the game's own pause menu (Game menu >, or a game pause) the picture behind is still a still picture: the game stops drawing 3D there.
