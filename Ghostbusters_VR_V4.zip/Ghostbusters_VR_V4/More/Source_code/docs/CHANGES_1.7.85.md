# 1.7.85 - Stay Puft camera lock-out fix + the logs that show why buttons / Quit Mission fail (built on 1.7.84)

## What you reported
- When dead: Quit Mission could not be pressed.
- The Stay Puft fight was not in VR.
- Controller buttons and sticks did nothing in game (laser clicks on the flat menus worked, hands were tracked).

## What the 1.7.84 report shows
- The camera rule for scripted scenes (a distant camera may stay in VR only if it follows the already verified player Ghostbuster) is the same code as in 1.7.70 and earlier: nothing in it was changed since the Stay Puft work. In your run it refused the scene at the moment the game walked the character (FORCEDMOVE) and the flat screen stayed up to the end of the log (about 11 s), with no line saying which of the four rules refused. The death screen was the same flat screen.
- The "verified player" was only refreshed while VR frames ran, so a player the game re-creates at a cut (a respawn / checkpoint load) kept the old object for the whole scene and was refused for good.
- In the same run the sticks and buttons worked for 8 minutes (snap turn, walking, stairs, trigger), so the "buttons do nothing" report is from a different run; the report from that run is needed.
- The quiet log hid every input and menu line (XINPUT, MENU click, POINTERMAP, HOOK xinput), so the death screen could not be diagnosed.

## Changes
- A follow target is now accepted as the player when nobody is verified yet, it is the verified object, or the old verified object no longer exists (the game re-created the player). Another LIVE Ghostbuster (a teammate in a cutscene) is still refused, so unrelated cutscene cameras stay on the flat screen. (`sceneview::same_player`, tested.)
- Every refusal now logs `SCENEVIEW refused #n (reason)`: pivot and camera distance, the camera's follow target and its class, the verified player and whether it still exists. First 40 changes of reason, then one line in 400.
- New `INPUTFLOW` log line: at the start of every flat screen, every 3 s while it stays up (40 at most), and in the 30-second summary. It says how often the game read the pad, whether the Quest controllers were tracked, which VR buttons were seen and which pad buttons were handed to the game, the biggest stick push, whether SteamVR gives the game the controller input, whether the game window is the active window, whether the flat screen / VR pages / hand-held menu are up, and the laser's moves / presses / releases / how many went to the game.
- The quiet (player) log now keeps: INPUTFLOW, HOOK xinput..., XINPUT, MENU, POINTERMAP, HELDMENU, CONTROLLERS tracked, CONTROLLERFAMILY.

## Not changed / not tested in the headset
- No change to the death screen itself: the cause is not visible in the old log. The INPUTFLOW lines of the next death screen will show whether the pad reaches the game and whether the laser clicks reach the menu.
- The camera fix only helps when the scene's refusal was the stale "verified player"; if the camera follows something that is not a Ghostbuster, or a different live one, the SCENEVIEW refused line will say so.
