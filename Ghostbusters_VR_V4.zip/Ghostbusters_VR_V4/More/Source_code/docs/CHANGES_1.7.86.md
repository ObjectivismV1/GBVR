# 1.7.86 HOTFIX - buttons / sticks do nothing in play (reports from Discord) (built on 1.7.85)

## What was reported
Players on Discord: the Quest controllers vibrate when a button is pressed, the hands are tracked and the flat menus can be clicked with the laser, but in play the buttons and sticks do nothing.

## What that tells
- The tick in the controller on a button press comes from the mod itself, so the mod sees the buttons. The break is between the mod and the game.
- The game reads the pad in play only while its own controller type is "gamepad". A fresh game starts on "mouse and keyboard" (the settings file of the test PC says gameControl=0), and the game's own setter refuses and puts "mouse and keyboard" back while the game has no pad connected. The mod switched the type through that setter, but at most 400 tries per session (two places, one try per 90 ticks): a player whose controllers were asleep for a while, or whose game fell back to mouse mode, could use up all tries and then never move again. Nothing in the quiet player log showed it.
- The XInput bridge (the mod's fake pad 0) only installed when the game's import slot held the plain export of xinput1_3.dll; if another program (Steam overlay / Steam Input, a controller remapper) already stood in that slot, the bridge was silently skipped and the pad never reached the game.

## Changes
- One routine keeps the game on gamepad: every 0.2 s it looks at the game's controller type; while the headset view is on, the controllers are tracked, a 3D picture is up (not a flat menu) and the type is "mouse and keyboard", it calls the game's setter, at most once per 1.2 s, with NO limit on the session. It runs on the game's thread from the game tick and from the binding update (the old second copy on the render thread is gone).
- Every try is counted and the first 12 (then every 50th) are logged as `CONTROLTYPE try #n ...` with the setter's answer and the type afterwards.
- The XInput bridge now installs even when another program already stands in the import slot: ours goes in front and calls it. `HOOK xinput ...` names that program's module. (Return 2 in the `[a b c]` of the HOOK line.)
- If the game keeps refusing (no pad connected for it) the tries slow down (1.2 s, then 5 s after 10 refusals, then 15 s after 40) so a stuck case does not hammer the game's setter; any success starts over.
- `INPUTFLOW` while one flat screen stays up: every 3 s for the first 8 lines, then every 15 s, 24 at most per flat screen, counted again at each new flat screen (so a long menu cannot use up the lines before a death screen).
- `INPUTFLOW` lines (1.7.85) now also carry the game's controller type and the number of switches / tries.
- TROUBLESHOOTING.md and the player README have a new line for "hands move, sticks and buttons do nothing".
- From 1.7.85: the Stay Puft scripted-camera lock-out fix and the refusal logs (`SCENEVIEW refused`), `INPUTFLOW`.

## Not tested in the headset
- These are the causes that fit the report; no log from an affected player was available. If it still happens, the report shows it: `CONTROLTYPE` says whether the game accepted gamepad mode, `INPUTFLOW` says whether the game reads the pad, whether the controllers are tracked, which buttons were seen and handed over, and whether SteamVR gives the game the controller input.
