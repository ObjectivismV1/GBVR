# 1.7.87 - checks and fixes for other Steam / SteamVR / Virtual Desktop setups (built on 1.7.86)

## Why
The mod was made and tested on one setup (Quest 3, Virtual Desktop, SteamVR 90 Hz, Windows 11, RTX 4080 SUPER, the Steam game). Other players have other Steam, SteamVR and Virtual Desktop settings. This version goes through what depends on those settings, fixes what can be fixed and makes the rest show up in the log in plain words.

## Already covered before (checked, unchanged)
- SteamVR not running / no headset / add-ons in safe mode / Oculus add-on errors: retries, `STEAMVR` log lines and plain hints (1.7.x).
- Refresh rate 72 / 80 / 90 / 120 Hz: work budget follows the headset's rate, `RATE`/`RATEFIT` lines; the game's desktop vsync is not waited for in VR.
- SteamVR render resolution / supersampling / motion smoothing: the mod uses its own picture size (from the game's picture level), so these only change SteamVR's own work. They are logged (`COMPOSITOR`).
- Standing vs seated floor level: head and hands are measured from the recenter point, so a wrong floor height does not move you.
- Steam Input / another program in the XInput slot: 1.7.86.
- Ultra-wide / 4K / 1080p monitors and Windows scaling: the picture follows the monitor's shape; the pointer is mapped to the picture (`POINTERMAP`).

## Changes
- **Index look-alike controllers.** Virtual Desktop can make a Quest look like a Valve Index ("Emulate Index Controllers", for finger tracking). A real Index has its thumb stick on axis 3; a look-alike may use axis 3 or axis 0. For an Index-type controller whose maker is not Valve the stick is now whichever of the two axes is pushed further, and a stick click on either axis' bit counts. Real Index, Windows MR, Vive wands and Touch-style controllers read exactly as before (tests prove it). `CONTROLLERFAMILY` now shows type|maker and says when it is a look-alike.
- **Graphics card check.** SteamVR says which graphics card the headset is on (adapter LUID); the game's own device must be on it. `ENVCHECK gpu` logs both and `ENVHINT` explains the Windows setting (ghost.exe > High performance) when they differ. Logged once, as soon as the game's device and the headset session both exist.
- **Setup facts in the log** (`ENVCHECK`): started from Steam or not (SteamAppId / SteamGameId), Steam Input virtual gamepad present (`SteamVirtualGamepadInfo`), Steam overlay loaded, window kind (window / borderless / maximised), client and window size, monitor size, Windows scaling (%), DPI-aware, Windows' own per-game graphics-card choice. `ENVHINT` says what to do when something is off (e.g. started without Steam).
- **No controllers for 25 s** logs one `ENVHINT` with the usual Quest / Virtual Desktop causes (asleep, hand tracking on, batteries).
- `INPUTFLOW` now also carries the largest push on each analog axis (0..4) per hand, so a dead stick can be traced to the axis a driver really uses.
- New log prefixes kept in the quiet player log: `ENVCHECK`, `ENVHINT`. Player README and TROUBLESHOOTING have a short "your settings" section and three new rows.
- New tests: `test_handaxis` (axis choice per family, look-alike detection) and `test_env` (graphics card relation, window kind, Windows scaling, Steam note).

## Not tested in the headset
- Nothing here was run on another PC. The Index look-alike rule follows SteamVR's documented axis layout, not a log from a Virtual Desktop in Index mode. The graphics-card check uses `IVRSystem::GetOutputDevice` as documented. If a report shows `ENVCHECK gpu ... DIFFERENT card` on a PC where VR works, the check is wrong and should be removed.
