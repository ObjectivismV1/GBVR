# 1.7.89 - the menu song is back in the download (built on 1.7.88)

- The song's creator (a YouTube creator) gave permission, so the Discord / public zip contains `bin/gbvr_menu_music.mp3` again. `PUBLIC=1 package.sh` now keeps the song and adds a MENU SONG note to the zip's README: used with permission, not covered by the mod's licence, delete the file for a silent menu. Only the internal play logs and hand-off PDF are left out of the public zip.
- The GitHub repository / kit still has no song file (permission was given for the download; add it there only if the creator agrees). Building from the repository with `PUBLIC=1` works without the song.
- No code change: the game is only silenced in menus when the song file is there (1.7.88), so installs with the song behave as before.
- Still to do: the creator's name for the credit line (the file has no tags, so the README says "the YouTube creator who made it").
