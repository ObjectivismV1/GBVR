# 1.7.90 - settings menu on the PC monitor, checks that really run (built on 1.7.89)

- The VR settings pages were only drawn in the headset; the PC window kept showing the frozen game. Now the same picture is drawn in the game window (centred, whole) while the pages are open (`monitorview_menu_present`, `vrmenu_picture`).
- The setup checks (`ENVCHECK window / graphics setting / steam later`), the module list and the sound probe (`AUDIO probe`, `AUDIO session`) were inside the full diagnostic dump, which the download never runs. They now run once about 15 s into the game (and the sound probe once more a few minutes in) in every build.
- Quiet log keeps every `AUDIO ` line (song ready / started / mute / given back), so a report shows whether the song played.
- The 1.7.89 report (Quest 3, RTX 4080 SUPER, one GPU, Steam Input on) showed a clean run: no stalls, controllers read, clean exit.
