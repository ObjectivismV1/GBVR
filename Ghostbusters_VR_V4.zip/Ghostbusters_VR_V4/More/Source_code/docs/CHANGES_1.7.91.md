# 1.7.91 - left stick does not walk (built on 1.7.90)

Report: a player on Galaxy XR + Virtual Desktop + SteamVR (shows up as Quest 3, Touch controllers): the right stick turns, the left stick does not walk.
- What the logs show: the controllers and both sticks are read correctly (left stick reached 100 % in the mod's pad) and the buttons arrive (the mod writes them into the game itself), but the game NEVER called XInputGetState (0 calls in every summary, while the owner's run shows ~850 calls per second). Walking is the one thing that needs the game to read the pad. Why the game does not poll on that PC is not known yet.
- New: import-slot guard. Every few seconds in play, if one of the game's three XInput import slots no longer holds the mod's function (another program replaced it), holds code, and the mod's function was not called, the mod puts its function back in front (never when its function is still being called, at most 8 times). Unit-tested decision (`pad::guard_should_repatch`).
- New logs: INPUTFLOW now ends with the game's own pad slots (state 0/2/12, DirectInput device pointers), capability asks and repairs; an ENVHINT line (once) when the game is in play with controllers tracked and has not read the pad for two reports, with the Steam Input advice.
- Not confirmed on hardware: whether the guard fixes that PC. The next report from the player decides.
