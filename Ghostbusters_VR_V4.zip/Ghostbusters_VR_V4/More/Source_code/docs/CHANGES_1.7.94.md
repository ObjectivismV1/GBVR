# 1.7.94 - Times Square "stuck after the sign is thrown" (built on 1.7.93)

Report: movement was fine until Stay Puft throws the sign in Times Square; from the same checkpoint the character then cannot move (the stick is pushed, aiming and firing still work). Still the same after the update, also after a height recalibration and seated mode. No log came with it.

What it can be (not confirmed - no log of the moment exists yet)
- The mod's knock-down comfort (1.7.36, on by default) does not call the game's `knockBack` (RVA 0xED100) at all; it starts a 3 s window of slow walking / dark edges instead. Read from the game's code: `knockBack(player, impactPoint, force)` ends the current weapon action, sets the fall flag and an impulse that points from the impact point THROUGH the player (the fall animation moves the player along it). For a thrown sign that lands on / next to the player this is what carries the player out of the landing spot. Skipped, the player stays where the debris collision now is: the stick is pushed, the body velocity is set, the position does not change, which is exactly what the 1.7.92 `STUCK` line is built to show.
- It fits the video (standing 15-25 s next to a truck while firing) and that it repeats from the same checkpoint. It is a hypothesis; the log decides.

Changes
- In a level with Stay Puft present (`fight_staypuft`) the comfort replacement is off: the game's own knock-back and fall are played, like `knock_comfort=0` there. Everywhere else the comfort window stays as before. (This costs the comfort window for knock-downs in that level; being unable to move costs more.)
- Rescue: when the `STUCK` watch fires (move stick >= 50 % for 2.5 s, position within 0.6 ft) and a knock-back was skipped within the last 2 minutes, that knock-back (impact point and force saved when it was skipped) is played on the game's thread via the consumer hook, and the comfort replacement stays off for the rest of the run (in memory only, `knock_comfort` in the settings file is not touched). At most 3 per run.
- Logs (kept in the quiet player log): `KNOCK knockBack #n` for each of the first 40 knock-backs of the player (impact point, distance, force, the game function that called it, Stay Puft level yes / no, comfort window or the game's fall), `KNOCK rescue #n`, and `STUCK knock info` right after each `STUCK` line (knock-backs sent / replaced, how long ago, rescue state).
- Quiet-log keep-list tests for the new lines (`tests/test_quietlog.cpp`).

Not changed
- The comfort window for ghost knock-downs outside Stay Puft levels, the setting `knock_comfort`, any other movement code.

Untested in a headset or in the level. If the player still cannot move: COLLECT_LOGS right after, the `STUCK`, `STUCK knock info` and `KNOCK knockBack` lines say what the world and the game were doing.
