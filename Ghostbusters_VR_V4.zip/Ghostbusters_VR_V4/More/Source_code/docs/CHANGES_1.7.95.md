# 1.7.95 - what the first Times Square log showed + LIFE log lines (built on 1.7.94)

The log from the player who was "stuck after the sign is thrown" (build 1.7.92, three tries from the same checkpoint) says:
- The controls work: the pad reaches the game (stick 100 % early in the level, sprint, no `STUCK` line, nothing in the mod zeroes the left stick).
- Try 1: the Stay Puft scene starts at 250 s, walking is fine until 262 s. Then three hits (273 s, 280 s, 286 s) take the player from 100 % to 1 % health in about 13 s. From 277 s to the game reset at 323 s the sticks are not pushed at all (biggest stick 38 % in a 30 s window, 0 % after that) while three more hits arrive: the player is knocked out, lying at 0-1 %. Try 2 ends at 0 % health 25 s after the scene starts, try 3 begins another scene and the player quits.
- Every hit in try 1 went through the knock-down comfort of 1.7.36 (the game's knock-back and fall skipped; 3 s of 45 % walk speed, 85 % dark edges, aim sway). In this level the hits come about every 7 s, so about half of the fight is spent slow and nearly blind and standing where the thing landed, with none of the game's own fall / get-up. That is what 1.7.94 already turns off in a level with Stay Puft (the boss was found at the start of every scene in this log).

So the reported "stuck" was most likely a knock-out, not a blocked stick. 1.7.94 should help; this log is from before it.

Changes
- New `LIFE` lines in the player log: when the player's health falls below 60 %, 30 %, 10 % and to about 0 %, and when it is back up: time, seconds since the step before, how many game knock-backs came in between, how many in all (comfort window / game's own fall), Stay Puft level yes / no. Needs the gun life bar on (default). Kept by the quiet log filter; test sample added.

Not changed
- Everything else (the 1.7.94 Stay Puft knock-back change and rescue are the same).

Untested in a headset. Next step is a log from 1.7.94 / 1.7.95 in the same level: the `LIFE` lines show whether the health still drains in a few hits and whether the player is stuck or knocked out.
