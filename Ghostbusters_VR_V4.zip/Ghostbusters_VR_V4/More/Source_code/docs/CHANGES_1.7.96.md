# 1.7.96 - Valve Index (first Index report) (built on 1.7.95)

Report (Valve Index + SteamVR, three runs): 1) no sound in the intro movies, 2) every button press buzzes very hard, 3) the buttons do not reach the game, the keyboard is needed to start it, 4) walking does not work, 5) F12 shrinks the game to a small screen above the hand.

What the log showed
- Stick: "largest push per analog axis" is axis 0 up to 1000 per mille on both hands and axis 3 always 0, in every run (and 190 s of play in the 1.7.80 run with the stick at 0 %). The mod read an Index stick from axis 3 only. SteamVR's own legacy bindings for this player put the stick on axis 0.
- Buttons: the only button ids ever seen were 1, 2 and the trigger (33). On an Index the OpenVR header names the A button "Grip" (id 2) and the B button "ApplicationMenu" (id 1), so the A button reached the mod as a grip press and never as A. Menus need A, the pad is ignored while the game is in mouse+keyboard mode, and the SteamVR laser never got a click (presses 0).
- Buzz: every new button press sends a 28 ms pulse of 40 % strength; an Index's actuators are much stronger than a Touch controller's for the same pulse.
- F12 is the hand-held menu (the flat game screen moves to the left hand, small, above it). It works as designed; F12 again, or B, puts it back.
- Sound: no AUDIO lines at all in the three logs. The sound check ran only after 900 3D frames, so a player who stays in the movies and menus never got one; the cause of the silent movies is not known.

Changes (all Index-only unless said)
- A REAL Valve Index whose axis 3 has never moved while axis 0 does reads the stick from axis 0 (stick click from either axis' bit). As soon as axis 3 has been pushed once, axis 0 (the trackpad) is ignored again, exactly as before. New `STICKAXIS` line (kept in the player log) says when this happened. Test: tests/test_handaxis.cpp.
- Outside a level (menus, loading) a grip press on a real Index is also given to the game as A (`INDEXA` line). In a level nothing changes: the grip keeps all its jobs. In a level an Index player still has no A button for the game's Interact; the `CONTROLLERS first press of button id` lines (now kept in the player log) will show what each physical button arrives as.
- Buzz: 30 % of the strength on a real Index. `haptic_pct` in the settings file still scales it.
- Sound check (`AUDIO probe` / `AUDIO session` lines: the PC's sound devices and every stream with its volume, the game's included) now also 15 s and 45 s after start, in any build, in the movies and menus; the old check after 900 3D frames stays.

Not changed
- Touch-style, Windows MR, Vive and Index look-alike (Virtual Desktop "Emulate Index") controllers; the squeeze of an Index (whatever it arrives as) is not remapped.

Untested on an Index. If A still does nothing in a level: COLLECT_LOGS after pressing A, B, the stick click and the squeeze one by one; the `CONTROLLERS first press` lines say what each is.
