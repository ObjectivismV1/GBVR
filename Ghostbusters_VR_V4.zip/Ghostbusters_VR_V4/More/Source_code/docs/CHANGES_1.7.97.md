# 1.7.97 - the gun hand takes hold and lets go (built on 1.7.96)

Report: "hand animation never got updated" (the other mod's hand closes on the gun / PKE and lets go; v5 deliberately changed no hand look). The report zip with it is a 1.7.92 (Beta v4) log, so it shows nothing about v5 or later.

What was there: the weapon hand's grip fingers were wrapped at once when the gun was drawn and open at once when it was holstered (one frame), the index follows the trigger, the left hand wraps the barrel by how far under the gun it is, the PKE keeps the game's own fingers.

Change
- The wrap amount of the gun hand's grip fingers is eased: about 100 ms closing, about 140 ms opening (`engine_hooks.cpp`, next to `t.gunWrap`). Nothing else about the hand or the gun's place changes. `HANDANIM t=..` lines (kept in the player log) give the time of each close / let-go so a video can be matched to the log.

Not changed / not known
- No draw or put-away motion of the gun itself (it already sits at the pack when holstered and the draw gesture starts at the pack), no new PKE hand animation (the game's fingers stay), no hand tracking.
- Untested in a headset. Which moment of the trailer still looks different (draw, put-away, PKE out / away, fingers while holding) is not known: a 20 s headset video of each plus the report gives the times to compare.
