# 1.7.99 - the game decides when you may hold the gun, the holstered gun lies in the pack (built on 1.7.98)

Requests: "don't let the player hold the blaster if the game would not allow it", "when the gun is holstered it goes through the VR model's chest - put it in the proton back", "when the game always gives the gun, don't automatically give it to the player - let them unholster it, but give a vibration to let them know it's allowed", "are you sure you're using my VR version, look at the flat version - how is the other VR mod getting hand animation", "keep this logic for all".

## Changes
- `gungatemath.h` (tests/test_gungate.cpp), setting `gun_wait_draw` (default 1, VR page Start: "I draw the gun myself"). The game allows a gun when a level runs, the character is not moved by force and the item in hand is a gun (proton, meson, boson, light, slime). Not allowed (between levels, a forced walk, nothing equipped for 0.4 s): the gun is put in the holster and the draw gesture is refused (`HOLSTER draw refused`). Allowed again for 0.5 s after not being allowed (the game GIVES the gun): it stays holstered, the right hand buzzes (0.9 strength, 260 ms), `HOLSTER gun ready`. The PKE or the trap in hand, and an unknown item, change nothing, so the PKE round trip is as before. A gun-to-gun switch never goes through the gate.
- Holstered gun in the pack: the gun was put at the pack's spot but kept the game's turn (barrel forward = through the body). It is now turned about its grip so the barrel points up and a little back (`HOLSTERPOSE` logs the spot and turn). `holster_on_back=0` still gives the old game spot.
- `gun_draw_anim` now defaults to 0 (settings revision 156): the report showed the game's gun-to-hand relation and finger bends do not move at a switch (index 125 / middle 170 / ring 166 / pinkie 144 always), and one stray 70.8 cm look.
- New log `HANDMOVE`: for 1.5 s after a weapon switch, the GAME's own right hand against the body, every 70 ms, with how far it moved. If the game moves its hand in a draw, this shows it.

## Not known / not done
- Untested in a headset. The turn of the holstered gun is a guess (barrel up, 20 degrees back); `HOLSTERPOSE` and a short video show how it sits.
- The 6-8 cm hand / gun gap (`GUNSLIP`, arm lengthened only to 120 %, so the arm stretch limit is not the cause) is not changed.
- The "item" reading: if it reads 0 for more than 0.4 s in a fight the gun is put away and must be drawn again; `HOLSTER gun put away` shows when it happened.
