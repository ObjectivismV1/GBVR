V4 update (1.7.224)
- Gun health bar: stays fixed on the gun while you walk and fire (it no longer follows the game's swaying gun). It also stops re-adjusting itself while you walk.
- PKE: your hand is turned much less to hold the meter, so it should look and feel more natural (setting pke_turn_max_deg, 25 by default).
- Boson Dart: the stream is let go for the game while you pull the left trigger (best guess, not proven). Setting dart_pause_stream = 0 turns it off.
- All untested in game. Send a short video plus COLLECT_LOGS if anything is off (new log lines: DARTPAUSE, GUNTUBE).

V4 update (1.7.223)
- Off-hand grip: the glove no longer creeps and twists round the barrel. It picks its position once when you take hold and then stays put unless your wrist gets uncomfortable.
- Boson Dart: the game is now always told "just pressed" at least once per left-trigger pull (before, it could miss it and only play the sound and effect). Not proven to be the whole cause.
- New DARTTRACE log lines record exactly what the game does on each left-trigger pull. If a dart still fails, play a bit, then run COLLECT_LOGS and send it (a short video helps too).

V4 update (1.7.222)
- Boson Dart fixed back: the left trigger goes to the game exactly as your controller gives it, like before 1.7.221. Nothing else about the darts changed.
- Still unexplained: darts that sometimes make the sound and effect but do not shoot. If it happens, run COLLECT_LOGS right after (DARTLT lines show each trigger pull).

V4 update (1.7.221)
- (1.7.221's Boson Dart change was wrong and is removed in 1.7.222.)
- Stay Puft roof view: the self re-centre now happens a couple of seconds after you settle (before it took about 30 s). It still fades to black for about 3 seconds when it does. roof_auto_center = 0 turns it off.
- Off hand on the gun barrel: fingers close a little tighter round it.
- If the dart still fails, the new DARTLT lines in COLLECT_LOGS show each trigger pull. A short video of the failing darts would help most.

V4 update (1.7.220)
- Off hand: when you grip the gun barrel, the hand now picks the way round the barrel that bends the wrist the least, so the glove should stop curling back over the barrel.
- Stay Puft roof fight: if your head is resting 12+ degrees off the boss, the view re-centres itself once (with the usual quick fade), so the straight-down view starts centred. Setting roof_auto_center = 0 turns it off.
- Untested in game. If the hand still curls or the view still feels off, send a short video plus COLLECT_LOGS (new lines: SCENELEFT "hand orbit", ROOFAUTO).

V4 update (1.7.219)
- Same play as 1.7.218. The log now proves the off-hand wrist limit and the roof head-movement fix are working (per-second numbers in the SCENELEFT and ROOFAIM lines).

V4 update (1.7.218)
- Stress-tested the last changes (off-hand wrist limit, roof head movement, roof view centring). Fixed: a lost headset reading could be taken as the roof view direction. Nothing else changed for play.

V4 update (1.7.217)
- Stay Puft roof fight: the forced-down view is now centred on Stay Puft and level even if your head was tipped steeply up or down when the fight started (before, that case could leave the view turned off-centre). New ROOFAIM log lines record how centred and level the view is.
- If the view still starts off-centre, recenter the view once (your usual recenter) after the fight begins. Untested in game.

V4 update (1.7.216)
- Stay Puft roof fight: your head movement (leaning, nodding, looking about) now follows the forced-down view, so your eyes should feel centred. Before, the picture was tilted down but your head movement was not.
- Untested in game.

V4 update (1.7.215)
- Off hand on the gun: the wrist can no longer fold back on the barrel (your video showed the glove bent back on top of it). The hand still swings from the wrist onto the barrel and stays on it. This also holds when the game forces your view down.
- Untested in game. New log line WRISTBEND shows the bend angle.

V4 update (1.7.214)
- Held hand: when you grip the gun with your off hand, the hand now swings from the wrist onto the barrel in one smooth turn and stays attached (it no longer curls back on the way).
- Untested in game; if it still looks wrong, send a short video.

V4 update (1.7.213)
- Hole in the neck when you look down: the hidden head now gathers at the top of the neck instead of being pulled down into the chest, so the neck skin closes over. Nothing is hidden or folded into the body.
- Untested in game: if you still see a hole or the neck looks stretched, send the report and a video looking straight down.

V4 update (1.7.212)
- Ghost trap: the trap is not touched. Only your off-hand glove is turned (about 30 degrees to the right, around the handle line) so the fist stays on the handle. Fist is the looser one from 1.7.211.
- Checked: all 107 tests pass, also with memory/undefined-behaviour checkers, and the new trap/look-down maths was tested over 200000 random hand poses.
- Not checked (needs you in the headset): which way the glove turns (flip if wrong), how the fist looks, the health tube, the right eye in the Stay Puft fight, the body when looking down.

V4 update (1.7.211)
- Health tube on the gun: now placed from where the game draws the gun, so it should stop floating. It falls back to the old way if the two disagree.
- Ghost trap: the off-hand glove is turned to the right while you hold the trap, and the fist is looser (less of a claw). The turn direction is my best reading of the code: if it turns the wrong way, tell me.
- Stay Puft fight: the right eye now gets a normal game step. This is a second guess; the first, in 1.7.209, did not fix it. The off hand no longer closes extra after taking hold of the gun.
- Body: when you hold a ghost and look down, the body now follows your head instead of staying turned away (that is why the pack and coat filled the view).
- All untested in game.

V4 update (1.7.210)
- Stay Puft fight: when your off hand holds the gun barrel it now sits round the barrel at the same distance as in normal play (palm on the barrel, fingers around it). Not a lock: the hand still follows your real hand along the barrel. With no grip held the hand is unchanged.
- Untested in game.

V4 update (1.7.209)
- Ghost trap: your off hand now makes a fist round the trap handle.
- Enemy health bars: an enemy you hurt keeps its bar for 10 seconds (big ones in the sewer were losing it). Untested in the sewer: no sewer log yet.
- Your own life tube on the gun is no longer cut away by your hands.
- Right eye missing in the Stay Puft fight / against walls: changed how the game decides what to draw for the right eye. This is my best guess, not proven. If it still happens, send the report: it now logs both eyes.
- Not changed: the off hand in the Stay Puft fight locks to the gun whenever you hold grip (the log shows 12 of 12); with grip released it floats free on purpose.

V4 update (1.7.208)
- Body centring now has room to move the body the full 10-14 cm under your head (1.7.207 only managed about half). Your view stays exactly where it was.
- Only improvements: nothing else was changed. Untested in game: how the arms and hose look with the body fully centred.

V4 update (1.7.207)
- Your body is now moved sideways toward the middle under your head (it sat 10-14 cm to the left). It moves as far as the hidden head can slide back, about 6 cm, so your view stays exactly where it was: expect it roughly half-centred, not fully.
- Arms and legs were checked in the code for left/right mistakes: none found.
- Untested in game: how the arms and the hose look with the body shifted. If anything looks wrong, send the COLLECT_LOGS zip.

V4 update (1.7.206)
- Stay Puft roof fight: the hose is hidden again, and your free hand no longer snaps to the gun by itself.
- Kitchen boss now gets a health bar (and the bar stays while you are hitting any boss).
- Not fixed yet / untested: gun "too far left", stairs scramble and the right eye losing the view model. I could not find the cause from the logs; this version records where the gun sits against your head (GUNVIEW) so the next one can fix it. The kitchen bar fix is untested in game.
- To help: play, then run COLLECT_LOGS and send the zip.

V4 update (1.7.205) - everything in 1.7.204 below, plus:
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play and get hit by normal ghosts and by bosses. Any hit the game would knock you down with (boss OR ghost) gives the same black edge, slower walk and slower arms for 4 s. A hit that only staggers does nothing.
3. Send the report zip. Look for KNOCKHIT: each hit is listed as boss/ghost, "knocks down" or "does not knock down", with the game's own numbers.
Honest limits: not tested in a headset. I read the game's own rule from its code (does the hit get a reaction at all, then a rotating counter), but I never saw a ghost hit knock the player down in any log, so KNOCKHIT will tell whether it happens at all. If a ghost knock-down you saw is not listed there as "knocks down", send the report and a short video.

V4 update (1.7.204) - everything in 1.7.203 below, plus:
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play. Check: (a) the hose from the pack to the gun is back, (b) a boss knock-down gives a clear steady BLACK edge for 4 s with slower walking/arms, (c) when you go down (health about 0) your view stays at standing height instead of dropping, lying and rising.
3. Send the report zip. Look for: KNOCKVIG summary, DOWNEYE, HOSEFLICK (bent should be above 0 now).
What I found in your 1.7.202 report: the hose was refused from the very first call of the session, not only after a level change. The game leaves junk in an unused column of the hose's bone matrices and my safety check refused every bone because of it. That check now ignores the unused column.
Honest limits: not tested in a headset. The downed fix is a guess from the log (I had no video): it only holds the eye height. If the "going down / lying / getting up" you see is something else (the body, the arms, a game camera), send a short video of it and I will match it frame by frame. The knock-down edge: if it is still not visible, the KNOCKVIG summary shows how strong it got.

V4 update (1.7.203) - everything in 1.7.202 below, plus:
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Pull the PKE out (twice: the first pull-out of a session learns the hold, later ones reuse it). It should no longer be dragged to one side before settling in your hand.
3. Send the report zip. Look for: PKEDRAG (how long after the pull-out the hand was tied to your controller).
Honest limits: not tested in a headset. In the 1.7.198 log the hand was only tied to the controller about 0.9 s after the pull-out, while the game's draw animation was still moving it; that is the drag. Now it is tied after 0.05 s (hold reused) or 0.25 s (first pull-out). If the PKE then sits twisted in the hand, the shorter wait caught it too early and I will lengthen it.

V4 update (1.7.202) - everything in 1.7.201 below, plus:
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play the Stay Puft roof fight: you should see ONLY your arms, the gun and the gun's hose. Nothing else (no flashlight, walkie-talkie, pack, belt).
3. Send the report zip. Look for: SUBMESH (every body part name and whether it was kept), SCENEPROPS (what got hidden).
Honest limits: not tested in a headset. The hide goes by the body parts' names, which I have never seen: if the flashlight / walkie-talkie are not separate body parts, or are named like an arm or torso piece, they stay. The SUBMESH lines will show. If no arm/torso-like name exists it hides nothing (so your arms cannot disappear by mistake).

V4 update (1.7.201) - everything in 1.7.200 below, plus:
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play. Check: only the boss hit that really knocks you down gives black edges + slower walk/arms (a boss hit that only staggers does nothing). Stay Puft roof: grab the gun with the left hand, the fingers should NOT curl round the barrel (they follow your own grip). Flashlight / walkie-talkie should be gone.
3. Send the report zip. Look for: KNOCKHIT (says "knocks down" or "only staggers"), SUBMESH (every body part name), SCENEPROPS.
Honest limits: not tested in a headset. The knock-down rule is read from the game's own code but the counter is mirrored, so it can drift from the game's real one. The prop hide works only if the flashlight / walkie-talkie are body parts with those kinds of names; SUBMESH tells me if not.

V4 update (1.7.200) - everything in 1.7.199 below, plus:
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play. Check: a boss knock-down gives BLACK edges, slower walking and clearly slower arms for 4 s (your setting was stuck at 3 s: fixed). Stay Puft roof: the free left hand should snap to the gun when it is near, without squeezing grip, and no curled fist; flashlight / walkie-talkie should be gone IF they are body parts named like that. Go back a level: look at the hose.
3. Send the report zip (COLLECT_LOGS). New lines to look at: KNOCKHIT, SUBMESH, SCENEKIDS, SCENEPROPS, SCENELEFT, HOSERELEARN, ROOFEYE.
Honest limits: not tested in a headset. NOT confirmed: flashlight / walkie-talkie (I do not know their names; SUBMESH will list them), the hose after a level change (this build only records WHY it fails), the right-eye glitch (logging only), and whether boss hits (types 0x6E/0x6F) are the knock-downs you mean.

V4 update (1.7.199)
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play: get hit hard by a boss (knock-down): edges should go dark/red, walking and arms slow for 4 s. Go back a level: the hose to the pack should be there. Stay Puft roof: the left hand should follow your own fingers (no curl).
3. Send the report zip. New lines: HOSERELEARN, SCENEOTHER. A short video of the roof with the flashlight / walkie-talkie helps a lot.
Honest limits: not tested in a headset. The flashlight / walkie-talkie are NOT fixed: they are not part of the player's body parts I hide, so SCENEOTHER will show if they are separate objects. The right-eye glitch in the roof fight is NOT fixed (no cause found in the log). The hose fix re-reads the hose after repeated refusals: a best guess.

V4 update (1.7.198) - everything in 1.7.197 below, plus: the trap is raised
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Take out the trap: the handle (below the trap's top end) should now be in your fist.
3. Not right? In gbvr_settings.txt change trap_hang_pct (now -30): lower (-60) = the trap sits higher, higher (0, 40) = lower. Tell me which way and I will set it.
Honest limit: I cannot see the trap model in the game, so the height is estimated from your old photo; not tested in a headset.

V4 update (1.7.197)
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play: die or get knocked down (no body should show, the edges pulse red), look at the health tube on the gun (locked, darker, brighter goo and heart), carry the trap (sits higher in the fist), go to the Stay Puft roof (free hand should snap to the gun from further away; look for the flashlight and walkie-talkie).
3. Send the report zip. New lines: DOWNED, SCENEGEAR, BODYCALM. A short video of the roof with the flashlight / walkie-talkie would help a lot.
Honest limits: not tested in a headset. The flashlight and walkie-talkie are NOT confirmed fixed: the report shows the roof fight body hiding works for the skeleton, so they come through another draw; SCENEGEAR logs which one. The tube lock and the trap height are best guesses (trap_hang_pct in gbvr_settings.txt: lower = higher). The dying view hides the body but the camera is still the game's.

V4 update (1.7.196)
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play. Hold a ghost in the beam and slam it: the body should no longer spin round (the chest stays within 30 degrees of your head). Get knocked down: you should walk slower, the gun should trail your hand and the edges go dark for 4 seconds.
3. Send the report zip: lines BODYCALM and KNOCKDOWN show what happened. A short video of a slam would help a lot.
Honest limits: not tested in a headset. The body fix is a best guess from the code (no log or video of a slam yet). The knock-down comfort never started in any report so far (no real knock-down in the runs), so it is still unproven in the game; its code and tests pass.

V4 update (1.7.195) - audited version of V1.3.49 (contains 1.3.47-1.3.49 below)
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play and get hit a few times, also in the Stay Puft fights; then send the report zip (HITREACT / EYEPAIR / KNOCK lines).
What the audit changed: a nearly dead player keeps the game's own reaction (so death / game over cannot be affected); the stuck rescue no longer fires in cutscenes; crosshair hide and trap hold hardened.
Honest limits: not tested in a headset. After a hit the game still has its own short stagger (about half a second of slowed movement) and the bosses' own hit animations - those are separate from what is skipped; the report will show if they still disturb you.
NOT done: right eye blank in the roof fight, PKE drag, missing roof ghost bars.

V1.3.49 update (1.7.194) - also contains V1.3.47 and V1.3.48 below
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play. Check: a ghost hit that does not knock you down plays no hit reaction on you (no push, gun stays put) but still costs health; a real knock-down plays no fall (slow walk, dark edges, light rumble); in the Stay Puft roof fight your off hand snaps to the gun again.
3. Send the report zip: lines HITREACT show each skipped hit reaction.
Not tested in a headset. This hit-reaction skip is a new hook on the game's own code (checked by its start bytes; if the game differs it stays off and logs that). If a hit ever leaves you stuck or the game acts odd, tell me - it is one switch to undo.
NOT done: the right eye blank in the roof fight (EYEPAIR lines will show), the PKE drag, missing roof ghost bars.

V1.3.48 update (1.7.193) - also contains everything in V1.3.47 below
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play. Check: the trap (hold X or the grip at the left hip) is held in your fist, higher, and turns with every twist of your wrist; walking over curbs, steps and stairs keeps the gun and view steady; the health tube stays on the gun while you walk.
Tested on the computer only (new walking / floor / stairs / object stress tests all pass; they found and fixed a small eye bob after a curb). Not tested in a headset.
NOT done: the right eye going blank in the roof fight (no cause found yet - the EYEPAIR lines in the next report will show it), the game's own small hit move (it is only slowed), the PKE drag, missing roof ghost bars.

V1.3.47 update (1.7.192)
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play. Check: no crosshair on screen; in the Stay Puft roof fight no flashlight / walkie-talkie and your off hand stays free; when a ghost hits you, you slow down, the edges go dark and the controllers rumble lightly.
3. If the right eye goes blank again, send the report zip: the new EYEPAIR lines show it.
Not tested in a headset. NOT done: the right-eye blank (no cause found yet, only logging added), the game's own small hit move (it is only slowed), the PKE drag, missing roof ghost bars.

V1.3.46 update (1.7.191)
1. Copy the new bin\d3d11.dll over the old one (or run the installer).
2. Play. Check: the health tube stays on the gun while you walk, the trap is held higher with its handle in your hand, and a knock-down never plays the fall (slow walk, dark edges, light rumble) - now in the whole game.
Not tested in a headset. NOT done: the game's small hit-reaction animation (I could not find it); the PKE drag and missing roof ghost bars are still open.

GHOSTBUSTERS: THE VIDEO GAME REMASTERED - VR MOD V1.3.45
=============================================================

V1.3.45 update (November 16):
- Stay Puft roof fight: you are no longer knocked down. A hit now gives you 3 seconds of: slower walking, black edges around your view, a light rumble in both controllers, and slower arms. You can still shoot. (The Times Square escort part is unchanged: the game's own fall plays there.)
- I think the knock-down in your video caused the tumbling view, the coat and chest radio showing, and the loose off hand, because it switched the arms-only view off. If so, those are gone now too.
- The dark "wings" under the arms in the roof fight are shorter (the hidden body is tucked up behind the shoulders).
- Not done: the hit reaction on the model that can make the gun float (I could not find where the game does it), and the health tube float (I saw no tube in this video).
- Not tested in a headset yet.

V1.3.44 update (November 15):
- New weapon wheel look, in the style of the health tube: smooth round letters, steel rims, dark glass with a glowing edge in each weapon's colour (blue = ready, green = in your hand, amber = switched off, red = not yours yet). The weapon you point at fills with glowing liquid.
- Opening, closing and moving between weapons is smooth: the letters and discs grow in instead of popping. I tested 1000 opening steps and 1000 random mixes on the computer; nothing jumps.
- Everything from V1.3.43 is still in (trap fix, trap handle, health tube).
- Not tested in a headset yet.

V1.3.43 update (November 15):
- Crash fixed (I think): throwing the trap could crash the game. The throw now happens between pictures, not in the middle of drawing one.
- The trap is turned half a turn: you hold it by the handle now. It is put back in your hand after every game step, so it should not flicker or float.
- The health tube on the gun is pinned to where the gun is drawn in the world, so it should stay on the gun.
- Still open: the PKE being dragged at the start (I found no cause in your report) and no health bar on the roof construction ghosts. The report now lists which ghost types the game uses there (ACTORKINDS), so I can fix it next time.
- Not tested in a headset yet.

V1.3.42 update (November 15):
- Epic Games Store support (not tested on an Epic copy yet: I have no Epic file). INSTALL_PROBE.cmd now finds the Epic copy of the game by itself.
- The mod checks the game's code when the game starts. If your Epic copy has the same code as the Steam one, the mod runs. If not, it stays off, the game runs normally, and the report tells me what moved.
- You still need SteamVR for the headset (Steam and SteamVR are free). Start the game from the Epic Launcher as usual.
- If it does not run: start the game once, run COLLECT_LOGS.cmd and send me the zip.

V1.3.41 update (November 15):
- Your whole body is drawn again in the whole game. Only the Stay Puft roof fight shows just the arms.
- Stay Puft roof fight: the fade back in takes 3 seconds now (setting scene_fade_ms; other fades are unchanged).
- Health tube on the gun: stress tested with fast swings and left-hand grabs. It stays on the gun to within a couple of millimetres and catches up in about 1/50 s after a grab.
- Stepping over an object: the held gun and PKE follow your eye height instead of jumping, and the body follows your eye further on a step. I could not see the cause in the report, so tell me if it still floats.
- Not tested in a headset yet.

V1.3.40 update (November 15):
- Fixed a mistake of mine in V1.3.39 (a line of default settings was cut off on a clean install; your saved settings hid it).
- Stay Puft roof fight: the black before the fight now lasts until the roof view is ready (it ended too early before).
- The health tube on the gun now follows the drawn gun on every game update, so it should stop trailing when you grab with the left hand.
- Still open: your legs, belt radio and trap show when you look down. The report now says whether the hide step runs.
- Not tested in a headset yet.

V1.3.39 update (November 15):
- Only your arms are drawn now: no chest, no gear on it (the grey box with the yellow light is gone). The gun and its hose are drawn as before.
- If the shoulders show odd stretched shapes, tell me. To bring the chest back, set arms_shoulders=1 and body_whole=1 in the settings file.
- The report now lists the body's bone names, so any other leftover can be hidden by name.
- Not tested in a headset yet.

V1.3.38 update (November 15):
- Stay Puft roof fight: no more wall view at the start. The picture goes black when the fight begins and fades up as soon as you are standing at the roof spot (2 seconds at most).
- Not tested in a headset yet.

V1.3.37 update (November 15):
- PKE: it is no longer pulled around when you take it out again. The mod now remembers how the game holds it and uses that straight away (before, it spent up to 6 seconds re-learning it).
- Hose: no more flicker when you swap between the gun and the PKE. It keeps its last shape for a moment instead of jumping.
- Trap: it now hangs from your fist like a case (grip end in your hand, body hanging down, flat side toward your palm).
- FPS limit list: the word "uneven" is gone.
- Not tested in a headset yet. The trap's flat side is a best guess - tell me which way it looks wrong.

V1.3.36 update (November 15):
- Floating hunt: the PKE no longer locks to your hand too early (it waits for real game updates), and the body size reading is steadier (it only learns while you stand normally, and a left/right switch keeps your size).
- Switching hands now clears the old hand's leftovers (gun easing, health tube, PKE drift, hip trap height).
- Left-handed: the gun hand, the free hand and the fingers are now drawn as a mirror of the right hand, and the PKE sits in the right spot. New log line MIRRORHAND.
- Not tested in a headset yet. Still open: health tube locked rigidly to the barrel.

V1.3.35 update (November 15):
- Every setting in the VR menu was checked one by one and the bugs found were fixed.
- Sprint 'off' now stays off. Buzz strength 0 also silences the menu click. Recenter waits 3 seconds and no longer twists the body. Measure height can no longer be left half-started or ruined by Seated play. The grab beam lets go when the ghost is gone. Ghost health Off now really turns it off. Comfort vignette is visible at 40-70. Smooth edges no longer switches itself off for good. The FPS limit marks uneven rates. Menu texts now match what the buttons do (including left-handed).
- Not tested in a headset yet.

V1.3.34 update (November 13):
- Fixed: your body, hands and the gun slowly shrank while you played (down to 94 %), which made the hands drift off the controllers. The size is now held steady.
- Not tested in a headset yet.

V1.3.33 update (November 13):
- Trap: you can no longer grab a new trap from your hip while one is still out on the ground (that is what made the trap fight your hand in left-handed play). Press X to call the old one back first.
- Gun health tube: it now stays locked to the gun instead of drifting behind it, and the metal around it is much darker.
- Gun weight is back (a little heavier to turn), and with ONE hand the gun is loose and sways again, even when you are not firing. Two hands keep it firm.
- Firing: your body is held still while the trigger is down, so the game's shooting animation no longer shakes the view.
Not tested in a headset. Seen in your log: your PC delivered 71 of 90 Hz, so the picture quality was lowered to level 3.

V1.3.32 update (November 13):
- Trap throw: checked against your last log. A plain X press already threw straight from your hand with no animation. The throw from the hip fell back to the old slow way when the hand position was briefly out of date; it now uses the instant throw then too.
- The throw now writes its result to the player log (TRAPDEPLOY lines), which was missing before.
Not tested in a headset.

V1.3.31 update (November 13):
- Gun health tube: sits lower, is darker and less glowy so it blends with the gun, and follows the gun more tightly.
- PKE: the first time you pull it out it no longer starts tangled (the hand turn is now saved a moment after the grip settles).
- Left-handed: the menu gesture now works beside your RIGHT ear, and the trap hangs on your RIGHT hip.
- Trap: held closer to your fist.
Not tested in a headset. Still open: the free hand's pose in left-handed play, and a fully rigid health tube.

V1.3.30 update (November 13):
- Trap: no more throw animation and no pause before each throw. The trap now leaves your off hand the moment you throw (or tap X), using the game's own throw. Your hand also closes round the trap while you hold it.
- Floating after switching (PKE <-> gun, weapon wheel, left-handed on/off): the gun and PKE hold is now taken only once it has been completely still for about a quarter second (before it could be taken while the item was still sliding into your hand and then stayed wrong). Switching hands or models now clears every old hold.
- Left-handed: fixed the left arm staying in the game's animation pose in some frames.
- Logs: new TRAPDEPLOY lines show what the game's throw returned. If the game refuses it three times, the mod switches back to the old way by itself.
Not tested in a headset yet. If something still floats, please send a video and say which switch caused it.

V1.3.29 update (November 13):
- Left-handed: your LEFT arm and hand now hold the gun, and your right arm follows your right controller (before, the game's right arm was just moved over).
- Trap button: fixed a mistake from V1.3.28 - pressing it while a trap is already out no longer moves that trap.
Not tested in a headset yet.

V1.3.28 update (November 12):
- Firing no longer shakes, kicks or lifts the gun in your hand. (Settings file: gun_fire_fx=1 brings it back.)
- Trap button: the trap now leaves from your off hand, and the game's throw animation no longer moves your body.
- Left-handed: elbows bend outward instead of into the chest; switching left-handed on or off now starts the gun and PKE grip fresh.
- Ghost health is a little more see-through.
Not tested in a headset yet.

V1.3.27 update (November 12): a recheck and stress test of the last two versions. No new features.
- Left-handed: fixed a bug where the arms could cross again (sometimes in one eye only).
- FPS limit: 50 / 60 / 72 / 80 now hold their number better on a PC that sometimes drops a frame, and can no longer make the mod lower your resolution by mistake.
- Gun health tube: steadier, and it can no longer get stuck away from the gun.
- PKE / gun: the "stay in the hand through a short gap" fix is more reliable, and the log now shows how often it is used.
Not tested in a headset yet.

V1.3.26 update (November 12):
- Ghost health circle, vial and bar are see-through now (55%) and the circle is thinner, so you can see the ghost through them. Your saved setting is updated once; change it any time with hbar_alpha_pct (15-100).
Not tested in a headset yet.

V1.3.25 update (November 12):
- Circle health is back: with "ring" chosen in the options the ring shows again (the vial was covering it).
- Gun health tube no longer bounces or floats off when you move or turn your hand.
- Floating: the gun and PKE stay in your hand through short gaps (up to 1 second) instead of dropping to where the game holds them; the PKE no longer floats away when you use the goggles.
- Left-handed: the arms no longer cross your body. Note: the game only has a right-hand gun grip, so you see the game's right hand on your left side.
- FPS limit: 50, 60, 72, 80 etc. now really work on a 90 Hz headset (before only 45 did). Half your headset's rate (45 on 90 Hz) is still the smoothest.
Not tested in a headset yet.

V1.3.24 update (November 11):
- Stay Puft rooftop: the stream no longer comes out of the gun sideways and kinks - it goes from the gun to where the game sends it.
- Stay Puft rooftop: your shoulders no longer fill the bottom of the view.
Not tested in a headset yet.

V1.3.23 update (November 11): looking down no longer shows the top of your own shoulders, collar and neck - the body slides back as you look down so you see your chest and legs. Setting body_down_back_cm (0 = off). Not tested in a headset yet.

V1.3.22 update (November 11):
- Gun health tube now sits on top of the gun you see (it follows the drawn gun, not just the controller).
- Your hands now cover the tube when they are in front of it (no more seeing it through your hand).
- Your body's chest turns toward your hands as well as your head, so it follows you better.
Not tested in a headset yet.

V1.3.21 update (November 11):
- Ghost trap: held below your fist like a case by its handle, and when thrown it flies from your hand (no more freeze at your side).
- If the controllers lose tracking for a moment, the game no longer pauses with its controller screen.
- Gun health liquid is much calmer (no more jumpy, flickering surface).
- Looking down / extra body: new data in the log (BODYDOWN) - please send a report after looking down for a few seconds.
Not tested in a headset yet.

V1.3.20 update (November 11): in big crowded fights the ghosts' health could all vanish at once - now the farthest are left out and the nearest always show. Left-handed players: the gun's health tube moves to the side facing you. Not tested in a headset yet.

V1.3.19 update (November 11): boss health checked for every boss. Bosses keep their own fixed health size (1.3.18 made them too big) and a calm follow (no overshoot when you look around them). Normal ghosts keep the new tight fit and follow. Not tested in a headset yet.

V1.3.18 update (November 11): ghost health vial and ring now stay on a moving ghost (no trailing behind) and fit the ghost's size; rounder, smoother shapes on the vial, ring and gun tube; the gun's liquid sloshes calmer and smoother. Not tested in a headset yet.

V1.3.17 update (November 11): the liquid in the gun's health tube now sloshes with the gun - it stays level when you tilt, swings back when you move fast, then settles. The ghosts' health vials stay still. Setting gun_hp_physics=0 turns it off. Not tested in a headset yet.

V1.3.16 update (November 11):
- Gun health tube now looks like a real part of the gun: metal channel, straps, screws, smoked glass, softer liquid, and the heart is an indicator lamp that pulses.
- 2D ambient light: menus no longer glow blue or show the last cutscene's colours; the light now takes the real colours of what is on screen, and keeps up with cutscene shots.
Not tested in a headset yet.

V1.3.15 update (November 11): Stay Puft's health vial on the rooftop fight was a thin line (he is far away); it now stays a readable size. The rest of the rooftop fight was checked against all new features. Not tested in a headset yet.

V1.3.14 update (November 10): the PKE is now put exactly on your controller (the 1.3.13 version moved it by the wrong amount). Not tested in a headset yet.

V1.3.13 update (November 10):
- Ghost health is now a glowing liquid vial too (green > yellow > red, drains, sloshes when hit). Menu/settings: ghost_hp_liquid=0 brings the old bar back.
- The PKE now sits centred on your controller (before it hung about 9 cm below it). pke_centre=0 is the old look.
- FPS limit: Off, or 45 / 50 / 60 / 72 / 80 / 90 / 100 / 120. Each click only stops on numbers that really change things on your headset, and the menu shows what you get.
Not tested in a headset yet - please report what you see.

V1.3.12 update (November 10) - the life bar on the gun, redone:
- It is now a small glass tube of glowing liquid with a heart at the end nearest you (same place on the gun as before).
- The liquid is slime green when you are well and turns yellow, amber and red as it drains toward the heart. Its surface moves, a few bubbles drift in it and a strip of light runs along the top.
- When you are hit, the part you just lost flashes pale for a moment and the surface sloshes, then it settles. Healing rises gently.
- The heart beats: calmly at full health, fast when you are nearly out (the liquid then throbs with it), and it stops and turns grey at zero.
- gun_hp_liquid=0 in the settings file gives the old plain strip back; gun_hp_bar=0 switches the bar off.
Not tested in a headset yet (looked at here as a computer-drawn picture only).

V1.3.11 update (November 10) - a full check of everything that can take the gun or the PKE out of your hand:
- FOUND AND FIXED: when a ghost hit you in a fight and the game shoved your character for more than half a second, the mod handed your body, arms and gun to the game's own animation for about two seconds. The gun left your hand and the body left your arms - right in the middle of firing. The same happened at every cut in a cutscene and could happen at a stutter while sprinting. An older version of the mod already protected against this; a later change removed the protection. Now nothing short of the game walking your character for more than 6 seconds takes the gun, arms or body.
- A stutter while running or sprinting is no longer mistaken for a "jump" of the character.
- New in the log: every time the gun is not placed in your hand for more than 0.3 seconds, the log says for how long and exactly why (GUNOUT lines).
- Checked and left as they are (the test log shows them working): the PKE's lock to the hand (8.7 cm from the grip on every check while it was out), the gun's lock to the drawn hand, the hose, the holster rules.
- Not explained yet: in the test log the game did not ask the mod to place the gun for 9.5 seconds during one two-handed hold, with no reason written down. The new GUNOUT line will name the reason next time.
Not tested in a headset yet.

V1.3.10 update (November 10) - from a play test on a Quest 3:
- The gun has weight again, and firing with ONE hand is punished again: the muzzle climbs, shakes and kicks, more the longer the burst; with two hands it stays steady. An older clean-up had switched all of this off by mistake. The weight is a turn of the gun and hand together about the grip: the grip itself never leaves your hand. (gun_heft_pct and gun_punish_pct in the settings file; 0 = off.)
- FPS limit: the menu now shows what you really get on your headset (for example "Half rate = 48 FPS", "60 -> 48 FPS", "90: no limit at 96 Hz"). The test log shows the limiter itself working as designed.
- Smooth edges: with it on, the comfort vignette was not drawn. Fixed.
- Still open: "a view model overlapping another" and "the gun floats out of the hand when fired". The log of that test shows the gun locked in the hand, so more was added to the log (FIREGUN lines). A short video of both would help most.
Not tested in a headset yet.

V1.3.9 update (November 10) - the new options checked for every headset rate (60, 72, 75, 80, 90, 100, 120, 144, 165 Hz and anything between):
- FPS limit has two new choices that fit EVERY headset: "Half rate" (a new picture on every 2nd headset frame) and "A third" (every 3rd). Use Half rate if you do not know your headset's rate.
- A number (30 ... 120) is now fitted to your headset: it becomes the nearest whole step of your headset's rate that is not more than 10 % over the number (on a 75 Hz headset "36" = 37.5, on 144 Hz "72" = 72, on 90 Hz "60" = 45).
- If a headset driver does not report its rate, a number still works (plain timer); Half rate / A third then do nothing and the log says so.
- The fade through black at a cutscene jump now also works at low frame rates.
- Stress tests widened: FPS limit over headset rates 50-240 Hz, cutscene logic at 15-240 FPS.
Not tested in a headset yet. The Smooth edges option depends on the graphics card; it switches itself off if a card cannot do it.

V1.3.8 update (November 10) - two new options in the VR menu > View, both OFF until you switch them on:
- FPS limit: Off / Half rate / A third / 30 / 36 / 40 / 45 / 60 / 72 / 80 / 90 / 120. If the game is choppy or uneven, choose Half rate. The game then shows a steady new picture on every 2nd headset frame and SteamVR / Virtual Desktop fill in the rest - usually much smoother than an uneven 55-75. The limit is locked to the headset's own frames; a value that does not divide your headset's rate is rounded down to one that does. Works at once, no restart.
- Smooth edges (anti-aliasing): smooths jagged, shimmering edges in the headset and lightly re-sharpens the picture (strength: eye_aa_sharp_pct in the settings file, 0-100, default 25). Costs a little speed. If your graphics card cannot do it, it switches itself off and the picture is as before.
- DLSS / FSR 2 are not possible in this mod: they need motion and depth data from inside the game's renderer, which the mod does not get. For a sharper picture use Resolution (same menu page) and your headset software's own sharpening.
- Speed: nothing in the game's own drawing was changed. The ways to get more speed are Resolution (press -) and the FPS limit.
Not tested in a headset yet.

V1.3.7 update (November 10) - a logic check of V1.3.6, with these corrections:
- The 2-second cutscene wait now only happens after the 2D screen has really been up (3D gone for 2 seconds or more). A short camera blip in the middle of play, the pause menu, or the headset losing tracking for a moment: 3D is back at once as before.
- Only the move stick ends the wait early. The trigger no longer does: on the 2D screen the trigger is a click, and people use it to skip cutscenes.
- The fade through black now happens at every jump when a cutscene cuts several times in a row (V1.3.6 only faded at the first), and never for a stutter while running.
- While a shot is kept on the 2D screen the mod no longer asks the game to turn your body toward your head.
- Corner glow: one bad frame from SteamVR is tried again (3 in a row before the single glow takes over); the four layers have a fixed drawing order.
Not tested in a headset yet.

V1.3.6 update (November 10):
- In-game cutscenes: between a cutscene's shots the game is back on the play camera for a second or less. The mod used to throw you into 3D inside the character for that moment and then back to the 2D screen - 2D, 3D somewhere else, 2D again. Now, once the 2D screen is up, 3D only comes back when the play camera has lasted 2 seconds without a break; short shots stay on the 2D screen. Push the move stick and 3D is back at once; no wait after the pause menu. (cut_hold_ms in the settings file, 0 = as before.)
- When the game moves your character to another place while you are in 3D, the picture now goes through black for a moment instead of lurching (cut_fade, 0 = off).
- 2D screen glow: the light around the screen now takes the colours of the picture's four corners (a red corner glows red) and follows the picture within a second or two. If SteamVR refuses the extra layers the old single glow is used. (flat_glow_corners, 0 = the old single glow.)
- Rechecked: all tests of the earlier fixes still pass; nothing else was changed.
Not tested in a headset yet.

V1.3.5 update (November 9) - a full recheck and stress test of the last updates:
- Hose: stays visible when the PKE is out (the game used to hide it then), follows the gun even when the body-follow setting is off, is never pulled toward the PKE, and its stretch is now shared evenly along its length instead of bunching in the middle. Stress-tested for 60,000 frames.
- Twisted forearm: the earlier fix could, after one tracking glitch, leave the forearm twisted until you turned your hand all the way round. It now has nothing to remember, so it cannot get stuck.
- PC monitor: the VR settings are always a panel over the game picture (also when the monitor view setting is off).
Not tested in a headset yet.

V1.3.4 update (November 9):
- Proton hose: the game's OWN hose is always shown, running from the pack to the gun. Its gun end follows the gun in your hand (and the holstered gun), the pack end stays on the pack, and the game's own hose animation (its sway) is kept. The mod's home-made cord is off, and the mod never hides the hose (only the hose_off setting does). In cutscenes, and whenever the game itself places the gun, the hose is exactly as the game animates it.
- Grabbing: the fingers now roll in from the index to the little finger when you squeeze (and let go the other way round), instead of all closing at once.
Not tested in a headset yet.

V1.3.2 update (November 9):
- Gun and PKE LOCKED to your hand: both are now drawn on the hand you see, every frame. Before, the gun sat on your controller through a stored hand offset, and the PKE was rebuilt from your controller most of the time; when that offset was off, they floated above the hand.
- If you notice the gun lagging a little behind very fast swings, that is the hand itself catching up; the gun stays in it.
Not tested in a headset yet.

V1.3.1 update (November 9):
- Twisted hand / forearm fixed: when you turned your hand far (palm up, the left hand under the gun) the forearm could spin half a turn in one frame and the arm looked twisted up. The forearm now turns smoothly with the hand and never more than a real forearm would.
- The log now records how far each arm reaches, so reports of a gun or PKE above the hand can be pinned down.
Not tested in a headset yet.

V1.3 update (November 6) - everything new since V1.1:
- Gun and PKE stay in your hand: they no longer float away from your hand the longer you play. Whenever your drawn hand and the gun/PKE stay more than about 3 cm apart while you hold still, they ease back into the hand within about half a second. Fast swings, shaky tracking and walking are handled (stress-tested in a 2-hour simulation).
- Joystick / HOTAS / wheel no longer blocks moving: if one of these was plugged in, the game read it as your controller and the left stick did nothing. The mod now closes that device for the game while the VR controllers are on. You no longer need to unplug it; it still works in other programs.
- No crash when the game is started outside Steam (desktop shortcut to ghost.exe, a VR launcher): the first achievement used to crash the game. The mod now skips it. Best: start the game with Play in Steam, then achievements work too.
- Seated play: "Measure my height" no longer accepts a sitting head height (it shrank the world and threw the hand and PKE sizes off). Stand up to measure, or leave the size alone.
- Stay Puft's health ring no longer sits on his chest during the Times Square escort while he walks far ahead. It shows when he is close, when you hit him, or when the real fight starts.
- Streaming / recording: when you open the VR settings, the PC monitor keeps showing the game and the menu appears as a panel in the middle (with the pointer dot), so people watching see how it works in the game. Before, the menu covered the whole monitor.
- After two crashes in a row the mod turns body features off for ONE run to stay safe (you then see through the character's head); one clean exit brings everything back.
Not tested in a headset yet.

V1.1 update (October 31): A newly drawn PKE resets its stored grip after a half-second absence so a previous hold cannot shift it after stowing or a scene transition. Enemy health bars and circular health markers share a lightly smoothed world anchor; the headset stays responsive and large enemy teleports snap immediately. The neck remains under the hidden head to cover the deep opening at the collar. The grab input now writes a clear diagnostic when the right stick is clicked. No control was remapped. These changes passed host checks; headset verification is pending.

V1.1 update: PKE scan assistance now preserves the game's own aim score when it is better than the controller-to-target-origin estimate. This prevents the helper from rejecting valid native scan points, including offset story targets. The architect drafting-room progression report still needs a headset retest; this is not a confirmed fix for that scene.

Player health update: The player-health strip now stays with proton, meson, boson and slime guns, including brief placement gaps between shots. It remains hidden for the PKE, trap, light and holstered gun. The earlier enemy-health improvement remains. All 80 host tests pass; in-game checks across firing styles are pending.

Weapon support update: Changing firing style or weapon geometry now clears the old offhand grip blend, then eases the support hand onto the new weapon pose. Right-hand tracking, firing controls, health updates, walking comfort and reload effects remain included. Host tests pass; test weapon switches in a headset.

Enemy health update: Health displays now recognize cumulative small damage ticks from other firing modes, while keeping the existing clear-wall, active-enemy and trap checks. The previously fixed walking camera and PKE behavior remain included. All 80 host tests pass; every weapon still needs in-game confirmation.

Walking comfort update: Walking camera height smooths small alternating floor seams while preserving steps, jumps, movement and PKE control. A teleport or actor change clears the height filter. All 80 host tests pass; in-game comfort and PKE animation need headset confirmation.

Full-body view update: Full body remains visible when looking down. The head is hidden while the neck remains to cover the opening at the collar; the result needs an in-game check after cutscenes. Existing body-turn, limb, reload sounds and steam behavior retained. Host regression tests and build checked; in-game confirmation pending.

Documentation reviewed 2026-10-31. V1.1 includes the PKE grip refresh and health-marker stability updates. Head-following flashlight and a trigger-near-head light toggle are NOT implemented in this build. Use the game's existing light selection/control; do not expect the new gesture yet. See CURRENT STATUS and the guide.



An unofficial fan-made VR mod for the Steam version of the game. Not made by, or connected to, the game's makers or publisher.
You need to own the game. This download contains no game files.

WHAT YOU NEED
- Windows 10 or 11, a PC that runs the game well (the mod draws the game twice, once per eye).
- The Steam version of "Ghostbusters: The Video Game Remastered", installed and started once without the mod.
- SteamVR (free, in Steam under Library > Tools) and a headset that works in it.
  Made and played on a Quest 3 through Virtual Desktop at 90 Hz. Other headsets / Air Link / Steam Link should work but are not tested.
  The mod talks to SteamVR ONLY (OpenVR). It does not use OpenXR, so the headset's own OpenXR runtime (Meta, Virtual Desktop's VDXR, Pico, WMR) does not matter and nothing is needed
  there - but SteamVR must be installed and running whatever headset or connection you use. How each headset reaches SteamVR:
    Quest (Virtual Desktop)     start Virtual Desktop, connect, then pick SteamVR in its menu (not VDXR / not the Oculus-only mode).
    Quest (Air Link / Link)     Meta Quest Link app on the PC, connect the headset, then start SteamVR (Link > Settings > General: allow "Unknown sources" if SteamVR asks).
    Quest (Steam Link / ALVR)   connect, SteamVR starts with it.
    Valve Index, Vive, Pimax    start SteamVR (Pimax: also turn on "Parallel Projections" in the Pimax software).
    Windows Mixed Reality       install "Windows Mixed Reality for SteamVR" in Steam, then start SteamVR.
    Pico                        Pico Connect or Streaming Assistant, then SteamVR.   Steam Frame / Galaxy XR: stream to the PC, SteamVR on the PC.
  Not supported: playing without SteamVR (OpenXR-only setups such as the Meta runtime alone). The game then just stays flat on the monitor; the log says why.
- Touch-style controllers (two thumbsticks, trigger, grip, A/B/X/Y) are what it was made on. Valve Index, Vive wands and Windows MR controllers have a layout of their own in V1.1 (untested on real hardware, see the notes below).
  Steam Frame: SteamVR gives the game the Touch layout, so the Frame's D-pad buttons act as the face buttons (left D-pad down = X trap, left D-pad left / up / right = Y,
  right X / Y / B = B) and the bumpers act as extra triggers. Playing the game on your PC and streaming it to the Frame (Steam Link) is the setup this mod is built for; running the Windows game on the Frame itself is untested.

- Offhand support: place the free hand by the drawn gun and squeeze its grip to steer/support the beam. Letting go releases aim support even when the hand remains nearby. The visual support pose follows the current weapon geometry and resets smoothly after a firing-style change. Some controllers expose a grip button rather than an analog squeeze. fore_grab=0 disables the support hand feature. (Older proximity behavior described in the history below is superseded.)

CURRENT STATUS
- V1.1; documentation reviewed 2026-10-31. No control mapping or flashlight feature was added.
- The flashlight currently follows its existing game/mod placement. Head-directed beam and trigger-near-head toggling have not been implemented or validated. Trigger near the right shoulder plus grip still holsters/draws the gun; trigger in the left-hand menu still clicks.
- Player health is on the drawn proton, meson, boson, and slime gun, including short between-shot placement gaps. It is hidden on PKE, trap, light, and holstered gear. Enemy health is a separate display subject to visibility, spawn and damage checks.
- Reload keeps the game's sound and steam effects. The viewmodel reload hold is render-only; in-game confirmation remains pending.
- PKE positioning, grab-beam response, close-range scanning and Hotel entry crashes have been reported; this build does not establish that either is fully resolved. Send a fresh COLLECT_LOGS.cmd report and a short video if they recur.

HONEST STATUS
- This is an experimental hobby mod, updated often. It has bugs. Expect to report some.
- Only the Steam game build it was made for is supported. The installer checks this and says so if your game is different.
- Linux / Steam Deck: the install scripts are tested, the mod inside Proton is not. See linux/README_LINUX.txt.
- The mod only adds files next to the game.exe and turns off the game's 30 / 60 FPS limit in its settings.ini (a backup is kept).
  It does not change the game's own files or your saves. REMOVE_PROBE.cmd puts everything back.
- Antivirus: the mod is a d3d11.dll that hooks the game (that is how every graphics mod works), so a virus scanner may warn about it.
  It is not a virus. The full source is in the "source" folder and can be built yourself (source\README_BUILD_1.7.120.txt).
  VERSION.txt lists the SHA-256 fingerprint of each installed file.

INSTALL (Windows, about 2 minutes)
1. Unzip the whole zip to a normal folder (right-click the zip > Extract All). Do NOT run anything from inside the zip.
2. Close the game if it is running.
3. Double-click INSTALL_PROBE.cmd.
   - If Windows says "Windows protected your PC": click "More info", then "Run anyway".
   - It finds the game by itself (Steam, any library drive). If it cannot, it asks you for the game folder:
     in Steam right-click the game > Manage > Browse local files, copy the address-bar path and paste it.
   - If it asks for administrator permission, say yes (the game folder needs it).
   - It backs up anything it replaces, and prints NEXT STEPS when it is done.
4. Put the headset on, start SteamVR (Quest: Virtual Desktop / Air Link / Steam Link first), then start the game from Steam.
   VR starts by itself.

UPDATE: unzip the new version and run its INSTALL_PROBE.cmd again. It replaces the old one by itself. Your settings are kept.
REMOVE: double-click REMOVE_PROBE.cmd. CHECK_INSTALL.cmd shows what is installed and anything that looks wrong.
If the installer says "not enough space on the disk": free a few hundred MB on the drive it names and run it again.

YOUR SETTINGS (Steam, SteamVR, Virtual Desktop) - what the mod needs, what does not matter
- Start the game with Play in Steam. Steam Input on or off both work. If sticks / buttons do nothing, try Steam > the game > Properties > Controller > Disable Steam Input.
- SteamVR running and the headset connected BEFORE the game starts. SteamVR's render resolution / supersampling and motion smoothing do not matter to the mod (it picks its own picture size).
- Virtual Desktop: 90 Hz is what it was made on (72 / 80 / 120 Hz should work but are untested). Use the controllers, not hand tracking. "Emulate Index controllers" can stay off; if you turn it on the mod now finds the stick by itself (untested).
  The LEFT Menu button belongs to Virtual Desktop, the mod does not use it.
- Game choppy or too slow (laptops, older cards)? Lower the Resolution: F12 > VR SETTINGS > View > Resolution, press - once or twice, restart the game. Also lower Virtual Desktop's graphics quality and use 72 Hz.
- Two graphics cards (most gaming laptops): Windows Settings > System > Display > Graphics > add ghost.exe > Options > High performance, and the same card for SteamVR. Otherwise the headset stays black.
- Windows display scaling, monitor size and windowed / full screen should not matter. The mod writes what it finds to its log (lines ENVCHECK and ENVHINT) so a report shows it.

PLAYER_GUIDE.pdf lists the current controls and the flashlight limitation. The detailed historical notes below describe older releases; the current controls and status above take precedence.

CONTROLS (Quest / Touch controllers, right-handed; VR settings > Play > Left-handed swaps the hands)
Move and look
- Walk: left stick. Sprint: click the left stick (click again to stop; VR settings > Play can make it hold-to-sprint).
- Turn: flick the right stick left or right (snap turn). SMOOTH turn: VR settings (F12 > VR SETTINGS) > Play > Snap turn off, then hold the right stick sideways.
- Jump: B (right). Interact (open, pick up, revive, use): tap A (right).
- Crouch: duck down in real life. Look around, lean and walk around the room for real; your body follows.
Fight (the gun is in your right hand)
- Fire: right trigger. Alternate fire (every weapon): left trigger. With the PKE meter out the right trigger scans.
- Steady aim / two-hand aim: put the left hand next to the drawn gun and hold the left grip. Release grip to return to one-hand aim. Works from SteamVR grip input across layouts; actual hardware checks are still needed.
- Capture / wrangle a ghost: click the right stick (VR settings > Play > "Grab beam: click on, click off" makes it one click to grab, one to let go). Hold the grab, then squeeze the LEFT trigger all the way = slam.
- Ghost trap: press X (left). Hold your left hand at your left hip to take the trap in your hand, swing out and let go to throw it.
Gear
- Weapon wheel: hold A (right), push the right stick toward a weapon, let go.
- PKE meter: tap Y (left) to take it out, tap again to put it away.
- Vent the pack (overheat): put a hand over your shoulder and squeeze a grip. Reload sound and steam remain active.
- Flashlight: this version does not provide head-following aim or trigger-near-head light toggle. Use only the existing in-game light selection/control; no new flashlight binding is assigned.
- Put the gun on your back / take it again: right hand over your right shoulder, squeeze trigger AND grip together (the hand buzzes). The game decides when a gun may be held: in cut-scenes it goes on your back by itself and is back in your hand afterwards if you had it out. Your first gun of a session starts in your hand.
- D-pad (choose a gadget, select): HOLD Y (left), then the right stick = D-pad, right stick click = vent, right B = HUD on / off, right A = select / back. Also: left grip held with the left hand held away from the gun + right stick = D-pad.
Menu
- Open / close: left hand beside your left ear, squeeze the left grip, hold still half a second (or F12 on the keyboard). It opens the game's own pause menu in your left hand: point with the right hand, trigger = click, right stick = scroll, A = close.
- VR SETTINGS (the button at the bottom of that menu) has four pages: Start (measure / reset height, recenter, objectives), Play (turn, sprint, left-handed, seated, grab beam, comfort vignette), View (ghost health ring or bars, game HUD, Resolution, buzz strength) and Help. Everything you change is saved at once. Hold - or + to change fast.
Keyboard (game window)
- F4 = headset view on / off, F9 = recenter, Ctrl+F9 = measure my height, F12 = menu.
Other controllers (V1.1 layout; individual hardware mappings need confirmation - report discrepancies)
- Pico, Rift S, Focus 3, Steam Frame: same as Quest.
- Valve Index: use the thumbstick, not the trackpad. A (Interact) = a QUICK tap of the right grip; left A = X (trap), left B = Y (PKE). Pushing the stick to the edge is not a click.
- Vive wands: the trackpad is the stick; click the LOWER part of the pad = A (right: interact / wheel, left: trap), click elsewhere = stick click; the menu button is B / Y.
- Windows Mixed Reality: the stick is read from the right input; clicking the trackpad = A.
- Anything else: the stick is found automatically. If it is wrong, controller_layout / stick_axis in gbvr_settings.txt can force it.

FIRST TIME
- Settings > Start > Measure my height (stand straight, look ahead). Reset my height puts it back.
- Seated play and Left-handed are on the Play page. Not sure about motion? Try Comfort vignette 40 to 70 and smooth turn off (snap).
- Everything you change is saved (gbvr_settings.txt in the game folder). Delete that file to go back to the defaults.
- Game choppy? View > Resolution, press - once or twice and restart the game.
- Trouble? Close the game, double-click COLLECT_LOGS.cmd and send the zip it puts in your Downloads folder.

SOMETHING WRONG?
- Black or flat picture in the headset: SteamVR must be running and the headset connected BEFORE you start the game. F4 in the game window switches the headset view on / off.
- No sound: older versions silenced the game's sound while a menu was open and, without the menu song, nothing played instead. V1.1 leave the sound alone then.
  Still silent: check the game's volume in the Windows volume mixer (on Steam Link / Steam Frame also the PC's playback device), then send COLLECT_LOGS. Sound that is deep or slow and broken means the game is running slower than real time (lower the picture size in the VR settings) - the log lines AUDIO probe and RATE show the rest.
- Picture on the monitor but the headset stays black, and you have two graphics cards: see YOUR SETTINGS above (High performance card for ghost.exe).
- No hands at all: wake the controllers (press a button), turn OFF hand tracking (Quest and Virtual Desktop), check the batteries. The mod's log says so after 25 seconds (ENVHINT).
- The LEFT stick does not walk but the right stick turns and the buttons work (reported on Galaxy XR + Virtual Desktop + SteamVR; the Steam Frame D-pad / bumper mix-up may be the same thing): the game was reading a DirectInput gamepad of its own (often Steam's virtual pad) instead of the VR controllers. V1.1 closes that pad by itself a few seconds after the controllers are tracked (log line DITAKEOVER), nothing to do for you. Still stuck: Steam > right-click the game > Properties > Controller > "Disable Steam Input", restart the game, then COLLECT_LOGS and send the zip.
- The character stands still although you push the left stick (seen in Times Square after Stay Puft throws the sign, with the left stick fine before that): V1.1 plays the game's own knock-back in the Stay Puft level (the sign's push is what moves you out of its landing spot) and, if you are still stuck after 2.5 s, plays a skipped knock-back for you. If it still happens: close the game right after and send COLLECT_LOGS (the STUCK and KNOCK lines say what was going on). Quick test without an update: in the game folder open gbvr_settings.txt, set knock_comfort=0, save, start again.
- The gun (or the PKE) floats away from your hand, mostly at the start of a level or after a cut-scene: V1.1 no longer locks a gun that is more than about 30 cm from the hand (the game still has it on the back then) as your grip. If you still see it, close the game right after and send COLLECT_LOGS with a short video (the log lines GUNGRIP / GUNSLIP say what the game's hand and gun were doing).
- The game decides when you may hold the gun. In a cut-scene, a forced walk, or between levels the gun is put on your back and cannot be drawn. Your first gun of a session starts in your hand; after a cut-scene or a level change it comes back the way you had it (in hand if it was out). The right hand buzzes when you may draw. A knock-down does not put the gun away. The PKE and the trap are unchanged. Set gun_wait_draw=0 in gbvr_settings.txt to disable the gun waiting rule.
- The holstered gun now lies in the proton pack on your back with the barrel up, not through your chest.
- The body keeps its size while you play: its size was recomputed every frame from a running measurement of the model and could drift; now a small drift is ignored and a lasting one is followed slowly (BODYSCALE log lines say when the model's size moved).
- The player life bar shows on the drawn proton, meson, boson and slime guns; it is hidden on PKE, trap, light and holstered gear. It may be hidden in cut-scenes when no gun is at the hand.
- An empty right hand (gun on the back, nothing equipped) has the same soft finger shape as the left hand: the fingertips no longer curl.
- When the story gives you a new character model (new outfit, new hands), everything the mod remembered about the old model (the gun and PKE hold, the body size) is dropped and taken again from the new one. MODELCHANGE lines in the log say when.
- Earlier technical changes and their original build IDs are kept in source/docs/CHANGES_1.7.120.md for troubleshooting.
- Nothing happens at all: double-click CHECK_INSTALL.cmd. It names the problem (game not found, wrong game version, file changed by another mod).
- Hands and head move but sticks / buttons do nothing in play: wait 2-3 s after the 3D picture appears (the mod then switches the game's controls to "gamepad"), click the game window on the monitor once,
  close programs that fake a gamepad (x360ce, DS4Windows), and if needed try Steam > the game > Properties > Controller > Disable Steam Input. Still nothing: COLLECT_LOGS.cmd (below) and send the zip.
- The game crashed or something looks wrong: close the game, double-click COLLECT_LOGS.cmd. It puts one zip in your Downloads folder.
  Attach that zip when you report the problem, and say what you were doing and roughly when. A short phone video of the headset view helps a lot.
  The zip holds the mod logs, SteamVR / headset log files and a list of the game folder. No passwords, no save games.

MENU SONG
- The song that plays while the game menu is open (bin/gbvr_menu_music.mp3) is used with the permission of the YouTube creator who made it. It is NOT covered by this mod's licence: do not re-use or re-upload it on its own. The Sound page in the VR settings has its volume and an on/off switch; delete the file for a silent menu.
