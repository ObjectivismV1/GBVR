# Ghostbusters Remastered VR — probe reconstruction notes (0.16R / 0.17)

Written 2026-10-06 by Claude while rebuilding the lost probe 0.16 source.
Read this together with `Ghostbusters_VR_Complete_Technical_Handoff_2026-10-06.pdf`
and `Ghostbusters_VR_Integration_Plan.md`. This file records what is now
*verified*, how, and what is still open.

## 1. Inputs used

| Input | Identity |
|---|---|
| `ghost.exe` (user's Steam copy) | SHA-256 `ea5edecb590ace8efa2274df354ad266ada95a3100dbe6cabc5a5fb34a225038`, PE timestamp `0x5FA8FC04`, SizeOfImage `0x31CB000`, image base `0x140000000` |
| Probe 0.16 log | `gbvr_render_probe(20261006-211914).log`, 5,471 lines |
| Handoff PDF + integration plan | as above |

The original 0.16 ZIP and C++ source were lost. Everything below was
re-derived from the executable and the 0.16 log.

## 2. Executable ↔ log consistency

The 0.16 log records absolute hook targets. With the module base
`0x7FF767570000` they resolve to these RVAs, every one of which is the exact
start of a function in this `ghost.exe` (checked against `.pdata`):

| 0.16 hook name | RVA | Function bounds |
|---|---|---|
| descriptor | 0x2F2CD0 | 0x2F2CD0–0x2F2D72 |
| basis | 0x3019F0 | 0x3019F0–0x3021BE |
| view-build | 0x42C310 | 0x42C310–0x42C61B |
| view-bind | 0x42C0B0 | 0x42C0B0–0x42C10E |
| camera-prepare | 0x455010 | 0x455010–0x4551EB |
| view-spatial | 0x42C170 | 0x42C170–0x42C1A9 |
| visibility-stage | 0x450740 | 0x450740–0x4508D6 |
| main-spatial | 0x42C620 | 0x42C620–0x42C65E |
| frustum-build | 0x42AB30 | 0x42AB30–0x42B69F |

So the uploaded `ghost.exe` is the same build the 0.16 test ran on.

## 3. Verified engine camera path (static analysis)

```
camera render, vtable +0x38 = 0x450DD0 (called with g_activeCamera, &g_renderContext)
  0x450DF1  call [vt+0x40]  Prepare(camera, ctx)          = 0x455010   ret -> 0x450DF4
              reads camera+0x08 eye[3], +0x14 pitch/yaw/roll (rad), +0x20 FOV (deg),
                    +0x24 viewport x,y,w,h (float), +0x34 projection mode (int)
              0x455079 call 0x3019B0 SetOrientationFromEuler(camera+0x14)
                         0x3019CB call 0x03DD40  Euler -> 3x3 (stack)
                         0x3019D5 call 0x3019F0  SetCameraBasis(float m[9])  ret -> 0x3019DA
                              single argument rcx; stores m into global 0x236B96C (+ 4x4 at *0x236EE10)
              0x4551CD call 0x42BF70 snapshot -> ctx+0x6A3C8
                         (calls view-build 0x42C310 with eye 0x236B954 and the global basis)
  0x450DFD  call [vt+0x48]  VisibilityStage(camera, ctx)  = 0x450740   ret -> 0x450E00
              main spatial query 0x42C620 with camera+0x6C, hull 0x42A200 -> 0x42AB30
```

* `g_activeCamera` = qword at RVA `0xDCF990` (written at 0x1F6D3E / 0x1F6D66,
  read by the render loop at 0x1F1DF6 before `call [rax+0x38]`).
* `g_renderContext` = static object at RVA `0x1671950`.
* Source camera vtable `0x7C2268`: +0x38 → 0x450DD0, +0x40 → 0x455010, +0x48 → 0x450740.
* The world camera render is skipped when 0x1FAF10 or 0x1FB110 return true
  (loading / full-screen states), so a verified Prepare implies world rendering.
* Pause-menu candidate flag: byte at RVA `0x2229519` (tested by the
  "Pause menu is not running…" memory report at 0x234560; set at 0x21E54D /
  0x234702, cleared at 0x21ECBB). **Not runtime-confirmed.** 0.16R/0.17 log
  every change (`PAUSEFLAG a -> b`) and reset the camera edit on any change.

## 4. What 0.16 actually did (recovered from the log)

* The edit happened in the basis hook, return address `0x3019DA`, one modified
  call per world frame (modifiedCalls grew ~180 per 180 frames).
* Math: `M' = M * R`, `R = [[c,0,-s],[0,1,0],[s,0,c]]`, `s = sin(+10°)` for F7.
  The basis columns are right/up/forward (left-handed, y up), so this is a
  camera-local yaw. Rebuilt code reproduces all five logged 0.16 samples
  **bit-exactly** (error 0); the independent double check gives 6.0e-8, matching
  the handoff's 5.98e-8. See `tests/test_math.cpp`.
* Source camera, eye, Euler fields and shader buffers were never written.

## 5. Reconstructed design (0.16R)

* `d3d11.dll` proxy (game imports only `D3D11CreateDevice`); all 51 system
  exports forwarded. Init on the first `D3D11CreateDevice` call.
* **New safety:** hooks are installed only if the running `ghost.exe` has the
  expected timestamp and SizeOfImage *and* the first 16 bytes at each hook site
  match (`layout.h`). Otherwise the game runs untouched and the log says why.
* Hooks: camera-prepare (gates + arm), basis (apply), visibility-stage (audit).
  The D3D/descriptor/view/frustum capture hooks of 0.4–0.15 were diagnostic and
  are not part of 0.16R.
* Gates, all re-evaluated per call on the camera thread: caller = 0x450DF4,
  camera == g_activeCamera, vtable 0x7C2268, ctx == g_renderContext, finite
  fields, FOV 1–179, projection mode 0, game window focused, capture open,
  basis and result are proper rotations, basis caller 0x3019DA on the same
  thread inside the armed Prepare. Any failure on the active camera resets
  the mode (logged with the reason). Other cameras/callers pass through untouched.
* New audits per report: `applyVerify` (global basis after the setter equals the
  edited basis) and `pairedBasisMatch/Differ` (the global basis is still the
  edited one when VisibilityStage runs on the same thread/camera). This
  directly tests the open "1 of 11 basis-to-draw differs" question for the
  visibility input.
* Capture window: 180 s from the first F7/F8/F9 (0.16 used 2160 world frames).

## 6. 0.17 additions

* OpenVR via the C function table (`FnTable:IVRSystem_026`) as a **background**
  application: no frame submission, does not launch SteamVR. `openvr_api.dll`
  (SDK 2.15.6) is loaded from the game folder.
* F9: start/enable head tracking and recenter; F9 again recenters; F6 off;
  F7/F8 switch to manual (mutually exclusive).
* Render thread (Present) samples the HMD each frame and publishes a locked
  snapshot; the camera hook only reads it. Pose > 250 ms old, invalid pose,
  tracking not Running_OK → reset.
* Conversion (unit-tested, `tests/test_headtrack.cpp`): yaw-only recenter
  reference Y, `D = Yᵀ·H`, `L = S·D·S` with `S = diag(1,1,-1)`, `M' = M·L`.
  Pure +10° head yaw gives exactly 0.16's F7 matrix. Pitch and roll are
  absolute (horizon follows the real headset).
* Camera position stays game-owned; no stereo, no controller aim yet.

## 7. Open items

1. Runtime confirmation that 0.16R matches 0.16 visually (walls stay solid).
2. Pause flag meaning (watch `PAUSEFLAG` lines while opening/closing the menu).
3. Head rotation is applied in camera-local space on top of game pitch; once
   first-person/stereo work starts, game pitch should be separated from head pitch.
4. Everything after 0.17 in the handoff's sequence (camera/aim alignment,
   first person, stereo, HUD, controllers, performance) is not started.

## 8. Building

* Windows: run `BUILD.cmd` (Visual Studio 2019/2022 with C++ tools).
* The shipped DLLs were built with `build_cross.sh` (clang 18 + lld, mingw-w64
  headers, freestanding: imports only KERNEL32, USER32, msvcrt). The MSVC path
  has not been run by Claude (no Windows machine); report any build errors.

## 9. Result: 0.16R runtime test (2026-10-07, `gbvr_probe_0.16R_20261007-000622.log`)

User report: **walls good** at the first Slimer encounter (F7/F8/F6).

* Identity and byte checks passed; all three engine hooks and Present installed (status 0).
* 1,592 world frames; every Prepare verified (active camera, vtable, context,
  fields, projection mode 0); `otherCaller=0`.
* 1,028 modified basis calls, exactly one per world frame while F7/F8 was on.
* `applyVerify` 1028/1028 (global basis equals the edited basis, max diff 0).
* Visibility stage paired with the modified Prepare 1028/1028, and the global
  basis still held the edited value every time (`pairedBasisDiffer=0`). The
  visibility/culling input therefore always used the rotated view.
* Worst yaw math error 8.13e-8 (float rounding); no invalid basis, no armed
  Prepare without its basis call.
* `PAUSEFLAG` (0x2229519) went 0→1 when the level started and 1→0 only after
  world rendering stopped (frame 1592). It behaves like an "in level" flag, not
  "pause menu open". Keep it as a logged transition trigger only.
* Conclusion: 0.16R reproduces 0.16's validated early-engine behaviour.
  Next: probe 0.17 head tracking test.

## 10. Result: 0.17 runtime test (2026-10-07, `gbvr_probe_0.17_20261007-001202.log`)

User report: **buttons work, walls good, everything good** (first Slimer,
Quest 3 + Virtual Desktop + SteamVR).

* OpenVR started as a background app with `IVRSystem_026` ~70 world frames
  after the first F9; F9 recenter and F6 off both worked (two head sessions).
* 2,420 world frames, all Prepares verified; 1,385 head-tracked basis edits.
* `applyVerify` 1385/1385, visibility paired 1385/1385 with
  `pairedBasisDiffer=0`, no invalid basis, no armed Prepare without its basis
  call, no pose-gate resets.
* Sampled head range (every 60 frames, 25 samples): yaw −29° to +18°,
  pitch −5° to +15°, roll −52° to +32°. Larger turns may have happened
  between samples but are not proven by the log.
* Pose age at use was 30–31 ms in every sample. The pose is sampled at Present
  and consumed by the next frame's Prepare, so this is one frame time:
  **the game was running at about 32 FPS**, consistent with the stock
  `lockTo30Hz` limiter. Native 90 FPS needs the limiter removed (120FPS patch
  values `lockTo30Hz=0`, `lockTo60Hz=0`) and frame-time measurement.
* Conclusion: the 0.17 acceptance test passed for the sampled range.

## 11. Proposed next steps

1. **0.18 – frame rate:** log real frame times (Present-to-Present, CPU/GPU
   split later); apply only the two limiter values to the user's settings.ini
   (with backup) and confirm the uncapped rate.
2. **0.19 – camera placement design:** find the player's head position in
   memory and test a first-person eye position through the same early path
   (Prepare reads the eye at camera+0x08 via 0x3021C0, analogous to the basis
   setter), designed together with stereo eye offsets as agreed.
3. Stereo submission after that.

## 12. Probe 0.18 (2026-10-07)

* Same camera/head-tracking code as 0.17 (unchanged behaviour), plus:
* `FRAMETIME` every 180 presents: FPS, avg/min/p50/p95/p99/max Present-to-Present
  ms, counts over 11.1 / 16.7 / 33.3 ms, average time blocked inside Present
  (vsync/GPU queue), sync interval, and the live lockTo30Hz/lockTo60Hz bytes.
  `MONITOR` logs the desktop refresh rate once.
* Limiter facts (verified in ghost.exe): defaults lockTo30Hz=1, lockTo60Hz=0
  (0x1F4094); main loop 0x1F05B6 picks 30 / 60 / 120 FPS (0x73776C, 0x73AF8C,
  0x73AF90). settings.ini path: `%LOCALAPPDATA%\<sanitised game title>\settings.ini`
  (SHGetFolderPathW CSIDL 0x1C at 0x241318, format `%s\%s\%s`).
* Installer: closes nothing itself; refuses to run while ghost.exe is running
  (the game rewrites settings.ini on exit). Sets only keys in
  `tools/settings_to_apply.txt` (lockTo30Hz=0, lockTo60Hz=0), keeps a full
  settings.ini backup, records original values in the manifest and restores
  them on removal if still 0. Launchers now detect "run from inside the zip".

## 13. 0.18 test and 0.18.1 fix (2026-10-07)

* 0.18 logs (`..._002611`, `..._002800`): frame time locked at 33.33 ms (30.0
  FPS), `lockTo30Hz=1` in memory, `syncInterval=1`, Present wait ~0.1–0.6 ms
  (the 30 FPS cap is the game's own limiter, not vsync or GPU load). Head
  tracking worked again; 532/532 edits verified; desktop refresh 59 Hz in one
  run and 165 Hz in the other.
* Cause: the installer looked for `%LOCALAPPDATA%\GHOSTBUSTERS*Remastered*`.
  ghost.exe cuts the title at the first ':' (strtok, 0x6CCD00 called at
  0x24134E), so the real file is `%LOCALAPPDATA%\GHOSTBUSTERS\settings.ini`;
  the settings were never changed.
* 0.18.1: installer checks `GHOSTBUSTERS\settings.ini` first, then any
  `GHOSTBUSTERS*` folder containing the `lockTo30Hz` key, and prints a red
  warning if none is found. The DLL logs the two keys from that file at
  start-up (`SETTINGSINI ...`). Camera/head-tracking code unchanged.
* 0.18.1 result: installer still found no settings.ini after the user started
  and closed the game, so the game never persists its settings on this PC
  (likely WritePrivateProfileStringW failing because the folder does not
  exist). Every launch uses the defaults set at 0x1F4094 (30 Hz lock on).
* **0.18.2:** the DLL clears lockTo30Hz/lockTo60Hz (0x2629D6E/0x2629D6F, in
  writable .data) on the render thread whenever they are non-zero, logging
  `FRAMELIMIT unlocked`. These are the same bytes the in-game graphics menu
  writes at runtime (0x21A404, 0x21A41D). The game cap becomes 120 FPS.
  The installer's settings.ini edit stays as an optional extra; "not found"
  is now an informational message.

## 14. 0.18.2 result and probe 0.19 (2026-10-07)

* 0.18.2 (`..._004405`): limiter cleared at present 1 (lockTo30Hz 1→0).
  Gameplay ran at a steady **72 FPS** (p50 ~15 ms, p95 ~18 ms) with
  `presentWaitAvgMs` ≈ 12 ms, i.e. the game itself needs only ~3 ms per
  frame and is waiting on the desktop/compositor (syncInterval=1, desktop
  paced at 72 Hz — the headset rate Virtual Desktop streams at). Real VR
  submission will be paced by SteamVR instead. Head tracking 1242/1242 verified.
* Camera system facts (ghost.exe): tuning table registered at 0x1FF9xx with
  labels; Standard Distance 0xDCF808=4.5, Pivot Height 0xDCF85C=5.5, Pivot
  Offset 0xDCF858=1.75, Focal Length 0xDCF86C=23 (= camera FOV field), Aim/
  Snared/PKE/Sprint variants follow. Game units are feet (5.5 ft eye height).
  Standard update 0x2023A9: pivot(+0x240) = target(+0x210)->pos(+0x54) +
  heading-rotated (offset +0x28C, height +0x290, +0x294); eye(+0x08, copy
  +0x6C) = pivot − forward × distance(+0x24C).
* **0.19 first-person test (F5; height F11 / Shift+F11, 1–8 ft):** eye = followed actor position
  + (0, height, 0) + 0.30 ft along the camera heading. Validated per frame
  (actor pointer readable via VirtualQuery, finite position, game pivot within
  8 ft of our head point, third-person eye within 40 ft). Applied through two
  more temporary-input hooks, never by writing camera/actor fields:
  - SetEye 0x3021C0 (only the call from Prepare, return 0x455075), so the
    prepared view snapshot uses the first-person eye;
  - MainSpatial 0x42C620 (only the call from VisibilityStage, return 0x45077C),
    so the sector/portal query that drives culling starts from the same eye.
  Counters: eyeApplied/eyeVerify (global eye 0x236B954), spatialApplied/
  spatialVerify (view+0x17F60). All callers of both functions were checked:
  none relies on volatile registers across the call.
* Known gap for this test: the player model is still drawn.

## 15. 0.19 result and probe 0.20 (2026-10-07)

* 0.19 (`..._011531`): first person applied on 2,434 frames — eyeVerify
  2434/2434, spatialVerify 2434/2434, no gate failures; head tracking
  1255/1255 verified. FPEYE samples confirm the model exactly: actor position
  is at the feet (floor), the game's pivot is actor + 5.50 ft up + 1.75 ft
  sideways. User: everything worked; the player's hair and eyes were visible;
  every mode switched off whenever a menu/focus change happened.
* 0.20 changes:
  - **Suspend instead of reset.** Focus, camera, pose and first-person gates
    still block the modification on any frame where they fail, but no longer
    switch the mode off; the effect resumes automatically (`SUSPENDED:` /
    `RESUMED after:` log lines). F6 is the only off switch. The pause/level
    flag is logged only. The capture window now only ends detailed sampling.
    This intentionally relaxes the handoff's "disable/reset" rule now that the
    path is validated; no frame is ever modified while a gate fails.
  - **First-person near plane.** Hook SetNearFar 0x300EB0, only the call from
    Prepare (return 0x455186), only while the first-person eye is armed:
    near = 0.55 ft (game default min(FOV/23·0.25, 0.25) = 0.25 ft). Adjustable
    Ctrl+F11 / Ctrl+Shift+F11 in 0.05 ft steps (0.25–1.50). Clips the inside of
    the player's own head without hiding the body.
* Investigated for later: CFloater::setRenderOnlyInMirrors (0x9AB30) shows the
  engine's per-render-instance pre-render callback mechanism (render manager
  0x140DD6F20, 0x3E0DF0) — the proper way to hide the player model from the
  main view while keeping mirrors; the player class's instance handles are
  not yet identified.

## 16. 0.20 result and probe 0.21: alternate-eye stereo prototype (2026-10-07)

* 0.20 (`..._015027`, `..._015241`): first person 3,564 frames — eye, sector
  query and near plane verified on every one; head tracking 4,273/4,273;
  `suspendedFrames=0`; ~72 FPS. User: walls good, modes survive menus.
  Evidence used for the stereo design:
  - verified prepares = world frames = Presents during gameplay (one prepare
    per presented frame);
  - the pose sampled just before Present was 9–12 ms old at the next prepare,
    equal to the time spent inside Present: prepare → draw → Present run in
    sequence (0.21 logs both thread ids in a `THREADS` line to confirm);
  - world frames stop while a menu/loading screen is up (presents 1080–1440).

### 16.1 Projection (new static analysis, all checked by `tests/verify_layout.py`)

* Prepare (0x455010) calls, in order: viewport setter 0x302200 (camera +0x24..
  +0x30, pixels), **SetProjection 0x302520** (call at 0x455067, return
  0x45506C), SetEye, SetOrientationFromEuler → basis setter, near/far, then
  the prepared-view snapshot 0x42BF70.
* `SetProjection(float zoom /*xmm0*/, int mode /*edx*/)`: zoom = camera field
  +0x20 (default 23 = the tuning value "Focal Length") / 18 × global 0xDE54EC
  (1.0). For mode 0 with a = viewport width/height × pixel aspect:
  a > 4/3: scaleY = 4/3·zoom, scaleX = scaleY/a; otherwise scaleX = zoom,
  scaleY = zoom·a. Stores scaleX 0x236EDC4, scaleY 0x236EDD4, 1/scaleX
  0x236BB54, 1/scaleY 0x236BB58. A bigger value is a NARROWER view (it is a
  focal length, not an angle).
* The renderer callback 0x3F5020 (called from the basis setter with scaleX,
  scaleY, near, far) builds the D3D projection: P[0][0] = scaleX, P[1][1] =
  scaleY, w = z, no off-centre terms. So 0x236BB54 = tan(half horizontal
  FOV), 0x236BB58 = tan(half vertical FOV): 1.0435 / 0.5870 at 16:9 =
  92.4° × 60.8° (vertical FOV is fixed, horizontal grows with aspect).
* The basis setter scales the view matrix columns with the same two values
  (CPU-side frustum/culling) and the snapshot copies them, so a change made
  through SetProjection inside Prepare reaches rendering and visibility
  together. 12 callers of SetProjection were checked: none relies on volatile
  registers across the call; the other view paths (shadow/reflection style
  cameras) call it themselves.

### 16.2 Design

Alternate-eye rendering: the game renders one eye per frame (left, right,
left, …) with everything that is already validated; nothing is rendered twice.

Camera thread, inside a verified Prepare, only when F4 is active, head pose
valid and every gate passes (otherwise the frame is left completely
unmodified):
* **View** = level(yaw) × headRotation. level(yaw) is the yaw-only engine
  basis from the camera's yaw field; the game's own pitch/roll (mouse look,
  camera shake) are left out so the horizon is always level in the headset.
  Passed through the basis setter hook (counter `yawAgree` checks that the
  engine's own basis has the same yaw).
* **Eye** = base + level × headPosition (only with F3) + viewRight × eyeX.
  base = first-person eye (F5 on, default) or the game's third-person eye.
  eyeX = OpenVR eye-to-head x (±half IPD) × 3.2808 ft/m × strength (Ctrl+F4).
  Passed through SetEye and the main sector query exactly like 0.19.
* **Field of view**: the game keeps its symmetric frustum but widened so it
  contains both eyes' off-centre frustums: target tanV = max(up/down extents,
  left/right extents ÷ aspect). Hook on SetProjection (only the call from
  Prepare, mode 0): call the original, read the tangents it produced, call
  again with zoom × tanV0 / target, read back and verify (`fovVerify`).
* After the engine's prepare returns, the eye, basis and tangents are read
  back once more; only if all still match is the frame published as an eye
  picture (`StereoFrame`: eye, headset pose, tangents).

Render thread, in the Present hook (`src/stereo.cpp`):
* Before Present: frame published → copy the back buffer into that eye's
  texture (CopyResource; ResolveSubresource for MSAA) and submit both eye
  textures to IVRCompositor with `Submit_TextureWithPose` (each with the pose
  it was rendered for) and `VRTextureBounds` selecting that eye's window in
  the wide frame:
  u = 0.5 + 0.5·left|right / tanH, v = 0.5 − 0.5·bottom|top / tanV.
  Frame not published (menu, loading, video, any suspended gate) for 3
  Presents → the frame is shown on an IVROverlay flat screen (3 m wide, 2.5 m
  in front of the current heading, alpha ignored) and no scene frame is
  submitted; the 3D picture returns after two published frames.
* After Present (sync interval forced to 0): `WaitGetPoses`; the predicted
  HMD pose is published for the next prepare. The render thread also owns
  the eye alternation (`stereoNextEye`).
* OpenVR session: F4 needs a *scene* application; a running background
  session (F9) is shut down and restarted. F4 off / F6 hides the overlay,
  shuts the session down and releases all D3D objects. `VREvent_Quit` is
  acknowledged and ends the session (the game keeps running).
* No game D3D state is touched; no camera/gameplay field is written; shader
  rotation stays disabled.

### 16.3 OpenVR raw projection convention

`GetProjectionRaw`: left < 0 < right; **"top" is negative and is the downward
edge, "bottom" is positive and is the upward edge** (y-up tangents with
swapped names). Sources: Valve's ComposeProjection sample (idy = 1/(bottom −
top), P[1][1] = 2·idy, P[1][2] = (bottom+top)·idy, P[3][2] = −1 ⇒ NDC top ↔
tangent = bottom) and OpenComposite's measured values for an asymmetric
headset (SteamVR top = tan(angleDown)). The texture-bound formulas above are
identical to the SteamVR Unity plugin's. `tests/test_stereo.cpp` checks the
bounds against ComposeProjection independently. Firefox's old OpenVR code
reads it the other way round (up = −top); if the picture turns out shifted
vertically on the Quest 3, this is the first thing to re-check (the raw
values are in the log as `STEREOPARAMS`).

### 16.4 Known limits of this prototype

* Each eye is updated at half the headset rate (36 Hz at 72 Hz): judder and
  shimmer on motion. Any temporal effect in the game (motion blur, temporal
  filtering, exposure driven by the camera) sees the eye jump every frame.
* Resolution: with a 2560×1440 back buffer and a Quest-like frustum each eye
  uses roughly 1100×1200 pixels of the frame.
* HUD and anything else drawn in screen space is cropped and has no depth.
  If the pause menu is drawn on top of a still-rendering world, it will not
  switch to the flat screen (to be seen in the test).
* The widened projection stays in the engine's globals after the last stereo
  prepare until the engine sets its own again (`engineTanNow` in
  `STEREOSTATE` shows it); nothing was observed that depends on it.
* Eye-to-head rotation (canted displays) is ignored with a warning.
* Player body still drawn; aim still follows the game's own camera pitch.
* If prepare and Present are ever on different threads, eye pictures can be
  paired with the wrong frame (`THREADS … same=0` warning).

### 16.5 Checks before release

* Independent review of all new code (OpenVR table usage vs `openvr_capi.h`,
  state machine walk-through, threading, D3D reference counting, MSVC
  compatibility); the defects it found (stale failed-session state, orphaned
  head-tracking mode, flat-screen placement, stale eye texture, a 0.20
  regression in gate handling, post-prepare verification, device identity)
  are fixed in this version.
* `tests/test_stereo.cpp`, `test_headtrack.cpp`, `test_math.cpp`: ALL PASS.
  `tests/verify_layout.py`: ALL PASS (35 checks).
* Not testable here: anything that needs SteamVR, a headset or the game.

## 17. 0.21 result and probe 0.21.1 (2026-10-07)

* 0.21 (`evidence_gbvr_probe_0.21_20261007-031205.log`), Quest 3 through
  Virtual Desktop, 90 Hz, IPD 70.6 mm. User: the desktop window changed
  (wide, flickering, followed the head) but the headset never showed the game.
* What worked (4,054 stereo frames): every frame complete and verified
  (`fovVerify` 4054/4054, `yawAgree` 4054, `incomplete=0`, `changedAfter=0`),
  eyes alternated exactly (2028/2026), one fresh frame per Present
  (`seqSkips=0`), poses valid, flat-screen mode entered/left around menus.
  Measured headset values: raw projection left eye −1.37638 / 0.83910 /
  top −1.42815 / bottom 0.96569 (mirror for the right eye), eye-to-head
  ±0.03534 m, no rotation. Engine: zoom 1.27778 → 0.52516, tanH 2.53893,
  tanV 1.42815; each eye uses 1116×1206 px of the 2560×1440 frame.
* **Failure: every `Submit` returned 106 =
  `VRCompositorError_SharedTexturesNotSupported`.** Cause: the game creates
  its DXGI factory with the DXGI 1.0 function `CreateDXGIFactory` (its only
  dxgi.dll import; call at 0x3F2C59), enumerates the adapter from it and
  passes it to `D3D11CreateDevice` (0x3F2E12). The compositor shares frames
  through keyed-mutex shared textures, which need a DXGI 1.1 device (Valve:
  create the factory with `CreateDXGIFactory1`).
* **0.21.1 fix:** `DllMain` rewrites the game's import-table slot for
  `CreateDXGIFactory` (RVA 0x732DA8, verified by `verify_layout.py`) to a
  wrapper that calls `CreateDXGIFactory1` and returns the interface the game
  asked for on that 1.1 factory; on any failure it calls the original. Only
  for the verified executable. `DllMain` does nothing else new (two
  GetProcAddress, one pointer write; no loading, logging or allocation).
  The log now shows `DXGIFACTORY install/calls/upgradedTo11` and, for every
  device the game creates, `SHARETEST` (creates a 16×16 keyed-mutex shared
  texture on that device) — so the log tells whether the headset path can
  work before F4 is pressed.
* **Threads.** `THREADS present=9436 cameraPrepare=37892`: prepare and
  Present are on different threads. Static analysis: the main frame function
  (0x1F0360…) first waits for the render command queue 0x141671938 to drain
  (0x3DDAC0), then renders the world (prepare → draw commands), then queues
  the end-of-frame command; the Present function 0x3F59C0 (callback slot
  0x1425506D0) runs on the render thread under the device critical section
  0x142629D80. Runtime evidence that the two take strict turns: the pose
  published *after* Present/WaitGetPoses was 0 ms old at the next prepare on
  all 64 gameplay samples (0.20: equal to the Present wait), and frames were
  consumed 1:1. So "the newest published frame at Present" is the frame being
  presented. 0.21.1 adds a direct check (`overlap=` in `STEREOCOUNTS`: a
  prepare that starts while the previous eye picture is still unpresented).
* Not yet known: what the headset showed during F4 in 0.21 (the overlay calls
  returned success 193 times while Submit failed).

### 17.1 Second 0.21 run and rename to 0.22 (2026-10-07)

* The user's next logs (`..._145230`, `evidence_gbvr_probe_0.21_20261007-145450.log`)
  were again written by 0.21 (header "0.21", no `DXGIFACTORY` line): 0.21.1
  had not been installed. Same result (3,484 complete stereo frames, all
  submits 106). New information: with F4 on, the headset showed SteamVR's
  endless waiting screen (the scene application is registered but no frame
  arrives) and F3 head position reached the engine (`headFeet` samples up to
  0.58 ft). Pose age 0 ms on 53 of 54 gameplay samples again.
* The 0.21.1 fix is released unchanged as **0.22** so that the version in the
  log file name cannot be confused with 0.21.

## 18. "Game won't start" after 0.21 and probe 0.23 (2026-10-07)

* Report after 0.22 was sent: "game won't start now". Earlier remark in the
  same test round: "saved settings" - the wording of the installer's refusal
  ("The game is running. Close it first (it saves its settings when it
  exits)"). Together with the fact that 0.21.1 was never installed although
  the user had run the installer, the most likely explanation is: **after a
  session with F4 (OpenVR scene application) ghost.exe stays alive in the
  background when the game is closed**, so the installer refuses and Steam
  will not start a second copy. Runs with F9 only (background application,
  0.17-0.20) always exited. Not proven: no log can show a process that fails
  to exit, and whether 0.22 itself starts is unknown (it may never have been
  installed).
* 0.23 therefore addresses both possibilities:
  - **Exit guard** (`src/exit_guard.cpp`), armed the first time an OpenVR
    session is requested: ExitProcess hook -> stop the render thread's OpenVR
    use (`g_vrStop`/`g_vrBusy`), orderly `VR_ShutdownInternal` on a helper
    thread (2 s limit), then `TerminateProcess` with the game's exit code
    (the game has finished its own shutdown when it calls ExitProcess; only
    DLL unload notifications are skipped). Watchdog: game window destroyed
    and no Present for 5 s -> same. Every step is logged (`EXIT ...`).
  - **Installer**: a ghost.exe without a window is treated as a stuck copy
    and closed (Stop-Process); with a window the user is asked to close the
    game as before. Start-up marker files are removed on install/removal.
  - **Start-up safety net** for the DXGI 1.1 switch: `gbvr_start_pending.txt`
    is written when the game asks for its factory and deleted after the first
    Present; if it is found at the next start, `gbvr_dxgi11_off.txt` is
    written and the import slot is left alone (start-up identical to 0.21)
    until the file is removed. Decided in DllMain with file-attribute calls
    only.
  - **Early log + crash notes**: the probe now initialises when the game asks
    for its DXGI factory (before device creation) and logs each step; a
    vectored exception handler writes `CRASHNOTE`/`CRASHSTACK` lines (module +
    offset, game code addresses found on the stack) for access violations and
    similar, then passes the exception on.
* Static check done for the DXGI switch: the game's display enumeration
  (0x3F0C10: EnumAdapters / EnumOutputs loops with failure checks, table at
  0x265D350) and device creation use only IDXGIFactory methods; the factory
  IID requested is IID_IDXGIFactory. No reason was found why a 1.1 factory
  would break start-up, but it has not run yet.

## 19. 0.23 result: first stereo picture in the headset (2026-10-07)

* `evidence_gbvr_probe_0.23_20261007-174248.log`. User: "worked, blurry, but
  worked in 3D". The earlier "game won't start" was a user-side mistake
  (not specified), so the stuck-background-copy explanation in §18 remains
  unconfirmed; the exit guard and installer change stay as precautions.
* DXGI switch: `DXGIFACTORY gave the game a DXGI 1.1 factory`, `slotWasPlain=1`,
  `SHARETEST` OK on both devices (keyed-mutex shared texture 0x00000000),
  start-up marker written and removed at the first frame.
* Stereo: 4,694 frames, all complete and verified (fovVerify 4694/4694,
  eye/sector/near 4694/4694, yawAgree 4694, **overlap=0**), eyes 2347/2347,
  **Submit OK 4697/4697 per eye, 0 failures**, flat screen 212 frames with
  overlay OK, seqSkips=0. F3 head position was used. 72.0 FPS steady
  (13.89 ms), i.e. 36 new pictures per second per eye.
* Exit: `EXIT game called ExitProcess ... SteamVR session shutdown finished ...
  ending the process now (exit code 0)` - the exit guard path works.
* Blur is expected: each eye is 1116x1206 px of the 2560x1440 frame, against
  the headset's recommended 2496x2688 per eye (about 20 % of the pixels).
* Still to be answered by the user: depth direction, world scale, level
  horizon, walls/culling with the wide view, flat-screen menus, leaning.
* Next work items: sharpness (use the whole frame per eye / higher render
  resolution) and smoothness (both eyes every frame instead of alternating).

## 20. Probe 0.24: both eyes per headset frame, more pixels per eye (2026-10-07)

User feedback on 0.23: depth good, scale about right, floor level, walls
good, very blurry, own character still visible, F3 (leaning) inconclusive.

### 20.1 Eye pairs ("smoother", F8, default on)

* 0.21-0.23 rendered one eye per headset frame (72 Hz headset pace measured:
  36 new pictures per second per eye, the other eye one frame older).
* 0.24 renders the two eyes in two consecutive game frames inside one headset
  frame and submits them together:
  - Present of the first eye: copy only, no Submit, no `WaitGetPoses`
    (never skipped twice in a row); the render thread sets
    `stereoPairPhase=1`, `stereoNextEye=right`.
  - Present of the second eye: copy, Submit both, then `WaitGetPoses`;
    phase back to 0, next eye left. Non-3D frames always wait and reset the
    pair.
  - Camera thread: the first frame of a pair stores {camera yaw, base eye,
    head pose}; the second frame reuses them (`secondEyeReused`), so both
    eyes are rendered from one consistent camera/head state even though the
    game advanced a few milliseconds. Moving objects still differ by that
    interval between the eyes (`pairGapAvgMs` in `STEREOSTATE`).
  - Frame limiter: `App::Tick(this, fps)` (vtable 0x7BE9C0 +0x158 =
    0x1F1C40; calls the frame timer 0x2D9CF0, a busy-wait until 1/fps since
    the previous tick, min ticks = 1179648/fps) is hooked. While the pair
    mode is active the 120 FPS value becomes 1000 for the second eye's frame
    and 240 for the first. The game's time step still comes from real
    elapsed time, so game speed is unchanged; frames now alternate between a
    short and a long time step.
* This is still two separate game frames per eye pair, not one simulation
  frame rendered twice; rendering the world twice inside one frame remains
  the long-term goal.

### 20.2 Separate horizontal / vertical field of view ("sharper", F7, default on)

* Until 0.23 the symmetric frustum came from SetProjection, where
  tanH = aspect * tanV. Covering the headset's vertical extent (1.428) forced
  tanH = 2.539 although only 1.376 is needed: each eye used 1116 of 2560
  columns.
* 0.24 calls the engine's direct setter SetScales(scaleX, scaleY) (0x302650,
  leaf; writes the same four globals) right after the original SetProjection
  inside the hooked Prepare call: tanH = 1.376, tanV = 1.428. The basis
  setter, renderer projection (P[0][0], P[1][1]), culling matrix and the
  prepared-view snapshot all read those globals, so the change is consistent
  the same way the zoom change was. Each eye now uses about 2060 x 1206
  pixels (bounds from the read-back tangents as before). Pixels are no longer
  square in the back buffer; the compositor's sampling undoes that for the
  world. Screen-space elements (HUD) are squeezed.
* Vertical pixel density is unchanged (1440 rows for 2.86 tangent units).
  More needs a larger back buffer or an off-centre projection.

### 20.3 Open

* Player model visible in first person (user request) - next item. Needs the
  player's render instance; candidates: the per-instance pre-render callback
  mechanism seen in CFloater::setRenderOnlyInMirrors (0x9AB30, render
  manager 0x140DD6F20, 0x3E0DF0).
* Risks to watch in the 0.24 test: game behaviour at twice the frame count
  with alternating short/long time steps; effects that assume square pixels
  or tanH = aspect * tanV.

## 21. 0.24 result and probe 0.25 (2026-10-07)

* `evidence_gbvr_probe_0.24_20261007-183520.log`, 12,641 stereo frames, all
  verified, `overlap=0`, no submit errors, clean exit.
* **Eye pairs work as designed:** 144 game frames per second, 72 pairs per
  second (90 pairs per 180 Presents), second eye reused the first eye's
  camera state on 6130/6140 pairs (`secondEyeNoState=0`), time between the
  two eyes of a pair 2.2-3.3 ms on average, `ticksLifted` = pairs. Pose age
  0-4 ms. User: "smoother", but toggling F8 made little visible difference.
* **Separate H/V field of view works technically** (tanH 1.37638, tanV
  1.42815 read back and verified on every frame, each eye 2060x1206 px) but
  the user preferred it OFF. Cause not established; candidates: non-square
  pixels (about 16 px/degree across, 9 px/degree up-down) look worse than a
  uniformly soft picture; more visible aliasing; the eye's outer edge now
  coincides with the frame edge, so head-turn reprojection shows black
  earlier. Default is now off.
* The picture is still "blurry": without F7 each eye has about 9 pixels per
  degree; the Quest 3 shows about 25, and SteamVR's recommended eye buffer
  for this setup (2496x2688) is about 20. The real fix is a larger render
  resolution in both directions. The README proposes a test with NVIDIA DSR
  (desktop and game at 3840x2160) to confirm that resolution is the cause
  before building an in-probe solution; `STEREO textures W x H` in the log
  shows what was used.
* User: feels about a foot too short / world too big. 0.25 adds a **player
  size** factor (default 110 %, PgUp/PgDn, 70-150 %): eye height above the
  actor's feet, eye separation and head movement are multiplied by it in the
  headset view. The first-person sanity check now compares the game's pivot
  with the nominal head point (5.5) so tuning cannot trip it.
* **Saved settings:** `gbvr_settings.txt` (name=number lines: size, depth,
  eye height, near plane, sharp, smooth), loaded at start, written by the
  render thread shortly after a key changed a value.
* Player model still visible (user mentioned it again in 0.23 feedback).
  Looked at `CFloater::setRenderOnlyInMirrors` (0x9AB30): it sets flag 4 at
  object+0x2A0 and registers a per-handle pre-render callback (0x9DD70) with
  the render manager (0x140DD6F20, 0x3E0DF0) for the handles at +0x7D88,
  +0x7DA0.. (8 x 0x18), +0xCE98, +0xCE9C. That layout is specific to
  CFloater; the player actor's render handles still have to be found.

## 22. 0.25 result and probe 0.26: picture levels, world size, mouse (2026-10-07)

* `evidence_gbvr_probe_0.25_20261007-185114.log`: 9,334 stereo frames, all
  verified, 72 pairs/s at 144 game FPS (pair gap about 3.1 ms = one whole
  game frame at 2560x1440), clean exit. Player height stayed at 110 % (no
  PgUp/PgDn presses). F3 (leaning) was on for a while; no feedback on it yet.
  F7 was switched on near the end and left on (`sharp=1` saved).
* User: "height feels fine", "make world bigger", and "game got better
  visual with your trick so proceed with that" (the NVIDIA DSR test from the
  0.25 README).
* **What the log says about the DSR test:** the swap chain was 2560x1440 for
  the whole run (`eyePixels` 1116x1206, 2060x1206 with F7) and the monitor
  was at 2560x1440 **59 Hz** (165 Hz in the run two minutes earlier). So the
  display settings were changed, but the game did not draw a bigger picture
  in this run; what looked better was most likely F7. Either way the request
  is clear: more pixels, without relying on the driver.
* **How the game chooses its picture size** (new analysis, `layout.h`
  "Display modes", all checked by `tests/verify_layout.py`):
  * `EnumerateAdapters` 0x3F0C10 asks each DXGI output for
    `GetDisplayModeList(format, 0)` (count call at 0x3F0E8F, fill call at
    0x3F0ED5, the only two such calls in the executable), keeps distinct
    sizes >= 640x480 (the last 32) in a 0x190-byte record: desktop size at
    +0x80/+0x84, sizes at +0x88, count at +0x188. Only Width and Height of
    each mode are read.
  * Three copies of the same selection - start-up 0x3B7DD0, the options
    menu's monitor/apply path 0x301800 and the window/device routine
    0x48A550 (runs last at start-up and when a resolution is picked) - take
    the size stored in 0xDD674C/0xDD6750 if it is in the list, else the
    entry equal to the desktop size, else entry 0, write it back to those
    globals and call `InitDevice` 0x3F2CE0. Nothing compares the result with
    the monitor size.
  * `InitDevice` creates the swap chain with that back-buffer size
    (Windowed = 1, SwapEffect = DISCARD, 2 buffers) or, when it exists, calls
    `SetResolutionBorderlessWindow` 0x3EE780: `ResizeBuffers(w, h)` and
    `SetWindowPos` to the monitor rectangle. The window is created at the
    settings size (0x458ADF) and set to the monitor rectangle before the
    first frame. The exclusive-fullscreen routine 0x3EEA10 has no callers.
    So with the game's default (`runWindowed=0`) the window covers the
    monitor and DXGI stretches the back buffer into it - the situation of a
    player who selects a DSR resolution in the game's menu.
  * With `runWindowed=1` (0xDD6758 != 0) the game sizes a normal window from
    its own saved size and does not use the list; the picture level then has
    no effect. `PICTURESIZE` logs the flag.
  * The perspective's aspect ratio is width/height of 0xDD674C/0xDD6750
    (0x2FA4C0, called by SetProjection); those two globals have about 380
    readers (the menus and HUD lay themselves out from them).
  * **Hard limit, 2880 lines:** 0x2FD160 (a leftover software-framebuffer
    path) writes one pointer per picture line into a 1440-entry table at
    0x251E090, which is followed directly by a second 1440-entry table at
    0x2520D90; live variables start at 0x2523A90. 1441-2880 lines run into
    the second table (2160 lines = what the game does on a 4K monitor);
    more than 2880 would overwrite other variables. `picturemath.h` never
    goes above 2880 lines (static_assert) or above 3840 wide (the game's
    retail maximum).
* **Picture levels (modes.cpp).** For the game's own two calls (return
  addresses 0x3F0E92 / 0x3F0ED9, call bytes checked at install) the probe
  answers `GetDisplayModeList` with exactly one mode. By the game's own
  rules that mode is then selected. Every other caller gets the real list.
  The probe writes nothing to the game's variables or settings; without the
  probe (or at level 1) the saved size is not in the list and the game
  returns to the desktop size (modelled in `tests/test_picture.cpp`).
  * Level 1: unchanged. Level 2 (default): 3840x2160. Level 3: 3840x2880.
    Level 4: 2880x2880 (test). (16:9 monitor; in general 2160 or 2880 lines
    in the monitor's shape, at most 3840 wide.)
  * Per eye (Quest 3, without F7): 1674x1810, 2233x2413, 2233x2413. One eye
    uses 36 % of a 16:9 picture, 52 % of a 4:3 one and 65 % of a square one,
    so level 3 gives what 5120x2880 would give for 25 % less work, and
    level 4 the same again for the cost of level 2. Level 3's 4:3 shape is
    one the game was made for; 1:1 is not (menus/HUD are laid out from
    width/height), hence "test". On the monitor levels 3 and 4 are stretched
    to the window.
  * The level of a run is fixed when the hook is installed (the game lists
    its modes several times). Key: Insert steps the saved level (1-4 beeps
    as feedback; the probe has no on-screen text yet), saved at once as
    `picture_level`, used from the next start.
  * Safety: when the answer is first replaced the start-up marker is
    rewritten with "picture=1". If that start does not reach its first
    frame, the next start writes `gbvr_picture_off.txt` and uses level 1
    (the headset picture itself stays available); the first Insert press, or
    the installer, deletes the file. Markers now carry the writer's process
    id; a marker younger than 30 s whose writer still runs is left alone
    (another process loading the DLL during a start is not a failed start).
  * `PICTURESIZE` (back buffer, the game's own wanted size, runWindowed,
    window client size, swap effect) is logged whenever it changes; `PICTURE`
    and `MOUSE` show the hooks' counters; `STEREOSTATE` now ends with
    picture=, height=, world=, pictureLevel=.
  * The flat screen in the headset keeps 3 m width for 16:9 and is limited
    to 1.75 m height for other shapes.
* **Mouse pointer (mouse.cpp, found by the independent review).** The game
  stores the pointer position of mouse messages (window pixels, read in
  `HandleMessage` 0x4586A0 from its WH_GETMESSAGE hook) in 0x25241BC/C0 and
  uses it as picture pixels (pointer sprite, menu hit tests); `SetCursor`
  0x45CB50 does the reverse with ClientToScreen + SetCursorPos. With a
  picture bigger than the window the pointer would reach only the upper-left
  67 % (level 2) or 50 % of the lines (levels 3/4). The probe hooks
  `HandleMessage` and hands it a copy of each mouse message with the
  position scaled to picture pixels (wheel messages: screen position
  adjusted so the game's own ScreenToClient gives the scaled point), and
  scales the other way in the one ClientToScreen call of `SetCursor` (import
  slot 0x7329A0, return address 0x45CB83). Both only while the sizes differ.
  Mouse look is unaffected: it comes from DirectInput (0x45EF92).
* **World size (Home/End, `world_percent`, default 100).** 0.25 multiplied
  eye height, eye separation and head movement by one "player size" (110 %),
  which makes the world look 9 % smaller. The user wants the height kept and
  the world bigger, so they are separate now: `size_percent` scales only the
  eye height; eye separation and head movement are divided by the world
  size. 100 % = the headset's real eye distance (70.7 mm = 0.232 ft).
* An independent review (separate agent, no knowledge of how the change was
  written) checked the game-side assumptions against the disassembly and
  the new code. Fixed from it: mouse scaling (above), Insert saved at once,
  level fixed per run, Insert after a failed start retries the same level,
  the 2880-line / 3840-width limits (level 3 was 5120x2880), marker details.
* Not tested on hardware: the whole feature. In particular whether the game
  holds 144 FPS at level 2/3 (eye pairs need two game frames per 13.9 ms),
  whether SteamVR accepts a 3840x2880 overlay texture for the flat screen,
  how the menus look at level 4, and the mouse scaling.
* Still open: player model visible in first person (next), F3 feedback,
  HUD/menus in stereo, aim, controllers, MSVC BUILD.cmd untested.

## 23. 0.26 result and probe 0.27: same moment for both eyes, diagnostic picture (2026-10-07)

* `evidence_gbvr_probe_0.26_20261007-205221.log`: the picture level worked
  first time. The game's mode list was answered with 3840x2160 (8 of 16
  game calls replaced = the fill calls; two outputs: 2560x1440 and
  1920x1080 desktops), `CreateSwapChain 3840 x 2160`, window 2560x1440,
  `runWindowed=0`, SwapEffect 0. 12,932 stereo frames, all verified,
  144 game FPS / 72 pairs per second throughout, pair gap 2.7-4.0 ms (it was
  3.1 ms at 2560x1440: the bigger picture costs almost nothing here).
  Flat-screen overlay at 3840x2160: 449 updates, 0 errors. Mouse scaling
  active (7,559 messages, 197 pointer moves). F7 was on for the whole run
  (saved from 0.25): each eye 3090x1810.
  The headset reports 90 Hz but pairs arrive at 72 per second (the frame
  wait paces them): the stream runs at 72. Not looked into yet.
* User: "it looks better"; "the beam of the proton pack and ghost and other
  character look kind of awkward and out of place"; "the world scale is good
  for the most part".
* **Cause found in the main loop: the two eyes showed game moments about
  10.8 ms apart.** One loop iteration (0x1F02A4-0x1F0622, main thread,
  `layout.h`) is: App::Simulate ([vtable+0x108] = 0x1F09C0, with the time
  step the *previous* iteration's tick stored) -> wait for the render thread
  (0x3DDAC0 on the queue 0x1671938; this is where the headset's frame wait
  after a finished pair lands) -> camera prepare (the probe's eye) -> render
  job to the render thread -> App::Tick (frame timer: the step for the *next*
  iteration). So the step measured by the tick after the first eye's prepare
  - which contains the headset wait - moved the world before the second eye
  was drawn. With the 0.26 numbers: second eye 10.8 ms after the first, next
  first eye 3.1 ms after that. A ghost at 20 ft/s was drawn 66 mm apart for
  the two eyes (the eyes are 71 mm apart): every moving thing had the wrong
  depth, and per-update effects (the proton stream's flicker) were different
  pictures. The camera state was shared since 0.24, which is why everything
  static was fine. (0.24's notes assumed 2-3 ms; the pair-gap counter
  measures Present to Present, not game time.)
  Second candidate, F7: the shaders show that particles, the beam and
  characters are ordinary projected geometry (`vparticle.vhl`,
  `vdistortion.vhl` use the normal projection), so non-square pixels cannot
  put them "out of place"; only screen-space effects are squeezed (bloom and
  blur `cSampleOffsets`, depth of field, radial blur, skin blur, HUD
  sprites, metaball slime). No previous-frame matrices in the shader
  constants (no motion blur / temporal AA).
* **Same moment (engine_hooks.cpp, Delete, `same_moment`, default on).**
  Decided by the eye that was just prepared and published (`g_tickRole`, set
  on the main thread at publish; the Present-side phase flag is one frame
  late at tick time - the first version of this fix used it and was caught
  by the independent review):
  * Tick after the **first** eye: the frame timer's "longest frame" limit
    [0xDD6748] (4096 ticks of 1/65536 s; no other per-frame reader) is set
    to 8 ticks for this one call and put back, so every time value the
    engine derives is consistently tiny; the timer's previous-tick time
    app[+0x1AC] is put back, so the tick after the second eye measures the
    whole headset frame (910 ticks at 72 Hz) and game speed is unchanged.
  * The next **App::Simulate** call (hooked, main-loop call site only) is
    left out - as the game's own loop does while paused (app[+0x4A9C1];
    the paused loop also skips 0x282E30 and the fade 0x1F3A60, which the
    probe leaves running): the second eye is drawn from the very same world
    state, including effects that re-roll every update. This also keeps the
    physics from being asked for two 0.06 ms sub-steps (Simulate sets the
    physics rate to 2 * max(30, 1/step) - which is also why the step must
    never be zero). The second review checked that nothing in the render
    stage depends on Simulate having run in the same iteration (the dynamic
    light list is reset at the start of the game update, the render context
    is rebuilt at every prepare, effect pools are submitted per view).
  * **Except while a key release or mouse-wheel notch is waiting** (found by
    the second review). Keys are read only inside Simulate, and the input
    poll 0x45A450 later in the same iteration (main loop 0x1F03F1, after the
    prepare) releases every key marked in the int array 0x2A87180 (600
    entries) and then pumps new messages. Key releases are deferred that
    way and every wheel notch is a pseudo-key (0x20F / 0x210) set down and
    marked in the same message, so it lives for exactly one poll period.
    Leaving out the simulation after a poll that pumped one would lose it
    (about 4 of 5 wheel notches in the loop model; the wheel is bound by
    default, probably next / previous weapon). So the probe reads the array
    (read only) and keeps the simulation when any key is marked; it then
    runs with the short step (eyes 0.12 ms apart for that pair) and the
    timer's previous-tick time is moved on by that step so no time is
    counted twice; the timer's unlimited real step app[+0x1B4] (read by
    some game behaviour callbacks) is set to the same short step for that
    simulation (third review). `SAMEMOMENT keptForKeys` counts these. The loop model
    has key and wheel events: none lost, game speed unchanged, with
    occasional keys more than 90 % of pairs stay exactly equal.
  * Before the Simulate that follows the **second** eye, the probe calls the
    engine's own render-queue wait first (the main loop would call it right
    after the simulation), so the second eye is finished before the world
    moves on, whether or not the renderer reads live objects.
  * Slow motion: the game multiplies ticks by its time scale and rounds
    down; the scale is measured on the normal ticks and the limit raised to
    keep about 8 ticks; below 1/64 the feature is skipped for that pair.
    Never two short ticks in a row; a skip request that is not used within
    one iteration expires.
  * `tests/test_picture.cpp` contains a model of the loop with both hooks
    (world state equal for both eyes, speed = real time, slow motion,
    frames that fail to publish, key releases and wheel notches); `SAMEMOMENT` in the log shows the game's
    step in force at each eye's prepare (second eye must be about 0.12 ms),
    short ticks, left-out simulations and early waits.
  * Cost: the simulation now runs once per headset frame (72 per second)
    instead of twice, and no longer overlaps the headset wait (about 1.5 ms
    later prepare).
* **Diagnostic picture (shot.cpp, shotmath.h, jpegenc.h; F2).** Until now
  every visual problem had to be guessed from a description. F2 takes three
  snapshots 8 headset frames apart - as played, F7 flipped, same moment
  flipped - and writes one JPEG (`gbvr_picture_<date>-<time>.jpg`, 1920 wide)
  into the game folder: the left eye's whole game frame on top (HUD
  included), then three rows left eye | right eye, each eye 960 px wide at
  the same scale in both directions. The switches are put back and not
  saved. The render thread copies the probe's own eye textures into a
  staging texture and box-shrinks them; a worker thread encodes (own
  baseline JPEG writer, standard tables, checked against Pillow in
  `tests/test_jpeg.cpp` + `check_jpeg.py`; the reviewer also decoded its
  output with ffmpeg and Go's decoder) and writes the file next to the log
  (game folder, or the log's Documents fallback). `SHOT` log lines record
  each row's settings and texture bounds. Two rising tones = saved, one low
  tone = nothing saved (menu open, request older than 1.5 s, write error;
  a request that finds no 3D picture is answered after 1.5 s at the latest).
  Each of the three snapshots stalls the render thread for roughly 40-65 ms.
* Not tested on hardware: both new features.
* Still open: player model visible in first person (next), F3 feedback,
  picture levels 3/4 untested by the user, 72 vs 90 Hz, HUD/menus in stereo,
  aim, controllers, MSVC BUILD.cmd untested.

## 24. 0.27 result and probe 0.28: own body hidden (2026-10-08)

* `evidence_gbvr_probe_0.27_20261008-011414.log`: same moment works on
  hardware: `gameStepBeforeSecondEyeMs=0.122` on every pair, the first eye
  sees one headset frame (13.9 ms), 72 pairs / 144 game FPS, simulations
  kept for key releases occasionally (`keptForKeys`), no errors. Two F2
  pictures: with same moment on, both eyes show Slimer and the stream in the
  same state; with it off the stream differs between the eyes. User: "I
  think it looked better".
* The pictures show the next problems: the HUD (money counter, button
  prompts, "Manual Vent") and the aiming reticle are drawn at the same frame
  position for both eyes, i.e. at infinite distance, and the counter at the
  top left is inside the left eye's part of the frame only.
* **Own body (engine_hooks.cpp "Own body", layout.h "Own body", found by a
  research agent, checked by `tests/verify_layout.py`).** The player is a
  CGhostbuster (vtable 0x774440, RTTI checked). Its render function adds the
  body (head included), a shadow-only mesh, the pack attachments, the hose
  and the wand as separate items and asks, for each, the virtual
  "mirrors only" check (slot +0x8C0 = 0xD35D0). The answer goes into the
  item's per-frame draw block; at draw time 0xEEC70 skips such an item
  unless the view is a mirror or the pass is the depth-only pass 8 (shadow
  maps). The game answers true only for the local player in its
  first-person PKE-goggles view. The probe hooks the check and answers true
  for the player's own items while the main loop's active-camera render
  call (0x450DD0, hooked, return address 0x1F1E0A) is collecting the main
  view and the first-person eye was placed in that view's prepare - only
  for the call sites body (0xD2A66), pack (0xD2C97), hose (0xD320F), the
  extra body pass (0x10B79C) and, with F1 mode 2, the wand (0xD343F). The
  PKE meter, which asks the same check, and every other Ghostbuster get the
  game's own answer. Nothing is written into the game; the answer lives in
  that frame's draw blocks only. F1 cycles hidden (2 beeps, default) ->
  wand hidden too (3) -> shown (1); saved as `hide_body`. The hooks are
  checked and installed separately: if anything does not match, only this
  feature is off. `BODY` log lines count hidden items per call site.
* The independent review confirmed the game-side claims (traversal entirely
  inside the 0x450DD0 call on the main thread, no re-entry, bool in al
  stored by every caller, mirror views (+0x180D8) and pass 8 still draw the
  items) and found two log/feedback issues, fixed: hidden frames are counted
  once per main view, and F1 gives one low tone when the hooks are not
  installed. Also applies in desktop first person (F5).
* Known limits (from the research): the body is still drawn into the
  soft-particle depth copy (particles right behind the invisible body may
  fade); the rappelling harness is not covered; the game's own rule that
  skips the player when its own (third-person) camera is within 0.65 ft of
  the player is unchanged.
* Next: HUD and reticle per eye (scale toward the middle, a disparity so it
  sits at about 2 m), then aim.

## 25. Probe 0.29: the 2D overlay placed for both eyes (2026-10-08)

* Problem (0.27 pictures): the HUD - money counter, button prompts, the
  aiming circle, subtitles - was drawn at the same frame position in both
  eye pictures: at infinite distance, and partly in one eye only.
* **How the game draws it** (research agent, `layout.h` "Overlay", checked
  by `tests/verify_layout.py`): on the render job, the camera's Draw
  (0x1FE4D0) draws the 3D scene, then all post-processing (0x41BE90), the
  damage overlay, then HUD::Draw 0x253240 (its only call, 0x1FE64D); menus
  and the fade come later. The overlay is laid out on the main thread in a
  virtual 1280x720 space; HUD::Draw only draws: screen-space quads in
  back-buffer pixels through tlvertex/v4bit, `Pos = (vPos - cScreenCenter.xy)
  * cScreenCenter.zw` from the engine's viewport globals. The only Direct3D
  viewport setter is 0x3F5880(x, y, w, h). The aiming reticle is a sprite at
  the fixed frame centre. The ghost health ring projects the ghost's 3D
  position with the current camera at draw time.
* **Placement (hud.cpp, hudmath.h):** while HUD::Draw runs for an eye
  picture (`stereo_drawing_eye`: the frame published at prepare and not yet
  presented), the probe gives 0x3F5880 a moved and scaled rectangle:
  x' = cx + sx (x - cx) + dx, y' = cy + sy (y - cy); sx = a / tanH,
  sy = (a H / W) / tanV, dx = (-e / D) / tanH * W / 2, with a = tan(30 deg)
  * size% (60 degrees wide at 100 %, limited to stay inside both eyes), e
  the eye's real sideways offset and D = 2.5 m. The lines of sight of the
  two eyes then meet 2.5 m in front of the head (unit-tested,
  `tests/test_hud.cpp`). Sub-viewports (subtitle boxes) move with it.
  Queued text is flushed (0x3D62E0) before each switch. The health ring
  is drawn with the engine's own rectangle (hooked 0x24D810). Every
  rectangle the engine asks for is remembered per thread so it can be set
  again after the overlay. Menus (0x2471F0) are not placed yet.
* Keys: Ctrl+F1 placed / as the game draws it (saved `hud_mode`),
  Ctrl+PgUp / PgDn size in 10 % steps (`hud_size_percent`, 50-200);
  `hud_distance_cm` (default 250) in the settings file. `HUD` log lines:
  frames placed, viewports moved, ring draws, last shift and scale.
* Text size: a 20/720 letter is about 1 degree tall at 100 % - about like
  text on a large desk monitor; 130 % gives 1.3 degrees.
* Independent review (no crash, hang or wrong-viewport finding): confirmed
  every Direct3D viewport goes through 0x3F5880 (Present's own save/restore
  0x3EF360 runs after the overlay, when the rectangle is the engine's own
  again), no scissor rectangles, the overlay shaders never read the pixel
  position, the engine itself flushes text at the start of every
  SetViewport (0x302237), [0x2523EFC] is a "device ready" gate that is never
  0 during play, and the "published, not yet presented" rule also holds in
  the synchronous path and the menu loops. Fixed from it: the per-thread
  rectangle table has 8 slots (the game runs up to 5 job workers plus the
  main thread) and, without a record, falls back to the engine's own
  viewport cache (0x2840D60) read at overlay entry; the overlay size is also
  limited by the headset's real half-views (smallest over both eyes, 5 %
  margin) instead of only the Quest 3 numbers. Cosmetic: the desktop window
  shows the overlay small and shifting a little between the eye frames.
* Not tested on hardware. Known simplification: the ring's on-screen
  position is smoothed by the game toward the previous frame's target (the
  other eye), so it can sit slightly off per eye.


## 26. 0.28 result and probe 0.30: body fully hidden, 0.29 crash fixed (2026-10-08)

* Tester: "body did not fully disappear and could see it when hit by ghost
  in getting back up animation". Evidence: `evidence_gbvr_probe_0.28_20261008-193011.log`
  (0.28, not 0.29) and five F2 pictures (two more attached were the old
  0.27 ones).
* What the log and pictures show (F1 history in the log: 1 -> 2 at frame
  4326 -> 0 at 4540 -> 1 -> 2 -> 0 at 6040 -> 1 at 7000 -> 2 at 7276):
  - The knock-down: FPEYE frames 6222-6588. The game's "Big Hurt" camera
    (distance 4.5 -> 8.0, pivot lower: pivotDist 2.6-3.1 ft, well inside
    the 8 ft gate) - first person never suspended (gateFails=0). The player
    is thrown about 8.5 ft (actor y up to +1.56 ft above the floor) and gets
    up there. The two pictures of it (193134, 193138) were taken with F1 =
    shown (mode 0): the body lying below the standing-height eye.
  - With the body hidden (pictures 193130 mode 2, 193140 mode 1, 193143
    mode 2): no body, pack or hose; left were the wand (mode 1, by design
    then) and a dark furry shape on the floor under the player, at both
    standing places - the player's own shadow (0.28 kept it on purpose).
  - Counters: every main view in first person hid body 4 / pack 3 / hose 2 /
    body2 1 items, notPlayerClass=0, noFollowTarget=0.
* **Call site missed in 0.28/0.29:** the extra body pass 0x10B690 draws the
  body model's `part_thigh_R_0x` piece (sub-mesh actor+0xCE04) as two items,
  and the second one asks the check at 0x10B7FA (return 0x10B800). 0.30
  hides it too; any other return address asking for the player during the
  main view is now counted and logged (`otherCallSites`).
* **Own shadow (layout.h "Own body", checked by verify_layout.py):** the
  answer of the mirrors-only check is stored as a whole byte in the item's
  per-frame draw block and only tested for zero, by exactly four callbacks
  through 0xEEC70 (body 0xD2AC0, pack 0xD2FC0, hose 0xD3290, wand 0xD3520)
  and inline by the extra body callback 0x10F340. The game's rule for a
  flagged item: drawn in mirror views and in pass 8 (set only by the light
  shadow-view renderer 0x4537A0 at 0x45390B). 0.30 answers 2 instead of 1
  when the shadow is to be hidden and hooks 0xEEC70 and 0x10F340: a 2 is
  drawn in mirror views only (0x10F340 returns exactly like its own skip
  path). 0 and 1 go to the game unchanged, so the game's own PKE-goggles
  view is not affected. Known moment: hose and wand set their byte to 1
  themselves for 0.1-0.25 s after the goggles are switched (timer
  actor+0x24D78) - their shadow shows for that moment.
* Defaults: body, wand and shadow hidden. F1 = hidden / shown (2 / 1 beeps),
  Shift+F1 = wand hidden / shown, `hide_shadow` in the settings file. Saved
  `hide_body=2` (0.28/0.29 "wand too") is read as 1.
* **0.29 crash (found while building 0.30):** the cross-built 0.29 DLL called
  msvcrt's `floor` (hudmath.h round_i) through the import table: the
  import library offers `floor` only as data, lld auto-imported it with a
  runtime pseudo relocation that nothing in this freestanding DLL applies,
  so the four `call floor` went to the IAT slot (`call 0x180021410
  <__imp__vsnprintf+0x8>`) - an access violation the first time the overlay
  was placed (first eye frame with F4). The linker warning was overlooked.
  Fix: round_i written out (unit-tested against floor), and the link now
  uses `--disable-auto-import --disable-runtime-pseudo-reloc`, so such a
  reference fails the build. The 0.30 DLL imports only `_vsnprintf`,
  `memcpy`, `memset` from msvcrt, all through thunks.
* Independent review (no crash, hang or corruption finding in the new hooks
  or in hud.cpp): confirmed the six stores, the four callers, the callback
  registrations, MinHook relocation of both prologues, pass 8 = light shadow
  views only (never mirror views), no depth pre-pass using it. Fixed from
  it: log text said "shadow hidden" even when the shadow hooks were not
  installed; a Present that does not reach the eye handling now marks its
  frame as taken (otherwise the overlay could stay shrunk on flat frames).
* Not tested on hardware.

## 27. 0.30 result and probe 0.31: world size 115 % (2026-10-08)

* `evidence_gbvr_probe_0.30_20261008-221912.log`, three F2 pictures. Tester:
  "player gone"; asked whether the body staying hidden while knocked down
  is intended (yes); "scale world larger".
* 0.30 on hardware: no crash (the 0.29 overlay crash is gone), clean exit.
  Overlay placed on every eye frame (`placed` = hidden frames, scale 0.227
  = tan 30 / 2.54 with F7 off, shift +-10.7 px). Body: every first-person
  main view hid body 4 / pack 3 / hose 2 / body2 1 / body2b 1 / wand 2
  items, otherCallSites=0, shadow draws skipped (`drawSkipped shadow` grows
  about 12 per frame), extra body skipped in some main passes, mirrorKept=0
  (no mirrors in this level). A knock-down (FPEYE frames 13481-13847, Big
  Hurt camera distance 8.0) passed with the body hidden and no gate
  failure. 135-144 game FPS.
* The tester has never changed the world size (no settings file; 100 %
  since 0.26, 91 % in 0.25). 0.31 changes only the default to 115 % (eye
  separation and head movement / 1.15); Home / End still adjust it in 5 %
  steps and save it. The "no settings file" log line now lists the
  defaults in use.

## 28. Probe 0.32: head aim (2026-10-11)

Source of the facts: static analysis of ghost.exe (layout.h "Aim direction",
checked by tests/verify_layout.py, 13 new checks) and, independently, the
ChatGPT 0.27..0.32 source (`EngineAim.h`, `TrackedAim.h`, `Probe.cpp`
`aimFieldSetHook`), which found the same store and the same hook point.

* Every shooting actor has a unit vector `iAimDir` at actor+0xB584 (default
  {0,0,1} at 0xDD4F40; the getter 0x76E80 falls back to it). The player-aim
  code (functions around 0xD9FD0 / 0xDAD30 / 0xDB5xx; strings
  processPlayerAim, ...2, ...3) smooths `aimHeading` (+0x24870) and
  `aimPitch` (+0x24898), turns them into a direction with the Euler->matrix
  function 0x3DD40 (forward column of the matrix = elements 2, 5, 8) and
  stores it through the wrapper 0x76DC0 (8 call sites). The wrapper adds
  0xB584 to the actor, skips the store when the vector is not unit length or
  equal to the stored one, otherwise jumps to the real store 0x76D20.
* The proton stream update (0xE6360) reads it through the getter (call at
  0xE659A) and, without a lock-on target (actor+0xB550 == 0), ends the stream
  at muzzle + aim * 100 ft ([0xDD2DD0]); with a lock-on target it uses the
  target's position. The getter has 17 call sites in all (4 in the stream
  update, the rest between 0xAB000 and 0x1B4000); none is in the camera code
  (0x1F0000..0x460000), so the camera cannot feed back into the aim.
* 0.32: hook 0x76D20 (16-byte check; callers and the stream read verified).
  The vector it receives for the PLAYER actor is replaced by the forward
  column of the last headset view (level game yaw x head rotation = the
  basis the probe gave the engine, `g_armOut`). The player actor is the
  follow target of the camera that produced that view if its vtable is
  0x774440 (CGhostbuster), the same test the body hiding uses. The view is
  accepted for 250 ms. Not published when the camera does not follow the
  player (cut-scenes), when the headset view is off, or when the feature is
  off (Shift+F2, settings `head_aim`): the game's own vector then passes
  through, and because the wrapper compares against the stored value the game
  overwrites ours on its next store. The game's calculation, smoothing,
  lock-on and hit tests stay its own; the only change is the argument of its
  own store function. Default on.
* Parallax: the stream starts at the (hidden) wand and runs parallel to the
  head direction, so it meets the line of sight only at a distance. Not
  corrected in 0.32; the muzzle position is in the stream update (0xE6360,
  [rbp+0x3D0..]) if the hardware test shows a need.
* Log: `HEADAIM first override ...` (game vector vs head vector), and every
  180 frames `HEADAIM ... published= playerStores= replaced= stale=
  lastGameVsHeadDeg= worstDeg=`. `replaced` growing while firing = working.
* ChatGPT v0.89 package reviewed (see section 29).

## 29. ChatGPT v0.89 package: what was reviewed, adopted, not adopted

Reviewed: Ghostbusters_VR_v0_89 hotfix/easy-install/continuous-work source.

Adopted (as facts, re-verified against ghost.exe before use):
* The game reads its Xbox pad through XInput 1.3 (GetState, SetState,
  GetCapabilities) and its aim through the stored aim vector.
* Control mapping ideas (stick = move, second stick = turn, trigger = fire,
  face buttons as the game's A/B/X/Y).
* Pointers to the live player resolver (0x2322AD8 / componentId 0xE366F8 /
  resolver 0x2D5A00), camera sphere sweep, inventory and rumble code, kept
  as future leads (not used yet).

Not adopted: the PowerShell setup hub, bundled third-party mods, and the
on-machine compiler download. Reason: this project ships one small DLL with
its source, a plain install/remove script and nothing that downloads or
modifies other software.

A bridge that only hooks XInputGetState would not make the game see a pad:
the game calls GetCapabilities first (0x45D7B0 -> 0x45D7E9) and stops if that
fails. 0.33 therefore redirects all three imports.

## 30. 0.33 Quest controllers

* Import address table slots (verified in the import directory, tests/
  verify_layout.py): 0x732D78 XINPUT1_3 ordinal 2 GetState, 0x732D80 ordinal 3
  SetState, 0x732D88 ordinal 4 GetCapabilities. The game calls them through
  `jmp [slot]` thunks at 0x546514 / 0x54651A / 0x546520 (GetState called from
  0x45D81A, 0x45FAB1, 0x4604D9; SetState from 0x4601A4; GetCapabilities from
  0x45D7E9). The slot contents are compared with GetProcAddress(xinput1_3,
  ordinal) before patching; any mismatch leaves the game untouched.
* src/controllers.cpp (render thread, right after the headset pose): reads
  both controllers with GetControllerStateWithPose, builds the pad state
  (src/padmath.h), converts the poses into the head's engine-local frame
  (headtrack.cpp vr_pose_to_engine_local) and publishes one snapshot under an
  SRW lock. src/xinput_bridge.cpp (game thread) only reads that snapshot.
* Mapping: left stick move, right stick turn, right trigger fire (RT), left
  trigger LT, right A = A, right B = B, left X = X, left Y = Y, left stick
  click = LB, right stick click = RB, right grip + right stick = D-pad, left
  menu + left grip = Start. Touch face buttons arrive as button ids 7 (A/X)
  and 1 (B/Y) per hand; this is an assumption. The first press of every
  button id is logged (`CONTROLLERS first press of button id ...`) to correct
  the mapping after the hardware test.
* A real pad still works and is merged. Rumble: the game's motor speeds become
  a haptic pulse (<= 3999 us) on both controllers each frame while requested.
* Aim (head_aim setting renamed aim_source): 0 mouse, 1 head, 2 hand (default).
  Hand = right controller forward column, tilted by hand_pitch_deci/10 degrees
  (Shift+Home/End, 2.5 degree steps); both grips held and hands >= 12 cm apart
  = line from right hand to left hand. The controller must be fresh (120 ms),
  else the head direction is used. Same store hook as 0.32.
* Not hardware-tested. Open questions for the test: button ids, whether the
  controller forward axis needs a tilt, whether the game keeps the pad after
  the headset is put on.

## 31. 0.33.1 crash fix
0.33 crashed at F4: the log ended after the HUD line of the periodic report, where
controllers_report() should have followed. Cause: `Snap s;` was left uninitialised
when no snapshot existed yet; clang treats the later use as undefined behaviour and
emitted no `ret` on that path (disassembly ended with a call, execution fell into the
next function). Fix: every Snap is zero-initialised and read_fresh() clears its
output first. Lesson: never read a local that a failing path leaves unset; check
disassembly for functions that end without ret/jmp.

## 32. 0.34 hands, wand and the stream start
Hardware result of 0.33.1 (user): controllers work as the pad (getCaps/GetState faked, sticks, cut-scene skip),
the beam follows the right hand (the "flashlight" they saw was the hidden wand's light), but no wand and no
hands were visible: the game's wand is hidden on purpose (hide_wand) and the body too, so nothing replaced them.
Button ids seen: 2 grip, 33 trigger, 34 grip analog, 7 A/X, 1 menu (B/Y), 32 stick click.

* Own models: src/handmath.h (pure geometry and the head/controller/eye transform, tests/test_hand.cpp) and
  src/handmodel.cpp (Direct3D 11). stereo.cpp calls handmodel_draw() right after each eye picture was copied
  into g_eyeTex: the hands are drawn into the COPY, never into the game's back buffer. Own depth buffer, own
  states, all pipeline state it touches saved and restored; shaders compiled at first use with
  d3dcompiler_47.dll (LoadLibrary), HANDS log lines say why if that fails. Eye space = engine axes, point =
  S * (Rh^T (Rd p + td - th) - eyeOffset); projection x/(z tanH), y/(z tanV) with the tangents the game
  rendered the picture with (StereoFrame.tanH/tanV). Real-metre scale (not the world-size setting).
* Stream start: 0xD3C90(actor, out[16], name) returns the world matrix of an attachment of the player's model.
  The stream update asks for "tip" at 0xE63F7 and reads the translation (floats 12..14 = [rbp+0x3D0..]) as the
  muzzle; every later use in the function derives from it. 0.34 hooks 0xD3C90 and, for the player's actor and
  the name "tip" while the hand aims (aim_source 2) and the sample is fresh (250 ms), replaces the translation
  with the wand tip in game world feet: headCenter + feetPerMetre * (view * tipInHeadAxes). headCenter and
  feetPerMetre (= 3.2808 * world factor) are computed in the stereo gate (ArmStereo.headCenter/feetPerMetre).
  Rotation rows untouched. Callers verified: 0xCBB38, 0xE2D41, 0xE2E88, 0xE63F7, 0xE78E0, 0xE833F.
* Log: HANDS first draw / HANDS frame=... draws= ; TIP first override ...; TIP frame=... overridden= lastMovedFeet=.
* Not hardware-tested. Offline check: tests/test_hand.cpp and a software render of the meshes (checked by eye).

## 33. 0.35 input probe (why the stream does not fire)
Hardware result of 0.34 (user): wand and hands visible and following, beam follows the hand, but the gun never
fires (also not in 0.33.1, so not a model problem). Static findings:
* 0x45FA90 stores LT/RT as floats at pad+0x50/+0x54 and sets controls 4 (LT) and 5 (RT) when > 0.3
  (0x737738); pad array 0x2A88EF0 stride 0x6C0, control state dwords at pad+0x138+4*control.
* Game-side getters over the array behind the pointer at 0xDD36D8: 0x297160 (pressed once, clears edge),
  0x297230 (held and not just pressed), 0x297290 (held). Their direct callers use controls 0-8 and 0x1C-0x1F.
  The other getters (0x45BE20/45C1C0/45C210/45C270, input-context actions with a pad index at +0x1C) have no
  direct references - bindings are per action and loaded from the profile (names eControl..., 0x7BEF40 table).
* The stream update 0xE6360 runs every frame and only fetches the tip; the fire decision is elsewhere.
* The user saw "a flashlight" earlier: the player may simply not own the proton gun at that point of the
  campaign. Not proven.
0.35 therefore only observes: the three getters are hooked (counts of asked/answered per control) and the pad
array is sampled; log lines BTNPROBE and PADMEM. Next step depends on what they show (is control 5 asked
for? answered yes? is the pad array holding the bit?).

### 33b. Result of 0.35 and 0.35.1
0.35 log (user held every button 3 s; blue light on the wand, no fire): PADMEM shows pad0 state=2 type=1,
control mask 0x20 (= RT, control 5) and rt=1.00, so the game receives RT. The probed getters
0x297160/0x297230/0x297290 are NOT used for gameplay (0x297160 asked only ~2x per control at start, held getters
never). The 0xDD36D8 pointer is not one of the four pads. So the fire code reads the pad through another path
(input-context action getters at 0x45BC50.. with pad index at ctx+0x1C, or the analog floats pad+0x50/54).
0.35.1 adds PADWATCH: guard pages on the two pages of pad 0, VEH single-step, three 3 s windows (frames >= 1200,
>= 1500 apart); the log lists the RVAs of the code that touched pad+0x40..0x240 with read/write counts.

### 33c. Result of 0.35.1 and 0.36
PADWATCH (3 windows, user walking and holding RT): in windows 2 and 3 the only code touching pad 0 was the
poll itself (0x45FA90 and the helpers 0x45CAA0/0x45BAB0); in window 1 only the "any button pressed" scan
(0x45CDB0). No gameplay code read the pad. The controls menu (0x217300) shows the controller type is a setting
at [[0xDCF680]+0x49200] (getter 0x1F4D40, setter 0x1F4D50; 0 mouse+keyboard, 1 gamepad, option strings table
0xDD0328). With type 0 the game uses keyboard/mouse for play. 0.36 logs the type (CONTROLTYPE) and, when the
controllers are active and the type is 0, calls the setter with 1 (up to 3 times). Unverified on hardware.
Earlier belief that "the controllers move the character" was likely keyboard movement.

### 33d. Result of 0.36 and 0.37
0.36 log: the setter worked (CONTROLTYPE 0 -> 1, result=1) and with type 1 the right stick turned the player
(HEADAIM lastGame changed while R stick was deflected), so pad -> game works. Fire still does nothing.
Structure learned: 0x296D70 is the per-frame update of the merged ("virtual") pad = pad slot 4 behind the pointer
at 0xDD36D8: per control it ORs the edge flags (+0xA4) of the active physical pad (only if pad state != 0 and the
input manager 0x1423229C0 vtable+0x200 index equals that pad) and the keyboard keys (0x4033C0 key query), then
writes the control through 0x45CAA0. Camera code reads its axes directly from the virtual pad (+0x4C/+0x58).
Control bindings (eControl 0..49, names table 0x7BEF40: 0 Primary Action, 1 Secondary, 2 Trap, 3 Interact,
4 Jump/Evade, 5 Vent, 6 PKE, 7 Capture Stream, 11 Proton Equipment, 48/49 next/previous weapon) live in
the settings object at +0x49204 + 0x4D0*player + 0x18*eControl. 0.37 dumps them (BINDINGS), logs the virtual pad
(VPAD) and watches it for readers (PADWATCH) to learn which control fires and which code reads it.

### 34. Prepared for 0.38 (not shipped yet, source only)
* handmath.h two_hand_pose(): with both grips held the drawn wand lies along the right->left hand line (same
  line the beam uses), rolled like the right controller; tests/test_hand.cpp covers it (ALL PASS). Wired into
  handmodel.cpp. Built into build/0.37 on disk but the delivered 0.37 zip does NOT contain it.
* Holster (padmath.h holster_hit/Holster, controllers.cpp, handmodel.cpp): right grip squeezed with the right hand
  within 16 cm of the hip point (22 cm right, 55 cm below the head, head-yaw frame) toggles holstered; while
  holstered LT/RT are forced 0 and the wand is not drawn; haptic click + HOLSTER log line. Off by default
  (setting holster, Ctrl+F11 2 beeps on / 1 off). tests/test_pad.cpp covers the zone and the toggle.
  src is version 0.38 (build/0.38 on disk, not packaged/sent).
* Next offline candidates: (holster done) (right hand at the hip: wand hidden, trigger ignored), grab/pick-up
  logic, main-menu in stereo. All wait for the fire-button answer from the 0.37 log.

## 35. 0.40 binding update hook (why the stream does not fire)
Read from the second 0.37 log (type forced to gamepad, RT held for thousands of frames, no firing rumble afterwards):
- BINDACTIVE sampled zero for 6271 frames although pad 0 held controls 4/5. The sampler read binding state from the render thread; the game's own queries only exist inside the game tick, so the zeros do not prove anything.
- Binding update = 0x1FC240(block, dt). block = 50 x 0x18 bytes at settings+0x49204 (+0x4D0 per player); [+0xC] state (0 idle, 1 held, 2 just released), [+0x10] hold time, [+0x14] analog 1.0. Pad bindings (type 1): dl = pad[+0xA4+4*ctrl] (value of the last change), r8b = pad[+0x1B8+4*ctrl] (previous), then 0x1FB9E0 moves the state machine (idle->1 only when previous was 0).
- Queries: 0x1FC5C0 state==1, 0x1FC5F0 state==2, 0x1FC620 state==1 and hold time 0 (just pressed).
- The block caches the controller type at +0x4CC; the settings object keeps it at +0x49200.
- 0.40: hook 0x1FC240; after the original runs, write state 1 / hold / analog 1.0 for Primary (0) while RT > 60 and Secondary (1) while LT > 60; re-run the setter whenever the global type is 0 (every 90 updates). Log BINDUPD (per-block calls, cached type, pad slot, natural state counts) and BINDQ (ask/yes per control for the three queries, player-0 block only).
- Open question for the 0.40 log: is the gameplay block the settings player-0 block? (BINDUPD lists every block seen.)
- Checked statically: the player code at 0xDC054 (the one that sets actor+0xC7A8 bit 0x40 = primary fire, 0x200000 = secondary) takes its binding block from settings+0x49204 (+0x4D0*player) and asks through 0x1FC5C0/5F0/620 with index 0 / 1. 0.40 therefore also answers those three queries directly for player 0, index 0/1, while the VR trigger is held (so firing works even if 0x1FC240 never runs on that block); on release the state goes 1 -> 2 -> 0 like the game's own.
- 0.40 result (log 140637): hooks all installed, player-0 block found (cachedType=1, padSlot=0), the game asks about control 0 (Primary) ~1500-1900 times, natural state never set (natState0=0). But forcedFrames=0: bindings_sample() receives 0/1 booleans from controllers.cpp and compared them with > 60. Fixed in 0.40.1 (!= 0).

## 36. 0.41 stream direction and two-hand tip
0.40.1 log: fire works. Remaining: inaccurate, and from the head with both hands.
- The beam is drawn along the rotation of the "tip" attach matrix (0xD3C90), which comes from the game's animation (follows the camera); 0.34-0.40 only replaced its translation. 0.41 learns which row of the matrix agrees with the game's own aim (last value seen by the aim store hook, >0.8 mean over 240 samples, next best 0.3 lower), then rewrites that row to the controller aim (tipmath.h, tests/test_tip.cpp) and turns the other rows with it. Log: TIPROT.
- head_aim_publish used the single right-hand pose for the tip even in the two-hand pose; it now uses the same pose as the drawn wand (two_hand_pose, pitch 0).

## 37. 0.42 VR menus and exit
- Menus already switched to a flat screen (stereo.cpp: SteamVR overlay "gbvr.flatscreen"), but nothing could operate it: no controllers (poses invalid there) and no mouse. 0.42 sets the overlay input method to Mouse (scale 1x1, discrete scroll), polls PollNextOverlayEvent and posts WM_MOUSEMOVE / WM_*BUTTON* / WM_MOUSEWHEEL to the game window (menu.cpp). The game's HandleMessage (0x4586A0; WM_MOUSEMOVE stores x,y from lParam when msg.hwnd is the game window; button messages set the mask at 0x1425241C4) already receives them through the WH_GETMESSAGE hook, and mouse.cpp scales window pixels to picture pixels. SteamVR counts y from the bottom (VREvent_Mouse_t); Ctrl+F12 (menu_flip) reverses it if that proves wrong.
- While the flat screen is up the forced gamepad type (controller_type_tick and the binding update hook) is not applied: the game itself switches to type 0 for menus and the pointer needs it. Log lines: MENU click..., MENU pointer events....
- Exit: vr_exit_cleanup now clears the last submitted frame and hides the overlay, waits 150 ms, shuts SteamVR down, then waits another 250 ms before TerminateProcess; EXIT +N ms lines give the timing. CHECK_FREEZE.cmd collects Display 4101 / nvlddmkm / Kernel-Power 41 / WHEA / LiveKernelEvent entries so a driver reset can be told apart from a SteamVR scene change.
- 0.41 double-check: tipmath::Learner (row choice) and rewrite_row are unit-tested (tests/test_tip.cpp). From the 141301 log: control 0 queried 4229x held, answered yes 1822x; forcedPress 53 (RT) / 19 (LT).

## 38. 0.43 frame rate, menus, resolution
Evidence (all logs 0.27-0.42): VR frames 144 per second = 72 pairs, FRAMETIME p99 never above 14.4 ms, WaitGetPoses ~6.9 ms of every 13.9 ms pair (the game needs ~7 ms, the rest is the compositor's wait). Pair period is exactly 1/72 s, the headset property says 90 Hz, and in 0.18.2 even the desktop swap chain (syncInterval 1) ran at 72. The game's work fits in 11.1 ms; the 72 comes from outside the game (Virtual Desktop's own streaming refresh rate is the prime suspect). Nothing in the probe can set that, so 0.43 only proves it: `COMPOSITOR` (vr_capi_timing_report: GetFrameTimings median vsync interval, headset property Hz, frames per application frame, dropped / reprojected, GPU ms, cumulative stats, steamvr settings read-only), `PACING` (pairs per second over the report interval, game work per pair = time from WaitGetPoses return to submit, count over 11.1 ms), `RATE NOTE` / `RATE OK`.
- Menus at 30 FPS (33.33 ms p50 in every menu FRAMETIME, lockTo30Hz = 0): App constructor 0x1ED181/0x1ED188 sets app[+0x4A9C0] = 1 and app[+0x4A9BC] = 30.0f; App::Tick 0x1F1C46 replaces its fps argument with that value while the byte is set. The main loop (0x1F05D0) clears the byte around the tick only when `sil` (running, not paused, no menu) holds, so menus / pause keep the 30 cap. hk_app_tick clears the byte for the one call when the VR view is active (setting menu_fast, default 1) and the game passed 120, then sets it back; counter menuTicksLifted in PAIRCOUNTS. verify_layout.py checks the three instruction sites.
- Resolution: default picture level 2 -> 3 (3840x2880, per eye 2233x2413 without F7, recommended 2496x2688, panel 2208). Level 2 pairs gap stayed 2.7-4.0 ms against 3.1 ms at 1440p, so the GPU is not the limit. settings.cpp: `settings_rev` 43; a file from an older version holding level 2 is moved to 3 once (an explicit 1/3/4 is kept). If the level 3 start fails the old picture-off safety net applies.
- Not testable here: everything (needs the headset). Expected check: PACING pairsPerSecond equal to COMPOSITOR measuredVsyncHz when the work stays under one period.

## 39. 0.44 fail-safes and evidence
Goal: every new risk (picture level 3, menu tick change, compositor calls) must either be harmless or leave a precise record and undo itself.
- Stages (safety.cpp, gbvr.h): `g_stageR` (render thread: present-enter, keys, session, head-tracking, report, before-present, acquire-back-buffer, copy-eye, hand-model, submit, flat-screen, menu-pump, real present, after-present, wait-for-steamvr, controllers, timing-report, exit) and `g_stageG` (last game hook entered: tick, simulate, prepare, aim, tip, binding update, HUD). Plain volatile stores. Shown in CRASHWHERE, STALL, HEALTH, STATE and in the run marker.
- Crash note: crash_note (VEH, first 4 faults) additionally logs CRASHWHERE (stages, rip/rsp/rax/rbx/rcx/rdx/rsi/rdi/r8/r9) and calls safety_on_fault: gbvr_last_crash.txt + marker `fault=1; stage=...`.
- Run marker `gbvr_run.txt` (log folder): written by safety_run_begin when the headset session is requested, `exiting=1` when vr_exit_cleanup starts, deleted at the end of a clean close. `gbvr_health.txt` (`count=N`): bad headset runs in a row; written at start from the leftover marker, deleted by a clean exit, by Insert, or by INSTALL. safetymath.h `plan()` = ladder: 1 menu_fast+diag_timing off; 2 picture <= 2; 3+ picture 1 and hand_model off; evidence rule: a leftover marker only counts as a bad run if it records a fault, recorded serious issues (`issues=`), or the PC restarted since (GetTickCount64 vs marker time); exiting=1 without fault is logged, not counted; a plain kill from Steam is logged as 'simply ended', not counted; a marker whose pid is alive is a second running copy: untouched. With no marker but count > 0 the step-back is applied again (idempotent) in case the settings were not saved before the run died. Settings changed by the ladder are saved (settings_changed).
- Runtime fallbacks (all once per run, setting auto_quality, default 1): eye textures cannot be created 3 times at level >= 3 -> level 2; 20 submit errors and no accepted picture at level >= 3 -> level 2; PerfWatch (safetymath.h): 5 reports in a row (about 6 s) with pairs/s < 85 % of the measured compositor rate, >= 100 pairs in the interval, no menu frames, average frame-wait under 2 ms (the game, not the compositor, is late) -> level 2. Needs diag_timing (measured rate).
- menu_fast guard: after every lifted menu tick the raw step (app+0x1B8 x 65536) must be 1..70000 ticks; three misses switch menu_fast off for the run and save it (raw step, because the scaled value is 0 while paused).
- Present failure: hk_present logs PRESENTFAIL with GetDeviceRemovedReason (first 8) and counts IS_PRESENT_FAIL / IS_DEVICE_REMOVED; a removed/reset device also writes the crash note. VRAM line (IDXGIAdapter3::QueryVideoMemoryInfo) every 8th report, flagged above 92 % of the budget.
- Heartbeat thread (safety_start_heartbeat): every 2 s a flush through a second file handle (log_flush_quiet; a flush on the writing handle would hold up the render thread); every 1 s a Present-progress check -> STALL line at 5, 10, 20, 40 ... 640 s with the stages, and "STALL over" when frames resume.
- Log: cap 60000 -> 150000 lines, after the cap lines starting CRASH / SAFETY / STALL / PRESENTFAIL / EXIT / HEALTH / STEREO off / RATE still get through (5000 more); extra fallback folder %TEMP% when neither the game folder nor Documents is writable; the log file is opened with share-write so the flush handle can open it.
- HEALTH line per report: counters presentFail, deviceRemoved, textureFail, submitFail, overlayFail, waitFail, poseInvalid, stalls, faults, menuFastOff, perfFallback, pictureFallback, vramHigh + stages + runCount.
- COLLECT_LOGS.cmd -> gbvr_manager.ps1 -Action Collect: newest 3 logs from the game folder, Documents\GhostbustersVR_logs and %TEMP%, marker / crash / settings files, the freeze report if present, Windows Display / nvlddmkm / Kernel-Power 41 / WHEA events (3 days), graphics driver -> one zip on the Desktop. Check also reports leftover run/health/crash files.
- Tests: tests/test_safety.cpp (ladder, PerfWatch, stall schedule, marker round trip, menu step sanity) ALL PASS. Not testable here: PowerShell Collect action (no pwsh), everything on the PC.

## 40. 0.45 stream axis, pack vent, flat view, flat rate
Evidence: 0.44 log (user run 2026-10-11 15:29) + Medal TV video. Symptoms: stream always flies to the right, two-hand hold changes nothing, blast never reaches ghosts, flat picture stretched, "still 72 fps".
- Stream axis (root cause of "right only"): stream update 0xE6360 -> tip matrix T from 0xD3C90 (our hk_attach_matrix), 0x2C7940 orthonormalises T with ROW 2 as the master axis (loads [rcx+0x20..0x28] first), local hit point = hit * inverse(T) (0x2C7190), normalised (0x1D4F0), angles from 0x31FFC0 (out[1] heading = atan2(x,z), out[0] pitch = -atan2(y,hypot(x,z))), clamped +-pi/2 (0x73FC98/A0), faded linearly between 30 and 60 degrees (double 0x764490 = pi/6), zero beyond; 0x3DD40 builds the angle matrix and the end point = (sinH cosP, -sinP, cosH cosP)*len through T. 0x3220A0 (angles -> vector) and 0x2C6BE0 (matrix -> euler: pitch = -asin(m[9]), heading = atan2(m[8], m[10])) confirm +Z = row 2 = forward. So the controller aim has to go into row 2. 0.41 learnt "-row0" from the idle pose (mean 0.922) and rewrote row 0, leaving row 2 about perpendicular to the aim: stream sideways (right), and the damage path (stream capsule / particles along the stream) never met a ghost. 0.45: tip_rotate = tipmath::rewrite_row(m, 2, +1, aim) from the first player tip call (no learner; Learner stays in tipmath.h, unused). tests/test_tip.cpp now also checks that after the rewrite the aim measures heading 0 / pitch 0 in the tip frame for 40 random poses.
- Evidence hook: MinHook on 0x31FFC0 (kBytesVecToAngles), counts only calls whose return address is 0xE6BEE (the stream update): log STREAMANG (within5 / within30 / within60 / beyond60, last heading / pitch, worst, last local vector); TIPROT now `row=2 applied failed`. If the fix is right, within5 should dominate while firing.
- Vent: game control 5 = Vent = pad button 7 (RB, 0x0200) per BINDINGS(type=1); stick click already mapped. New gesture (padmath.h pack_hit, controllers.cpp): a hand behind (0.22 m) and below (0.15 m) the head, radius 0.26 m, in the head's yaw frame, with its grip squeezed -> RB held; haptic tick on entering the zone, VENT started / stopped log lines, VENTGESTURE counters; setting vent_gesture (default 1). tests/test_pad.cpp checks both shoulders, chest, hips, turned head, looking down.
- Flat view (flatview.cpp, picturemath.h fit_view / view_to_picture / picture_to_view): level 3 is 3840 x 2880 because the width is capped at 3840 (picturemath.h level_size); the window is 16:9 and the windowed DISCARD swap chain (3840x2880, 2 buffers, format 28, 1 sample) is stretched over it. Before the game's Present (not while stereoActive): CopyResource back buffer -> own texture, clear to black, draw it with a SV_VertexID triangle into the centred rectangle whose stretch by Windows gives the right shape (viewport in back-buffer pixels = view * back / client). State saved / restored (RTV x8, DSV, viewport, RS, blend, depth, IA layout / topology, VS / GS / HS / DS / PS, PS slot-0 SRV and sampler); a fresh RTV per frame, no reference to the back buffer kept (ResizeBuffers is not blocked); 3 failures switch flat_view off. mouse.cpp maps pointer positions through the view only while the pass really drew in the last 500 ms (flatview_get_view); wheel messages and the game's own pointer moves go through the same mapping. Setting flat_view (default 1). Log FLATVIEW.
- Flat rate: 0.44 flat FRAMETIME showed syncInterval=1 with presentWaitAvgMs ~10 and exactly 72 fps (video overlay: 71-73 FPS, later 144-145 = refresh or half of it); menus 28-30 FPS (33.3 ms p50). Now hk_present sets sync 0 outside the headset (setting flat_vsync_off, default 1) and hk_app_tick's menu lift (clear App+0x4A9C0 for the one call) also runs in flat mode when flat_vsync_off is on.
- Headset rate (log 0.44, 4860-5040): compositor presents 88 / s, app submits 60 / s, reprojected 28 / s, pairs / s 60-70.5, work 7.8-9.0 ms, wait 5.9-8.8 ms, appGpuMs 6.2-7.6, display 90 Hz: so VD is at 90 now and the app is the limit. Period 14.7 ms ~ 68 % of frames at 11.1 ms + 32 % at 22.2 ms (SteamVR motion smoothing stepping down). CPU ~8.5 ms per pair (two game frames; the second-eye simulation is already skipped) + GPU tail does not fit 11.1 ms. vr_capi_timing_report now takes frame time differences in either order and adds per-second presents / submits / reprojected / dropped from the cumulative stats (perSecond(...)); stereo.cpp RATE NOTE uses presents per second when the measured vsync is unknown and prints RATE ADVICE (steady rate = highest of 120/90/80/72 with 1000/R >= work + 4.5 ms). PerfWatch still uses only the strictly measured rate and needs a frame-wait under 2 ms.
- Not testable here (no Windows / headset): the stream direction in game, the D3D flat pass, the mouse mapping, the haptics. verify_layout.py: 8 new checks for the stream code (all PASS on ghost.exe).

## 41. 0.46 why no pad button except the triggers ever worked (log 0.45)
- Evidence: BINDQ "held" over five logs: only controls 0/1 (Primary/Secondary, which we force) ever answered yes; Vent (5 = [1,7] = pad button 7 = RB), Capture (7), Jump, Interact, Trap, PKE, D-pad actions never, although PADMEM showed held=0x80 while the vent gesture was on and VENT started/stopped lines were logged.
- Mechanism (ghost.exe): the pad poll 0x45FA90 (XInputGetState via thunk 0x546514) copies held [pad+0x138] to previous-held [pad+0x1B8], sets the new held and, only on a change, the edge/latch flag [pad+0xA4] (helper 0x45CAA0). Pad = array 0x2A88EF0, stride 0x6C0, slot = block+0x4BC. The binding update 0x1FC240 runs per player block; for an action with kind 1 it calls 0x1FB9E0(entry, down=[a4]!=0, wasHeld=[1b8]!=0, dt): when the action is not yet state 1 and wasHeld is set the press is dropped. Entry layout (stride 0x18): +0 kind, +4 button, +8 alt, +0xC state (0 idle, 1 held, 2 just released), +0x10 hold time, +0x14 analog.
- In VR the pad is polled more than once per simulation step (two eye frames per pair, one skipped simulation), so the second poll sets wasHeld before the binding update ever sees the press: every native press is lost. Only forced Primary/Secondary worked.
- Fix: padmath.h game_button_mask (XInput bits -> game button numbers: 0 Y, 1 B, 2 A, 3 X, 4 LT, 5 RT, 6 LB, 7 RB, 8 Start, 9 Back, 10/11 stick clicks, 28 left, 29 right, 30 up, 31 down); controllers.cpp calls bindings_pad each poll; hk_bind_update (player 0 only, pad enabled, not flat mode) restores the pre-update state of every kind-1 action >= 2 and writes held / released / hold time itself (a press shorter than one update is latched once). Log: BTNFORCE (presses/frames per action), BINDQ yes counts.
- Unknown until tested: whether the game only vents when the pack has heat.

## 42. 0.47 head position on by default
- headMove (F3) existed since 0.21 but defaulted off. Checked the consumers: eye = base + level*headFeet (stereomath eye_position, headFeet = playspace offset from the recentre point, clamped to 1 m, scaled by world factor); the wand tip (engine_hooks aim publish) uses st.headCenter, which includes the same headFeet, plus the hand pose relative to the head; the hand model and the vent / holster zones are head-relative. So eye, wand, tip and stream stay consistent when the head moves. Setting head_move (default 1), F3 now saves it. The game's body does not follow, no collision for the eye.

## 43. 0.48 data collection
- ACTORSNAP/ACTORDIFF: 0x2000 bytes of the player actor copied when idle (400 calls), firing (200), venting (100), idle again; diffs of firing/venting vs idle (raw, then without the dwords that also differ between the two idle snapshots). Purpose: find pack heat / vent / fire flag offsets offline.
- BTNEVENT (first 400 action presses/releases with hold time), HEADMOVE (range of head offset, clamped count).

## 44. 0.49 more data
- ACTORGRAPH: pointer fields (qwords whose first qword is a vtable inside the exe image) of the player actor (0x2000 bytes) and, one level deeper, of each linked object (0x400 bytes); logged for idle, then only new objects for firing / venting / MARK. OBJDIFF: dwords that changed in the 0x400 bytes of each depth-1 object between idle and firing / venting / mark (noise removed with idle-again). Goal: pack heat, vent state, weapon / stream / target objects, world actor list.
- MARK: Pause key or both grips + both stick clicks; TRACK once per second; GAMEDIR two-level listing of the game folder. Setting probe_data (default 1) switches the snapshots off.
- Risk accepted: the snapshot reads game memory after readability checks (VirtualQuery); an object freed on another thread in that instant would fault. Five snapshots per session at most.

## 45. 0.50 grips, prediction
- User (0.49 test): any grip stopped the right stick turning (right grip + stick was the D-pad), and the two-hand hold needed the right grip too. Now: D-pad = left grip with the left hand > 0.8 m from the right hand + right stick (Hand.away, pad::hands_apart); two-hand hold (aim line, drawn wand, tip) = left grip only, hands 0.12..0.8 m apart (two_hand_pose / two_hand_line_world upper limit 2 m -> 0.8 m). Right grip only used by the holster zone.
- 0.49 log: STREAMANG within5 24% / 30 41% / 60 21% / beyond 14% of stream updates: the game's own target steering (lock-on) still pulls the stream off the controller line; weirdness of shooting not yet explained -> SHOT lines (tip, aim, hit in tip frame, heading/pitch, two-hand flag) at 4 Hz while firing.
- Controller poses were taken as measured (prediction 0): wand and stream trailed the hand by about the tick-to-photon time. vr_capi_hand now asks GetDeviceToAbsoluteTrackingPose with hand_predict_ms (default 20).

## 46. 0.51 real models, gun weight, haptics, data
- User (18:36): use the game's own body / pack / wand instead of placeholders; make the gun feel heavy with one hand and stable with two; recheck all haptics (not felt consistently); more probe data.
- Wand model location (static analysis of ghost.exe): the player render function (0xD2260..0xD263C) pushes three model instances. Matrix at actor+0x246d8 (the 5-item list at +0xD450, stride 0x90: body2 / extras), actor+0x24718 (instance at +0xD728, collector 0xD3340, draw callback 0xD3520 = the proton wand) and actor+0x24758 (instance +0xD7B0, collector 0xD3150, callback 0xD3290 = the hose). Each is a 4x4 float, row vectors, translation in row 3. The render pass calls the matrix product 0x17210(A, out, B) (out = A x B) with A = the world matrix (0xD2470, return 0xD2475) and B = the view matrix, then pushes the product on the context's matrix stack (0x303FB0) that culling and drawing use. The "tip" attachment (0xD3C90) is tipLocal (map at actor+0xD728) x actor+0x24718 (0xD3CE3), so the tip lives on the wand instance.
- Hook: MinHook on 0x17210; acts only when the return address is 0xD2475 and A == playerActor + 0x24718. wandmath.h: the instance is turned about its grip so the tip's forward (row 2) points along the aim, then the grip (W translation) is placed at the controller: W'rot = Wrot R^T, W'trans = grip; tip' = grip + R (tip - W.t). hk_attach_matrix uses the same numbers for the stream start, so the stream starts at the real wand tip. Not changed in memory (the game's W is untouched, a copy is passed on). Safety: skipped when the grip is > 12 ft from the game's wand (wrong instance), when holstered, when data is stale; counters in the WAND line; safety ladder step 1 switches it off (wand_to_hand), step 3 also real_models.
- Not yet done: hose (instance 0xD7B0) still ends at the game's wand position; arms keep the game's animation; the head mesh around the eye is not hidden. Check in the next log: WAND first move (turn / shift / grip-to-tip length), MODELMAT lines (all three matrices and the tip), ATTACH names.
- Gun weight (weightmath.h, tests/test_weight.cpp): spring-damper on the wand rotation (rotation vector error, semi-implicit, 5 ms sub-steps, orthonormalised), parameters by heaviness h (setting gun_weight_pct / 100): one hand omega 20/(1+h) rad/s zeta 0.72, two hands 70/(1+0.5h) zeta 0.95 (blend rate 9/s on, 6/s off); droop 3.5h deg (+4h at full fatigue, fatigue 12 s to full, only one-handed and raised), two-hand 0.35h; tremor 0.55h deg (+0.9h with fatigue) vs 0.08h; recoil (builds in 0.45 s while a trigger is down) 1.1h deg climb + 13-23 Hz shake vs 0.22h; deviation from the hand capped at 35 deg. Applied in controllers_poll to the wand pose only (hand poses stay true): snapshot fields wandPose / wandRot, used by controllers_hand_aim, the tip / grip publish, the placeholder wand. Log WEIGHT (mean lag one-hand vs two-hand, while firing, fatigue max, grabs).
- Haptics (hapticmath.h, haptics.cpp, tests/test_haptic.cpp). Findings in the 0.50 log: rumbleSets 261 but only 107 pulses in 8500 polls: the old code played one <=4 ms pulse per poll and only when the game's value happened to be non-zero at poll time. Now a mixer holds effects per hand and source with expiry; a thread (high resolution waitable timer, 6 ms period, setting haptic_period_ms) plays the strongest effect (+ quarter of the second) as a pulse of length strength x 3999 us every tick. Game rumble is taken at XInputSetState time (played >= 120 ms). Sources: game, fireKick, fireHold (11 Hz rhythm), blast, twoHand, pack, vent, holster, mark, button, hello, trigger. Logs: HAPTIC (ticks, pulses per hand, longest tick gap, SteamVR input availability, per-source counts / peaks), RUMBLE, VREVENT (input focus events), DEVICE.
- Data added: SYSINFO (Windows build, CPU, RAM, GPU(s), monitor, exe version, command line), MODULES (all modules in the process, versions of GPU driver / dxgi / openvr / xinput files), DEVICE (maker, model, tracking system, controller type, render model, input profile, battery, firmware, supported buttons), VREVENT, ATTACHNAMES + ATTACH new name (every attachment name the game asks for), MODELMAT (the three world matrices and the tip at start and at each MARK), WAND, WEIGHT, HAPTIC, RUMBLE.
- Not testable here: everything in game. verify_layout.py: 5 new checks for the wand code (all PASS on ghost.exe).

## 47. 0.52 auto-pause, body follows the real body, height calibration
- User (19:17, 0.51 test): gun / shooting / reload / all 8 rumbles fine. Body did not follow arms; aim felt better with the gun held low (suspected: the tool assumes the real player is the game's player); wants a gesture that scales the VR player to the real height and the game's model to follow the real body; wants the game to open its menu by itself when he leaves SteamVR (stuck in VR otherwise).
- Auto-pause (autopausemath.h, tests/test_autopause.cpp): vr_openvr.c counts "player left" events (502 DashboardActivated, 400 InputFocusCaptured, 106 EnterStandbyMode, 700/701 Quit, 104 UserInteractionEnded for the headset only, headset activity level 2/3/4 polled through GetTrackedDeviceActivityLevel(0), logged as pseudo events 9001+level). Events in the first 6 s after the first poll are ignored (session start sends 502/400/412). hk_app_tick (game thread) runs the Pauser: only if App::Simulate (main-loop call) ran within 400 ms (= the game's "sil": not paused, no menu, 0x1F02D0/0x1F02E0; Simulate is not called otherwise) it holds Start for 180 ms, checks 1.2 s later whether Simulate stopped (paused) and retries up to 3 times. Start reaches the game two ways: controllers_poll ORs it into the controller pad mask (also feeds bindings_pad), and hk_get_state fakes a connected pad with only Start when no controller is tracked (the dashboard takes controller input: inputAvailable=0 in the 0.51 log); hk_get_caps answers "connected" for the same time. Log: AUTOPAUSE (action lines with appPaused byte [App+0x4A9C1], 0x20B01D0 byte, pauseFlag) and AUTOPAUSE summary.
- 0.51 log facts used: dashboard events 502/400 arrive together with inputAvailable=0, ApplicationNotResponding 1415 follows after ~1.4 s; the pauseFlag byte (0x2229519) is useless as an indicator (always 1).
- Body follow: the player render function 0xD2040.. multiplies four world matrices with the view through 0x17210: body base (call 0xD213F, a stack matrix built from actor basis +0xF4.. and position +0x54), extras / pack (0xD2384, actor+0x246D8), wand (0xD2470, existing) and hose (0xD257F, actor+0x24758). hk_mat_mul_impl now also acts on the three other return addresses (0xD2144, 0xD2389, 0xD2584). bodymath.h Xf: p' = s*((p-A)*R(phi)) + A + d with A = the actor's feet (read live), d = real head minus game head (horizontal, from arm_stereo's headCenter - base, plus the eye-forward nudge difference), phi = torso yaw (dead zone torso_dead_deg, lag torso_lag_ms, limit 130 deg), s = camera eye height / body_eye_centifeet (clamped 0.6..1.6). The wand is not touched by the follow (it is already placed from the controller). The body base is the player's when its translation is within 0.6 ft of the actor; extras / hose by pointer. Sign convention checked in tests/test_body.cpp (positive phi turns +z towards +x, same as the engine's yaw). Switched off by the safety ladder step 1 (bodyFollowOff).
- Calibration (bodymath.h Calib): left Menu + right Grip (no left grip) held 1.5 s, or Ctrl+F9; median of the headset height (standing space y) over the hold; size_pct_for(): sizePct = 100 * eyeM * 3.2808 * world_factor / eyeHeightFt (70..150), then recenter (head position re-zeroed) and torso reset. Y (the Menu button) is masked while calibrating and the holster toggle is suppressed. Log CALIBRATE (height, hands' height, old and new percent).
- Polish: stream hum swells 0.22 -> 0.32 over 3 s; a 40 ms tick when the stream stops.
- Fixed: ATTACH census saw only single letters because memory_readable() requires 4-byte alignment (name+1 is odd): new memory_readable_any().
- Data added: SHOTFACE (aim yaw vs the actor's facing columns, stream heading in tip frame, torso, head yaw) to test whether the game pulls the stream towards the body's facing: 0.51 SHOT stats: stream deviates 13.2 deg (one hand) / 7.3 deg (two hands) in heading from the barrel; ACTORBASIS; BODYFOLLOW; AUTOPAUSE; headset activity events.
- Not yet done: arms (skinned to the game's animation), hose end, stream steering towards the body's facing (hypothesis), head mesh at the eye.
- verify_layout.py: 9 new checks (body / extras / hose call sites) all PASS on ghost.exe.

## 48. 0.53 in-VR menu
- User (19:45): the left Menu button clashes with Virtual Desktop; wants a very user-friendly in-game menu opened with F4 holding all tests and settings.
- vrmenu.cpp: a second SteamVR overlay "gbvr.menu" (Mouse input = laser pointer, trigger = left click, sort order 20 above the flat game screen), 1.7 m wide, 1.25 m ahead of the head along the horizontal gaze, 10 cm below. Picture 1280x800 drawn with GDI loaded by name (gdi32 via LoadLibrary, so static imports stay KERNEL32/USER32/msvcrt), BGRA -> opaque RGBA, SetOverlayRaw only when dirty (>= 33 ms apart). Six tabs, rows of toggles / steppers (press-and-hold repeat, vmenumath.h Repeater) / action buttons; rows are bound to settings.cpp entries via settings_lookup().
- Opening: automatically once, frame > 150 and menu_on_start; F12 (plain; Ctrl+F12 stays menu_flip); left hand within 0.30 m of the head + left grip 0.5 s (controllers.cpp). While open the pad state is zeroed (autopause_buttons still ORed after, so Pause / Resume work); Pause / Resume close the menu.
- Removed the left Menu + right Grip calibration gesture (calibGest = 0); calibration is the Measure button (3.5 s countdown, then calibrateRequest) or Ctrl+F9. Status line shows the result from body_last_calibration().
- Helpers: autopause_manual_leave (counts as a leave event), autopause_tap (Start press window), game_running_now.
- Logs: MENU (opens/closes/clicks/pointerMoves/redraws/uploads/lastDrawMs/settingChanges), MENUSET key old -> new, MENU action ...
- Unknown until tested: whether the overlay laser works on the Quest through Virtual Desktop the same as the flat screen (menu_flip), readability, draw time.

## 49. 0.54 menu freezes the world, ring experiments
- User (19:58): (1) ghost health overlay behind the ghost, ghost in front; (2) menu open = game paused around you but the character's arm still moves for the menu.
- Freeze: engine_freeze_pulse() (vrmenu_tick every frame while open and menu_freeze; each pulse = 300 ms so a stuck state ends by itself); hk_app_simulate_impl returns before g_lastSimMs for the main loop's call while active (the same thing the game does when paused; the tick caps the next step at 4096 ticks). Render, head and hand hooks are not in Simulate, so view and arms go on. autopause counts a frozen game as running; Pause / Resume close the menu first (which ends the freeze) so the Start press is read. Log FREEZE (start/end, simulations left out, longest).
- Ring: 0x24D810 only projects the ghost's 3D position into 2D (+0x19c/+0x1a0) and draws a sprite in the HUD pass with 2D vertices: no depth. A depth-correct ring needs the scene's depth buffer bound plus a z for the sprite (viewport MinDepth=MaxDepth trick) - not done blind. RINGPROBE logs render target, depth view (bound? size, format), depth state and viewport during the first 6 ring draws; ring_mode=1 skips the ring.

## 50. 0.55 clean-up and visibility
- User (20:11/20:13): "F4 did not work, never went in VR mode"; the log they attached was the old 0.51 run of 19:11 (same file as sent at 19:17; F4 worked there: STEREO requested at frame 100, session ready later). No log of the failing run reached me; no new log in their folder = the 0.53/0.54 DLL probably was not loaded (not installed). Static audit of 0.52 -> 0.54 found no load-time or F4-path change (imports: only lstrcmpA/W, lstrcpyW, DrawTextW added; keys: same indices; PE .data grew to 4.5 MB for the menu picture buffer, harmless).
- 0.55: title-bar status through SendMessageTimeout (WM_SETTEXT, 100 ms cap, base title read once), F4 beep, focus test accepts any window of the game's own process, log when F4 is down without focus, menu auto-open after 180 headset frames instead of the absolute game frame count.
- Latent: vr_capi_hand keeps 64 poses (5.1 KB) on the stack and the build has -mno-stack-arg-probe; has worked in all tests since 0.33, left alone.

## 51. 0.56 menu laser, speed data
- User test of 0.55 (20:25 log): F4 / title / beep fine; menu opened (gesture and auto), freeze worked (236+114 Simulate calls left out), auto-pause worked when the headset was taken off (400/502/104/106/9004 events -> Start). Laser did not appear: MENU pointer counters 0. Cause (openvr.h): a scene application keeps the controllers; the laser mouse mode needs VROverlayFlags_MakeOverlaysInteractiveIfVisible (65536) on a visible overlay (the flat game screen only worked in flat mode where no scene is submitted). Set on the menu overlay; fallback own pointer (ray from the controller pose, -z axis, plane of the menu, trigger > 0.6 click / < 0.35 release, only while no overlay event came for 500 ms).
- Side effect of laser mode: InputFocusCaptured/Released (400/401) events -> counted as "player left" -> auto-pause would press Start: vrmenu_quiet() (open or closed < 1.5 s ago) makes autopause_tick ignore them (s_ignored offset).
- Speed: 0.55 log in headset mode 13 FPS (7 pairs/s), workAvg 150 ms per pair, appGpuMs 20-39 ms (0.51 log: 72 pairs/s, work 7 ms, GPU 7 ms), gameStep 62.5 ms (the clamp), skipExpired 123, secondEyeNoState 35-41, 37 ApplicationNotResponding events. Same picture size (3840x2880), same start position. No code path from 0.52-0.55 explains it by reading; the PerfWatch never fired because kMinWorks was 100 per 1.3 s (impossible at 7 pairs/s): now 6. PROFILE line (log.cpp prof_add/prof_report, slots tick / simulate / present / controllers / menu / bodyPush / hud / armStereo / submit / waitPoses) added to find it.
- New unknown: where the 70 ms per eye goes (CPU wait in tick/render thread or GPU).
- Body: BODYFOLLOW in the same log shows the base is moved (applied 1605, max offset 0.47 ft, torso up to 31 deg, scale 1.099); arms are still the game's animation (skinned): needs bone-level work (next).

## 52. 0.57 skeleton arms
- User (20:46): body skeleton before testing; the blaster/body must be what the player wears (any skin), full skeleton in VR.
- Found (layout.h "0.57 skeleton"): player model instance at actor+0x430: skeleton M+0x7930 (count +0x88, defs +0x8C, 0x4C each, name inline, parent at +0x1C, parents before children), bone count M+0x2090, local pose M+0x2AE8 (40 B: quat, scale, pos), model-space world cache M+0x2B00 (64 B/bone, 3x4 used), state M+0x2B08. Engine functions: EnsureWorld 0x30D410, LocalToMatrix 0x30D950, Mul34 0x32E510. Actor bone indices +0xCDC8.. (head, spine3, R/L upper arm, R/L hand).
- Hook: body_push (the body-matrix product before the model draw) -> arm_drive -> armcore::Core::apply: chain rebuilt from local pose + unedited parent world each call (idempotent for two eyes), two-bone IK (armmath.h), right hand takes the wand's rigid motion, left goes to the left controller (wrist back/down offset), descendants recomputed with the engine's own LocalToMatrix+Mul34, verify at the extras push (ARMS kept/lost).
- Modules: armmath.h (math), armcore.h (template over engine access, unit-tested with a fake skinned model in tests/test_armcore.cpp), arms.cpp (binding + byte checks + ARMS/ARMPOSE log). Settings arm_ik 0/1/2, arm_wrist_cm, arm_elbow_down_pct; safety ladder armIkOff.
- Test-harness note: a -O1-only segfault was a bug in the test's fake Mul34 (t[12] indexed to 14), not in armcore.h; fixed. Build now has -fno-strict-aliasing.
- Unknown until the in-game test: whether the engine recomputes bones after the write (ARMS lost counter / NOTE), hand roll, finger look, left-arm wrist offsets.

## 53. 0.58 speed, heavy rolling gun
- User (21:26): fix the FPS; gun heavier, one-handed, harder to turn and move, fully rotatable ("fixed in one direction").
- FPS, honest state: no new log; the 0.55 log (13 FPS, work 150 ms per pair, GPU 20-39 ms, gameStep at the 62.5 ms clamp, skipExpired 123) is not explained by any single 0.52-0.55 change. Candidate found: App::Tick ignores its fps argument and waits for the 30 FPS cap while the byte at app+0x4A9C0 is 1 (menu / pause); the eye-pair ticks (tick_pair in engine_hooks.cpp) called o_appTick directly, so a paused game was held to 2 ticks x 33 ms per pair (~15 pairs/s). tick_pair clears the byte for the call exactly like the menu_fast path (counter pairTickUncapped). Safety net: speedmath.h Guard + prof_report (log.cpp): per ~1.3 s window ms/s of menu, body push (minus arms), arms, HUD, controllers vs pairs/s (WaitGetPoses calls); pairs/s < 55 and a part >= 60 ms/s for 3 windows -> that part off for the run (menu redraw gap 300 ms, body_follow 0, arm_ik 0, hud_mode 0), log SPEEDGUARD. New data: SPEED, TICKGAP (tick gap avg/max, ticks that began with the cap byte set, paused flag, frozen, menu open).
- Gun: (1) roll: wand::solve got an optional up vector (controller up published as g_headAim.wup from the same hand::Xform as the grip) and rollRad (setting wand_roll_deg): after the swing that points the tip (matrix row 2) along the aim, the instance is twisted about the aim until the tip matrix row 1 equals the controller up; assumes the wand model's local y is its up (unknown: the setting is the fix; WAND log shows rolled/lastRollDeg). The arms use the same R, so the gun hand rolls too. (2) heft: weightmath.h tune: omega1 14/(1+1.2h) (was 20/(1+h)), zeta1 0.8, droop 4.5h, lag cap 50 deg (one hand) .. 35 (two); new step_pos: grip position relative to the head through a damped spring (omega 24/(1+h) one hand, 70 two hands, cap 10 cm / 3.5 cm), applied in controllers.cpp to the wand pose translation; setting key renamed gun_heft_pct (default 150) so the saved 100 does not hide the new default.

## 54. 0.59 crash guard
- User test of 0.58 (22:28): game crashed going in. Crash note: c0000005 at ghost.exe+0x2D668A, read address FFFFFFFFFFFFFFFF, flat mode (stereo=0, no headset), 824 presents, last probe stage game-wand-tip (only the last stage set; inProbe=0). Log: ATTACH "tip" for a new actor, PAUSEFLAG 0->1, then the crash. The 0.55 run passed the same sequence (tip, PAUSEFLAG, hose).
- Site: 0x2D6670 = bool Get(obj rcx, key rdx): test rcx; mov rax,[rcx]; call [rax]; compare > 0. rcx = 0x00FFFFFF00FFFFFF (colour bytes). Callers: 0x2BDF00 (obj [this+8], key [this+0x10]) <- 0x2CC540 ... (map / script-value code, level load).
- Not the 0.57 arms code: arm_drive / body_push only run with stereoActive. Hook and attach code unchanged since 0.55. Cause (game race / bad data vs. probe) unproven.
- 0.59: MinHook on 0x2D6670 (bytes checked: layout.h kRvaPropGet / kBytesPropGet, verify_layout.py check): user-mode range test, then readability of obj, its vtable and vtable[0] (last verified page cached); broken -> return 0, log PROPGUARD (first 8 with obj/key/caller RVA) and a PROPGUARD line per 180 frames (calls/caught). If another crash site follows, the crash note gives the next one.
- Log file name still says 0.37 (GBVR_VERSION_FILE), harmless.


## 55. 0.60 memory guard, hang recorder
- 0.59 test (23:53): flat mode, ATTACH "tip" at frame ~720-900, then the main thread never ticked again (gameStage stayed game-wand-tip, worldFrames=0, no PAUSEFLAG, no hose; Presents continued at 30 FPS) - endless loading. No PROPGUARD catch was logged: the 0.59 guard never fired. The 0.58 crash and the 0.59 hang are at the same moment of the same level load; the 0.55 run passed it (tip -> PAUSEFLAG -> hose, frames 540-900).
- Common factor in the SYSINFO lines: pageFileFreeMB (ullAvailPageFile = commit limit - commit charge) 2421 (0.55, worked), 1106 (0.58 crash), 1059 (0.59 hang). Free RAM was 14 GB in all. Hypothesis: commit exhaustion (3840x2880 swap chain + shared textures + Virtual Desktop / SteamVR) -> game allocation fails during the load. Unproven.
- 0.60: MEMGUARD in proxy.cpp after safety_after_settings: commit free < 3000 MB -> picture level 2, < 1500 -> level 1 for the run only (g_ctl, not saved; needs autoQuality). engine_main_stall_check() (engine_hooks.cpp, called by the heartbeat each second): g_st.tickCalls unchanged for 6/20/60 s -> suspend the thread recorded in g_mainTid, log RIP and ghost.exe return addresses found on its stack (MAINSTALL).
- Windows report zip (COLLECT_LOGS) also holds graphics_driver.txt / windows_graphics_events.txt: nvlddmkm event 153 entries at 13:43-14:15 UTC on 10/11, long before the tests; Virtual Desktop Monitor adapter present.

## 56. 0.61 full body, pause-menu fix
- 0.60 log (02:32): SPEEDGUARD had switched body follow off at frame 863 (a dashboard dip), arms ran only 313 times; right arm reach constant ~150% (clamped): avatar arms ~1.98 ft vs controller distance. Game pause menu: log shows "MENU action: resume (Start tapped, game running=0)" - game_running_now() is false while my menu freezes the world, so autopause_tap() pressed Start and OPENED the pause menu; AUTOPAUSE skipped lines show appPaused/pausedByte 1 while flat=1.
- 0.61 pause: menu_on_start / menu_freeze / auto_pause forced 0 after settings_load (proxy.cpp), A_RESUME no longer taps Start, NOPAUSEMENU in autopause_tick (engine_hooks.cpp): paused (app+kAppPaused or byte ghost+0x20B01D0) for 1.5 s with stereo on and the menu closed -> Start tap, 3 tries then 20 s rest. Setting no_pause_menu. Speed guard (log.cpp) no longer switches off body/arms.
- 0.61 full body (armcore.h torso_pass, runs before the arms inside Core::apply; ArmTargets bodyOn): target = head bone (bone_head) + headDelta, where headDelta = (lean xz, crouch y) published by body_update: horizontal head offset up to body_lean_cm is a LEAN (feet stay: d reduced by it), bigger offsets move the feet as before; y = headFeet.y when negative. Steps: (1) crouch: 0.85*dy (cap body_drop_cm) shift of the pelvis subtree, then two-bone IK on both legs (bone_L/R_thigh -> calf -> ankle, chains 2/3 in Cache.arm[]) with ankles pinned at the animated world positions, knee fallback direction = body forward (arm::solve fallback param); (2) lean: swing of head-pivot vector at spine1 (half) then spine3 (rest), each limited to body_lean_deg/2, subtree rotation via sub_rotate; (3) head: Qh = view * level(bodyYaw)^T (view = a.view columns right/up/forward, bodyYaw = camYaw + torso phi), minus the lean already applied, neck gets 35%, head the rest, limit body_head_deg. Arms: stretch factor sc = d/(0.97*L) up to arm_stretch_pct, applied as lengthened E0/W0 to the solver and a scale of the along-limb axis row of the upper arm / forearm matrices (along_row).
- Skeleton names used: bone_pelvis 0, bone_hips 1, thighs/calves/ankles 2-4 / 7-9, bone_spine1 30, bone_spine3 33, bone_neck 93, bone_head 94. Log: BODYCHAIN (once per model), BODYPOSE (every report, plus first/600th/6000th torso), ARMS move lines now carry stretch=. Safety ladder turns full_body off with arm_ik. Tests: tests/test_fullbody.cpp (fake 24-bone model).
- UNTESTED in VR: whether head bone/spine axes assumptions hold on the real rig (head orientation assumes the animated head faces the body's yaw), whether pack/hose (separate matrices) lag the lean, leg IK knee direction on the real rig. Next: read BODYPOSE/ARMS from the next log.

## 57. 0.62 body-off bug, menu pointer
- 0.61 log (02:52): BODYFOLLOW follow=0, ARMS calls=0, BODYPOSE torso=0 for the whole run: the 0.60 speed guard set g_ctl.bodyFollow=0 and settings_save persisted it. 0.62 forces bodyFollow/realModels/fullBody (and armIk if 0) on after settings_load (log BODYFIX). Guard no longer touches them (0.61).
- Same log: gameMsPerSec simulate 450-770 per second with pairs 27-40/s (simulate avg 8-10 ms, max 40-65 ms, half the calls over 5 ms) while own cost was ~0: the game's own Simulate is the stutter. Cause unknown.
- Menu: new setting menu_own_pointer (default 1): vrmenu pump_events drains and ignores SteamVR laser events, own_pointer (ray_to_menu) always runs; redraw interval 60 ms. NOPAUSEMENU waits 0.4 s, retries 0.9 s. Dashboard activation (type 502) is followed within ~2 s by appPaused=1 and a flat screen.

## 58. 0.65 (from the 0.64 test log 13:26)
- Body works (SMOKE OK, BODYPOSE torso=3539+). Own cost was high: PROFILE arms avg 1.87 ms/call, bodyPush avg 1.06 ms x 1080/window; SPEED own ms/s body 196-313, arms 81-142 at 34 pairs/s. Cause found: the engine does not rebuild the pose between the two eyes of a pair, so torso_pass was applied twice (relative shifts/rotations compounded). 0.65: torso_pass skips when head/pelvis/spine1 matrices still equal what it wrote and the target signature is unchanged (BODYPOSE skippedSamePose); ARMTIMING log (EnsureWorld avg us, memory check count).
- Menu: laser mode (MakeOverlaysInteractiveIfVisible + Mouse input) captured input focus -> vr_capi_hand returned nothing (CONTROLLERS left=0 right=0, ownMoves=0, no ring). 0.65: vr_capi_menu_laser(0) = no interactive flag, input method None. Menu opened at frame 2913, then worldFrames stopped (game paused, flat screen for 1300 frames): NOPAUSEMENU now closes the menu after 2.5 s of paused state, then taps Start.
- Saved size_percent 82 (view at the stomach, eye 4.51 ft): settings rev 65 resets values below 100 to 110. The old 'picture 2 -> 3' migration now only for files older than rev 43 (PERFADVICE saved level 2 stays).

## 59. 0.66 (from the 0.64 log, gun in hand, lag)
- "Gun not in the full-body hand": BODY wand=hidden was only a label (gb_hide_body() = hideBody && !realModels, so with real_models=1 the mirrors-only hook never runs, hidden counters 0). WAND applied > 1600: the wand matrix was moved. ARMS clamped 195/360 right arm, reach 168-172 % with stretch at its 170 % cap: the controller was farther than the stretched avatar arm (body scale 0.82 from the saved 82 % height; the real arm ~2.3 ft in game feet vs avatar 1.47 ft). Gun at the controller, hand short of it.
- 0.66: arm_stretch_pct default 260 (range to 400; saved 170 migrates, settings rev 66); Stats.lastMiss = wanted wrist - reached wrist (right arm), published by arms_gun_miss() (fresh within 40 ms); wand hook subtracts it from the wand matrix translation, hk_attach_matrix from the stream start (setting gun_glue, WAND log glue= gunGlued= tipGlued= lastGlueFt); REACH log = histogram of controller distance in unstretched arm lengths; GUNHAND log = misses.
- Lag: PROFILE of 0.64: bodyPush 0.86-1.36 ms avg x 540-1080 calls per 90 pairs (~8 ms per pair of ~26) with arms only 1.9 ms of it; the non-arms calls did one VirtualQuery each (memory_readable on the actor's matrices) and little else. Hypothesis: VirtualQuery on the game's big committed heap blocks is slow (it scans page-table state). memcache.h: region cache (16 slots, 200 ms TTL, spin flag, never waits) behind memory_readable / memory_readable_any / armcore G::readable; setting mem_cache=0 = old behaviour; log MEMCACHE (cached hits, full checks, average/max us of a full check) every PROFILE window - it will confirm or refute the hypothesis.
- armcore: arm pass skipped when world[U], world[H] still equal what was written and the target signature (wand/left-hand targets, wrist offsets, elbow bias, stretch cap, W2) is unchanged (armSkipped); ARMTIMING per stage (total / engine EnsureWorld / torso+legs / arms, QPC ticks via G::clock()).
- Menu: pointer ring = separate overlay "gbvr.menucursor" (vr_capi_cursor, 64x64 RGBA built in vrmenu.cpp, 5 cm wide, 6 mm in front of the menu plane, sort order 30, moved when the hit moves > 0.5 mm); after 3 refusals the old painted ring is used (MENU log). New Start-tab action A_RESETH (height 110 %), new Full body tab (7 rows), tabs 74 px high so 7 fit. MENU log: cursorOverlay / cursorMoves / cursorFails.
- Gun feel: weightmath.h omega x (1 + 0.35 fire (1-two)).
- GBVR_WIDE_VERSION (menu footer) had been stuck at 0.60; now 0.66.
- UNTESTED in VR: everything above. Next from the log: MEMCACHE fullCheckAvgUs (is VirtualQuery really slow?), PROFILE bodyPush/arms avg, REACH histogram at the new height, GUNHAND misses, MENU cursor counters.

## 60. 0.67 (from the 0.66 log 14:28: SteamVR blocked an add-on, VR init error 1114)
- 0.66 log: F4 at frame 254, "VR init failed (scene), error 1114", whole run flat (539 lines), so none of the 0.66 VR features were tested. 1114 = EVRInitError_VendorSpecific_OculusRuntimeBadInstall (checked in third_party/openvr/headers/openvr_capi.h: 1000 UnableToConnectToOculusRuntime, 1002 OculusLinkNotEnabled, 1114 OculusRuntimeBadInstall). Raised by vrserver's Oculus driver, not by this DLL. Web check: reports of 1114 are on Oculus/SteamVR installs; SteamVR "safe mode" blocks add-ons (blocked_by_safe_mode in steamvr.vrsettings). Which add-on was blocked is NOT in the old report (it had no SteamVR files).
- API audit (vr_openvr.c): only IVRSystem_026 / IVRCompositor_029 / IVROverlay_028 / read-only IVRSettings; no manifest, no driver, no settings writes, no chaperone/room edits; openvr_api.dll (SDK 2.15.6) is loaded from the game folder only when F4/F9 starts a session, so nothing touches SteamVR at game start. Game ships no openvr_api.dll of its own (GAMEDIR listing), so any copy there is ours.
- steamvr_diag.cpp (start worker thread) + steamvrmath.h (pure text code, tests/test_steamvr.cpp): STEAMVR lines before the first try (VR_IsHmdPresent, VR_IsRuntimeInstalled, VR_GetRuntimePath, processes vrserver/vrcompositor/vrmonitor/vrstartup/OVRServer/OculusClient/VirtualDesktop*, openvrpaths.vrpath runtime/config/log, versions, drivers folder list, Oculus runtime folder, steamvr.vrsettings enable / blocked_by_safe_mode / forcedDriver / requireHmd / activateMultipleDrivers lines, newest keyword lines of vrserver.txt / vrstartup.txt) and after a failure (hint, processes again, settings again, vrserver/vrstartup/vrcompositor/vrclient_ghost keyword lines). Init is tried up to 3 times 4 s apart (2 for 1000-1199; none for 100-107, 110-114, 130, 168); each attempt logged with VR_GetVRInitErrorAsSymbol / AsEnglishDescription text and time. Status text keeps the old "VR init failed (scene), error N" prefix plus a short hint; the window title shows it (render_hooks.cpp title_update, state 4).
- COLLECT_LOGS: zip goes to the Downloads known folder (SHGetKnownFolderPath via Add-Type, fallback %USERPROFILE%\Downloads, then Desktop) and Explorer selects it; steamvr\ folder in the zip: openvrpaths.vrpath, steamvr.vrsettings, tails (3000 lines) of vrserver / vrstartup / vrcompositor / vrmonitor / vrclient_ghost / vrdashboard, steamvr_state.txt (paths, versions, drivers, Oculus runtime, processes, newest log files), Virtual Desktop logs (newest 2 txt/log per 'Virtual Desktop*' folder under APPDATA / LOCALAPPDATA / ProgramData, 600 lines). PowerShell checked with pwsh 7.4.6 on Linux (parser + the collect function on a fake tree), not on Windows PowerShell 5.1.
- Installer: an existing file identical (SHA-256) to the one being installed is kept, not moved to a .gbvr_backup_ file (the 0.66 run showed openvr_api.dll.gbvr_backup_20261012-142231 = a copy of our own DLL, same size 837272).
- arms.cpp ARMTIMING: %lld replaced by %I64d (msvcrt).
- Gun feel: unchanged on purpose (no VR log of 0.66 yet).
- UNTESTED: everything with Windows calls in steamvr_diag.cpp, the retry loop against a real SteamVR, the title message, the Windows side of COLLECT_LOGS.

## 61. 0.68 (from the 0.67 log 36296b66 + report eef3857d + video)
- Headset worked. User: avatar "below me, not in the head of the rig", arms too long, hands off, right hand not on the gun, pack/legs wrong; menu pointer jittery, clicks do nothing (log: menu opened twice, 5 clicks = 4x "Measure my height" + close, zero tab changes), menu does not pause the game (Pause button did nothing, auto_pause=0); gun feels odd while firing and too heavy one-handed.
- Body: absolute eye alignment in armcore.h torso_pass: avatar eyes = midpoint of bone_L_eye (109) / bone_R_eye (130); target = headCenter - eyeBackCm*view forward. Horizontal bias learned in the body frame (gain 0.04, only near the standing point |lean|<0.2 ft) and added to the body base offset d; the unscaled model eye height (running mean for 250 samples, then slow follow) sets the body scale in body_update; final head-subtree slide capped 0.35 ft. EYEALIGN log. Settings body_eye_align, body_bias_cm (30), eye_back_cm (4).
- Shoulder reach (shoulder_pull_deg 35): bone_*_clavicle1 swings toward a hand target farther than the arm, before stretching; arm_stretch_pct default 150. Crouch dead zone (crouch_dead_cm 8): drop = (dip - dead)*0.9. Pack follow (pack_follow): packmath.h bpack::apply applies the torso pass' recorded drop + the lower-spine rotation to the extras matrix in body_push (which==1). Pack hangs from spine2, so only stage 0.
- Gun: weightmath.h lighter one-hand idle (omega1 26/(1+.35k), droop 1.6k), `stiff` ramp 0.12 s on / 0.5 s off while the trigger is down, step_pos stiff. Aim assist (assistmath.h, engine_hooks.cpp head_aim_publish): uses the game's targeted-ghost ring position (health ring draw 0x24D810 -> aim_ring_seen), cone aim_assist_deg 6 + size, pull up to 0.65*strength, smoothing 60 ms on / 120 ms off, only while trigger >0.5 (+0.25 s). The assisted dir goes to hk_aim_set / hk_attach_matrix; the gun model keeps the raw dir. UNKNOWN: whether the ring exists before the first hit. Logs: AIMASSIST.
- Menu: vmenumath.h OneEuro + Pointer (hold at trigger >=0.15, release <0.10), hand pose unpredicted (vr_capi_hand_predict_off), click arming (trigger released once after open), MENUCLICK log, menu_freeze allowed again (default 1; skipping App::Simulate), Pause button removed. Pages: Start / Gun / Full body / Help rewritten.
- settings rev 68 (menu_freeze 0->1, arm_stretch 260->150). Tests: test_assist, test_packmath new; test_fullbody (eye bones, shoulder, dead zone, pack vs bone), test_weight, test_vmenu extended; all pass.
- UNTESTED in VR: all of it. Next from the log: EYEALIGN left-over and learned bias/eye height, pulled counts, AIMASSIST target ring lines (is there a ring before the first hit?), MENUCLICK, MENU jitter.

## 62. 0.69 (from the 0.68 log 171545 + report c5933155 + user words)
- User: body still below, beam drifts L/R, gun not in hand, "not all menu features work"; wants the menu to play a song (65 %) with the game sound paused and the cover picture blurred/see-through behind; swinging = cutscene forced movement.
- Body (armcore.h torso_pass): no learned bias. Each pass measures the avatar eyes Ee (mean of bones 109/130) and moves them exactly to eyeTarget: crouch drop, two-stage lean, head turn, then the residual R*fade shifts the whole pelvis subtree (cap eye_shift_cap_cm 30) and a small remainder slides the head subtree (cap 0.2 ft); legs re-planted at the animation's ankles (plant_legs). Model eye height = tallest peak of a 180-bin histogram (modemath.h) over 3.5-8 ft, sampled at fade>0.99 only. packmath.h gained shift (applied last).
- Forced moves (forcedmath.h, engine_hooks.cpp body_update): actor xz speed vs left-stick magnitude; stick idle >=0.30 s and speed >=1.5 ft/s for 0.10 s, or a jump >5 ft => forced; fade 0 in 0.12 s, back in 0.9 s; hold 0.5 s. FORCEDMOVE log (first 60 events).
- Straight beam: the stream update (0xE6360) fetches the tip (call site kRvaTipCallers[3]) then calls vec_to_angles (0x31FFC0); the game bends the stream toward the head-ray hit (30-60 deg). hk_vec_angles zeroes the two angles for the player's stream (flagged by the tip-fetch thread). BEAMSTRAIGHT log shows how much bend the game wanted.
- Audio (audio.cpp): own thread (MTA), ole32 by name; minimp3 (CC0) decodes gbvr_menu_music.mp3 from the game folder; WASAPI shared stream with its own session GUID (AUTOCONVERTPCM 16-bit at the song's rate, fallback = device format with linear resample); fades 1.2 s in / 0.5 s out; game mute = ISimpleAudioVolume of every other session of this process on all active render endpoints, ramp 0.25 s down / 0.6 s up, exact restore; marker file gbvr_audio_muted.flag + recovery at the next start (Windows remembers app volume). audio_menu(open) from vrmenu open/close/tick; audio_shutdown from vr_exit_cleanup; AUDIO log.
- Menu look (vrmenu.cpp): backdrop = cover picture (tools/make_menu_bg.py -> src/menu_bg.h 256x160 blurred, stretched bilinear) mixed over the dark colour by menu_bg_pct; panels are alpha-blended by hand into the DIB (rounded-corner coverage tables), text queued and drawn with GDI after the panels with a 2 px shadow; 8 tabs (Sound new), rows 72 px.
- settings rev 69: new keys eye_shift_cap_cm, forced_detect, beam_straight, menu_music(+_pct), menu_mute_game, menu_bg(+_pct); aim_assist cone 6 -> 10 once; body_bias_cm removed; size migration only at rev < 65.
- UNTESTED in VR/Windows: all of it. Next from the log: EYEALIGN (shifted/capped/max, model eye height + peak share), FORCEDMOVE, BEAMSTRAIGHT (bentOver counts), AUDIO (gameSessions, underruns, errors), MENU bg.


## 63. 0.70 notes
The 0.69 log (EYEALIGN) showed a mean eye error of 0.74 ft and the 1 ft pelvis-only shift capped 15% of passes (legs clamped ~37%). The sideways part of the residual now shifts the whole skeleton and the ankle targets A0 (plant_legs gets A0+walk), only Y keeps the legs planted. SetOverlayRaw per redraw blanked the menu: vr_openvr.c keeps two overlays (gbvr.menu, gbvr.menu2), uploads to the hidden one, shows it at sort 21 and hides the old one 140 ms later (vr_capi_menu_settle).

## 64. 0.73 notes (hose and shoulders)
The game's pack, hose and wand are separate rigid models drawn from world matrices at actor+0x246d8 / 0x24 hose / 0x24718, not skinned to the body bones, so the arms-only collapse (which squashes bones) does not touch them. Game logs from 0.70: pack at 4.3 ft above the body root, hose origin 0.8 ft below the pack centre. The hose is one rigid model, so it cannot follow a wand that is moved to the controller; 0.73 hides it (mirror-only check at the hose call site, as for the body) and draws a probe-made rope instead, in tracking space, through the same eye transform as the hands (model_to_eye with an identity device pose). The rope is stepped once per eye draw (dt from QPC, a second eye within 2 ms reuses the shape). Pack end and wand end anchors are guesses; BODYREL log lines give the game's own pack/hose position relative to the eye so they can be tuned.
Shoulders: the avatar skeleton has bone_spine3 with the neck (and head) and both clavicles below it. Keeping spine3 and its subtree except the neck subtree leaves the upper chest and the area where the pack straps run; the remaining bones are squashed to a point below and behind spine3. Skin vertices weighted between kept and squashed bones are stretched toward the point (a taper behind the chest); whether that shows in the headset is the open question.

## 65. 0.74 notes (rig view, hose, shoulder slide)
Rig view data path: armcore.h snapshot_rig() runs in apply() after both arms are written and before collapse_body(); positions are bone-matrix translations (model space) -> sp.point_world -> head axes with ArmTargets.hmdBasis (row-major 3x3, column k = right/up/forward in game world) and eyeTarget; only with bodyOn and eyeOn. The pack (extras) and hose matrices (rows 0..2 axes, row 3 translation, row-vector convention) are stored from body_push() through arms_rig_part(). handmodel.cpp reads the snapshot with a sequence lock (Core::rs / rsSeq, odd while writing) and builds the figure in tracking space: head-axes vector (r,u,f)/fpm -> (r,u,-f) -> head rotation columns -> turn about the vertical by delta -> scale 0.4 -> add the miniature's centre. A snapshot older than 1.5 s (no body render: menu, cutscene) is not drawn (only the floor, red dot and controllers). Known game numbers from the 0.73.1 log: spine3 26 cm below and 20 cm behind the eye, pack matrix origin 35 cm below / 16 cm behind, hose origin 56 cm below / 18 cm behind / 8 cm right, arm length 1.0 + 0.89 ft; controller demand beyond 220 percent of the arm in about 10 percent of right-arm calls.
Hose: see STATUS_AND_PLAN 0.74. Stuck ghosts: the ring never set in the 0.73.1 session; sim_every_n is an experiment, not a fix.


## 66. 0.75 notes (gun in hand, view higher / body out, seamless hose, wall watch)
- Root cause of the loose gun (0.74 log + rig pictures): arm IK measured the hand (Hp) from chain_world on the MOVED / scaled body (W2), but the wand model's origin (ArmTargets.wandP0 = the wand world matrix) and the wand's rigid motion R about it are in the game's UNMOVED world. Hand-minus-wand-origin was about 26 cm in the log. Fix (armcore.h): pose_world(local, hand bone) rebuilds the hand's matrix from the animation's local poses (root first, using the engine's own local->matrix and 3x4 multiply), origBody (the game's original body matrix `a` from body_push which==0) maps it to game world (gh.pos / gh.ax); the wrist target is grip + R (gh.pos - wandP0) and the hand's axes are R * game axes (Q = R G C^T for place()). Fallback to the old path if the hand is farther than 3 ft from the wand origin or the pose cannot be rebuilt. Stats: gripFixed, gripNoPose, offset min/mean/max, jump max, the old way's error, rebuilt-vs-engine check (log GRIP). Test: tests/test_armcore.cpp (wrist exact within 2 mm, axes within 0.005, old error > 5 cm, far-wand and origOn=0 fallbacks).
- View higher / body out (armcore.h torso_pass): the avatar's eye goal = camera eye + (sin yaw, 0, cos yaw) * bodyOutFt, y - viewDownFt; D, R and the residual use the goal. Settings view_up_cm (default 8), body_out_cm (default 10), menu Rig tab. The cord's pack anchor and torso ellipse move the same way (cordmath pack_anchor outM/downM). Test: test_fullbody 14b.
- Hose (cordmath.h build_mesh): 12 sides, 3 rings per rope segment, per-vertex colour (smooth: rubber 0.085 with a baked top sheen, boots blend to metal 0.2), boots 4.5 cm flaring to 1.45x, ends embedded 1 cm. The overlay's own depth buffer is cleared per pass, so the cord is drawn over the game's picture: the embed is only cosmetic.
- WALL (engine_hooks.cpp wall_watch, layout kCamDistTarget 0x2F4): camera distance (0x24C) against the spring target; episode = below 75 percent for 3 frames, ends after 10 calm frames; counters of gate failures / incomplete pairs / body and arm failures during the episode; shot_request() 20 frames in (max 3 per run, 20 s apart). The +0x2F4 reading is from the earlier read of the standard-mode update; the first WALL line shows both numbers, check that the target looks like 4.5 before trusting the ratio. Setting wall_diag (default 1).
- Not testable here: all of it in the headset.

## 0.77 notes
- Slam: needs capture (LB, now the left trigger) held + fire + slam gauge [player+0x24A40] >= 0.25 (RVA 0xDCD278); the gauge only fills while a target is wrangled ([player+0x24D80]). The 0.76 log showed gauge 0.00 and capture never held (it was on the left stick click).
- Items: EInventoryItem 0 Nothing, 1 ProtonGun, 2 Shotgun(meson), 3 Railgun(boson), 4 Trap, 5 Meter(PKE), 6 Light, 7 SlimeGun. Player table at +0xCFE0, stride 0x18 (0 none / 1 owned / 2 in hand / 3 off). readyInventoryItem(player, item) RVA 0xE3EF0 (called on the game thread from the camera-prepare hook). requestDeployTrap RVA 0xEC5A0 (sets action-mask bit 0x40); trap object [player+0x24D88], trap state [player+0xD040].
- Bars: visible when ([0x25241A4]-1) <= [actor+0x298]; game LOS test RVA 0x7BCE0 bool(CActor*, const float* worldFt3).
- Arm stretch in the user's 0.76 log was 100% (never stretched): migrated once to 200%.
- Near plane: 0.55 ft (17 cm) cut the avatar's chest when looking down; now 0.18 ft, and the hook may go below the game's own 0.25 ft.
- Forearm roll: armmath.h twist_about / forearm_roll (swing-twist about the forearm axis, tests/test_roll.cpp).

## 0.78

* Controls: right A button = tap Interact (replayed >= 90 ms after release) / hold 0.2 s = weapon wheel (`gear::TapHold`); left X = take the trap at the left hip
  (`gear::Trap` now button-driven; a quick still tap there replays X = the game's deploy). Grips are not used by either. The map is written in `src/ctlmap.h`,
  logged as CONTROLMAP at start and checked in `tests/test_ctlmap.cpp` (no two uses of one button that can be active together unless in one exclusive context
  group or listed as settled; no new feature on a grip).
* Gate: A / X are only taken while the inventory is "fresh" (`fight_items` = the player object was published within 0.5 s, i.e. a level is running); otherwise
  they pass through live.
* Wheel (Alyx style): discs on a circle, hover by stick (wins at >= 0.55) or by hand offset in the wheel's plane (on 5 cm, off 3.5 cm), anchored pose
  (`gear::wheel_anchor`: in front of the head, clamped 0.42-0.70 m, side +-0.30, height -0.28..+0.10, upright, facing the head), open 0.16 s / close 0.14 s,
  hover easing 40 ms, flash on pick, locked ("?", item state 0) / off (state 3) discs refuse (event 4). Built flat in its own plane, placed with
  `hand::model_to_eye(head, wheelPose)`. Vertex budget < 9000 (kUiCap).
* Hose colour: `src/hosetex.cpp`. Game thread (called from `fight_publish`): census of the model instances at player+{0xD450 + k*0x90, 0xD728, 0xD7B0}
  (mesh list at instance+0x78: count +0x34, pointer array +0x38, name at mesh+0x18 = pointer or inline) and a pointer walk (depth 3, 32 qwords a node, budget 6000
  nodes) for Direct3D 11 objects (vtable and its first three slots inside d3d11.dll, not our own proxy) which are QueryInterface'd for an SRV / 2D texture.
  Render thread: staging copy, smallest mip <= 16x16, average of plain 8-bit RGBA/BGRA and BC1-BC3, normal maps skipped. The hose instance's first colour texture
  becomes `cord::hose_tint()` (texture average / 0.06, smoothed 0.8 s). Log: PARTS, PARTSRAW (hex of the hose / wand instance, model list, first mesh), HOSECOLOR, HOSETEX.
  UNVERIFIED: every offset above comes from the earlier static analysis, none has run in the game.

## 0.79 (from the 0.78 log 211526 + video 212444)
* "Right hand gone / left hand wrong": GRIP offset (hand minus wand origin) was ~72 cm whenever the game's item in hand was 0 (nothing: level start, cutscene, forced walk); the 0.75 grip fix accepted anything under 3 ft, so the wrist target = grip + R * 72 cm flew away. armcore.h: real grip only under 0.8 ft; otherwise (`farGrip`, stat gripFar) wrist = controller grip and the hand follows the controller (`hand_from_controller`: swing forearm -> controller forward, then roll about it by the controller's roll against the level up, faded out near vertical). The left hand uses the same helper (it had swing only, no roll). ArmTargets.rdirOk/rdir/rup from engine_hooks arm_drive.
* Slam: the 0.78 log had capture held 867 samples, fastest hand 2.0 m/s, threshold 2.2 -> 0 sweeps. Default 1.2 m/s (settings rev 79). The slam meter reached FULL twice only.
* Haptics: fire kick/hold only while the player's stream updates (hk_vec_angles stamps g_streamSeenQ, `engine_stream_recent(150)`); FIREQUIET log.
* Trap: the game's own trap actor ([player+0x24D88]; position at +0x54) is moved to the left controller (game feet, g_headAim.lpos) every frame while the trap button is held (damage.cpp fight_trap_carry, called right after head_aim_publish). Own model only with trap_own_model=1. Log TRAPCARRY (gameMovedItBack = the game rewrites the position each frame, then this does not hold).
* Hose invisible: the 0.77 chest shield tube enclosed the eye, so every ray to the cord crossed its wall. Now top = eye - 0.16 m, centre 0.17 m behind the (shifted) head, half width 0.17, half depth 0.085 (cordmath kShield*); tests/test_cord.cpp ray test. The physics keep-out ellipse is unchanged (it lies ~0.19 m in front of the eye: the cord still floats in front of the chest; to tune from the next log).
* hbar default 0 (rev 79). Game ring: draws in the HUD pass as a 2D sprite from this+0x1A8 (world pos) for the targeted ghost only. RINGRAW / RINGPTR dump the ring object (0x240 bytes, and 0x60 bytes behind each pointer) 3 times so the health field can be found.
* Hose texture (0.78): 9384 objects walked, 1230 D3D objects, 0 QI to a texture: the model parts hold texture NAMES (mesh+0x58.., e.g. weap\proton_pack_equipment_diff.tga), not D3D views. Not solved.

## 0.80
- Chest hidden: `arms_shoulders` default 0 (migration at rev 80), so collapse_body keeps only arms + clavicles. The game's straps are skinned onto the chest, so the probe draws its own: `rig::build_straps` (rigmath.h) builds two 6-sided tubes per side from the rig snapshot (shoulders, neck, spine3, pack origin) in head axes; drawn in handmodel.cpp with g_uiVb. `rigOn` is now also set when armsOnly && armsStraps. Log: GEARDRAW strapDraws/strapMiss.
- Flat screen (stereo.cpp show_flat): 3.6 m x 2.8 m, follows the head when it stays >55 deg away for 1.4 s (g_flatYaw). Log FLATSCREEN.
- Untested in headset.

## 0.81
- Crash 0.80: access violation (write) at system d3d11.dll+0x191c47 on the game thread (game-simulate), ghost+0x41d1be caller; cause unknown, VIDMEM line added in stereo.cpp.
- strapMiss bug: arms_rig_part (pack matrix) was only fed when rig_view != 0; now also when armsOnly && armsStraps.
- PKE mode (engine_hooks.cpp pke_mode(): fight_items cur == 5): rightOn/leftOn = 0, armsOnly + headOnly (armcore collapse_body keeps everything except neck/head), wand override skipped, straps and physics cord hidden.
- Left foregrip magnet (armcore.h, left branch): foregrip = grip + rdir * 0.55 * gunLenFt - rup * 0.1 ft; weight smoothstep 0.5..1.3 ft.
- Solid body (solidmath.h): elliptic torso column under the eye; grip point and left hand pushed out; the wand matrix gets the same delta.
- Cord slack 0.48 - 0.26*t (was 0.30 - 0.20*t).

## 0.82
- 0.81 log: ARMS noTarget=3915/3915 matches PKE-mode passes (arms overrides were off) = the arms "phasing". PKE mode now keeps IK + wand override, only headOnly squash.
- Hang at PKE ON #2 (MAINSTALL rip other-module, main thread spinning, no Present); MAINSTALL now logs the module name.
- left_grip_pct default 0, view_model_pct 165, hose slack 0.95 - 0.70*t (NPC-like loop).


## 0.83
- 0.82 log (run 00:29): MEMGUARD saw 385 MB commit memory free -> picture level 1 (2560x1440) and the lowered value was saved into the settings file. Fix: the guard's value is not saved (g_guardKeepLevel), thresholds 700/1500 MB, settings rev 83 puts picture_level < 3 back to 3.
- gloves_only (default 1): armcore `noArms` squashes the arms too; handmodel draws the probe's own glove at each controller (no own wand, since the game's gun is shown). With the PKE in hand (item 5) the old arms return (engine_glove_mode()). pke_body default 0.
- wheel: kSlots 10 -> 7 (Light, Next, Previous removed). Holster: right trigger+grip over the shoulder (pack zone), vent needs the trigger up (ctlmap kAtShoulderTrig).
- trap throw: the 0.82 log shows BTNEVENT button 3 (Trap) reaches the game but the player's trap state stays 1 (idle) in every log; TRAPFLIGHT now also logs the action mask and item in hand; a plain X press starts the same 4 s log.
- Deluxe mod (v0.83a) is a mod-loader pack: drop `deluxe` into MODS. data/tweak.txt has `Render Health Bar` per ghost class (0 on 5 classes). Textures (.tex) are not plain DXT1; not decoded.

## 0.84
- 0.83 log (run 01:15): PKE held from frame ~5871 (item 5). cloth_pke (bone 24) / cloth_pke1 (25) hang under bone_hips; arms-only squashes them, so the PKE vanished. Fix: `pkeAttach` - armcore pke_capture takes cloth_pke relative to the nearest hand from the engine's own world matrices before the torso pass, pke_apply sets `Off * Hand` after both arms are placed, collapse_body keeps both bones. Proton gun is drawn at zero scale while the PKE is out (wand hook). PKEHAND log shows distances to both hands.
- Fingers (`fingers`, default 1): bone_X_{thumb,index,middle,ring,pinkie}1-4 found by name, each chain must hang from the hand bone. Hinge axis = measured from the animation (joints 2-3, >=12 deg bend) else geometry (pinkie->index knuckle line, negated for the left hand; derived by hand for a palm-down right hand). Free hand: absolute bend = curl*190..200 deg split 0.36/0.40/0.24; gun hand (right hand with the grip fix): animation kept, trigger adds up to 55 deg to the index, grip released opens the others to 40%. FINGER / FINGERS log lines show axis source, agreement with geometry (x100) and bends now/wanted.
- Wheel: kSlots 7 -> 6 (Trap removed; the trap is the hip gesture). Wheel PKE pick presses the game's own Y (action 6) instead of calling the ready-item function a second time (that second call froze the game in 0.83).
- Trap hip throw: X is pressed 0.12 s after the carry ends (was at the same moment), TRAPFLIGHT watches it.
- Memory guard thresholds 600/900 MB commit free (was 700/1500); the 0.80-0.83 freezes and the crash had 2.6-3.6 GB free, so they were not memory. MEM lines in the log.
- Hose: cord start taken from the game's real pack position (`real_anchor`), shield lid/floor removed and the shield is not drawn when looking down more than ~17 deg (the lid hid the hose).
- gloves_only default back to 0 (migration rev 84).
- Untested in the headset.

## 0.85
- PKE is placed through the wand-slot matrix (pkew_capture/pkew_apply in armcore.h): the game's hold pose relative to the nearest hand, re-applied on the final IK hand. pke_bones=0 by default (cloth_pke gluing put it ~2 ft off).
- Finger curl geometric axis sign fixed (right negated, left plain); measured axis uses joints 2,3 only.
- body_height_cm (-30..30) replaces view_up_cm in the menu.
- Video guard (exit_guard.cpp, CreateFileW hook): logs VIDEOOPEN, blocks br_*/attract* when skip_videos=1. Untested.
- Open: trap throw resets to hip, view_model_pct inversion, viewmodel overlap.

## 0.86
- 0.85 run (12:43): VR started 12:44:05, game process gone 12:44:18 (vrserver "ran for only 12.87 s"), last log line SUSPENDED (cutscene -> gameplay, frame 149); no CRASHNOTE, no EXIT line: not an access violation, not ExitProcess. Memory fine (commit free 4.4 GB min). 0.84 passed the same transition.
- Black box: safety.cpp crumb() ring of 512 steps in memory-mapped gbvr_crumbs.bin; previous ring dumped at start (CRUMBLAST, gbvr_crumbs_last.txt). Crumbs in tick, simulate, camera render, wand hook, body push, arm_drive, armcore apply stages, present, video open.
- crash_note covers stack overflow / fast fail / heap corruption; SetUnhandledExceptionFilter logs LASTWORD.
- MAINSTALL stall report at 2/4/8/20/60 s. Log flushed every 1 s.
- Video hook moved from kernel32 to KernelBase (the 0.85 hook never fired); skip_videos migrated to 0 (rev 86).

## 0.87
- 0.86 run 18:58: black box ring (gbvr_crumbs.bin, 44-byte entries, header 16) ended at "sim:in" on the game thread, tick 1573, no sim:out, no CRASHNOTE/LASTWORD; flat mode (stereo never started). Same moment as the 0.85 crash (end of hotel cutscene). Only 0.85+ change active in flat mode = CreateFileW hook (never matched a video: videosOpened 0 in both runs).
- Removed the CreateFileW hook. skip_videos now (default 0) installs optional ntdll NtCreateFile/NtOpenFile hook (log + block non-CS_ videos). settings rev 87 resets skip_videos to 0.
- exit_spy_arm(): ntdll NtTerminateProcess(self)/RtlExitUserProcess + kernelbase RaiseFailFastException log caller + stack + flush.

## Third-party mods installed by the user (keep in mind for every probe)
- "Straight to menu" intro fix (GhostbustersNoIntro.asi + Ultimate ASI Loader as winmm.dll, by Gametism) is installed in the game folder (user, 2026-10-16). Proprietary license: never copy/port/bundle/repackage it or reuse its patch logic. The probe must NOT build its own intro skipper, and install/remove/reset scripts must never touch winmm.dll or *.asi.
- Intro skipping is therefore handled by that mod. Probe skip_videos stays 0 (the experimental ntdll hook is opt-in only).
- When analysing a crash or hang at start, remember this mod is loaded too (ask for the GAMEDIR listing / log line to confirm winmm.dll + .asi are present; compare with the mod removed if a start-up problem appears).
- Deluxe mod (MODS\deluxe) is separate and still untested with the probe.

## 0.88 - outside watcher, video checks, Windows crash report
Findings from the 0.87 run (report 20261016-203411): the world freezes at world frame 138 (pauseFlag=1, the cutscene) while the render
thread keeps presenting (about 770-900 presents, 10 s); the process then disappears at about the time a cutscene of that length ends
(0.84's passing run froze for ~900 presents at world frame 89, then resumed at 99). The black box ends at `sim:in` of the game's
App::Simulate; no CRASHNOTE, EXITSPY or LASTWORD line, no MAINSTALL (the process was gone in < 2 s). A fast fail (`int 0x29`: abort,
stack cookie, invalid parameter) kills a process without any user-mode handler, so nothing inside the DLL can see it. The game's cutscene
video class is `WinVideo` (Media Foundation, NV12 shared textures; strings at file offset 0xc9248f..: "NV12 SharedTextureSupported IS /
NOT supported", "NV12 supported / not supported by device"); the user reports audio but no picture.
Added:
- `src/watch.c` -> `gbvr_watch.exe` (freestanding, kernel32 + memset only): debugger-API watcher. The probe's heartbeat thread starts it
  (`watch_game=1` default; setting rev 88) with `<pid> <log> <event>`; it attaches, sets KillOnExit=FALSE, answers every event so the game
  behaves normally (int3 skipped, exceptions passed on, first-chance exceptions only logged once per code+address), logs DLL loads, thread
  stacks at the fatal event (RIP of every thread, 28 return-address candidates), OutputDebugString text (DBGSTR, first 4000), C++ throws
  (first 25), the fast-fail code (FATAL fast-fail code N = name) and the exit code (EXIT), and writes `gbvr_crash.dmp` (MiniDumpNormal +
  ThreadInfo + UnloadedModules, no exception record). It lets go of the game if > 60000 debug strings or > 400000 exceptions.
  While attached the probe clears PEB.BeingDebugged every second so `IsDebuggerPresent()` is FALSE for the game (the game imports it).
- Probe: `WATCH ...` lines, `MODLOAD name base` (every second, new modules), `MFFILES` (Media Foundation DLLs in System32 with sizes),
  `VIDEODEV` per created device (NV12/P010/YUY2/BGRA format support bits, feature level, creation flags, ID3D11VideoDevice, hardware decoder
  profile count, H.264 yes/no).
- Manager (Collect): Windows Application log (`windows_app_events.txt`: Application Error / WER / Application Hang for ghost|d3d11|gbvr),
  `wer_N_*.wer` (Report.wer of the newest 3 AppCrash folders), `gbvr_watch_*.log` (newest 3) and `gbvr_crash.dmp`.
- Build: `build_cross.sh` builds `build/0.88/gbvr_watch.exe`; `package.sh` ships it in `bin/` (the installer copies everything in `bin/`).
Not done on purpose: no gun-feel change (the crash comes first). Untested on real Windows: the watcher.

## 0.89 - what the 0.88 watcher caught
Two different deaths, both after the hotel cutscene (the cutscene itself no longer killed the game):
1. VR run: access violation (DEP, execute) at system d3d11+0x1d9060 on the game main thread (stage game-camera-prepare, present 1882). The probe's own
   CRASHSTACK (`probe+...`) puts it in `hosetex.cpp crawl()` <- `hosetex_game_step`: `looks_com()` accepted any object whose first three vtable slots lay
   *somewhere* in d3d11.dll (data included) and `com_texture()` then called QueryInterface through it. Fix: the object's table must itself lie inside
   d3d11.dll and be data, the three slots must be executable code; `hose_from_game` default 0 (setting rev 89 migrates a saved 1 to 0).
   NOTE: watcher module names were ambiguous (our proxy and the system d3d11.dll both printed "d3d11.dll"); 0.89 prefixes any module outside
   \Windows\ with '!'.
2. Flat run: fast-fail 8 (RANGE_CHECK_FAILURE) at ghost.exe+0x51a398 = the CRT's invalid_parameter_noinfo_noreturn thunk (0x51a368). Caller is
   0x403320 (clear one byte in the 600-entry table at 0x2523f00 by index, `cmp rcx,0x258; jae -> fail`), called from 0x1FC680 (release one binding:
   `this+idx*24`; kind at +0 (1 pad, 3 keyboard), code at +4; kind 3 uses the code as the table index). So some keyboard-kind binding had a code >= 600 or
   negative (cause unknown: unbound key, mouse button, or a table the probe's controller-type switch left behind; the flat run had the probe's pad
   forcing disabled). 0.89 hooks 0x1FC680 (bytes checked) and substitutes key 0 for that one call, logs BADBINDING (max 20), counts in BINDUPD
   (`releaseCalls`, `badBindings`) and dumps the whole 50-entry table once per block (BINDTAB).
Untested on real Windows. Not done: gun-feel polish, video picture question (needs the user's answer).

## 0.90
- PADWATCH (PAGE_GUARD single-step on the pad pages) disabled in watch_tick (about 525k exceptions per 3 s, the stutter in 0.89).
- Defaults / rev 90 migration: view_model_pct 100, arms_shoulders 1, rig_view 0, solid_body 1, hbar 1 (health bars back on; off since rev 79).
- hose_off (default 1): cord_hides_hose() true whenever real models + first person; probe cord (handmodel doCord) not drawn.
- body_whole (default 1): with arms_only + arms_shoulders, arm_drive sets headOnly (only neck + head squashed; no stretched triangles to the squash point); probe straps skipped. Log BODYWHOLE.
- PKE wand: t.pkeWand now uses a wandRead flag (0.85 tested wandM[15] != 0 which never held, PKEWAND tries=0). Log PKEDBG every 600 frames while the PKE is held.
- Trap hip zone: trap_hip_drop_cm (70) and trap_hip_radius_cm (28) replace 0.55 m / 0.20 m; plain-X log shows hand-to-hip distance.

## 0.91
- 0.90 log: bars hidden by gate (drawnRecently test pass 3 / fail 978); gate vis test removed, hbar_gate default 0 (rev 91).
- Trap: hold X or left grip (grip bit cleared while held); throw only on release with >= 0.8*1.6 m/s (gearmath Trap::update). Log showed grabs working with zone 70 cm / 28 cm.
- PKE: PKEWAND placed 16931 but offset from hand 2.3 ft (wand slot matrix not at the hand in the PKE animation). New pke_like_gun (default 1): PKE goes through the gun path (pkeWand off).
- Wheel: Y press for PKE worked only before the first fight_request_item (ready-item) call; PRO with PKE out now sends D-pad 0x1.
- Slam: gauge at player+0x24A40 never changed (34k samples); SLAMSCAN logs floats 0x24A00..0x24ABF changing while capture is held.
- Menu: Rig page wrist/elbow rows; Fight page hose row.

## 0.93
- Labels: GBVR_WIDE_VERSION (menu footer, window title) was stuck at 0.76 and GBVR_VERSION_FILE (log file name) at 0.37, so reports could not be matched to builds. Both now follow GBVR_VERSION (0.93).
- Hand on the controller (setting grip_at_hand, default 1): the game's hand sits ~10 cm from the wand's origin; the wand origin was put on the controller and the wrist at controller + R*offset, so the drawn hand swung round the real one when the wrist turned. Now the wrist target is the controller point and the wand slides by -R*offset (armcore.h gripShift, arms_grip_shift(), applied to W2 translation in the wand hook and to the beam's stream start). Log: WAND ... handAtHand= handFit= tipFit=.
- Wheel: PRO while the PKE is out is a Y press (stow) instead of D-pad/ready-item; every PKE/PRO pick is checked 0.7 s later (g_pend) and retried up to 4 times, the 3rd and 4th try send the equipment button (D-pad up) first. Log: "WHEEL check:".
- PKE own model (pke_own default 1, pke_tilt_deg 20): 0.85-0.92 never placed the game's PKE (PKEWAND 2.36 ft off the hand in the 0.90 log; wand-slot vs cloth_pke bones unclear, gripFar passes = PKE out). Now handmath.h build_pke (372 vertices) is drawn by handmodel.cpp at the right controller (tilt about x) while fight_items cur==5; the wand hook zero-scales the game's wand-slot matrix and armcore squashes cloth_pke/cloth_pke1 (ArmTargets.hidePke) while it is out. Log: PKEOWN lines. Menu: Gear "PKE meter in your hand", Controls "PKE meter tilt".
- User asked (voice, garbled): "wave it around, [scan?], and [?] it from the air" - read as: free movement, scan by pointing; unconfirmed.
- 0.93 data: HANDFEEL (handmodel.cpp: per frame controller speed / second-difference shake / still frames / jumps / turn per frame, both hands), GRIPFIT (gun slide cm, PKE bones squashed passes), SLAMSCAN widened to player+0x24800..0x24D00 (floats and small whole numbers that change while the capture stream is held, 150/100 lines), WHEEL check lines.

## 0.94
- The real held PKE is CPKEMeter (size 0x690, vtable RVA 0x790d18), `*(player+0x24D90)`; owner +0x4A8, model instance +0x428 (vtable +0x240 returns it). World pose: position float[3] +0x4B8, rotation 3x3 +0x4C4 with s[3*i+j] = M[j*4+i]
  (local axis j in world = (s[j], s[3+j], s[6+j]); forward = row 2). Written every frame by the player update 0xD6270 (setters 0x141E60 4x4, 0x141EE0 pos+euler, 0x141F10 pos+3x3) from the animated "R_PKE" attach + aim heading/pitch.
  Draw: vtable +0xE8 collect 0x141070 (reads the pose at 0x1411C8 / 0x141236). Update: vtable +0x80 0x141860 (args this, dt) runs the scan (0x1436E0 ... strength 0x1430B0): ray start = the model's "tip" attach
  (entity attach-world getter 0x2C1E40(this, name, out4x4) = local attachment (vtable +0x240 instance, 0x31A010) x entity matrix at +0xF4 / +0x54), direction = the player's iAimDir (getter 0x76E80) or the lock-on target (player+0xB550).
  The 0.85-0.93 PKE work moved the wand-slot model (a stowed gun, 2.3 ft away) or squashed the belt bones (cloth_pke): neither is the PKE the player sees.
- engine_hooks.cpp `pke_place`: MinHook on collect and update; for the player's PKE while item 5 is in hand the pose is rewritten: pointing axis found once (|dot| >= 0.9 with the controller direction, else local +Z),
  whole pose swung onto the controller direction, roll from the controller up (+ wand_roll_deg), optional tilt (pke_tilt_deg, front down), position = controller grip point (+ solid-body push + grip-at-hand shift + pke_fwd_cm / pke_up_cm).
  pkemath.h holds the math (tests/test_pke.cpp). Hook on 0x2C1E40 corrects the "tip" (attachment x entity^-1 x placed pose) so the scan starts at the hand. Wand-slot model stays hidden (zero scale) while the PKE is out.
  Settings: pke_game (1), pke_fwd_cm, pke_up_cm, pke_tilt_deg (0), pke_assist_deg (14), pke_assist_pct (100). pke_own (the drawn copy) and hbar default 0.
- Scan help: damage.cpp `pke_sources_scan` lists CPKESource actors (vtable 0x791568, position at +0x54) 10x/s while the PKE is out (fight_pke_sources); head_aim_publish pulls the published aim (adir) toward the best one inside pke_assist_deg
  (assist::step with its own state, strength x1.5, size 1.2 ft). Log: PKESRC (new source, state dwords +0x468..0x470 to find a "scanned" flag), PKEASSIST.
- PKE has no weight (controllers.cpp: heaviness 0 while item 5 is in hand). Gun: weightmath.h omega1 52/(1+0.3k) zeta 0.9 (was 42/(1+0.35k)), omega2 90/(1+0.35k), max lag 12/8 deg (was 20/16), one-handed firing slows 38 % (was 55 %),
  twist lock (Params.twistLock, setting gun_twist_pct 90): the roll about the barrel is taken from the hand at once, the pointing keeps its weight. Default gun_heft_pct 100 (was 150; settings rev 93 migrates 150 -> 100).
- Ring: hbar default 0 (settings rev 93); the game's ring is untouched (drawn with the engine's rectangle in the eye picture). RING log lines show ring+0x19C/0x1A0 (projected position) and ring+0x1A8 (ghost position).
- Wheel PKE/PRO check: up to 8 tries, waits 0.8 s then 1.4 s, every other later try sends the equipment button first. The failure line now lists all item states.
- Open: slam meter field, hand feel, cutscene video "sound but no picture", gun over glove, which local axis the model's front is (PKEGAME logs it), whether the entity matrix at +0xF4/+0x54 mirrors the pose (PKETIP / PKEGAME lines).

## 0.95
- PKE weight: weightmath.h `pke_params(pct, twistLock)` (setting pke_weight_pct, default 40): spring omega 60 / (1 + 2.5u) rad/s, zeta 0.72 (a hair of overshoot), lag cap 4 + 8u degrees, droop/sway from heaviness 0.2 + 0.6u,
  no recoil/kick (controllers.cpp passes firing = 0 while `engine_pke_item()`); the PKE's pose then reaches pke_place through the same weighted wandPose/dir/grip/wup as the gun. Position inertia via step_pos with that heaviness.
  Unit-tested (test_weight.cpp): 40 % = about 3.5 degrees behind 50 ms into a 30 degree flick, never more than 7.2 degrees behind a steady turn.
- One-handed shot punishment: `Params.punish` (setting gun_punish_pct, default 100; 0 = the 0.94 numbers). One-handed firing (oneFire = stiff x (1 - two)) now: omega x (1 - (0.38 + 0.15 pn)), zeta - (0.18 + 0.08 pn),
  sway + (2.4 + 1.2 pn) x heaviness degrees, climb/shake x (1 + (3 + 1.4 pn) oneFire), muzzle kick (2 + 2 pn) x heaviness degrees, lag cap x (1 + 0.6 + 0.4 pn) (= 24 degrees one-handed), position cap bigger.
  New `strain` (0..1): +1 per 3.5 s of one-handed fire, -1 per 2 s otherwise; sway and climb x (1 + 0.5 pn strain); the stream buzz grows with it (controllers.cpp). Two hands are unchanged.
  Log WEIGHT2: PKE polls/mean/max lag, one-handed shot sway/climb/strain maxima. The WEIGHT line is gun-only now.
- 2D screens (stereo.cpp show_flat): the "black box" is read as SteamVR's grid room, which the compositor shows after ClearLastSubmittedFrame. `vr_capi_fade_grid(0.25, 0)` (IVRCompositor::FadeGrid) is called when the flat screen
  starts and re-checked about every 1.5 s (GetCurrentGridAlpha > 0.02 -> again); setting flat_void (1). Log FLATVOID (alpha before, then 1 s and 4 s later). If a box is still seen the next step is SetSkyboxOverride with a black cube.
- TV glow (flatglow.cpp, glowmath.h, setting flat_glow_pct 70): a second overlay "gbvr.flatglow" (sort order 1, the screen is now 2, menus 20+) with a straight-alpha picture 160 x ~123: transparent over the screen, alpha peak 0.5 x strength at the
  edge falling to 0 over 0.35 screen widths; colour = 70 % nearest picture edge + 30 % picture mean (x 1.6), black bars skipped. Source: a copy of the flat texture into a texture with a full mip chain (GENERATE_MIPS), GenerateMips, the level with
  <= 24 cells copied to a staging texture, mapped next time with DO_NOT_WAIT (about every 90 ms; formats RGBA8 / BGRA8 / RGB10A2, anything else = constant light). The picture eases toward the target (k 0.18, max 0.10 per update, 15 Hz) so a flash never flashes the glow;
  alpha is dithered. Log FLATGLOW (setup, readings, counts).
- Menu: the three PKE/gun rows added in 0.94 were hidden (Controls page had n = 5, rows 6-8 never showed); fixed (n = 8, row 8 = PKE weight). New Feel tab (gun_punish_pct, gun_twist_pct, flat_void, flat_glow_pct); 11 tabs (50 px tall).
- Open: slam meter field, hand feel, cutscene video "sound but no picture", gun over glove, the PKE's front axis and fit (PKEGAME / PKETIP), whether FadeGrid is enough for the black void (FLATVOID).

## 0.96

Mod compatibility (the user is adding the Ghostbusters Deluxe mod, ModDB "ghostbusters-deluxe", WIP v0.83a, 88 MB; the page has no install steps and does not say whether it targets the 2009 game or the Remastered).

- New `src/modscan.cpp` + `src/modscanmath.h` (tests/test_modscan.cpp). `modscan_start()` is called from `init_once_cb` after `sysinfo_log()`. It starts a below-normal thread that waits 4 s and then logs MODSCAN lines:
  - `MODSCAN exe`: size, CRC-32, date of the running ghost.exe and whether it is the analysed file (`layout::kVanillaExeFileSize` 15,854,592 / `kVanillaExeCrc32` 0x2E738F86, also checked by verify_layout.py). A different exe is not an error: engine hooks are already gated on PE identity and on 16 bytes at every hook site (`check_game_module`, `bytes_match`).
  - `MODSCAN folder`: walk of the game folder (depth 4, 8 s / 80k file cap): every top-level entry, per-folder totals with oldest/newest date, DLL/EXE/ASI at any depth (with version/company/product), small settings files, `WATCH` (ASI plugins, loader-style DLLs) and `CONFLICT?` (a dxgi/d3d9/xinput DLL next to ghost.exe), "deluxe" markers, the busiest write days, and other folders next to the game folder that hold a ghost.exe.
  - `MODSCAN module[n]` at 25 s, 100 s, 300 s, 900 s: loaded modules outside Windows/drivers with path, version, company, product; later snapshots only list new ones; overlay/capture tools (RTSS, OBS, Discord, Steam overlay) are tagged because they hook the same Present call.
  - It uses its own version-info buffer: `sysinfo.cpp`'s `file_version` has a static 64 KB buffer and runs on the render thread.
- `gbvr_manager.ps1`: `Get-ModNotes` (INSTALL, CHECK and COLLECT print/collect it; warns about a foreign d3d11.dll, dxgi.dll, xinput DLL, a changed probe file, a second game folder), `Collect-ModInfo` (zip folder `mods/`: mod_notes.txt, modscan_from_log.txt, game_inventory.csv, game_folder_summary.txt with write-day histogram, game_file_hashes.txt, files/ with small readme/ini/cfg/log files, steam_install_record.txt with harmless keys only, game_settings_folder_listing.txt + settings.ini). Parse-checked and run on a fake game folder with PowerShell 7 on Linux.
- No setting, hook or feel changed. `kSettingsRev` stays 94.

## 0.97
What the 0.96 report (04:04 session, log `gbvr_probe_0.96_20261018-040415.log`) proved, and what 0.97 changes. Nothing below has been run in the game (no Windows/Wine here): "untested" until a 0.97 log shows it.

### Log findings (facts)
- `PKEGAME` "moved 2.62 ft" once, then 0.00 forever: the 0.94-0.96 code rewrote only the CPKEMeter second pose (+0x4B8 pos / +0x4C4 rot). The DRAWN meter uses the ENTITY matrix (pos +0x54 `kActorPos`, rot +0xF4 `kOffEntityRot`): collect 0x141070 -> base collect 0x140110570 -> `0x1402C2800` = `jmp 0x140041360(ctx, this+0x54, this+0xF4)`, then the model instance is drawn with an identity local matrix. The player update (~0xD6270) rewrites the entity every frame (`0x1402C3AB0(PKE, pos, angles)`). The scan range centre (`0x142120`, XZ distance from +0x54/+0x5C) and the effects/sounds (`0x1436E0` at rbx+0x54) use the same entity position.
- `PKETIP ... model's own axes 0.00,1.07,0.03`: the model front is local +Y. 0.94-0.96 locked the pointing axis to local Z (the axis whose dot with the game's aim was largest in the animation pose), so the meter was held 90 degrees off.
- ARMS: right `noTarget` 0 until frame ~11100 and then +1/pass to the end (5083). `HOLSTER wand holstered` at frame ~11094. arm_drive only produced a right target from the wand-matrix path, which is off while holstered. So after the holster the avatar's arm stayed in the animation (the "PKE is in the animation" pictures).
- WHEEL: PKE came out at frame 6762 (in hand 5); four PROTON picks, each 8 Y/D-pad tries, never returned the gun (in hand 5 until the end). `readyItemCalls=0` all session.
- `PKESRC distinct=2`: the only PKE sources in the level were 234.8 ft and 400.6 ft away; no ghosts (`RING ghost at 0,0,0`). Nothing to scan in range.
- WEIGHT: `posLagMm(mean/max/capped)=8/71/394`, max rotation lag 22.6 deg one-handed; maxFatigue 100 %, droop 1.4 deg. GUNHAND wrist miss 0.00 (the wrist is exactly at the target). So no log shows the gun separating from the hand; the lag against the real hand is the only measured candidate.
- MODSCAN: `MODS` folder at game root, 79 files / 21 folders / 103 MB, with `MODS\deluxe`. Loaders present: only the Ultimate ASI Loader (`winmm.dll`) + `GhostbustersNoIntro.asi`. ghost.exe has no "MODS" string. Whether the Deluxe mod loads is unproven.

### Changes
- `pkemath.h`: `pke::look()` builds the pose from two axes (front = model front axis, up = the axis that points up in the game's level hold) set to the controller direction/up, keeps the matrix handedness, optional tilt/roll; `pke::rigid()` = the rigid turn old frame -> new frame (for the arm). `tests/test_pke.cpp` covers them.
- `engine_hooks.cpp` PKE block rewritten (`pke_place_locked`): reads the game's placement from the entity matrix (or the second pose when `pke_entity=0`), remembers what it wrote (`wPos/wRot`) so it can tell its own values from a fresh game placement, sets pose AND entity to the controller grip (solid-body push + grip shift + fit offsets). The entity is NOT restored afterwards (the draw may use it later; the game rewrites it each frame). The front axis is read from the tip attachment's local vector (`hk_entity_attach`), default +Y; the up axis is found once from the game's level hold (|dot with world up| >= 0.6) and locked after 40 unclear calls. Spin lock around the placement (collect and update can run on different threads).
- `pke_arm_target()` exports the rigid motion (game placement -> controller) under a seqlock; `arm_drive` feeds it as the right-arm target (wandR/wandP0/grip/rdir/rup, gunLen 0) when the game's PKE is in hand, independent of the holster state; `pkeAttach/pkeWand` are forced off then.
- Diagnostics: `PKEGAME` (axes, entity vs pose), `PKETIP` (tip in model axes, tip on entity), `PKESCAN` (scan flag +0x53C flips, target at +0x4E8, progress +0x548/+0x54C, raw state dwords; nearest source distance every 5 s), `PKEARM` counters, `+0x24E80` parent check, auto picture 3 s and 12 s after the PKE comes out.
- Gun: `weight::kPosCapM` 0.04 -> 0.02 (one-handed firing scales it up to 2.6x); `GUNLOST` detector in arm_drive (gun out, right hand without target, reasons: aim stale / wand unreadable / no solution; picture on the first 2 of the last two).
- Wheel: last resort in `controllers.cpp` when a PROTON pick fails 8 tries with the PKE in hand: one `fight_request_item(kItemProton)` (the 0.90 note says Y may not bring the PKE out again after a ready-item call).
- `modscan.cpp`: `MODOPEN` observer = MinHook on `kernelbase!CreateFileW`; records opens whose path has `\mods\` or ends in `tweak.txt` (`modscan::mod_path_hit`) into a 64-entry lock-free ring flushed by the scan thread (no logging inside the hook); summaries at 25 s / 100 s / 5 min / 15 min / 1 h. Only opens after the probe starts are seen. `MODSCAN MODS folder` line with the newest write and last-access dates.
- New setting `pke_entity` (default 1); `kSettingsRev` stays 94.

## 1.0
Shipped as "1.0" because the user asked "Make this all 1.0" (the working name was 0.98). Built from the 0.97 report (12:27 session, `gbvr_probe_0.97_20261018-122740.log`, 7 pictures) and the user's 12:34-12:54 messages. Nothing below has been run in the game (no Windows/Wine here): "untested" until a 1.0 log shows it.

### Log findings (facts)
- 2D screens: `ClearLastSubmittedFrame` left SteamVR with no scene, so SteamVR Home showed behind the black box. `FadeGrid` only removes the grid. The glow followed the picture colours, so it flashed.
- Body gone with the PKE out: the game's "render only in mirrors" answer is true while the PKE is in hand (the game's own PKE view). The draw predicate at RVA 0xEEC70 is flag-based only (refuses flag!=0 outside mirror views; 0 when draw-ctx pass==8 and the owner matches).
- Wall episodes (WALL #1-#5): zero game refusals, so the right-eye body loss near walls is a different, still undiagnosed cause. `WALLEYE` / `BODYEYE` now count per eye.
- PKE too far from the controller / flickering: GRIPFIT shift averaged 11.7 cm, up to 21.6 cm, valid for 40 ms only, so the slide was added unsteadily.
- Controls: the game's gamepad indices are 0=Y(PKE) 1=B(Jump) 2=A(Interact) 3=X(trap) 4=LT 5=RT 6=LB 7=RB 8=Start 9=Back 10=L3(Sprint) 11=R3(DisplayHUD) 28-31 = D-pad L/R/U/D. The probe never sent L3.
- Pacing: FRAMETIME pair windows median 144 fps (72 pairs/s), 35 of 250 windows had a frame over 40 ms. Picture 3840x2880 is the engine maximum (eye pixels 2233x2413 vs SteamVR recommended 2496x2688).
- Gun/wrist drift: GUNHAND "wrist fell short" 0.00 ft throughout, so it is not arm reach. WAND `applied` froze between frames ~8500 and 36000 while `pushes` kept growing (`WANDGATE` now says which gate).

### Changes
- Flat mode: `flat_black_frames` (default 1). A 64x64 black texture (`g_blackTex`, created in `acquire_back_buffer`) is submitted to both eyes every flat frame (`submit_black`), so SteamVR always has a scene. `enter_flat_mode` no longer calls `ClearLastSubmittedFrame` while it is on. `FLATVOIDSUM` lists blackOK/blackFail/blackNow.
- Glow: `flat_glow_steady` (default 1). `glow::blend_toward` (k = dt/(tau+dt), tau 5 s) keeps a slow grid; `glow::steady_look` (edge share 0.35, peak 0.42); smaller ease steps. `flatglow.cpp` resets it on hide/release.
- PKE body: `pke_show_body` (default 1). `hk_mirror_only_impl` returns 0 (not "mirror only") for the six body sites while the PKE is in hand; counters `BODYPKE` and `BODYEYE` (asked/hidden/drawn/refused per eye, `g_be.eye` set before each frame is published). `pke_pair_cache` (default 1) keeps one PKE placement per eye pair.
- PKE steadiness: `pke::ShiftState` / `shift_step` in `pkemath.h` (hold 0.5 s, fade over 0.3 s, ease tau 0.06 s). `pke_shift_pct` (default 50) is the share of the gun's hand slide that the PKE gets. `PKESHIFT` log line. `pke_weight_pct` default 40 -> 55 (settings migration at `kSettingsRev` 95).
- Controls (`padmath.h`, `ctlmap.h`, `controllers.cpp`):
  - `sprint_click` (default 1): left stick click = L3 (Sprint). The old second fire (LT on the right stick click via RB) moves to the right stick click = LT=255; Vent stays over-the-shoulder and is in the layer.
  - The Y button is a tap/hold machine (`g_yHold`, hold 300 ms, min tap 90 ms): tap = Y (PKE); hold = D layer: right stick -> D-pad (mag > 0.6, no turning), right stick click -> RB (Vent), right B (VR menu button) -> R3 (HUD), right A -> Back (Select). The layer needs `sprint_click`, a head pose, no VR menu, in game, wheel closed, left grip not pressed. The A machine is reset while the layer is on. `hlStart` keeps the raw Y for Menu+grip = Start.
  - `ctlmap.h` conflict test updated (`kGLayer`, `isNew078 == 2`, new kSettled entries). Logs: `DLAYER`, `NEWPAD`.
  - VR menu: Controls page gets "Sprint on left stick click" and "PKE closer to my hand"; Feel page gets "Calm TV glow", "Black behind 2D screens", "Show body with the PKE"; Help page 5 lists the buttons.
- Rate / sharpness: `ratemath.h` (`best_fit`, `work_budget_ms`, `area_ratio`), `vr_capi_display_hz()` / `vr_capi_recommended_size()`. `g_workBudgetMs` replaces the hard-coded 11.1 ms in `submit_eyes`. Log lines `PACING` (now with workOverBudget and displayHz), `RATEFIT` (which of 72/80/90/120 Hz the measured work fits), `SHARPNESS` (eye pixels vs SteamVR recommended). The picture level itself is unchanged (3 is the engine maximum).
- Smoothness: `SMOOTH` (steady / late / hitch counts of eye submissions, gaps > 2 s ignored) and `ANIMPUSH` (change in the avatar's eye error between passes: how much the animation pushes the player) in `arms.cpp` / `armcore.h` stats.
- Mod look: `modscan_mark_note()` is called from `probe_mark` (F2 / both grips + both stick clicks) and logs `MODLOOK` (MODOPEN counters at that moment). `COLLECT_LOGS` keeps 14 pictures (was 10).
- Gun drift diagnostic: `WANDGATE` (settings/stereo gate, other buster's wand, PKE out, noAim, stale, holstered, noTip, farSkip, seconds since last applied).
- Tests: `test_glow`, `test_pke`, `test_ctlmap`, `test_rate` (new) and `test_pad` cover the new maths; `verify_layout.py` unchanged. `kSettingsRev` 94 -> 95.

### Not diagnosed (next log should say)
- Right-eye body loss near walls (`WALLEYE`, `BODYEYE`).
- Gun floating out of the hand later in a session (`WANDGATE`, `PKESHIFT`, GUNHAND).
- What "the animation messes with the player" means in numbers (`ANIMPUSH`, `SMOOTH`).

## 1.1

Log findings (1.0 log, 27180 frames, 6 minutes):
- PKE out by Y at frame ~8057 (try 1). Wheel PRO pick (stow): 8 Y tries, the game saw `action 6` pressed every time (BTNEVENT), nothing happened. 0.97 last resort `ReadyItem(1)` worked once (item states 1 2 0 0 1 1 1 0). After that about 10 PKE picks: all failed. So the input reaches the game; the game drops the request.
- WANDGATE: applied 20428, only paused while the PKE was out (pkeOut 4211), GUNLOST 0, PKESHIFT mean 6.3 / max 6.5 cm. Nothing on the probe side explains "gun went away".
- FLATGLOW: reading the picture fine (15x11 cells, lastMean steady), `steady=1`. Only ~614 flat frames in the whole log. The old path called SetOverlayRaw about 15 times a second while the slow average moved; suspected blink source.

The game's item switch (all addresses RVA, player = `this`):
- Y handler (action 6 on button 0), region 0xDC517: needs `[+0x24858]==0`; PKE in hand -> request item `[+0x24CE4]` (else 5) else request 5. A request is `[+0x24CE0]=item` and `[+0xC7A8] |= 0x400000`. The whole input block only runs when the "input allowed" byte is 1: not blocked by any of 0xEBD90, 0xEABF0 (`[+0x24E78]!=0`), 0x80710 (`[+0xC7F0]!=0`), 0x76950 (`[+0x88C0]!=0`), 0x7CF10, 0x7D380, 0x7D1B0, 0x7D1F0 (anim-state checks via 0x311360(player+0x430, id) with the byte `[+0x2468]`), `[+0x2482B]`; and not item0 in hand, 0xD7070, `[+0x24838]>0` (a float lock timer), `[+0x2485B]`.
- 0xD7C44: while flag 0x400000 is set the per-frame code calls the processor 0xE2FC0. The processor takes `[+0x24CE0]`, CLEARS it at once (so a blocked request is simply lost), then drops the request if item 0 is in hand, 0x7D230 (anim state `[+0xB608]`), `[+0x88C0]`, `[+0xC7F0]`, `[+0x24E78]`, or the target state is not 1; else calls ReadyItem 0xE3F10 (r8=1).
- ReadyItem 0xE3F10: returns false if `[+0x24D74]==0`, the target state is 0 or 3, or the target is already in hand with no pending switch; also bails on anim-state checks 0x7D1B0 / 0x7D1F0. It then writes `[+0xD0A4]=old`, `[+0x24CD8]=old` (pending "stowed" event), `[+0x24CDC]=new` (pending "drawn" event), and for item 5 `[+0x24CE4]` = the item to return to (old, or 1 if old was 5).
- The animation-event dispatcher (0xC9650) consumes the two pending fields: stow-finished runs 0xE3570(player, `[+0x24CD8]`) and clears it; draw-finished runs vtable[0x8F0](player, `[+0x24CDC]`) and clears it.
- 0xE50E0 = "finish the pending switch now": runs both handlers for whatever is pending and clears both fields. The game calls it from 8 places (it is its own cancel).

Hypothesis (unproven): a pending marker stays set because the animation signal never comes (or one of the other checks is stuck), and every later Y request is dropped silently.

Changes:
- `damage.cpp` `g_sw` watch (25 per second): reads the fields above plus the six anim-state predicates (0x7CF10, 0x7D1B0, 0x7D1F0, 0x7D230, 0x7D380, 0xD7070; pure readers, called only when `[+0x2468]!=0`), keeps a 17-bit mask, logs SWITCHGATE on a change in the first 10 bits + the request bit (max 160 lines, 4 per second) and whenever the wheel asks (`fight_switch_note`), SWITCHSUM in the periodic report.
- Recovery (setting `switch_help`, default 1): if a switch stays pending for 3 s the game thread calls 0xE50E0; the wheel's even retry tries call `fight_switch_help(item)`: finish a switch pending for over 1.2 s, then write `[+0x24CE0]=item` and set 0x400000 (the same as a Y press, without the input-allowed check) when the target state is 1 and it is not in hand. Odd tries press Y as before (D-pad up first from try 3). The 0.97 last resort stays.
- Steady glow: halo texture sent once per flat screen (white RGB + the soft edge alpha); colour = `glow::ambient_target` (hue of the picture's average, luma 0.64, default blue-white for black pictures), followed with tau 6 s and at most 0.05 per channel per second through `vr_capi_glow_tint` (SetOverlayColor / SetOverlayAlpha). Fade in 1.6 s. Old per-frame path stays for `flat_glow_steady=0`.
- Flat screen: size (`flat_size_pct`, as an angle), distance, drop, curve (`glow::screen_curvature`, OpenVR curvature c = width / (2 pi r) for a screen that wraps around the viewer at 100 %), 0.45 s fade-in, remembered style applied before the overlay is first shown. VR menu: new Screen tab (12 tabs, 45 px each).
- Haptics: short buzz in the right hand when a wheel switch lands.

Still not diagnosed: the real blocker in the game (needs a SWITCHGATE line from a failed press), body vanishing in the right eye near walls (WALLEYE/BODYEYE still collecting), the gun leaving the hand later.

## 1.2

User asked: "Make sure the monitor can see the full view model and all equipment and ghost and health bars, and it's a wide view from the head" + "and no flickering" + "the viewmodel and stuff". The 1.1 reading of "front view" (the in-headset 2D screen) was probably wrong: the PC window is meant.

Findings (1.0 recording / log):
- In headset mode `flatview_present` is not called (stereoActive), so the window showed the raw back buffer of every Present. In pair mode (`stereo.cpp`, `g_ctl.stereoPair`) a Present is one eye of a pair, so the window alternated left / right eye pictures (3840 x 2880, 4:3, FOV tanH 1.9042 / tanV 1.42815 = about 125 x 110 degrees), Windows stretched them 4:3 -> 16:9, and the picture rolled with the head.
- BODYEYE (1.0 log, last lines): asked(prepare) left/right = 4798/3591, drawn 5330/3819: the game offers the player's own parts less often in the right eye -> the monitor defaults to the left eye.
- The eye textures `g_eyeTex[e]` (SHADER_RESOURCE | RENDER_TARGET, same size / format as the back buffer) are filled by `copy_back_buffer` BEFORE `stereo_before_present` submits them, and `handmodel_draw` draws the hands / wand into them, so a pass that draws into the back buffer after `stereo_before_present` cannot change what the headset gets.

Changes:
- `monitorview.cpp` (+ `monitormath.h`, `tests/test_monitor.cpp`): `monitorview_present(sc)` runs in the Present hook right after `stereo_before_present` while `stereoActive` and not in flat mode. It takes one eye texture from `stereo_monitor_source(wantEye, ...)` (the wanted eye; the other only while the wanted one has no picture yet; texture + the pose it was drawn for + age in real frames), clears the back buffer, and draws it with a SV_VertexID triangle: VS cbuffer b0 = {M (2x2), centre}, src uv = centre + M * (p - 0.5); PS averages 4 taps at +-0.25 of ddx / ddy of the uv (the 3840 x 2880 picture shrinks about 2.7x into the window), outside [0,1] = black. Fresh SRV + RTV per frame (no references kept); saved / restored state includes the VS constant buffer slot 0; 3 failures switch `monitor_view` off.
- Geometry (`monitormath.h`): `fit` 0 = whole picture in `picture::fit_view` (pillarbox), `fit` 1 = fills the client area with the largest window of the client's shape inside the picture (16:9 -> full width, 3/4 of the height); `monitor_zoom_pct` 50..100 shrinks that window; roll = `atan2(right.y, up.y)` of the eye pose (OpenVR 3x4 row-major, left ear down positive, same sign as the log's roll=), faded to 0 between cos(pitch) 0.12..0.35 (looking straight up / down); the window is turned so the world's up is vertical on the monitor; fit 1 is scaled down (`inscribed_scale`) so the turned window stays inside the picture, fit 0 shows black corners instead. The test builds poses with yaw / pitch / roll and checks that the world's "up" in the picture lands straight up and the horizon direction is perpendicular.
- Present hook (`render_hooks.cpp`): `!stereoActive` -> `flatview_present(sc, 0)` as before; `stereoActive` + `stereo_in_flat_mode()` -> `flatview_present(sc, 1)` (the 2D screen in the headset: the window gets the picture in its own shape; `flatview_get_view` still reports no view while stereoActive, the mouse is not used then); `stereoActive` otherwise -> `monitorview_present(sc)`.
- Settings (`kSettingsRev` 97): `monitor_view` 1, `monitor_eye` 0 (left), `monitor_fit` 0, `monitor_level` 1, `monitor_zoom_pct` 100. VR menu: new "Monitor" tab (13 tabs, 44 px high, end at y 712).
- Gun feel: trigger release after a stream = thud (0.30..0.60 on the fireKick source, 45 ms, grows with the stream's length up to 3 s) + soft tail (0.12..0.22, 150 ms, the otherwise idle `kSrcTrigger` source); off hand half.
- Logging: `MONITORVIEW ready` / `layout` (eye, fit, zoom, level, sizes, source window and the angle it covers, roll) and a `MONITORVIEW frame=` report with draws, noPicture, skipped, mismatch, failed, eyeShown, eyeChanges (must stay 0), pictureAge histogram 0/1/2/3+, oldest, turnedSmaller, blackCorners, roll min / max / avgAbs, drawGapMs avg / max, drawn rectangle and window size.

Not changed: the probe's own health bars stay off (0.94), the game's ring is part of the eye picture. Open: real blocker of the game's item switch, body missing in the right eye near walls, gun leaving the hand later.

## 1.3

User asked: "make the game start in VR, make the transition from flat to VR more polished, and make the ui better in-game polish" + "place the menu and stuff in the black box glow area and any other forced 2d menus, and make sure a cursor is there and is accurate to where it's pointing". Read as: the flat 2D screens (game menus / videos) live in the black void with the TV glow; they get a cursor that is exactly where the laser touches; the VR menu is dimmed-screen-in-the-void on top of a flat screen. (To be confirmed by the user.)

Changes:
- Auto start (`render_hooks.cpp` `auto_start_vr`, called after `poll_keys`): after present frame 20 and `hookBytesOK`, asks `vr_capi_hmd_present(g_selfDir)` (`VR_IsHmdPresent`, does not start SteamVR) once a second; sets `stereoWanted` when a headset is present or after 25 s; if `stereoWanted` falls back to 0 (SteamVR refused) it asks once more after 20 s, then gives up (STARTVR lines). F4 off sets `g_userVrOff` and stops it; F4 on clears it. `start_in_vr` 1.
- Black from the start: `vr_capi_start_black(flatVoid)` before `vr_capi_request_start`; `start_thread` calls `FadeGrid(0, 0)` right after `SetTrackingSpace`; the grid alpha right after is logged (FADEINSUM startGridAlpha).
- Fade into 3D (`stereo.cpp` `fade_in_begin/tick/clear`): `FadeToColor(0, black, 1)` when 3D takes over from a flat screen or the first pair is submitted; three pair ticks (or 250 ms) later `FadeToColor(fade_in_ms/1000, black, 0)`; forced removal 700 ms after the fade should have ended; cleared (`FadeToColor(0,..,0)`) when a flat screen comes and in `deactivate`. `fade_in_ms` 450, 0 = no fades (also the VR menu's 240 ms fade-in via `vr_capi_menu_alpha`).
- Flat cursor (`flatcursor.cpp`): after `menu_pump()` in `show_flat`, a ring is drawn into `g_flatTex` at the laser's (u, v) (`menu_pointer()`: valid 400 ms after the last overlay mouse event), alpha blended, saving / restoring the pipeline state; 3 failures switch `flat_cursor` off. Hidden while the VR menu is open.
- Pointer mapping (`menu.cpp`): the laser uv -> window pixel goes through `flatview_get_view` (the letterboxed view) when the window shows the flat screen in its own shape (`g_activeHeadset`), the same view the PC mouse uses. While the VR menu is open the events are drained and the mouse released (`ignoredWhileVrMenuOpen`).
- Dim: `menu_dim_flat` multiplies the flat screen's overlay fade by 0.28 (ramp 4 per second) while the VR menu is open.
- VR menu (`vrmenu.cpp`): `HK_ROW` hover hits (added before the buttons so the buttons win), row highlight, full description in the footer (font -19, up to 255 chars via `TextJob.s[256]`), page title in the header, new "2D & Start" tab (14 tabs of 40 px, end at y 703), menu fade-in (`vr_capi_menu_alpha`, both overlays; new overlays start at the current alpha).
- Gun: the stream's level is scaled 0.60..1.0 over the first 0.3 s, plus a slow throb (+0.07 / -0.03 at 2.2 Hz) after 1.8 s.
- Settings (`kSettingsRev` 98): `start_in_vr` 1, `fade_in_ms` 450, `flat_cursor` 1, `flat_cursor_pct` 100, `menu_dim_flat` 1.
- Logging: STARTVR, FADEIN / FADEINSUM, FLATCURSOR, FLATUISUM, POINTERMAP, MENU ignoredWhileVrMenuOpen.

Not changed: no new controller bindings (ctlmap conflict test still passes). Open: real blocker of the game's item switch, body missing in the right eye near walls, gun leaving the hand later.

## 1.4

User asked (1.3 test: report zip, logs, 14 pictures, 2 videos): "Still can't scan, and the body goes from good and solid gun in hand to it floating ... Check all bindings and make sure everything is good; check the game logic and make a system for easy PKE scans, and improve the view from the monitor in general, and especially in PKE mode; ... the cause of the PKE overlay is to figure it out. Make sure the health bar is on the ghost at all times, but it disappears when not looking at ghosts or just fired a gun".

Findings (1.3 log + disassembly, all in `layout.h` "1.4" block and checked by `tests/verify_layout.py`):
- The old PKESCAN "ON/off" line was `+0x53C` = the item is equipped, NOT the scan. The real scan is `scan_ok` (0x1456A0): equipped, a target in the record at `+0x4E8`, cooldown `+0x540` <= 0, the target's vcalls `+0x3F8` true / `+0x278` false, visible flag `+0x4FC`, ground distance squared `+0x4F8` <= range squared `+0x4F0` (225 = 15 ft), alignment `+0x500` > the global float at RVA 0xEA9C88 (= cos 18 deg, written by the static initialiser at 0x5BB0 from the double at 0x791170). The enumeration (0x142120) also drops every target below that cosine. The player's per-frame code (0xD8F60) sets the input byte `+0x538` while the primary request bit (0x40) is down and the PKE is the held item. Ghosts in the 1.3 log were 37-65 ft away: no scan was possible.
- The green frame is the second full-screen quad of the overlay draw (0x205660, called at 0x1FE60A before HUD::Draw): drawn when `overlay+0x448` is 1 or 2 (read at 0x20594B). "xor eax,eax; nop x4" over that 6-byte read skips it.
- Bars: `hbar` was 0 since 0.94 (settings rev 93); the game's ring (`targetSet=0` the whole 1.3 run) shows only for the targeted ghost, and only on ~1 of 9 frames.
- Monitor: 1.3 log `fit=whole zoom=100`, `blackCorners=73991` of 79916 draws (a constant 1.4 degree head roll turned the picture, leaving wedges).
- WANDGATE: `pkeOut` 65789 of 123698 pushes: the PKE was out most of the run; `applied` froze while it was out. The "floating body" is probably the game's PKE pose (torso lean 36-40 deg, arms stretched) with `pke_show_body` on. Not proven.

Changes:
- `pkeeasymath.h` + `tests/test_pkeeasy.cpp`: window / start / keep decisions, cone cosine, rumble level.
- `engine_hooks.cpp` "1.4 the forgiving PKE scan": `pke_easy_threshold` (the game's cone global follows `pke_cone_deg`, original kept and restored with `pke_easy` 0), `hk_pke_scan_ok` (second ask with the record's range raised to `pke_easy_ft` when only the range failed), `pke_easy_pre` (sets `+0x538` while `want_input` holds: `pke_auto`), `pke_easy_post` (target / scan start / end logging with PKEEASY lines, haptics `kSrcScan`, the locked target for the aim help, 3 pictures at scan starts), `engine_goggle_apply` (the 6-byte patch, called from `hk_hud_draw` = same thread as the overlay draw), `pke_easy_report`. The aim help (`head_aim_publish`) now also takes the game's locked target. The old PKESCAN ON/off line is relabelled equipped / put away.
- Settings (rev 99): `pke_easy` 1, `pke_easy_ft` 35, `pke_cone_deg` 40, `pke_auto` 1, `pke_frame` 0, `pke_assist_deg` 14 -> 24, `hbar` 1, `hbar_gate` 0, `ring_mode` 1, `monitor_fit` 1, `monitor_zoom_pct` 100 -> 72. VR menu: Feel tab 8 rows (Easy PKE scan, Scan distance, Scan angle, Scan by pointing), Monitor tab 8 rows (Green PKE goggle frame).
- Monitor: `monitor::calm_roll` (dead zone 2.5 deg, low-pass 0.15 s, 30 deg limit) used by `monitorview.cpp`; report line gets rawHeadRollMax / followedMax.
- Gun feel: `fight_hit_age_ms()` (damage.cpp) -> a bright flutter on the stream's rumble while a ghost's health drops (350 ms fade).
- FLOATCHECK (handmodel.cpp `float_log`): item in hand, torso lean from the vertical, joints from the eye, wrist-to-controller miss; a picture when the miss > 15 cm or the lean jumps 18 deg (max 6, 20 s apart).
- BTNEVENT: one line per button press (the first action bound to it), cap 1500.
- ctlmap: no new button; the trigger entry mentions the PKE scan.

Not changed / open: the game's item-switch blocker (SWITCHGATE data), body missing in the right eye near walls, the cause of "floating" (FLOATCHECK + pictures collect it).

## 1.5

User asked (after 1.4): "NO, I WANT THE GAME HEALTH BAR AND ALSO MAKE THE CHARACTER FOLLOW WHERE YOU'RE LOOKING SO YOU CAN TURN JUST BY TURNING YOUR HEAD, BUT ALSO WITH SNAP TURN OFC".

Findings (layout.h "1.5" block, checked by `tests/verify_layout.py`):
- The game's health ring is a HUD object: update `0x24D450` (this, dt in xmm1), draw `0x24D810` (draws only when the state test `0x255680`, `[ring+0xC] != 0`, passes; world position at `ring+0x1A8..0x1B0`). Its inputs are two player getters: `GetFocusPos` `0xDE1F0(player, out)` (locked target `[player+0x2E8]` +0x54..0x5C, or the PKE record's target when item 5 is equipped; false = ring hides) and `GetFocusHealth` `0xDE1E0` = `[player+0x24938]` (-1 = none).
- The lock is set by SetTarget `0xE8CF0` (inside the aim function) and released by `0xE8ED0`; the VR logs show 0 targets for 81,030 ring draws since 0.93, so the ring never had anything to show.

Changes:
- Ring assist (`hud.cpp`): hooks on the ring update (sets a same-thread flag) and on the two getters; only while the ring update runs and only when the game has no answer of its own does `fight_ring_pick` (damage.cpp) answer with the ghost picked by gaze (cone `ring_cone_deg` 28, x1.6 for the current or recently hit ghost, hold `ring_hold_ds` 25 = 2.5 s, < 60 m, off while a PKE item is in hand). Health = actor+0xB860/0xB868, position = actor+0x54 (the same point the game's own lock reports). Logs: RINGPICK, RINGFORCE.
- damage.cpp: hit tracking now runs for every living enemy (the 1.4 version only ran inside the bars loop).
- Head-follow (`followmath.h`, tests in `tests/test_follow.cpp`): the stereo view = level(game yaw) * L, L = head rotation vs recenter. The probe keeps A = the yaw it made the game turn for the player (`vr_follow_add`, headtrack.cpp) and uses L_eff = level(-A) * L_raw (also for the head position and the controller poses), so the picture does not turn twice. e = basis_yaw(L_eff); past `turn_follow_deg` (35) the right stick axis is pushed toward the head (strength by error, min 0.38 to pass the game's dead zone) until |e| < 7 deg. The sign of the push is learned from the first turns; no answer for 1.3 s = give up for 5 s; camera jumps > 45 deg are ignored (cut-scenes, respawns); the player's own stick wins in smooth mode. Blocked in menu / wheel / D layer / D-pad-with-grip / not in a level / forced moves.
- Snap turn: a flick of the right stick (> 0.7, back to < 0.35 before the next) = A -= `turn_snap_deg` (the picture jumps at once), then the same catch-up turns the body. The game's own smooth turn is zeroed while snap is on, except the slam swing's own stick flick (fixed during the 1.5 build).
- Settings (rev 100): `ring_assist` 1, `ring_cone_deg` 28, `ring_hold_ds` 25, `turn_follow` 1, `turn_follow_deg` 35, `turn_snap` 1, `turn_snap_deg` 30; migration sets `hbar` 0 and `ring_mode` 0 (the game's ring is shown, the probe's bars are off).
- VR menu: new "Turn" tab (15 tabs, 37 px high, font -28); the extra-bars toggle moved there, Fight keeps the bar size / number / gate.
- 1.4 bug fixed: `g_ctl.gunTwistPct = 90;` had been swallowed into a comment in proxy.cpp (new installs got 0).
- ctlmap: no new button; the "stick = turn" line now documents the snap turn and the follow push.

Not tested in the game. Open: the real cause of the floating body / gun (quick test: Feel tab "Body stays with the PKE" OFF), PKE scanning (1.4), body missing in the right eye near walls, the game's item-switch blocker.

## 1.6

User report (1.5 logs, after 1.5): "Gun and PKE still float, but not at the start of the game. FIX THIS TOP PRIORITY. PKE still won't scan. ... monitor still filled no matter the resolution ... weapon wheel semi-transparent with a red outline ... locked weapon: no name, give ? ... Game HUD sometimes does not load in the right eye, and the health stays on ghosts that are gone".

Findings (layout.h "1.6" block, checked by `tests/verify_layout.py`):
- Floating: the game's hand-to-weapon offset is 3-21 cm and jumps up to 15 cm between frames; the 1.5 PKE slide was applied at 50 % in world space and the gun's fatigue sag grew with dt/12 s. Fix = `pke::RigidShift` / `rigid_step` (pkemath.h): the slide is kept in weapon-local axes, fast ease (0.08 s) in the first second, slow (0.6 s) after, hold 0.5 s + fade 0.3 s. Used for the PKE (`pke_place_locked`) and the gun (wand hook; `g_gunRigidLast` also feeds the beam tip in `hk_attach_matrix`). Settings `pke_rigid`, `gun_rigid`. Evidence: RIGID report line, FLOATMARK (F2 or any marker).
- PKE scan: CPKEMeter update 0x141F60/0x141860, scan_ok 0x1456A0, ping 0x1460D0, rate 0x145F20, level 0x145E00; signal S +0x534, bar +0x680 clamp 0.10-0.90, cooldown +0x540 (2.0 s, 1.25 s upgraded), owner state [owner+0xD3E8] must be 0, input byte +0x538; target vcalls 0x278 blocked / 0x3E0 scanned / 0x3E8 add progress / 0x3F0 progress / 0x3F8 scannable. Rate levels 1.0/0.5/0.25/0.0 - the 0.0 level when the PKE is not centred makes the scan stall. Fix = `hk_pke_rate` floors the rate at 0.5 (`pkeeasy::ping_rate`) while `pke_scan_help` is on; `hk_pke_ping` logs progress before/after (PKEPING), why-census (PKEWHY, `pkeeasy::why_not`), owner state (PKEOWNER), target types (PKETYPE). Tests: `tests/test_pkeeasy.cpp`.
- Stale ring: lockable predicate = actor vtable +0x360(actor, player); candidates must pass it (`actor_lockable`, damage.cpp), `ring_hold_ds` 25 -> 15. Logs: RINGGONE. Hypothesis only.
- HUD right eye: HUD::Draw 0x253240 early-outs on byte [[0xDCF680]+0x3ada0]==0 or dword [[0xDCF680]+0x1e0]!=0. Cause of the missing right-eye HUD not proven. hud.cpp measures each eye's draw (empty = too few draw calls / too short), retries once, forces the early-out flags off for the retry, saves a picture (HUDEYE). Setting `hud_retry`.
- Monitor: `make_window` (monitormath.h) fills any aspect; the mismatch check in monitorview.cpp was relaxed (counters instead of switch-off); `tests/test_monitor.cpp` has the fill test over many window sizes/shapes/rolls. Migration sets `monitor_fit` 1.
- Wheel (gearmath.h `build_wheel(..., int* opaqueFrom)`, handmodel.cpp): vertices are in two groups - body (track, centre disc, disc fills) drawn with a constant-blend-factor state `g_bsWheel` (`wheel_alpha_pct`, default 60), then the solid group (red rims, red disc outlines, words, cursor, centre label) with `g_bs`. A locked slot shows "?" on its disc and in the centre ("LOCKED" under it); the name is hidden. If the blend state cannot be created the wheel is drawn solid (log line).
- Settings rev 101: `pke_rigid`, `gun_rigid`, `wheel_alpha_pct`, `hud_retry`, `pke_scan_help`, `ring_clear_gone`; migration: `pke_shift_pct` 50 -> 100, `pke_weight_pct` 55 -> 30, `ring_hold_ds` 25 -> 15, `monitor_fit` 0 -> 1.
- Weight (weightmath.h): fatigue sag softened.
- VR menu: new "Fixes" tab (16 tabs, 35 px high, font -26); default texts of the PKE shift / weight / ring-hold rows updated.
- Every marker (F2, both grips + both sticks, the menu's "Mark this moment") now also writes FLOATMARK.
- ctlmap: no mapping changed (conflict test unchanged and passing).

Not tested in the game. Open: whether the rigid slide really removes the floating, whether the PKE scan completes, the true cause of the right-eye HUD miss.

## 1.7

User report (1.6 logs, after 1.6): gun and PKE still float after the start; aim assist grabs tables and chairs; PKE scan should also be a press; sprint on the left stick click does nothing and the running animation is bad in VR; slam does not work (wants the left trigger, in the direction of the pull, with a buzz on touch); a subtle light on items on the ground; remove the dead "BEAM SWITCH" wheel slot.

Findings:
- Floating: the 1.6 FINGERS line shows the gun hand wanted 68 degrees of grip bend where the animation had 170 (`base * (0.4 + 0.6 * tg)` with tg = 0, because the controller grip is not used for the weapon). Fix = `ArmTargets::gunWrap` (setting `gun_wrap_pct`, default 100): the grip fingers keep the animation's grip. Menu tab "Fit" adds `gun_fwd_cm` / `gun_up_cm` (applied to the wand pose in the wand hook and to the muzzle in hk_attach_matrix) and exposes the existing `pke_fwd_cm` / `pke_up_cm`. Hypothesis, untested.
- Aim assist: the game's lock ring can sit on anything the capture beam can grab (CProp etc.). The enemy scan in `fight_publish` now publishes a census (position, bounds centre, radius of every living enemy, 64 max, seqlock `g_census`); `fight_enemy_near(world point, pad ft)` answers 1 / 0 / -1 (unknown, census older than 0.4 s: the old behaviour). Setting `aim_ghost_only`. Logs AIMGHOST.
- PKE scan: the input byte at record +0x538 is set when the player code sees the primary bit (0x40 in `player+0xC7A8`); with `pke_trigger_scan` the right trigger (pad bit 5) sets it (PKESCAN summary). Auto scan stays (`pke_auto`). 1158 "not scannable" answers came from class 0x791568 (CPKESource) targets: the game decides, not the probe.
- Sprint: tuning floats at RVA 0xDCCFF4: start delay 0.55 s, max duration 5.0 s, blocked-after 2.5 s, turn clamp 65 deg/s (checked in `tests/verify_layout.py`). `sprint_tune` (damage.cpp) writes, while `easy_sprint` is on, start delay <= 0.08 s, max duration >= 30 s, blocked time <= 0.2 s and (with `sprint_turn_free`) turn clamp >= 180 deg/s, after checking the four floats look sane; it restores the originals when the setting is off. The meaning of the third float ("blocked") is a guess from its name. Sprint request bit 0x8000000 in `player+0xC7A8` (`sprint_tune(mask)`). The latch (`sprint_latch`): a tap of the left stick click keeps L3 held until the next tap or until the stick is idle. Cause of the bad running animation NOT found; the speed and animation are the game's.
- Slam: in the 1.6 log the game's slam hit 4 times (type 0x73, strength 28.8) each right after a fire press (pad bit 5) with the capture bit (pad bit 6) held and the meter (`player+kOffSlamGauge`, threshold at RVA kRvaSlamThreshold) full; the 1.6 `slamStarts` / `firePresses` counters read 0 (they look at the wrong flag), so do not trust them. `TrigSlam` (gearmath.h): left trigger >= `slam_trig_pct` (90) + capture + meter full + a FRESH squeeze (or a meter that filled < 0.4 s after the squeeze began) -> fire pressed for 0.45 s, right stick flicked for 0.3 s toward the hand's travel over the last 0.5 s (`PullDir`, head space, needs 5 cm; no pull = no flick, the game slams down). Buzz: kSrcSlam on grab, on the slam, and a small one when the meter is not full. Tests in `tests/test_gear.cpp`.
- Wheel: `kSlots` 6 -> 5 (BEAM SWITCH was a D-pad press that did nothing). `tests/test_gear.cpp` updated for 5 slots.
- Ground items: no RTTI class in the exe is clearly a pickup (CProp, CInventoryItem, CPickList, CGhostTrap ... only). `item_glow_pct` is reserved and unused. New world census (damage.cpp `world_note`, `rtti_name` from vtable[-1] -> locator -> type descriptor): WORLDCLASS (first sight of every non-enemy class with its game name, count, nearest, number lying on the floor within 25 ft) and WORLD (every 8 s: the 10 nearest kinds). Next step: read these lines after the user stood next to an item.
- Settings rev 102: `gun_wrap_pct` 100, `gun_fwd_cm` 0, `gun_up_cm` 0, `aim_ghost_only` 1, `pke_trigger_scan` 1, `easy_sprint` 1, `sprint_latch` 1, `sprint_turn_free` 1, `slam_trigger` 1, `slam_trig_pct` 90, `slam_buzz_pct` 100, `item_glow_pct` 50 (unused), `slam_gesture` 0 (migration switches the old swing off).
- VR menu: new tabs "Moves" and "Fit" (18 tabs, 31 px high, font -23); Fight tab gets "Slam on left trigger" and "Old slam swing".
- ctlmap: texts for the left stick click and the left trigger updated; no new button; the conflict test passes.

Not tested in the game. Open: whether the wrapped fingers remove the floating, whether the ghost-only gate hides real ghosts at the edge (census age 0.4 s), whether the sprint tuning writes take effect (SPRINT lines), whether the trigger slam starts the slam (SLAMTRIG lines + the game's HIT SLAM), what the ground items are (WORLD lines).

## 1.7.1

User request (00:30): triple-check the hand / gun / PKE floating and make sure it is fixed.

Evidence gathered from the 1.6 report (pictures + log), nothing could be run in the game:
- Pictures (14): the gun hand is open with the weapon a few cm in front of it, at the start and later; in the one burst with the controller grip squeezed the fist closes around the handle.
- Log: gun-hand mode in 81067 of 81077 grip passes; the wrist fell short of the controller by more than 0.1 ft in 56 calls (max 0.23 ft); steady slide gun 10.1 cm, PKE 12.5 cm (strayed 1.6 cm mean, 16 cm max); the FINGERS line showed the right middle finger asked at 68 degrees where the animation had 170 (40 %).
- Code review: hand position = controller point, weapon = controller point + R * (P0 - H) (rigid by construction), hand axes = R * game hand axes; so the position math is consistent; the visible cause is the open fingers (fixed in 1.7, `gun_wrap_pct`).
- Unproven residual risks: the hand's rotation relative to the weapon follows the game's animation while the weapon slide is steady (slow follow); the left hand had its fingers wanted at 0 on the foregrip.

Changes:
- `armcore.h` curl_hand non-gun branch: the left hand on the foregrip (`st.lMagWNow` > 0.3, set from the foregrip magnet weight in `apply`) raises the wanted curl of index..pinkie to `gunWrap * 0.85 * weight`. Stats `lMagWNow`, `lWrapPasses`, `gunFingerPasses`.
- `arms.cpp` `arms_finger_text()` + LEFTGRIP line (wrapped passes). `engine_hooks.cpp` `float_hands_line()`: FLOATHANDS line on every marker (F2 etc.) and about every 15 s (every 10th wand report): finger animation -> drawn bend of both hands, controller grip / trigger, gun_wrap_pct, fit offsets.
- `tests/test_fingers.cpp` block 5c (real `curl_hand`): foregrip wrap 129 degrees (2 x 0.40 x 0.85 x 190), open with setting 0 / no magnet / far, closed with grip squeezed.
- VR menu text of "Fingers on the gun" mentions the left hand. No new settings (rev stays 102), no mapping change.

Not tested in the game. Open: whether the open fingers were the whole story; the F2 FLOATHANDS + FLOATMARK lines of a floating moment will show.

## 1.7.2

User report (03:01, `gbvr_report_20261019-025843.zip`): the body work turns bad after about 2 seconds (gun and PKE off the hand), the PKE still scans by itself, slam does not work, the blaster targets furniture, an "artifact" does not show up.

Evidence from the 1.7.1 report (nothing can be run in the game):
- The enemy scan was capped at 700 actors (`fight_publish`) and 900 (`pke_sources_scan`); the BARS/ACTORLIST counters show the list is longer, so real ghosts were never seen: ghost-only census, ring and aim assist had `targetSet=0`. Cap now `kMaxActors = 20000`, with `walked`/`capHit` counters (`ACTORLIST`, `BARS`).
- `hurt_common` returned early when the beam boost was off (`pct <= 100`), silencing hit logs and the touch buzz. Now only the boost itself depends on `pct`.
- Slam: capture (pad bit 6) was held only by the player's own trigger squeeze; a quick squeeze ended it before the fire press. `TrigSlam` v2 (`gearmath.h`): capture is forced for 0.7 s (`kCapHold`), fire press at 0.10 s, stick flick 0.30 s from `PullDir::best` (strongest recent pull chord, newer weighted up to 2x), blocked with no held ghost (`fight_wrangled()`: `player+0x24D80`, only used once seen non-null), `ping` buzz when the meter becomes full while a ghost is held. `SLAMRESULT` / `WRANGLE` / `SLAMTRIG` log lines follow every slam at 0.25/0.5/1/2/3.2 s.
- Furniture lock: `fight_lock_guard()` clears `player+0xB550` (stream end) and `player+0x2E8` (ring focus) when the target's vtable is not one of `kEnemies`; `LOCKGUARD` log; setting `lock_ghost_only` (default 1, menu Moves > "Beam ignores furniture").
- Auto scan: `pke_auto` forced to 0 by the rev-103 migration and the default; the right trigger scans (`pke_trigger_scan`).
- Collectibles: `trinket_note()` (CTrinket vtable RVA 0x7A4408) logs `TRINKET` lines within 60 ft (distance, height, frames since last drawn) and a `TRINKETSUM` line. Why the user's "artifact" does not show is unknown; asked which one it is.
- Floating: the 1.7.1 PKE picture shows a closed fist with the handle about 5 cm beyond it, so fingers were not the whole story. The steady hand slide (gun 10.1 cm, PKE 12.6 cm, strayed 0.0 cm in the RIGID lines, so no jumps) is applied correctly by the math but the weapon still looks forward. Practical change: default Fit `gun_fwd_cm = -3`, `pke_fwd_cm = -9` (rev-103 migration sets them only when they are still 0). The root cause and the "good for 2 seconds" part are NOT found.
- New measuring line `HOLDCHECK` (`holdcheck_line` / `holdcheck_timeline` / `holdcheck_now` in `engine_hooks.cpp`, `arms_hold_numbers` in `arms.cpp`): weapon origin to the drawn wrist and to the controller point (along the aim and across), the game's hand-to-weapon offset, slide in use, wrist miss, fit. Logged at 0.3/1/2/3/5/8/12 s after the weapon comes into the hand, on every marker (`engine_float_mark`) and about every 15 s.

Settings rev 103: `lock_ghost_only`; `pke_auto` 0; gun/PKE fit defaults. ctlmap text for the left trigger updated (no new button; conflict test passes). Version 1.7.2.

Tests: all 43 `tests/test_*.cpp` pass (including the new slam scenarios in `test_gear.cpp` and `test_ctlmap`). `tests/verify_layout.py` needs the game's `ghost.exe` and was not run here. Not tested in the game. Open: ground-item light, sprint animation, why the weapon looks right at first and off after about 2 s (the HOLDCHECK timeline will show it).

## 1.7.3

User report (11:14): "The collectibles in game don't show up" (follow-up to "some artifact won't show up").

Findings (static analysis of ghost.exe, nothing run):
- Game text: "The Paragoggles are tied to PKE Meter use and allow you to view otherwise invisible objects", "Blue signals on the PKE Meter indicate a cursed artifact is located nearby", "Cursed Artifact [collectable]" is a CPKESource type. Actors have a "visible in UV light only" flag (`actor+0x4C` bit 0x20000000, `CActor::setVisibleInUVLightOnly`, render-command resubmission at RVA 0x153E0).
- CTrinket (vtable RVA 0x7A4408, size 0x548): model at +0x538, a glow effect object at +0x540 (started/stopped by vtable slot 10, RVA 0x178CC0; the effect is created in the load function at RVA 0x178D10), trophy id at +0x4FC. `hasBeenPickedUp` (RVA 0x179510) = `world(0xDCF680)+0x4F560` table, float at `+16*(id+1)` (ids 0..0x7B) non-zero. The getter at RVA 0x282710 is a plain read.
- The 1.7.1 log's WORLD lines list `CTrinket x2` (nearest 9.1 ft, +2.5 up) and `CPKESource x2` (nearest 65-79 ft, +12.8 up). Cause of the invisibility in the headset: NOT found.

Changes:
- `fightmath.h`: `Marker`, `diamond`, `number`, `marker_width`, `build_markers` (eye space like the bars: gold diamond + light beam for kind 0, cyan diamond for kind 1, dark outline, white core, slow pulse, distance in feet for the one nearest the view centre; nothing nearer than 1 m or behind).
- `damage.cpp`: in the world walk of `fight_publish`, `mark_consider` takes CTrinket (not picked up per the game's table; within 120 ft) and, with the PKE out, CPKESource (within 70 ft); nearest 12 are published (`g_msnap`, `fight_markers_read`, fresh for 0.4 s). Log lines `MARKER` (per new collectible), `MARKERS` (damage_report).
- `handmodel.cpp`: draws the markers after the health bars (same buffer/state, no depth test); `MARKDRAW` counters in the report.
- Settings `collect_marker` (default 1), `collect_marker_pct` (40..300, default 100); VR menu Fixes page (now 8 lines).
- Tests: `test_fight.cpp` marker geometry (behind/too close not drawn, colours, size bounds, buffer overflow, finite for any phase). All 43 native tests pass. Not tested in the game.

## 1.7.4
- Sprint: the 1.7.1 log (336 L3 clicks, 0 sprints) shows eControlSprint/L3 never starts a sprint. The game sprints while Jump/Evade (XInput B, pad::kB) is held. controllers.cpp now ORs kB into the pad while the left stick click is down (or the kept-on sprint is active), the stick is past 0.30, and no menu/wheel/layer is open. Setting `sprint_via_jump` (default 1). Log: SPRINTPAD (jump frames). Untested.
- Scan reveal: damage.cpp `mark_consider` in scan mode (`collect_marker_always` = 0) needs the PKE out; the angle between the PKE aim (`engine_pke_aim`, from `wand_aim_read`) and the vector to the target must stay inside a 32 deg cone (50 deg under 10 ft), distance <= 40 ft, dwell >= 0.6 s, then the target is revealed for 12 s with a haptic tick (`REVEAL` log). A proximity ping runs on the right hand: period 0.28 + pingMin/60*1.1 s, level 0.12+0.30*(1-pingMin/60), 28 ms, when the nearest target is under 60 ft. Constants are first guesses.
- ctlmap.h: left stick click text updated (no new button, so no new conflicts; test_ctlmap passes).

## 1.7.5
- Sprint toggle: `sprint_toggle` (default 1). In the sprint block of controllers.cpp every new left-stick click flips g_sp.latched (any press length), the click is removed from the pad (no hold), the latch ends after 1.2 s with the stick under 0.30, and the Jump/Evade hold from 1.7.4 is unchanged. 0 = the old tap/hold behaviour. Log: SPRINTPAD toggle.
- Body follows head (followmath.h): smoothstep push curve, ramp (up 3.5/s, down 7/s, starts at minStick 0.38), the first-turn cap (0.55) is applied before the ramp. With `turn_follow_walk` (default 1) the start/stop angles blend from 35/7 deg to 19/5 deg as the left stick goes from 0.25 to 0.75 (controllers_move_mag). Log: TURNFOLLOW start (stick + walking limit), TURNWALK. Tests: test_follow sections 14-15. All first guesses, untested in the game.

## 1.7.6
- Report 1.7.5 (21:46): level start in the Sedgewick Hotel lobby (no-fire zone: HITS 0, FIREQUIET, PKE without target). The turn follow deadlocked: 47 snaps, 0 deg of real turning, the picture offset A up to 180 deg from the body, so movement and aim looked reversed and shots went crooked. The game's look dead zone: a push of 0.55 barely turns it (1.6 and 1.7.1 logs), about 0.7 gives about 25 deg/s.
- followmath.h: minStick 0.58, calibCap 0.85, learnedMin raised by 0.1 every 0.5 s of <0.5 deg movement while active, probe boost (probeSec 0.4, probeRad 0.4 deg) -> boost 1.0 after a miss, noAnswerStreak; gave_up() after 2 misses in a row. engine_hooks.cpp follow_pre: a miss realigns A to 0 (picture turned back), snaps dropped while resting (cool) or after 2 misses; controllers.cpp passes the real right stick through while the follow gave up. Logs: TURNFOLLOW no answer, TURNMISS, TURNWALK.
- Sprint: the game never started its own sprint (1.7.1 L3 3826 polls, 1.7.5 Jump 194 polls: 0 starts). New `sprint_force` (default 1): controllers.cpp sets g_sprintWantQ while sprint is on (toggle/latched), the left stick > 0.30 and no trigger squeezed (rt/lt < 40); damage.cpp sprint_force() ORs 0x8000000 into player+0xC7A8 once per fight_publish. The bit selects the run animation in 0xD67A0. `sprint_via_jump` default 0 (migration rev 104). Logs SPRINTGATE (timers 247B4/247B8/247BC, 2E8, 24E78, C7F0, 88C0, 24AC1, six animation checks), SPRINTFORCE (counts; "run timer ran in N frames" = the game really sprinted), SPRINTWANT.
- Possible measuring flaw found: the action mask is zeroed at the end of the player update, so the old "sprint bit set" counter (SPRINT line) can read 0 even when the game ran. The timers in SPRINTFORCE do not have that problem.
- `walk_cap_pct` (default 100 = off, 40..100): with sprint off the left stick vector is scaled down to this share (controllers.cpp, after the sprint block). RUNSPEED log (engine_hooks.cpp) = average ft/s per left-stick bucket, with and without the run asked, to find where the game switches from walk to run.
- Menu: new Walk tab (sprint toggle, probe starts the run, walk pace limit, hold Jump, go where I look); Fit lost the two sprint items. settings rev 104.
- Not done: glove/gun look (black glove on black gun, forearm barely visible; no code change), the "pink green effect" the user mentions (unknown which; the log has no firing), gun/PKE drift, light on ground items.

## 1.7.7
- User (22:17): the gun/PKE draws in front of the hand (the hand does not cover what it holds), wrist placement in the rig, the menu opens when the hand is not by the head.
- Wrist: with grip_at_hand the right wrist was set exactly on the controller point (T = grip) and the weapon slid by -rd0 (the game's wrist-minus-weapon offset). The controller point is the middle of the real palm, so the whole virtual hand sat a hand length too far forward. New `gun_wrist_cm` (default 7, Fit tab): armcore.h gripAtHand branch T = grip - (rdir*back + rup*down), gripShift = -rd0 - wb (the weapon keeps the game's hand-to-weapon relation; the muzzle/stream take the same shift via arms_grip_shift). An empty hand (gripFar) gets the same set-back. The left hand's foregrip target is measured from the gun's placed origin (ArmTargets.gunPos from g_gunPlaced) instead of the controller point. Test: test_armcore "wrist back".
- PKE: pke_fwd_cm -9 -> -15 (migration rev 105): the 1.7.5 picture showed the handle ending at the top of the fist.
- Menu gesture: vmenumath.h ear_zone() (within 24 cm of the headset centre, right <= 8 cm, forward <= 12 cm, up -20..+18 cm, in the headset's own axes) + not on the gun (hl.away) + the hand moves < 10 cm during the 0.6 s wait; `menu_strict` (default 1; 0 = the old 30 cm ball, 0.5 s). The pad is cleared only inside the zone. ctlmap.h kNearHead updated (resolved: two-hand hold wins).
- Logs: WRISTFIT (per weapon: the game's hand-minus-weapon offset in the controller's aim/up/right axes, the fist centre minus the weapon origin in the same axes, the hand's across axis dot aim), MENUGESTURE (opens with the hand's offset from the head; the old rule's would-be opens).
- Not done: gun forward/up default (no new evidence), PKE scan colours (pink/green), gun/PKE drift after 2 s.

## 1.7.8
- User (23:04-23:08, report 1.7.7): "you broke the game", "sprint feels awful and only goes in one direction - I just need the player to go faster, not play the animation", "right stick did not work", "game did not progress at the point I was supposed to go to".
- Facts from the 1.7.5 / 1.7.7 logs: the game's camera heading (cam + kCamEuler + 4) stayed at -2.5464 rad for the whole play, also with a full right-stick push (in 1.7.1, another place, it turned fine). The game walks relative to that heading, so walking went the wrong way and snap turns turned only the picture. Forced game sprint (bit 0x8000000 at player+0xC7A8) really started the run timer but gave 6.7 ft/s against 7.5 ft/s at a full stick and locks the walk forward with the run animation.
- Walk: `follow::rotate_stick` turns the left stick by e (the head's yaw from the game's heading) so the game walks along the head whatever its camera does (`walk_head`, default 1). The 1.7.6 "give up and take the picture turn back" logic is gone: snaps always turn the picture, follow keeps working (miss logging only).
- Sprint: the game's sprint is never started (no run bit, left-stick click is removed from the pad). `sprint_speed_pct` (default 170, 100..300) boosts the player's speed while sprint is on and the left stick > 0.30: hook on the character update 0x84390 (bytes in layout.h, verified), filtered by the player actor. Three ways in boostmath.h (velocity / time / nudge), the speed that is really got is measured at a full stick and `auto` (`sprint_speed_method` 0) goes velocity -> time -> nudge when one does not reach 1+0.55(K-1). Nothing could be run, so which way works is unknown: SPEEDBOOST / SPEEDWAYS / SPEEDBODY lines tell.
- Settings rev 106: sprint_force and easy sprint switched off for old files. VR menu Walk page rewritten.
- New diagnostics: GAMECAM (is the game's heading moving; 6-second watchdog line), PROGRESS (player place, walked feet, jumps), WALKHEAD (stick turned by the head), SPEEDBOOST/SPEEDWAYS/SPEEDBODY.
- Also: Snap::clear zeroes the pack/hose matrices (test_rig failed at random on stale numbers); verify_layout checks kBytesCharUpdate.
- Not known: why the game's camera stays frozen at the hotel start and why the story did not go on. Not done: gun/PKE drift, scan colours (pink/green).


## 1.7.9

Report: gbvr_report_20261019-233740.zip + video (23:41). Complaints: PKE green not on / nothing visible in PKE mode; the game ended and the story did not progress; monitor FOV too small; "fix all issues in the video".

### What the 1.7.8 log proved
- `SPEEDBOOST ... player ticks 0`: the hook on 0x84390 (`hk_char_update`) never saw the player in 16000 frames. The boost did nothing. (0x84390 may be an NPC update, or the player is not `head_aim_actor()`; 1.7.9 counts every caller and its vtable: line `SPEEDCHAR`.)
- `GAMECAM`: the game's camera heading is frozen at -2.5464 for the whole run, as in 1.7.5 / 1.7.7.
- `EXIT game called ExitProcess` right after NOPAUSEMENU Start tap #3 and a flat-screen flash. Before that: `AUTOPAUSE skipped ... leaveEvents`, `CONTROLLERS tracked: left=0 right=0` (focus loss / tracking lost -> the game paused by itself).

### Goggles (reverse engineering, all by reading ghost.exe)
- `isGogglesActive(player)` = 0xD6580: item 5 state == 2 (`[player+0xCFE0+5*0x18]`), `[player+0xB568] != 0` (button held), `0x78DA0(player) == 0` ([player+0xB640] object query), `!0x7D1F0(player)`, `!([player+0x4C] >> 7 & 1)`.
- Five callers: 0xCAB39 and 0xD7ABE (-> `HUD::setGoggles(hud=[player+0xB550], on)` 0x1FEFB0 -> fader at hud+0x448: state 0 off / 1 in / 2 on / 3 out, timer +4, progress +0x14 = hud+0x45C; `setGoggles(true)` is a no-op in state 1/2), 0x141133 (the render command's view flag: UV-only objects are drawn when it is set, command 0x16FD0 tests `[view+0x64] & 3`), 0xD1DE3 and 0xD58F1 (smooth `[player+0x247C4]`, which also moves the PKE meter; left to the game).
- The "mirror only" check 0xD35D0 (body hidden in the goggle view) uses item 5 state, `[player+0xB568]` and `[player+0x247C4] >= 1`, NOT isGogglesActive. So forcing isGogglesActive at three sites does not hide the PKE meter as long as `[player+0xB568]` stays 0.
- Global byte 0x23224D2 (BSS, 14 readers, no writer in code and no absolute pointer to it): a developer "show everything" switch. HUD::Draw (0x1FE503) forces the tint amount to 1.0 when it is set. Level 2 of `pke_goggles` sets it while the PKE is in the hand (restored afterwards).
- Implementation: `hk_is_goggles` (engine_hooks.cpp) wraps 0xD6580; at the three sites it answers yes when the PKE is in the hand, the game said no, player flag bit 7 is clear and no forced move runs. `goggles_after_sim` logs the HUD fader per tick, and is the fallback (direct `setGoggles(true)`) if the HUD sites are never asked.
- Log: `GOGGLES`, `GOGGLEWHY` (which of the game's conditions failed with the PKE in the hand), `GOGGLEHUD`.

### Sprint (main loop)
- `boost_after_sim(app)` runs after every real simulation (mainLoop, after `o_appSimulate`). It measures the actor's net motion (pre-nudge to pre-nudge), judges the way (boostmath.h: nudge first, velocity / time only when the character-update hook has seen the player 30 times), and for the nudge adds `(k-1) * plain step` to the actor position, to the copies of the old position found by value in the body (0x300 bytes) and the actor (0x200 bytes), and to the fixed body fields. `plain_step` = measured motion minus last nudge, capped at a full-stick step: no feedback runaway. `adapt` trims the strength every 0.6 s of settled walking so the measured gain stays at the asked one.
- Log: `SPEEDBOOST`, `SPEEDWAYS`, `SPEEDCHAR`, `SPEEDTIME` (game step against wall clock), `SPEEDBODY`, `BODYSTAND`/`BODYWALK` (80 floats of the body standing / walking), `NUDGEFIELDS`.

### Monitor
- Picture tangent was 1.428 (110 deg); with `monitor_wide_pct` 125 the engine is asked for 1.785 (121 deg) while `monitor_view` is on (`a.needH/needV` x widen). The headset's texture window shrinks with the real tangents (texture_bounds), pixel density stays above the panel's. `monitor_zoom_pct` default 72 -> 100 (settings rev 107).

### Exit
- `EXITCALLER` (14 frames of the stack at ExitProcess, `ghost+x` = RVA) and `EXITSTATE`. NOPAUSEMENU taps are 2.5 s apart (was 0.9).

## 1.7.10
User (1.7.9 report + video): gun/PKE floating, stream shot left of the gun, ghosts take long to kill, items/UI must not get lost.
- Evidence: video frames (stream leaves the muzzle ~90 deg sideways while the barrel points forward, same side in many rooms); 1.7.8 log: BEAMSTRAIGHT mean bend 75 deg, DMG calls=0, HITS 0, LOCKGUARD lock none 5418/5419, GUNHAND wrist short up to 0.70 ft in 888 passes, REACH right <220% 888 (controller 1.7-2.2 arm lengths from the shoulder), SLIDE limit 12 cm.
- Disassembly of the stream update 0xE6360 (no lock-on target): hit = (view object at actor+0x24FD8, virtual +0x168) when 0xDBD10(actor), else muzzle + aim getter (0x76E80) * [0xDD2DD0]; with byte actor+0xC7E0 set it is the tip matrix forward (row 2). The bend angles (0x31FFC0, zeroed since 0.69) only shape the end; the hit point was untouched.
- Change: hk_aim_getter (0x76E80, only the return 0xE677D of the stream update, player thread) and hk_view_hit (virtual found at run time from the player's view object, only the return 0xE6755) put the hit on muzzle + barrel aim * the game's distance. Setting stream_aim_gun (rev 108). Log STREAMAIM. verify_layout.py: 3 new checks.
- beam_damage_pct 115 -> 135 (rev 108 migration), shoulder_slide_cm 12 -> 30.
- Not tested in the game. Open: whether the stream now follows the barrel (STREAMAIM, BEAMSTRAIGHT bend, DMG calls), whether the hook on the view object's virtual installed (HOOK view-hit-point status).

## 1.7.11
- arm_stretch_pct default 170 -> 220 (rev 109 migration): the 1.7.9 log had the controller 170-220 % of an arm length from the shoulder in 888 passes, the arm stopped at 170 %, wrist short up to 21 cm. Not tested in the game.

## 1.7.12
- Objectives: the game's Objectives live in its pause menu, which NOPAUSEMENU (engine_hooks.cpp) closes by Start taps. New VR-menu action A_OBJECTIVES (Help page) -> `game_menu_request()`: taps Start once if the game runs, sets `g_userMenuUntil` = now + 180 s; the NOPAUSEMENU block does not tap while that latch is active. Log: GAMEMENU. Untested.
- PKE: 1.7.8 log shows the chain works (PKEPING #1 FINISHED on source 0x...5360 at 15 ft; then "already scanned" + 2 s cooldown). Added haptic cue per fresh trigger squeeze (nothing locked: 0.50/120 ms, already scanned: 0.22/50 ms), log PKECUE; pke_easy_ft 35 -> 50 (migration rev 110). pke_auto stays 0 (1.7.2 decision).

## 1.7.13
From the 1.7.12 report (log gbvr_probe_1.7.12_20261020-184043, 10 pictures). User: take back all gun/PKE placement, let the game choose; slam broken, body weird, fingers weird; slim the menu; better height measure.
- Log facts: floating fixed (GUNHAND wrist miss max 0.02 ft; REACH nearly all <100 %); STREAMAIM view hook installed (put on barrel 6396); 1176 CFloater beam hits (damage reaches them). Slam: 3 starts, 1 game slam hit (strength 33.8, ghost at the 25 % floor: no damage); SHOTFACE shows the avatar facing swinging ~60-90 deg during a slam = the aim-stick flick turning the body.
- New setting `game_place` (default 1, rev 111). Gates when 1: hk_attach_matrix returns the game's tip (but records tip + row 2 as the stream reference so hk_aim_getter / hk_view_hit put the hit point on the game's barrel; stats GAMEPLACE); wand hook (hk_mat_mul wand branch) passes through (gateOffLast=16); arm_drive: no right target (gr=6), no left target, no fingers, no PKE arm target / attach / hide; pke_place_locked disabled. Aim store replacement (hk_aim_set), aim assist and body_push stay.
- slam_flick_pct default 60 -> 0 (migration). Menu cut to Start / Play / View / Sound / Help; kTabH 64.
- Height: Calib uses the 75th percentile, rejects spread >= 20 cm; size_pct_for clamp 85-120; body_scale clamp 0.85-1.2 (tests updated).
- Unknown until the next log: whether the game's own gun animation follows the aim we give it (GAMEPLACE mean/max deg tells).

## 1.7.14
- PKE proximity buzz (damage.cpp, per census frame): nearest of (unscanned PKE source from pke_sources_scan, using the new engine_pke_source_scanned() = vcall kVtTargetScanned/Scannable on the source actor) and pingMin (collectibles in scan mode); hapticmath.h prox_level/period/ms; setting pke_prox_buzz (rev 112); logs PKEPROX (periodic + first pulses). Replaces the old weak 0.12-0.42 ping.
- Measure: vrmenu.cpp measures itself in vrmenu_tick (1.5 s, upper-quarter head height from vr_capi_hmd_pose, standing universe), reasons g_mFail 1 not tracked / 2 not standing height / 3 moved >= 20 cm, then body_calibrate_apply (clamps 85-120). controllers.cpp's Ctrl+F9 path unchanged. No CALIBRATE line exists in any earlier log: the menu path had never been seen working.
- Code fixes: gbvr.h now defines ARMCORE_CRUMB before including armcore.h (arms.cpp's define came after gbvr.h had included it, so the armcore crumbs were no-ops); PKEPING "sideways offset S" printed 1e30 (never-set) -> -1.

## 1.7.15
- Ring: the 1.7.12 log shows the game's ring object keeps its last focus position and projected screen spot (RING # lines: 355,3 with ghost -12.5,51.5,-64.5 for 14,000 frames; 640,360 with ghost 0,0,0 early) and hk_ring_draw drew it every time (28,643). hk_ring_draw now draws only when ring_draw_allowed(): PKE item out (the game's rules), a fresh fight_ring_pick (<= 250 ms), or a native focus seen in the last 0.2 s (g_ringNativeQ set in hk_focus_pos when the game's own getter said yes); else skipped (counted in g_hs.ringHidden and g_rd, log RINGDRAW). Defaults ring_cone_deg 28 -> 35, ring_hold_ds 15 -> 4 (rev 113).
- Disassembly of the ring update (0x24D450): it asks focus health (0xDE1E0) every frame and compares with -1 (none); +0x1BC is a 2 s linger timer; so a lingering ring after the target is gone is the game's own behaviour, now suppressed at draw time.

## 1.7.16
- User (1.7.14 report): "no motion control or anything". GAMEPLACE in the 1.7.14 log: game barrel vs controller mean 79.5 deg, max 178, 3296 tip matrices taken from the game, WAND applied=0. Cause: game_place default 1 (1.7.13) gates wand/tip/arm/finger/PKE placement.
- Fix: migration rev 114 forces game_place = 0, proxy default 0, menu toggle removed (Start page 7 items). The setting key stays in the file for diagnostics only.
- Not fixed (no evidence): PKE box overlapping the gun in the 1.7.12 pictures with the PKE out (PKEMODE on=0, PKEGAME placed=599 earlier in that run).

## 1.7.17
From the 1.7.16 report (log gbvr_probe_1.7.16_20261021-020056). User: spin worse when capturing, fingers broken, body stiff, height measure sinks the view into the stomach, "115 % damage", ring never shows -> bars.
- Height: Calib gave size 85 %: camera -0.83 ft + torso scale 0.853 but arm bones/hands unscaled; GUNHAND wrist shortfall max 1.74/3.43 ft (8.4/7.5 at the reset jump), 0.00 at 100 %. body_calibrate_apply now sets worldPct = body::world_pct_for(eyeM, eyeHeightFt) (90..125), sizePct = 100. Menu: Player height row -> World size; Reset -> world 115, size 100. Migration rev 115 forces size 100.
- Spin: GAMECAM heading moved in 214 frames, 4.6 rad in 540 frames (frames 17445-17985) while TURNFOLLOW activeFrames did not grow = the game's own turn during capture. follow_pre adds such smooth deltas (<= 20 deg/frame, not a cut, no menu/forced/own-stick) to the picture offset while LB/RT/LT is held + 1.5 s (setting hold_view, log HOLDVIEW).
- Bars: hbar 0 / ring_mode 0 since the 1.5 migration; RINGDRAW allowed 1382 of 19965. Migration 115: hbar 1, ring_mode 1, hbar_gate 0.
- Fingers: held-grip want was 0 for open hand (ruler-straight). Now rest curl finger_rest_pct (25): fingers want = rest, thumb 0.22, index max(trigger, 0.8 rest).
- Damage: no 115 found (DMG beam_damage=135, calls 2073 boosted 2073). beam_damage_pct 150 default, menu row.
- Not found / unchanged: "stiff body" - no evidence in the log (BODYFOLLOW torso follows head, dead zone 20 deg, lag 250 ms); not changed.

## 1.7.18
User (after 1.7.17): "check the rig under different events ... change it to 115 damage ... make sure pke works, does not auto-scan, and scans things accurately ... check the flat-to-VR skill".
- Damage: `beam_damage_pct` default 115 (proxy.cpp), menu row step 5 ("115 = default"), settings migration rev 116 placed LAST in the chain (after every older step, otherwise the rev<108 step "115 -> 135" would undo it) forces 115 for everybody. World size (`world_percent`, also 115 by default) is a different setting.
- PKE auto-scan: the game's player code 0xD8F60 writes `meter+0x538 = 0` first and sets 1 only while the primary request bit (player+0xC7A8 & 0x40) is down and the PKE is held, so the game cannot scan alone. The only auto path was ours (`pkeasy::want_input` with `pke_auto`). `pke_easy_cfg()` now always has `autoScan = 0`; settings load forces `pke_auto = 0` (log `SETTINGS pke_auto 1 -> 0`); the table entry stays so old files parse. PKESCAN/PKEEASY still print `auto_scan` / "set by the probe (auto)" (must be 0).
- PKE accuracy: target choice is the game's (enumeration 0x142120 keeps the record with the highest strength = best alignment; vis/alignment/strength come from 0x1401430B0, ray from the closest point on the PKE line to the target, origin = the meter bone or the aim getter 0x76E80 / the player's HUD object when set). Defaults: `pke_cone_deg` 40 -> 30, `pke_assist_deg` 24 -> 18 (only when still at the old default), `pke_easy_ft` 50 unchanged. New log `PKEACC ping #n` before each PKEPING line: ground distance and angle off the meter's line from the game's own record at the moment of the ping, clear-line flag, cone/reach in force, autoInput count.
- Old-log facts (1.7.1): 8225 locked updates, 7080 "no clear line" (class 7a4408, 10-45 deg off); 1 scan finished (class 7a4408 at 8.3 ft, 31 deg off); `hk_pke_rate` is never called (rate asked 0 times), so the scan-help floor is dead code; the PKE was never used in the 1.7.14 and 1.7.16 runs (Y taps 0-1). Unknown: why the game's line is blocked so often (needs a PKEACC/PKEWHY run).
- Rig: 1.7.16 log GUNHAND right 493 / 16966 passes over 0.1 ft (97 % within 3 cm), clusters at log lines 6693-7114 (menu open at 6394), 11598-12074 (after CALIBRATE size 85 % at 9960; FLOATCHECK neck -319 cm below the eye while size 90-95 % was being stepped back to 100). REACH: right > 220 % of arm length in 503 of 16966 passes. New `RIGEVENT` line (engine_hooks.cpp `rig_event_sample` after `arms_apply`, buckets normal / menu / PKE / trigger-held / forced) so the next log splits the misses by situation. No rig behaviour changed.
- Skill (VR Mod Vibecoding Wizard): project already follows it (SMOKE line, MARK, bug logs, "untested" until proven). Gaps it lists: left-handed play, seated mode, user profiles, other controller families (Index, Vive, Steam Frame), button-prompt text substitution, desktop simulator. Not started in 1.7.18.

## 1.7.19
User (after 1.7.18, report 030651): "Left hand fingers are broken, and capture stream catches more objects than the ghost; health bar is too big and needs to be more transparent, and can see it before the ghost spawns and when a ghost is behind a wall; when left hand grabs gun make it go under the gun and feel/look good; throwing trap more free, not locked to a path".
- Fingers (engine_hooks arm_drive `want[5]`): 1.7.18 picture 030336 = fist + one straight index (index followed the trigger only). Grip held: {0.60, max(trig,0.52) capped 0.92, 0.88, 0.90, 0.92}; on the gun {0.55, 0.82+, 0.90, 0.92, 0.92}; open: soft gradient rest*{0.85,1.05,1.30,1.55}.
- Left hand under the barrel: new ArmTargets.underW/underFt (eased in engine_hooks, tau 0.10 s in / 0.16 s out; active when right hand has the gun, left grip held, no trap/PKE). armcore: target = gunPos + rdir*along(clamped 25..95 % of gunLenFt) - rup*underFt, along = projection of the controller (slides); hand further than 1.2 ft from that point is left alone. Old foregrip magnet (left_grip_pct) still there, 0. Stats lUnderN/Along/Move/Clamped/Far, log LEFTUNDER. Settings left_under (1), left_under_cm (6).
- Bars: 1.7.18 log: actor_lockable (virtual +0x360) said no 53236 of 73912 asks, bars shown 32468 (hbarGate was 0 since 0.91 because the old drawn-recently test failed 978/981). Now bar_active() = hit recently || held by stream || actor_lockable; wall test = game LOS fn 0x7BCE0 from 3 points (centre, near side, upper body) + 0.3 s grace per actor. hbar_gate default 1 (migration rev 117 last), hbar_size_pct 60, hbar_alpha_pct 45 (constant blend factor via g_bsWheel). Logs BARVIS, HBARALPHA. Menu View page now 8 rows.
- Capture: player+0xB550 is an owned object (released with vcall +8 in the player destructor) - the guard only ever cleared it once (CGameView). player+0x24D80 holds CProtonBeam, not the target. The 1.7.18 run had 0 stream hits and 0 slams, so no evidence of props being caught. Guard now also runs in hk_view_hit; 0x24D80 is audited only (LOCKGUARD capture-held counts).
- Trap: gear::Trap keeps 24 velocity samples; the throw direction = speed-weighted swing over 0.16 s (swingDirDeg logged), speed = max(release, swing mean); min speed 1.1 m/s, armed after 16 cm (was 22). 1.7.18 log: trap flew 5 ft at 0.6 s, 11 ft at 0.8 s (state 3 deploying): the arc is the game's. Not done: taking over the trap actor in flight (game rewrites its position; risky blind).
- Tests: test_gear (swing, lob), test_armcore (under the barrel, clamp, far, off).


## 1.7.20
- Health bar: `fight::colour_for` is a 5-stop smoothstep ramp; `ease_shown` glides the drawn fraction (k = dt/(0.20+dt)). Log BARCOLOUR.
- Weapons: `is_beam` covers ammo 0x09, 0x0C-0x12, 0x13-0x16. `hk_wrangle` (0xDEDA0 processWrangling) guard; LOCKGUARD audits player+0x24D80. Per-weapon accumulators log WEAPON/WEAPONS. Only the proton stream aim is barrel-corrected (other 17 aim-getter callers are not).
- Left-handed: swap at the OpenVR choke point (`g_swapHands`, `vr_capi_set_handed`); haptics swapped too.
- Seated: `g_refPos[1] = g_refBaseY - seatCm`; recenter 4 s after toggle; `crouchOn` off when seated.
- Controller families: `classify_family` by OpenVR string properties (Index axis 3, WMR axis 2, else 0); click bit remapped to 32+axis. Untested on hardware.
- Profiles: `settings_profile_switch` writes gbvr_profile_N.txt (all keys except machine keys) and loads the other; buffers 6144 -> 16384. Menu Comfort page. Log PROFILE.
- kSettingsRev unchanged (117); new keys default off (profile_slot 1).
- Not done: prompt-glyph substitution, comfort vignette, teleport, simulator.


## 1.7.21
From the 1.7.20 report. Body: `torso_pass` step 2b bends spine1's subtree forward about the head's right axis by bendFrac*(pitchDown-10deg), capped at bendMaxDeg (test_fullbody: 32.5 deg at 60 deg look-down, 65 %, cap 55). Damage: `damage_install` returns early when beam_damage_pct <= 100 and damage_watch = 0 (nothing patched); settings rev 118 sets 100 / alpha 100 / aim assist 0. Aim: `hk_aim_getter` replaces the player's aim at EVERY read with the live hand aim (`live_aim`, aim_live); 1.7.20 data: stored aim 39.8 deg off the barrel in the stream update, replaced stores only 3210 of ~20000 frames. Slam: `fight_wrangled` now = lock target (player+0x2E8) is an enemy class; player+0x24D80 always holds the CProtonBeam. SLAMMASK log. HOLDVIEW absorbs up to 170 deg per frame (not within 0.6 s of a snap). LEFTUNDER pull fades with distance. Lag: probe costs <1 ms; game simulate 5.8 ms avg / present spikes; compositor 32 Hz vs 72. Profile switch log renamed USERPROFILE. tests/run_all.sh runs all 45 tests.

## 1.7.22
Options, both OFF by default (user: "not on by default just options"). **Vignette:** `vignettemath.h` (want/step/darkness_at/build, tests/test_vignette.cpp) + `handmodel_vignette` (handmodel.cpp), called from stereo.cpp right after `texture_bounds`, so it needs the window rectangle. Darkness is per-vertex colour (emissive flag alpha=1) and the blend state `g_bsDark` is Src=ZERO, Dest=INV_SRC_COLOR, i.e. out = dst*(1-d): a smooth gradient from GPU interpolation, no stacked layers. Flat NDC vertices (x,y,0) go through an Xform with r = diag(tanH*z, tanV*z, 1), t = (0,0,z), z = 0.5, so picture coordinates stay exact. Inputs: `controllers_move_mag`, `controllers_turn_info`, `controllers_sprint_want`, dash pulse (`vignette_pulse`), menu open = 0.6 preview. One step per frame pair (dt >= 2 ms), quick in (0.15 s) slow out (0.5 s). Setting `vignette_pct` (0 default). Log VIGNETTE. **Blink dash:** `dashmath.h` (double tap: push >= 0.85 for <= 0.4 s, back to <= 0.30, push again within 0.5 s; cooldown 1.2 s; 0.30 s burst x4 with soft ends; tests/test_dash.cpp). Not a teleport: in `boost_after_sim` the multiplier is max(sprint k, dash k) and only the NUDGE way reads that local k (other ways read b.s.k so they never dash), nudge cap 0.6 ft per tick during a dash, trim 1.0, and speed sampling/judging is skipped while a burst runs (`dashHold`) so bursts never count as plain/boosted walking. Gated by blink_dash, not forced moves, menu closed. Log BLINKDASH. ctlmap: left stick entry now isNew078 = 3 and says "blink dash"; test added (no grip). **Button glyphs:** not built; atlases are in pak data (ui\xbo\buttonsXBO_1024.tga etc.), controller type is 1 = gamepad; Quest A/B/X/Y already match Xbox positions. Needs the sheet or a screenshot. Compile check: SYSROOT=/home/claude/wintc/sysroot.


## 1.7.23
User (16:24, report 162219): "slam still does not work ... change my idea in terms of controls just make it work and feel good and not freak out in the body and gun; left hand fingers are weird; I want the body rig to follow ... when I look down the view model does but it looks bad; make the VR rig look and feel good without changing the gun and PKE hand placement". All changes below are UNTESTED in the headset.
- **Slam (gearmath.h TrigSlam, controllers.cpp).** Theory: the game slams only on a NEW fire edge (RT) while capture (LB) is held, a ghost is locked and the meter is full. The 1.7.22 sequence pressed fire while the player's own right trigger was often still down, so the game never saw an edge. Now: capture is forced for `capHold = kFireAt + fireLen + 0.30`, fire (`pad.rt`) is forced to 0 for the first `kFireAt = 0.18 s` (`releaseNow`), then forced to 255 for `fireLen`. `fireLen` cycles through three variants {0.45, 0.12, 0.90} per slam so one session tells which press length the game accepts. A haptic thump in both hands marks the instant of the fresh press. Logs: SLAMTRIG (variant, capHold, fireLen, releaseFrames, releasedHeld = frames where the real RT was down while we zeroed it), SLAMRESULT, BTNEVENT. tests/test_gear.cpp: release before press, simulated held RT gives exactly 1 edge with >= 15 zero polls, three variants.
- **Torso (armcore.h torso_pass step 2b).** The old lean axis had the wrong sign, so the body tipped backwards and looking down put the eyes in the model. New step 2b measures the real tilt of spine1 -> neck from upright, in the direction of the head's horizontal forward, and swings the chain forward to T = bendFrac * (pitchDown - 10 deg), capped at bendMaxDeg. It only ever adds tilt (T > current), and only when the horizontal forward is valid. Defaults bodyBendPct 60, bodyBendMaxDeg 40 (settings rev 119 migration). New stats BODYTILT: before/after/wanted tilt, passes, applied. FLOATCHECK lean sign fixed (+ pitch). Gun and PKE hand placement code not touched (arms are placed before the torso pass and the torso pass keeps them).
  tests/test_fullbody.cpp: tilt toward the facing direction at several yaws (24.0 deg for pitch 50, frac 0.6); no-op for an 8 deg look-down.
- **Left hand (engine_hooks.cpp, armcore.h curl_hand).** The finger want was a hard switch at `s_underW > 0.3`; now a smoothstep blend (`wrapAmt`) between relaxed and wrapped. The left thumb keeps the game's own pose (`ArmTargets.leftThumbKeep`, setting left_thumb_anim, default 1) instead of 1.7.22's straightened thumb. Logs LEFTFINGERS, LEFTTHUMB. Root cause of "weird" not identified for certain (pictures too dark).
- **Not built:** button-glyph swap (needs the game's atlas ui\xbo\buttonsXBO_1024.tga or a screenshot).
- **Lag check in the 162219 log:** headset 72 Hz, game ~32 frames/s with compositor reprojection (FRAMETIME / COMPOSITOR) - same advice (VD 60 Hz, motion smoothing off).
- Menu text for body bend now says 60 = default.


## 1.7.24
User (16:43/16:49): "the left hand not on the gun model looks off, triple-check the slam logic, remove percent from the ghost health bar, make the bars surrounding the color of the health neon black, explain how to slam" and "deluxe mod has been added take note and look for changes specific from that".
- **Slam (engine_hooks.cpp slam helper block, layout.h, controllers.cpp).** Disassembly (scratchpad/full.asm): player+0x24D80 is CProtonBeam, mode at +0x170 (0 idle, 2 proton, 3 ending, 4 capture), sub-state +0x174. The slam entry (RVA 0xD8596) needs beam mode 4 plus action-mask bits 0x40 and 0x200000 (RT down), then TryEnterSlam (RVA 0xDE390): meter (player+0x24A40) >= limit (float at RVA 0xDCD278 = 0.25) and flag (+0x24A48) clear, then EnterSlam (0xDE410) sets the flag and takes 0.25 off the meter. `hk_try_slam` counts the game's own calls; `sa_step` (called from `hk_wrangle` for the player) logs SLAMSTATE, and if a slam was requested (full squeeze, `slam_assist_request`) and 0.38 s later the game has not started one while a ghost is wrangled and the meter is full, calls `o_trySlam(player)` once per sequence (SLAMASSIST). Setting `slam_assist` (default 1). `slam_helper_report` writes SLAMGAME. Unverified in game: whether the helper's call alone produces the animation/damage; whether mode 4 needs a held lock target.
- **SLAMRESULT verdict (damage.cpp):** used the drop relative to the press gauge, not an absolute threshold.
- **Left hand (engine_hooks.cpp finger block, armcore.h curl_hand).** `leftThumbKeep` is now a 0..1 weight (= the left hand's wrap amount): 1 on the gun (thumb keeps the game's pose), fades to 0 as the hand leaves it, then the thumb curl follows the relaxed finger values. Log LEFTFREE.
- **Health bars (fightmath.h build).** No digits drawn (`digitsFocus` ignored). Frame and track are pure black; a hairline (7 % of bar height) in the health colour sits outside the frame. tests/test_fight.cpp updated (no white vertices, >= 12 black vertices, digits setting ignored).
- **Deluxe mod 0.8.3 (MODS\deluxe, installed 2026-10-18).** previews\modinfo.ini, data\tweak.txt (enemy HP/behaviour; "Render Health Bar=0" in several sections turns the game's own bars off), data\credits.txt, UI text and textures. modscan.cpp `deluxe_report` (read-only) writes DELUXE lines; gbvr_manager.ps1 Collect-ModInfo also copies MODS\*\ small text files (depth <= 7). The probe changes no damage or health value.
- **Menu:** Help page gets a HOW TO SLAM note (7 rows). README_1.7.24.txt has the plain steps.


## 1.7.25
User (17:29/17:30) with report 172859 (1.7.24 log): slam before it is full (charges), spin, left fingertip wrinkle, goggles gone, gun/PKE vanish while walking + overlap rig, rig snaps back when looking behind/side, Deluxe left alone, no bar for ghosts in the trap, remove unneeded tracking/recording; simpler slam; holstered gun puts right arm out of use and the gun at the side, not the back.
- **Slam facts from the log:** the game's own slam entry (TryEnterSlam RVA 0xDE390) was reached 0 times in 6 tries; the helper's call was accepted twice (flag 0->1, meter -0.25; the flag cleared and the meter went to 0.00 about 0.9 s later). Disassembly: in capture mode 4 (0xD8596) the entry needs mask bit 6 (action 0 / Primary down, set in the proton case 0xDC606) and bit 21; bit 21 = Primary down (0xB9A20/0xB9DA0) or, with a lock target, Secondary down while Primary down. Releasing fire dropped mode 4 -> 3 and the ring (SLAMSTATE), so the 1.7.23 release-then-press gap made the helper skip ("no ghost under the ring"). Now: TrigSlam kFireAt 0, no release, no fire press; `sa_step` calls the game's function at once (retries 0.6 s while the ring / mode 4 are not there). ready = meter >= 0.25 (one charge).
- **Body follow (followmath.h):** `dwellSec` 0.7 (not while walking, mv > 0), default start 75 deg (was 35); State.dwell / dwellHolds; migration rev 120.
- **Holster (engine_hooks.cpp):** arm_drive no longer skips the right hand when holstered (gunWrap 0 then); body_push stores the pack matrix (`g_packPoseW`); the wand hook draws the holstered gun at the pack + 0.35 ft (`holster_on_back`).
- **Aim hold:** `wand_aim_read` keeps the last good aim for 0.15 s (seqlock misses / grip unknown). AIMHOLD log.
- **Fingers:** left hand uses `kShareL` / `kMaxL` (tip 16 % share, cap 50 deg).
- **Bars:** `in_trap` hides bars of ghosts within 3.5 ft of a trap object more than 4 ft from the player (BARTRAP).
- **Goggles:** pke_frame default and migration -> 1; menu Sound page row. Unclear what the user meant: asked for a screenshot.
- **Deluxe:** now installed as MODS.POD (103 MB) + PATCH.POD next to ghost.exe (written 2026-10-21 20:49 UTC); modscan logs them. proxy.cpp beam_damage default 100 everywhere; DELUXESAFE line.
- **Log:** full dump gated in render_hooks.cpp (first 10, every 2160 frames, `g_reportNow` after a slam try / pause); BTNPROBE hooks no longer installed. Measured in the 1.7.24 log: probe per-frame cost ~0.2 ms (controllers 83 us, bodyPush 2 us x6, hud 12, submit 37, arms 11), game simulate ~5.6 ms, waitPoses ~9.9 ms.
- Tests: test_gear (new slam sequence), test_follow (dwell).


## 1.7.26
User (19:00): "sometimes the rigs get messed up in-game cutscenes, stop those from affecting the rig and make the body feel more connected and realistic".
- Facts from the 1.7.24 log: 9 FORCEDMOVE events (5 jumps, speeds 2.6-6420 ft/s) and 322 RIGEVENT passes in "forced"; in those passes the right wrist stayed 0 cm from the controller, i.e. arm_drive kept dragging the animated arms to the controllers. forcedmath.h only faded the eye-match shift. No cutscene flag is known in the game (layout.h has none; pauseFlag does not track cutscenes).
- cinemath.h `cine::Guard`: engages after `engageSec` 0.55 s of a forced move, or at once on a jump (teleports count rises); holds 0.6 s / 1.5 s; blend rises 0.12 s, falls 0.7 s. `mix16` blends probe and game matrices.
- engine_hooks.cpp: Guard updated in body_update (after the forced detector, game thread) -> `g_cineBlendX1000`; `body_push`: blend >= 0.999 returns the game's matrix (counts bodyPass/packPass/hosePass), 0..1 mixes W2 with the game's matrix, `arm_drive` skipped above 0.5; wand hook passes through above 0.5; the right-stick follow push is blocked above 0.5. Logs: CINE start/end, CINESUM in the report.
- Setting `cine_guard` (default 1, menu Sound page), settings rev 121 (torso_dead_deg 12 -> 8, torso_lag_ms 170 -> 140 only when still at the old values).
- Tests: tests/test_cine.cpp.
- Open: scenes where the actor stands still are not detected; a second signal (scripted camera turn without stick or probe push, the hand-far-from-wand condition with item 0) needs data: CINESUM / CINE lines will show.

## 1.7.27
User (19:41): gun/view model/PKE sometimes in one eye only; PKE scans but no green goggle view; PKE sometimes vanishes; story does not progress (characters wait although the player did the thing); better resolution. (19:45): health bars must NOT go away behind a wall, but no bar when not spawned / dead.
- Root cause found for the missing goggles: player+0xB550 is the game's HUD (CGameView), not a lock target. Evidence: HUD::Init 0x1FDBA3 stores itself there, the player destructor 0x6EFC5 deletes it, the goggle sites 0xCAB20 / 0xD7AB1 call HUD::setGoggles (0x1FEFB0, fader at hud+0x448) only when it is non-null. The 1.7.2 fight_lock_guard zeroed it at the first stream request of every session (LOCKGUARD "sits on a CGameView ... let go" in every log).
- Fix: fight_lock_guard only counts slot 0. New hook on the proton stream update 0xE6360 (single caller 0xCAEB2): the HUD pointer is 0 only for the player's own call (the VR barrel-line aim relies on the B550 == 0 path), restored right after. Log STREAMHUD. layout.h kRvaStreamUpdate + kBytesStreamUpdate (verify_layout.py checks the bytes).
- Story not moving on: hypothesis only (prompts / tutorial hints run through the HUD). Unproven.
- Same picture: pair memory (PairMemEnt g_pm[48]): the left eye stores its answer for the mirror-only check (0xD35D0 hook) and the draw rule (0xEEC70 hook, player parts); the right eye of the same pair (g_st.pairFirst equal, < 0.12 s old) replays it. PARITY logs the first 40 differences. Setting same_picture (default 1, menu Sound page). The real cause of the one-eye mismatch is not confirmed; the PKE entity's own culling is not covered.
- PKEVANISH: logs transitions of the wand-slot mirror-only answer with the PKE held (B568 goggle button byte, +0x247C4 blend, flags). Diagnostics only.
- Resolution: monitor_wide_pct 125 -> 100 (widen multiplies needTanH/V: the headset lost 25 % linear density; eye pixels were 1787x1931 = 51 % of SteamVR's recommended 2496x2688). Anisotropic filtering: CreateSamplerState hook (device vtable slot 23) turns MIN_MAG_MIP_LINEAR into ANISOTROPIC with texture_aniso taps (default 16, restart needed). Log SAMPLERS.
- Bars: wall hiding only when hbar_wall_hide=1 (default 0); not-spawned / dead filtering (actor_lockable, f <= 0) stays.
- Settings rev 122: pairSame=1, hbarWallHide=0, pkeFrame=1, texAniso=16, monitorWidePct 125 -> 100 (only when it was 125).
- Open: whether the HUD fix unblocks the story; PKE vanish cause; one-eye mismatch cause.

## 1.7.28
User (20:01): the PC window must fill the screen in-game and in the menu ("very zoomed out"), without changing the VR resolution; make the menu the Ghostbusters game menu, not the probe's own; hold it in the hand while the world is paused around it; merge the VR settings into the game settings; "do all". (20:03): keep the song when paused - the only thing wanted from the old VR menu.
- Monitor, in game: the log showed the window at 2560x1440 with the whole eye picture (about 120 x 89 degrees at monitor_wide 125, 108 x 76 at 100). New `monitor_hfov_deg` (default 100, 0 = the old zoom): monitorview.cpp asks `monitor::zoom_for_hfov` (monitormath.h, tangent proportional) for the zoom that shows that many degrees across; monitor_zoom_pct range 50..100 -> 30..100. Crop is in the PC window pass only; the eye textures are untouched. Log MONITORFOV. Reasoning for 100: 1.4-1.7.8 showed 91 degrees (zoom 72) and the user said "FOV too small" (1.7.9); 1.7.9-1.7.26 showed 121 and 1.7.27 110, "very zoomed out".
- Monitor, in the menu: the flat 2D screen's back buffer is 2880x2880; FLATVIEW drew it as a 1440x1440 square at 560,0 in the 2560x1440 window. `monitor_menu_fill` (default 1): flatview_present(inHeadset) returns at once, Windows stretches the buffer over the window, flatview_get_view reports "not corrected" so the mouse/laser mapping is the plain per-axis scale. Not distortion-free (a square becomes 16:9); the alternative would cut 44 % of the menu.
- Hand-held game menu (`held_menu`, default 1; heldmenu.cpp, heldmath.h): the gesture / F12 (`vrmenu_toggle`) now calls `held_menu_toggle`: `game_menu_request()` (Start once if the game runs; the 3-minute latch keeps NOPAUSEMENU away) or, when the menu is up, `game_menu_close()` (Start once). `held_menu_tick` (from vrmenu_tick, every headset frame) is active when the setting, the headset view, the flat screen, `game_paused_flag()` (appPaused / pausedByte, same as NOPAUSEMENU) and the request latch (refreshed every tick while up) all hold; it starts the song (`audio_menu`) and ends it when the game runs again / the 2D screen is gone for 30 ticks.
  - stereo.cpp show_flat: `held_menu_place` -> the flat overlay gets a placement every frame: `held::place_panel` (middle 17 cm above the logical-left hand, 6 cm toward the head, facing the eyes, never rolled; hand position smoothed with tau 70 ms), width held_menu_cm (default 46), no bend, no TV glow. `submit_frozen()` hands the last whole pair (g_eyeTex/g_eyeBounds/g_eyePose, `g_frozenOk` set in submit_eyes when both eyes were accepted) to the headset instead of the black picture. When the held menu ends while the flat screen stays (loading), `g_flatPlaced = 0` puts the big screen back in front of you.
  - VR SETTINGS: `held_banner_paint` UpdateSubresource's a GDI-made button (vrmenu_banner, 2 states: plain / pointed at) into the bottom of g_flatTex (rect from `held::banner_rect`, u 0.28-0.72, v 0.925-0.992), formats 28/29 (RGBA) and 87/91 (BGRA). menu_pump asks `held_menu_pointer` first: moves set the hover, a click that starts and ends on the button opens the pages (`vrmenu_open_in_hand`) and is not sent to the game. The pages (vrmenu.cpp) hang in the same hand (`held_vr_place`, 0.64 m wide, 19 cm above the hand), the flat overlay is hidden meanwhile (show_flat returns early with the frozen world), the close button reads "< Game menu" (g_viaHeld) and only closes the pages. No song/freeze changes from the pages while viaHeld.
  - autopause_tick: the "menu open and game paused 2.5 s -> close my menu" rule is skipped when held_menu is on.
  - New Menus page (Hand-held game menu, size, Monitor view width, Menu fills the monitor); Help text updated; ctlmap.h text for the ear gesture updated (no new mapping; no grip use added).
- Settings rev 123: monitor_hfov_deg 100, monitor_menu_fill 1, held_menu 1, held_menu_cm 46, monitor_zoom_pct < 100 -> 100.
- Tests: tests/test_held.cpp (placement orthonormal / faces the eyes / level, smoothing, active rule, button rectangle), test_monitor.cpp (zoom_for_hfov, zoom floor 30). verify_layout.py unchanged.
- Open / unverified: whether the game's pause menu always means appPaused (the focus-loss pause did), where the game puts its own bottom-of-screen hints in the square layout, whether the frozen last pair looks right (HUD, hands, gun are baked into it), whether the left hand is a comfortable holder. The 1.7.27 questions (HUD fix and the story, one-eye cause, PKE vanish) are still open.


## 1.7.29
User (20:31): "place the menu on the PKE as in the actual game, the other hand a point to click everything, smooth"; "in-game VR did not work, it took me to the menu but out of VR"; "the rig shakes a lot when the body moves, equipment looks off"; "PKE did not scan"; (20:34) "PKE scanned the ghost and another thing, failed on the third".
- Held menu never came up in 1.7.28: `held::is_active` required `game_paused_flag()` (App+kAppPaused / byte 0x20B01D0), which the pause menu does not set (HELDMENU requests=1, opens=0, activeTicks=0, "paused" never true). Now `is_active(setting, headset, flat, requestedRecently)`: flat screen within 6 s (`held::kRequestWindowMs`) of `held_menu_toggle` (`g_h.reqMs`). Logs the latency ("HELDMENU opened ... N ms after the request") and, if no flat screen after 2.5 s, why (running / paused flags). Closing: setting off / headset ended / flat screen gone for > 8 ticks; `game_menu_release()` ends the request latch without pressing Start.
- Own pointer (heldmenu.cpp `held_menu_frame` -> `pointer_step`, once per flat frame after `menu_pump`): right (logical gun) hand, measured pose, `held::ray_hit` (ray = -z of the hand; margin 5% so it does not blink at the edge), `vmenu::Pointer` (OneEuro + 4 px dead zone + trigger lock from 0.15) in half-millimetre units, `menu_inject(u, v, type, button)` (menu.cpp) posts WM_MOUSEMOVE / BUTTON / MOUSEWHEEL to the game window through the same flatview letterbox map as `menu_pump`; click = trigger > 0.6 after < 0.2 (armed), up < 0.35, haptic 2500 us; right stick scroll `held::scroll_notches` (7 notches/s max); A (kVrA, the bottom face button per the standing no-grip / no-Menu rule; rising edge, ignored the first 0.5 s) closes; registered in ctlmap.h (kHeldMenuOn rows + settled notes). SteamVR's laser on the flat overlay is switched off while the held menu is up (`vr_capi_flat_laser(0)` -> overlay input method None); the 1.7.28 run had 8 laser moves and 0 clicks. The ring is always painted while held (flat_cursor setting ignored).
- Panel: 36 cm wide (rev 124: 46 -> 36), middle 15 cm above the hand, 8 cm toward the head. The real PKE model is not drawn under it (hand placement must not change).
- Calm walking (`body_calm_ms`, default 140, 0 = off; Comfort page replaces the duplicate Recenter button): armcore.h torso_pass step 4. off = avatar eye - pelvis (world); `calm::step` low-passes it (tau, max lag 0.10 ft, restart on a 0.6 ft jump / 0.25 s gap / NaN / fade < 0.99); S = goal - pelvis - smoothed off; the hidden head slides the (<= 0.10 ft) remainder so the eyes still sit on the headset eye. Stepped once per game frame (`calmSeq` = worldFrames, `calmDtS`). Measured in the 1.7.28 log: the wrists stay exactly on the controllers (RIGEVENT 0 cm), eye error mean 0.49 ft, body shift mean 0.44 ft, ANIMPUSH mean 0.014 ft, legs clamped 11%; I found no direct evidence of the shake itself, so RIGSHAKE logs the second difference of the body's offset (mm, raw vs applied, standing vs moving) and the frame gap distribution.
- PKE: `pke_sources_scan` skips dormant (IsScannable 0) and already scanned (IsScanned 1) sources within 60 ft, includes CTrinket collectibles (aim +0.3 ft), logs counts in PKESRC; trigger-press PKESCAN lines name the class, scannable/scanned flags, distance, angle, cone, range; PKECUE gives a dull tick for a locked but not-scannable target. The third failed scan in the 20:34 run was Slimer (already scanned).
- Settings rev 124: body_calm_ms 140, held_menu_cm 46 -> 36.
- Tests: test_held.cpp (4-arg is_active, request window incl. tick wrap, ray_hit, scroll_notches), new test_calm.cpp (flattening of a 2 Hz bob, lag cap, catch-up, jump / gap / dt 0 / off / NaN, second difference). 49 pass.
- Open / unverified: that the pause menu is shown as a flat screen within 6 s of the Start tap in every case; the pointer's feel (filter constants are the VR settings pages' values); whether calm walking is the cause of the shake the user sees (RIGSHAKE will tell).

## 1.7.30
User (21:23, report 212223): "the view model flickers, but only in the left eye"; "health bars spawn before ghosts do and stay after ghosts are in trap"; "the mirrors in the hotel don't reflect correctly"; "the gun starts in the hand when I spawn in, then floats away".
- Mirrors (disassembled this round): camera vtable+0x50 = 0x454530 (called from the visibility stage, ret 0x454553) calls the mirror-view builder 0x427210(list=[0xDDA608], ctx). The builder reads cam = ctx[0] and, right at its start, calls 0x3DD40(out=[rsp+0x78], cam+0x14) (Euler -> 9-float basis, ret 0x4272AA) then reads the eye cam+0x08/0x0C/0x10 into its stack. After 0x427300 rbx is the mirror object. So the mirrors came from the CAMERA OBJECT's eye and angles, not from what Prepare hands to the engine (the probe replaces the latter only). Fix (engine_hooks.cpp `hk_build_mirrors` / `hk_euler_to_basis`): if the thread's last Prepare was a headset-modified one of the same camera (`g_lastTid/g_lastCamera/g_lastModified/g_lastEyeApplied`), write `g_lastEye` into cam+0x08..0x10 for the duration of the call (restored after) and replace the 0x3DD40 result at that one call site (ret 0x4272AA) by `g_lastOut`. Setting `mirror_vr` (default 1). The second builder 0x428400 (type-4 views, object at view+0x180E0) does not use the player's eye. UNVERIFIED in game: that g_lastOut has the same layout as the 0x3DD40 output (it is the matrix 0x3019F0 receives, which comes from the same conversion), that the mirror's own projection needs no change.
- One-eye parity: PARITY (1.7.29 log) left stored 393,278 / right replayed 321,973 / no left answer 71,333 for the mirror-only checks, draw rule 234,944 / 188,485 / 22,776; BODYEYE asked(prepare) 266,334/265,536 but drawn+refused 234,944 left vs 211,261 right: the left frame asks the draw rule ~23,700 times more than the right. The 48-entry replay table was the leak (10-17 % of right-eye answers lost). Now 8,192 entries, hash + 24-slot chain, stamped with the pair id (`g_st.pairFirst`), the view kind (view+0x180C4) is in the draw-rule key. Only 22 + 11 real disagreements in the whole run: the table is not proven to be the flicker's cause. New VIEWDRAW (per eye x class main/mirror/shadow x view kind x pass, for the player's parts, plus "others") shows what the extra left-eye questions are.
- Gun vanish seen in picture 211601 (row 2/3 without gun, both eyes) coincides with ITEMS "1 1 0 0 3 1 1 0" (item 1 in hand -> owned -> in hand, requested last 1) right after WALL #15 (camera pulled in to 2.34 of 4.5 ft): the game's own re-equip, not the probe. Picture 211646: the PKE screen disappears in rows 2/3 in both eyes while the handle stays (PKEVANISH shows the wand-slot answer toggling normally with the goggles).
- Health bars (barlogic.h, tests/test_barlogic.cpp): per ghost `Track.seen` (set when the game's seen-frame test passes, or when hit / in the capture stream, or when the test is not trusted), forgotten after 2 s neither active nor drawn; the drawn test is calibrated against surely-visible ghosts (trusted unless >=12 fails with fewer than 1 pass per 6 fails). `Track.trapped`: set when the ghost is the capture stream's held target (`g_sl.wrPtr`) within 4 ft of a trap that lies on the floor (trap y - player y < 1.5 ft; the player->trap distance no longer matters), released when the ghost is more than 8 ft from where it was latched. A ghost within 2 ft of a floor trap loses its bar too. Setting `hbar_smart` (default 1). 1.7.29 log: drawn test passed 5,930 / failed 26,667 for ghosts the 1.7.19 rule accepted (= the "bars before ghosts" cases); BARTRAP counted only 1,206 checks.
- Gun at spawn: `GUNSPAWN` (first 90 reports): deltas of wand pushes applied / refused by reason, shift from the game's spot, item in hand. FLOATCHECK shows wrist 3 cm (arm hanging) to 8-11 cm (arm raised) from the controller; WAND `lastShiftFt` 1.65, glue 0. No placement change (standing instruction).
- Menu: new "Fixes" tab (Mirrors follow my head, Smart health bars, Health bar hides behind walls). Settings rev 125. Layout: kRvaBuildMirrors 0x427210, kRvaEulerToBasis 0x3DD40, kRvaBuildMirrorsEulerRet 0x4272AA, kRvaBuildMirrorsCaller 0x454530, kRvaBuildMirrorsRet 0x454553, kViewType 0x180C4 (all checked in verify_layout.py).
- Open / unverified: mirror look in the headset; whether the caught-in-trap latch fires (needs a BARTRAPPED line); the left-only flicker's real cause (VIEWDRAW / PARITYTABLE next).


## 1.7.31
Report 22:15 (no log): left-eye rig shake while moving (two-hand gun, PKE), bars on trapped ghosts, hands good for ~2 s then bad, hand-held menu a different size per eye and laggy.
- Trapped bars: `player+0x24D80` is the CProtonBeam, never the ghost (1.7.30 compared against it). The held ghost is the lock target (`player+0x2E8`) while the capture button is down; the floor trap sits 0.1-0.9 ft above the player (carried 2.8-3.7 ft). barlogic.h: `trap_step2`, `vanish_step`, `vanish_trusted`, `in_cone`, `dist_xz`. The game's LOS function 0x7BCE0 separates "behind a wall" (keep bar) from "gone". Logs BARGONE, BARTRAPPED, TRAPWATCH.
- pair_hands: `head_aim_publish` caches the `HandsRaw` of the first eye (pairRole 1) for 100 ms and gives it to the second eye. PAIRHANDS measures how far the controllers moved between the two reads (still / moving). GEARSHAKE / GEARTRACE note the gun (wand push, `gear_note(0|1)`) and PKE (`gear_note(2)`) placements.
- Early hands: STARTTL (engine_hooks.cpp, `starttl_sample`, called from `head_aim_publish`): first 12 s after the actor appears, 0.25 s steps, 3 windows. The cine guard and forced-move detector never fired in the 1.7.29 log (CINESUM all zero), so the old "fade" theory is dropped.
- Menu: heldmenu.cpp mover thread (high-resolution waitable timer, 4 ms, ABOVE_NORMAL), measured hand (`vr_capi_hand_measured`, no shared predict flag), tau 25 ms, seqlock `mover_read`; the thread calls `vr_capi_overlay_move` (game panel) or `vr_capi_menu_move` (settings pages) only while the render thread placed that panel in the hand in the last 300 ms. stereo.cpp passes no transform to `vr_capi_overlay_update` once the thread owns the panel (otherwise every flat frame set it back to an older spot). `held::keep_away` pushes the panel middle along head->panel to `held_menu_min_cm` (scaled by width/0.36 so the angular size is kept). Logs HELDGEOM (distance and angular width per eye, 64 mm eyes assumed), HELDTIMING (flat-frame gaps, frame cost), HELDFOLLOW (thread counters), FROZENEYES (stored world pictures behind the menu, per eye bounds and pose difference).
- Settings rev 126: pair_hands=1, held_menu_follow=1, held_menu_min_cm=55. VR menu: Fixes > Same hands in both eyes; Menus > Menu follows my hand fast, Menu closest to my eyes.
- Open: the real cause of the left-eye-only shake, of the ~2 s hand change and of the per-eye menu size is unproven. Read the new logs first.


## 1.7.37
- Base: ChatGPT 1.7.35 source merged with my 1.7.36 (knock-down comfort, always-rumble) re-applied.
- New: gun life bar (gunbarmath.h, handmodel.cpp doGunBar; fraction from actor+0xB860/+0xB868), beam damage locked to 100 on load, VR SETTINGS banner painted on 3840x2880 texture, freer trap throw (Trap armDist/coolS), trap launch-from-hand (fight_trap_launch), CAPWHY diagnostics, 9-page menu with tabs 58/6.
- Test: tests/run_all.sh 57 pass. Untested in game.
- Open: grab lock root cause, 360 menu backdrop, view-model feel.

## 1.7.38
- Cause of 'cannot grab objects': lock_ghost_only (1.7.2) wiped the prop lock every frame before the capture step. Now kept while bindings_capture_down().

## 1.7.39
- Spec (chest camera) frame flow: render thread after a submitted pair -> g_ctl.stereoSpecNext=1 -> next hk_prepare: arm_stereo consumes it (needs pair state < 100 ms old), a.spec=1 -> StereoFrame.spec -> stereo_before_present copies the back buffer to g_specTex and returns before any submit; stereo_after_present returns before the compositor wait. Tick role 2 is used for the tick after it (full tick with the small elapsed time).
- Sprint: SPRINTFORCE log shows forced / yielded counts.
