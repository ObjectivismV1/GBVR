# Status board - 2026-10-21 (probe 1.7.31)
Mode: agentic | Gate: soft (everything is "untested" until the user's log shows it) | Headset: Quest 3, Virtual Desktop + SteamVR

- Seen working in the logs: stereo at 72 fps, head tracking, controllers place gun / arms / PKE (hand within 3 cm of the controller in 97 % of arm passes), walk-where-you-look, damage reaches ghosts, PKE scan chain (one scan finished in the 1.7.1 log).
- 1.7.31 (built, untested; no log came with the 22:15 report): trapped-ghost bars use the lock target and the floor trap (player+0x24D80 is always the CProtonBeam, so 1.7.30's check never matched); setting pair_hands makes the second eye of a pair reuse the first eye's hand poses (PAIRHANDS, GEARSHAKE, GEARTRACE measure it); STARTTL logs the first 12 s after the player appears every 0.25 s (hands good then bad after ~2 s is NOT explained: cine guard / forced move never fired in the 1.7.29 log); hand-held menu has its own follow thread (~4 ms, 25 ms smoothing, held_menu_follow) and a closest-to-the-eyes push (held_menu_min_cm, 55); logs HELDGEOM, HELDTIMING, HELDFOLLOW, FROZENEYES. Settings rev 126.
- 1.7.30 (built, untested): hotel mirrors are built from the headset eye and direction (hooks on the mirror builder 0x427210 and its Euler->basis call, setting mirror_vr); smart health bars (seen-once latch, caught-in-trap latch, drawn-test self-check, setting hbar_smart); the one-eye answer table is 8,192 entries instead of 48; new logs MIRROR, PARITYTABLE, VIEWDRAW, BARSMART/BARSEEN/BARTRAPPED, GUNSPAWN; new VR menu tab Fixes. Left-eye-only flicker and the gun floating away are NOT proven fixed: the logs decide.
- 1.7.29 (built, untested): the hand-held menu now really starts (no more waiting for a paused flag), right hand = own smooth pointer with trigger click, stick scroll, B closes; 36 cm panel on the left hand; calm walking filter for the body (body_calm_ms) + RIGSHAKE meter; PKE aim help skips dormant/scanned sources and includes collectibles, dull tick when a target cannot be scanned.
- 1.7.28 (built, untested): the game's own pause menu is the menu, held above the left hand with the world frozen behind it and the song on (held_menu); VR SETTINGS button inside it opens the probe pages in the same hand; PC window crops to 100 degrees across (monitor_hfov_deg) and the flat menu fills the window (monitor_menu_fill); headset picture untouched.
- 1.7.27 (built, untested): HUD pointer (player+0xB550) restored outside the stream update (goggles; story prompts suspected), same picture in both eyes (pair replay + PARITY), PKEVANISH diagnostics, monitor_wide 100 + anisotropic textures, bars stay behind walls (hbar_wall_hide).
- 1.7.26 (built, untested): cutscene guard (body, arms, gun left alone while the game moves the character, eased in/out; menu Sound page), torso follows the head sooner (8 deg / 140 ms).
- 1.7.25 (built, untested): slam through the game's function at once on one charge, body-follow dwell 0.7 s / 75 deg, right arm + gun-on-the-back while holstered, aim hold 0.15 s, left fingertip cap, no bars at the trap, goggle frame on, lighter log (full dump every 30 s).
- 1.7.24 (built, untested): slam helper + SLAMSTATE/SLAMASSIST/SLAMENTER/SLAMGAME logs, left thumb relaxes off the gun (LEFTFREE), ghost bars black with neon hairline and no percent, DELUXE mod report (mod 0.8.3 installed 2026-10-18; reads only).
- Built, not yet tested in the headset: 1.7.17 (height measure sets world size, capture-spin guard, relaxed fingers, health bars on); 1.7.18 (damage 115, PKE auto-scan locked off, narrower PKE cone, RIGEVENT / PKEACC logs).; 1.7.19 (left fingers, left hand under the barrel, smaller see-through bars only for active ghosts not behind walls, capture guard, freer trap throw); 1.7.20 (smooth health colour, weapon checks, left-handed, seated, profiles, controller families, Comfort page); 1.7.21 (body bend when looking down, game-base damage with no hook, solid bars, live aim for capture/slam, wider spin guard, softer left-hand pull); 1.7.22 (comfort vignette and blink dash, both options and off by default); 1.7.23 (slam: release fire then press fresh with 3 press lengths + thump; torso tilts toward where you face when you look down; left fingers blend smoothly, left thumb keeps the game pose)
- Open, no evidence yet: PKE line-of-sight "no clear line" in most locked updates (1.7.1 log), stiff body feel, PKE box overlapping the gun (1.7.12 pictures).
- Not started (playbook gaps): left-handed mode, seated mode, user profiles, other controller families, button-prompt substitution, desktop simulator.
- Next: user runs the 1.7.18 list (PKE no auto-scan + scan accuracy, damage, hands) and sends COLLECT_LOGS; I read PKEACC, PKESCAN, PKEWHY, RIGEVENT, DMG first.

# Status - Ghostbusters: The Video Game Remastered VR mod - 2026-10-12
Mode: agentic | Gate: hard (user tests in the headset) | Probe 0.69, "stage 2-8 prototype"

## Status board (against the VR-mod playbook)
- Built and tested by the user: entry (d3d11.dll proxy), camera ownership (head tracking, first person), stereo (eye pairs, 72 fps when the PC has memory), controllers as Xbox pad, wand follows the right controller, in-VR menu opens, haptics.
- Built, NOT yet seen working: full body (head/spine/crouch/legs/arm stretch, 0.61-0.62; 0.61 test had it switched off by a bug, fixed in 0.62), menu own pointer (0.62), pause-menu escape (0.62).
- Broken / open: game stutter (game's own Simulate 10-20 ms per pair at times), pause menu on Virtual Desktop -> SteamVR switch, menu lag/flash.
- Not started: comfort options (snap turn, vignette, seated/standing), physics hands and grabbing world objects, holsters beyond the simple one, button-prompt substitution ("Press E" -> controller button), in-menu profiles, IK for real foot stepping, mirror/body view calibration flow, desktop simulator, in-VR bug-report button (MARK exists), packaging/README for others.
- Won't be in Phase 1 (proposed): vehicles/ladders unless the game has them in the early levels; performance pass.

## What was improved this round
1. Found the real reason the body never appeared (settings file kept body_follow=0 from the speed guard).
2. SMOKE line in the log (0.63): says OK/WARNING about whether the body layer is really enabled, so a bad run is spotted in seconds.
3. Docs: this board and plan.

## 0.69 (2026-10-12 19:00)
- Seen in the 0.68 test (log 171545 + report c5933155, user words): body still below the head, beam drifts left/right sometimes, gunplay better after the height test, gun not in the hand, "not all menu features work"; swinging comes from cutscenes where the game moves the character.
- Fixed this round (untested in VR): exact per-frame eye match (no learned bias; model eye height from a histogram mode), forced-move detector (cutscenes) that eases the body out/in, straight beam (game bend toward the head ray removed for the player's stream), aim assist cone 10 deg + ring freshness 350 ms, menu song (gbvr_menu_music.mp3, 65 %) + game sound muted while open (WASAPI own session + other-session volumes, crash marker file), see-through menu over the blurred cover picture, Sound tab, 8 tabs.
- Still open: which menu rows "do nothing" (asked), whether the game's sound goes through a Windows session (AUDIO log), gun-in-hand check, stutter root cause, comfort options, real foot stepping.

## 0.68 (2026-10-12 16:30)
- Seen working by the user (0.67 log + video): headset runs, body follows, menu opens, pointer points.
- Fixed this round (untested in VR): avatar eyes lined up with the camera (body was below the head), shoulder reach + stretch 150 %, pack follows crouch/lean, crouch dead zone, lighter one-hand gun + firmer when firing, aim assist, menu pointer smoothing/hold + click arming + log, menu freezes the game again.
- Still open: stutter root cause, comfort options, arm-span calibration, real foot stepping, aim assist depends on the game's target ring.

## 0.67 (2026-10-12 15:00)
- 0.66 test did not reach the headset: SteamVR error 1114 (its own Oculus add-on) and a blocked add-on. Nothing of 0.66 is verified yet.
- This round: SteamVR check + readable failure reason (STEAMVR / STEAMVRLOG log lines, window title), 3 tries to connect, COLLECT_LOGS to Downloads with SteamVR's logs and settings, installer no longer backs up its own DLL.
- User action: SteamVR > Settings > Startup / Shutdown > Manage Add-Ons: unblock, Oculus add-on OFF; restart SteamVR from Virtual Desktop; then test the 0.66 list.

## 0.66 (2026-10-12 14:30)
- Seen working by the user (0.64 log): full body moves (head, back, legs, arms), SMOKE OK.
- Fixed this round (untested in VR): gun floating beside the hand (arm stretch 260 %, gun glued to the hand when the arm falls short), per-frame lag (cached memory checks, second-eye arm skip), menu pointer lag/flash (pointer ring as its own overlay), height reset button, Full body menu tab.
- Still open: stutter root cause proven only by the next log (MEMCACHE / PROFILE), comfort options, arm-span calibration, real foot stepping, pack/hose lean.

## 0.64 additions
- PERFADVICE auto-lowers the picture level after ~10 s under 62 pairs/s; MARK saves the two-eye picture.

## Audit - what the playbook says we lack (ranked by value)
1. Verified body (stage 7): never yet seen in the headset. Everything else waits on this.
2. Comfort (stage 4): none. Add vignette and snap turn (stick turn is the game's own; can be quantised in the pad bridge) + seated/standing height offset. Cheap, high value.
3. Own bug capture (pipeline intake 2): MARK exists but nothing captures a screenshot of each eye plus the last log lines; the F2 diagnostic picture can be tied to MARK.
4. Calibration flow (stage 7/9): height only. Add arm span (scales arm stretch), a mirror/body-view toggle.
5. Settings (stage 9): menu has most settings but no profiles and no reset-all.
6. Prompts (stage 8): text substitution for "Press ..." strings.
7. Hands/grab (stage 5): doors, pickups by hand; needs game object hooks (unknown).
8. No desktop simulator: every test costs headset time. A scripted fake-head replay inside the DLL would let me test body code without you.

## Game plan
- Next test (you): install 0.63, F4, look down, turn/tilt, lean, crouch, open menu, play 2 min, send log. I read SMOKE, BODYPOSE, ARMS, BODYFOLLOW first.
- Then, depending on the log:
  A. Body works -> tune (eye offset, knee direction, head pivot), add arm-span calibration, mirror view.
  B. Body shows no change -> read BODYCHAIN / verify counters (kept vs lost) and move the hook later in the render pass.
  C. Stutter -> add per-call timing of the game's Simulate callers to find which game system is slow; try lowering physics substeps.
- Version 0.64: comfort (snap turn + vignette + seated offset), MARK-triggered screenshot report.
- Version 0.65: calibration flow + profiles + reset-all.
- Version 0.66: prompt text substitution, hand interaction research (which game functions open doors/pick up).
- Then packaging (README, uninstall, controls per controller family) when the body and comfort are accepted.


## 0.70
- Menu: two alternating overlays (no blank frame), pointer dead zone 4 px + creep, minCut 0.9.
- Song default 55 (migration 65->55). Settings rev 70.
- Gun: gun_glue default 0 (migration), arm stretch 250 (migration from 150), one-handed firing heavier/shakier (weightmath.h `oneFire`), two-hand firm.
- Body: sideways eye residual moves whole body + ankle targets (cap 6 ft), vertical part capped 1 ft with legs planted. BODY70 log.
- Open: 'above the body at 110% / stomach at 83%' root cause unknown; read BODY70 camera vs avatar eye above feet next.

## 0.71
- Arms only: armcore.h collapse_body/collapse_undo (all bones outside clavicle+arm subtrees squashed to one point behind the shoulders after the arms are placed; undone at the next apply). Setting arms_only (default 1), Body tab, log ARMSONLY. Body (VR-skill Stage 7) paused; focus Stage 6 gun/hands.

## 0.72
- Gun tracking: weightmath omega1 42/(1+.35k), droop 1.0k, maxLag 20 (1.35x one-hand firing), pos omega 70/(1+.4k), cap 4 cm; one-hand firing heaviness via oneFire.
- Arms polish: elbowOut 0.5 (outward pole), ARMVIEW log. Menu cleanup to 7 tabs. 0.70 log: wrist miss <=0.14 ft right; gun lag 9 deg/16 mm mean was the issue.

## 0.73
- Physics hose: src/cordmath.h (Verlet rope, 22 points, gravity 9, damping, 12 constraint iterations, rest length 1.2 m growing to 1.03 x distance when taut, floor at tracking y=0, torso capsule, pinned ends; pack anchor 0.48 m below / 0.26 m behind the head, turned by a slow body yaw with a 25 degree dead zone; wand anchor 13 cm behind the grip). Drawn by handmodel.cpp as a second draw in the same D3D pass (dynamic vertex buffer, 756 vertices). The game's own hose is hidden (hk_mirror_only hose site only) while the cord was drawn within 0.5 s (handmodel_cord_active). Settings cord_physics (default 1), log CORD.
- Shoulders: ArmTargets.keepShoulders (setting arms_shoulders, default 1): collapse_body also keeps the spine3 subtree minus neck/head; the squash point is 0.5 ft below / 0.3 ft behind spine3. Log SHOULDERS (spine3 relative to the camera eye).
- Data for tuning anchors: BODYREL lines (pack/hose relative to the eye in headset axes next to the game's wand).
- Menu: Arms tab now 7 rows (Arms only, Shoulders and straps, Hose with physics, ...). Fixed proxy.cpp: the 0.71/0.72 line with menu_mute_game / menu_bg defaults was inside a comment.
- Untested in the headset: cord anchors (pack end, wand end), shoulder look, the stretched triangles between kept chest and the squash point.

## 0.73.1
- Stuck ghosts (user: stuck in walls/floor, in every version, not due to height/world size - those only move the camera, verified in code). Cause found in the 0.70 log: 43 tick gaps > 50 ms in 8 minutes; the game limits a tick at 4096 ticks (62 ms) and its behaviour callbacks read the UNLIMITED real step (App+0x1B4). engine_hooks.cpp step_guard_before/after: lower kRvaMaxFrameTicks to sim_step_cap_ms (default 33, 0 = off) and clamp App+0x1B4 after every tick (headset only). Logs: SIMSTEP (histogram of steps, clamps, hitch lines with the game stage), GHOSTWATCH (targeted ghost speed, still / jump events with positions).
- Unproven: if ghosts still stick, read GHOSTWATCH still/jump lines and SIMSTEP hitch lines; next suspects: the skipped-simulation second eye, ghosts' physics step size at 72 pairs/s, base-game bug.

## 0.74 (user 23:13 test of 0.73.1: pack not showing on the back, arms stretched and weird, one-handed firing should be more punishing, ghosts still stuck, wants a camera in front of the rig and a red dot at the real head; then: the rope balls up under the player, make the texture black like the game's)
- Hose rebuilt (cordmath.h): the 0.73.1 log showed the ends only 0.44 m apart on average against a fixed 1.2 m cord, 75k torso-capsule contacts and a 54 m/s point: slack piled up. Now rest length = distance + slack (0.30 m close, 0.10 m far; reels in at 0.8 m/s), bend limit (neighbour segments may not fold closer than 95 percent), points 1 and N-2 pinned along exit directions (pack: down/out/forward; wand: back), anchor = the game's hose origin from the BODYREL log (7.5 cm right, 18 cm behind, 56 cm below the eye), torso as an ellipse (0.20 x 0.13 m) 4 cm behind the eye, Catmull-Rom smoothed 8-sided tube (40 rings), black rubber 0.042/0.062 with dark collars. Log CORD2 (length, sag, tightest bend). Max point speed in the unit test 5.6 m/s (was 54 in play).
- Rig view (rigmath.h, handmodel.cpp, armcore.h snapshot_rig/rig_part, arms.cpp): a 40 percent figure of the avatar floats 1.15 m ahead / 0.5 m left of the body yaw, turned to face the player (setting rig_view 0 off, 1 front, 2 right, 3 back, 4 left; menu Rig tab). Joints come from the skeleton after the arms are placed and before arms-only squashes it, expressed in the headset's axes relative to the camera eye (feet / fpm = metres); pack and game hose matrices from body_push; the red dot = the real eye, red line = where the headset looks (1 m, scaled), white boxes = real controllers, blue line = the physics hose. rig_auto_shots (default 1): a diagnostic JPEG (shot.cpp) is saved 6 s after the first fresh snapshot and every 40 s after (max 6); COLLECT_LOGS now takes the newest six gbvr_picture_*.jpg. Logs RIGDATA (joints and parts in cm from the eye, every 25 s, max 40), RIGVIEW (draw counts), RIGSHOT.
- Arms: shoulder slide (armcore.h, ArmTargets.shoulderSlideFt, setting shoulder_slide_cm default 12): after the clavicle swing, if the target is still beyond 97 percent of the arm, the clavicle subtree translates toward it (up to the cap) before the stretch is computed. Defaults: stretch 250 -> 170, shoulder reach 35 -> 45 (settings rev 74 migrates only old defaults). Logs SLIDE (slides, stretch histogram).
- One-handed firing (weightmath.h): omega x(1-0.55 oneFire) (was 0.42), zeta -0.18 (was 0.12), sway +2.4 deg x weight (was 1.3), recoil x4 (was 2.6), max lag x1.8 (was 1.35), trigger snap of about 3 degrees decaying in 0.22 s, position trail cap x2.2 (was 1.5) and slower. Two hands unchanged.
- Stuck ghosts: still unproven. New: setting sim_every_n (1 default; 2 or 3 = the game simulates only every 2nd / 3rd picture via the same short-tick/skip-simulation path as the second eye; menu View tab "Ghost test: game steps"). The 0.73.1 log has the game's health ring unset for the whole session (targetSet=0 of 31143 draws, against 428 in the 0.70 log) while the trigger was held for a third of the time, so the beam never hit a ghost: consistent with unhittable (stuck) ghosts, not proof. Logs SIMEVERY.
- Not testable here: everything in the headset (rig view legibility, cord ends meeting the gun, slide look, firing feel, sim_every_n side effects such as missed button taps).


## 0.75 (user 00:54 test of 0.74: gun good, ghosts still sometimes stuck / not attacking a lot, avatar freaks out near walls and the view crosses, wants the view higher with the head hidden and the body pushed out, gun still not holding to the hand, hose connected to gun and pack and seamless)
- Gun in hand: root cause = hand measured on the moved body, wand in the unmoved game space (about 26 cm). Fixed in armcore.h (origBody, pose_world, gh). Log GRIP.
- View higher / body out: view_up_cm 8, body_out_cm 10 (Rig tab). Log EYEGOAL.
- Hose: seamless one-piece tube with rounded boots (cordmath.h), pack anchor follows the pushed body.
- Walls: not diagnosed. WALL / WALLSUM logs + automatic pictures (wall_diag). Next version: read them.
- Ghosts: unchanged (step cap 33 ms, sim_every_n test switch).
- Gun polish: a soft haptic tick when the off hand lets go.


## 1.7.37
- Base: ChatGPT 1.7.35 source merged with my 1.7.36 (knock-down comfort, always-rumble) re-applied.
- New: gun life bar (gunbarmath.h, handmodel.cpp doGunBar; fraction from actor+0xB860/+0xB868), beam damage locked to 100 on load, VR SETTINGS banner painted on 3840x2880 texture, freer trap throw (Trap armDist/coolS), trap launch-from-hand (fight_trap_launch), CAPWHY diagnostics, 9-page menu with tabs 58/6.
- Test: tests/run_all.sh 57 pass. Untested in game.
- Open: grab lock root cause, 360 menu backdrop, view-model feel.

## 1.7.38
- Grab fix: fight_lock_guard no longer clears the ring-focus lock (player+0x2E8) on a prop while the capture button is down (GRABKEEP log). Rest = 1.7.37.

## 1.7.39
- Boss parts: fight_lock_guard leaves CGolemPartBase (vtable RVA 0x7793E0 / RTTI "CGolem*") alone (log: golem parts left alone). Cause: guard cleared the ring lock on boss parts (273 hits in the 1.7.38 log).
- Sprint: sprint_game (default 1) sets the run bit 0x8000000 at player+0xC7A8 while sprint is toggled on and the stick is pushed (sprint_force in damage.cpp); the 1.7.8 boost is skipped when it is on. Cause: click stripped since 1.7.8 + boost measured no effect.
- Chest camera (chest_cam, default 0; chest_cam_every 4; down 25 / back 18 / near 14 cm): render thread asks for an extra game picture after every N pairs (stereoSpecNext); arm_stereo builds it from the finished pair's state (reused path, pairRole 2, eye 1) with the chest camera view/position (chestmath.h); stereo.cpp copies it to g_specTex, no headset submit, no frame wait, monitor view shows it. Skipped for spec frames: head_aim/fight/trap publishes, draw state, follow loop, HUD overlay.
- Test: tests/run_all.sh 58 pass (new test_chestcam). Untested in game.
- Open: chest camera geometry vs the real model, grab on ghosts, 360 menu backdrop, view-model feel.

## 1.7.40
- Real cause of "boss head not grabbable": fight_wrangled()/g_sl.wrangled (damage.cpp) counted only kEnemies classes as held; the lock sat on CGolemPartBase, so SLAMTRIG refused every squeeze ("holds no ghost", 26-32 times, 0 slams). golem_part_vt() now counts CGolem* parts as held (WRANGLEFIELD: golemHeld). The 1.7.39 lock-guard change was not the cause (GRABKEEP already kept the lock in 1.7.38).
- CAPWHY never printed in 1.7.38: gate used s.pad.lt which the capture bridge never sets; now lt || bindings_capture_down().
