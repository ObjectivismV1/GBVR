// Head aim math (0.32). Pure functions, no Windows dependency, unit-tested in
// tests/test_aim.cpp.
//
// The rendered view of the headset picture is an engine basis (row-major
// float[9], columns right, up, forward, left-handed, y up - see vmath.h). The
// direction the player looks in is its forward column. The game's aim vector
// (iAimDir) is a unit vector in the same world axes.
#pragma once
#include <stdint.h>
#include "vmath.h"

namespace aim {

// Forward column of an engine basis as a unit vector. Returns 0 (out
// untouched) when the basis is not finite or the column is not usable.
inline int forward_from_basis(const float* m, float* out) {
  for (int i = 0; i < 9; ++i) if (!vm::is_finite_f(m[i])) return 0;
  double x = m[2], y = m[5], z = m[8];
  double l2 = x * x + y * y + z * z;
  if (!(l2 > 0.25) || !(l2 < 4.0)) return 0;  // a rotation's column has length 1
  double inv = 1.0 / vm::dsqrt(l2);
  out[0] = (float)(x * inv);
  out[1] = (float)(y * inv);
  out[2] = (float)(z * inv);
  return 1;
}

// Sample not older than maxMs (and not from the future).
inline int is_fresh(int64_t now, int64_t stamp, int64_t freq, int maxMs) {
  if (stamp <= 0 || freq <= 0 || now < stamp) return 0;
  return (double)(now - stamp) * 1000.0 <= (double)maxMs * (double)freq;
}

// Angle between two unit vectors in degrees (for the log only).
inline double angle_deg(const float* a, const float* b) {
  double d = (double)a[0] * b[0] + (double)a[1] * b[1] + (double)a[2] * b[2];
  if (d > 1.0) d = 1.0;
  if (d < -1.0) d = -1.0;
  // acos(d) = atan2(sqrt(1-d^2), d)
  double s = vm::dsqrt(1.0 - d * d);
  return vm::datan2(s, d) * 180.0 / vm::kPi;
}

// The address the game stores the aim vector at, for an actor.
inline uintptr_t aim_field_of(uintptr_t actor, uint32_t offset) { return actor ? actor + offset : 0; }

}  // namespace aim
