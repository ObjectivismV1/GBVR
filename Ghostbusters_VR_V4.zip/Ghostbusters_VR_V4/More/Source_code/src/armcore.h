// 0.57 the arm override, written against a small "game" interface G so that the same code runs in the DLL (arms.cpp, the
// real engine functions) and in tests/test_armcore.cpp (a fake skinned model with the same memory layout).
//
// G must provide:
//   static void ensure(void* model);                          // the engine's EnsureWorld
//   static void local(const void* local, float* out);         // LocalToMatrix (writes the 3x4 part only)
//   static void mul(float* out, const float* a, const float* b);   // Mul34: out = a x b
//   static int  readable(const void* p, size_t n, int write); // memory check
//   static int64_t clock();                                   // 0.66: a cheap time stamp (QueryPerformanceCounter), for the stage timers
//   static void log(const char* fmt, ...);
// Layout of the model instance: layout.h "0.57 skeleton".
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "armmath.h"
#include "layout.h"
#include "modemath.h"
#include "rigmath.h"
#include "calmmath.h"
#include "handprop.h"
#include "pkealignmath.h"

// Targets in game world axes (feet), published by engine_hooks.cpp
struct ArmTargets {
  int64_t stereoPair; int stereoRole; // completed stereo pair identity and first/second eye
  int rightOn;  double wandR[9]; double wandP0[3]; double grip[3];   // right hand: the wand's rigid motion (rotation R about wandP0 -> grip)
  int leftOn;   double lpos[3], lfwd[3], lup[3];                      // left hand: the controller (position, forward, up)
  int hidePke;                // 0.93: squash the game's PKE bones (the probe draws its own PKE)
  int gripAtHand;             // 0.93: the hand goes to the controller and the gun moves by the offset (hand-to-wand) instead of the other way round
  double gunLenFt;   double gripMagnet;   int headOnly;  int noArms;              // 0.81: gun length (feet), how strongly the left hand is drawn to the foregrip (0 = off, 1 = full), PKE mode: only the head is squashed
  double wristBackFt, wristDownFt, elbowDown;
  double gunWristBackFt, gunWristDownFt;   // 1.7.7: the weapon hand's wrist sits this far behind / below the controller point (along the pointing direction / the controller's up), like the left hand; the weapon slides with it
  double gunLiveOpen;                      // 1.7.111: 0 = the gun hand keeps the game's fist whatever the grip does; >0 = letting the grip go opens the grip fingers by up to this share (0..1)
  double pkeEaseS;                      // 1.7.225: the PKE alignment eases in over this many seconds after the grip locks (0 = at once)
  double pkeTurnMaxDeg;                 // 1.7.224: the PKE alignment turns the hand by at most this much to lift/lower the meter (90 or more = as before)
  double pkePitchDeg;                      // 1.7.111: the PKE's long side lies this many degrees above the controller's forward (900 or more = left as the hold has it)
  double trigPullDeg;                      // 1.7.109: how far the gun hand's trigger finger bends in beyond the game's own pose at a full pull (degrees; 0 = the old 55)
  int grabLatOk; double grabLatX, grabLatY;  // 1.7.110: the real hand's sideways place against the barrel line (in the gun's right / up axes, feet), already smoothed by the engine while you walk or turn
  double grabOrbitDeg, grabOrbitFollow;    // 1.7.111: where round the barrel the wrapped hand sits (0 = under, 90 = left side, 180 = on top; the teaser's overhand hold is about 110) and how much your real hand moves it (0..1)
  double grabWrap, grabWrapDeg;            // 1.7.109: the hand that has taken hold of the gun wraps AROUND the barrel (weight 0..1, tilt of the fingers toward the muzzle in degrees); 0 = the older look (fist pointing along the barrel)
  double underW, underFt;                  // 1.7.19: the left hand holds the barrel from UNDER (0..1 blend, how far under the barrel in feet): it slides along the barrel to wherever you grab it
  int gunPosOk; double gunPos[3];          // 1.7.7: where the gun was placed in the last pass (game feet): the left hand's foregrip target is measured from it
  int nativeSupport; // use the current weapon animation's left-to-right hand relation instead of a guessed cylinder grip
  int switchHold;                    // 1.7.226: a weapon change is being held off: the pose kept from before it is not dropped because the item id changed
  int reloadHold, itemId; // keep the pre-reload upper-body pose while controllers/head keep tracking
  // 0.61 full body
  int bodyOn;                 // head / spine / crouch layer
  double headDelta[3];        // where the head must go relative to where the (placed) animation has it, game world feet
  double hmdBasis[9];         // headset orientation in game world (columns right, up, forward)
  double bodyYaw;             // yaw the placed body faces (camera yaw + torso turn)
  double leanMaxDeg, headMaxDeg, dropMaxFt;
  double leftFingerKeep;         // 1.7.103: 0..1 how much ALL the left fingers keep the game's own pose (1 = exactly the animation's; between = a blend from the animation's bend to the soft shape)
  double leftThumbKeep;          // 1.7.23/24: 0..1 how much the left thumb keeps the animation's own pose (the gun hand's thumb always did). 1.7.24: it is 1 on the gun and fades to 0 as the hand leaves it, so a free hand's thumb relaxes with its fingers
  double bendFrac, bendMaxDeg;   // 1.7.21: the upper body bends forward when you look down (fraction of the head pitch past 10 deg, and its limit)
  int crouchOn;
  double stretchMax;          // longest arm stretch factor (1 = no stretch)
  int handClean;              // 1.7.70: 1 = a stretched / sheared hand bone matrix is made clean (same directions, perpendicular, the hand's normal size)
  double armLenBase;          // 1.7.69: the avatar's arms are this much longer along the limb at all times (1 = as modelled), so the elbow bends when your hand is near you
  // 0.68
  int eyeOn;                  // the avatar's eyes are lined up with the camera's eye (eyeTarget)
  double eyeTarget[3];        // the camera's (cyclopean) eye, game world feet
  double shoulderPullDeg;     // 0 = off: the clavicle swings toward a hand target that is farther than the arm reaches
  double crouchDeadFt;        // a head drop smaller than this is a lean, not a crouch (the legs stay straight)
  // 0.69
  int eyeSampleBlock;          // 1.7.181: 1 = the model-eye histogram does not learn now (a forced move, cutscene, firing or walking pose is not the standing eye height)
  double fade;                // 0..1: strength of the eye-matching body shift and head slide (0 while the game moves the character by force: cutscene, knock-back)
  double shiftCapFt;          // the whole body may shift this far (legs stay planted) to put the avatar's eyes at the camera (0 = 1.0 ft)
  double slideCapFt;          // the head may slide this far on top of that (0 = 0.2 ft)
  double calmTauS; double calmDtS; int64_t calmSeq;   // 1.7.29 calm walking: time constant (0 = off), seconds since the previous frame's first pass, a number that changes once per frame
  // 0.71
  double elbowOut;            // 0.72: how far the elbows are pushed away from the body centre (0 = off, 0.5 = default)
  int armsOnly;               // 1 = every bone that is not part of an arm (head, spine, pelvis, legs) is squashed to a point: only the arms are drawn
  int floatingArms;           // temporary fight view: shoulders anchored under the tracked head
  int mirrorArms;             // 1.7.170 left-handed play: each arm hangs from the OTHER shoulder, so the gun arm (the game's right arm, on the left controller) no longer reaches across the body
  float sceneShift[3];        // VR-only suspended viewpoint relative to actor
  int keepShoulders;          // 0.73: with armsOnly, the spine3 subtree (upper chest, shoulders, pack straps) is kept too; only the neck/head, lower back and legs are squashed
  // 0.74
  double shoulderSlideFt;     // 0 = off: after the clavicle swing, the whole shoulder (clavicle and arm) slides up to this far toward a hand that is still out of reach
  double fpm;                 // game feet per metre of the world (the rig view shows real sizes)
  int rigOn;                  // publish the skeleton snapshot for the rig view
  // 0.75
  int origOn; float origBody[16];   // the body's model -> world matrix as the GAME has it, before the probe moved / scaled / turned the body (0 = off: the old hand placement)
  double viewDownFt;          // the avatar's eyes are put this far BELOW the camera's eye (the view sits higher on the body; the head stays hidden)
  double downBackFt;          // 1.7.168: looking down, the body slides this far BACK (and body_out fades out), so the eye is in front of the collar, not above the neck
  double bodyOutFt;           // ... and this far in front of it, along the body's facing: the shoulders are closer to the hands, the arms reach further
  // 0.77
  int rdirOk; double rdir[3], rup[3];   // 0.79: the gun controller's pointing direction and up in game world (a hand that is not on the animation's grip follows it fully)
  double forearmTwist;        // 0 = off: share (0..1) of the hand's turn about the forearm that the forearm takes, so a turned hand turns the whole forearm
  // 0.84
  double gunWrap;             // 1.7: how far the weapon hand's grip fingers stay wrapped around the grip when the controller grip is not squeezed (0..1; the 1.6 pictures showed an open hand with the PKE in front of it)
  int fingersOn;              // the game's own glove fingers curl: curl[hand][finger] 0 = open .. 1 = closed (hand 0 right, 1 left; finger: thumb, index, middle, ring, pinkie)
  double curl[2][5];
  int pkeAttach;              // the PKE meter in hand: the game's PKE bones (cloth_pke) are kept and follow the nearest hand
  // 0.85: the PKE is the game's wand-slot model while it is out: the game's wand matrix (unmoved) and a request to place it relative to the hand the way the game has it
  int pkeWand; float wandM[16];
  // 1.7.76: the weapon hand's turn is tied to the controller: the relation hand <-> controller is captured once (when the PKE hold is steady) and kept, so the hand and the PKE in it turn exactly with the controller
  int handFreeze;
  // 1.7.104: the PKE out: the PKE's long axis (unit, in the hand's own axes) and its centre (feet, in the hand's own axes) from the locked R_PKE hold. With pkeAlign the captured
  // hand <-> controller relation is turned so the PKE's long axis lies in the controller's centre plane (no sideways lean), and the hand is moved sideways so the PKE's centre is on it
  int pkeAlign; int pkeCentre; double pkeVh[3], pkePh[3];
  // 1.7.104: the right hand has nothing in it (the gun is on the back / not drawn): its fingers follow the controller like the left hand's, not the gun-grip rules
  int rightEmpty;
  // 1.7.104: how much the left hand on the foregrip follows the gun's roll instead of the controller's (0 = as before, 0..1)
  double foreSteady;
  // 1.7.105: the left hand has taken hold of the gun (fore grab): it stays on the grip point (no fade with distance), lines up with the barrel
  int grabOn; double grabW;   // grabW 0..1: how firmly the hand has taken hold (eased by the caller: it comes on and goes off smoothly)
};

#ifndef ARMCORE_CRUMB
#define ARMCORE_CRUMB(tag, arg) ((void)0)   // 0.86: arms.cpp turns this into the black-box crumb
#endif
namespace armcore {

enum { MAXB = 256, MAXPATH = 8 };

struct ArmInfo {
  int U, F, H, plen;
  int path[MAXPATH];
  int subN;
  unsigned char inSub[MAXB];
};
struct Cache {
  uintptr_t model, skel;
  int n, ok;
  int parent[MAXB];
  ArmInfo arm[4];   // 0 right arm, 1 left arm, 2 left leg, 3 right leg (0.61)
  int bPelvis, bSpine1, bSpine3, bNeck, bHead, torsoOk;
  unsigned char inSpine[MAXB], inSpine3[MAXB], inNeck[MAXB], inHead[MAXB], inPelvis[MAXB];
  int bEyeL, bEyeR;                    // 0.68 the avatar's eye bones (-1 = not found)
  int clav[2];                         // 0.68 the clavicle above each arm (-1 = none)
  unsigned char inClav[2][MAXB];       // 0.68 the clavicle and everything below it
  int fing[2][5][4];                   // 0.84 finger bones per hand (0 right, 1 left): thumb, index, middle, ring, pinkie; 1..4 (-1 = missing)
  int bPke[2];                         // 0.84 cloth_pke, cloth_pke1 (-1 = missing)
};
struct Stats {
  long stereoSaved, stereoReused;
  int calls, moved[2], noModel, badLayout, badBones, ikFail, nonFinite, noTarget[2], clamped[2], twisted[2];
  int rollShared[2], rollMaxX10[2], rollLastX10[2];
  arm::RollMemory roll[2];   // 1.7.150: the forearm's share fades out near a half turn (no flip, no memory)   // 0.77 forearm roll: calls where the forearm took a share of the hand's turn, biggest / last share (degrees x10)
  int verifyKept, verifyLost, revalidations, spaceFail, badSpace[2], badLen[2]; int mirrored[2], mirrorBad, mirrorElbow[2]; long dispSolved[2], dispFail[2], dispNoTarget[2]; int dispReachX100[2]; arm::RollMemory rollDisp[2];   /* 1.7.174 left-handed: each arm drawn at the other controller */   // 1.7.170 left-handed arms; 1.7.173 elbow side mirrored
  int maxReachX100[2], lastReachX100[2];
  int torsoSkipped, torso, torsoFail, legMoved[2], legFail[2], legClamped[2], stretched[2], stretchMaxX100[2], lastStretchX100[2];
  long handCleaned[2]; double handBase[2]; int handBaseHave[2];   // 1.7.70: hand bone matrices that came out stretched / sheared and were made clean
  int leanMaxX10, headMaxX10, dropMaxX100, lastLeanX10, lastHeadX10, lastDropX100, noLegs, noTorso;
  int lastBendX10, bendMaxX10, bendPasses, bendActive, leftThumbKept;
  int downK100;   // 1.7.168: how far the look-down slide is (0..100)
  int tiltBeforeX10, tiltWantX10, tiltPasses, tiltBendWanted, tiltBendApplied, tiltBeforeMaxX10, tiltBeforeMinX10; long tiltBeforeSumX10;   // 1.7.23: forward tilt of spine1 -> neck before the bend / wanted   // 1.7.21
  float lastS[2][3], lastE[2][3], lastT[2][3], lastL1[2], lastL2[2];
  // 0.66
  int armSkipped[2];                 // arm passes skipped: the matrices were still the ones we wrote and nothing about the target changed (second eye of a pair)
  int demand[2][8];                  // how far the controller was from the shoulder, in arm lengths (unstretched): <80, <100, <130, <170, <220, <300, <400, more (percent)
  float lastMiss[2][3];              // wanted wrist position minus the wrist we could reach (game world feet): the part of the way the arm could not go
  int missOver[2], missMaxX100[2], lastMissX100[2];   // calls with a miss over 0.1 ft, the largest miss, the last one (x100 feet)
  int64_t missClock[2];              // G::clock() of the last arm pass that set lastMiss
  int64_t tEnsure, tTorso, tArms, tTotal; int timed;   // G::clock() ticks per stage, summed over `timed` calls
  // 0.68 eyes lined up with the camera
  float eyeErr[3];                   // camera eye minus the avatar's eye BEFORE the torso pass (game world feet, last)
  float eyeErrBody[3];               // the same minus what the lean is meant to explain, in the body's frame (right, up, forward)
  int eyeN, eyeErrMaxX100, eyeErrSumX100;   // samples, largest |error|, sum of |error| (x100 feet)
  int eyeJumps, eyeJumpMaxX100, eyeJumpSumX100; // 0.98: how much the animation moves the avatar's head between two passes: passes where it moved the error by more than 0.25 ft, the largest such change, sum of all changes (x100 feet)
  float latRawCm, latAppliedCm;   // 1.7.207: pelvis minus eye sideways before the centring, and what was applied (cm)
  float eyeResid[3]; int eyeResidMaxX100, headShifted, headShiftMaxX100, eyeBoneMissing;   // after lean + head turn: what is left, how often the head was slid
  float modelEyeFt;                  // 0.69: the most common eye height of the UNSCALED model above its feet (a histogram peak; 0 = not measured yet)
  int modelEyeN;                     // samples behind modelEyeFt
  float modelEyeShare;               // share of the samples inside the peak (a clean standing pose gives a high share)
  // 0.69 the exact eye match: the whole body shifts (ankles planted), scaled by the fade
  int shifted, shiftCapped, forcedCalls;   // passes that shifted the body, of which hit the cap, passes with the fade under one half
  int shiftMaxX100, fadeX100;              // largest shift (x100 ft), the last fade (x100)
  float shiftLast[3];
  int colPasses, colUndone, colBones, colNoArms, colBadPoint;
  int colShoulders; float spine3Rel[3]; double spine3RelSum[3]; int spine3RelN;   // 0.73 shoulders kept: passes, and the spine3 bone relative to the camera eye (body right, up, forward; feet)
    float wristRel[2][3]; double wristRelSum[2][3]; int wristRelN[2];   // 0.72 data: the wrist relative to the camera eye (body right, up, forward; feet)   // 0.71 arms only
  // 0.70: how the shift splits (sideways whole-body part / up-down part), and the heights above the animation's feet
  int walkN, walkSumX100, walkMaxX100, vertSumX100, vertMaxX100;
  float camAboveFeet, eyeAboveFeet; int feetN; double camAboveFeetSum, eyeAboveFeetSum;
  // 1.7.29 calm walking and the shake meter (second difference of the body's offset from the eye, per frame, feet): [0] standing, [1] moving (the pelvis travels more than 1.5 ft/s)
  long calmFrames, calmSmoothed, calmSnapped, calmOff; double calmLagSumFt, calmLagMaxFt;
  long shakeN[2]; double shakeRawSum[2], shakeRawMax[2], shakeAppSum[2], shakeAppMax[2];
  long dtN, dtOver20, dtOver33; double dtSum, dtMax;
  int pulled[2], pullMaxX10[2], lastPullX10[2];   // shoulder reach: how often the clavicle swung, the largest and the last swing (degrees x10)
  int slid[2], slideMaxX100[2], lastSlideX100[2];  // 0.74 shoulder slide: how often the whole shoulder slid toward the hand, the largest and the last slide (x100 ft)
  int stretchHist[2][6];                           // 0.74 the stretch actually applied: 100, <=115, <=130, <=150, <=200, more (percent)
  int raisedElbow[2];                               // 1.7.35 elbow pole eased outward as a hand goes above its shoulder
  int legExtended[2], legExtendMaxX100[2], legMissMaxX100[2]; // small extension keeps the animated feet planted
  int rigPasses, rigNoBasis;                       // 0.74 rig view snapshots taken / skipped (no eye alignment)
  // 0.75 the gun hand is placed from the game's own untouched pose: where the animation has the hand relative to the wand, in the game's world
  long lUnderN, lUnderClamped, lUnderFar; int lUnderMaxX100; long long lUnderAlongX100, lUnderMoveX100;   // 1.7.19: arm passes with the left hand under the barrel (where along it, how far it was moved)
  int lMagN, lMagMaxX100; long long lMagSumX100, lMagWSumX100;   // 0.81: arm passes where the left hand was drawn to the gun foregrip (distance feet x100, weight x100)
  long lGrabPasses;                                                // 1.7.105: arm passes with the left hand held on the gun by the fore grab
  long leftFingerKept, leftFingerBlend;                           // 1.7.103: passes where the left fingers fully kept / partly kept the game's pose
  double lOrbitPrev; int lOrbitPrevOk, lOrbitShiftX10, lOrbitBend0X10, lOrbitBendX10; long lOrbitN, lOrbitMoved;   // 1.7.220: the forearm-aware orbit of the wrap grip
  long lBendN, lBendClamped, lBendFallback; long long lBendSumX10; int lBendMaxX10, lBendLastX10;   // 1.7.215: wrist bend (hand pointing vs forearm, deg x10) of the wrap-gripped left hand
  double lWrapNow; long lWrapGripPasses; int lWrapTiltX10, lWrapOrbitX10;   // 1.7.109: wrap weight of this pass, passes holding the barrel wrapped, last tilt / orbit angle (deg x10)
  double lMagWNow; int lWrapPasses, gunFingerPasses;               // 1.7.1: weight of the foregrip pull in this pass (0 = none); passes where the left fingers were wrapped on the foregrip; passes with the right hand in the gun-hand finger mode
  int gripFar;                                     // 0.79: arm passes where the game's hand was far from the wand's origin (no weapon in hand): the hand went to the controller instead
  float gripShift[3]; int64_t gripShiftClock;      // 0.93: add this to the wand's position so the gun's handle (not its origin) sits in the real hand (game feet)
  int gripShiftMaxX100; double gripShiftSumX100; int pkeHidePasses;   // 0.93: size of the gun slide (x100 ft), arm passes that squashed the game's PKE bones
  int gripHandN;                                   // 0.93: arm passes that did it
  // 1.7.7 wrist and fist data, [0] = gun (a barrel, gunLenFt > 0), [1] = PKE: the game's hand-minus-weapon offset in the controller's axes (cm: along the aim / up / right), the wrist set-back, the fist centre in the weapon's frame
  long wfN[2]; double wfOffSum[2][3], wfOff[2][3], wfBackSum[2]; double wfLast[2];
  long ffN[2], ffAcrossN[2]; double ffSum[2][3], ffLast[2][3], ffAcrossSum[2], ffAcrossLast[2];
  int gripFixed, gripNoPose;                       // arm passes that used it / could not (no pose, bad matrix)
  float gripOff[3]; int gripOffMinX100, gripOffMaxX100, gripOffN; double gripOffSumX100;   // hand minus wand origin in the game's world (feet): last, |.| min / max / mean
  int gripJumpMaxX100;                             // largest change of that offset between two passes (x100 ft): a steady offset means the wand and the pose agree in time
  int gripOldErrMaxX100; double gripOldErrSumX100; // how far the OLD placement (hand measured on the moved, scaled body) would have been from the new one (x100 ft)
  int gripOldErrOver10;                            // ... passes where that was over 0.1 ft (3 cm)
  int gripCheckN, gripCheckMaxX100;                // pose rebuilt from the local poses compared with the engine's own matrix for the hand (x100 ft; a mismatch means the rebuild is wrong)
  float gripPrev[3]; int gripPrevOk;
  int eyeGoalOn; float eyeGoalOff[3];              // 0.75 view higher / body out: the offset between the camera's eye and where the avatar's eyes are put (feet, world)
  // 0.84 fingers (curled with the trigger / grip) and the PKE glued to the nearest hand
  int fingerAxisFixed[2];   // 1.7.111
  int fingerPasses[2], fingerSkipped[2], fingerFlips[2], fingerMeasured[2], fingerGeometry[2], fingerNoAxis[2], fingerBad[2];
  int fingerBaseX10[2][5];           // last total bend the animation had in each finger (degrees x10, along the curl axis)
  int fingerFinalX10[2][5];          // 1.7.104: the total bend each finger was given in the last pass (degrees x10), what is drawn
  int fingerTgX10[2][5];             // 1.7.104: the curl asked for (0..1000), -1000 = the finger was left to the game
  long fingerSkip[2][5];             // 1.7.104: passes where this finger's pass stopped early (no usable bones / lengths, no bend axis)
  long fingerEmptyPasses;            // 1.7.104: right-hand passes made with the free-finger rules (nothing in the hand)
  int fingerWantX10[2][5];           // last total bend asked for
  int fingerAxisDotX100[2][5];       // last: measured curl axis . geometric curl axis (x100; 100 = they agree, -100 = opposite)
  int fingerMaxDeltaX10[2];          // largest single joint turn applied (degrees x10)
  int pkeCalls, pkeNoBones, pkeNoHand, pkeApplied[2], pkeKept;   // PKE: arm passes that tried it / bones missing / no hand / times glued to the right / left hand / bones kept un-squashed
  float pkeDistFt[2][2];             // last distance of cloth_pke / cloth_pke1 from the right / left hand in the game's own pose (feet)
  float pkeOffLocal[3];              // last offset of cloth_pke from the chosen hand, in the hand bone's axes (feet)
  int pkeHand;                       // last hand chosen (0 right, 1 left, -1 none)
  int pwCalls, pwNoPose, pwOut[2]; float pwDistFt[2]; float pwOff[3];   // 0.85 PKE as the wand-slot model: tries, no game pose, placed on the right / left hand; wand distance from each hand in the game's pose (ft); offset in the hand's axes
  // 0.68 what the torso pass did, for the models drawn on their own (the pack): drop first, then each lean stage about its pivot, 0.69 then the eye shift
  struct Motion { int have; int64_t clock; double drop; double shift[3]; double pv[2][3]; double Q[2][9]; } motion;
};
// last matrices written (to check later in the same render pass that they are still the ones in the cache)
struct Written { const float* world; int U, H; float u[16], h[16]; int have; };

inline int name_eq(const char* a, const char* b) {
  for (;;) {
    char x = *a, y = *b;
    if (x >= 'A' && x <= 'Z') x = (char)(x + 32);
    if (y >= 'A' && y <= 'Z') y = (char)(y + 32);
    if (x != y) return 0;
    if (!x) return 1;
    ++a; ++b;
  }
}
inline void bone_name(const uint8_t* skel, int i, char* out /* 0x19 */) {
  const char* p = (const char*)(skel + 0x8c + (size_t)i * 0x4c);
  int k = 0;
  for (; k < 0x18 && p[k]; ++k) out[k] = (p[k] >= 32 && p[k] < 127) ? p[k] : '?';
  out[k] = 0;
}
inline int find_bone(const uint8_t* skel, int n, const char* want) {
  char nm[0x19];
  for (int i = 0; i < n; ++i) {
    bone_name(skel, i, nm);
    if (name_eq(nm, want)) return i;
  }
  return -1;
}
// 0.84: bone_R_index2 and so on (side 0 right, 1 left; finger 0..4 = thumb, index, middle, ring, pinkie; joint 1..4)
inline int find_finger(const uint8_t* skel, int n, int side, int f, int joint) {
  static const char* const kF[5] = {"thumb", "index", "middle", "ring", "pinkie"};
  char buf[40];
  int k = 0;
  const char* pre = side ? "bone_L_" : "bone_R_";
  for (; pre[k]; ++k) buf[k] = pre[k];
  for (const char* q = kF[f]; *q; ++q) buf[k++] = *q;
  buf[k++] = (char)('0' + joint);
  buf[k] = 0;
  return find_bone(skel, n, buf);
}
inline int finite16(const float* m) {
  for (int i = 0; i < 16; ++i) if (!vm::is_finite_f(m[i]) || m[i] > 1e6f || m[i] < -1e6f) return 0;
  return 1;
}
inline void copy12(float* dst, const float* src) {   // the 3x4 part; the fourth column is not ours to give
  for (int r = 0; r < 4; ++r) for (int c = 0; c < 3; ++c) dst[r * 4 + c] = src[r * 4 + c];
}

template <class G>
struct Core {
  static inline struct StereoCache {
    int64_t pair; uintptr_t actor, skel, local, world; int n, result;
    float W[16], bones[MAXB][16];
  } stereoCache;
  static constexpr double wrist_limit_rad = 55.0 * 3.14159265358979323846 / 180.0;   // 1.7.215: the most the wrap-gripped left wrist bends (a real wrist bends about 70 deg)
  static inline Cache c;
  static inline Stats st;
  static inline Written w[2];
  struct ArmOut { const float* world; float u[16], h[16]; double sig[128]; int sigN; int have; };
  static inline ArmOut ao[2];            // 0.66 arm guard: what the last arm pass wrote and the inputs it came from
  // 0.71 arms only: what the squashed bones held before (the engine does not always rebuild the pose between calls, so it is put back first)
  static inline struct Col { const float* world; int n, have, ref; float Z[16]; float saved[MAXB][16]; unsigned char was[MAXB]; } col;
  static inline const float* tpWorld;   // 0.61 torso guard: the world cache and head/pelvis/spine matrices we wrote last time
  static inline float tpHead[16], tpPelvis[16], tpSpine[16];
  static inline calm::Filter calmF; static inline int64_t calmLastSeq = -1; static inline double calmHistRaw[3][3], calmHistApp[3][3], calmPrevP[3]; static inline int calmHistN, calmHaveP;   // 1.7.29
  static inline double tpSig[23];
  static inline int tpHave;
  static inline rig::Snap rs;            // 0.74 the rig view: joints relative to the camera eye, in the headset's axes (feet)
  static inline volatile long rsSeq;     // odd while rs is being written
  static inline modem::Hist eyeHist;     // 0.69: the unscaled model's eye height above its feet, most common value
  static inline int eyeHistInit;
  // 1.7.58: exact full game-hand -> VR-hand pair for the right hand.  The gun/PKE hooks use this
  // pair to preserve the GAME'S complete hand-to-prop transform.  This replaces the old guessed / learned
  // translation-only grip fit.  Matrices are game-world affine 3x4s in the game's row-vector convention.
  static inline float handGameW[16], handFinalW[16];
  static inline uintptr_t handActor;
  static inline int64_t handClock;
  static inline int handHave;
  // 1.7.76: the right hand's world axes = the controller's frame x a fixed relation K (captured from the hand as the old rules had it, at the first steady pass); data for the log
  static inline struct { int have; uintptr_t actor; double K[9]; long applied, captured, noFrame; double maxDevDeg, lastDevDeg, sumDevDeg;
    double latFt, fwdShiftFt, upShiftFt; long alignN, alignFail; pkealign::Result al; double rampT; long rampSeq; } frz;   // 1.7.104: latFt = the sideways move the hand makes (feet); al = the last alignment
  static void frz_reset() { frz.have = 0; frz.actor = 0; frz.rampT = 0.0; frz.rampSeq = -1; }

  static int hand_pair_read(uintptr_t actor, float* gameHand, float* finalHand, int64_t* clock) {
    if (!handHave || !handClock || !actor || handActor != actor) return 0;
    for (int i = 0; i < 16; ++i) { gameHand[i] = handGameW[i]; finalHand[i] = handFinalW[i]; }
    if (clock) *clock = handClock;
    return finite16(gameHand) && finite16(finalHand);
  }

  // Rebuild the cache for this model instance: bone count, parents, the two arm chains and what hangs below them.
  static int revalidate(const uint8_t* M, const uint8_t* skel, int n, const uint8_t* actor) {
    ++st.revalidations;
    eyeHist.init(3.5, 8.0); eyeHistInit = 1; st.modelEyeFt = 0; st.modelEyeN = 0; st.modelEyeShare = 0;   // 0.69: a new model instance: measure its eye height again
    c.model = (uintptr_t)M; c.skel = (uintptr_t)skel; c.n = n; c.ok = 0;
    for (int i = 0; i < n; ++i) {
      int p = *(const int*)(skel + 0x8c + (size_t)i * 0x4c + 0x1c);
      if (p < -1 || p >= i) { G::log("ARMS skeleton %p: bone %d has parent %d (not before it): arms left alone", (const void*)skel, i, p); return 0; }
      c.parent[i] = p;
    }
    static const char* const kU[4] = {"bone_R_upperArm", "bone_L_upperArm", "bone_L_thigh", "bone_R_thigh"};
    static const char* const kH[4] = {"bone_R_hand", "bone_L_hand", "bone_L_ankle", "bone_R_ankle"};
    static const char* const kLbl[4] = {"right arm", "left arm", "left leg", "right leg"};
    const int* idx = (const int*)(actor + layout::kOffActorBoneIdx);
    const int actorIdx[2][2] = {{idx[2], idx[4]}, {idx[3], idx[5]}};
    int any = 0;
    for (int s = 0; s < 4; ++s) {
      ArmInfo& a = c.arm[s];
      a.U = find_bone(skel, n, kU[s]); a.H = find_bone(skel, n, kH[s]); a.F = -1; a.plen = 0; a.subN = 0;
      for (int i = 0; i < MAXB; ++i) a.inSub[i] = 0;
      if (a.U < 0 || a.H < 0) { G::log("ARMS %s: bone %s / %s not found in the skeleton", kLbl[s], kU[s], kH[s]); a.U = -1; continue; }
      if (s < 2 && (a.U != actorIdx[s][0] || a.H != actorIdx[s][1]))
        G::log("ARMS %s: skeleton search found upper arm %d hand %d, the actor's own indices are %d / %d", kLbl[s], a.U, a.H, actorIdx[s][0], actorIdx[s][1]);
      int rev[MAXPATH], rn = 0, j = a.H;
      while (j >= 0 && rn < MAXPATH) { rev[rn++] = j; if (j == a.U) break; j = c.parent[j]; }
      if (rn < 3 || rev[rn - 1] != a.U) { G::log("ARMS %s: end bone %d is not below start bone %d within %d bones: left alone", kLbl[s], a.H, a.U, (int)MAXPATH); a.U = -1; continue; }
      a.plen = rn;
      for (int k = 0; k < rn; ++k) a.path[k] = rev[rn - 1 - k];
      a.F = a.path[1];
      for (int i = 0; i < n; ++i) {
        a.inSub[i] = (unsigned char)(i == a.U || (c.parent[i] >= 0 && a.inSub[c.parent[i]]));
        a.subN += a.inSub[i];
      }
      if (a.subN > 120) { G::log("ARMS %s: %d bones below the start bone (more than 120): left alone", kLbl[s], a.subN); a.U = -1; continue; }
      char nu[0x19], nf[0x19], nh[0x19];
      bone_name(skel, a.U, nu); bone_name(skel, a.F, nf); bone_name(skel, a.H, nh);
      G::log("ARMS %s found: start %d \"%s\" -> middle %d \"%s\" ... end %d \"%s\" (%d bones in the chain, %d below the start)",
             kLbl[s], a.U, nu, a.F, nf, a.H, nh, a.plen, a.subN);
      if (s < 2) ++any;
    }
    // 0.68 the clavicle above each arm (its parent, when it is called ...clav...) with everything below it, and the eye bones
    for (int s = 0; s < 2; ++s) {
      c.clav[s] = -1;
      for (int i = 0; i < MAXB; ++i) c.inClav[s][i] = 0;
      if (c.arm[s].U < 0) continue;
      const int p = c.parent[c.arm[s].U];
      if (p < 0) continue;
      char nm[0x19];
      bone_name(skel, p, nm);
      int hit = 0;
      for (int k = 0; nm[k] && nm[k + 1] && nm[k + 2] && nm[k + 3]; ++k)
        if ((nm[k] | 32) == 'c' && (nm[k + 1] | 32) == 'l' && (nm[k + 2] | 32) == 'a' && (nm[k + 3] | 32) == 'v') hit = 1;
      if (!hit) continue;
      c.clav[s] = p;
      for (int i = 0; i < n; ++i) c.inClav[s][i] = (unsigned char)(i == p || (c.parent[i] >= 0 && c.inClav[s][c.parent[i]]));
      G::log("ARMS %s shoulder bone %d \"%s\" found (shoulder reach can swing it)", s ? "left" : "right", p, nm);
    }
    {   // 0.84 the glove fingers (each chain must hang from the hand bone) and the PKE meter's bones
      int found = 0;
      for (int s = 0; s < 2; ++s) for (int f = 0; f < 5; ++f) {
        for (int j = 0; j < 4; ++j) c.fing[s][f][j] = find_finger(skel, n, s, f, j + 1);
        if (c.arm[s].U < 0 || c.fing[s][f][0] < 0 || c.parent[c.fing[s][f][0]] != c.arm[s].H) c.fing[s][f][0] = -1;
        for (int j = 1; j < 4; ++j) if (c.fing[s][f][j] < 0 || c.parent[c.fing[s][f][j]] != c.fing[s][f][j - 1]) c.fing[s][f][0] = -1;
        if (c.fing[s][f][0] >= 0) ++found;
      }
      c.bPke[0] = find_bone(skel, n, "cloth_pke"); c.bPke[1] = find_bone(skel, n, "cloth_pke1");
      G::log("FINGERS bones found: %d of 10 chains (right hand %d, left hand %d); PKE bones cloth_pke=%d cloth_pke1=%d", found,
             (c.fing[0][0][0] >= 0) + (c.fing[0][1][0] >= 0) + (c.fing[0][2][0] >= 0) + (c.fing[0][3][0] >= 0) + (c.fing[0][4][0] >= 0),
             (c.fing[1][0][0] >= 0) + (c.fing[1][1][0] >= 0) + (c.fing[1][2][0] >= 0) + (c.fing[1][3][0] >= 0) + (c.fing[1][4][0] >= 0), c.bPke[0], c.bPke[1]);
    }
    c.bEyeL = find_bone(skel, n, "bone_L_eye"); c.bEyeR = find_bone(skel, n, "bone_R_eye");
    G::log("BODYCHAIN eye bones: left %d right %d (%s)", c.bEyeL, c.bEyeR, (c.bEyeL >= 0 && c.bEyeR >= 0) ? "the avatar's eyes can be lined up with the camera" : "not found: the old head placement is used");
    c.bPelvis = find_bone(skel, n, "bone_pelvis"); c.bSpine1 = find_bone(skel, n, "bone_spine1"); c.bSpine3 = find_bone(skel, n, "bone_spine3");
    c.bNeck = find_bone(skel, n, "bone_neck"); c.bHead = find_bone(skel, n, "bone_head");
    c.torsoOk = c.bPelvis >= 0 && c.bSpine1 >= 0 && c.bSpine3 >= 0 && c.bNeck >= 0 && c.bHead >= 0;
    if (c.torsoOk) {
      const int roots[5] = {c.bPelvis, c.bSpine1, c.bNeck, c.bHead, c.bSpine3};
      unsigned char* masks[5] = {c.inPelvis, c.inSpine, c.inNeck, c.inHead, c.inSpine3};
      for (int m = 0; m < 5; ++m) for (int i = 0; i < n; ++i) masks[m][i] = (unsigned char)(i == roots[m] || (c.parent[i] >= 0 && masks[m][c.parent[i]]));
      G::log("BODYCHAIN torso bones: pelvis %d spine1 %d spine3 %d neck %d head %d; legs left %s right %s (head/spine/crouch layer ready)", c.bPelvis, c.bSpine1, c.bSpine3, c.bNeck, c.bHead,
             c.arm[2].U >= 0 ? "ok" : "MISSING", c.arm[3].U >= 0 ? "ok" : "MISSING");
    } else G::log("BODYCHAIN torso bones missing (pelvis %d spine1 %d spine3 %d neck %d head %d): head/spine/crouch layer off", c.bPelvis, c.bSpine1, c.bSpine3, c.bNeck, c.bHead);
    static int dumps;
    if (dumps < 2) {   // data for later: the whole skeleton once (names and parents)
      ++dumps;
      G::log("SKELETON model=%p skeleton=%p bones=%d (index parent name)", (const void*)M, (const void*)skel, n);
      for (int i = 0; i < n; ++i) {
        char nm[0x19];
        bone_name(skel, i, nm);
        G::log("SKELBONE %d %d %s", i, c.parent[i], nm);
      }
    }
    c.ok = any;
    return any;
  }

  static void chain_world(const uint8_t* local, const float* world, const ArmInfo& a, float Wc[MAXPATH][16]) {
    alignas(16) float tmp[16];
    for (int k = 0; k < a.plen; ++k) {
      for (int i = 0; i < 16; ++i) tmp[i] = 0;
      G::local(local + (size_t)40 * a.path[k], tmp);
      const float* par = nullptr;
      if (k == 0) { int p = c.parent[a.U]; if (p >= 0) par = world + (size_t)16 * p; }
      else par = Wc[k - 1];
      if (par) { for (int i = 0; i < 16; ++i) Wc[k][i] = 0; G::mul(Wc[k], tmp, par); }
      else for (int i = 0; i < 16; ++i) Wc[k][i] = tmp[i];
    }
  }

  // ---- 0.61 helpers -------------------------------------------------------------------------------------------------
  static void write_chain(float* world, const uint8_t* local, int n, const ArmInfo& a, const float* Un, const float* Fn, const float* Hn) {
    alignas(16) float tmp[16];
    for (int j = 0; j < n; ++j) {
      if (!a.inSub[j]) continue;
      float* dst = world + (size_t)16 * j;
      if (j == a.U) copy12(dst, Un);
      else if (j == a.F) copy12(dst, Fn);
      else {
        for (int i = 0; i < 16; ++i) tmp[i] = 0;
        G::local(local + (size_t)40 * j, tmp);
        G::mul(dst, tmp, world + (size_t)16 * c.parent[j]);
      }
      if (j == a.path[a.plen - 1]) copy12(dst, Hn);
    }
  }
  // every bone below (and including) the masked root: moved by delta (world), after being turned by Q about pivot (world)
  static void sub_rotate(float* world, int n, const unsigned char* mask, const arm::Space& sp, const double* pivot, const double* Q) {
    for (int j = 0; j < n; ++j) {
      if (!mask[j]) continue;
      float* B = world + (size_t)16 * j;
      double p[3], r[3], rr[3], np[3];
      sp.point_world(B + 12, p);
      arm::sub(p, pivot, r);
      arm::apply3(Q, r, rr);
      for (int i = 0; i < 3; ++i) np[i] = pivot[i] + rr[i];
      float out[16];
      sp.place(B, Q, np, out);
      if (finite16(out)) copy12(B, out);
    }
  }
  static void sub_shift(float* world, int n, const unsigned char* mask, const arm::Space& sp, const double* delta) {
    double dm[3];
    sp.dir_model(delta, dm);
    for (int j = 0; j < n; ++j) {
      if (!mask[j]) continue;
      float* B = world + (size_t)16 * j;
      B[12] += (float)dm[0]; B[13] += (float)dm[1]; B[14] += (float)dm[2];
    }
  }
  // 0.68: one bone's matrix from its own local pose and its parent's current matrix (undoes an earlier shoulder swing, whatever the engine did)
  static void rebuild_bone(float* world, const uint8_t* local, int b) {
    if (c.parent[b] < 0) return;
    alignas(16) float tmp[16];
    for (int i = 0; i < 16; ++i) tmp[i] = 0;
    G::local(local + (size_t)40 * b, tmp);
    G::mul(world + (size_t)16 * b, tmp, world + (size_t)16 * c.parent[b]);
  }
  // 1.7.181 MIRRORED HANDS (left-handed play). A hand's bone matrix is turned into a rig-independent "knuckle frame" G (x: wrist -> the middle of the index and little finger
  // knuckles, y: index -> little finger knuckle made square to x, z = x cross y). The bone's own axes are fixed in that frame (B = G^T F, the same in every pose of one rig, so it
  // absorbs however the rig turns / flips its left and right hand bones). The mirror image of a hand is G reflected in the plane (x, y reflected, z recomputed) put back through the
  // OTHER hand's B. Nothing is assumed about the rig: only that the left glove is the mirror image of the right one.
  static void frame_raw(const arm::Space& sp, const float* B, double* M) {   // like frame_world, but the three axes are only normalised (a flipped bone stays flipped)
    for (int r = 0; r < 3; ++r) {
      double m[3] = {B[r * 4], B[r * 4 + 1], B[r * 4 + 2]}, w3[3];
      sp.dir_world(m, w3);
      if (!arm::unit(w3, w3)) { w3[0] = r == 0; w3[1] = r == 1; w3[2] = r == 2; }
      for (int k = 0; k < 3; ++k) M[k * 3 + r] = w3[k];
    }
  }
  static int knuckle_frame(const uint8_t* local, const arm::Space& sp, int s, double* Kf, double* Bn) {   // Bn = G^T F in the animation's own pose of hand s
    const int H = c.arm[s].U >= 0 ? c.arm[s].H : -1, fi = c.fing[s][1][0], fp = c.fing[s][4][0];
    if (H < 0 || fi < 0 || fp < 0) return 0;
    float Ph[16], Pi[16], Pp[16];
    if (!pose_world(local, H, Ph) || !pose_world(local, fi, Pi) || !pose_world(local, fp, Pp)) return 0;
    double h[3], i3[3], p3[3], x[3], y[3], z[3];
    sp.point_world(Ph + 12, h); sp.point_world(Pi + 12, i3); sp.point_world(Pp + 12, p3);
    for (int k = 0; k < 3; ++k) x[k] = 0.5 * (i3[k] + p3[k]) - h[k];
    arm::sub(i3, p3, y);
    if (!(arm::len(x) > 0.3 * arm::len(y))) return 0;   // the first finger bones are not out at the knuckles: no usable frame (the old look stays)
    if (!arm::unit(x, x)) return 0;
    const double d = arm::dot(y, x);
    for (int k = 0; k < 3; ++k) y[k] -= d * x[k];
    if (!arm::unit(y, y)) return 0;
    arm::cross(x, y, z);
    double F[9], Gt[9];
    for (int k = 0; k < 3; ++k) { Kf[k * 3] = x[k]; Kf[k * 3 + 1] = y[k]; Kf[k * 3 + 2] = z[k]; }
    frame_raw(sp, Ph, F);
    weight::transpose3(Kf, Gt); weight::mul3(Gt, F, Bn);
    return 1;
  }
  // Ff = hand `from`'s desired bone frame (columns, world); n = the mirror plane's unit normal (world). Fo = the bone frame hand 1-from needs to be the mirror image. 0 = not possible.
  static int mirror_hand_frame(const uint8_t* local, const arm::Space& sp, int from, const double* Ff, const double* n, double* Fo) {
    double Gf[9], Bf[9], Gt[9], Bt[9], Bft[9], Gm[9];
    if (!knuckle_frame(local, sp, from, Gf, Bf) || !knuckle_frame(local, sp, 1 - from, Gt, Bt)) return 0;
    weight::transpose3(Bf, Bft); weight::mul3(Ff, Bft, Gm);   // the knuckle frame the hand has as it is placed
    for (int col = 0; col < 2; ++col) {
      double v[3] = {Gm[col], Gm[3 + col], Gm[6 + col]};
      const double k = 2.0 * arm::dot(v, n);
      for (int i = 0; i < 3; ++i) Gm[i * 3 + col] = v[i] - k * n[i];
    }
    double x[3] = {Gm[0], Gm[3], Gm[6]}, y[3] = {Gm[1], Gm[4], Gm[7]}, z[3];
    arm::cross(x, y, z);
    for (int i = 0; i < 3; ++i) Gm[i * 3 + 2] = z[i];
    weight::mul3(Gm, Bt, Fo);
    for (int i = 0; i < 9; ++i) if (!vm::is_finite_f((float)Fo[i])) return 0;
    return 1;
  }
  static void reflect_point(const double* P, const double* P0, const double* n, double* o) {   // the mirror image of point P in the plane through P0 with unit normal n
    double d[3] = {P[0] - P0[0], P[1] - P0[1], P[2] - P0[2]};
    const double k = 2.0 * arm::dot(d, n);
    for (int i = 0; i < 3; ++i) o[i] = P[i] - k * n[i];
  }
  static void reflect_dir(const double* v, const double* n, double* o) { const double k = 2.0 * arm::dot(v, n); for (int i = 0; i < 3; ++i) o[i] = v[i] - k * n[i]; }
  // 1.7.174 LEFT-HANDED, drawn properly. "It is just switching the gun and hose without any change to the hand position": the game only has a right-hand
  // gun hold, so until now its RIGHT arm reached to your left controller. The gun, the hose and the PKE are placed through that right hand, so that
  // solve stays exactly as it is (it is the hold the gun is drawn from). What is DRAWN changes: after the normal solve each arm is solved once more to
  // the other arm's target - your real left hand gets the body's left arm and left hand (turned by its own controller, as the left hand always is, with
  // the fingers closed on the handle), your real right hand gets the right arm. Nothing else reads the drawn arm bones.
  static inline struct Disp { double T[2][3], f[2][3], u[2][3]; int ok[2]; double F[2][9], wF[2]; int okF[2]; } disp;   // what the normal solve of arm s aimed at: wrist, pointing direction, up; 1.7.181: F = the whole hand frame (columns = the bone's axes in world) the drawn hand takes, wF = how much of it (0..1)
  static inline double gunBend[5][3]; static inline int gunBendOk[5], mirrorBendOn;   // 1.7.181: the joint bends the gun hand's fingers ended with this pass (the left hand that is drawn on the gun takes the same ones)
  static inline int curlSup = 1;   // 1.7.181: which hand MESH (0 right, 1 left) the barrel-wrap finger shape (grab_wrap) is for: 1 normally, 0 while the right hand is drawn as the supporting hand in left-handed play
  static int display_arm(float* world, const uint8_t* local, int n, const arm::Space& sp, const ArmTargets* t, int s, const double* T, const double* f, const double* u, const double* Fd = nullptr, double wFd = 0.0) {
    const ArmInfo& a = c.arm[s];
    if (a.U < 0 || a.plen < 2) return 0;
    if (!t->floatingArms && c.clav[s] >= 0) rebuild_bone(world, local, c.clav[s]);   // the shoulder as the animation has it (the normal solve may have swung it toward the other hand)
    alignas(16) float Wc[MAXPATH][16];
    for (int j = 0; j < MAXPATH; ++j) for (int i = 0; i < 16; ++i) Wc[j][i] = 0;
    chain_world(local, world, a, Wc);
    double S[3], E0[3], Hp[3];
    sp.point_world(Wc[0] + 12, S); sp.point_world(Wc[1] + 12, E0); sp.point_world(Wc[a.plen - 1] + 12, Hp);
    double eu[3] = {E0[0] - S[0], E0[1] - S[1], E0[2] - S[2]}, ef[3] = {Hp[0] - E0[0], Hp[1] - E0[1], Hp[2] - E0[2]};
    const double Lsum = arm::len(eu) + arm::len(ef);
    if (!(Lsum > 0.05 && Lsum < 30.0)) return 0;
    double tv[3] = {T[0] - S[0], T[1] - S[1], T[2] - S[2]};
    const double dT = arm::len(tv);
    const double base = t->armLenBase > 1.0 ? (t->armLenBase > 1.6 ? 1.6 : t->armLenBase) : 1.0;
    double sc = base;
    if (t->stretchMax > 1.0 && dT > 0.97 * Lsum * base) { sc = dT / (0.97 * Lsum); const double cap = t->stretchMax > base ? t->stretchMax : base; if (sc > cap) sc = cap; }
    double E0s[3], Hps[3];
    for (int i = 0; i < 3; ++i) { E0s[i] = S[i] + eu[i] * sc; Hps[i] = E0s[i] + ef[i] * sc; }
    double outward[3] = {0, 0, 0}; int haveOut = 0;
    if (t->floatingArms && t->elbowOut > 0.01) {
      double sy, cy; vm::dsincos(t->bodyYaw, &sy, &cy);
      const double sign = s == 0 ? 1.0 : -1.0;
      outward[0] = sign * cy * t->elbowOut; outward[2] = -sign * sy * t->elbowOut; haveOut = 1;
    } else if (t->elbowOut > 0.01 && c.arm[1 - s].U >= 0) {
      double So[3], lat[3];
      if (!fresh_shoulder(world, local, 1 - s, sp, So)) sp.point_world(world + (size_t)16 * c.arm[1 - s].U + 12, So);
      lat[0] = S[0] - So[0]; lat[1] = 0.0; lat[2] = S[2] - So[2];
      if (arm::unit(lat, lat)) { for (int i = 0; i < 3; ++i) outward[i] = lat[i] * t->elbowOut; haveOut = 1; }
    }
    const double elbowDown = arm::raised_elbow_down(S, T, Lsum * sc, t->elbowDown);
    arm::Ik k;
    if (!arm::solve(S, E0s, Hps, T, elbowDown, &k, haveOut ? outward : nullptr)) return 0;
    float Un[16], Fn[16], Hn[16];
    double QF[9], Qh[9];
    weight::ident(Qh);
    sp.place(Wc[0], k.QU, S, Un);
    for (int i = 0; i < 3; ++i) Un[12 + i] = Wc[0][12 + i];
    weight::mul3(k.Q2, k.QU, QF);
    sp.place(Wc[1], QF, k.E, Fn);
    { double fa[3], fu[3]; arm::sub(Hp, E0, fa); if (arm::unit(fa, fu)) hand_from_controller(fu, f, u, Qh); }
    if (Fd && wFd > 0.001) {   // 1.7.181: the hand takes the mirror image of the hand that holds the gun (or of the hand the game puts on the barrel), not the animation's roll plus the controller's
      double Fc[9], FcT[9], Qm[9], Ql[9], dl[9], part[9];
      frame_raw(sp, Wc[a.plen - 1], Fc); weight::transpose3(Fc, FcT); weight::mul3(Fd, FcT, Qm);
      const double det = Qm[0] * (Qm[4] * Qm[8] - Qm[5] * Qm[7]) - Qm[1] * (Qm[3] * Qm[8] - Qm[5] * Qm[6]) + Qm[2] * (Qm[3] * Qm[7] - Qm[4] * Qm[6]);
      if (det > 0.98 && det < 1.02) {   // a pure turn (otherwise leave the old look)
        weight::transpose3(Qh, Ql); weight::mul3(Qm, Ql, dl);
        static int mlog; const double dev = weight::angle_between(Qh, Qm);
        if (++mlog <= 8 || mlog % 900 == 0) G::log("MIRRORHAND arm %d: the mirrored hand differs from the animation-roll hand by %.1f deg (weight %.2f)", s, dev, wFd);
        arm::rot_part(dl, wFd > 1.0 ? 1.0 : wFd, vm::kPi, part); weight::mul3(part, Qh, Qh);
      }
    }
    sp.place(Wc[a.plen - 1], Qh, k.T, Hn);
    if (t->forearmTwist > 0.01) {
      double a1[3] = {k.T[0] - k.E[0], k.T[1] - k.E[1], k.T[2] - k.E[2]}, Qt[9], QF2[9];
      if (arm::unit(a1, a1)) {
        const double g = arm::forearm_roll_cont(Qh, QF, a1, t->forearmTwist, &st.rollDisp[s], 100.0 * vm::kPi / 180.0, Qt);
        if (vm::dabs(g) > 0.01) { weight::mul3(Qt, QF, QF2); sp.place(Wc[1], QF2, k.E, Fn); }
      }
    }
    if (sc > 1.0001) {
      const int ru = along_row(Wc[0], sp, eu), rf = along_row(Wc[1], sp, ef);
      for (int cc = 0; cc < 3; ++cc) { Un[ru * 4 + cc] = (float)(Un[ru * 4 + cc] * sc); Fn[rf * 4 + cc] = (float)(Fn[rf * 4 + cc] * sc); }
    }
    if (!finite16(Un) || !finite16(Fn) || !finite16(Hn)) return 0;
    write_chain(world, local, n, a, Un, Fn, Hn);
    if (t->fingersOn) {
      ArmTargets fg = *t;
      fg.grabWrap = s == 0 ? t->grabWrap : 0.0; fg.gunWrap = 0.0; fg.leftFingerKeep = 0.0; fg.leftThumbKeep = 0.0;   // 1.7.181: the right hand drawn on the barrel wraps it like the left hand does in right-handed play
      if (s == 1) {   // the left hand is on the gun's handle: closed on it, the index finger with the trigger
        const double trig = t->curl[0][1] >= 0.0 ? t->curl[0][1] : 0.5;
        fg.curl[1][0] = 0.55; fg.curl[1][1] = trig < 0.35 ? 0.35 : trig; fg.curl[1][2] = fg.curl[1][3] = fg.curl[1][4] = 0.85;
      } else for (int fi = 0; fi < 5; ++fi) fg.curl[0][fi] = t->curl[1][fi];   // the right hand is the free hand: it takes the free controller's fingers
      const double keepMag = st.lMagWNow; st.lMagWNow = 0.0;
      curlSup = s == 0 ? 0 : 1; mirrorBendOn = s == 1;
      curl_hand(world, n, s, sp, &fg, 0);
      curlSup = 1; mirrorBendOn = 0;
      st.lMagWNow = keepMag;
    }
    st.dispReachX100[s] = (int)(k.reach * 100.0);
    // the next call of the same stereo pair finds these matrices and leaves the arm alone (the arm guard), and the pose check knows them as ours
    copy12(ao[s].u, world + (size_t)16 * a.U); copy12(ao[s].h, world + (size_t)16 * a.H);
    w[s].world = world; w[s].U = a.U; w[s].H = a.H; copy12(w[s].u, Un); copy12(w[s].h, Hn); w[s].have = 1;
    return 1;
  }
  // 1.7.172: where arm s's shoulder is as the animation has it NOW, worked out from the local poses and the clavicle's parent - never from the
  // clavicle / upper arm matrices themselves, which may already be ours (moved to the other side by an earlier pass of the same stereo pair).
  static int fresh_shoulder(const float* world, const uint8_t* local, int s, const arm::Space& sp, double* out) {
    const int cl = c.clav[s], U = c.arm[s].U;
    if (cl < 0 || U < 0 || c.parent[U] != cl || c.parent[cl] < 0) return 0;
    alignas(16) float lc[16], lu[16], cw[16], uw[16];
    for (int i = 0; i < 16; ++i) lc[i] = lu[i] = cw[i] = uw[i] = 0;
    G::local(local + (size_t)40 * cl, lc);
    G::mul(cw, lc, world + (size_t)16 * c.parent[cl]);
    G::local(local + (size_t)40 * U, lu);
    G::mul(uw, lu, cw);
    for (int i = 12; i < 15; ++i) if (!vm::is_finite_f(uw[i])) return 0;
    sp.point_world(uw + 12, out);
    return 1;
  }
  // 0.75: one bone's model-space matrix straight from the animation's local poses, root first. Nothing the probe wrote can be in it (only `world`
  // is ever written; `local` is the animation's own output), so it is the game's own pose whatever was done to the bones before.
  // 0.79 a hand that follows a controller completely: the forearm direction fu is swung onto the controller's pointing direction f, then the hand
  // rolls about f exactly as far as the controller rolled (angle between the level up and the controller's up). Replaces the swing alone (no roll).
  static void hand_from_controller(const double* fu, const double* f, const double* u, double* Q) {
    double Qs[9];
    arm::swing(fu, f, Qs);
    for (int i = 0; i < 9; ++i) Q[i] = Qs[i];
    double ur[3] = {0.0, 1.0, 0.0}, up[3];
    const double fy = f[1];
    const double a = fy < 0 ? -fy : fy;
    if (a > 0.995) return;                      // pointing straight up or down: no roll reference
    const double k = arm::dot(ur, f);
    for (int i = 0; i < 3; ++i) ur[i] -= k * f[i];
    const double ku = arm::dot(u, f);
    for (int i = 0; i < 3; ++i) up[i] = u[i] - ku * f[i];
    if (!arm::unit(ur, ur) || !arm::unit(up, up)) return;
    double cr[3];
    arm::cross(ur, up, cr);
    double ang = vm::datan2(arm::dot(cr, f), arm::dot(ur, up));
    double w = (0.985 - a) / 0.07; w = w < 0.0 ? 0.0 : (w > 1.0 ? 1.0 : w);   // fades out near vertical so the hand does not snap
    double Rr[9];
    weight::axis_angle(f, ang * w, Rr);
    weight::mul3(Rr, Qs, Q);
  }
  static int pose_world(const uint8_t* local, int bone, float* out) {
    int stack[64], ns = 0;
    for (int j = bone; j >= 0 && ns < 64; j = c.parent[j]) stack[ns++] = j;
    if (ns <= 0 || ns >= 64) return 0;
    alignas(16) float acc[16], tmp[16], nx[16];
    for (int k = ns - 1; k >= 0; --k) {
      for (int i = 0; i < 16; ++i) tmp[i] = 0;
      G::local(local + (size_t)40 * stack[k], tmp);
      if (k == ns - 1) { for (int i = 0; i < 16; ++i) acc[i] = tmp[i]; }
      else { for (int i = 0; i < 16; ++i) nx[i] = 0; G::mul(nx, tmp, acc); for (int i = 0; i < 16; ++i) acc[i] = nx[i]; }
    }
    for (int i = 0; i < 16; ++i) out[i] = acc[i];
    for (int i = 0; i < 15; ++i) if (!vm::is_finite_f(out[i]) || out[i] > 1e6f || out[i] < -1e6f) return 0;
    return 1;
  }
  // a bone matrix's three axis rows as world directions, as the columns of an orthonormal matrix (column form)
  static void frame_world(const arm::Space& sp, const float* B, double* M) {
    for (int r = 0; r < 3; ++r) {
      double m[3] = {B[r * 4], B[r * 4 + 1], B[r * 4 + 2]}, w3[3];
      sp.dir_world(m, w3);
      for (int k = 0; k < 3; ++k) M[k * 3 + r] = w3[k];
    }
    weight::orthonormalize(M);
  }
  // which of the bone matrix's three axis rows runs along the limb (the one to stretch)
  static int along_row(const float* B, const arm::Space& sp, const double* dir) {
    int best = 0; double bd = -1;
    for (int r = 0; r < 3; ++r) {
      double m[3] = {B[r * 4], B[r * 4 + 1], B[r * 4 + 2]}, w[3];
      sp.dir_world(m, w);
      double l = arm::len(w);
      if (!(l > 1e-9)) continue;
      double d = arm::dot(w, dir) / l;
      if (d < 0) d = -d;
      if (d > bd) { bd = d; best = r; }
    }
    return best;
  }

  // 0.69 the legs: after the pelvis moved (crouch drop, eye shift) each ankle goes back to where the animation had it and the knee folds or
  // stretches to follow. A0 = the animation's ankles (world), haveA0 says which are valid.
  static void plant_legs(float* world, const uint8_t* local, int n, const arm::Space& sp, const double A0[2][3], const int haveA0[2], double yaw) {
    double fb[3] = {0, 0, 1};
    {
      double sy, cy;
      vm::dsincos(yaw, &sy, &cy);
      fb[0] = sy; fb[2] = cy;
    }
    for (int l = 0; l < 2; ++l) {
      ArmInfo& a = c.arm[2 + l];
      if (a.U < 0 || !haveA0[l]) { ++st.noLegs; continue; }
      float Wc[MAXPATH][16];
      chain_world(local, world, a, Wc);
      double S[3], E0[3], Hp[3];
      sp.point_world(Wc[0] + 12, S); sp.point_world(Wc[1] + 12, E0); sp.point_world(Wc[a.plen - 1] + 12, Hp);
      double q1[3] = {E0[0] - S[0], E0[1] - S[1], E0[2] - S[2]}, q2[3] = {Hp[0] - E0[0], Hp[1] - E0[1], Hp[2] - E0[2]};
      double a1 = arm::len(q1), a2 = arm::len(q2);
      if (!(a1 > 0.3 && a1 < 4.0 && a2 > 0.3 && a2 < 4.0)) { ++st.legFail[l]; continue; }
      const double reach[3] = {A0[l][0] - S[0], A0[l][1] - S[1], A0[l][2] - S[2]};
      const double legScale = arm::planted_leg_scale(arm::len(reach), a1 + a2);
      double E0s[3], Hps[3];
      for (int i = 0; i < 3; ++i) { E0s[i] = S[i] + q1[i] * legScale; Hps[i] = E0s[i] + q2[i] * legScale; }
      arm::Ik k;
      if (!arm::solve(S, E0s, Hps, A0[l], 0.0, &k, fb)) { ++st.legFail[l]; continue; }
      float Un[16], Fn[16], Hn[16];
      double QF[9], I3[9];
      weight::ident(I3);
      sp.place(Wc[0], k.QU, S, Un);
      for (int i = 0; i < 3; ++i) Un[12 + i] = Wc[0][12 + i];
      weight::mul3(k.Q2, k.QU, QF);
      sp.place(Wc[1], QF, k.E, Fn);
      sp.place(Wc[a.plen - 1], I3, k.T, Hn);   // the ankle keeps its own turn
      if (legScale > 1.0001) {
        const int ru = along_row(Wc[0], sp, q1), rf = along_row(Wc[1], sp, q2);
        for (int cc = 0; cc < 3; ++cc) { Un[ru * 4 + cc] = (float)(Un[ru * 4 + cc] * legScale); Fn[rf * 4 + cc] = (float)(Fn[rf * 4 + cc] * legScale); }
        ++st.legExtended[l];
        const int x100 = (int)(legScale * 100.0);
        if (x100 > st.legExtendMaxX100[l]) st.legExtendMaxX100[l] = x100;
      }
      if (!finite16(Un) || !finite16(Fn) || !finite16(Hn)) { ++st.legFail[l]; continue; }
      write_chain(world, local, n, a, Un, Fn, Hn);
      ++st.legMoved[l];
      if (k.clamped) ++st.legClamped[l];
      const double miss[3] = {A0[l][0] - k.T[0], A0[l][1] - k.T[1], A0[l][2] - k.T[2]};
      const int missX100 = (int)(arm::len(miss) * 100.0);
      if (missX100 > st.legMissMaxX100[l]) st.legMissMaxX100[l] = missX100;
    }
  }

  // The head / spine / crouch layer: runs before the arms so the shoulders are where the torso put them.
  // 0.69 order: measure the avatar's eyes -> crouch drop (whole pelvis subtree) -> lean about the waist and the lower back -> head turn
  // -> the exact eye match (the whole pelvis subtree shifts so the eyes are at the camera; capped, scaled by t->fade) -> legs planted
  // at the animation's ankles -> the head slides the last bit.
  static void torso_pass(float* world, const uint8_t* local, int n, const arm::Space& sp, const ArmTargets* t) {
    if (!t->bodyOn) return;
    if (!c.torsoOk) { ++st.noTorso; return; }
    const double fade = t->fade < 0 ? 0.0 : (t->fade > 1 ? 1.0 : t->fade);
    st.fadeX100 = (int)(fade * 100.0);
    // 0.75 where the avatar's eyes are put: the camera's eye, a little lower (the view sits higher on the body) and a little forward (the shoulders are
    // closer to the hands). The head is hidden anyway; the arms reach further and the view is not inside the neck.
    double goal[3] = {t->eyeTarget[0], t->eyeTarget[1], t->eyeTarget[2]};
    if (t->eyeOn) {
      double gs, gc;
      vm::dsincos(t->bodyYaw, &gs, &gc);
      // 1.7.168 "looking down, an overlapping body": body_out (10 cm) put the avatar's neck in FRONT of your eye, and looking down you saw the top of your own
      // shoulders, the collar and the neck from above (the 1.7.165 video). Real eyes sit in front of the neck. From 20 deg down to 60 deg down the body_out
      // fades out and the body slides back by down_back instead, so you look down at your chest and legs, in front of the collar.
      double outFt = t->bodyOutFt;
      { const double hx = t->hmdBasis[2], fy = t->hmdBasis[5], hz = t->hmdBasis[8]; const double hl = vm::dsqrt(hx * hx + hz * hz);
        const double pd = vm::datan2(-fy, hl > 1e-6 ? hl : 1e-6) * 57.29577951308232;   // degrees down
        double k = (pd - 20.0) / 40.0; k = k < 0.0 ? 0.0 : (k > 1.0 ? 1.0 : k); k = k * k * (3.0 - 2.0 * k);   // 20..60 deg (the stress test: a later or slower slide leaves the neck in view at 45-55 deg)
        if (k == k) { outFt = t->bodyOutFt * (1.0 - k) - t->downBackFt * k; st.downK100 = (int)(k * 100.0 + 0.5); } }
      goal[0] += gs * outFt; goal[2] += gc * outFt; goal[1] -= t->viewDownFt;
      st.eyeGoalOn = (t->bodyOutFt != 0.0 || t->viewDownFt != 0.0) ? 1 : 0;
      st.eyeGoalOff[0] = (float)(goal[0] - t->eyeTarget[0]); st.eyeGoalOff[1] = (float)(goal[1] - t->eyeTarget[1]); st.eyeGoalOff[2] = (float)(goal[2] - t->eyeTarget[2]);
    }
    {   // the engine does not rebuild the pose between the two eyes of a pair: when the matrices are still the ones we wrote, the body is already posed
      const float* h = world + (size_t)16 * c.bHead; const float* pv = world + (size_t)16 * c.bPelvis; const float* sp1 = world + (size_t)16 * c.bSpine1;
      double sig[23];
      for (int i = 0; i < 3; ++i) sig[i] = t->headDelta[i];
      for (int i = 0; i < 9; ++i) sig[3 + i] = t->hmdBasis[i];
      sig[12] = t->bodyYaw; sig[13] = t->crouchOn ? t->dropMaxFt + t->leanMaxDeg + t->headMaxDeg : -1.0;
      for (int i = 0; i < 3; ++i) sig[14 + i] = t->eyeOn ? t->eyeTarget[i] : 0.0;
      sig[17] = t->crouchDeadFt; sig[18] = fade; sig[19] = t->viewDownFt; sig[20] = t->bodyOutFt + 7.0 * t->downBackFt; sig[21] = t->bendFrac; sig[22] = t->bendMaxDeg;
      if (tpHave && tpWorld == world) {
        int same = 1;
        for (int i = 0; i < 23; ++i) if (sig[i] != tpSig[i]) same = 0;
        for (int r = 0; r < 4 && same; ++r) for (int cc = 0; cc < 3; ++cc)
          if (h[r * 4 + cc] != tpHead[r * 4 + cc] || pv[r * 4 + cc] != tpPelvis[r * 4 + cc] || sp1[r * 4 + cc] != tpSpine[r * 4 + cc]) { same = 0; break; }
        if (same) { ++st.torsoSkipped; if (st.motion.have) st.motion.clock = G::clock(); return; }
      }
    }
    ++st.torso;
    if (fade < 0.5) ++st.forcedCalls;
    const double kRad = vm::kPi / 180.0;
    double dl[3] = {t->headDelta[0], t->headDelta[1], t->headDelta[2]};
    for (int i = 0; i < 3; ++i) if (!vm::is_finite_f((float)dl[i])) { ++st.torsoFail; return; }
    double Ph0[3];
    sp.point_world(world + (size_t)16 * c.bHead + 12, Ph0);
    double target[3] = {Ph0[0] + dl[0], Ph0[1] + dl[1], Ph0[2] + dl[2]};
    double A0[2][3] = {{0, 0, 0}, {0, 0, 0}};
    int haveA0[2] = {0, 0};
    for (int l = 0; l < 2; ++l) if (c.arm[2 + l].U >= 0) { sp.point_world(world + (size_t)16 * c.arm[2 + l].H + 12, A0[l]); haveA0[l] = 1; }
    st.motion.have = 0;
    // 0.69 where the avatar's eyes are now (animation + the base placement). Measured every pass: the log wants it, and the eye height of the
    // UNSCALED model goes into a histogram (its tallest peak is the standing pose; the body scale is camera eye / that)
    int haveEye = 0;
    if (c.bEyeL >= 0 && c.bEyeR >= 0) {
      double ea[3], eb[3], Ee[3];
      sp.point_world(world + (size_t)16 * c.bEyeL + 12, ea); sp.point_world(world + (size_t)16 * c.bEyeR + 12, eb);
      for (int i = 0; i < 3; ++i) Ee[i] = 0.5 * (ea[i] + eb[i]);
      if (vm::is_finite_f((float)Ee[0]) && vm::is_finite_f((float)Ee[1]) && vm::is_finite_f((float)Ee[2])) {
        const double sc = vm::dsqrt(sp.A[0] * sp.A[0] + sp.A[1] * sp.A[1] + sp.A[2] * sp.A[2]);
        if (sc > 0.3 && fade > 0.99 && !t->eyeSampleBlock) {   // not while the game is moving the character by force (1.7.181: nor in a cutscene, firing or walking: those poses are not the standing eye height)
          const double m = (Ee[1] - sp.t[1]) / sc;
          if (m > 3.5 && m < 8.0) {
            if (!eyeHistInit) { eyeHist.init(3.5, 8.0); eyeHistInit = 1; }
            eyeHist.add(m);
            float share = 0;
            const double md = eyeHist.mode(&share);
            if (md > 0) { st.modelEyeFt = (float)md; st.modelEyeShare = share; }
            st.modelEyeN = eyeHist.n;
          }
        }
        if (t->eyeOn) {
          double D[3];
          for (int i = 0; i < 3; ++i) D[i] = goal[i] - Ee[i];
          haveEye = arm::len(D) < 20.0;
          if (haveEye) {
            if (st.eyeN > 0) {   // 0.98: change from the last pass (the animation pushing the head about while the headset did not)
              const double j0 = D[0] - st.eyeErr[0], j1 = D[1] - st.eyeErr[1], j2 = D[2] - st.eyeErr[2];
              const int j100 = (int)(vm::dsqrt(j0 * j0 + j1 * j1 + j2 * j2) * 100.0);
              st.eyeJumpSumX100 += j100 > 100000 ? 100000 : j100;
              if (j100 > 25) ++st.eyeJumps;
              if (j100 > st.eyeJumpMaxX100) st.eyeJumpMaxX100 = j100;
            }
            for (int i = 0; i < 3; ++i) st.eyeErr[i] = (float)D[i];
            const int e100 = (int)(arm::len(D) * 100.0);
            ++st.eyeN; st.eyeErrSumX100 += e100 > 100000 ? 100000 : e100;
            if (e100 > st.eyeErrMaxX100) st.eyeErrMaxX100 = e100;
            double sy, cy;
            vm::dsincos(t->bodyYaw, &sy, &cy);
            const double ex = D[0] - dl[0], ez = D[2] - dl[2], ey = D[1] - dl[1];
            st.eyeErrBody[0] = (float)(ex * cy - ez * sy); st.eyeErrBody[1] = (float)ey; st.eyeErrBody[2] = (float)(ex * sy + ez * cy);   // beyond the lean: right, up, forward
          }
        }
      }
    } else if (t->eyeOn) ++st.eyeBoneMissing;
    // 1. crouch: the whole body drops (the legs are put back on the ground at the end)
    double drop = 0;
    {
      const double dead = t->crouchDeadFt > 0 ? t->crouchDeadFt : 0.04;
      if (t->crouchOn && dl[1] < -dead) {
        drop = t->crouchDeadFt > 0 ? (dl[1] + dead) * 0.9 : dl[1] * 0.85;   // 0.68: a head that only dips a little (leaning, looking down) does not fold the knees
        if (drop < -t->dropMaxFt) drop = -t->dropMaxFt;
      }
    }
    st.motion.drop = drop;
    for (int i = 0; i < 3; ++i) st.motion.shift[i] = 0;
    for (int k = 0; k < 2; ++k) { weight::ident(st.motion.Q[k]); for (int i = 0; i < 3; ++i) st.motion.pv[k][i] = 0; }
    if (drop != 0) {
      double d3[3] = {0, drop, 0};
      sub_shift(world, n, c.inPelvis, sp, d3);
    }
    // 2. lean: the upper body turns about the waist, then the lower back, so the head reaches its target
    double Ql[9], I3[9];
    weight::ident(Ql); weight::ident(I3);
    {
      const double maxRad = t->leanMaxDeg * kRad;
      for (int stage = 0; stage < 2; ++stage) {
        const int pivotBone = stage == 0 ? c.bSpine1 : c.bSpine3;
        double pv[3], ph[3], v0[3], v1[3], u0[3], u1[3];
        sp.point_world(world + (size_t)16 * pivotBone + 12, pv);
        sp.point_world(world + (size_t)16 * c.bHead + 12, ph);
        arm::sub(ph, pv, v0); arm::sub(target, pv, v1);
        if (!(arm::len(v0) > 0.3) || !arm::unit(v0, u0) || !arm::unit(v1, u1)) continue;
        double Qf[9], Qs[9];
        arm::swing(u0, u1, Qf);
        arm::rot_part(Qf, stage == 0 ? 0.5 : 1.0, maxRad * 0.5, Qs);
        sub_rotate(world, n, stage == 0 ? c.inSpine : c.inSpine3, sp, pv, Qs);
        weight::mul3(Qs, Ql, Ql);
        for (int i = 0; i < 3; ++i) st.motion.pv[stage][i] = pv[i];
        for (int i = 0; i < 9; ++i) st.motion.Q[stage][i] = Qs[i];
      }
    }
    // 2b. 1.7.23 the body bends with you, measured on the real bones. 1.7.21 rotated about "the head's right axis" and the 1.7.22 log proved the sign wrong for the game's axes (the upper body
    // went BACK about as far as the old lean went forward: the world tilt was 5 to 8 degrees while looking down 60 to 70 degrees, and the avatar's chest filled the bottom of the view).
    // The upper body follows its own facing while the head looks aside. Bending toward the head's horizontal facing made the chest twist sideways when looking down during a turn.
    // The torso direction (spine1 -> neck) is read from the bones; side lean is kept. A body already leaning farther is left alone.
    double bendAng = 0;
    double tiltBefore = 0, tiltWant = 0;
    int tiltKnown = 0;
    if (t->bendFrac > 0.0 && t->bendMaxDeg > 0.0 && c.bNeck >= 0 && c.bSpine1 >= 0) {
      const double hx = t->hmdBasis[2], fy = t->hmdBasis[5], hz = t->hmdBasis[8];
      const double hl = vm::dsqrt(hx * hx + hz * hz);
      if (hl > 1e-4) {
        const double pitchDown = vm::datan2(-fy, hl);
        double T = t->bendFrac * (pitchDown - 10.0 * kRad);
        if (T < 0) T = 0;
        if (T > t->bendMaxDeg * kRad) T = t->bendMaxDeg * kRad;
        double pvb[3], pn[3], v[3];
        sp.point_world(world + (size_t)16 * c.bSpine1 + 12, pvb);
        sp.point_world(world + (size_t)16 * c.bNeck + 12, pn);
        arm::sub(pn, pvb, v);
        const double vl = arm::len(v);
        if (vl > 0.1) {
          double sy, cy; vm::dsincos(t->bodyYaw, &sy, &cy);
          const double fh[3] = {sy, 0.0, cy};
          const double vf = v[0] * fh[0] + v[2] * fh[2], vu = v[1];
          double vr[3] = {v[0] - vf * fh[0], 0.0, v[2] - vf * fh[2]};
          const double lat = arm::len(vr) / vl;
          tiltBefore = vm::datan2(vf, vu); tiltWant = T; tiltKnown = 1;
          if (T > tiltBefore + 0.002 && vu > 0.0) {
            const double pl = lat < 1.0 ? vm::dsqrt(1.0 - lat * lat) : 0.0;
            double sT, cT; vm::dsincos(T, &sT, &cT);
            double u0[3] = {v[0] / vl, v[1] / vl, v[2] / vl}, u1[3];
            u1[0] = vr[0] / vl + pl * sT * fh[0]; u1[1] = pl * cT; u1[2] = vr[2] / vl + pl * sT * fh[2];
            double Qb[9];
            if (arm::unit(u1, u1)) {
              arm::swing(u0, u1, Qb);
              sub_rotate(world, n, c.inSpine, sp, pvb, Qb);
              weight::mul3(Qb, Ql, Ql);
              bendAng = T - tiltBefore;
            }
          }
        }
      }
    }
    if (tiltKnown) {   // the log: how far the torso leaned before the bend, what was wanted, and (once the eye match is done) what is left
      st.tiltBeforeX10 = (int)(tiltBefore / kRad * 10.0); st.tiltWantX10 = (int)(tiltWant / kRad * 10.0);
      ++st.tiltPasses; if (tiltWant > 0.02) { ++st.tiltBendWanted; if (tiltBefore < tiltWant - 0.002) ++st.tiltBendApplied; st.tiltBeforeSumX10 += st.tiltBeforeX10; }
      if (st.tiltPasses == 1) st.tiltBeforeMinX10 = st.tiltBeforeMaxX10 = st.tiltBeforeX10;
      if (st.tiltBeforeX10 > st.tiltBeforeMaxX10) st.tiltBeforeMaxX10 = st.tiltBeforeX10;
      if (st.tiltBeforeX10 < st.tiltBeforeMinX10) st.tiltBeforeMinX10 = st.tiltBeforeX10;
    }
    st.lastBendX10 = (int)(bendAng / kRad * 10.0);
    if (st.lastBendX10 > st.bendMaxX10) st.bendMaxX10 = st.lastBendX10;
    ++st.bendPasses; if (bendAng > 0) ++st.bendActive;
    // 3. head: takes the headset's orientation (a third of it at the neck)
    double Lv[9], LvT[9], Qh[9], QlT[9], Qneed[9];
    {
      double sy, cy;
      vm::dsincos(t->bodyYaw, &sy, &cy);
      Lv[0] = cy; Lv[1] = 0; Lv[2] = sy; Lv[3] = 0; Lv[4] = 1; Lv[5] = 0; Lv[6] = -sy; Lv[7] = 0; Lv[8] = cy;
    }
    weight::transpose3(Lv, LvT);
    weight::mul3(t->hmdBasis, LvT, Qh);
    weight::transpose3(Ql, QlT);
    weight::mul3(Qh, QlT, Qneed);
    double headAng = 0;
    {
      double Qn[9], Qrem[9], QnT[9], pv[3];
      const double maxRad = t->headMaxDeg * kRad;
      headAng = arm::rot_part(Qneed, 0.35, maxRad * 0.35, Qn);
      sp.point_world(world + (size_t)16 * c.bNeck + 12, pv);
      sub_rotate(world, n, c.inNeck, sp, pv, Qn);
      weight::transpose3(Qn, QnT);
      weight::mul3(Qneed, QnT, Qrem);
      double Qr2[9];
      arm::rot_part(Qrem, 1.0, maxRad * 0.65, Qr2);
      sp.point_world(world + (size_t)16 * c.bHead + 12, pv);
      sub_rotate(world, n, c.inHead, sp, pv, Qr2);
    }
    // 4. 0.69 the exact eye match: what is left between the avatar's eyes and the camera's eye is taken out by shifting the whole body
    // (the ankles stay where the animation had them, the legs follow), and the last few centimetres by sliding the head
    double S[3] = {0, 0, 0}, H[3] = {0, 0, 0}, walk[3] = {0, 0, 0};
    if (haveEye) {
      double ea[3], eb[3], R[3];
      sp.point_world(world + (size_t)16 * c.bEyeL + 12, ea); sp.point_world(world + (size_t)16 * c.bEyeR + 12, eb);
      for (int i = 0; i < 3; ++i) R[i] = (goal[i] - 0.5 * (ea[i] + eb[i])) * fade;
      if (haveA0[0] && haveA0[1]) {   // 0.70 data: camera eye and avatar eye above the animation's feet (after the lean and head turn)
        const double fy = 0.5 * (A0[0][1] + A0[1][1]);
        st.camAboveFeet = (float)(t->eyeTarget[1] - fy); st.eyeAboveFeet = (float)(0.5 * (ea[1] + eb[1]) - fy);
        st.camAboveFeetSum += st.camAboveFeet; st.eyeAboveFeetSum += st.eyeAboveFeet; ++st.feetN;
      }
      // 1.7.29 calm walking: the avatar's eye minus its pelvis (off) is what the walk animation bobs; the pelvis follows a smoothed copy of it, the hidden head slides the small rest,
      // so the body (and the pack and the hose on it) stops shaking in your head's frame while the eyes still sit exactly on the headset's eye. The shake meter below measures both.
      double Rs[3] = {R[0], R[1], R[2]};
      {
        double Pp[3], Ee3[3] = {0.5 * (ea[0] + eb[0]), 0.5 * (ea[1] + eb[1]), 0.5 * (ea[2] + eb[2])};
        sp.point_world(world + (size_t)16 * c.bPelvis + 12, Pp);
        double off[3] = {Ee3[0] - Pp[0], Ee3[1] - Pp[1], Ee3[2] - Pp[2]}, offC[3] = {off[0], off[1], off[2]};
        const int newFrame = (t->calmSeq != calmLastSeq);
        double dt = newFrame ? t->calmDtS : 0.0;   // the same frame again (a second pass): hold, do not step twice
        if (newFrame) {
          calmLastSeq = t->calmSeq; ++st.calmFrames;
          st.dtSum += t->calmDtS; ++st.dtN; if (t->calmDtS > st.dtMax) st.dtMax = t->calmDtS;
          if (t->calmDtS > 0.020) ++st.dtOver20; if (t->calmDtS > 0.033) ++st.dtOver33;
        }
        const int calmOn = t->calmTauS > 0.001 && fade > 0.99 && vm::is_finite_f((float)off[0]);
        if (calmOn) {
          const int sm = calm::step(&calmF, off, dt, t->calmTauS, 0.10, 0.6, offC);
          if (newFrame) { if (sm) ++st.calmSmoothed; else ++st.calmSnapped; }
          for (int i = 0; i < 3; ++i) Rs[i] = R[i] + (off[i] - offC[i]);   // S = goal - pelvis - smoothed offset
          const double dd[3] = {off[0] - offC[0], off[1] - offC[1], off[2] - offC[2]};
          const double lag = calm::len3(dd);
          if (newFrame) { st.calmLagSumFt += lag; if (lag > st.calmLagMaxFt) st.calmLagMaxFt = lag; }
        } else { calm::reset(&calmF); if (newFrame) ++st.calmOff; }
        {   // 1.7.207 centre the body under the head: the avatar's eyes sit on the camera, but its pelvis sits where the animation keeps it (left of the head in the aim stance). Sideways only.
          double bsy, bcy; vm::dsincos(t->bodyYaw, &bsy, &bcy);                 // body right = (cos, 0, -sin)
          st.latRawCm = (float)(-(off[0] * bcy - off[2] * bsy) * 30.48);       // data: pelvis minus eye, sideways, before the fix (cm, + = pelvis right of the eye)
          double lb = (offC[0] * bcy - offC[2] * bsy) * fade;                   // eye minus pelvis along body right (smoothed)
          if (!vm::is_finite_f((float)lb)) lb = 0.0;
          if (lb > 0.6) lb = 0.6;
          if (lb < -0.6) lb = -0.6;
          {   // keep the avatar's eyes exactly on the camera: the hidden head slides the sideways difference back, and it can only slide slideCap, so use no more than that room
            const double capHc = t->slideCapFt > 0 ? t->slideCapFt : 0.2;
            double sc = 1.0;
            for (int it = 0; it < 10; ++it) {
              const double rx = (R[0] - Rs[0]) - sc * lb * bcy, ry = R[1] - Rs[1], rz = (R[2] - Rs[2]) + sc * lb * bsy;
              if (vm::dsqrt(rx * rx + ry * ry + rz * rz) <= capHc || sc < 0.01) break;
              sc *= 0.5;
            }
            if (sc < 0.01) sc = 0.0;
            lb *= sc;
          }
          Rs[0] += lb * bcy; Rs[2] -= lb * bsy;
          st.latAppliedCm = (float)(lb * 30.48);
        }
        if (newFrame) {   // the shake meter: second difference of the body's place against the eye, raw (what 1.7.28 did) and as applied now; split by standing / moving
          int moving = 0;
          if (calmHaveP && t->calmDtS > 0.0 && t->calmDtS < 0.25) {
            const double dx = Pp[0] - calmPrevP[0], dz = Pp[2] - calmPrevP[2];
            moving = (dx * dx + dz * dz) > (1.5 * t->calmDtS) * (1.5 * t->calmDtS) ? 1 : 0;
          }
          if (t->calmDtS <= 0.0 || t->calmDtS >= 0.25 || !calmHaveP) calmHistN = 0;
          for (int i = 0; i < 3; ++i) { calmHistRaw[0][i] = calmHistRaw[1][i]; calmHistRaw[1][i] = calmHistRaw[2][i]; calmHistRaw[2][i] = off[i];
                                         calmHistApp[0][i] = calmHistApp[1][i]; calmHistApp[1][i] = calmHistApp[2][i]; calmHistApp[2][i] = offC[i]; calmPrevP[i] = Pp[i]; }
          calmHaveP = 1; if (calmHistN < 3) ++calmHistN;
          if (calmHistN >= 3) {
            const double r2 = calm::second_diff(calmHistRaw[0], calmHistRaw[1], calmHistRaw[2]), a2 = calm::second_diff(calmHistApp[0], calmHistApp[1], calmHistApp[2]);
            if (r2 < 3.0) {   // a jump of metres is a cut or a teleport, not a shake
              st.shakeRawSum[moving] += r2; st.shakeAppSum[moving] += a2; ++st.shakeN[moving];
              if (r2 > st.shakeRawMax[moving]) st.shakeRawMax[moving] = r2;
              if (a2 > st.shakeAppMax[moving]) st.shakeAppMax[moving] = a2;
            }
          }
        }
      }
      const double rl = arm::len(Rs);
      if (rl > 0.003 && rl < 20.0) {
        const double capS = t->shiftCapFt > 0 ? t->shiftCapFt : 1.0, capH = t->slideCapFt > 0 ? t->slideCapFt : 0.2;
        // 0.70: the sideways part (x, z) moves the WHOLE body, feet included (the ankle targets move with it), so it needs no cap and never
        // stretches a leg - the 0.69 log showed the old 1 ft pelvis-only shift hitting its cap 15 percent of the time and the legs clamped 37 percent.
        // Only the up/down part is limited (the legs stay planted for it).
        const double capW = 6.0;
        double Rh[3] = {Rs[0], 0.0, Rs[2]}, Rv[3] = {0.0, Rs[1], 0.0};
        const double rhl = arm::len(Rh);
        if (rhl > capW) { for (int i = 0; i < 3; ++i) Rh[i] *= capW / rhl; ++st.shiftCapped; }
        const double rvl = arm::len(Rv);
        if (rvl > capS) { for (int i = 0; i < 3; ++i) Rv[i] *= capS / rvl; ++st.shiftCapped; }
        for (int i = 0; i < 3; ++i) { S[i] = Rh[i] + Rv[i]; walk[i] = Rh[i]; }
        { const int w100 = (int)(arm::len(Rh) * 100.0), v100 = (int)(arm::len(Rv) * 100.0);
          ++st.walkN; st.walkSumX100 += w100; st.vertSumX100 += v100;
          if (w100 > st.walkMaxX100) st.walkMaxX100 = w100;
          if (v100 > st.vertMaxX100) st.vertMaxX100 = v100; }
        double rest[3] = {R[0] - S[0], R[1] - S[1], R[2] - S[2]};
        const double restL = arm::len(rest);
        for (int i = 0; i < 3; ++i) H[i] = rest[i];
        if (restL > capH) for (int i = 0; i < 3; ++i) H[i] *= capH / restL;
        const double sl = arm::len(S);
        if (sl > 0.003) {
          sub_shift(world, n, c.inPelvis, sp, S);
          ++st.shifted;
          for (int i = 0; i < 3; ++i) { st.shiftLast[i] = (float)S[i]; st.motion.shift[i] = S[i]; }
          const int s100 = (int)(sl * 100.0);
          if (s100 > st.shiftMaxX100) st.shiftMaxX100 = s100;
        }
      }
      for (int i = 0; i < 3; ++i) st.eyeResid[i] = (float)((goal[i] - 0.5 * (ea[i] + eb[i])) - S[i] - H[i]);
      double rv[3] = {st.eyeResid[0], st.eyeResid[1], st.eyeResid[2]};
      const int r100 = (int)(arm::len(rv) * 100.0);
      if (r100 > st.eyeResidMaxX100) st.eyeResidMaxX100 = r100;
    }
    // 5. legs: the pelvis moved (drop and/or shift): the ankles go back to where the animation had them
    if (drop != 0 || arm::len(S) > 0.003) {
      double A1[2][3];
      for (int l = 0; l < 2; ++l) for (int i = 0; i < 3; ++i) A1[l][i] = A0[l][i] + walk[i];   // 0.70: the feet go along with the sideways shift
      plant_legs(world, local, n, sp, A1, haveA0, t->bodyYaw);
    }
    st.motion.have = 1; st.motion.clock = G::clock();
    if (haveEye && arm::len(H) > 0.002) {   // the head slides the last bit
      sub_shift(world, n, c.inHead, sp, H);
      ++st.headShifted;
      const int h100 = (int)(arm::len(H) * 100.0);
      if (h100 > st.headShiftMaxX100) st.headShiftMaxX100 = h100;
    }
    {
      const float* h = world + (size_t)16 * c.bHead; const float* pv = world + (size_t)16 * c.bPelvis; const float* sp1 = world + (size_t)16 * c.bSpine1;
      for (int r = 0; r < 4; ++r) for (int cc = 0; cc < 3; ++cc) { tpHead[r * 4 + cc] = h[r * 4 + cc]; tpPelvis[r * 4 + cc] = pv[r * 4 + cc]; tpSpine[r * 4 + cc] = sp1[r * 4 + cc]; }
      for (int i = 0; i < 3; ++i) tpSig[i] = t->headDelta[i];
      for (int i = 0; i < 9; ++i) tpSig[3 + i] = t->hmdBasis[i];
      tpSig[12] = t->bodyYaw; tpSig[13] = t->crouchOn ? t->dropMaxFt + t->leanMaxDeg + t->headMaxDeg : -1.0;
      for (int i = 0; i < 3; ++i) tpSig[14 + i] = t->eyeOn ? t->eyeTarget[i] : 0.0;
      tpSig[17] = t->crouchDeadFt; tpSig[18] = fade; tpSig[19] = t->viewDownFt; tpSig[20] = t->bodyOutFt; tpSig[21] = t->bendFrac; tpSig[22] = t->bendMaxDeg;
      tpWorld = world; tpHave = 1;
    }
    // statistics
    double lv[3];
    weight::rot_vector(Ql, lv);
    const int leanX10 = (int)(arm::len(lv) / kRad * 10.0), headX10 = (int)(headAng / kRad * 10.0), dropX100 = (int)(-drop * 100.0);
    st.lastLeanX10 = leanX10; st.lastHeadX10 = headX10; st.lastDropX100 = dropX100;
    if (leanX10 > st.leanMaxX10) st.leanMaxX10 = leanX10;
    if (headX10 > st.headMaxX10) st.headMaxX10 = headX10;
    if (dropX100 > st.dropMaxX100) st.dropMaxX100 = dropX100;
    if (st.torso == 1 || st.torso == 600 || st.torso == 6000) {
      G::log("BODYREL centre torso #%d: body centre (pelvis) minus eye, sideways: %.1f cm before the fix, %.1f cm after (fix applied %.1f cm, + = right of the eye)", st.torso, (double)st.latRawCm, (double)(st.latRawCm + st.latAppliedCm), (double)st.latAppliedCm);
      G::log("BODYPOSE torso #%d: head delta %.2f,%.2f,%.2f ft, crouch drop %.2f ft, lean %.1f deg, head turn %.1f deg (limits lean %.0f head %.0f, drop max %.2f ft)",
             st.torso, dl[0], dl[1], dl[2], -drop, arm::len(lv) / kRad, headAng / kRad, t->leanMaxDeg, t->headMaxDeg, t->dropMaxFt);
      if (haveEye)
        G::log("EYEALIGN torso #%d: camera eye %.2f,%.2f,%.2f minus the avatar's eye (before the torso pass) = %.2f,%.2f,%.2f ft (world); in the body frame, beyond the lean: right %.2f up %.2f forward %.2f; "
               "body shifted %.2f,%.2f,%.2f ft (fade %.2f), head slid %.2f ft; left %.3f,%.3f,%.3f ft; model eye height %.2f ft (peak share %.0f%%, %d samples)",
               st.torso, t->eyeTarget[0], t->eyeTarget[1], t->eyeTarget[2], (double)st.eyeErr[0], (double)st.eyeErr[1], (double)st.eyeErr[2],
               (double)st.eyeErrBody[0], (double)st.eyeErrBody[1], (double)st.eyeErrBody[2], S[0], S[1], S[2], fade, arm::len(H),
               (double)st.eyeResid[0], (double)st.eyeResid[1], (double)st.eyeResid[2], (double)st.modelEyeFt, (double)st.modelEyeShare * 100.0, st.modelEyeN);
      else if (t->eyeOn) G::log("EYEALIGN torso #%d: eye bones %s (L %d R %d): the avatar's eyes cannot be measured, no eye match", st.torso, (c.bEyeL >= 0 && c.bEyeR >= 0) ? "found but unreadable" : "missing", c.bEyeL, c.bEyeR);
    }
  }


  // 0.74 RIG VIEW: the joints of the avatar as they stand after the arms are placed (and before arms-only squashes anything), relative to the camera eye
  // in the headset's axes (feet). handmodel.cpp turns them into a small figure you can look at from the front.
  static void snapshot_rig(const float* world, int n, const arm::Space& sp, const ArmTargets* t) {
    if (!t->bodyOn || !t->eyeOn) { ++st.rigNoBasis; return; }
    const int idx[rig::kJ] = {c.bHead, c.bNeck, c.bSpine3, c.bSpine1, c.bPelvis,
                              c.clav[0], c.arm[0].U, c.arm[0].U >= 0 ? c.arm[0].F : -1, c.arm[0].H,
                              c.clav[1], c.arm[1].U, c.arm[1].U >= 0 ? c.arm[1].F : -1, c.arm[1].H,
                              c.arm[2].U, c.arm[2].U >= 0 ? c.arm[2].F : -1, c.arm[2].H,
                              c.arm[3].U, c.arm[3].U >= 0 ? c.arm[3].F : -1, c.arm[3].H, c.bEyeL, c.bEyeR};
    ++rsSeq;
    rs.fpm = (t->fpm > 0.1 && t->fpm < 100.0) ? (float)t->fpm : 3.28084f;
    int any = 0;
    for (int i = 0; i < rig::kJ; ++i) {
      rs.ok[i] = 0;
      const int b = idx[i];
      if (b < 0 || b >= n) continue;
      double Pw[3];
      sp.point_world(world + (size_t)16 * b + 12, Pw);
      if (!vm::is_finite_f((float)Pw[0]) || !vm::is_finite_f((float)Pw[1]) || !vm::is_finite_f((float)Pw[2])) continue;
      rig::point_to_head(t->hmdBasis, t->eyeTarget, Pw, rs.j[i]);
      rs.ok[i] = 1; ++any;
    }
    rs.have = any > 4;
    rs.stretch[0] = (float)(st.lastStretchX100[0] / 100.0); rs.stretch[1] = (float)(st.lastStretchX100[1] / 100.0);
    ++st.rigPasses;
    ++rsSeq;
  }
  static int rig_read(rig::Snap* out) {   // from another thread: a consistent copy, 0 = nothing yet
    for (int tries = 0; tries < 4; ++tries) {
      const long s0 = rsSeq;
      if (s0 & 1) continue;
      rig::Snap tmp = rs;
      if (rsSeq == s0) { *out = tmp; out->seq = s0; return tmp.have; }
    }
    return 0;
  }
  // the pack (which = 1) and the hose (which = 2) matrices of this render, relative to the camera eye in the headset's axes
  static void rig_part(int which, const float* W2, const double* view9, const double* eye3) {
    ++rsSeq;
    const int pk = which == 1;
    double Pw[3] = {W2[12], W2[13], W2[14]};
    float* o = pk ? rs.pack : rs.hose;
    rig::point_to_head(view9, eye3, Pw, o);
    float (*ax)[3] = pk ? rs.packAx : rs.hoseAx;
    for (int a = 0; a < 3; ++a) { double D[3] = {W2[a * 4], W2[a * 4 + 1], W2[a * 4 + 2]}; rig::dir_to_head(view9, D, ax[a]); }
    if (pk) rs.packOk = 1; else rs.hoseOk = 1;
    ++rsSeq;
  }

  // 0.71 ARMS ONLY. Every bone that is not part of an arm (the clavicle and everything below it) is squashed to one point just behind the
  // shoulders, so the skinned model draws only the two arms and hands: no head, chest or legs in the view. The squashed bones are put back at
  // the start of the next call (collapse_undo), so nothing else in the tool ever works on a squashed bone.
  static void collapse_undo(float* world, int n) {
    if (!col.have) return;
    col.have = 0;
    if (col.world != world || col.n != n || col.ref < 0) return;
    if (!same12(world + (size_t)16 * col.ref, col.Z)) return;   // the engine rebuilt the pose since: nothing to put back
    for (int j = 0; j < n; ++j) if (col.was[j]) copy12(world + (size_t)16 * j, col.saved[j]);
    ++st.colUndone;
  }
  static void collapse_body(float* world, int n, const arm::Space& sp, const ArmTargets* t) {
    unsigned char keep[MAXB];
    for (int j = 0; j < n; ++j) keep[j] = 0;
    int arms = 0;
    for (int s = 0; s < 2; ++s) {
      if (c.arm[s].U < 0) continue;
      ++arms;
      for (int j = 0; j < n; ++j) if (c.arm[s].inSub[j] || (c.clav[s] >= 0 && c.inClav[s][j])) keep[j] = 1;
    }
    if (arms < 2) { ++st.colNoArms; return; }
    const int noArms = t->noArms;   // 0.83 gloves only: the arms are squashed as well (the probe draws its own gloves)
    if (noArms) for (int j = 0; j < n; ++j) keep[j] = 0;
    const int headOnly = t->headOnly && c.torsoOk;
    if (headOnly) {   // Keep the neck as a short, natural cap over the collar; collapsing it opened a deep hole in the chest.
      for (int j = 0; j < n; ++j) keep[j] = c.inHead[j] ? 0 : 1;
      keep[c.bHead] = 0;
    }
    const int hidePke = t->hidePke && c.bPke[0] >= 0;   // 0.93
    if (hidePke) ++st.pkeHidePasses;
    if (hidePke) { keep[c.bPke[0]] = 0; if (c.bPke[1] >= 0) keep[c.bPke[1]] = 0; }
    // 0.73 shoulders: the upper chest bone and what hangs from it (the clavicles, which are kept anyway) stay; the neck and head do not
    const int shoulders = t->keepShoulders && c.torsoOk && !headOnly && !noArms;
    if (shoulders) for (int j = 0; j < n; ++j) if (c.inSpine3[j] && !c.inNeck[j]) keep[j] = 1;
    if (!hidePke && pkeKeepNow && c.bPke[0] >= 0) { keep[c.bPke[0]] = 1; if (c.bPke[1] >= 0) keep[c.bPke[1]] = 1; ++st.pkeKept; }   // 0.84: the PKE stays (it is glued to the hand)
    const float* u0 = world + (size_t)16 * c.arm[0].U;
    const float* u1 = world + (size_t)16 * c.arm[1].U;
    double P[3];
    for (int i = 0; i < 3; ++i) P[i] = 0.5 * ((double)u0[12 + i] + (double)u1[12 + i]);
    if (shoulders) {   // the point the rest is squashed to: below and behind the upper chest bone
      const float* s3 = world + (size_t)16 * c.bSpine3;
      for (int i = 0; i < 3; ++i) P[i] = (double)s3[12 + i];
      ++st.colShoulders;
      if (t->eyeOn) {   // data: where the upper chest is relative to the camera eye
        double Sp[3], sy2, cy2;
        sp.point_world(s3 + 12, Sp);
        vm::dsincos(t->bodyYaw, &sy2, &cy2);
        const double dx = Sp[0] - t->eyeTarget[0], dy = Sp[1] - t->eyeTarget[1], dz = Sp[2] - t->eyeTarget[2];
        const double rr = dx * cy2 - dz * sy2, ff = dx * sy2 + dz * cy2;
        st.spine3Rel[0] = (float)rr; st.spine3Rel[1] = (float)dy; st.spine3Rel[2] = (float)ff;
        st.spine3RelSum[0] += rr; st.spine3RelSum[1] += dy; st.spine3RelSum[2] += ff; ++st.spine3RelN;
      }
    }
    if (headOnly) {   // 1.7.213: the head gathers to ONE point at the neck top (the head bone's own origin), not buried in the chest: the neck's skin closes over there like a cap (the old point, 0.1 ft below the upper chest bone, pulled the neck tube's top ring down into the chest and left a hole in the collar)
      const float* nk = world + (size_t)16 * c.bHead;
      for (int i = 0; i < 3; ++i) P[i] = (double)nk[12 + i];
    }
    {   // a little behind (the way the body faces) and below the shoulder line: the stray triangles between an arm and the squashed body then end behind the eyes
      double sy = 0, cy = 1;
      if (t->bodyOn) vm::dsincos(t->bodyYaw, &sy, &cy);
      // With floating fight arms, bury the squashed chest/legs far behind and below the
      // shoulders. This is render-only bone placement; the player actor and physics never move.
      // 1.7.190 "a weird void going down just the arms" (the roof fight): the coat triangles between an arm and the squashed body stretched all the way to this point and showed as long dark wings
      // under the arms; with the point close behind the shoulders they stay short and end behind the eyes
      const double hiddenBack = t->floatingArms ? -0.35 : -1.40;
      const double hiddenDown = t->floatingArms ? -0.20 : -0.85;
      double back[3] = {shoulders ? -0.30 * sy : hiddenBack * sy, shoulders ? -0.50 : hiddenDown, shoulders ? -0.30 * cy : hiddenBack * cy};   // feet, game world
      if (headOnly) { back[0] = 0.0; back[1] = 0.0; back[2] = 0.0; }   // 1.7.213: exactly at the neck top
      double bm[3];
      sp.dir_model(back, bm);
      for (int i = 0; i < 3; ++i) P[i] += bm[i];
    }
    for (int i = 0; i < 3; ++i) if (!vm::is_finite_f((float)P[i])) { ++st.colBadPoint; return; }
    for (int i = 0; i < 16; ++i) col.Z[i] = 0;
    col.Z[0] = col.Z[5] = col.Z[10] = 1e-4f; col.Z[15] = 1.0f;
    col.Z[12] = (float)P[0]; col.Z[13] = (float)P[1]; col.Z[14] = (float)P[2];
    col.ref = -1;
    int cnt = 0;
    for (int j = 0; j < n; ++j) {
      col.was[j] = 0;
      if (keep[j]) continue;
      float* B = world + (size_t)16 * j;
      copy12(col.saved[j], B);
      copy12(B, col.Z);
      col.was[j] = 1; ++cnt;
      if (col.ref < 0) col.ref = j;
    }
    col.world = world; col.n = n; col.have = cnt > 0;
    st.colBones = cnt; ++st.colPasses;
    static int logged;
    if (++logged == 1)
      G::log("ARMSONLY first pass: %d of %d bones squashed to one point behind the shoulders (arms, hands, clavicles%s kept: %d); the head, %s and legs are no longer drawn", cnt, n,
             shoulders ? " and the upper chest with the pack-strap area" : "", n - cnt, shoulders ? "lower body" : "chest");
  }

  // 0.66: everything the arm pass depends on besides the bone matrices
  static int arm_sig(int s, const float* W2, const ArmTargets* t, double* o) {
    int n = 0;
    if (s == 0) { for (int i = 0; i < 9; ++i) o[n++] = t->wandR[i]; for (int i = 0; i < 3; ++i) o[n++] = t->wandP0[i]; for (int i = 0; i < 3; ++i) o[n++] = t->grip[i]; }
    else { for (int i = 0; i < 3; ++i) o[n++] = t->lpos[i]; for (int i = 0; i < 3; ++i) o[n++] = t->lfwd[i]; for (int i = 0; i < 3; ++i) o[n++] = t->lup[i];
      for (int i = 0; i < 3; ++i) { o[n++] = t->grip[i]; o[n++] = t->rdir[i]; o[n++] = t->rup[i]; } o[n++] = t->gunLenFt; o[n++] = t->gripMagnet; o[n++] = (double)(t->rightOn + 2 * t->rdirOk); o[n++] = t->underW; o[n++] = t->underFt; o[n++] = t->grabW; o[n++] = t->foreSteady; o[n++] = t->grabWrap; o[n++] = t->grabWrapDeg; o[n++] = t->grabOrbitDeg; o[n++] = t->grabOrbitFollow; o[n++] = (double)t->grabLatOk; o[n++] = t->grabLatX; o[n++] = t->grabLatY; o[n++] = t->fpm; }   // 1.7.105: the grab and the steadying change the left hand too
    o[n++] = t->trigPullDeg; o[n++] = t->pkePitchDeg; o[n++] = t->gunLiveOpen;
    o[n++] = t->wristBackFt; o[n++] = t->wristDownFt; o[n++] = t->elbowDown; o[n++] = t->stretchMax; o[n++] = t->forearmTwist;
    o[n++] = t->gunWristBackFt; o[n++] = t->gunWristDownFt; o[n++] = (double)t->gunPosOk; for (int i = 0; i < 3; ++i) o[n++] = t->gunPos[i];
    for (int i = 0; i < 16; ++i) o[n++] = W2[i];
    o[n++] = t->floatingArms; o[n++] = t->mirrorArms;
    o[n++] = t->reloadHold; o[n++] = t->itemId;
    for (int i = 0; i < 3; ++i) o[n++] = t->floatingArms ? t->eyeTarget[i] : 0.0;
    o[n++] = t->floatingArms ? t->bodyYaw : 0.0;
    o[n++] = t->floatingArms ? t->fpm : 0.0;
    return n;
  }
  static int same12(const float* a, const float* b) {
    for (int r = 0; r < 4; ++r) for (int cc = 0; cc < 3; ++cc) if (a[r * 4 + cc] != b[r * 4 + cc]) return 0;
    return 1;
  }

  // ---- 0.84 fingers: the game's own glove fingers curl with the controller's trigger (index) and grip (the other fingers) ----
  // Each finger is a chain of 3 hinge joints that all bend about one axis. The axis comes from the finger's own bend in the animation when it is bent
  // by 12 degrees or more, otherwise from the hand's geometry (the line across the knuckles, from the index finger to the little finger on the right hand, the other way on the left; fixed in 0.85 from the real log). Positive turns close the finger. The bones below a joint are turned rigidly about it, so the glove mesh follows the skin weights.
  static void curl_hand(float* world, int n, int s, const arm::Space& sp, const ArmTargets* t, int gunHand) {
    const ArmInfo& a = c.arm[s];
    ++st.fingerPasses[s];
    if (s == 0 && !gunHand) ++st.fingerEmptyPasses;
    static const double kShare[5][3] = {{0.0, 0.5, 0.5}, {0.36, 0.40, 0.24}, {0.36, 0.40, 0.24}, {0.36, 0.40, 0.24}, {0.34, 0.40, 0.26}};
    static const double kTotal[5] = {60.0, 190.0, 200.0, 200.0, 190.0};   // degrees of bend over the three joints at curl = 1 (a fist is about 230)
    static const double kMax[3] = {95.0, 110.0, 85.0};
    // 1.7.25 "the fingers wrinkle on the left hand by the tip": the left hand's fingertip joint bent about 45-60 degrees and the glove skin folded there. It now takes a smaller share (the knuckle and middle joint take it) and is capped lower.
    // 1.7.98 "left hand fingertips curl and look bad": the tip joint still took 16 % and bent up to about 30 degrees in a fist, which hooks the glove's fingertips. The tip now takes
    // 6 % and stops at 14 degrees; the knuckle and the middle joint carry the bend (a fist is still about 180 degrees in all). Only the free / foregrip left hand uses these.
    static const double kShareL[5][3] = {{0.0, 0.5, 0.5}, {0.46, 0.48, 0.06}, {0.46, 0.48, 0.06}, {0.46, 0.48, 0.06}, {0.44, 0.50, 0.06}};
    static const double kMaxL[3] = {95.0, 110.0, 14.0};
    const double rad = vm::kPi / 180.0;
    double Ph[3];
    sp.point_world(world + (size_t)16 * a.H + 12, Ph);
    double across[3] = {0, 0, 0};
    int haveAcross = 0;
    if (c.fing[s][1][0] >= 0 && c.fing[s][4][0] >= 0) {
      double pi3[3], pp3[3];
      sp.point_world(world + (size_t)16 * c.fing[s][1][0] + 12, pi3);
      sp.point_world(world + (size_t)16 * c.fing[s][4][0] + 12, pp3);
      arm::sub(pi3, pp3, across);
      haveAcross = arm::unit(across, across);
    }
    static int logged;
    for (int f = 0; f < 5; ++f) {
      const int* b = c.fing[s][f];
      if (b[0] < 0) continue;
      double tg = t->curl[s][f];
      st.fingerTgX10[s][f] = tg >= 0.0 ? (int)(tg * 1000.0) : -1000;
      if (!(tg >= 0.0)) continue;
      if (tg > 1.0) tg = 1.0;
      if (gunHand && f == 0) continue;   // the gun hand's thumb stays where the animation has it
      if (s == 1 && f == 0 && t->leftThumbKeep > 0.0) {   // 1.7.24: the left thumb follows the game's pose on the gun and relaxes with the fingers as the hand leaves it
        const double keep = t->leftThumbKeep > 1.0 ? 1.0 : t->leftThumbKeep;
        if (keep > 0.97) { ++st.leftThumbKept; continue; }
        tg *= (1.0 - keep);
      }
      double P[5][3], g[4][3], gl[4];
      for (int i = 0; i < 3; ++i) P[0][i] = Ph[i];
      for (int k = 0; k < 4; ++k) sp.point_world(world + (size_t)16 * b[k] + 12, P[k + 1]);
      int bad = 0;
      for (int i = 0; i < 4; ++i) { arm::sub(P[i + 1], P[i], g[i]); gl[i] = arm::len(g[i]); if (!(gl[i] > 1e-4) || !(gl[i] < 5.0)) bad = 1; }
      if (bad) { ++st.fingerBad[s]; ++st.fingerSkip[s][f]; continue; }
      // the axis the finger bends about
      double mx[3] = {0, 0, 0}, bestS = 0;
      for (int i = 2; i <= 3; ++i) {   // the two finger joints; the knuckle's own bend is not used (the knuckles sit off to the side of the wrist, which would look like a bend about the wrong axis)
        double x[3];
        arm::cross(g[i - 1], g[i], x);
        const double sn = arm::len(x) / (gl[i - 1] * gl[i]);
        if (sn > bestS) { bestS = sn; for (int k = 0; k < 3; ++k) mx[k] = x[k]; }
      }
      double ax[3], geo[3] = {0, 0, 0};
      int measured = bestS > 0.208 && arm::unit(mx, ax);   // 12 degrees
      int haveGeo = 0;
      if (f > 0 && haveAcross) {
        double fd[3];
        if (arm::unit(g[1], fd)) {
          const double k = arm::dot(across, fd);
          for (int i = 0; i < 3; ++i) geo[i] = across[i] - k * fd[i];
          haveGeo = arm::unit(geo, geo);
          if (haveGeo && s == 0) for (int i = 0; i < 3; ++i) geo[i] = -geo[i];   // 0.85: the 0.84 log showed the measured axis opposite to this guess on BOTH hands (agreement -0.97..-0.99), so the signs are swapped
        }
      }
      if (measured && haveGeo) {
        const double d = arm::dot(ax, geo);
        st.fingerAxisDotX100[s][f] = (int)(d * 100.0);
        if (d < 0.0) ++st.fingerFlips[s];
        if (!gunHand && f > 0 && vm::dabs(d) > 0.5 && vm::dabs(d) < 0.985) {   // 1.7.111 a free hand's fingers all bend about the knuckle line: a measured axis that is skewed (a finger splayed in the animation, "left middle finger broken") would swing the finger sideways
          const double sg = d < 0.0 ? -1.0 : 1.0;
          for (int i = 0; i < 3; ++i) ax[i] = geo[i] * sg;
          ++st.fingerAxisFixed[s];
        }
      }
      if (measured) ++st.fingerMeasured[s];
      else if (haveGeo) { for (int i = 0; i < 3; ++i) ax[i] = geo[i]; ++st.fingerGeometry[s]; }
      else { ++st.fingerNoAxis[s]; ++st.fingerSkip[s][f]; continue; }
      // how far each joint is bent now (along that axis) and how far it should be
      double bend[3], base = 0.0;
      for (int j = 0; j < 3; ++j) {
        double x[3];
        arm::cross(g[j], g[j + 1], x);
        bend[j] = vm::datan2(arm::dot(x, ax), arm::dot(g[j], g[j + 1]));
        if (!(f == 0 && j == 0)) base += bend[j];
      }
      double th[3];
      if (gunHand) {   // a hand on the gun: the animation's own grip is kept; the trigger finger pulls, the others open a little when the grip is let go
        double tgw = (f >= 2 && t->gunWrap > tg) ? t->gunWrap : tg;
        if (f >= 2 && t->gunLiveOpen > 0.0) {   // 1.7.111: the gun hand's fingers are usable: squeezed grip = the game's full fist, grip let go = they open by gunLiveOpen
          double g = (tg - 0.30) / 0.58; if (g < 0.0) g = 0.0; if (g > 1.0) g = 1.0;
          tgw = 1.0 - (t->gunLiveOpen > 1.0 ? 1.0 : t->gunLiveOpen) * (1.0 - g);
        }   // 1.7: the grip fingers stay wrapped (the controller's grip button is not used for the weapon: with it let go the fingers used to open to 40 %)
        const double pullDeg = t->trigPullDeg > 0.0 ? t->trigPullDeg : 55.0;   // 1.7.109
        const double want = f == 1 ? base + tg * pullDeg * rad : (f == 0 ? base : base * (0.4 + 0.6 * tgw));   // 1.7.113: the gun hand's thumb stays on the handle like the game's own hold (opened it stuck out and the hand looked like it floated beside the handle)
        for (int j = 0; j < 3; ++j) th[j] = bend[j] + kShare[f][j] * (want - base);
        st.fingerWantX10[s][f] = (int)(want / rad * 10.0);
        if (s == 0 && f == 1) ++st.gunFingerPasses;
      } else {
        double tgE = tg;
        if (s == 1 && f >= 1 && st.lMagWNow > 0.3 && t->gunWrap > 0.0) {   // 1.7.1: the left hand is on the gun's foregrip: its fingers stay wrapped around it too (with the grip button let go they used to open to 0)
          const double fl = t->gunWrap * 0.85 * st.lMagWNow * (1.0 - (t->grabWrap > 1.0 ? 1.0 : t->grabWrap));   // 1.7.109: wrapping the barrel the curl is set by the engine's wrap pose (a fist closed to 0.85 buried the fingertips in the palm)
          if (fl > tgE) { tgE = fl; if (f == 1) ++st.lWrapPasses; }
        }
        const double want = tgE * kTotal[f] * rad;
        const double gwp = (s == curlSup && f >= 1 && t->grabWrap > 0.0) ? (t->grabWrap > 1.0 ? 1.0 : t->grabWrap) : 0.0;   // 1.7.109: round the barrel the fingertip bends too (knuckle .40, middle .40, tip .20 of the bend), 1.7.98 kept it nearly straight
        static const double kShareW[3] = {0.40, 0.40, 0.20};
        for (int j = 0; j < 3; ++j) th[j] = ((1.0 - gwp) * kShareL[f][j] + gwp * kShareW[j]) * want;   // 1.7.99: a hand with nothing in it (either hand) takes the softer finger shape the left hand got in 1.7.98: knuckle and middle joint carry the bend, the fingertip stays nearly straight
        st.fingerWantX10[s][f] = (int)(want / rad * 10.0);
      }
      st.fingerBaseX10[s][f] = (int)(base / rad * 10.0);
      for (int j = 0; j < 3; ++j) { const double gwm = (s == curlSup && f >= 1 && !gunHand && t->grabWrap > 0.0) ? (t->grabWrap > 1.0 ? 1.0 : t->grabWrap) : 0.0; const double mx = (!gunHand ? kMaxL[j] + (j == 2 ? 28.0 * gwm : 0.0) : kMax[j]); if (th[j] > mx * rad) th[j] = mx * rad; if (th[j] < -8.0 * rad) th[j] = -8.0 * rad; }
      if (gunHand && s == 0 && f >= 1) { for (int j = 0; j < 3; ++j) gunBend[f][j] = th[j]; gunBendOk[f] = 1; }   // 1.7.181
      if (!gunHand && s == 1 && f >= 1 && mirrorBendOn && gunBendOk[f]) for (int j = 0; j < 3; ++j) th[j] = gunBend[f][j];   // 1.7.181: the mirror image of the game's grip
      if (s == 1 && f >= 1 && !gunHand && t->leftFingerKeep > 0.0) {   // 1.7.103 the supporting hand takes the game's own finger pose: no made-up curl while it keeps
        const double keep = t->leftFingerKeep > 1.0 ? 1.0 : t->leftFingerKeep;
        for (int j = 0; j < 3; ++j) th[j] = bend[j] + (1.0 - keep) * (th[j] - bend[j]);
        if (f == 1) { if (keep > 0.97) ++st.leftFingerKept; else ++st.leftFingerBlend; }
      }
      { double fin = 0.0; for (int j = 0; j < 3; ++j) { if (f == 0 && j == 0) continue; fin += th[j]; } st.fingerFinalX10[s][f] = (int)(fin / rad * 10.0); }
      for (int j = 0; j < 3; ++j) {
        if (f == 0 && j == 0) continue;
        double d = th[j] - bend[j];
        if (d > 100.0 * rad) d = 100.0 * rad;
        if (d < -100.0 * rad) d = -100.0 * rad;
        if (vm::dabs(d) < 0.2 * rad) continue;
        const int root = b[j];
        unsigned char mask[MAXB];
        for (int i = 0; i < n; ++i) mask[i] = (unsigned char)(i == root || (i > root && c.parent[i] >= 0 && mask[c.parent[i]]));
        double piv[3], Q[9];
        sp.point_world(world + (size_t)16 * root + 12, piv);
        weight::axis_angle(ax, d, Q);
        sub_rotate(world, n, mask, sp, piv, Q);
        const int d10 = (int)(vm::dabs(d) / rad * 10.0);
        if (d10 > st.fingerMaxDeltaX10[s]) st.fingerMaxDeltaX10[s] = d10;
      }
      if (logged < 16 && (tg > 0.05)) {
        ++logged;
        G::log("FINGER %s %d: axis from the %s (measured vs geometry %.2f), bends now %.1f/%.1f/%.1f deg (total %.1f), wanted total %.1f (curl %.2f%s)",
               s ? "left" : "right", f, measured ? "animation" : "hand geometry", measured && haveGeo ? arm::dot(ax, geo) : 9.0, bend[0] / rad, bend[1] / rad, bend[2] / rad, base / rad,
               st.fingerWantX10[s][f] / 10.0, tg, gunHand ? ", gun hand" : "");
      }
    }
    if (s == 0 && gunHand && t->rdirOk && st.gripShiftClock) {   // 1.7.7 where the fist really is relative to the weapon: the centre of the four fingers' joints, in the weapon's frame (cm)
      double C[3] = {0, 0, 0}; int nj = 0;
      for (int f = 1; f < 5; ++f) { const int* b = c.fing[s][f]; if (b[0] < 0) continue; for (int k = 0; k < 4; ++k) { double p[3]; sp.point_world(world + (size_t)16 * b[k] + 12, p); for (int i = 0; i < 3; ++i) C[i] += p[i]; ++nj; } }
      if (nj >= 8) {
        for (int i = 0; i < 3; ++i) C[i] /= nj;
        double wo[3]; for (int i = 0; i < 3; ++i) wo[i] = t->grip[i] + (double)st.gripShift[i];   // the weapon's origin as slid by the hand fit (before the menu's fit offsets)
        double d[3] = {C[0] - wo[0], C[1] - wo[1], C[2] - wo[2]}, rt[3];
        arm::cross(t->rdir, t->rup, rt);
        const double cm = t->fpm > 0.1 ? 100.0 / t->fpm : 30.48;
        const int k = t->gunLenFt > 0.0 ? 0 : 1;
        const double c3[3] = {arm::dot(d, t->rdir) * cm, arm::dot(d, t->rup) * cm, arm::dot(d, rt) * cm};
        ++st.ffN[k]; for (int i = 0; i < 3; ++i) { st.ffSum[k][i] += c3[i]; st.ffLast[k][i] = c3[i]; }
        double ax2[3] = {across[0], across[1], across[2]};
        if (haveAcross) { const double ca = arm::dot(ax2, t->rdir); st.ffAcrossLast[k] = ca; st.ffAcrossSum[k] += ca; ++st.ffAcrossN[k]; }
      }
    }
  }
  // affine inverse of a 3x4 bone matrix in the row-vector form (p' = p A + t)
  static int inv34(const float* m, float* o) {
    double A[9];
    for (int r = 0; r < 3; ++r) for (int k = 0; k < 3; ++k) A[r * 3 + k] = m[r * 4 + k];
    const double c0 = A[4] * A[8] - A[5] * A[7], c1 = A[5] * A[6] - A[3] * A[8], c2 = A[3] * A[7] - A[4] * A[6];
    const double d = A[0] * c0 + A[1] * c1 + A[2] * c2;
    if (!(vm::dabs(d) > 1e-12)) return 0;
    const double id = 1.0 / d;
    const double Ai[9] = {c0 * id, (A[2] * A[7] - A[1] * A[8]) * id, (A[1] * A[5] - A[2] * A[4]) * id,
                          c1 * id, (A[0] * A[8] - A[2] * A[6]) * id, (A[2] * A[3] - A[0] * A[5]) * id,
                          c2 * id, (A[1] * A[6] - A[0] * A[7]) * id, (A[0] * A[4] - A[1] * A[3]) * id};
    for (int i = 0; i < 16; ++i) o[i] = 0;
    for (int r = 0; r < 3; ++r) for (int k = 0; k < 3; ++k) o[r * 4 + k] = (float)Ai[r * 3 + k];
    for (int k = 0; k < 3; ++k) o[12 + k] = (float)-(m[12] * Ai[k] + m[13] * Ai[3 + k] + m[14] * Ai[6 + k]);
    o[15] = 1.0f;
    return finite16(o);
  }
  // 0.85 PKE as the wand-slot model: its place relative to the hand in the game's own pose (through the unmoved body matrix), then put on the hand after the IK
  struct PkeWand { int ok, hand; double off[3], rel[9], sc[3]; };
  static inline float pwOut[16];
  static inline int64_t pwClock;
  static inline int pwHave;
  static void pkew_capture(const uint8_t* local, const ArmTargets* t, PkeWand* g) {
    g->ok = 0; g->hand = -1;
    ++st.pwCalls;
    arm::Space spO;
    if (!t->origOn || !spO.set(t->origBody)) { ++st.pwNoPose; return; }
    double Mh[2][9], Ph[2][3], dist[2] = {1e9, 1e9};
    const double Wp[3] = {t->wandM[12], t->wandM[13], t->wandM[14]};
    for (int s = 0; s < 2; ++s) {
      if (c.arm[s].U < 0) continue;
      float Pw[16];
      if (!pose_world(local, c.arm[s].H, Pw)) continue;
      spO.point_world(Pw + 12, Ph[s]);
      frame_world(spO, Pw, Mh[s]);
      const double d[3] = {Wp[0] - Ph[s][0], Wp[1] - Ph[s][1], Wp[2] - Ph[s][2]};
      dist[s] = arm::len(d);
      st.pwDistFt[s] = (float)dist[s];
    }
    const int h = dist[0] <= dist[1] + 0.5 ? 0 : 1;   // the right hand unless the left is clearly nearer
    if (dist[h] > 1e8) { ++st.pwNoPose; return; }
    double Mw[9];
    for (int r = 0; r < 3; ++r) {
      double row[3] = {t->wandM[r * 4], t->wandM[r * 4 + 1], t->wandM[r * 4 + 2]};
      g->sc[r] = arm::len(row);
      if (!(g->sc[r] > 1e-6)) { ++st.pwNoPose; return; }
      for (int k = 0; k < 3; ++k) Mw[k * 3 + r] = row[k] / g->sc[r];
    }
    double MT[9];
    weight::transpose3(Mh[h], MT);
    const double d[3] = {Wp[0] - Ph[h][0], Wp[1] - Ph[h][1], Wp[2] - Ph[h][2]};
    arm::apply3(MT, d, g->off);
    weight::mul3(MT, Mw, g->rel);
    g->ok = 1; g->hand = h;
    for (int i = 0; i < 3; ++i) st.pwOff[i] = (float)g->off[i];
  }
  static void pkew_apply(const float* world, const arm::Space& sp, const PkeWand* g) {
    if (!g->ok) return;
    const float* Hn = world + (size_t)16 * c.arm[g->hand].H;
    double Mf[9], Pf[3], o[3], R[9];
    frame_world(sp, Hn, Mf);
    sp.point_world(Hn + 12, Pf);
    arm::apply3(Mf, g->off, o);
    weight::mul3(Mf, g->rel, R);
    float out[16];
    for (int i = 0; i < 16; ++i) out[i] = 0;
    for (int r = 0; r < 3; ++r) for (int k = 0; k < 3; ++k) out[r * 4 + k] = (float)(R[k * 3 + r] * g->sc[r]);
    for (int k = 0; k < 3; ++k) out[12 + k] = (float)(Pf[k] + o[k]);
    out[15] = 1.0f;
    if (!finite16(out)) return;
    pwHave = 0;
    for (int i = 0; i < 16; ++i) pwOut[i] = out[i];
    pwClock = G::clock();
    pwHave = 1;
    ++st.pwOut[g->hand];
  }
  static int pke_wand_read(float* out, int64_t* clock) {
    if (!pwHave) return 0;
    for (int i = 0; i < 16; ++i) out[i] = pwOut[i];
    *clock = pwClock;
    return 1;
  }
  // 0.84 PKE: where the game's PKE bones are relative to a hand in the game's own pose (taken before anything is moved)
  struct PkeGrab { int ok, hand; float off0[16], off1[16]; };
  static inline int pkeKeepNow;
  static void pke_capture(const float* world, const arm::Space& sp, PkeGrab* g) {
    g->ok = 0; g->hand = -1;
    ++st.pkeCalls;
    if (c.bPke[0] < 0) { ++st.pkeNoBones; return; }
    double Pp[3], dist[2] = {1e9, 1e9};
    sp.point_world(world + (size_t)16 * c.bPke[0] + 12, Pp);
    for (int s = 0; s < 2; ++s) {
      if (c.arm[s].U < 0) continue;
      double Ph[3];
      sp.point_world(world + (size_t)16 * c.arm[s].H + 12, Ph);
      dist[s] = vm::dsqrt((Pp[0] - Ph[0]) * (Pp[0] - Ph[0]) + (Pp[1] - Ph[1]) * (Pp[1] - Ph[1]) + (Pp[2] - Ph[2]) * (Pp[2] - Ph[2]));
      st.pkeDistFt[0][s] = (float)dist[s];
      if (c.bPke[1] >= 0) {
        double P1[3];
        sp.point_world(world + (size_t)16 * c.bPke[1] + 12, P1);
        st.pkeDistFt[1][s] = (float)vm::dsqrt((P1[0] - Ph[0]) * (P1[0] - Ph[0]) + (P1[1] - Ph[1]) * (P1[1] - Ph[1]) + (P1[2] - Ph[2]) * (P1[2] - Ph[2]));
      }
    }
    int h = dist[0] <= dist[1] + 0.6 ? 0 : 1;   // the right hand unless the left is clearly closer
    if (dist[h] > 1e8) { ++st.pkeNoHand; return; }
    alignas(16) float inv[16];
    const float* H = world + (size_t)16 * c.arm[h].H;
    if (!inv34(H, inv)) { ++st.pkeNoHand; return; }
    alignas(16) float o0[16] = {0}, o1[16] = {0};
    G::mul(o0, world + (size_t)16 * c.bPke[0], inv);
    if (c.bPke[1] >= 0) G::mul(o1, world + (size_t)16 * c.bPke[1], inv);
    if (!finite16(o0) || (c.bPke[1] >= 0 && !finite16(o1))) { ++st.pkeNoHand; return; }
    for (int i = 0; i < 16; ++i) { g->off0[i] = o0[i]; g->off1[i] = o1[i]; }
    g->ok = 1; g->hand = h;
    st.pkeHand = h;
    st.pkeOffLocal[0] = o0[12]; st.pkeOffLocal[1] = o0[13]; st.pkeOffLocal[2] = o0[14];
  }
  static void pke_apply(float* world, const PkeGrab* g) {
    if (!g->ok) return;
    const float* H = world + (size_t)16 * c.arm[g->hand].H;
    alignas(16) float n0[16] = {0}, n1[16] = {0}, f0[16], f1[16];
    for (int i = 0; i < 16; ++i) { f0[i] = g->off0[i]; f1[i] = g->off1[i]; }
    G::mul(n0, f0, H);
    if (c.bPke[1] >= 0) G::mul(n1, f1, H);
    if (!finite16(n0) || (c.bPke[1] >= 0 && !finite16(n1))) return;
    copy12(world + (size_t)16 * c.bPke[0], n0);
    if (c.bPke[1] >= 0) copy12(world + (size_t)16 * c.bPke[1], n1);
    ++st.pkeApplied[g->hand];
    pkeKeepNow = 1;
  }

  // W2: the body's model -> world matrix (16 floats). Returns 1 if at least one arm moved.
  static int apply(uintptr_t actor, const float* W2, const ArmTargets* t) {
    if (!actor || !W2 || !t) return 0;
    if (!(t->rightOn || t->leftOn || t->bodyOn)) return 0;
    ++st.calls;
    const uint8_t* A = (const uint8_t*)actor;
    const uint8_t* M = A + layout::kOffActorModel;
    if (!G::readable(A + layout::kOffActorBoneIdx, 24, 0) || !G::readable(M + layout::kOffModelBoneCount, 4, 0) || !G::readable(M + layout::kOffModelLocal, 0x24, 0) ||
        !G::readable(M + layout::kOffModelSkeleton, 8, 0)) { ++st.noModel; return 0; }
    const uint8_t* skel = *(const uint8_t* const*)(M + layout::kOffModelSkeleton);
    const uint8_t* local = *(const uint8_t* const*)(M + layout::kOffModelLocal);
    const uint8_t* engineLocal = local;
    float* world = *(float* const*)(M + layout::kOffModelWorld);
    const int n = *(const int*)(M + layout::kOffModelBoneCount);
    if (!skel || !local || !world || n < 8 || n > MAXB || !G::readable(skel + 0x88, 4, 0) || *(const int*)(skel + 0x88) != n ||
        !G::readable(skel, 0x8c + (size_t)n * 0x4c, 0) || !G::readable(local, (size_t)n * 40, 0) || !G::readable(world, (size_t)n * 64, 1)) {
      ++st.badLayout;
      return 0;
    }
    if (c.model != (uintptr_t)M || c.skel != (uintptr_t)skel || c.n != n) { ARMCORE_CRUMB("apply:revalidate", n); revalidate(M, skel, n, A); }
    if (!c.ok) { ++st.badBones; return 0; }
    // A completed first-eye pose is the pose for the whole stereo pair. Do not
    // step filters/IK or reapply torso motion on already modified bones. If the
    // engine rebuilt the skeleton for eye two, restore the same finished pose.
    bool samePair = t->stereoPair && stereoCache.pair == t->stereoPair &&
        stereoCache.actor == actor && stereoCache.skel == (uintptr_t)skel &&
        stereoCache.local == (uintptr_t)local && stereoCache.world == (uintptr_t)world && stereoCache.n == n;
    for (int i = 0; samePair && i < 16; ++i)
      if ((i & 3) != 3 && vm::dabs((double)W2[i] - stereoCache.W[i]) > 1e-6) samePair = false;
    if (samePair && (t->stereoRole == 1 || t->stereoRole == 2)) {
      G::ensure((void*)M);
      for (int i = 0; i < n; ++i) for (int k = 0; k < 16; ++k) if ((k & 3) != 3) world[16 * i + k] = stereoCache.bones[i][k];
      ++st.stereoReused;
      return stereoCache.result;
    }
    if (t->stereoRole == 1) stereoCache.pair = 0;
    ARMCORE_CRUMB("apply:start", st.calls);
    collapse_undo(world, n);   // 0.71: bones squashed by the last call go back to what they held, before anything reads them
    arm::Space sp;
    if (!sp.set(W2)) { ++st.spaceFail; return 0; }
    const int64_t tc0 = G::clock();
    ARMCORE_CRUMB("apply:ensure", 0);
    G::ensure((void*)M);   // every bone's matrix valid (the engine computes them when the animation changed the pose)
    static struct { uintptr_t actor, skel; int n, item, have, handHave; float handRel[16]; alignas(16) uint8_t neutral[MAXB * 40], view[MAXB * 40]; } reload;
    if (reload.actor != actor || reload.skel != (uintptr_t)skel || reload.n != n || (reload.item != t->itemId && !(t->switchHold && t->reloadHold))) {
      reload.actor = actor; reload.skel = (uintptr_t)skel; reload.n = n; reload.item = t->itemId; reload.have = reload.handHave = 0;
    }
    if (!t->reloadHold) {
      for (int i = 0; i < n * 40; ++i) reload.neutral[i] = local[i];
      reload.have = 1;
    } else if (reload.have && c.torsoOk) {
      for (int bone = 0; bone < n; ++bone) for (int i = 0; i < 40; ++i)
        reload.view[bone * 40 + i] = c.inSpine[bone] ? reload.neutral[bone * 40 + i] : local[bone * 40 + i];
      local = reload.view; // private render pose; never write to the game's animation locals
      for (int bone = 0; bone < n; ++bone) {
        alignas(16) float matrix[16] = {};
        G::local(local + bone * 40, matrix);
        if (c.parent[bone] >= 0) G::mul(world + bone * 16, matrix, world + c.parent[bone] * 16);
        else for (int i = 0; i < 16; ++i) world[bone * 16 + i] = matrix[i];
      }
    }
    const int64_t tc1 = G::clock();
    // 0.75 the gun hand as the game's own pose has it (position and axes in the game's own world), taken from the local poses so that nothing the
    // probe did to the body (moved, shrunk to the player's size, turned, leaned) is in it. The wand model stays where the game has it until the
    // hook moves it, so wand and hand are measured in the same untouched frame: the hand then follows the gun rigidly, whatever the body does.
    struct { int ok, matOk; double pos[3]; double ax[9]; float W[16]; } gh = {};
    gh.ok = 0; gh.matOk = 0;
    if (t->rightOn && t->origOn && c.arm[0].U >= 0) {
      float Pw[16];
      arm::Space spO;
      if (pose_world(local, c.arm[0].H, Pw) && spO.set(t->origBody)) {
        spO.point_world(Pw + 12, gh.pos);
        frame_world(spO, Pw, gh.ax);
        gh.ok = vm::is_finite_f((float)gh.pos[0]) && vm::is_finite_f((float)gh.pos[1]) && vm::is_finite_f((float)gh.pos[2]);
        // Exact untouched game-hand matrix in the same world frame as the game's wand/entity.
        G::mul(gh.W, Pw, t->origBody);
        gh.matOk = finite16(gh.W);
        {   // data: is the rebuilt pose the engine's own? (compared while the engine's matrix is still the one it computed)
          const float* hb = world + (size_t)16 * c.arm[0].H;
          const ArmOut& o0 = ao[0];
          if (!(o0.have && o0.world == world && same12(hb, o0.h))) {
            double dx = (double)Pw[12] - hb[12], dy = (double)Pw[13] - hb[13], dz = (double)Pw[14] - hb[14];
            const int e100 = (int)(vm::dsqrt(dx * dx + dy * dy + dz * dz) * 100.0);
            ++st.gripCheckN; if (e100 > st.gripCheckMaxX100) st.gripCheckMaxX100 = e100;
          }
        }
      }
      if (!gh.ok) ++st.gripNoPose;
    }
    PkeGrab pk;
    pk.ok = 0;
    pkeKeepNow = 0;
    PkeWand pw;
    pw.ok = 0;
    if (t->pkeWand) pkew_capture(local, t, &pw);   // 0.85
    if (t->pkeAttach) pke_capture(world, sp, &pk);   // 0.84: the PKE's place relative to the hand, in the game's own pose, before the body is moved
    ARMCORE_CRUMB("apply:torso", 0);
    torso_pass(world, local, n, sp, t);
    const int64_t tc2 = G::clock();
    int movedAny = t->bodyOn ? 1 : 0;
    // 1.7.170: left-handed play: where each shoulder is before anything moves it (each arm is moved to the other one's place below)
    double shoulderAt[2][3]; int mirror = 0;
    if (t->mirrorArms == 2 && c.arm[0].U >= 0 && c.arm[1].U >= 0 && c.clav[0] >= 0 && c.clav[1] >= 0 &&   // 1.7.174: the shoulder swap of 1.7.170-173 is no longer used (mirrorArms 1 = each arm drawn at the other controller, below)

        fresh_shoulder(world, local, 0, sp, shoulderAt[0]) && fresh_shoulder(world, local, 1, sp, shoulderAt[1])) {   // 1.7.172: from the local poses (the same in both eyes of a pair)
      double d[3] = {shoulderAt[0][0] - shoulderAt[1][0], shoulderAt[0][1] - shoulderAt[1][1], shoulderAt[0][2] - shoulderAt[1][2]};
      const double w = arm::len(d);
      if (w > 0.2 && w < 3.0) mirror = 1;
    }
    if (t->mirrorArms == 2 && !mirror) ++st.mirrorBad;
    // 1.7.181 left-handed: the supporting hand's target is worked out as a LEFT hand (the game's own barrel hold, wrap, under-barrel magnet, fingers) at the MIRROR IMAGE of the real free
    // controller in the gun's plane (through the gun's origin, normal = barrel x up). Its result is mirrored back below, for the right arm that is really drawn there.
    if (t->mirrorArms == 1) for (int f = 0; f < 5; ++f) gunBendOk[f] = 0;   // 1.7.181: only this pass's gun-hand fingers
    ArmTargets tMir; const ArmTargets* tReal = t; double mirN[3] = {0, 0, 0}, mirP[3] = {0, 0, 0}; int mirOk = 0;
    if (t->mirrorArms == 1 && t->rdirOk && t->rightOn) {
      double nn[3]; arm::cross(t->rdir, t->rup, nn);
      if (arm::unit(nn, mirN)) {
        mirOk = 1;
        for (int i = 0; i < 3; ++i) mirP[i] = t->gunPosOk ? t->gunPos[i] : t->grip[i];
        if (t->leftOn) {
          tMir = *t;
          reflect_point(t->lpos, mirP, mirN, tMir.lpos); reflect_dir(t->lfwd, mirN, tMir.lfwd); reflect_dir(t->lup, mirN, tMir.lup);
          tMir.grabLatX = -t->grabLatX;   // the sideways place against the barrel is in (barrel x up) = the plane's normal
          t = &tMir;
        }
      }
    }
    int solvedArm[2] = {0, 0};   // 1.7.172: also when a clavicle is missing or unreadable
    for (int s = 0; s < 2; ++s) {
      if (!(s == 0 ? t->rightOn : t->leftOn)) { ++st.noTarget[s]; disp.ok[s] = 0; continue; }   // 1.7.174: and nothing for the other arm to be drawn at
      ArmInfo& a = c.arm[s];
      if (a.U < 0) continue;
      double sig[128];   // 1.7.110: the signature grew past 64 values (the pass skip compared a cut-off one)
      const int sigN = arm_sig(s, W2, t, sig);
      {   // 0.66: the engine does not rebuild the pose between the two eyes of a pair. If both arm matrices are still the ones we wrote
          // and the targets are the same, the result would be the same: leave it (and keep the old miss, it still holds)
        ArmOut& o = ao[s];
        int same = !(s == 1 && t->nativeSupport) && o.have && o.world == world && o.sigN == sigN && same12(world + (size_t)16 * a.U, o.u) && same12(world + (size_t)16 * a.H, o.h);
        for (int i = 0; same && i < sigN; ++i) if (sig[i] != o.sig[i]) same = 0;
        if (same) {
          ++st.armSkipped[s];
          st.missClock[s] = tc0;
          w[s].world = world; w[s].U = a.U; w[s].H = a.H; copy12(w[s].u, o.u); copy12(w[s].h, o.h); w[s].have = 1;
          movedAny = 1;
          continue;
        }
      }
      float Wc[MAXPATH][16];
      if ((t->floatingArms || t->shoulderPullDeg > 0.5 || t->shoulderSlideFt > 0.01 || mirror) && c.clav[s] >= 0) rebuild_bone(world, local, c.clav[s]);   // 1.7.172: also for left-handed: an earlier pass's swap is undone first, so the swap below is done exactly once
      chain_world(local, world, a, Wc);
      double S[3], E0[3], Hp[3];
      sp.point_world(Wc[0] + 12, S);
      sp.point_world(Wc[1] + 12, E0);
      sp.point_world(Wc[a.plen - 1] + 12, Hp);
      double dispLf[3] = {0, 0, 1}, dispLu[3] = {0, 1, 0}; int dispLOk = 0;   // 1.7.174
      disp.ok[s] = 0; disp.okF[s] = 0;   // solved afresh: set again below once the target is known
      double HpWand[3] = {Hp[0], Hp[1], Hp[2]}; int mirShifted = 0;   // 1.7.170: the hand as the game placed it (the gun's rigid motion is measured from here, not from the swapped arm)
      if (mirror && !t->floatingArms) {   // 1.7.170: this arm now hangs from the other shoulder
        double delta[3]; for (int i = 0; i < 3; ++i) delta[i] = shoulderAt[1 - s][i] - S[i];
        sub_shift(world, n, c.inClav[s], sp, delta);
        chain_world(local, world, a, Wc);
        sp.point_world(Wc[0] + 12, S); sp.point_world(Wc[1] + 12, E0);
        sp.point_world(Wc[a.plen - 1] + 12, Hp);
        ++st.mirrored[s]; mirShifted = 1;
      }
      if (t->floatingArms && t->eyeOn && c.clav[s] >= 0 && t->fpm > 0.1 && t->fpm < 100.0) {
        double sy, cy; vm::dsincos(t->bodyYaw, &sy, &cy);
        const double side = ((s == 0) != (mirror != 0) ? 0.17 : -0.17) * t->fpm;   // 1.7.170: left-handed: the sides swap
        // Stay Puft / scripted floating arms: keep the shoulders well behind the eyes so the
        // forearms and the collapsed torso cannot sit across the center sightline. Controller
        // targets still own the hands; this moves only the rendered shoulder roots.
        const double front = -0.16 * t->fpm;
        const double anchor[3] = {t->eyeTarget[0] + side * cy + front * sy,
                                  t->eyeTarget[1] - 0.24 * t->fpm,
                                  t->eyeTarget[2] - side * sy + front * cy};
        double delta[3]; for (int i = 0; i < 3; ++i) delta[i] = anchor[i] - S[i];
        sub_shift(world, n, c.inClav[s], sp, delta);
        chain_world(local, world, a, Wc);
        sp.point_world(Wc[0] + 12, S); sp.point_world(Wc[1] + 12, E0);
        sp.point_world(Wc[a.plen - 1] + 12, Hp);
      }
      if (!mirShifted) for (int i = 0; i < 3; ++i) HpWand[i] = Hp[i];   // unchanged without left-handed play
      {   // the bone matrices must be in the space the body is drawn in: the shoulder near the actor, an arm a human length
        const double lim = 10.0;
        if (vm::dabs(S[0] - sp.t[0]) > lim || vm::dabs(S[1] - sp.t[1]) > lim || vm::dabs(S[2] - sp.t[2]) > lim) { ++st.badSpace[s]; continue; }
        double q1[3] = {E0[0] - S[0], E0[1] - S[1], E0[2] - S[2]}, q2[3] = {Hp[0] - E0[0], Hp[1] - E0[1], Hp[2] - E0[2]};
        double a1 = arm::len(q1), a2 = arm::len(q2);
        if (!(a1 > 0.3 && a1 < 3.0 && a2 > 0.3 && a2 < 3.0)) { ++st.badLen[s]; continue; }
      }
      double T[3], Qh[9];
      int reloadHandOk = 0; float reloadHand[16], tracked[16];
      if (s == 0 && t->reloadHold && reload.handHave && t->rdirOk) {
        float grip[3], forward[3], up[3];
        for (int i = 0; i < 3; ++i) { grip[i] = (float)t->grip[i]; forward[i] = (float)t->rdir[i]; up[i] = (float)t->rup[i]; }
        reloadHandOk = handprop::tracked_frame(grip, forward, up, tracked) && handprop::place(reload.handRel, tracked, reloadHand);
      }
      int nativeOk = 0;
      float nativeHand[16];
      if (s == 1 && t->nativeSupport && t->grabW > 0.001 && t->rightOn && t->gunLenFt > 0.2 &&
          t->origOn && gh.matOk && handHave && handActor == actor) {
        float localHand[16] = {}, gameLeft[16] = {}, relHand[16];
        if (pose_world(local, a.H, localHand)) {
          G::mul(gameLeft, localHand, t->origBody);
          const double dx = gameLeft[12] - gh.W[12], dy = gameLeft[13] - gh.W[13], dz = gameLeft[14] - gh.W[14];
          const double reach = vm::dsqrt(dx * dx + dy * dy + dz * dz);
          nativeOk = reach > 0.15 && reach < 3.0 && handprop::relative(gameLeft, gh.W, relHand) &&
            handprop::place(relHand, handFinalW, nativeHand);
        }
      }
      int gripOn = 0, farGrip = 0;
      if (s == 0) {
        double d[3] = {HpWand[0] - t->wandP0[0], HpWand[1] - t->wandP0[1], HpWand[2] - t->wandP0[2]}, rd[3];
        arm::apply3(t->wandR, d, rd);
        for (int i = 0; i < 3; ++i) T[i] = t->grip[i] + rd[i];
        for (int i = 0; i < 9; ++i) Qh[i] = t->wandR[i];
        farGrip = arm::len(d) >= 0.8;   // 0.79: the hand is nowhere near the wand's origin (no weapon in hand)
        if (gh.ok) {   // 0.75: the hand is where the game's own pose has it relative to the wand, turned with the wand (see gh above)
          double d0[3] = {gh.pos[0] + t->sceneShift[0] - t->wandP0[0],
                          gh.pos[1] + t->sceneShift[1] - t->wandP0[1],
                          gh.pos[2] + t->sceneShift[2] - t->wandP0[2]}, rd0[3], T0[3];
          arm::apply3(t->wandR, d0, rd0);
          for (int i = 0; i < 3; ++i) T0[i] = t->grip[i] + rd0[i];
          const double dl = arm::len(d0);
          if (dl < 0.8) {   // 0.79: a hand within about 24 cm of the wand's origin is a real grip (0.78 accepted 3 ft: with no weapon in hand the hand sat 72 cm away and flew off)
            const double ex = T0[0] - T[0], ey = T0[1] - T[1], ez = T0[2] - T[2];
            const int e100 = (int)(vm::dsqrt(ex * ex + ey * ey + ez * ez) * 100.0);
            st.gripOldErrSumX100 += e100; if (e100 > st.gripOldErrMaxX100) st.gripOldErrMaxX100 = e100; if (e100 > 10) ++st.gripOldErrOver10;
            const int o100 = (int)(dl * 100.0);
            if (st.gripOffN == 0 || o100 < st.gripOffMinX100) st.gripOffMinX100 = o100;
            if (o100 > st.gripOffMaxX100) st.gripOffMaxX100 = o100;
            st.gripOffSumX100 += o100; ++st.gripOffN;
            if (st.gripPrevOk) {
              const double jx = d0[0] - st.gripPrev[0], jy = d0[1] - st.gripPrev[1], jz = d0[2] - st.gripPrev[2];
              const int j100 = (int)(vm::dsqrt(jx * jx + jy * jy + jz * jz) * 100.0);
              if (j100 > st.gripJumpMaxX100) st.gripJumpMaxX100 = j100;
            }
            for (int i = 0; i < 3; ++i) { st.gripPrev[i] = (float)d0[i]; st.gripOff[i] = (float)d0[i]; }
            st.gripPrevOk = 1;
            for (int i = 0; i < 3; ++i) T[i] = T0[i];
            if (t->gripAtHand) {   // 0.93: the wrist goes exactly to the controller; the gun slides back by the hand's offset, so the handle is in the real hand
              // 1.7.7: ... but the controller point is the middle of the real palm, and the wrist is a hand length behind it. Like the left hand (free_wrist) the wrist now sits back along the
              // pointing direction and a little below, and the weapon slides back with it (it keeps the game's own hand-to-weapon relation), so the fist, not the wrist, is at the real hand.
              double wb[3] = {0, 0, 0};
              if (t->rdirOk && t->gunWristBackFt > 0.0) for (int i = 0; i < 3; ++i) wb[i] = t->rdir[i] * t->gunWristBackFt + t->rup[i] * t->gunWristDownFt;
              for (int i = 0; i < 3; ++i) { T[i] = t->grip[i] - wb[i]; st.gripShift[i] = (float)(-rd0[i] - wb[i]); }
              if (t->rdirOk) {   // the numbers for the log (cm): where the game keeps the hand relative to the weapon, in the controller's axes
                const int k = t->gunLenFt > 0.0 ? 0 : 1;
                double rt[3]; arm::cross(t->rdir, t->rup, rt);
                const double cm = t->fpm > 0.1 ? 100.0 / t->fpm : 30.48;   // game feet -> cm (fpm = game feet per metre)
                const double c3[3] = {arm::dot(rd0, t->rdir) * cm, arm::dot(rd0, t->rup) * cm, arm::dot(rd0, rt) * cm};
                ++st.wfN[k]; for (int i = 0; i < 3; ++i) { st.wfOffSum[k][i] += c3[i]; st.wfOff[k][i] = c3[i]; }
                st.wfLast[k] = arm::len(wb) * cm; st.wfBackSum[k] += st.wfLast[k];
              }
              st.gripShiftClock = tc0; ++st.gripHandN;
              { const int sh100 = (int)(arm::len(rd0) * 100.0); st.gripShiftSumX100 += sh100; if (sh100 > st.gripShiftMaxX100) st.gripShiftMaxX100 = sh100; }
            }
            gripOn = 1; farGrip = 0;
            ++st.gripFixed;
          } else farGrip = 1;
        }
        // 1.7.57: the right wrist is a tracked-controller target, not a view-model-animation target.
        // The game's live hand pose is still used above to learn the one-time gun slide, but a missing/rebuilt
        // hand bone during a weapon/view-model change may never move or rotate the tracked right hand.
        if (t->gripAtHand && t->rdirOk) {
          double wb[3] = {0, 0, 0};
          if (t->gunWristBackFt > 0.0) for (int i = 0; i < 3; ++i) wb[i] = t->rdir[i] * t->gunWristBackFt + t->rup[i] * t->gunWristDownFt;
          for (int i = 0; i < 3; ++i) T[i] = t->grip[i] - wb[i];
          double fa[3], fu[3]; arm::sub(Hp, E0, fa);
          if (arm::unit(fa, fu)) hand_from_controller(fu, t->rdir, t->rup, Qh);
        }
      } else {
        arm::free_wrist(t->lpos, t->lfwd, t->lup, t->wristBackFt, t->wristDownFt, T);
        if (st.lWrapNow <= 0.01) st.lOrbitPrevOk = 0;   // 1.7.220: the last pass did not hold the barrel wrapped: the orbit starts again from the wanted one
        st.lMagWNow = 0.0; st.lWrapNow = 0.0;
        double fa[3], fu[3];
        arm::sub(Hp, E0, fa);
        double lf[3] = {t->lfwd[0], t->lfwd[1], t->lfwd[2]}, lu[3] = {t->lup[0], t->lup[1], t->lup[2]};   // 1.7.104: lu = the up the left hand turns by (the controller's, steadied toward the gun's up on the foregrip)
        if (!nativeOk && t->underW > 0.001 && t->rightOn && t->rdirOk && t->gunLenFt > 0.2) {   // fallback for a missing native support pose
          const double L = t->gunLenFt;
          const double fk = (t->fpm > 0.1 && t->fpm < 100.0) ? t->fpm / 3.28084 : 1.0;   // 1.7.110: the real-hand distances below are metres turned to game feet: they follow the world size (fpm), like the hand itself
          double base[3], rel[3];
          for (int i = 0; i < 3; ++i) { base[i] = t->gunPosOk ? t->gunPos[i] : t->grip[i]; rel[i] = t->lpos[i] - base[i]; }
          double along = arm::dot(rel, t->rdir);
          const double lo = 0.25 * L, hi = 0.95 * L;
          const int clamped = along < lo || along > hi;
          if (along < lo) along = lo; if (along > hi) along = hi;
          double Gp[3], dx[3];
          for (int i = 0; i < 3; ++i) { Gp[i] = base[i] + t->rdir[i] * along - t->rup[i] * t->underFt; dx[i] = Gp[i] - t->lpos[i]; }
          const double dist = arm::len(dx);
          // 1.7.21: the 1.7.20 log: the hand was pushed 13 cm on average and up to 36 cm (it felt detached from your real hand). The pull now fades with distance: full within 14 cm, none from 30 cm.
          double wd = (1.0 * fk - dist) / (0.55 * fk); wd = wd < 0.0 ? 0.0 : (wd > 1.0 ? 1.0 : wd); wd = wd * wd * (3.0 - 2.0 * wd);
          const double gw = t->grabW < 0.0 ? 0.0 : (t->grabW > 1.0 ? 1.0 : t->grabW);
          wd = gw + (1.0 - gw) * wd;   // 1.7.105: a hand that has taken hold stays on the gun; it takes hold and lets go smoothly (grabW is eased), the pull no longer fades with distance meanwhile
          const double w = (t->underW > 1.0 ? 1.0 : t->underW) * wd;
          if (dist < (gw > 0.01 ? 1.7 : 1.0) * fk) {   // a hand far from the gun (arm's length away) is left where it is: nothing is dragged across the screen
            const double kl = 0.5 + 0.35 * gw;   // 1.7.105: holding the gun the hand lines up with the barrel (nearly fully)
            for (int i = 0; i < 3; ++i) { T[i] += w * dx[i]; lf[i] += kl * w * (t->rdir[i] - lf[i]); }
            if (gw > 0.5) ++st.lGrabPasses;
            if (!arm::unit(lf, lf)) for (int i = 0; i < 3; ++i) lf[i] = t->lfwd[i];
            if (t->foreSteady > 0.0 || gw > 0.0) { const double ksb = t->foreSteady + (t->foreSteady < 0.9 ? (0.9 - t->foreSteady) * gw : 0.0); const double ks = ksb * w; for (int i = 0; i < 3; ++i) lu[i] += ks * (t->rup[i] - lu[i]); if (!arm::unit(lu, lu)) for (int i = 0; i < 3; ++i) lu[i] = t->lup[i]; }   // 1.7.104: pushing the stick with the thumb rolls the real controller; the hand on the foregrip follows the gun's roll more
            if (t->grabWrap > 0.001 && gw > 0.01) {   // 1.7.109 WRAP GRIP: the palm lies on the barrel, the knuckle line runs along it, the fingers go round it and the thumb points to the muzzle (a fist beside the barrel, fingers pointing along it, was the 1.7.108 look)
              double rt[3]; arm::cross(t->rdir, t->rup, rt);   // numerically (rdir x rup) = the player's LEFT in the game's left-handed world; only used as a basis here
              double ap[3], v[3];
              for (int i = 0; i < 3; ++i) { ap[i] = base[i] + t->rdir[i] * along; v[i] = t->lpos[i] - ap[i]; }
              double wx = arm::dot(v, rt), wy0 = arm::dot(v, t->rup);
              if (t->grabLatOk) { wx = t->grabLatX; wy0 = t->grabLatY; }   // smoothed by the engine (walking / turning moves the world between the two hands' samples)
              double wy = wy0 - 0.30 * fk; if (wy > -0.08 * fk) wy = -0.08 * fk;   // 1.7.110: a soft bias (9 cm): 5 cm of sideways wobble of the real hand turns the wrapped hand by only about 10 degrees   // the real hand's side of the barrel (below it unless you hold it out to the side), never over the top
              const double wl = vm::dsqrt(wx * wx + wy * wy);
              double cx = wx / wl, cy = wy / wl;
              {   // 1.7.111: the hand takes hold the way the teaser shows it (from the top-left, fingers over the barrel, the wrist coming in from the lower left); your real hand only moves it a little. It no longer swings to the far (right) side of the barrel.
                const double pref = (t->grabOrbitDeg < -90.0 ? -90.0 : (t->grabOrbitDeg > 180.0 ? 180.0 : t->grabOrbitDeg)) * vm::kPi / 180.0;
                double fol = t->grabOrbitFollow < 0.0 ? 0.0 : (t->grabOrbitFollow > 1.0 ? 1.0 : t->grabOrbitFollow);
                if (t->grabOrbitFollow >= 0.0 && t->grabOrbitDeg > -900.0) {
                  double d = vm::datan2(cx, -cy) - pref;
                  while (d > vm::kPi) d -= 2.0 * vm::kPi;
                  while (d < -vm::kPi) d += 2.0 * vm::kPi;
                  const double th = pref + fol * d; double sn, cs; vm::dsincos(th, &sn, &cs);
                  cx = sn; cy = -cs;
                }
              }
              {   // 1.7.220 FOREARM-AWARE ORBIT: "the hand curls back". The teaser orbit (110 deg, over the top of the barrel) asks the wrist to fold back when the forearm comes up from below. Of the orbits within 70 deg of the wanted one the one that bends the wrist least is taken (the shoulder is known), moving at most 5 deg a pass so nothing jumps; the 55 deg wrist limit below stays as the backstop.
                double rad_ = t->underFt > 0.12 * fk ? t->underFt : 0.12 * fk;
                { const double sz_ = L / (0.583 * fk); rad_ *= sz_ < 0.85 ? 0.85 : (sz_ > 1.4 ? 1.4 : sz_); }
                const double tl_ = (t->grabWrapDeg < 0.0 ? 0.0 : (t->grabWrapDeg > 70.0 ? 70.0 : t->grabWrapDeg)) * vm::kPi / 180.0;
                double sT_, cT_; vm::dsincos(tl_, &sT_, &cT_);
                const double th0 = vm::datan2(cx, -cy);
                // 1.7.222 NO TWISTING: 1.7.220 re-chose the orbit every pass (up to 5 deg a pass) so the glove crept round the barrel whenever the hands moved ("the grip is twisting on the barrel").
                // Now the orbit is chosen ONCE when the hand takes hold (the best of the nearby orbits, as before) and then it stays put. It only moves when the wrist gets uncomfortable (bend over 38 deg), slowly
                // (0.3 deg a pass, 1 deg a pass over 50 deg), and while comfortable it drifts back toward the wanted orbit at 0.1 deg a pass only where that keeps the wrist under 38 deg.
                auto bend_at = [&](double th) -> double {
                  double sn, cs; vm::dsincos(th, &sn, &cs);
                  const double cxx = sn, cyy = -cs;
                  double dH[3], Gp[3], np_[3], f0_[3], fW_[3], uW_[3], Tw_[3], av[3];
                  for (int i = 0; i < 3; ++i) { dH[i] = rt[i] * cxx + t->rup[i] * cyy; Gp[i] = ap[i] + dH[i] * rad_; np_[i] = -dH[i]; }
                  arm::cross(np_, t->rdir, f0_);
                  for (int i = 0; i < 3; ++i) fW_[i] = f0_[i] * cT_ + t->rdir[i] * sT_;
                  if (!arm::unit(fW_, fW_)) return -1.0;
                  arm::cross(fW_, np_, uW_);
                  if (!arm::unit(uW_, uW_)) return -1.0;
                  arm::free_wrist(Gp, fW_, uW_, t->wristBackFt, t->wristDownFt, Tw_);
                  for (int i = 0; i < 3; ++i) av[i] = Tw_[i] - S[i];
                  if (!arm::unit(av, av)) return -1.0;
                  double c2 = arm::dot(fW_, av); c2 = c2 > 1.0 ? 1.0 : (c2 < -1.0 ? -1.0 : c2);
                  return vm::datan2(vm::dsqrt(1.0 - c2 * c2), c2);
                };
                const double lo = -30.0 * vm::kPi / 180.0, hi = 135.0 * vm::kPi / 180.0, stepR = 10.0 * vm::kPi / 180.0, deg = vm::kPi / 180.0;
                const double thPrev = st.lOrbitPrevOk ? st.lOrbitPrev : th0;
                const double bendAt0 = bend_at(th0), bendPrev = st.lOrbitPrevOk ? bend_at(thPrev) : bendAt0;
                if (bendAt0 >= 0.0 && bendPrev >= 0.0) {
                  auto best_orbit = [&](double ref, double* bendOut) -> double {   // the nearby orbit with the least cost; never one that bends the wrist more than the wanted one
                    double bestTh = th0, bestCost = 1e30; *bendOut = bendAt0;
                    for (int qq = 0; qq < 15; ++qq) {
                      const int kk = qq == 0 ? 0 : (qq <= 7 ? -qq : qq - 7);
                      double th = th0 + kk * stepR;
                      if (th < lo) th = lo; if (th > hi) th = hi;
                      const double bend = kk == 0 ? bendAt0 : bend_at(th);
                      if (bend < 0.0) continue;
                      if (kk != 0 && bend > bendAt0) continue;
                      const double cost = bend + 0.25 * vm::dabs(th - th0) + 0.30 * vm::dabs(th - ref);
                      if (cost < bestCost) { bestCost = cost; bestTh = th; *bendOut = bend; }
                    }
                    return bestTh;
                  };
                  double thNew = thPrev, bendNew = bendPrev, bb = bendAt0;
                  if (!st.lOrbitPrevOk) {   // taking hold: the orbit is picked right away (the hand is still blending onto the barrel)
                    thNew = best_orbit(th0, &bb); bendNew = bb;
                  } else if (bendPrev <= 38.0 * deg) {   // comfortable: stay; drift back toward the wanted orbit only where it stays comfortable
                    double d = th0 - thPrev; const double mx = 0.10 * deg; if (d > mx) d = mx; if (d < -mx) d = -mx;
                    double cand = thPrev + d; if (cand < lo) cand = lo; if (cand > hi) cand = hi;
                    const double bc = bend_at(cand);
                    if (bc >= 0.0 && bc <= 38.0 * deg) { thNew = cand; bendNew = bc; }
                  } else {   // uncomfortable: move toward the least-bend orbit, slowly
                    const double bt = best_orbit(thPrev, &bb);
                    double stp = bt - thPrev; const double mx = (bendPrev > 50.0 * deg ? 1.0 : 0.3) * deg;
                    if (stp > mx) stp = mx; if (stp < -mx) stp = -mx;
                    thNew = thPrev + stp; const double bn = bend_at(thNew); bendNew = bn >= 0.0 ? bn : bendPrev;
                  }
                  double sn, cs; vm::dsincos(thNew, &sn, &cs);
                  cx = sn; cy = -cs;
                  st.lOrbitPrev = thNew; st.lOrbitPrevOk = 1;
                  st.lOrbitShiftX10 = (int)((thNew - th0) / vm::kPi * 1800.0); st.lOrbitBend0X10 = (int)(bendAt0 / vm::kPi * 1800.0); st.lOrbitBendX10 = (int)(bendNew / vm::kPi * 1800.0);
                  ++st.lOrbitN; if (vm::dabs(thNew - th0) > 0.02) ++st.lOrbitMoved;
                }
              }
              double dirH[3]; for (int i = 0; i < 3; ++i) dirH[i] = rt[i] * cx + t->rup[i] * cy;
              double rad = t->underFt > 0.12 * fk ? t->underFt : 0.12 * fk;
              { const double sz = L / (0.583 * fk); rad *= sz < 0.85 ? 0.85 : (sz > 1.4 ? 1.4 : sz); }   // 1.7.111: a longer / bigger weapon (upgrades, other guns) has a thicker barrel: the hand sits farther from its axis
              double Gp2[3], np[3], f0[3], fW[3], uW[3];
              for (int i = 0; i < 3; ++i) { Gp2[i] = ap[i] + dirH[i] * rad; np[i] = -dirH[i]; }
              arm::cross(np, t->rdir, f0);   // the game's world is left-handed: this numeric cross is the right-hand-rule cross of (rdir, np) turned round; fingers go round the barrel, e.g. hand under the barrel: fingers point to the player's right
              const double tl = (t->grabWrapDeg < 0.0 ? 0.0 : (t->grabWrapDeg > 70.0 ? 70.0 : t->grabWrapDeg)) * vm::kPi / 180.0;
              double sT, cT; vm::dsincos(tl, &sT, &cT);
              for (int i = 0; i < 3; ++i) fW[i] = f0[i] * cT + t->rdir[i] * sT;
              if (arm::unit(fW, fW)) {
                arm::cross(fW, np, uW);   // thumb side: forward along the barrel for a hand under it (palm up, fingers right)
                if (arm::unit(uW, uW)) {
                  const double ww = (t->grabWrap > 1.0 ? 1.0 : t->grabWrap) * (t->underW > 1.0 ? 1.0 : t->underW);
                  double Tw[3];
                  arm::free_wrist(Gp2, fW, uW, t->wristBackFt, t->wristDownFt, Tw);
                  for (int i = 0; i < 3; ++i) T[i] += ww * (Tw[i] - T[i]);
                  // 1.7.214: the hand SWINGS from the wrist onto the barrel as one turn (a true slerp of the whole hand frame). Before, the pointing and the up
                  // line were blended separately and the hand folded / curled back on the way (lf and lu pass through odd mixes). Ends exactly on the wrap pose.
                  int swung = 0;
                  {
                    double b0[3] = {lf[0], lf[1], lf[2]}, b1[3] = {lu[0], lu[1], lu[2]};
                    const double kb = arm::dot(b1, b0);
                    for (int i = 0; i < 3; ++i) b1[i] -= kb * b0[i];
                    if (arm::unit(b0, b0) && arm::unit(b1, b1)) {
                      double b2[3], g2[3], Rb[9], Rt[9], Rbt[9], dl[9], part[9], Rn[9];
                      arm::cross(b0, b1, b2); arm::cross(fW, uW, g2);
                      for (int i = 0; i < 3; ++i) { Rb[i * 3] = b0[i]; Rb[i * 3 + 1] = b1[i]; Rb[i * 3 + 2] = b2[i]; Rt[i * 3] = fW[i]; Rt[i * 3 + 1] = uW[i]; Rt[i * 3 + 2] = g2[i]; }
                      weight::transpose3(Rb, Rbt); weight::mul3(Rt, Rbt, dl);
                      arm::rot_part(dl, ww, vm::kPi, part);
                      weight::mul3(part, Rb, Rn);
                      double nf[3] = {Rn[0], Rn[3], Rn[6]}, nu[3] = {Rn[1], Rn[4], Rn[7]};
                      if (arm::unit(nf, nf) && arm::unit(nu, nu)) { for (int i = 0; i < 3; ++i) { lf[i] = nf[i]; lu[i] = nu[i]; } swung = 1; }
                    }
                  }
                  if (!swung) for (int i = 0; i < 3; ++i) { lf[i] += ww * (fW[i] - lf[i]); lu[i] += ww * (uW[i] - lu[i]); }
                  if (!arm::unit(lf, lf)) for (int i = 0; i < 3; ++i) lf[i] = fW[i];
                  if (!arm::unit(lu, lu)) for (int i = 0; i < 3; ++i) lu[i] = uW[i];
                  st.lWrapNow = ww; if (ww > 0.5) ++st.lWrapGripPasses;
                  st.lWrapTiltX10 = (int)(tl / vm::kPi * 1800.0); st.lWrapOrbitX10 = (int)(vm::datan2(cx, -cy) / vm::kPi * 1800.0);
                }
              }
            }
            st.lMagWNow = w;
            ++st.lUnderN; st.lUnderAlongX100 += (long long)(along / L * 100.0); st.lUnderMoveX100 += (long long)(dist * 100.0); if (clamped) ++st.lUnderClamped;
            if ((int)(dist * 100.0) > st.lUnderMaxX100) st.lUnderMaxX100 = (int)(dist * 100.0);
          } else ++st.lUnderFar;
        } else if (!nativeOk && t->gripMagnet > 0.0 && t->rightOn && t->rdirOk && t->gunLenFt > 0.2) {   // 0.81: fallback foregrip
          double Gp[3], dx[3];
          const double fore = 0.55 * t->gunLenFt;
          const double fk2 = (t->fpm > 0.1 && t->fpm < 100.0) ? t->fpm / 3.28084 : 1.0;   // 1.7.110
          for (int i = 0; i < 3; ++i) {
            // 1.7.7: measured from where the gun really is (its origin in the last pass), not from the controller point: the gun sits a hand length from that point
            const double base = t->gunPosOk ? t->gunPos[i] : t->grip[i];
            Gp[i] = base + t->rdir[i] * fore - t->rup[i] * 0.10; dx[i] = Gp[i] - t->lpos[i];
          }
          const double dist = arm::len(dx);
          double w = (1.3 * fk2 - dist) / (0.8 * fk2); w = w < 0.0 ? 0.0 : (w > 1.0 ? 1.0 : w);
          w = w * w * (3.0 - 2.0 * w) * (t->gripMagnet > 1.0 ? 1.0 : t->gripMagnet);
          if (w > 0.001) {
            for (int i = 0; i < 3; ++i) { T[i] += w * dx[i]; lf[i] += 0.7 * w * (t->rdir[i] - lf[i]); }
            if (!arm::unit(lf, lf)) for (int i = 0; i < 3; ++i) lf[i] = t->lfwd[i];
            st.lMagWNow = w;
            ++st.lMagN; st.lMagSumX100 += (long long)(dist * 100.0); st.lMagWSumX100 += (long long)(w * 100.0);
            if ((int)(dist * 100.0) > st.lMagMaxX100) st.lMagMaxX100 = (int)(dist * 100.0);
          }
        }
        if (arm::unit(fa, fu)) hand_from_controller(fu, lf, lu, Qh); else weight::ident(Qh);   // 0.79: with the controller's roll
        for (int i = 0; i < 3; ++i) { dispLf[i] = lf[i]; dispLu[i] = lu[i]; } dispLOk = 1;   // 1.7.174
      }
      if (s == 0 && !gripOn && farGrip) {   // 0.79: the game's hand is nowhere near the wand's origin (no weapon in hand: cutscene, level start): the hand goes to the controller itself
        ++st.gripFar;
        for (int i = 0; i < 3; ++i) T[i] = t->grip[i];
        if (t->rdirOk && t->gunWristBackFt > 0.0) for (int i = 0; i < 3; ++i) T[i] -= t->rdir[i] * t->gunWristBackFt + t->rup[i] * t->gunWristDownFt;   // 1.7.7: an empty hand's wrist sits back as well
        double fa[3], fu[3];
        arm::sub(Hp, E0, fa);
        if (t->rdirOk && arm::unit(fa, fu)) hand_from_controller(fu, t->rdir, t->rup, Qh);
      }
      if (s == 0 && t->handFreeze && t->pkeAlign && frz.have && frz.actor == actor && t->rdirOk && (frz.latFt > 1e-5 || frz.latFt < -1e-5 || frz.fwdShiftFt > 1e-5 || frz.fwdShiftFt < -1e-5 || frz.upShiftFt > 1e-5 || frz.upShiftFt < -1e-5)) {   // 1.7.104: the hand moves sideways so the PKE's centre is on the controller (1.7.111: and forward / up when the pitch turn moved it)
        double lf3[3] = {t->rdir[0], t->rdir[1], t->rdir[2]}, lu3[3] = {t->rup[0], t->rup[1], t->rup[2]}, lcr[3];
        const double kd = arm::dot(lu3, lf3);
        for (int i = 0; i < 3; ++i) lu3[i] -= kd * lf3[i];
        if (arm::unit(lf3, lf3) && arm::unit(lu3, lu3)) {
          arm::cross(lf3, lu3, lcr);
          for (int i = 0; i < 3; ++i) T[i] += -frz.latFt * lcr[i] + frz.fwdShiftFt * lf3[i] + frz.upShiftFt * lu3[i];
        }
      }
      if (nativeOk) {
        const double blend = t->grabW > 1.0 ? 1.0 : t->grabW;
        double current[9], ct[9], wanted[9], qn[9], qt[9], delta[9], part[9];
        frame_world(sp, Wc[a.plen - 1], current);
        weight::transpose3(current, ct);
        for (int j = 0; j < 3; ++j) {
          double row[3] = {nativeHand[j * 4], nativeHand[j * 4 + 1], nativeHand[j * 4 + 2]};
          if (!arm::unit(row, row)) { nativeOk = 0; break; }
          for (int i = 0; i < 3; ++i) wanted[i * 3 + j] = row[i];
        }
        if (nativeOk) {
          static int nativeLogs;
          if (++nativeLogs <= 3) G::log("GRAB native support pose: the weapon animation's left-hand position, orientation and fingers follow the current VR weapon hand (barrel length %.2f ft)", t->gunLenFt);
          weight::mul3(wanted, ct, qn);
          weight::transpose3(Qh, qt); weight::mul3(qn, qt, delta);
          arm::rot_part(delta, blend, vm::kPi, part); weight::mul3(part, Qh, Qh);
          for (int i = 0; i < 3; ++i) T[i] += blend * (nativeHand[12 + i] - T[i]);
        }
      }
      if (reloadHandOk) for (int i = 0; i < 3; ++i) T[i] = reloadHand[12 + i];
      // 0.68 shoulder reach: a target farther than the arm is long first swings the clavicle toward it (like shrugging the shoulder forward),
      // so the arm has to stretch less
      if (t->shoulderPullDeg > 0.5 && c.clav[s] >= 0) {
        double q1[3] = {E0[0] - S[0], E0[1] - S[1], E0[2] - S[2]}, q2[3] = {Hp[0] - E0[0], Hp[1] - E0[1], Hp[2] - E0[2]};
        const double Ls = (arm::len(q1) + arm::len(q2)) * (t->armLenBase > 1.0 ? t->armLenBase : 1.0);
        double tv0[3] = {T[0] - S[0], T[1] - S[1], T[2] - S[2]};
        const double d0 = arm::len(tv0);
        const double need = d0 - Ls;
        if (need > 0.02 && d0 > 1e-3) {
          double Cc[3], v0[3], u0[3];
          sp.point_world(world + (size_t)16 * c.clav[s] + 12, Cc);
          arm::sub(S, Cc, v0);
          const double l0 = arm::len(v0);
          if (l0 > 0.05 && l0 < 2.0 && arm::unit(v0, u0)) {
            const double maxRad = t->shoulderPullDeg * (vm::kPi / 180.0);
            double sh, ch;
            vm::dsincos(maxRad * 0.5, &sh, &ch);
            const double chord = 2.0 * l0 * sh;
            const double mv = need < chord ? need : chord;
            double St[3] = {S[0] + tv0[0] / d0 * mv, S[1] + tv0[1] / d0 * mv, S[2] + tv0[2] / d0 * mv}, v1[3], u1[3];
            arm::sub(St, Cc, v1);
            if (arm::unit(v1, u1)) {
              double Qf[9], Qp[9];
              arm::swing(u0, u1, Qf);
              const double ang = arm::rot_part(Qf, 1.0, maxRad, Qp);
              sub_rotate(world, n, c.inClav[s], sp, Cc, Qp);
              chain_world(local, world, a, Wc);
              sp.point_world(Wc[0] + 12, S);
              sp.point_world(Wc[1] + 12, E0);
              sp.point_world(Wc[a.plen - 1] + 12, Hp);
              ++st.pulled[s];
              const int a10 = (int)(ang / (vm::kPi / 180.0) * 10.0);
              st.lastPullX10[s] = a10 > (int)(t->shoulderPullDeg * 10.0) ? (int)(t->shoulderPullDeg * 10.0) : a10;
              if (st.lastPullX10[s] > st.pullMaxX10[s]) st.pullMaxX10[s] = st.lastPullX10[s];
            }
          }
        }
      }
      // 0.74 shoulder slide: if the hand is still out of reach after the clavicle swing, the whole shoulder (the clavicle and everything below it) slides
      // toward the hand, a hand's width at most, so the arm has to stretch less (long thin stretched arms were the thing that looked wrong)
      if (t->shoulderSlideFt > 0.01 && c.clav[s] >= 0) {
        double q1[3] = {E0[0] - S[0], E0[1] - S[1], E0[2] - S[2]}, q2[3] = {Hp[0] - E0[0], Hp[1] - E0[1], Hp[2] - E0[2]};
        const double Ls = (arm::len(q1) + arm::len(q2)) * (t->armLenBase > 1.0 ? t->armLenBase : 1.0);
        double tv1[3] = {T[0] - S[0], T[1] - S[1], T[2] - S[2]};
        const double d1 = arm::len(tv1);
        const double need = d1 - 0.97 * Ls;
        if (need > 0.02 && d1 > 1e-3) {
          const double mv = need < t->shoulderSlideFt ? need : t->shoulderSlideFt;
          double Dw[3] = {tv1[0] / d1 * mv, tv1[1] / d1 * mv, tv1[2] / d1 * mv}, Dm[3];
          sp.dir_model(Dw, Dm);
          if (vm::is_finite_f((float)Dm[0]) && vm::is_finite_f((float)Dm[1]) && vm::is_finite_f((float)Dm[2])) {
            for (int j = 0; j < n; ++j) if (c.inClav[s][j]) { float* Bj = world + (size_t)16 * j; Bj[12] += (float)Dm[0]; Bj[13] += (float)Dm[1]; Bj[14] += (float)Dm[2]; }
            chain_world(local, world, a, Wc);
            sp.point_world(Wc[0] + 12, S);
            sp.point_world(Wc[1] + 12, E0);
            sp.point_world(Wc[a.plen - 1] + 12, Hp);
            ++st.slid[s];
            const int m100 = (int)(mv * 100.0);
            st.lastSlideX100[s] = m100; if (m100 > st.slideMaxX100[s]) st.slideMaxX100[s] = m100;
          }
        }
      }
      // 0.61 reach stretch: the avatar's arms are shorter than the player's, so the arm bones are lengthened (along the limb only)
      // until the hand reaches the controller (up to stretchMax)
      double eu[3] = {E0[0] - S[0], E0[1] - S[1], E0[2] - S[2]}, ef[3] = {Hp[0] - E0[0], Hp[1] - E0[1], Hp[2] - E0[2]};
      const double Lsum = arm::len(eu) + arm::len(ef);
      double tv[3] = {T[0] - S[0], T[1] - S[1], T[2] - S[2]};
      const double dT = arm::len(tv);
      const double base = t->armLenBase > 1.0 ? (t->armLenBase > 1.6 ? 1.6 : t->armLenBase) : 1.0;   // 1.7.69: elbow room
      double sc = base;
      if (t->stretchMax > 1.0 && dT > 0.97 * Lsum * base) { sc = dT / (0.97 * Lsum); const double cap = t->stretchMax > base ? t->stretchMax : base; if (sc > cap) sc = cap; }
      {   // 0.66 data: how far the controller really is, in arm lengths of the unstretched avatar arm
        const int pc = (int)(dT / Lsum * 100.0);
        st.demand[s][pc < 80 ? 0 : pc < 100 ? 1 : pc < 130 ? 2 : pc < 170 ? 3 : pc < 220 ? 4 : pc < 300 ? 5 : pc < 400 ? 6 : 7]++;
      }
      double E0s[3], Hps[3];
      for (int i = 0; i < 3; ++i) { E0s[i] = S[i] + eu[i] * sc; Hps[i] = E0s[i] + ef[i] * sc; }
      arm::Ik k;
      double outward[3] = {0, 0, 0};
      int haveOut = 0;
      if (t->floatingArms && t->elbowOut > 0.01) {
        double sy, cy; vm::dsincos(t->bodyYaw, &sy, &cy);
        const double sign = (s == 0) != (mirror != 0) ? 1.0 : -1.0;   // 1.7.170: left-handed: the sides swap
        outward[0] = sign * cy * t->elbowOut; outward[2] = -sign * sy * t->elbowOut;
        haveOut = 1;
      } else if (t->elbowOut > 0.01 && c.arm[1 - s].U >= 0) {   // relaxed outward elbow bend
        double So[3], lat[3];
        if (mirror) for (int i = 0; i < 3; ++i) So[i] = shoulderAt[s][i];   // 1.7.170: outward = away from where this arm used to hang
        else sp.point_world(world + (size_t)16 * c.arm[1 - s].U + 12, So);
        lat[0] = S[0] - So[0]; lat[1] = 0.0; lat[2] = S[2] - So[2];
        if (arm::unit(lat, lat)) { for (int i = 0; i < 3; ++i) outward[i] = lat[i] * t->elbowOut; haveOut = 1; }
      }
      if (mirShifted) {
        // 1.7.173 "left hand mode looks wrong": the arm hangs from the other shoulder, but the elbow still bent the way the animation has it for its OWN
        // side - toward the middle of the body, through the chest. The animation's elbow direction is mirrored across the body's middle plane
        // (as a correction to the elbow's pull: arm::solve takes hint * 0.5 + fallback * 0.6), so the elbow bends outward on its new side.
        double nrm[3] = {shoulderAt[0][0] - shoulderAt[1][0], shoulderAt[0][1] - shoulderAt[1][1], shoulderAt[0][2] - shoulderAt[1][2]};
        double uT[3] = {T[0] - S[0], T[1] - S[1], T[2] - S[2]};
        if (arm::unit(nrm, nrm) && arm::unit(uT, uT)) {
          const double kq = arm::dot(eu, uT); double hint[3] = {eu[0] - uT[0] * kq, eu[1] - uT[1] * kq, eu[2] - uT[2] * kq};
          if (arm::unit(hint, hint)) {
            const double hn = arm::dot(hint, nrm);
            for (int i = 0; i < 3; ++i) outward[i] += -2.0 * hn * nrm[i] * (0.5 / 0.6);
            haveOut = 1; ++st.mirrorElbow[s];
          }
        }
      }
      const double elbowDown = arm::raised_elbow_down(S, T, Lsum * sc, t->elbowDown);
      if (elbowDown < t->elbowDown - 0.01) ++st.raisedElbow[s];
      if (t->mirrorArms == 1) {   // 1.7.174: what this arm aims at, for the other arm's drawn solve
        disp.ok[s] = 0;
        if (s == 0) {
          double ff[3] = {T[0] - S[0], T[1] - S[1], T[2] - S[2]};   // no controller direction (rare: the wand's turn only): a straight wrist
          const int straight = !t->rdirOk && arm::unit(ff, ff);
          if (t->rdirOk || straight) { for (int i = 0; i < 3; ++i) { disp.T[0][i] = T[i]; disp.f[0][i] = t->rdirOk ? t->rdir[i] : ff[i]; disp.u[0][i] = t->rdirOk ? t->rup[i] : (i == 1 ? 1.0 : 0.0); } disp.ok[0] = 1; }
        }
        if (s == 1 && t != tReal) {   // 1.7.181: T is for the mirror image of the free hand: back to the real side. The hand frame the game's hold gave the (virtual) left hand is mirrored into a right-hand frame
          reflect_point(T, mirP, mirN, disp.T[1]);
          for (int i = 0; i < 3; ++i) { disp.f[1][i] = tReal->lfwd[i]; disp.u[1][i] = tReal->lup[i]; }
          disp.ok[1] = 1;
          double Fc[9], Fv[9], Fo[9];
          frame_raw(sp, Wc[a.plen - 1], Fc); weight::mul3(Qh, Fc, Fv);   // the (virtual) left hand's frame once placed
          if (mirror_hand_frame(local, sp, 1, Fv, mirN, Fo)) { for (int i = 0; i < 9; ++i) disp.F[1][i] = Fo[i]; disp.wF[1] = t->grabW < 0.0 ? 0.0 : (t->grabW > 1.0 ? 1.0 : t->grabW); disp.okF[1] = 1; }
        } else if (s == 1) { for (int i = 0; i < 3; ++i) { disp.T[1][i] = T[i]; disp.f[1][i] = t->lfwd[i]; disp.u[1][i] = t->lup[i]; } disp.ok[1] = 1; (void)dispLf; (void)dispLu; (void)dispLOk; }   // the free controller's own pointing and up (not the barrel-wrap turn, which is worked out for a left hand): the right hand is turned the way your real one is
      }
      if (!arm::solve(S, E0s, Hps, T, elbowDown, &k, haveOut ? outward : nullptr)) { ++st.ikFail; continue; }
      if (t->eyeOn) {   // 0.72 data: where the wrist is relative to the camera eye
        double sy, cy;
        vm::dsincos(t->bodyYaw, &sy, &cy);
        const double dx = k.T[0] - t->eyeTarget[0], dy = k.T[1] - t->eyeTarget[1], dz = k.T[2] - t->eyeTarget[2];
        const double rr = dx * cy - dz * sy, ff = dx * sy + dz * cy;
        st.wristRel[s][0] = (float)rr; st.wristRel[s][1] = (float)dy; st.wristRel[s][2] = (float)ff;
        st.wristRelSum[s][0] += rr; st.wristRelSum[s][1] += dy; st.wristRelSum[s][2] += ff; ++st.wristRelN[s];
      }
      float Un[16], Fn[16], Hn[16];
      double QF[9];
      sp.place(Wc[0], k.QU, S, Un);
      for (int i = 0; i < 3; ++i) Un[12 + i] = Wc[0][12 + i];   // the shoulder does not move
      weight::mul3(k.Q2, k.QU, QF);
      sp.place(Wc[1], QF, k.E, Fn);
      if (gripOn) {   // 0.75: the hand's axes end up where the game's pose had them, turned by the wand's rotation (Q = R * G * C^T: current frame C -> game frame G -> turned)
        double Cm[9], CT[9], Dq[9];
        frame_world(sp, Wc[a.plen - 1], Cm);
        weight::transpose3(Cm, CT);
        weight::mul3(gh.ax, CT, Dq);
        weight::mul3(t->wandR, Dq, Qh);
      }
      if (s == 0 && t->handFreeze && t->rdirOk) {   // 1.7.76: the hand turns with the controller, nothing else (the animation's own hand turn made the PKE swing 4 cm about your fist)
        double Cm2[9], CT2[9], Fcur[9], f3[3] = {t->rdir[0], t->rdir[1], t->rdir[2]}, u3[3] = {t->rup[0], t->rup[1], t->rup[2]}, kd = 0, cr[3], Cc[9], CcT[9];
        frame_world(sp, Wc[a.plen - 1], Cm2);
        weight::transpose3(Cm2, CT2);
        weight::mul3(Qh, Cm2, Fcur);
        for (int i = 0; i < 3; ++i) kd += u3[i] * f3[i];
        for (int i = 0; i < 3; ++i) u3[i] -= kd * f3[i];
        if (arm::unit(f3, f3) && arm::unit(u3, u3)) {
          arm::cross(f3, u3, cr);
          for (int i = 0; i < 3; ++i) { Cc[i * 3] = f3[i]; Cc[i * 3 + 1] = u3[i]; Cc[i * 3 + 2] = cr[i]; }
          weight::transpose3(Cc, CcT);
          if (!frz.have || frz.actor != actor) {
            weight::mul3(CcT, Fcur, frz.K); frz.have = 1; frz.actor = actor; ++frz.captured;
            frz.rampT = 0.0; frz.rampSeq = -1;
            G::log("PKECTL the hand's turn is now tied to your controller (captured from the hand as it was: this is how it stays)");
          } else {
            double Fdes[9], Dv[9], DvT[9], Ku[9];
            for (int i = 0; i < 9; ++i) Ku[i] = frz.K[i];
            frz.latFt = 0.0; frz.fwdShiftFt = 0.0; frz.upShiftFt = 0.0;
            // 1.7.225 "the PKE gets pulled around when it first comes out": the alignment (hand turn plus the 15 cm move that centres the meter on the controller) used to start in full
            // on the first pass after the grip locked, so the meter jumped. It now eases in over 0.45 s (smooth), counted in game frames (not per pass).
            double rp = 1.0;
            if (t->pkeEaseS > 0.0 && t->calmDtS > 0.0) {
              if (frz.rampSeq != (long)t->calmSeq) { frz.rampSeq = (long)t->calmSeq; frz.rampT += (t->calmDtS > 0.1 ? 0.1 : t->calmDtS); }
              rp = frz.rampT / t->pkeEaseS; rp = rp > 1.0 ? 1.0 : rp; rp = rp * rp * (3.0 - 2.0 * rp);
            }
            if (t->pkeAlign) {   // 1.7.104: the PKE's long axis into the controller's centre plane (the captured relation K stays as it was; the turn is recomputed from the hold each pass)
              const pkealign::Result ar = pkealign::solve_ex(frz.K, t->pkeVh, t->pkePh, 70.0, t->pkePitchDeg, Ku, t->pkeTurnMaxDeg > 0.0 ? t->pkeTurnMaxDeg : 1.0e9);
              frz.al = ar; ++frz.alignN;
              if (ar.ok) {
                frz.latFt = ar.latAfterFt; if (frz.latFt > 0.3) frz.latFt = 0.3; if (frz.latFt < -0.3) frz.latFt = -0.3;
                { double KT[9], DK[9], part[9], Kb[9]; weight::transpose3(frz.K, KT); weight::mul3(KT, Ku, DK); arm::rot_part(DK, rp, vm::kPi, part); weight::mul3(frz.K, part, Kb); for (int i = 0; i < 9; ++i) Ku[i] = Kb[i]; }   // the turn eases in too
                frz.fwdShiftFt = t->pkeCentre ? -ar.fwdFt : ar.shiftFwdFt; if (frz.fwdShiftFt > 0.3) frz.fwdShiftFt = 0.3; if (frz.fwdShiftFt < -0.3) frz.fwdShiftFt = -0.3;
                frz.upShiftFt = t->pkeCentre ? -ar.upFt : ar.shiftUpFt; if (frz.upShiftFt > 0.3) frz.upShiftFt = 0.3; if (frz.upShiftFt < -0.3) frz.upShiftFt = -0.3;
                frz.latFt *= rp; frz.fwdShiftFt *= rp; frz.upShiftFt *= rp;
              } else ++frz.alignFail;
            }
            weight::mul3(Cc, Ku, Fdes);
            weight::transpose3(Fcur, DvT); weight::mul3(DvT, Fdes, Dv);
            double tr = Dv[0] + Dv[4] + Dv[8], cs = (tr - 1.0) * 0.5; cs = cs > 1.0 ? 1.0 : (cs < -1.0 ? -1.0 : cs);
            const double dev = vm::datan2(vm::dsqrt(1.0 - cs * cs), cs) * 57.29577951308232;
            frz.lastDevDeg = dev; frz.sumDevDeg += dev; if (dev > frz.maxDevDeg) frz.maxDevDeg = dev;
            weight::mul3(Fdes, CT2, Qh);
            ++frz.applied;
          }
        } else ++frz.noFrame;
      }
      if (reloadHandOk) {
        double current[9], ct[9], desired[9];
        frame_world(sp, Wc[a.plen - 1], current); weight::transpose3(current, ct);
        for (int r = 0; r < 3; ++r) {
          double row[3] = {reloadHand[r * 4], reloadHand[r * 4 + 1], reloadHand[r * 4 + 2]};
          arm::unit(row, row); for (int i = 0; i < 3; ++i) desired[i * 3 + r] = row[i];
        }
        weight::mul3(desired, ct, Qh);
      }
      if (s == 1 && st.lWrapNow > 0.01 && dispLOk) {   // 1.7.215 WRIST LIMIT: the wrap-gripped hand swings from the wrist onto the barrel but cannot fold back past a natural bend (the video: the glove sat on top of the barrel bent back ~90 deg)
        double fh[3] = {dispLf[0], dispLf[1], dispLf[2]}, uh[3] = {dispLu[0], dispLu[1], dispLu[2]};
        const double ww = st.lWrapNow > 1.0 ? 1.0 : st.lWrapNow;
        const double lim = wrist_limit_rad;
        if (arm::unit(fh, fh) && arm::unit(uh, uh)) {
          auto bend_of = [&](const arm::Ik& kk, const double* ff, double* a1o) {
            a1o[0] = kk.T[0] - kk.E[0]; a1o[1] = kk.T[1] - kk.E[1]; a1o[2] = kk.T[2] - kk.E[2];
            if (!arm::unit(a1o, a1o)) return -1.0;
            double cs = arm::dot(a1o, ff); cs = cs > 1.0 ? 1.0 : (cs < -1.0 ? -1.0 : cs);
            return vm::datan2(vm::dsqrt(1.0 - cs * cs), cs);
          };
          double a1[3];
          const double bend0 = bend_of(k, fh, a1);
          if (bend0 >= 0.0) {
            st.lBendLastX10 = (int)(bend0 / vm::kPi * 1800.0); ++st.lBendN; st.lBendSumX10 += st.lBendLastX10; if (st.lBendLastX10 > st.lBendMaxX10) st.lBendMaxX10 = st.lBendLastX10;
            if (bend0 > lim + 0.005) {
              const arm::Ik k0 = k; double Qh0[9], fh0[3], uh0[3];
              for (int i = 0; i < 9; ++i) Qh0[i] = Qh[i];
              for (int i = 0; i < 3; ++i) { fh0[i] = fh[i]; uh0[i] = uh[i]; }
              // the wrist moves round the palm point (the palm stays on the barrel), which moves the elbow and turns the forearm again: a few passes settle it, the best one is kept
              arm::Ik kb = k; double Qb[9], bestBend = bend0; for (int i = 0; i < 9; ++i) Qb[i] = Qh[i];
              for (int pass = 0; pass < 4; ++pass) {
                double ax[3], R[9], o0[3], o1[3], bd = bend_of(k, fh, a1);
                if (bd < 0.0 || bd <= lim + 0.005) break;
                arm::cross(fh, a1, ax);
                if (!arm::unit(ax, ax)) break;
                weight::axis_angle(ax, (bd - lim) * ww, R);
                for (int i = 0; i < 3; ++i) o0[i] = fh[i] * t->wristBackFt + uh[i] * t->wristDownFt;   // palm point = wrist + o0
                arm::apply3(R, o0, o1);
                double Tn[3]; for (int i = 0; i < 3; ++i) Tn[i] = (k.T[i] + o0[i]) - o1[i];
                arm::Ik k2;
                if (!arm::solve(S, E0s, Hps, Tn, elbowDown, &k2, haveOut ? outward : nullptr)) break;
                double f2[3], u2[3];
                arm::apply3(R, fh, f2); arm::apply3(R, uh, u2);
                for (int i = 0; i < 3; ++i) { fh[i] = f2[i]; uh[i] = u2[i]; }
                weight::mul3(R, Qh, Qh);
                k = k2;
                const double nb = bend_of(k, fh, a1);
                if (nb >= 0.0 && nb < bestBend) { bestBend = nb; kb = k; for (int i = 0; i < 9; ++i) Qb[i] = Qh[i]; }
              }
              if (bestBend <= lim + 0.05 * (bend0 - lim) + 0.02) { k = kb; for (int i = 0; i < 9; ++i) Qh[i] = Qb[i]; }   // settled (within a few degrees of the limit)
              else {   // did not settle (the forearm keeps turning away): turn only the hand, the wrist stays where the arm already had it
                k = k0; for (int i = 0; i < 9; ++i) Qh[i] = Qh0[i];
                double ax[3], R[9]; bend_of(k, fh0, a1); arm::cross(fh0, a1, ax);
                if (arm::unit(ax, ax)) { weight::axis_angle(ax, (bend0 - lim) * ww, R); weight::mul3(R, Qh, Qh); }
                ++st.lBendFallback;
              }
              ++st.lBendClamped;
              weight::mul3(k.Q2, k.QU, QF);
              sp.place(Wc[0], k.QU, S, Un); for (int i = 0; i < 3; ++i) Un[12 + i] = Wc[0][12 + i];
              sp.place(Wc[1], QF, k.E, Fn);
            }
          }
        }
      }
      sp.place(Wc[a.plen - 1], Qh, k.T, Hn);
      if (t->forearmTwist > 0.01) {   // 0.77: the hand's turn about the forearm is shared with the forearm (the skin between elbow and wrist twists instead of only the hand)
        double a1[3] = {k.T[0] - k.E[0], k.T[1] - k.E[1], k.T[2] - k.E[2]}, Qt[9], QF2[9];
        if (arm::unit(a1, a1)) {
          const double g = arm::forearm_roll_cont(Qh, QF, a1, t->forearmTwist, &st.roll[s], 100.0 * vm::kPi / 180.0, Qt);
          if (vm::dabs(g) > 0.01) {
            weight::mul3(Qt, QF, QF2);
            sp.place(Wc[1], QF2, k.E, Fn);
            ++st.rollShared[s];
            const int g10 = (int)(vm::dabs(g) * 573.0);
            st.rollLastX10[s] = g10; if (g10 > st.rollMaxX10[s]) st.rollMaxX10[s] = g10;
          }
        }
      }
      if (sc > 1.0001) {
        const int ru = along_row(Wc[0], sp, eu), rf = along_row(Wc[1], sp, ef);
        for (int cc = 0; cc < 3; ++cc) { Un[ru * 4 + cc] = (float)(Un[ru * 4 + cc] * sc); Fn[rf * 4 + cc] = (float)(Fn[rf * 4 + cc] * sc); }
        ++st.stretched[s];
        st.lastStretchX100[s] = (int)(sc * 100.0);
        if (st.lastStretchX100[s] > st.stretchMaxX100[s]) st.stretchMaxX100[s] = st.lastStretchX100[s];
      } else st.lastStretchX100[s] = 100;
      { const int sp100 = st.lastStretchX100[s]; ++st.stretchHist[s][sp100 <= 100 ? 0 : sp100 <= 115 ? 1 : sp100 <= 130 ? 2 : sp100 <= 150 ? 3 : sp100 <= 200 ? 4 : 5]; }
      if (t->handClean && finite16(Hn)) {   // 1.7.70: the 1.7.66-1.7.69 logs: the drawn hand matrix came out with axes like 0.67/2.16/0.89 for seconds after the PKE came out
        float hw[16] = {0};
        for (int r = 0; r < 3; ++r) { double m[3] = {Hn[r * 4], Hn[r * 4 + 1], Hn[r * 4 + 2]}, w[3]; sp.dir_world(m, w); hw[r * 4] = (float)w[0]; hw[r * 4 + 1] = (float)w[1]; hw[r * 4 + 2] = (float)w[2]; }
        hw[15] = 1.0f;
        const double ratio = handprop::row_ratio(hw), ms = handprop::mean_scale(hw);
        if (ratio > 0.0 && ratio < 1.06 && ms > 0.8 && ms < 1.25) { st.handBase[s] = ms; st.handBaseHave[s] = 1; }
        else {
          float cl[16];
          if (handprop::rigid_frame(hw, st.handBaseHave[s] ? st.handBase[s] : 1.0, cl)) {
            for (int r = 0; r < 3; ++r) { double w[3] = {cl[r * 4], cl[r * 4 + 1], cl[r * 4 + 2]}, m[3]; sp.dir_model(w, m); Hn[r * 4] = (float)m[0]; Hn[r * 4 + 1] = (float)m[1]; Hn[r * 4 + 2] = (float)m[2]; }
            ++st.handCleaned[s];
          }
        }
      }
      if (!finite16(Un) || !finite16(Fn) || !finite16(Hn)) { ++st.nonFinite; continue; }
      // write the arm: chain bones get the new matrices, the rest below the upper arm is re-derived from its own local pose
      ARMCORE_CRUMB("apply:chain", s);
      write_chain(world, local, n, a, Un, Fn, Hn);
      ARMCORE_CRUMB("apply:fingers", s);
      if (t->fingersOn && !(nativeOk && t->grabW > 0.97)) {
        if (nativeOk) {
          ArmTargets fingers = *t;
          fingers.grabWrap = 0.0;
          fingers.leftFingerKeep = fingers.leftThumbKeep = t->grabW;
          curl_hand(world, n, s, sp, &fingers, 0);
        } else curl_hand(world, n, s, sp, t, s == 0 && gripOn && !t->rightEmpty);
      }
      if (s == 0 && gh.matOk) {
        float hf[16];
        G::mul(hf, world + (size_t)16 * a.H, W2);
        if (finite16(hf)) {
          for (int i = 0; i < 16; ++i) { handGameW[i] = gh.W[i]; handFinalW[i] = hf[i]; }
          handActor = actor; handClock = G::clock(); handHave = 1;
          if (!t->reloadHold && t->rdirOk) {
            float grip[3], forward[3], up[3], controller[16];
            for (int i = 0; i < 3; ++i) { grip[i] = (float)t->grip[i]; forward[i] = (float)t->rdir[i]; up[i] = (float)t->rup[i]; }
            reload.handHave = handprop::tracked_frame(grip, forward, up, controller) && handprop::relative(hf, controller, reload.handRel);
          }
        }
      }
      movedAny = 1; solvedArm[s] = 1;
      {   // 0.66: what we wrote and what it came from (the next call of the same pair compares against it); and how far the wrist fell short
        ArmOut& o = ao[s];
        o.world = world; o.sigN = sigN; for (int i = 0; i < sigN; ++i) o.sig[i] = sig[i];
        copy12(o.u, world + (size_t)16 * a.U); copy12(o.h, world + (size_t)16 * a.H); o.have = 1;
        double ms[3] = {T[0] - k.T[0], T[1] - k.T[1], T[2] - k.T[2]};
        for (int i = 0; i < 3; ++i) st.lastMiss[s][i] = (float)ms[i];
        const int mx = (int)(arm::len(ms) * 100.0);
        st.lastMissX100[s] = mx; if (mx > st.missMaxX100[s]) st.missMaxX100[s] = mx; if (mx > 10) ++st.missOver[s];
        st.missClock[s] = tc0;
      }
      w[s].world = world; w[s].U = a.U; w[s].H = a.H; copy12(w[s].u, Un); copy12(w[s].h, Hn); w[s].have = 1;
      // statistics and the first-move report
      int first = ++st.moved[s];
      int rx = (int)(k.reach * 100.0);
      st.lastReachX100[s] = rx;
      if (rx > st.maxReachX100[s]) st.maxReachX100[s] = rx;
      if (k.clamped) ++st.clamped[s];
      if (k.twisted) ++st.twisted[s];
      {
        st.lastL1[s] = (float)arm::len(eu);
        st.lastL2[s] = (float)arm::len(ef);
      }
      for (int i = 0; i < 3; ++i) { st.lastS[s][i] = (float)S[i]; st.lastE[s][i] = (float)k.E[i]; st.lastT[s][i] = (float)k.T[i]; }
      if (first == 1 || first == 300 || first == 3000) {
        // where the hand bone's three axes point relative to the forearm and the world: data for hand roll later
        double fa[3] = {Hp[0] - E0[0], Hp[1] - E0[1], Hp[2] - E0[2]}, fu[3];
        arm::unit(fa, fu);
        double ax[3][3], dots[3], ups[3];
        for (int r = 0; r < 3; ++r) {
          double m[3] = {Wc[a.plen - 1][r * 4], Wc[a.plen - 1][r * 4 + 1], Wc[a.plen - 1][r * 4 + 2]};
          sp.dir_world(m, ax[r]);
          double l = arm::len(ax[r]);
          if (l > 1e-9) { ax[r][0] /= l; ax[r][1] /= l; ax[r][2] /= l; }
          dots[r] = arm::dot(ax[r], fu);
          ups[r] = ax[r][1];
        }
        G::log("ARMS %s arm move #%d: shoulder %.2f,%.2f,%.2f elbow %.2f,%.2f,%.2f -> %.2f,%.2f,%.2f wrist %.2f,%.2f,%.2f -> %.2f,%.2f,%.2f (feet, game world); "
               "upper arm %.3f ft, forearm %.3f ft, reach %d%% clamped=%d twisted=%d stretch=%.2f; hand axes vs forearm %.2f/%.2f/%.2f vs up %.2f/%.2f/%.2f; body scale %.3f",
               s ? "left" : "right", first, S[0], S[1], S[2], E0[0], E0[1], E0[2], k.E[0], k.E[1], k.E[2], Hp[0], Hp[1], Hp[2], k.T[0], k.T[1], k.T[2],
               (double)st.lastL1[s], (double)st.lastL2[s], rx, k.clamped, k.twisted, sc, dots[0], dots[1], dots[2], ups[0], ups[1], ups[2],
               vm::dsqrt(sp.A[0] * sp.A[0] + sp.A[1] * sp.A[1] + sp.A[2] * sp.A[2]));
      }
    }
    float holdH[16]; int holdOk = 0;   // 1.7.181: the right hand as the gun-hold solve left it (the PKE bones / PKE model are placed through it, below)
    if (t->mirrorArms == 1 && (solvedArm[0] || solvedArm[1])) {   // 1.7.174 left-handed: each arm is drawn at the OTHER arm's target (display_arm)
      ARMCORE_CRUMB("apply:lefthanded", 0);
      if (solvedArm[0] && c.arm[0].U >= 0) { copy12(holdH, world + (size_t)16 * c.arm[0].H); holdOk = 1; }
      disp.okF[0] = 0;
      if (holdOk && mirOk) {   // 1.7.181: the left hand that holds the gun is the mirror image of the right hand the game holds it with
        double Fr[9], Fo[9];
        frame_raw(sp, holdH, Fr);
        if (mirror_hand_frame(local, sp, 0, Fr, mirN, Fo)) { for (int i = 0; i < 9; ++i) disp.F[0][i] = Fo[i]; disp.wF[0] = 1.0; disp.okF[0] = 1; }
      }
      for (int s = 0; s < 2; ++s) {
        const int o = 1 - s;
        if (c.arm[s].U < 0) continue;
        if (disp.ok[o]) { if (display_arm(world, local, n, sp, t, s, disp.T[o], disp.f[o], disp.u[o], disp.okF[o] ? disp.F[o] : nullptr, disp.wF[o])) ++st.dispSolved[s]; else ++st.dispFail[s]; }
        else if (solvedArm[s]) {   // the other hand has no target (its controller is not tracked): this arm goes back to the animation, it does not stay on the other hand's side
          const ArmInfo& a = c.arm[s];
          if (!t->floatingArms && c.clav[s] >= 0) rebuild_bone(world, local, c.clav[s]);
          alignas(16) float Wc[MAXPATH][16];
          for (int j = 0; j < MAXPATH; ++j) for (int i = 0; i < 16; ++i) Wc[j][i] = 0;
          chain_world(local, world, a, Wc);
          write_chain(world, local, n, a, Wc[0], Wc[1], Wc[a.plen - 1]);
          copy12(ao[s].u, world + (size_t)16 * a.U); copy12(ao[s].h, world + (size_t)16 * a.H);
          w[s].world = world; w[s].U = a.U; w[s].H = a.H; copy12(w[s].u, Wc[0]); copy12(w[s].h, Wc[a.plen - 1]); w[s].have = 1;
          ao[s].have = 0;   // 1.7.175: do not let the arm guard treat this animation pose as 'already solved' on the next call (left-handed arm stayed in the animation)
          ++st.dispNoTarget[s];
        }
      }
    }
    ARMCORE_CRUMB("apply:pke", 0);
    {   // 1.7.181 left-handed: the PKE hangs on the hand of the gun-hold solve (the right hand at your gun controller), not on the right arm as it was DRAWN (at the free controller)
      const int swapH = t->mirrorArms == 1 && holdOk && ((pw.ok && pw.hand == 0) || (pk.ok && pk.hand == 0));
      float drawnH0[16];
      if (swapH) { copy12(drawnH0, world + (size_t)16 * c.arm[0].H); copy12(world + (size_t)16 * c.arm[0].H, holdH); }
      if (pw.ok) pkew_apply(world, sp, &pw);   // 0.85
      if (pk.ok) pke_apply(world, &pk);   // 0.84: after both hands are placed
      if (swapH) copy12(world + (size_t)16 * c.arm[0].H, drawnH0);
    }
    ARMCORE_CRUMB("apply:snapshot", 0);
    if (t->rigOn) snapshot_rig(world, n, sp, t);   // 0.74: the whole skeleton as it stands now, before anything is squashed
    ARMCORE_CRUMB("apply:collapse", 0);
    if (t->armsOnly) collapse_body(world, n, sp, t);   // 0.71: last of all, after the arms are placed
    {
      const int64_t tc3 = G::clock();
      st.tEnsure += tc1 - tc0; st.tTorso += tc2 - tc1; st.tArms += tc3 - tc2; st.tTotal += tc3 - tc0; ++st.timed;
    }
    if (t->stereoRole == 1 && t->stereoPair) {
      stereoCache.actor = actor; stereoCache.skel = (uintptr_t)skel;
      stereoCache.local = (uintptr_t)engineLocal; stereoCache.world = (uintptr_t)world; stereoCache.n = n;
      stereoCache.result = movedAny;
      for (int i = 0; i < 16; ++i) stereoCache.W[i] = W2[i];
      for (int i = 0; i < n; ++i) for (int k = 0; k < 16; ++k) stereoCache.bones[i][k] = world[16 * i + k];
      stereoCache.pair = t->stereoPair;
      ++st.stereoSaved;
    }
    return movedAny;
  }

  // Later in the same render pass: is what was written still what the model holds? (If the engine recomputed its bone matrices
  // after the product, the arms would look unmoved and this counts it.)
  static void verify(uintptr_t actor) {
    for (int s = 0; s < 2; ++s) {
      if (!w[s].have) continue;
      w[s].have = 0;
      const uint8_t* M = (const uint8_t*)actor + layout::kOffActorModel;
      if (!G::readable(M + layout::kOffModelWorld, 8, 0)) continue;
      const float* world = *(const float* const*)(M + layout::kOffModelWorld);
      if (world != w[s].world || !G::readable(world, (size_t)(w[s].H + 1) * 64, 0)) { ++st.verifyLost; continue; }
      int same = 1;
      const float* u = world + (size_t)16 * w[s].U;
      const float* h = world + (size_t)16 * w[s].H;
      for (int r = 0; r < 4; ++r) for (int cc = 0; cc < 3; ++cc) {
        if (u[r * 4 + cc] != w[s].u[r * 4 + cc]) same = 0;
        if (h[r * 4 + cc] != w[s].h[r * 4 + cc]) same = 0;
      }
      if (same) ++st.verifyKept; else ++st.verifyLost;
    }
  }
};

}  // namespace armcore
