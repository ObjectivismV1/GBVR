// 0.57 the game's own arms follow the real hands. Pure math, no Windows dependency; unit-tested in tests/test_arm.cpp.
//
// The game's player model is a skinned skeleton: every bone has a 4x4 matrix in MODEL space (row vectors, translation in
// row 3, cached by the model instance). Drawing places the model with the actor's world matrix W (model -> world:
// p_world = p_model * A + t, A = W's 3x3 incl. the body scale). To move an arm the three bones of the chain
// (upper arm U, forearm F, hand H) get new matrices; everything below them (fingers, twist bones) is recomputed by the
// engine's own local-to-parent rule, so whatever skin or weapon variant is equipped, its own bones follow.
//
// All the solving is done in WORLD space (feet) in double precision:
//   1. two-bone IK: shoulder S stays, the wrist is put at T (clamped to the arm's reach), the elbow goes into the plane
//      that hangs "down" (blended with where the animation had it),
//   2. U is turned by the smallest rotation that takes (E - S) to (E' - S), plus a twist about that axis that keeps the
//      elbow hinge plane; F is turned by the smallest rotation that takes its direction to (T' - E'),
//   3. the hand takes a rigid motion (the wand's, for the gun hand) or a swing to the controller direction.
// A rotation Q is a 3x3 matrix in column form (v' = Q v), like weight::axis_angle makes them.
#pragma once
#include "vmath.h"
#include "weightmath.h"

namespace arm {

inline double dot(const double* a, const double* b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
inline double len(const double* a) { return vm::dsqrt(dot(a, a)); }
inline void sub(const double* a, const double* b, double* o) { o[0] = a[0] - b[0]; o[1] = a[1] - b[1]; o[2] = a[2] - b[2]; }
inline void add(const double* a, const double* b, double* o) { o[0] = a[0] + b[0]; o[1] = a[1] + b[1]; o[2] = a[2] + b[2]; }
inline void scale(const double* a, double k, double* o) { o[0] = a[0] * k; o[1] = a[1] * k; o[2] = a[2] * k; }
inline void cross(const double* a, const double* b, double* o) {
  double t[3] = {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
  o[0] = t[0]; o[1] = t[1]; o[2] = t[2];
}
inline int unit(const double* a, double* o) {
  double l = len(a);
  if (!(l > 1e-9)) return 0;
  o[0] = a[0] / l; o[1] = a[1] / l; o[2] = a[2] / l;
  return 1;
}
inline void apply3(const double* Q, const double* v, double* o) {   // Q v (column form)
  double t[3] = {Q[0] * v[0] + Q[1] * v[1] + Q[2] * v[2], Q[3] * v[0] + Q[4] * v[1] + Q[5] * v[2], Q[6] * v[0] + Q[7] * v[1] + Q[8] * v[2]};
  o[0] = t[0]; o[1] = t[1]; o[2] = t[2];
}

// The rotation that takes unit vector a to unit vector b by the shortest way.
inline void swing(const double* a, const double* b, double* R) {
  double ax[3];
  cross(a, b, ax);
  double sn = len(ax), cs = dot(a, b);
  if (sn > 1e-9) {
    scale(ax, 1.0 / sn, ax);
    weight::axis_angle(ax, vm::datan2(sn, cs), R);
  } else if (cs > 0) {
    weight::ident(R);
  } else {   // opposite: half a circle about any axis perpendicular to a
    double h[3] = {1, 0, 0};
    if (vm::dabs(a[0]) > 0.9) { h[0] = 0; h[1] = 1; }
    cross(a, h, ax);
    unit(ax, ax);
    weight::axis_angle(ax, vm::kPi, R);
  }
}

// Model <-> world for one render: p_world = p_model * A + t.
struct Space {
  double A[9], Ai[9], t[3];
  int ok;
  int set(const float* W) {   // W: 16 floats, the actor's model -> world matrix
    ok = 0;
    for (int r = 0; r < 3; ++r) { for (int c = 0; c < 3; ++c) A[r * 3 + c] = W[r * 4 + c]; t[r] = W[12 + r]; }
    double c0 = A[4] * A[8] - A[5] * A[7], c1 = A[5] * A[6] - A[3] * A[8], c2 = A[3] * A[7] - A[4] * A[6];
    double d = A[0] * c0 + A[1] * c1 + A[2] * c2;
    if (!(vm::dabs(d) > 1e-9)) return 0;
    double id = 1.0 / d;
    Ai[0] = c0 * id;                           Ai[1] = (A[2] * A[7] - A[1] * A[8]) * id;  Ai[2] = (A[1] * A[5] - A[2] * A[4]) * id;
    Ai[3] = c1 * id;                           Ai[4] = (A[0] * A[8] - A[2] * A[6]) * id;  Ai[5] = (A[2] * A[3] - A[0] * A[5]) * id;
    Ai[6] = c2 * id;                           Ai[7] = (A[1] * A[6] - A[0] * A[7]) * id;  Ai[8] = (A[0] * A[4] - A[1] * A[3]) * id;
    for (int i = 0; i < 9; ++i) if (!vm::is_finite_f((float)Ai[i])) return 0;
    ok = 1;
    return 1;
  }
  void dir_world(const double* m, double* w) const {   // row vector times A
    double t0 = m[0] * A[0] + m[1] * A[3] + m[2] * A[6], t1 = m[0] * A[1] + m[1] * A[4] + m[2] * A[7], t2 = m[0] * A[2] + m[1] * A[5] + m[2] * A[8];
    w[0] = t0; w[1] = t1; w[2] = t2;
  }
  void dir_model(const double* w, double* m) const {
    double t0 = w[0] * Ai[0] + w[1] * Ai[3] + w[2] * Ai[6], t1 = w[0] * Ai[1] + w[1] * Ai[4] + w[2] * Ai[7], t2 = w[0] * Ai[2] + w[1] * Ai[5] + w[2] * Ai[8];
    m[0] = t0; m[1] = t1; m[2] = t2;
  }
  void point_world(const float* pm, double* w) const {
    double m[3] = {pm[0], pm[1], pm[2]};
    dir_world(m, w);
    w[0] += t[0]; w[1] += t[1]; w[2] += t[2];
  }
  void point_model(const double* w, float* pm) const {
    double d[3] = {w[0] - t[0], w[1] - t[1], w[2] - t[2]}, m[3];
    dir_model(d, m);
    pm[0] = (float)m[0]; pm[1] = (float)m[1]; pm[2] = (float)m[2];
  }
  // new model matrix of a bone: its axis rows turned by the world rotation Q, its origin put at newPosW (world)
  void place(const float* B, const double* Q, const double* newPosW, float* out) const {
    for (int i = 0; i < 16; ++i) out[i] = B[i];
    for (int r = 0; r < 3; ++r) {
      double m[3] = {B[r * 4], B[r * 4 + 1], B[r * 4 + 2]}, w[3];
      dir_world(m, w);
      apply3(Q, w, w);
      dir_model(w, m);
      out[r * 4] = (float)m[0]; out[r * 4 + 1] = (float)m[1]; out[r * 4 + 2] = (float)m[2];
    }
    point_model(newPosW, out + 12);
  }
};

struct Ik {
  double E[3];        // new elbow (world)
  double T[3];        // wrist after clamping (world)
  double QU[9];       // world rotation of the upper arm (about the shoulder)
  double Q2[9];       // extra world rotation of the forearm (about the new elbow)
  double reach;       // wanted distance shoulder -> wrist divided by the arm's length (1 = fully stretched)
  int clamped;        // wrist could not be reached
  int twisted;        // hinge twist applied
};

// S, E0, W0: shoulder, elbow, wrist of the animation (world); T: where the wrist should be. downBias: how strongly the
// elbow is pulled down (1 = as strong as the animation's own elbow direction counts 0.5).
// fallback (0.61, legs): a direction the joint should bend towards when the animation's own bend is too small to tell (the knee goes forward)
inline int solve(const double* S, const double* E0, const double* W0, const double* T, double downBias, Ik* o, const double* fallback = nullptr) {
  double e0v[3], f0v[3];
  sub(E0, S, e0v); sub(W0, E0, f0v);
  double l1 = len(e0v), l2 = len(f0v);
  if (!(l1 > 1e-3) || !(l2 > 1e-3)) return 0;
  double v[3];
  sub(T, S, v);
  double d = len(v);
  if (!(d > 1e-4)) return 0;
  double u[3];
  scale(v, 1.0 / d, u);
  double dmax = (l1 + l2) * 0.999, dmin = vm::dabs(l1 - l2) * 1.001 + 1e-4;
  o->reach = d / (l1 + l2);
  o->clamped = d > dmax;
  double dc = d < dmin ? dmin : (d > dmax ? dmax : d);
  for (int i = 0; i < 3; ++i) o->T[i] = S[i] + u[i] * dc;
  // elbow: on the circle of points at l1 from S and l2 from the wrist
  double a = (l1 * l1 - l2 * l2 + dc * dc) / (2.0 * dc);
  double h2 = l1 * l1 - a * a;
  double h = h2 > 0 ? vm::dsqrt(h2) : 0.0;
  double hint[3] = {0, 0, 0};
  {   // where the animation had the elbow, off the new shoulder-wrist line
    double k = dot(e0v, u), p[3] = {e0v[0] - u[0] * k, e0v[1] - u[1] * k, e0v[2] - u[2] * k};
    if (len(p) > 1e-3 * l1) unit(p, hint);
  }
  double dn[3] = {0, -downBias, 0};
  double c[3] = {hint[0] * 0.5 + dn[0], hint[1] * 0.5 + dn[1], hint[2] * 0.5 + dn[2]};
  if (fallback) for (int i = 0; i < 3; ++i) c[i] += fallback[i] * 0.6;
  double kk = dot(c, u);
  double pole[3] = {c[0] - u[0] * kk, c[1] - u[1] * kk, c[2] - u[2] * kk};
  if (!unit(pole, pole)) {
    if (!unit(hint, pole)) {   // nothing to go by: any direction perpendicular to u
      double r[3] = {1, 0, 0};
      if (vm::dabs(u[0]) > 0.9) { r[0] = 0; r[2] = 1; }
      cross(u, r, pole);
      if (!unit(pole, pole)) return 0;
    }
  }
  for (int i = 0; i < 3; ++i) o->E[i] = S[i] + u[i] * a + pole[i] * h;
  // upper arm: smallest turn, then a twist about the new bone axis that keeps the elbow hinge plane
  double e0[3], e1[3], ev[3];
  unit(e0v, e0);
  sub(o->E, S, ev);
  if (!unit(ev, e1)) return 0;
  double Q1[9];
  swing(e0, e1, Q1);
  weight::ident(o->QU);
  for (int i = 0; i < 9; ++i) o->QU[i] = Q1[i];
  o->twisted = 0;
  {
    double n0[3];
    cross(e0v, f0v, n0);
    if (len(n0) > 0.12 * l1 * l2) {
      double n1[3], f2v[3], n2[3];
      apply3(Q1, n0, n1);
      sub(o->T, o->E, f2v);
      cross(ev, f2v, n2);
      if (len(n2) > 1e-4 * l1 * l2) {
        // components perpendicular to e1
        double k1 = dot(n1, e1), p1[3] = {n1[0] - e1[0] * k1, n1[1] - e1[1] * k1, n1[2] - e1[2] * k1};
        double k2 = dot(n2, e1), p2[3] = {n2[0] - e1[0] * k2, n2[1] - e1[1] * k2, n2[2] - e1[2] * k2};
        if (unit(p1, p1) && unit(p2, p2)) {
          double cx[3];
          cross(p1, p2, cx);
          double ang = vm::datan2(dot(cx, e1), dot(p1, p2));
          double Qt[9];
          weight::axis_angle(e1, ang, Qt);
          weight::mul3(Qt, Q1, o->QU);
          o->twisted = 1;
        }
      }
    }
  }
  // forearm: smallest turn from where the upper arm's turn left it to the wrist
  double f1[3], f2[3], f2v[3];
  apply3(o->QU, f0v, f1);
  unit(f1, f1);
  sub(o->T, o->E, f2v);
  if (!unit(f2v, f2)) return 0;
  swing(f1, f2, o->Q2);
  for (int i = 0; i < 3; ++i) if (!vm::is_finite_f((float)o->E[i]) || !vm::is_finite_f((float)o->T[i])) return 0;
  for (int i = 0; i < 9; ++i) if (!vm::is_finite_f((float)o->QU[i]) || !vm::is_finite_f((float)o->Q2[i])) return 0;
  return 1;
}

// A raised hand needs the elbow to bend outward instead of hanging directly below
// the shoulder. Keep the usual pole for hands at chest height and below; ease the
// downward pull away as the wrist rises, without moving the tracked wrist.
inline double raised_elbow_down(const double* shoulder, const double* wrist, double armLength, double downBias) {
  if (!(armLength > 1e-4)) return downBias;
  double h = (wrist[1] - shoulder[1]) / (0.55 * armLength);
  if (h < 0.0) h = 0.0;
  if (h > 1.0) h = 1.0;
  const double ease = h * h * (3.0 - 2.0 * h);
  return downBias * (1.0 - 0.65 * ease);
}

// Small leg extensions let an ankle stay planted when the tracked head raises
// the pelvis beyond the animated leg's reach. Limit mesh stretch to eight percent.
inline double planted_leg_scale(double hipToAnkle, double legLength) {
  if (!(legLength > 1e-4) || hipToAnkle <= 0.999 * legLength) return 1.0;
  double scale = hipToAnkle / (0.999 * legLength);
  return scale < 1.08 ? scale : 1.08;
}

// 0.61: a rotation (column form) turned by only the fraction f of its angle, and limited to maxRad; returns the original angle (radians)
inline double rot_part(const double* Q, double f, double maxRad, double* o) {
  double v[3];
  weight::rot_vector(Q, v);
  double a = len(v);
  if (!(a > 1e-9)) { weight::ident(o); return 0.0; }
  double ax[3] = {v[0] / a, v[1] / a, v[2] / a};
  double na = a * f;
  if (maxRad > 0 && na > maxRad) na = maxRad;
  weight::axis_angle(ax, na, o);
  return a;
}

// 0.77 forearm roll. R: a world rotation (column form). a: a unit axis (world). Returns the part of R that is a turn about a, in (-pi, pi]
// (swing-twist split: the quaternion's vector part projected on a).
inline double twist_about(const double* R, const double* a) {
  double w, x, y, z;
  const double tr = R[0] + R[4] + R[8];
  if (tr > 0.0) {
    const double s = 2.0 * vm::dsqrt(tr + 1.0);
    w = 0.25 * s; x = (R[7] - R[5]) / s; y = (R[2] - R[6]) / s; z = (R[3] - R[1]) / s;
  } else if (R[0] > R[4] && R[0] > R[8]) {
    const double s = 2.0 * vm::dsqrt(1.0 + R[0] - R[4] - R[8]);
    w = (R[7] - R[5]) / s; x = 0.25 * s; y = (R[1] + R[3]) / s; z = (R[2] + R[6]) / s;
  } else if (R[4] > R[8]) {
    const double s = 2.0 * vm::dsqrt(1.0 + R[4] - R[0] - R[8]);
    w = (R[2] - R[6]) / s; x = (R[1] + R[3]) / s; y = 0.25 * s; z = (R[5] + R[7]) / s;
  } else {
    const double s = 2.0 * vm::dsqrt(1.0 + R[8] - R[0] - R[4]);
    w = (R[3] - R[1]) / s; x = (R[2] + R[6]) / s; y = (R[5] + R[7]) / s; z = 0.25 * s;
  }
  const double d = x * a[0] + y * a[1] + z * a[2];
  double ang = 2.0 * vm::datan2(d, w);
  const double twoPi = 2.0 * vm::kPi;
  if (ang > vm::kPi) ang -= twoPi;
  else if (ang <= -vm::kPi) ang += twoPi;
  return ang;
}

// The extra turn about the forearm's axis a that lets the forearm take `share` (0..1) of the hand's turn relative to it:
// the hand's world rotation is Qh, the forearm's is QF. Writes Qt (a world rotation, applied AFTER QF: forearm' = Qt * QF). Returns the angle given (radians).
inline double forearm_roll(const double* Qh, const double* QF, const double* a, double share, double* Qt) {
  double QFt[9], R[9];
  weight::transpose3(QF, QFt);
  weight::mul3(Qh, QFt, R);
  const double th = twist_about(R, a);
  const double g = th * (share < 0.0 ? 0.0 : share > 1.0 ? 1.0 : share);
  weight::axis_angle(a, g, Qt);
  return g;
}

// 1.7.146 / 1.7.150 "the left hand gets twisted up": twist_about() gives the hand's turn about the forearm wrapped to -180..180 degrees. When the hand's turn relative to
// the forearm passes 180 degrees (a hand under the barrel, palm up), it jumps from +180 to -180 and the forearm's share (50 %) jumped from +90 to -90: the forearm spun
// half a turn in one frame and the skin between elbow and wrist twisted.
// 1.7.146 kept the angle continuous from the last frame; the recheck found that one tracking glitch could leave that memory a whole turn off, and the forearm then stayed
// twisted 100 degrees until the hand went round again. 1.7.150 has NO memory: the forearm's share fades out as the turn nears 180 degrees (full up to 120, none from 175),
// so it is zero on both sides of the jump. Nothing can flip and nothing can get stuck; near a half turn the wrist carries the turn for that moment.
struct RollMemory { long faded, capped; };
inline double roll_fade(double th) {   // 1 up to 120 degrees, smooth to 0 at 175 and beyond
  const double a = vm::dabs(th) * 180.0 / vm::kPi;
  if (a <= 120.0) return 1.0;
  if (a >= 175.0) return 0.0;
  const double x = (175.0 - a) / 55.0;
  return x * x * (3.0 - 2.0 * x);
}
inline double forearm_roll_cont(const double* Qh, const double* QF, const double* a, double share, RollMemory* m, double maxShareRad, double* Qt) {
  double QFt[9], R[9];
  weight::transpose3(QF, QFt);
  weight::mul3(Qh, QFt, R);
  const double th = twist_about(R, a);
  const double f = roll_fade(th);
  if (m && f < 1.0) ++m->faded;
  double g = th * (share < 0.0 ? 0.0 : share > 1.0 ? 1.0 : share) * f;
  if (maxShareRad > 0.0 && (g > maxShareRad || g < -maxShareRad)) { g = g > 0.0 ? maxShareRad : -maxShareRad; if (m) ++m->capped; }
  weight::axis_angle(a, g, Qt);
  return g;
}

// a * b of two 4x4 row-major row-vector matrices (float)
inline void mul4(const float* a, const float* b, float* o) {
  float t[16];
  for (int r = 0; r < 4; ++r)
    for (int c = 0; c < 4; ++c)
      t[r * 4 + c] = a[r * 4] * b[c] + a[r * 4 + 1] * b[4 + c] + a[r * 4 + 2] * b[8 + c] + a[r * 4 + 3] * b[12 + c];
  for (int i = 0; i < 16; ++i) o[i] = t[i];
}

// the wrist for a free hand: the controller origin (world), moved back along the hand's forward and down along its up
inline void free_wrist(const double* pos, const double* fwd, const double* up, double backFt, double downFt, double* o) {
  for (int i = 0; i < 3; ++i) o[i] = pos[i] - fwd[i] * backFt - up[i] * downFt;
}

}  // namespace arm
