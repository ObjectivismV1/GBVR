// 0.57 the game's own arms follow the real hands.
//
// The player's body is a skinned model instance (actor+0x430, layout.h "0.57 skeleton"): a skeleton (bone names, parents)
// and a cache of one 3x4 matrix per bone in model space. The render pass multiplies the body's world matrix with the view
// right before it asks the model to draw (0xD213F -> 0x15640); body_push() in engine_hooks.cpp calls arms_apply() from
// that product. armcore.h does the work: the three bones of each arm (upper arm, forearm, hand) get new matrices (armmath.h:
// two-bone IK to the hand target) and everything below them (twist bones, fingers) is recomputed with the engine's own
// functions from its own local pose, so whichever skin or weapon variant is equipped, its own bones follow - nothing here is
// a fixed model. The chain's starting pose is rebuilt from the local pose and the (unchanged) parent matrices every call,
// so calling it twice for the same animation frame (two eyes) gives the same result.
//
// Nothing is trusted: the instance pointers, counts, bone names and parent order are checked before every use, any
// failure leaves the animation as the game made it and is counted (ARMS log line).
#include "gbvr.h"
#include <stdlib.h>
#include "armcore.h"
#include "memcache.h"
#include "packmath.h"
#include "hosemath.h"

#if GBVR_HEADTRACK

namespace {

typedef void(__fastcall* PFN_Ensure)(void* model);
typedef void(__fastcall* PFN_LocalMat)(const void* local, float* out);
typedef void(__fastcall* PFN_Mul34)(float* out, const float* a, const float* b);
PFN_Ensure f_ensure;
PFN_LocalMat f_local;
PFN_Mul34 f_mul;
LONG64 g_tEnsure, g_tReadable, g_nEnsure, g_nReadable;   // 0.65 timing of the engine call and the memory checks (QPC ticks)
int g_ready;   // 1 usable, -1 not (bytes differ), 0 not checked yet

struct Game {
  static void ensure(void* m) { LARGE_INTEGER a, b; QueryPerformanceCounter(&a); f_ensure(m); QueryPerformanceCounter(&b); g_tEnsure += b.QuadPart - a.QuadPart; ++g_nEnsure; }
  static void local(const void* l, float* out) { f_local(l, out); }
  static void mul(float* out, const float* a, const float* b) { f_mul(out, a, b); }
  static int readable(const void* p, size_t n, int write) {
    ++g_nReadable;
    return memcache::readable(p, n, write, 1);   // 0.66: cached (see memcache.h): VirtualQuery was the hidden cost of every call
  }
  static int64_t clock() { LARGE_INTEGER a; QueryPerformanceCounter(&a); return a.QuadPart; }
  template <class... A> static void log(const char* fmt, A... a) { log_line(fmt, a...); }
};
typedef armcore::Core<Game> Core;

}  // namespace

void arms_init() {
  struct Chk { uint32_t r; const uint8_t* b; } chk[3] = {
    {layout::kRvaModelEnsureWorld, layout::kBytesModelEnsureWorld},
    {layout::kRvaModelLocalToMatrix, layout::kBytesModelLocalToMatrix},
    {layout::kRvaModelMul34, layout::kBytesModelMul34}};
  int ok = 1;
  for (int c = 0; c < 3; ++c) {
    const uint8_t* p = (const uint8_t*)rva(chk[c].r);
    for (int i = 0; i < 16; ++i) if (p[i] != chk[c].b[i]) ok = 0;
  }
  if (ok) {
    f_ensure = (PFN_Ensure)rva(layout::kRvaModelEnsureWorld);
    f_local = (PFN_LocalMat)rva(layout::kRvaModelLocalToMatrix);
    f_mul = (PFN_Mul34)rva(layout::kRvaModelMul34);
  }
  g_ready = ok ? 1 : -1;
  log_line("ARMS skeleton code %s (bone functions %s): the game's arms %s", ok ? "found" : "NOT found", ok ? "match" : "differ in this build",
           ok ? "can follow the hands" : "stay as animated");
}

// 1.7.148 the game's own hose follows the drawn gun (hosemath.h). The hose instance (actor+0xD7B0) is checked to be the same model class as the body: its skeleton's
// bone count must equal the instance's, every parent must come before its bone, the memory must be readable, and the gun end of its longest bone chain must lie within
// 1.5 ft of the game's own gun. Anything else: nothing is written and 0 is returned (the caller then keeps the hose hidden, as before).
static struct { uintptr_t model, skel; int n, cn, gunAtStart, chain[hose::kMaxBones], parent[hose::kMaxBones]; long failRun, calls, ok, badLayout, notNear, mathFail, logged, held, heldStale; double lastEndFt; int64_t okQ; } g_hz;
static hose::Keeper g_keep; static uintptr_t g_keepModel;   // 1.7.182: file level, so a refused frame can hold the last bent pose
long arms_collapse_stat(int which) { const armcore::Stats& q = Core::st; return which == 0 ? q.colPasses : which == 1 ? q.colBones : which == 2 ? q.colUndone : which == 3 ? q.colNoArms : q.colBadPoint; }   // 1.7.185 BODYHIDE: how the arms-only squash is doing
long arms_hose_stat(int which) { return which == 0 ? g_hz.calls : which == 1 ? g_hz.ok : which == 2 ? g_hz.badLayout : which == 3 ? g_hz.notNear : which == 4 ? g_hz.mathFail : which == 5 ? g_hz.held : g_hz.heldStale; }
// 1.7.182 THE HOSE FLICKER: a frame in which the hose could not be bent (the log: the PKE put away / taken out, when the hose's gun end is briefly not at the game's gun) showed the
// game's own pose for that frame, which sits at the game's gun, so the hose jumped. Within 0.15 s of the last good bend the last bent pose is shown again instead (the pack end and
// the gun end stay where they were); after that the game's own pose, as before. Returns 1 when the held pose was written.
int arms_hose_hold(int stale) {
  if (g_ready != 1 || !g_hz.model || !g_hz.okQ || g_keep.n != g_hz.n || g_hz.n <= 0) return 0;
  LARGE_INTEGER now, fq; QueryPerformanceCounter(&now); QueryPerformanceFrequency(&fq);
  if ((now.QuadPart - g_hz.okQ) * 1000 > 150 * fq.QuadPart) return 0;
  const uint8_t* M = (const uint8_t*)g_hz.model;
  if (!Game::readable(M + layout::kOffModelWorld, 8, 0)) return 0;
  float* world = *(float* const*)(M + layout::kOffModelWorld);
  const int n = g_hz.n;
  if (!world || !Game::readable(world, (size_t)n * 64, 1)) return 0;
  for (int i = 0; i < n * 16; ++i) if ((i & 3) != 3) world[i] = g_keep.last[i];
  g_keep.have = 1;   // the cache is ours again: the next bend tells the game's new pose from it
  if (stale) ++g_hz.heldStale; else ++g_hz.held;
  return 1;
}

int arms_hose_follow(uintptr_t actor, const float* hoseGame, const float* hoseDraw, const float* gunGame, const float* gunDraw) {
  if (g_ready != 1 || !actor || !hoseGame || !hoseDraw || !gunGame || !gunDraw) return 0;
  ++g_hz.calls;
  const uint8_t* M = (const uint8_t*)actor + 0xD7B0;
  if (!Game::readable(M + layout::kOffModelBoneCount, 4, 0) || !Game::readable(M + layout::kOffModelLocal, 8, 0) || !Game::readable(M + layout::kOffModelWorld, 8, 0) ||
      !Game::readable(M + layout::kOffModelSkeleton, 8, 0) || !Game::readable(M + layout::kOffModelState, 4, 0)) { ++g_hz.badLayout; return 0; }
  const uint8_t* skel = *(const uint8_t* const*)(M + layout::kOffModelSkeleton);
  const uint8_t* local = *(const uint8_t* const*)(M + layout::kOffModelLocal);
  float* world = *(float* const*)(M + layout::kOffModelWorld);
  const int n = *(const int*)(M + layout::kOffModelBoneCount);
  if (!skel || !local || !world || n < 3 || n > hose::kMaxBones || !Game::readable(skel + 0x88, 4, 0) || *(const int*)(skel + 0x88) != n ||
      !Game::readable(skel, 0x8c + (size_t)n * 0x4c, 0) || !Game::readable(local, (size_t)n * 40, 0) || !Game::readable(world, (size_t)n * 64, 1)) { ++g_hz.badLayout; return 0; }
  if (g_hz.model != (uintptr_t)M || g_hz.skel != (uintptr_t)skel || g_hz.n != n) {
    g_hz.model = (uintptr_t)M; g_hz.skel = (uintptr_t)skel; g_hz.n = n; g_hz.cn = 0;
    for (int i = 0; i < n; ++i) g_hz.parent[i] = *(const int*)(skel + 0x8c + (size_t)i * 0x4c + 0x1c);
    g_hz.cn = hose::longest_chain(g_hz.parent, n, g_hz.chain, hose::kMaxBones);
    if (g_hz.logged < 3) {   // data: the hose's bones
      ++g_hz.logged;
      char line[900]; int o = 0;
      for (int i = 0; i < n && o < 820; ++i) {
        const char* nm = (const char*)(skel + 0x8c + (size_t)i * 0x4c);
        o += wsprintfA(line + o, "%s%d:", i ? " " : "", i);
        for (int k = 0; k < 0x18 && nm[k] && o < 880; ++k) line[o++] = (nm[k] >= 32 && nm[k] < 127) ? nm[k] : '?';
        o += wsprintfA(line + o, "<%d", g_hz.parent[i]);
      }
      line[o] = 0;
      log_line("HOSEBONES the game's hose has %d bones, its longest chain %d: %s", n, g_hz.cn, line);
    }
  }
  if (g_hz.cn < 3) { ++g_hz.badLayout; return 0; }
  Game::ensure((void*)M);
  // the bend itself (hosemath.h bend(): the game's own pose is kept apart from ours, the hose end must be within 2.5 ft of the game's gun, the pack end stays)
  hose::Keeper& keep = g_keep; uintptr_t& keepModel = g_keepModel;
  if (keepModel != (uintptr_t)M) { keep.have = 0; keepModel = (uintptr_t)M; g_hz.okQ = 0; }
  double endFt = 0.0;
  const int r = hose::bend(&keep, world, g_hz.parent, n, g_hz.chain, g_hz.cn, hoseGame, hoseDraw, gunGame, gunDraw, 2.5, &endFt);
  g_hz.lastEndFt = endFt;
  if (r < 0) { ++g_hz.notNear; if (arms_hose_hold(0)) return 1; return 0; }
  if (r == 0) {
    ++g_hz.mathFail; ++g_hz.failRun;
    // 1.7.199: after going back a level the hose kept being refused (911 + 4399 times per 30 s, report 01:33): forget the learned bones and the kept pose so they are read again from the new model
    if (g_hz.failRun >= 20) {
      static LONG s_rl; if (InterlockedIncrement(&s_rl) <= 6) {
        auto det3 = [](const float* m) { return (double)m[0] * ((double)m[5] * m[10] - (double)m[6] * m[9]) - (double)m[1] * ((double)m[4] * m[10] - (double)m[6] * m[8]) + (double)m[2] * ((double)m[4] * m[9] - (double)m[5] * m[8]); };
        int nonFinite = 0; for (int i = 0; i < n * 16; ++i) if (!(world[i] == world[i]) || world[i] > 1e8f || world[i] < -1e8f) { ++nonFinite; }
        const int c0 = g_hz.chain[0], c1 = g_hz.chain[g_hz.cn - 1];
        log_line("HOSERELEARN the hose maths was refused %ld times in a row: stage counts (move %ld, chain length %ld, a bone %ld), chain length %.3f, det(hoseGame) %.4f det(hoseDraw) %.4f det(gunGame) %.4f det(gunDraw) %.4f, bad numbers in the hose cache %d, chain ends at (%.2f %.2f %.2f) and (%.2f %.2f %.2f), hose matrix %.2f %.2f %.2f, end %.2f ft from the gun, %d bones: the hose bones are read again",
                 g_hz.failRun, keep.stageN[1], keep.stageN[2], keep.stageN[3], keep.dbgL, det3(hoseGame), det3(hoseDraw), det3(gunGame), det3(gunDraw), nonFinite,
                 (double)world[16 * c0 + 12], (double)world[16 * c0 + 13], (double)world[16 * c0 + 14], (double)world[16 * c1 + 12], (double)world[16 * c1 + 13], (double)world[16 * c1 + 14],
                 hoseGame[12], hoseGame[13], hoseGame[14], endFt, n);
      }
      g_hz.model = 0; g_hz.failRun = 0; keep.have = 0; keep.n = 0;
    }
    if (arms_hose_hold(0)) return 1;
    return 0;
  }
  g_hz.failRun = 0;
  ++g_hz.ok;
  { LARGE_INTEGER q; QueryPerformanceCounter(&q); g_hz.okQ = q.QuadPart; }
  return 1;
}

int arms_apply(uintptr_t actor, const float* W2, const ArmTargets* t) {
  if (g_ready != 1) return 0;
  ProfScope ps(PF_ARMS);
  return Core::apply(actor, W2, t);
}

// 0.66: how far the right wrist fell short of its target in the last arm pass (game world feet). 1 = fresh (this render), 0 = no data.
int arms_gun_miss(float out[3]) {
  if (g_ready != 1) return 0;
  const armcore::Stats& st = Core::st;
  if (!st.missClock[0]) return 0;
  LARGE_INTEGER now, fq;
  QueryPerformanceCounter(&now); QueryPerformanceFrequency(&fq);
  if ((now.QuadPart - st.missClock[0]) * 1000 > 40 * fq.QuadPart) return 0;
  for (int i = 0; i < 3; ++i) out[i] = st.lastMiss[0][i];
  return 1;
}

// 0.93: how far to slide the gun so its handle sits in the real hand (game feet). 1 = fresh (this render), 0 = none.
// 1.7.58: complete untouched-game-hand and final VR-hand world matrices for the right hand.
// The weapon/PKE hooks preserve the game's own hand-to-prop transform with these; no guessed cm offsets.
int arms_game_hand_pair(uintptr_t actor, float gameHand[16], float finalHand[16]) {
  if (g_ready != 1 || !actor || !gameHand || !finalHand) return 0;
  int64_t ck = 0;
  if (!Core::hand_pair_read(actor, gameHand, finalHand, &ck)) return 0;
  LARGE_INTEGER now, fq; QueryPerformanceCounter(&now); QueryPerformanceFrequency(&fq);
  return ck && (now.QuadPart - ck) * 1000 <= 160 * fq.QuadPart;
}

// 1.7.67: how much the right arm was lengthened in the last arm pass (100 = not at all); logged next to the hand's size so the two can be compared.
long arms_hand_cleaned(int s) { return g_ready == 1 && (s == 0 || s == 1) ? Core::st.handCleaned[s] : 0; }
int arms_right_finger_base_x10(int f) { return g_ready == 1 && f >= 0 && f < 5 ? (int)Core::st.fingerBaseX10[0][f] : 0; }   // 1.7.98
int arms_left_finger_base_x10(int f) { return g_ready == 1 && f >= 0 && f < 5 ? (int)Core::st.fingerBaseX10[1][f] : 0; }   // 1.7.103
int arms_finger_final_x10(int s, int f) { return g_ready == 1 && (s == 0 || s == 1) && f >= 0 && f < 5 ? Core::st.fingerFinalX10[s][f] : 0; }   // 1.7.104
int arms_finger_tg_x10(int s, int f) { return g_ready == 1 && (s == 0 || s == 1) && f >= 0 && f < 5 ? Core::st.fingerTgX10[s][f] : -1000; }
long arms_finger_skips(int s, int f) { return g_ready == 1 && (s == 0 || s == 1) && f >= 0 && f < 5 ? Core::st.fingerSkip[s][f] : 0; }
long arms_finger_empty_passes() { return g_ready == 1 ? Core::st.fingerEmptyPasses : 0; }
// 1.7.104: PKE alignment numbers of the last pass (see pkealignmath.h); 1 = a pass was made
int arms_align_info(long* passes, long* fails, double out[9]) {
  if (g_ready != 1) return 0;
  const auto& f = Core::frz;
  if (passes) *passes = f.alignN; if (fails) *fails = f.alignFail;
  out[0] = f.al.leanBeforeDeg; out[1] = f.al.leanAfterDeg; out[2] = f.al.pitchDeg; out[3] = f.al.swingDeg; out[4] = f.al.latBeforeFt; out[5] = f.al.latAfterFt; out[6] = f.al.fwdFt; out[7] = f.al.upFt; out[8] = f.al.pitchAfterDeg;
  return f.alignN > 0;
}
int arms_finger_axis_fixed(int side) { return g_ready == 1 ? Core::st.fingerAxisFixed[side ? 1 : 0] : 0; }   // 1.7.111
long arms_wrap_passes() { return g_ready == 1 ? Core::st.lWrapGripPasses : 0; }   // 1.7.109
int arms_wrap_tilt_x10() { return g_ready == 1 ? Core::st.lWrapTiltX10 : 0; }
long arms_bend_n() { return g_ready == 1 ? Core::st.lBendN : 0; }   // 1.7.215
long arms_bend_clamped() { return g_ready == 1 ? Core::st.lBendClamped : 0; }
int arms_bend_mean_x10() { return g_ready == 1 && Core::st.lBendN > 0 ? (int)(Core::st.lBendSumX10 / Core::st.lBendN) : 0; }
int arms_bend_last_x10() { return g_ready == 1 ? Core::st.lBendLastX10 : 0; }
int arms_orbit_shift_x10() { return g_ready == 1 ? Core::st.lOrbitShiftX10 : 0; }   // 1.7.220
int arms_orbit_bend0_x10() { return g_ready == 1 ? Core::st.lOrbitBend0X10 : 0; }
int arms_orbit_bend_x10() { return g_ready == 1 ? Core::st.lOrbitBendX10 : 0; }
long arms_orbit_n() { return g_ready == 1 ? Core::st.lOrbitN : 0; }
long arms_orbit_moved() { return g_ready == 1 ? Core::st.lOrbitMoved : 0; }
long arms_bend_fallback() { return g_ready == 1 ? Core::st.lBendFallback : 0; }
int arms_bend_max_x10() { return g_ready == 1 ? Core::st.lBendMaxX10 : 0; }
int arms_wrap_orbit_x10() { return g_ready == 1 ? Core::st.lWrapOrbitX10 : 0; }   // where round the barrel the hand sits: 0 = under it, + = to the left, deg x10
long arms_grab_passes() { return g_ready == 1 ? Core::st.lGrabPasses : 0; }   // 1.7.105: arm-solver passes with the hand held on the gun by the fore grab (running total)
int arms_left_finger_kept() { return g_ready == 1 ? (int)Core::st.leftFingerKept : 0; }   // 1.7.103
int arms_right_stretch_x100() { return g_ready == 1 ? (int)Core::st.lastStretchX100[0] : 100; }

// 1.7.76: the hand turned with the controller (PKE in hand): captured / applied passes, how far the old rules (the animation's turn) would have been off, in degrees x10
void arms_frz_stats(long* captured, long* applied, int* lastDevX10, int* maxDevX10, int* meanDevX10) {
  const auto& f = Core::frz;
  if (captured) *captured = f.captured; if (applied) *applied = f.applied;
  if (lastDevX10) *lastDevX10 = (int)(f.lastDevDeg * 10.0); if (maxDevX10) *maxDevX10 = (int)(f.maxDevDeg * 10.0);
  if (meanDevX10) *meanDevX10 = f.applied ? (int)(f.sumDevDeg / (double)f.applied * 10.0) : 0;
}
// 1.7.77: counters of the arm code, for the gun-gap log (what failed while the gun had no hand)
void arms_fail_snapshot(long out[12]) {
  const auto& st = Core::st;
  out[0] = st.calls; out[1] = st.moved[0]; out[2] = st.ikFail; out[3] = st.nonFinite; out[4] = st.noTarget[0]; out[5] = st.badSpace[0]; out[6] = st.badLen[0];
  out[7] = st.noModel; out[8] = st.badBones; out[9] = st.badLayout; out[10] = st.armSkipped[0]; out[11] = st.clamped[0];
}
void arms_frz_reset() { Core::frz_reset(); }

int arms_mirror_info(long* right, long* left, long* bad) { if (g_ready != 1) return 0; *right = Core::st.dispSolved[0]; *left = Core::st.dispSolved[1]; *bad = Core::st.dispFail[0] + Core::st.dispFail[1] + Core::st.dispNoTarget[0] + Core::st.dispNoTarget[1]; return 1; }   // 1.7.174: left-handed drawn arms
long arms_pke_hide_passes() { return g_ready == 1 ? (long)Core::st.pkeHidePasses : -1; }

int arms_grip_shift(float out[3]) {
  if (g_ready != 1) return 0;
  const armcore::Stats& st = Core::st;
  if (!st.gripShiftClock) return 0;
  LARGE_INTEGER now, fq;
  QueryPerformanceCounter(&now); QueryPerformanceFrequency(&fq);
  if ((now.QuadPart - st.gripShiftClock) * 1000 > 40 * fq.QuadPart) return 0;
  for (int i = 0; i < 3; ++i) out[i] = st.gripShift[i];
  return 1;
}

// 1.7.2: the right hand's numbers of this moment for the HOLDCHECK line (game feet): where the wrist is going (the controller point), how far it fell short, and
// the game's own hand-minus-weapon-origin offset (what the weapon is slid back by). 1 = fresh (this render), 0 = no data.
int arms_hold_numbers(float wrist[3], float miss[3], float animOff[3]) {
  if (g_ready != 1) return 0;
  const armcore::Stats& st = Core::st;
  if (!st.missClock[0]) return 0;
  LARGE_INTEGER now, fq;
  QueryPerformanceCounter(&now); QueryPerformanceFrequency(&fq);
  if ((now.QuadPart - st.missClock[0]) * 1000 > 60 * fq.QuadPart) return 0;
  for (int i = 0; i < 3; ++i) { wrist[i] = st.lastT[0][i]; miss[i] = st.lastMiss[0][i]; animOff[i] = st.gripOff[i]; }
  return 1;
}

// 1.7.1: the hands' finger numbers of this moment as text (for the F2 line): per hand, how far the game's animation has each finger bent -> how far it is drawn (degrees),
// whether the right hand is in the gun-hand finger mode, and how often the left fingers were wrapped on the foregrip. Proof for "is the hand closed around the weapon".
void arms_finger_text(char* out, int cap) {
  if (!out || cap < 8) return;
  out[0] = 0;
  if (g_ready != 1) { log_fmt(out, cap, "arms not ready"); return; }
  const armcore::Stats& s = Core::st;
  static const char* nm[5] = {"thumb", "index", "middle", "ring", "pinkie"};
  int len = 0;
  for (int h = 0; h < 2; ++h) {
    len += log_fmt(out + len, cap - len, "%s hand (animation->drawn deg):", h ? "LEFT" : "RIGHT");
    for (int f = 1; f < 5 && len < cap - 40; ++f) len += log_fmt(out + len, cap - len, " %s %d->%d", nm[f], s.fingerBaseX10[h][f] / 10, s.fingerWantX10[h][f] / 10);
    if (len < cap - 2) len += log_fmt(out + len, cap - len, "; ");
  }
  if (len < cap - 120) log_fmt(out + len, cap - len, "right gun-hand passes=%d, left foregrip wrapped passes=%d (of %d on the foregrip), left pull weight now %d%%", s.gunFingerPasses, s.lWrapPasses, s.lMagN, (int)(s.lMagWNow * 100.0));
}

// 0.68: what the last torso pass did (drop, lean rotations) so the pack can do the same. 1 = fresh (this render), 0 = none.
int arms_torso_motion(bpack::Motion* out) {
  if (g_ready != 1) return 0;
  const armcore::Stats::Motion& m = Core::st.motion;
  if (!m.have || !m.clock) return 0;
  LARGE_INTEGER now, fq;
  QueryPerformanceCounter(&now); QueryPerformanceFrequency(&fq);
  // 0.76: 250 ms (was 40 ms): the body pass and the pack pass are not always in the same render, and a 40 ms window made the pack miss the torso's move whenever they were
  if ((now.QuadPart - m.clock) * 1000 > 250 * fq.QuadPart) return 0;
  out->have = 1; out->drop = m.drop;
  for (int i = 0; i < 3; ++i) out->shift[i] = m.shift[i];
  for (int s = 0; s < 2; ++s) { for (int i = 0; i < 3; ++i) out->pv[s][i] = m.pv[s][i]; for (int i = 0; i < 9; ++i) out->Q[s][i] = m.Q[s][i]; }
  return 1;
}

// 1.7.100: how many times the player's model / skeleton was looked at again from scratch (a new outfit, a new character model, a streamed rig): 0 when the arm layer is not usable
int arms_revalidations() { return g_ready == 1 ? Core::st.revalidations : 0; }
// 0.69: the eye height of the unscaled model above its feet, the most common value (a histogram peak). 0 = not known yet.
float arms_model_eye_ft() {
  if (g_ready != 1) return 0.0f;
  const armcore::Stats& st = Core::st;
  return st.modelEyeN >= 60 ? st.modelEyeFt : 0.0f;
}

int arms_rig_read(rig::Snap* out) {
  if (g_ready != 1) return 0;
  return Core::rig_read(out);
}
void arms_rig_part(int which, const float* W2, const double* view9, const double* eye3) {
  if (g_ready != 1) return;
  Core::rig_part(which, W2, view9, eye3);
}

void arms_wall_snap(ArmsWallSnap* o) {
  const armcore::Stats& s = Core::st;
  o->calls = s.calls; o->moved = s.moved[0]; o->badSpace = s.badSpace[0] + s.badSpace[1]; o->badLen = s.badLen[0] + s.badLen[1];
  o->clamped = s.clamped[0] + s.clamped[1]; o->nonFinite = s.nonFinite; o->gripNoPose = s.gripNoPose; o->torsoFail = s.torsoFail;
  o->missOver = s.missOver[0]; o->shiftCapped = s.shiftCapped; o->verifyLost = s.verifyLost; o->forcedCalls = s.forcedCalls; o->eyeErrMaxX100 = s.eyeErrMaxX100;
}

int arms_pke_wand(float out[16]) {   // 0.85: where the PKE (the wand-slot model) must be so that it sits in the hand the way the game holds it; 1 = fresh (under 0.3 s)
  if (g_ready != 1) return 0;
  int64_t ck = 0;
  if (!Core::pke_wand_read(out, &ck)) return 0;
  LARGE_INTEGER now, fq; QueryPerformanceCounter(&now); QueryPerformanceFrequency(&fq);
  return (now.QuadPart - ck) < fq.QuadPart * 3 / 10;
}

void arms_verify(uintptr_t actor) {
  if (g_ready != 1) return;
  Core::verify(actor);
}

void arms_report(LONG frame) {
  log_line("BODYPAIR saved=%ld reused=%ld (one finished skeleton per stereo pair)", Core::st.stereoSaved, Core::st.stereoReused);
  armcore::Stats& g_st = Core::st;
  log_line("ARMS frame=%d ik=%d ready=%d calls=%d moved(right/left)=%d/%d noTarget=%d/%d clamped=%d/%d twisted=%d/%d reach%%(last/max right)=%d/%d (left)=%d/%d "
           "kept=%d lost=%d fail(noModel/layout/bones/space/ik/nonFinite)=%d/%d/%d/%d/%d/%d revalidations=%d armLen(upper/fore ft right)=%.2f/%.2f (left)=%.2f/%.2f "
           "wristCm=%d elbowDown=%d%% badSpace=%d/%d badLen=%d/%d",
           (int)frame, (int)g_ctl.armIk, g_ready, g_st.calls, g_st.moved[0], g_st.moved[1], g_st.noTarget[0], g_st.noTarget[1],
           g_st.clamped[0], g_st.clamped[1], g_st.twisted[0], g_st.twisted[1], g_st.lastReachX100[0], g_st.maxReachX100[0],
           g_st.lastReachX100[1], g_st.maxReachX100[1], g_st.verifyKept, g_st.verifyLost, g_st.noModel, g_st.badLayout,
           g_st.badBones, g_st.spaceFail, g_st.ikFail, g_st.nonFinite, g_st.revalidations,
           (double)g_st.lastL1[0], (double)g_st.lastL2[0], (double)g_st.lastL1[1], (double)g_st.lastL2[1], (int)g_ctl.armWristCm, (int)g_ctl.armElbowDown,
           g_st.badSpace[0], g_st.badSpace[1], g_st.badLen[0], g_st.badLen[1]);
  if (g_ctl.leftHanded || g_st.dispSolved[0]) log_line("ARMSWAP left-handed=%d (1.7.174: the left arm is drawn holding the gun, the right arm at the free controller): drawn right arm %ld / left arm %ld passes, failed %ld / %ld, free hand without a target %ld / %ld, reach now %d%% / %d%%", (int)g_ctl.leftHanded, g_st.dispSolved[0], g_st.dispSolved[1], g_st.dispFail[0], g_st.dispFail[1], g_st.dispNoTarget[0], g_st.dispNoTarget[1], g_st.dispReachX100[0], g_st.dispReachX100[1]);
  log_line("ARMROLL forearm takes %d%% of the hand's turn about it: shared right/left=%d/%d, last %d.%d/%d.%d deg, biggest %d.%d/%d.%d deg (of %d calls); 1.7.150 share faded near a half turn (no flip) right/left %ld/%ld, capped at 100 deg %ld/%ld", (int)g_ctl.forearmTwistPct, g_st.rollShared[0], g_st.rollShared[1],
           g_st.rollLastX10[0] / 10, g_st.rollLastX10[0] % 10, g_st.rollLastX10[1] / 10, g_st.rollLastX10[1] % 10, g_st.rollMaxX10[0] / 10, g_st.rollMaxX10[0] % 10, g_st.rollMaxX10[1] / 10, g_st.rollMaxX10[1] % 10, g_st.calls,
           g_st.roll[0].faded, g_st.roll[1].faded, g_st.roll[0].capped, g_st.roll[1].capped);
  log_line("RIGPOLISH raised elbow R/L=%d/%d | planted-leg extensions L/R=%d/%d max scale=%d/%d%% ankle miss max=%.1f/%.1f cm (the wrist stays at its controller; small leg extension keeps feet on the floor)",
           g_st.raisedElbow[0], g_st.raisedElbow[1], g_st.legExtended[0], g_st.legExtended[1],
           g_st.legExtendMaxX100[0], g_st.legExtendMaxX100[1],
           g_st.legMissMaxX100[0] * 0.3048, g_st.legMissMaxX100[1] * 0.3048);
  log_line("BODYPOSE frame=%d fullBody=%d torso=%d skippedSamePose=%d fail=%d noTorso=%d noLegs=%d legMoved(L/R)=%d/%d legFail=%d/%d legClamped=%d/%d lean(last/max deg)=%.1f/%.1f head(last/max deg)=%.1f/%.1f crouchDrop(last/max cm)=%d/%d "
           "armStretched(R/L)=%d/%d stretch%%(last/max R)=%d/%d (L)=%d/%d",
           (int)frame, (int)g_ctl.fullBody, g_st.torso, g_st.torsoSkipped, g_st.torsoFail, g_st.noTorso, g_st.noLegs, g_st.legMoved[0], g_st.legMoved[1], g_st.legFail[0], g_st.legFail[1], g_st.legClamped[0], g_st.legClamped[1],
           g_st.lastLeanX10 / 10.0, g_st.leanMaxX10 / 10.0, g_st.lastHeadX10 / 10.0, g_st.headMaxX10 / 10.0, (int)(g_st.lastDropX100 * 30.48 / 100.0), (int)(g_st.dropMaxX100 * 30.48 / 100.0),
           g_st.stretched[0], g_st.stretched[1], g_st.lastStretchX100[0], g_st.stretchMaxX100[0], g_st.lastStretchX100[1], g_st.stretchMaxX100[1]);
  {
    LARGE_INTEGER fq; QueryPerformanceFrequency(&fq);
    const double us = 1e6 / (double)fq.QuadPart;
    const double nt = g_st.timed ? (double)g_st.timed : 1.0;
    log_line("ARMTIMING calls=%d avgUs: total=%.0f engineEnsureWorld=%.0f torsoLegs=%.0f arms=%.0f | ensure calls=%I64d avg %.1f us | memory checks=%I64d | arm passes skipped (same pose, second eye)=%d/%d torso skipped=%d",
             g_st.timed, (double)g_st.tTotal * us / nt, (double)g_st.tEnsure * us / nt, (double)g_st.tTorso * us / nt, (double)g_st.tArms * us / nt,
             (long long)g_nEnsure, g_nEnsure ? (double)g_tEnsure * us / (double)g_nEnsure : 0.0, (long long)g_nReadable, g_st.armSkipped[0], g_st.armSkipped[1], g_st.torsoSkipped);
    g_tEnsure = g_nEnsure = g_nReadable = 0;
    g_st.tEnsure = g_st.tTorso = g_st.tArms = g_st.tTotal = 0; g_st.timed = 0;
    // 0.66 gun in hand: how far the controller is from the avatar's shoulder (in arm lengths) and how far the wrist fell short
    log_line("REACH controller distance from the shoulder in arm lengths (calls): right <80%%=%d <100%%=%d <130%%=%d <170%%=%d <220%%=%d <300%%=%d <400%%=%d more=%d | left <80%%=%d <100%%=%d <130%%=%d <170%%=%d <220%%=%d <300%%=%d <400%%=%d more=%d",
             g_st.demand[0][0], g_st.demand[0][1], g_st.demand[0][2], g_st.demand[0][3], g_st.demand[0][4], g_st.demand[0][5], g_st.demand[0][6], g_st.demand[0][7],
             g_st.demand[1][0], g_st.demand[1][1], g_st.demand[1][2], g_st.demand[1][3], g_st.demand[1][4], g_st.demand[1][5], g_st.demand[1][6], g_st.demand[1][7]);
    log_line("GUNHAND wrist fell short of the controller: right last=%.2f ft max=%.2f ft calls over 0.1 ft=%d | left last=%.2f max=%.2f over=%d | stretch limit %d%%",
             (double)g_st.lastMissX100[0] / 100.0, (double)g_st.missMaxX100[0] / 100.0, g_st.missOver[0], (double)g_st.lastMissX100[1] / 100.0,
             (double)g_st.missMaxX100[1] / 100.0, g_st.missOver[1], (int)g_ctl.armStretchPct);
  }
  // 0.69 eyes against the camera (exact match), shoulder reach
  log_line("EYEALIGN frame=%d on=%d samples=%d error(last x,y,z ft)=%.2f,%.2f,%.2f |error|(mean/max ft)=%.2f/%.2f beyondLean(right,up,fwd)=%.2f,%.2f,%.2f "
           "bodyShifted=%d (hit the %.1f ft cap %d, max %.2f ft, last %.2f,%.2f,%.2f) headSlid=%d (max %.2f ft) left(x,y,z)=%.3f,%.3f,%.3f max=%.2f fade=%d%% forcedPasses=%d "
           "modelEyeHeight=%.2f ft (peak share %.0f%%, n=%d) eyeBonesMissing=%d | shoulderReach(R/L): swings=%d/%d last=%.1f/%.1f max=%.1f/%.1f deg (limit %d)",
           (int)frame, (int)g_ctl.bodyEyeAlign, g_st.eyeN, (double)g_st.eyeErr[0], (double)g_st.eyeErr[1], (double)g_st.eyeErr[2],
           g_st.eyeN ? (double)g_st.eyeErrSumX100 / 100.0 / (double)g_st.eyeN : 0.0, (double)g_st.eyeErrMaxX100 / 100.0,
           (double)g_st.eyeErrBody[0], (double)g_st.eyeErrBody[1], (double)g_st.eyeErrBody[2], g_st.shifted, 1.0, g_st.shiftCapped, (double)g_st.shiftMaxX100 / 100.0,
           (double)g_st.shiftLast[0], (double)g_st.shiftLast[1], (double)g_st.shiftLast[2], g_st.headShifted, (double)g_st.headShiftMaxX100 / 100.0,
           (double)g_st.eyeResid[0], (double)g_st.eyeResid[1], (double)g_st.eyeResid[2], (double)g_st.eyeResidMaxX100 / 100.0, g_st.fadeX100, g_st.forcedCalls,
           (double)g_st.modelEyeFt, (double)g_st.modelEyeShare * 100.0, g_st.modelEyeN, g_st.eyeBoneMissing, g_st.pulled[0], g_st.pulled[1],
           g_st.lastPullX10[0] / 10.0, g_st.lastPullX10[1] / 10.0, g_st.pullMaxX10[0] / 10.0, g_st.pullMaxX10[1] / 10.0, (int)g_ctl.shoulderPullDeg);
  log_line("ANIMPUSH frame=%d how much the game's animation moved the avatar's head between two passes while the headset view stayed its own: passes=%d mean %.3f ft, over 0.25 ft: %d times (%.1f%%), largest %.2f ft (0.97 had no such number; big or frequent = the animation is pushing the player about)",
           (int)frame, g_st.eyeN, g_st.eyeN > 1 ? (double)g_st.eyeJumpSumX100 / 100.0 / (double)(g_st.eyeN - 1) : 0.0, g_st.eyeJumps,
           g_st.eyeN > 1 ? 100.0 * (double)g_st.eyeJumps / (double)(g_st.eyeN - 1) : 0.0, (double)g_st.eyeJumpMaxX100 / 100.0);
  log_line("BODY70 sideways whole-body shift: passes=%d mean %.2f max %.2f ft | up-down shift (legs planted): mean %.2f max %.2f ft | heights above the animation's feet: camera eye %.2f ft (mean %.2f), avatar eye %.2f ft (mean %.2f) over %d | legs clamped %d/%d moved %d/%d failed %d/%d",
           g_st.walkN, g_st.walkN ? (double)g_st.walkSumX100 / 100.0 / (double)g_st.walkN : 0.0, (double)g_st.walkMaxX100 / 100.0,
           g_st.walkN ? (double)g_st.vertSumX100 / 100.0 / (double)g_st.walkN : 0.0, (double)g_st.vertMaxX100 / 100.0,
           (double)g_st.camAboveFeet, g_st.feetN ? g_st.camAboveFeetSum / (double)g_st.feetN : 0.0, (double)g_st.eyeAboveFeet, g_st.feetN ? g_st.eyeAboveFeetSum / (double)g_st.feetN : 0.0, g_st.feetN,
           g_st.legClamped[0], g_st.legClamped[1], g_st.legMoved[0], g_st.legMoved[1], g_st.legFail[0], g_st.legFail[1]);
  {   // 1.7.29 calm walking and the shake meter (feet -> millimetres). raw = what 1.7.28 did (the body takes every bob of the walk animation), applied = what the body does now
    const double mm = 304.8;
    log_line("RIGSHAKE frame=%d calm=%dms frames=%ld smoothed=%ld restarted=%ld off=%ld | body lag behind the animation: mean %.1f max %.1f mm (the hidden head slides it back) | frame gaps: mean %.1f ms, max %.0f ms, over 20 ms %ld, over 33 ms %ld of %ld | "
             "shake of the body in your head's frame (2nd difference per frame, mean/max mm): STANDING raw %.1f/%.0f applied %.1f/%.0f (%ld frames) | MOVING raw %.1f/%.0f applied %.1f/%.0f (%ld frames) (applied well under raw = the calm filter works; both high = the shake is elsewhere)",
             (int)frame, (int)g_ctl.bodyCalmMs, g_st.calmFrames, g_st.calmSmoothed, g_st.calmSnapped, g_st.calmOff,
             g_st.calmSmoothed ? g_st.calmLagSumFt * mm / (double)g_st.calmSmoothed : 0.0, g_st.calmLagMaxFt * mm,
             g_st.dtN ? g_st.dtSum * 1000.0 / (double)g_st.dtN : 0.0, g_st.dtMax * 1000.0, g_st.dtOver20, g_st.dtOver33, g_st.dtN,
             g_st.shakeN[0] ? g_st.shakeRawSum[0] * mm / (double)g_st.shakeN[0] : 0.0, g_st.shakeRawMax[0] * mm, g_st.shakeN[0] ? g_st.shakeAppSum[0] * mm / (double)g_st.shakeN[0] : 0.0, g_st.shakeAppMax[0] * mm, g_st.shakeN[0],
             g_st.shakeN[1] ? g_st.shakeRawSum[1] * mm / (double)g_st.shakeN[1] : 0.0, g_st.shakeRawMax[1] * mm, g_st.shakeN[1] ? g_st.shakeAppSum[1] * mm / (double)g_st.shakeN[1] : 0.0, g_st.shakeAppMax[1] * mm, g_st.shakeN[1]);
  }
  for (int h = 0; h < 2; ++h)
    if (g_st.wristRelN[h])
      log_line("ARMVIEW %s wrist relative to the camera eye (feet; right, up, forward): last %.2f,%.2f,%.2f mean %.2f,%.2f,%.2f over %d", h ? "left" : "right", (double)g_st.wristRel[h][0], (double)g_st.wristRel[h][1], (double)g_st.wristRel[h][2],
               g_st.wristRelSum[h][0] / g_st.wristRelN[h], g_st.wristRelSum[h][1] / g_st.wristRelN[h], g_st.wristRelSum[h][2] / g_st.wristRelN[h], g_st.wristRelN[h]);
  log_line("SLIDE shoulder slide toward the hand: slid R/L=%d/%d last=%.2f/%.2f max=%.2f/%.2f ft (limit %d cm) | arm stretch applied R: none=%d <=115%%=%d <=130%%=%d <=150%%=%d <=200%%=%d more=%d | L: none=%d <=115%%=%d <=130%%=%d <=150%%=%d <=200%%=%d more=%d | rig snapshots=%d noBasis=%d",
           g_st.slid[0], g_st.slid[1], g_st.lastSlideX100[0] / 100.0, g_st.lastSlideX100[1] / 100.0, g_st.slideMaxX100[0] / 100.0, g_st.slideMaxX100[1] / 100.0, (int)g_ctl.shoulderSlideCm,
           g_st.stretchHist[0][0], g_st.stretchHist[0][1], g_st.stretchHist[0][2], g_st.stretchHist[0][3], g_st.stretchHist[0][4], g_st.stretchHist[0][5],
           g_st.stretchHist[1][0], g_st.stretchHist[1][1], g_st.stretchHist[1][2], g_st.stretchHist[1][3], g_st.stretchHist[1][4], g_st.stretchHist[1][5], g_st.rigPasses, g_st.rigNoBasis);
  // 0.75 gun in hand: the hand taken from the game's own pose (through the unmoved body matrix), rigid with the wand
  {   // 1.7.7 the wrist set-back and where the fist really is relative to the weapon (cm; aim = along the weapon's pointing direction, up = the controller's up, right = the controller's right)
    for (int k = 0; k < 2; ++k) {
      const long n = g_st.wfN[k], nf = g_st.ffN[k];
      if (!n && !nf) continue;
      log_line("WRISTFIT %s: wrist set back %d cm (gun_wrist_cm; the real value used %.1f cm incl. 2 cm down) | the game's hand-minus-weapon offset (aim/up/right, cm): mean %.1f/%.1f/%.1f last %.1f/%.1f/%.1f over %ld | fist centre (middle of the 4 fingers' joints) minus weapon origin (aim/up/right, cm): mean %.1f/%.1f/%.1f last %.1f/%.1f/%.1f over %ld | hand 'across' axis dot aim: mean %.2f last %.2f | "
               "reading: a weapon held in the fist has up and right near 0; 'aim' says how far along the weapon the fist sits (negative = the fist is behind the weapon origin)",
               k ? "PKE" : "gun", (int)g_ctl.gunWristCm, n ? g_st.wfBackSum[k] / (double)n : 0.0,
               n ? g_st.wfOffSum[k][0] / (double)n : 0.0, n ? g_st.wfOffSum[k][1] / (double)n : 0.0, n ? g_st.wfOffSum[k][2] / (double)n : 0.0, g_st.wfOff[k][0], g_st.wfOff[k][1], g_st.wfOff[k][2], n,
               nf ? g_st.ffSum[k][0] / (double)nf : 0.0, nf ? g_st.ffSum[k][1] / (double)nf : 0.0, nf ? g_st.ffSum[k][2] / (double)nf : 0.0, g_st.ffLast[k][0], g_st.ffLast[k][1], g_st.ffLast[k][2], nf,
               g_st.ffAcrossN[k] ? g_st.ffAcrossSum[k] / (double)g_st.ffAcrossN[k] : 0.0, g_st.ffAcrossLast[k]);
    }
  }
  log_line("GRIPFIT 0.93 hand on the controller: setting=%d passes=%d gun slide mean %.1f max %.1f cm | game PKE bones squashed in %d arm passes (the probe's own PKE is drawn instead)",
           (int)g_ctl.gripAtHand, g_st.gripHandN, g_st.gripHandN ? g_st.gripShiftSumX100 / (double)g_st.gripHandN * 0.3048 : 0.0, g_st.gripShiftMaxX100 * 0.3048, g_st.pkeHidePasses);
  log_line("GRIP far(hand to the controller, no weapon in hand)=%d fixed=%d noPose=%d (the hand's place from the game's pose: calls used / not available) | offset hand-from-wand origin (cm): last %.1f,%.1f,%.1f ft=%.2f,%.2f,%.2f min=%.1f mean=%.1f max=%.1f jumpMax=%.1f over %d | "
           "the 0.74 way would have missed by: mean %.1f max %.1f cm, over 10 cm in %d calls | rebuilt pose vs the engine's own hand: max %.1f cm over %d checks",
           g_st.gripFar, g_st.gripFixed, g_st.gripNoPose, (double)g_st.gripOff[0] * 30.48, (double)g_st.gripOff[1] * 30.48, (double)g_st.gripOff[2] * 30.48,
           (double)g_st.gripOff[0], (double)g_st.gripOff[1], (double)g_st.gripOff[2],
           g_st.gripOffMinX100 * 0.3048, g_st.gripOffN ? (double)g_st.gripOffSumX100 / (double)g_st.gripOffN * 0.3048 : 0.0, g_st.gripOffMaxX100 * 0.3048, g_st.gripJumpMaxX100 * 0.3048, g_st.gripOffN,
           g_st.gripOffN ? (double)g_st.gripOldErrSumX100 / (double)g_st.gripOffN * 0.3048 : 0.0, g_st.gripOldErrMaxX100 * 0.3048, g_st.gripOldErrOver10, g_st.gripCheckMaxX100 * 0.3048, g_st.gripCheckN);
  log_line("EYEGOAL on=%d viewHigher=%d cm bodyOut=%d cm | goal relative to the camera eye (ft x,y,z; the avatar's eyes are put there): %.3f,%.3f,%.3f",
           g_st.eyeGoalOn, (int)g_ctl.bodyHeightCm, (int)g_ctl.bodyOutCm, (double)g_st.eyeGoalOff[0], (double)g_st.eyeGoalOff[1], (double)g_st.eyeGoalOff[2]);
  log_line("LEFTGRIP strength=%d%% passes drawn to the foregrip=%d meanDistanceCm=%d maxCm=%d meanWeight=%d%% | 1.7.1 left fingers wrapped on the foregrip in %d passes", (int)g_ctl.leftGripPct, g_st.lMagN, g_st.lMagN ? (int)(g_st.lMagSumX100 * 30.48 / 100.0 / g_st.lMagN) : 0, (int)(g_st.lMagMaxX100 * 30.48 / 100.0), g_st.lMagN ? (int)(g_st.lMagWSumX100 / g_st.lMagN) : 0, g_st.lWrapPasses);
  log_line("BODYBEND pct=%d max=%d deg | body passes %d, bending in %d of them, bend now %.1f deg, most %.1f deg (1.7.23: the torso is measured on the bones and swung toward the way you face; 1.7.21 tipped it backward)", (int)g_ctl.bodyBendPct, (int)g_ctl.bodyBendMaxDeg, g_st.bendPasses, g_st.bendActive, (double)g_st.lastBendX10 / 10.0, (double)g_st.bendMaxX10 / 10.0);
  log_line("BODYTILT forward tilt of the torso (spine1 -> neck, degrees from upright, + = toward where you face): passes %d, bend wanted in %d, applied in %d | before the bend: now %.1f, lowest %.1f, highest %.1f, mean while a bend was wanted %.1f | wanted now %.1f",
           g_st.tiltPasses, g_st.tiltBendWanted, g_st.tiltBendApplied, (double)g_st.tiltBeforeX10 / 10.0, (double)g_st.tiltBeforeMinX10 / 10.0, (double)g_st.tiltBeforeMaxX10 / 10.0,
           g_st.tiltBendWanted ? (double)g_st.tiltBeforeSumX10 / 10.0 / (double)g_st.tiltBendWanted : 0.0, (double)g_st.tiltWantX10 / 10.0);
  log_line("LEFTUNDER on=%d under=%d cm | passes with the left hand under the barrel=%ld, mean spot along the barrel %d%% (25..95 allowed), pushed to the spot %d cm on average (largest %d cm), held at an end of the barrel %ld times, hand too far from the gun to move %ld times",
           (int)g_ctl.leftUnder, (int)g_ctl.leftUnderCm, g_st.lUnderN, g_st.lUnderN ? (int)(g_st.lUnderAlongX100 / g_st.lUnderN) : 0, g_st.lUnderN ? (int)(g_st.lUnderMoveX100 * 30.48 / 100.0 / g_st.lUnderN) : 0, (int)(g_st.lUnderMaxX100 * 30.48 / 100.0), g_st.lUnderClamped, g_st.lUnderFar);
  log_line("FINGERS on=%d passes R/L=%d/%d axis(measured/geometry/none) R=%d/%d/%d L=%d/%d/%d flipsVsGeometry=%d/%d bad=%d/%d biggestJointTurn=%d.%d/%d.%d deg | total bend now->wanted (deg) R: thumb %d.%d->%d.%d index %d.%d->%d.%d middle %d.%d->%d.%d ring %d.%d->%d.%d pinkie %d.%d->%d.%d | L: thumb %d.%d->%d.%d index %d.%d->%d.%d middle %d.%d->%d.%d ring %d.%d->%d.%d pinkie %d.%d->%d.%d | axis agreement x100 R %d %d %d %d L %d %d %d %d",
           (int)g_ctl.fingers, g_st.fingerPasses[0], g_st.fingerPasses[1], g_st.fingerMeasured[0], g_st.fingerGeometry[0], g_st.fingerNoAxis[0], g_st.fingerMeasured[1], g_st.fingerGeometry[1], g_st.fingerNoAxis[1],
           g_st.fingerFlips[0], g_st.fingerFlips[1], g_st.fingerBad[0], g_st.fingerBad[1], g_st.fingerMaxDeltaX10[0] / 10, g_st.fingerMaxDeltaX10[0] % 10, g_st.fingerMaxDeltaX10[1] / 10, g_st.fingerMaxDeltaX10[1] % 10,
           g_st.fingerBaseX10[0][0] / 10, abs(g_st.fingerBaseX10[0][0] % 10), g_st.fingerWantX10[0][0] / 10, abs(g_st.fingerWantX10[0][0] % 10), g_st.fingerBaseX10[0][1] / 10, abs(g_st.fingerBaseX10[0][1] % 10), g_st.fingerWantX10[0][1] / 10, abs(g_st.fingerWantX10[0][1] % 10),
           g_st.fingerBaseX10[0][2] / 10, abs(g_st.fingerBaseX10[0][2] % 10), g_st.fingerWantX10[0][2] / 10, abs(g_st.fingerWantX10[0][2] % 10), g_st.fingerBaseX10[0][3] / 10, abs(g_st.fingerBaseX10[0][3] % 10), g_st.fingerWantX10[0][3] / 10, abs(g_st.fingerWantX10[0][3] % 10),
           g_st.fingerBaseX10[0][4] / 10, abs(g_st.fingerBaseX10[0][4] % 10), g_st.fingerWantX10[0][4] / 10, abs(g_st.fingerWantX10[0][4] % 10),
           g_st.fingerBaseX10[1][0] / 10, abs(g_st.fingerBaseX10[1][0] % 10), g_st.fingerWantX10[1][0] / 10, abs(g_st.fingerWantX10[1][0] % 10), g_st.fingerBaseX10[1][1] / 10, abs(g_st.fingerBaseX10[1][1] % 10), g_st.fingerWantX10[1][1] / 10, abs(g_st.fingerWantX10[1][1] % 10),
           g_st.fingerBaseX10[1][2] / 10, abs(g_st.fingerBaseX10[1][2] % 10), g_st.fingerWantX10[1][2] / 10, abs(g_st.fingerWantX10[1][2] % 10), g_st.fingerBaseX10[1][3] / 10, abs(g_st.fingerBaseX10[1][3] % 10), g_st.fingerWantX10[1][3] / 10, abs(g_st.fingerWantX10[1][3] % 10),
           g_st.fingerBaseX10[1][4] / 10, abs(g_st.fingerBaseX10[1][4] % 10), g_st.fingerWantX10[1][4] / 10, abs(g_st.fingerWantX10[1][4] % 10),
           g_st.fingerAxisDotX100[0][1], g_st.fingerAxisDotX100[0][2], g_st.fingerAxisDotX100[0][3], g_st.fingerAxisDotX100[0][4],
           g_st.fingerAxisDotX100[1][1], g_st.fingerAxisDotX100[1][2], g_st.fingerAxisDotX100[1][3], g_st.fingerAxisDotX100[1][4]);
  log_line("LEFTTHUMB the left thumb fully kept the game's own pose in %d passes (left_thumb_anim=%d; 1.7.24: kept on the gun, relaxes with the fingers off it; 1.7.22 straightened it across the palm: a spiky thumb in the pictures)", g_st.leftThumbKept, (int)g_ctl.leftThumbAnim);
  log_line("PKEWAND tries=%d noPose=%d placed(right/left)=%d/%d | wand distance from the hands in the game's pose (ft) right %.2f left %.2f | wand from the chosen hand in the hand's axes (ft) %.2f,%.2f,%.2f",
           g_st.pwCalls, g_st.pwNoPose, g_st.pwOut[0], g_st.pwOut[1], (double)g_st.pwDistFt[0], (double)g_st.pwDistFt[1], (double)g_st.pwOff[0], (double)g_st.pwOff[1], (double)g_st.pwOff[2]);
  log_line("PKEHAND setting=%d tries=%d noBones=%d noHand=%d glued(right/left)=%d/%d bonesKept=%d lastHand=%d | game pose distance cloth_pke to the hands (ft) right %.2f left %.2f, cloth_pke1 right %.2f left %.2f | cloth_pke from the chosen hand in the hand's axes (ft) %.2f,%.2f,%.2f",
           (int)g_ctl.pkeAttach, g_st.pkeCalls, g_st.pkeNoBones, g_st.pkeNoHand, g_st.pkeApplied[0], g_st.pkeApplied[1], g_st.pkeKept, g_st.pkeHand,
           (double)g_st.pkeDistFt[0][0], (double)g_st.pkeDistFt[0][1], (double)g_st.pkeDistFt[1][0], (double)g_st.pkeDistFt[1][1], (double)g_st.pkeOffLocal[0], (double)g_st.pkeOffLocal[1], (double)g_st.pkeOffLocal[2]);
  log_line("ARMSONLY on=%d passes=%d bonesSquashed=%d undone=%d noArms=%d badPoint=%d", (int)g_ctl.armsOnly, g_st.colPasses, g_st.colBones, g_st.colUndone, g_st.colNoArms, g_st.colBadPoint);
  if (g_st.colShoulders)
    log_line("SHOULDERS kept=%d (upper chest bone relative to the camera eye, feet right,up,forward: last %.2f,%.2f,%.2f mean %.2f,%.2f,%.2f over %d)", (int)g_ctl.armsShoulders, (double)g_st.spine3Rel[0], (double)g_st.spine3Rel[1], (double)g_st.spine3Rel[2],
             g_st.spine3RelN ? g_st.spine3RelSum[0] / g_st.spine3RelN : 0.0, g_st.spine3RelN ? g_st.spine3RelSum[1] / g_st.spine3RelN : 0.0, g_st.spine3RelN ? g_st.spine3RelSum[2] / g_st.spine3RelN : 0.0, g_st.spine3RelN);
  if (g_st.moved[0] && (frame % 8) == 0)
    log_line("ARMPOSE right: shoulder %.2f,%.2f,%.2f elbow %.2f,%.2f,%.2f wrist %.2f,%.2f,%.2f | left: shoulder %.2f,%.2f,%.2f elbow %.2f,%.2f,%.2f wrist %.2f,%.2f,%.2f",
             (double)g_st.lastS[0][0], (double)g_st.lastS[0][1], (double)g_st.lastS[0][2], (double)g_st.lastE[0][0], (double)g_st.lastE[0][1], (double)g_st.lastE[0][2],
             (double)g_st.lastT[0][0], (double)g_st.lastT[0][1], (double)g_st.lastT[0][2], (double)g_st.lastS[1][0], (double)g_st.lastS[1][1], (double)g_st.lastS[1][2],
             (double)g_st.lastE[1][0], (double)g_st.lastE[1][1], (double)g_st.lastE[1][2], (double)g_st.lastT[1][0], (double)g_st.lastT[1][1], (double)g_st.lastT[1][2]);
  // too many results lost: the engine recomputes after our write - say so once
  static int warned;
  if (!warned && g_st.verifyLost > 20 && g_st.verifyLost > 4 * g_st.verifyKept) {
    warned = 1;
    log_line("ARMS NOTE: the model's bone matrices were replaced again after the arms were moved (lost=%d kept=%d): the arms may look unmoved; this tells the next version where to hook.",
             g_st.verifyLost, g_st.verifyKept);
  }
}

#endif  // GBVR_HEADTRACK
