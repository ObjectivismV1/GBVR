// 0.68 aim assist: ghosts are fast and the beam is a thin line held by a hand, so a ghost the beam nearly hits gets a gentle pull.
// Pure math, no Windows dependency; unit-tested in tests/test_assist.cpp.
//
// The game marks the ghost it considers targeted with a ring (the health ring, drawn at the ghost's 3D position, see hud.cpp).
// That position is the candidate. Inside a narrow cone around the beam the beam direction is turned a fraction of the way
// toward it: strong near the middle of the cone, nothing at its edge, so a deliberate move away from the ghost is never fought.
// The fraction is smoothed over time (fast on, slower off) so the beam glides, never snaps. All vectors are in game world axes.
#pragma once
#include "vmath.h"

namespace assist {

inline double dot3(const double* a, const double* b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

// The angle (degrees) between unit direction `dir` and the line from `origin` to `target`; dist = that line's length.
// Returns 0 when the target is unusable (too near, too far, not finite).
inline int angle_to(const double* origin, const double* dir, const double* target, double minDist, double maxDist, double* angDeg, double* dist, double* u) {
  double v[3] = {target[0] - origin[0], target[1] - origin[1], target[2] - origin[2]};
  for (int i = 0; i < 3; ++i) if (!vm::is_finite_f((float)v[i])) return 0;
  const double d = vm::dsqrt(dot3(v, v));
  if (!(d >= minDist) || !(d <= maxDist)) return 0;
  for (int i = 0; i < 3; ++i) u[i] = v[i] / d;
  double c = dot3(dir, u);
  if (c > 1.0) c = 1.0;
  if (c < -1.0) c = -1.0;
  const double s = vm::dsqrt(1.0 - c * c);
  *angDeg = vm::datan2(s, c) * 180.0 / vm::kPi;
  *dist = d;
  return 1;
}

// The cone grows a little for a ghost that is close (it is big then): coneDeg plus the angle a body of radius `sizeFt` covers.
inline double cone_for(double coneDeg, double dist, double sizeFt) {
  return coneDeg + vm::datan2(sizeFt, dist) * 180.0 / vm::kPi;
}

// How much of the way to the target the beam is turned (0..1) for a target `ang` degrees off inside a cone of `cone` degrees.
inline double pull_fraction(double ang, double cone, double strength) {
  if (!(cone > 0.01) || !(ang < cone) || !(strength > 0.0)) return 0.0;
  const double x = ang / cone;
  double f = strength * 0.65 * (1.0 - x * x);   // 0.65 at the very middle: a nudge, not a magnet
  if (f > 0.95) f = 0.95;
  if (f < 0.0) f = 0.0;
  return f;
}

// out = dir turned fraction f of the way toward u (both unit vectors), unit length.
inline void turn_toward(const double* dir, const double* u, double f, double* out) {
  double m[3] = {dir[0] * (1.0 - f) + u[0] * f, dir[1] * (1.0 - f) + u[1] * f, dir[2] * (1.0 - f) + u[2] * f};
  const double l = vm::dsqrt(dot3(m, m));
  if (!(l > 1e-6)) { out[0] = dir[0]; out[1] = dir[1]; out[2] = dir[2]; return; }
  for (int i = 0; i < 3; ++i) out[i] = m[i] / l;
}

// Smoothed pull over time. One step per aim update.
struct State {
  double fs;          // smoothed fraction
  double u[3];        // direction to the target that fraction belongs to (kept while the pull fades out)
  int haveU;
  int locked;         // the target is inside the (wider) hold cone
  void reset() { fs = 0; haveU = 0; locked = 0; u[0] = u[1] = u[2] = 0; }
};

inline double ease(double dt, double tau) {   // 1 - exp(-dt/tau), cheap and monotone
  if (!(dt > 0) || !(tau > 0)) return 0;
  const double x = dt / tau;
  if (x >= 4.0) return 1.0;
  const double y = x / 4.0;
  double e = 1.0 - y + y * y / 2.0 - y * y * y / 6.0;
  e = e * e; e = e * e;
  return 1.0 - e;
}

struct Result { int active; double angDeg, distFt, coneDeg, fraction, turnedDeg; };

// origin, dir (unit) of the beam; target (or null = none this time); returns the assisted unit direction in out.
// strength: 1 = default. active=1 in the result when the pull is noticeable.
inline Result step(State* s, const double* origin, const double* dir, const double* target, double dt, double coneDeg, double strength, double sizeFt, double* out) {
  Result r; r.active = 0; r.angDeg = r.distFt = r.coneDeg = r.fraction = r.turnedDeg = 0;
  double goal = 0.0;
  if (target) {
    double ang = 0, dist = 0, u[3];
    if (angle_to(origin, dir, target, 3.0, 150.0, &ang, &dist, u)) {
      double cone = cone_for(coneDeg, dist, sizeFt);
      if (s->locked) cone *= 1.4;   // once the beam is on it, it takes a clearer move to leave
      r.angDeg = ang; r.distFt = dist; r.coneDeg = cone;
      goal = pull_fraction(ang, cone, strength);
      s->locked = goal > 0.0;
      if (goal > 0.0) { s->u[0] = u[0]; s->u[1] = u[1]; s->u[2] = u[2]; s->haveU = 1; }
    } else s->locked = 0;
  } else s->locked = 0;
  s->fs += (goal - s->fs) * ease(dt, goal > s->fs ? 0.06 : 0.12);
  if (s->fs < 0.003) { s->fs = 0; }
  if (s->fs > 0.0 && s->haveU) {
    turn_toward(dir, s->u, s->fs, out);
    r.fraction = s->fs;
    r.active = s->fs > 0.02;
    const double c = dot3(dir, out);
    r.turnedDeg = vm::datan2(vm::dsqrt(1.0 - (c > 1 ? 1 : c) * (c > 1 ? 1 : c)), c) * 180.0 / vm::kPi;
  } else { out[0] = dir[0]; out[1] = dir[1]; out[2] = dir[2]; }
  return r;
}

}  // namespace assist
