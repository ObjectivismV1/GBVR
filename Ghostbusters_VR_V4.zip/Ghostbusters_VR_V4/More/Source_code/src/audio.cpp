// 0.69 audio.cpp: the menu's song and the quiet game.
//
// While the in-VR menu is open:
//  - the song gbvr_menu_music.mp3 (game folder) plays at the volume set on the menu's Sound page (default 65 %),
//    through the Windows audio system (WASAPI, shared mode) in a session of its own, so it can be told apart from the game;
//  - the game's own sound is silenced: every audio session of THIS process (except the song's) is turned to 0 and given
//    back exactly as it was when the menu closes. (The game's sound keeps running silently - this is a mute, not a pause.)
// Everything runs on its own thread; the render thread only sets a flag (audio_menu). ole32 is loaded by name, so the DLL
// still imports nothing but KERNEL32 / USER32 / msvcrt.
//
// Crash safety: Windows remembers an application's volume. If the game dies while muted, the next start would be silent.
// So a small marker file (gbvr_audio_muted.flag) is written while muting; if it is found at the next start, the thread
// looks for this process's sessions for a while and gives back the volume of any that sit at zero.
#include "gbvr.h"
#include "audiomath.h"

#if GBVR_HEADTRACK

#define MINIMP3_IMPLEMENTATION
#define MINIMP3_NO_SIMD
#define MINIMP3_ONLY_MP3
#include "minimp3.h"

#include <mmdeviceapi.h>
#include <audioclient.h>
#include <audiopolicy.h>

namespace {

const GUID kClsidEnum   = {0xBCDE0395, 0xE52F, 0x467C, {0x8E, 0x3D, 0xC4, 0x57, 0x92, 0x91, 0x69, 0x2E}};
const GUID kIidEnum     = {0xA95664D2, 0x9614, 0x4F35, {0xA7, 0x46, 0xDE, 0x8D, 0xB6, 0x36, 0x17, 0xE6}};
const GUID kIidClient   = {0x1CB9AD4C, 0xDBFA, 0x4C32, {0xB1, 0x78, 0xC2, 0xF5, 0x68, 0xA7, 0x03, 0xB2}};
const GUID kIidRender   = {0xF294ACFC, 0x3146, 0x4483, {0xA7, 0xBF, 0xAD, 0xDC, 0xA7, 0xC2, 0x60, 0xE2}};
const GUID kIidMgr2     = {0x77AA99A0, 0x1BD6, 0x484F, {0x8B, 0xC7, 0x2C, 0x65, 0x4C, 0x9A, 0x9B, 0x6F}};
const GUID kIidSimpleVol= {0x87CE5498, 0x68D6, 0x44E5, {0x92, 0x15, 0x6D, 0xA4, 0x7E, 0xF8, 0x83, 0xD8}};
const GUID kIidCtl      = {0xF4B1A599, 0x7266, 0x4319, {0xA8, 0xCA, 0xE7, 0x0A, 0xCB, 0x11, 0xE8, 0xCD}};
const GUID kIidCtl2     = {0xBFB7FF88, 0x7239, 0x4FC9, {0x8F, 0xA2, 0x07, 0xC9, 0x50, 0xBE, 0x9C, 0x6D}};
const GUID kSubFloat    = {0x00000003, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71}};
const GUID kMySession   = {0x6A1D0B6E, 0x5B7C, 0x4C0E, {0x9D, 0x2A, 0x47, 0x42, 0x56, 0x52, 0x4D, 0x31}};

typedef HRESULT(WINAPI* PFN_CoInit)(LPVOID, DWORD);
typedef void(WINAPI* PFN_CoUninit)(void);
typedef HRESULT(WINAPI* PFN_CoCreate)(const GUID&, IUnknown*, DWORD, const GUID&, LPVOID*);
typedef void(WINAPI* PFN_CoFree)(LPVOID);

template <class T> void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

inline bool same_guid(const GUID& a, const GUID& b) {
  const unsigned char* x = (const unsigned char*)&a; const unsigned char* y = (const unsigned char*)&b;
  for (int i = 0; i < (int)sizeof(GUID); ++i) if (x[i] != y[i]) return false;
  return true;
}

uint64_t hash_w(const wchar_t* s) {
  uint64_t h = 1469598103934665603ULL;
  for (; *s; ++s) { h ^= (uint64_t)(unsigned short)*s; h *= 1099511628211ULL; }
  return h;
}

void proc_name(DWORD pid, char* out, int n) {
  out[0] = 0;
  if (!pid) { lstrcpynA(out, "-", n); return; }
  HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
  if (!h) { lstrcpynA(out, "?", n); return; }
  wchar_t w[MAX_PATH]; DWORD sz = MAX_PATH;
  if (QueryFullProcessImageNameW(h, 0, w, &sz)) {
    const wchar_t* b = w;
    for (const wchar_t* p = w; *p; ++p) if (*p == L'\\') b = p + 1;
    if (!WideCharToMultiByte(CP_ACP, 0, b, -1, out, n, nullptr, nullptr)) lstrcpynA(out, "?", n);
  } else lstrcpynA(out, "?", n);
  CloseHandle(h);
}

// ---------------------------------------------------------------------------
volatile LONG g_open;        // the menu is open (set by the render thread)
volatile LONG g_quit;
volatile LONG g_threadUp;
volatile LONG g_recover;     // a marker file was found at start
volatile LONG g_probe;       // 1.7.88: a request (render thread) for one log of the PC's sound setup
volatile LONG g_songState;   // 1.7.88: 0 not looked at yet, 1 the song file is there, -1 there is none
volatile LONG g_noSongLogged;
HANDLE g_thread;

// data for the report (written by the audio thread, read by the render thread; plain counters)
volatile LONG g_stFile, g_stHz, g_stCh, g_stOutHz, g_stOutCh, g_stOutFloat, g_stInit, g_stRunning, g_stGainPct;
volatile LONG g_stPlayed, g_stLoops, g_stUnder, g_stReinit, g_stErr;
volatile LONG g_stBytes, g_stFadeIn;
volatile LONG g_stMuteEvents, g_stScans, g_stSessions, g_stEndpoints, g_stOtherSessions, g_stGamePct, g_stRestored, g_stMuteActive, g_stRecovered;
volatile LONG g_stFirstSeen;

// 1.7.88: is there a song to play? (looked at once; the public download has none)
int song_exists() {
  if (g_songState) return g_songState > 0;
  wchar_t p[MAX_PATH + 40];
  lstrcpynW(p, g_selfDir, MAX_PATH);
  lstrcatW(p, L"gbvr_menu_music.mp3");
  const int yes = GetFileAttributesW(p) != INVALID_FILE_ATTRIBUTES;
  InterlockedExchange(&g_songState, yes ? 1 : -1);
  return yes;
}

const int kMaxSess = 24;
struct Sess { ISimpleAudioVolume* vol; uint64_t id; float orig; int seen; };

const int kRing = 16384;   // power of two

struct Worker {
  // COM
  HMODULE ole;
  PFN_CoInit coInit; PFN_CoUninit coUninit; PFN_CoCreate coCreate; PFN_CoFree coFree;
  int comOk;
  IMMDeviceEnumerator* enumr;

  // song
  BYTE* data; size_t size, skip, pos;
  mp3dec_t dec;
  mp3d_sample_t pcm[MINIMP3_MAX_SAMPLES_PER_FRAME];
  int srcHz, srcCh;
  float ring[kRing][2];
  uint64_t wr, rd;
  double frac;
  int fileTried, fileOk, musicDead, initFails;
  double nextInitMs;

  // WASAPI
  IAudioClient* client; IAudioRenderClient* render; ISimpleAudioVolume* myVol;
  UINT32 bufFrames;
  int outHz, outCh, outFloat;
  int running;
  uint64_t myId;
  double fade;           // 0..1
  double lastGain;
  int wroteAny;

  // game sessions
  Sess ss[kMaxSess]; int nss;
  int muteActive;
  double gameGain;
  double lastScanMs;
  int firstScanLogged;
  double recoverUntilMs, recoverNextMs, recoverDoneMs;
  float recoverVal;

  wchar_t flagPath[MAX_PATH + 40];
  wchar_t songPath[MAX_PATH + 40];

  void zero() {
    ole = nullptr; coInit = nullptr; coUninit = nullptr; coCreate = nullptr; coFree = nullptr; comOk = 0; enumr = nullptr;
    data = nullptr; size = skip = pos = 0; srcHz = 44100; srcCh = 2; wr = rd = 0; frac = 0;
    fileTried = fileOk = musicDead = initFails = 0; nextInitMs = 0;
    client = nullptr; render = nullptr; myVol = nullptr; bufFrames = 0; outHz = 44100; outCh = 2; outFloat = 0; running = 0; myId = 0;
    fade = 0; lastGain = 0; wroteAny = 0;
    nss = 0; muteActive = 0; gameGain = 1.0; lastScanMs = -100000; firstScanLogged = 0;
    recoverUntilMs = 0; recoverNextMs = 0; recoverDoneMs = 0; recoverVal = 1.0f;
    for (int i = 0; i < kMaxSess; ++i) ss[i].vol = nullptr;
  }

  // ---- song file ----
  int load_file() {
    fileTried = 1;
    lstrcpynW(songPath, g_selfDir, MAX_PATH);
    lstrcatW(songPath, L"gbvr_menu_music.mp3");
    HANDLE f = CreateFileW(songPath, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) { InterlockedExchange(&g_stErr, 1); log_line("AUDIO song file not found: %ls", songPath); return 0; }
    LARGE_INTEGER sz; sz.QuadPart = 0;
    GetFileSizeEx(f, &sz);
    if (sz.QuadPart < 2000 || sz.QuadPart > 96LL * 1024 * 1024) {
      CloseHandle(f); InterlockedExchange(&g_stErr, 2);
      log_line("AUDIO song file has a strange size (%I64d bytes), not used", (long long)sz.QuadPart);
      return 0;
    }
    data = (BYTE*)HeapAlloc(GetProcessHeap(), 0, (SIZE_T)sz.QuadPart);
    if (!data) { CloseHandle(f); InterlockedExchange(&g_stErr, 3); log_line("AUDIO out of memory for the song"); return 0; }
    size_t got = 0;
    while (got < (size_t)sz.QuadPart) {
      DWORD r = 0; DWORD want = (DWORD)((size_t)sz.QuadPart - got > (1u << 24) ? (1u << 24) : (size_t)sz.QuadPart - got);
      if (!ReadFile(f, data + got, want, &r, nullptr) || r == 0) break;
      got += r;
    }
    CloseHandle(f);
    size = got;
    skip = 0;
    if (size >= 10 && data[0] == 'I' && data[1] == 'D' && data[2] == '3') {
      const size_t tag = ((size_t)(data[6] & 0x7F) << 21) | ((size_t)(data[7] & 0x7F) << 14) | ((size_t)(data[8] & 0x7F) << 7) | (size_t)(data[9] & 0x7F);
      skip = 10 + tag + ((data[5] & 0x10) ? 10 : 0);
      if (skip >= size) skip = 0;
    }
    InterlockedExchange(&g_stBytes, (LONG)size);
    fileOk = 1;
    return 1;
  }

  void rewind_song() { mp3dec_init(&dec); pos = skip; wr = rd = 0; frac = 0; }

  int decode_one() {   // decodes one frame into the ring; 0 = end of data
    for (int guard = 0; guard < 200; ++guard) {
      if (pos >= size) return 0;
      mp3dec_frame_info_t info;
      size_t left = size - pos;
      int n = mp3dec_decode_frame(&dec, data + pos, left > 0x7FFFFFFF ? 0x7FFFFFFF : (int)left, pcm, &info);
      pos += (size_t)info.frame_bytes;
      if (n > 0) {
        if (info.hz > 0) { srcHz = info.hz; srcCh = info.channels; }
        for (int i = 0; i < n; ++i) {
          float l, r;
          if (info.channels >= 2) { l = pcm[i * info.channels] * (1.0f / 32768.0f); r = pcm[i * info.channels + 1] * (1.0f / 32768.0f); }
          else { l = r = pcm[i] * (1.0f / 32768.0f); }
          const int k = (int)((wr + (uint64_t)i) & (kRing - 1));
          ring[k][0] = l; ring[k][1] = r;
        }
        wr += (uint64_t)n;
        return 1;
      }
      if (info.frame_bytes == 0) return 0;
    }
    return 0;
  }

  int ensure_two() {   // at least two frames ahead of the read position
    int guard = 0;
    while (wr - rd < 2) {
      if (!decode_one()) {
        // end of the song: start again (frames still needed come from the beginning)
        if (++guard > 3) return 0;
        mp3dec_init(&dec); pos = skip; wr = rd = 0; frac = 0;
        InterlockedIncrement(&g_stLoops);
      }
    }
    return 1;
  }

  // ---- WASAPI ----
  int get_default_client(IAudioClient** out) {
    IMMDevice* dev = nullptr;
    HRESULT hr = enumr->GetDefaultAudioEndpoint(eRender, eConsole, &dev);
    if (FAILED(hr) || !dev) { InterlockedExchange(&g_stErr, (LONG)hr); log_line("AUDIO no default playback device (0x%08X)", (unsigned)hr); return 0; }
    hr = dev->Activate(kIidClient, CLSCTX_ALL, nullptr, (void**)out);
    dev->Release();
    if (FAILED(hr) || !*out) { InterlockedExchange(&g_stErr, (LONG)hr); log_line("AUDIO cannot open the playback device (0x%08X)", (unsigned)hr); return 0; }
    return 1;
  }

  void close_client() {
    if (client && running) { client->Stop(); }
    running = 0; wroteAny = 0;
    rel(myVol); rel(render); rel(client);
    myId = 0;
    InterlockedExchange(&g_stInit, 0); InterlockedExchange(&g_stRunning, 0);
  }

  int init_music() {
    if (!comOk || !enumr) return 0;
    if (!fileTried) { if (!load_file()) { musicDead = 1; return 0; } }
    if (!fileOk) { musicDead = 1; return 0; }
    // probe the song's sample rate
    rewind_song();
    if (!decode_one()) { log_line("AUDIO the song could not be decoded (not an MP3?)"); InterlockedExchange(&g_stErr, 4); musicDead = 1; return 0; }
    InterlockedExchange(&g_stHz, srcHz); InterlockedExchange(&g_stCh, srcCh);
    rewind_song();

    if (!get_default_client(&client)) { ++initFails; if (initFails >= 4) musicDead = 1; return 0; }
    WAVEFORMATEX wf; ZeroMemory(&wf, sizeof(wf));
    wf.wFormatTag = WAVE_FORMAT_PCM; wf.nChannels = 2; wf.nSamplesPerSec = (DWORD)srcHz; wf.wBitsPerSample = 16;
    wf.nBlockAlign = 4; wf.nAvgBytesPerSec = (DWORD)srcHz * 4;
    const DWORD flags = 0x80000000u /*AUTOCONVERTPCM*/ | 0x08000000u /*SRC_DEFAULT_QUALITY*/;
    HRESULT hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, flags, 2000000, 0, &wf, &kMySession);
    const char* how = "own 16-bit format (Windows converts)";
    if (SUCCEEDED(hr)) { outHz = srcHz; outCh = 2; outFloat = 0; }
    else {
      log_line("AUDIO 16-bit stream refused (0x%08X); trying the device's own format", (unsigned)hr);
      rel(client);
      if (!get_default_client(&client)) { ++initFails; if (initFails >= 4) musicDead = 1; return 0; }
      WAVEFORMATEX* mix = nullptr;
      hr = client->GetMixFormat(&mix);
      if (FAILED(hr) || !mix) { InterlockedExchange(&g_stErr, (LONG)hr); log_line("AUDIO GetMixFormat failed (0x%08X)", (unsigned)hr); rel(client); ++initFails; if (initFails >= 4) musicDead = 1; return 0; }
      int isFloat = mix->wFormatTag == WAVE_FORMAT_IEEE_FLOAT;
      if (mix->wFormatTag == WAVE_FORMAT_EXTENSIBLE && mix->cbSize >= 22) {
        const WAVEFORMATEXTENSIBLE* ex = (const WAVEFORMATEXTENSIBLE*)mix;
        isFloat = same_guid(ex->SubFormat, kSubFloat);
      }
      const int ok = (isFloat && mix->wBitsPerSample == 32) || (!isFloat && mix->wBitsPerSample == 16 && mix->wFormatTag != WAVE_FORMAT_IEEE_FLOAT);
      if (!ok) {
        log_line("AUDIO device format not supported here (tag=%d bits=%d ch=%d hz=%d)", (int)mix->wFormatTag, (int)mix->wBitsPerSample, (int)mix->nChannels, (int)mix->nSamplesPerSec);
        if (coFree) coFree(mix);
        rel(client); musicDead = 1; return 0;
      }
      outHz = (int)mix->nSamplesPerSec; outCh = mix->nChannels < 1 ? 1 : (int)mix->nChannels; outFloat = isFloat;
      hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, 0, 2000000, 0, mix, &kMySession);
      if (coFree) coFree(mix);
      how = "device format (we convert)";
      if (FAILED(hr)) { InterlockedExchange(&g_stErr, (LONG)hr); log_line("AUDIO stream init failed (0x%08X)", (unsigned)hr); rel(client); ++initFails; if (initFails >= 4) musicDead = 1; return 0; }
    }
    hr = client->GetBufferSize(&bufFrames);
    if (FAILED(hr) || bufFrames < 256) { log_line("AUDIO bad buffer size (0x%08X, %u)", (unsigned)hr, (unsigned)bufFrames); rel(client); ++initFails; if (initFails >= 4) musicDead = 1; return 0; }
    hr = client->GetService(kIidRender, (void**)&render);
    if (FAILED(hr) || !render) { log_line("AUDIO no render service (0x%08X)", (unsigned)hr); rel(client); ++initFails; if (initFails >= 4) musicDead = 1; return 0; }
    // tell our session apart from the game's
    IAudioSessionControl* ctl = nullptr;
    if (SUCCEEDED(client->GetService(kIidCtl, (void**)&ctl)) && ctl) {
      ctl->SetGroupingParam((GUID*)&kMySession, nullptr);
      ctl->SetDisplayName(L"Ghostbusters VR menu music", nullptr);
      IAudioSessionControl2* c2 = nullptr;
      if (SUCCEEDED(ctl->QueryInterface(kIidCtl2, (void**)&c2)) && c2) {
        LPWSTR id = nullptr;
        if (SUCCEEDED(c2->GetSessionInstanceIdentifier(&id)) && id) { myId = hash_w(id); if (coFree) coFree(id); }
        c2->Release();
      }
      ctl->Release();
    }
    client->GetService(kIidSimpleVol, (void**)&myVol);
    if (myVol) { myVol->SetMasterVolume(1.0f, nullptr); myVol->SetMute(FALSE, nullptr); }   // Windows may remember a volume for an app's session; ours is always full (the song's own gain is applied by us)
    InterlockedExchange(&g_stOutHz, outHz); InterlockedExchange(&g_stOutCh, outCh); InterlockedExchange(&g_stOutFloat, outFloat);
    InterlockedExchange(&g_stInit, 1);
    log_line("AUDIO song ready: %d Hz %d ch, %u bytes; output %d Hz %d ch %s, buffer %u frames, %s, sessionId=%08X",
             srcHz, srcCh, (unsigned)size, outHz, outCh, outFloat ? "float" : "16-bit", (unsigned)bufFrames, how, (unsigned)(myId & 0xFFFFFFFF));
    return 1;
  }

  void feed(double g0, double g1) {
    UINT32 pad = 0;
    HRESULT hr = client->GetCurrentPadding(&pad);
    if (FAILED(hr)) { fail_stream(hr, "padding"); return; }
    const UINT32 want = (UINT32)(outHz / 8);   // keep about 125 ms queued
    if (pad >= want) return;
    UINT32 n = want - pad;
    if (n > bufFrames - pad) n = bufFrames - pad;
    if (n == 0) return;
    if (wroteAny && pad == 0) InterlockedIncrement(&g_stUnder);
    BYTE* dst = nullptr;
    hr = render->GetBuffer(n, &dst);
    if (FAILED(hr) || !dst) { fail_stream(hr, "buffer"); return; }
    const double step = (double)srcHz / (double)outHz;
    int silent = 0;
    for (UINT32 i = 0; i < n; ++i) {
      float l = 0, r = 0;
      if (!silent) {
        if (!ensure_two()) silent = 1;
        else {
          const int a = (int)(rd & (kRing - 1)), b = (int)((rd + 1) & (kRing - 1));
          const float f = (float)frac;
          l = ring[a][0] + (ring[b][0] - ring[a][0]) * f;
          r = ring[a][1] + (ring[b][1] - ring[a][1]) * f;
          frac += step;
          while (frac >= 1.0) { frac -= 1.0; ++rd; }
        }
      }
      const float g = (float)(g0 + (g1 - g0) * ((double)(i + 1) / (double)n));
      l *= g; r *= g;
      if (outFloat) {
        float* o = (float*)(dst + (size_t)i * outCh * 4);
        if (outCh == 1) o[0] = (l + r) * 0.5f;
        else { o[0] = l; o[1] = r; for (int c = 2; c < outCh; ++c) o[c] = 0; }
      } else {
        short* o = (short*)(dst + (size_t)i * outCh * 2);
        float m0 = outCh == 1 ? (l + r) * 0.5f : l, m1 = r;
        if (m0 > 1.f) m0 = 1.f; if (m0 < -1.f) m0 = -1.f; if (m1 > 1.f) m1 = 1.f; if (m1 < -1.f) m1 = -1.f;
        o[0] = (short)(m0 * 32767.f);
        if (outCh >= 2) { o[1] = (short)(m1 * 32767.f); for (int c = 2; c < outCh; ++c) o[c] = 0; }
      }
    }
    hr = render->ReleaseBuffer(n, 0);
    if (FAILED(hr)) { fail_stream(hr, "release"); return; }
    wroteAny = 1;
    InterlockedExchangeAdd(&g_stPlayed, (LONG)n);
  }

  void fail_stream(HRESULT hr, const char* where) {
    InterlockedExchange(&g_stErr, (LONG)hr);
    InterlockedIncrement(&g_stReinit);
    log_line("AUDIO stream problem at %s (0x%08X); it will be reopened with the next menu", where, (unsigned)hr);
    close_client();
    if (++initFails >= 6) musicDead = 1;
  }

  void music_step(double dt, double nowMs, int open) {
    const int wantMusic = open && g_ctl.menuMusic && g_ctl.menuMusicPct > 0 && !musicDead;
    if (wantMusic) fade += dt / 1.2; else fade -= dt / 0.5;
    if (fade > 1.0) fade = 1.0;
    if (fade < 0.0) fade = 0.0;
    if (!wantMusic && fade <= 0.0) {
      if (running) { client->Stop(); client->Reset(); running = 0; InterlockedExchange(&g_stRunning, 0); }
      lastGain = 0;
      return;
    }
    if (!client) {
      if (nowMs < nextInitMs) { fade = 0; return; }
      if (!init_music()) { fade = 0; nextInitMs = nowMs + 3000.0; return; }
    }
    if (!client) return;
    const double pct = (double)g_ctl.menuMusicPct / 100.0;
    // an easing curve, so the start is soft
    const double g1 = pct * (fade * fade * (3.0 - 2.0 * fade));
    if (!running) {
      lastGain = 0;
      feed(0.0, 0.0);   // fill first, then start
      if (!client) return;
      HRESULT hr = client->Start();
      if (FAILED(hr)) { fail_stream(hr, "start"); return; }
      running = 1; InterlockedExchange(&g_stRunning, 1);
      log_line("AUDIO song started (volume %d%%)", (int)g_ctl.menuMusicPct);
    }
    feed(lastGain, g1);
    lastGain = g1;
    InterlockedExchange(&g_stGainPct, (LONG)(g1 * 100.0 + 0.5));
  }

  // ---- the game's sessions ----
  void free_sessions() {
    for (int i = 0; i < kMaxSess; ++i) if (ss[i].vol) { ss[i].vol->Release(); ss[i].vol = nullptr; }
    nss = 0;
  }

  void scan_sessions(int logAll) {
    if (!comOk || !enumr) return;
    for (int i = 0; i < nss; ++i) ss[i].seen = 0;
    IMMDeviceCollection* coll = nullptr;
    HRESULT hr = enumr->EnumAudioEndpoints(eRender, DEVICE_STATE_ACTIVE, &coll);
    UINT nd = 0;
    if (SUCCEEDED(hr) && coll) coll->GetCount(&nd);
    InterlockedExchange(&g_stEndpoints, (LONG)nd);
    InterlockedIncrement(&g_stScans);
    const DWORD myPid = GetCurrentProcessId();
    int ours = 0, others = 0, logged = 0;
    for (UINT d = 0; d < nd; ++d) {
      IMMDevice* dev = nullptr;
      if (FAILED(coll->Item(d, &dev)) || !dev) continue;
      IAudioSessionManager2* mgr = nullptr;
      if (SUCCEEDED(dev->Activate(kIidMgr2, CLSCTX_ALL, nullptr, (void**)&mgr)) && mgr) {
        IAudioSessionEnumerator* se = nullptr;
        if (SUCCEEDED(mgr->GetSessionEnumerator(&se)) && se) {
          int sc = 0; se->GetCount(&sc);
          for (int j = 0; j < sc; ++j) {
            IAudioSessionControl* ctl = nullptr;
            if (FAILED(se->GetSession(j, &ctl)) || !ctl) continue;
            IAudioSessionControl2* c2 = nullptr;
            if (SUCCEEDED(ctl->QueryInterface(kIidCtl2, (void**)&c2)) && c2) {
              DWORD pid = 0; c2->GetProcessId(&pid);
              LPWSTR idw = nullptr; uint64_t id = 0;
              if (SUCCEEDED(c2->GetSessionInstanceIdentifier(&idw)) && idw) { id = hash_w(idw); if (coFree) coFree(idw); }
              GUID grp; int mine = 0;
              if (id && myId && id == myId) mine = 1;
              if (!mine && SUCCEEDED(ctl->GetGroupingParam(&grp)) && same_guid(grp, kMySession)) mine = 1;
              ISimpleAudioVolume* v = nullptr;
              float cur = -1.f;
              if (SUCCEEDED(ctl->QueryInterface(kIidSimpleVol, (void**)&v)) && v) v->GetMasterVolume(&cur);
              if (logAll && logged < 30) {
                AudioSessionState st = AudioSessionStateInactive; ctl->GetState(&st);
                char nm[64]; proc_name(pid, nm, sizeof(nm));
                log_line("AUDIO session endpoint=%u pid=%u (%s) %s state=%d volume=%d%%", (unsigned)d, (unsigned)pid, nm,
                         pid == myPid ? (mine ? "OURS-SONG" : "OURS-GAME") : "other", (int)st, (int)(cur * 100.f + 0.5f));
                ++logged;
              }
              if (pid == myPid && !mine && v) {
                ++ours;
                int found = -1;
                for (int k = 0; k < nss; ++k) if (ss[k].vol && ss[k].id == id) { found = k; break; }
                if (found >= 0) { ss[found].seen = 1; }
                else if (nss < kMaxSess) {
                  ss[nss].vol = v; v->AddRef();
                  ss[nss].id = id;
                  ss[nss].orig = (cur >= 0.02f && cur <= 1.0f) ? cur : 1.0f;   // a session sitting at 0 is "stuck": give back full volume
                  ss[nss].seen = 1;
                  ++nss;
                }
              } else if (pid != myPid) ++others;
              if (v) v->Release();
              c2->Release();
            }
            ctl->Release();
          }
          se->Release();
        }
        mgr->Release();
      }
      dev->Release();
    }
    if (coll) coll->Release();
    // sessions that vanished
    for (int i = 0; i < nss; ) {
      if (!ss[i].seen) {
        if (ss[i].vol) ss[i].vol->Release();
        ss[i] = ss[nss - 1]; ss[nss - 1].vol = nullptr; --nss;
      } else ++i;
    }
    InterlockedExchange(&g_stSessions, (LONG)nss);
    InterlockedExchange(&g_stOtherSessions, (LONG)others);
    if (ours > 0 && !g_stFirstSeen) { g_stFirstSeen = 1; log_line("AUDIO the game's own sound sessions were found: %d (these are the ones that get muted)", ours); }
  }

  void set_flag(int on, float orig) {
    if (on) {
      HANDLE f = CreateFileW(flagPath, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
      if (f != INVALID_HANDLE_VALUE) {
        char b[24]; int len = log_fmt(b, sizeof(b), "%d", (int)(orig * 1000.f + 0.5f));
        DWORD w = 0; WriteFile(f, b, (DWORD)len, &w, nullptr); CloseHandle(f);
      }
    } else DeleteFileW(flagPath);
  }

  void apply_game_gain(int exact) {
    for (int i = 0; i < nss; ++i) {
      if (!ss[i].vol) continue;
      float v = exact ? ss[i].orig : (float)(ss[i].orig * gameGain);
      if (v < 0.f) v = 0.f; if (v > 1.f) v = 1.f;
      ss[i].vol->SetMasterVolume(v, nullptr);
    }
    InterlockedExchange(&g_stGamePct, (LONG)(gameGain * 100.0 + 0.5));
  }

  void game_step(double dt, double nowMs, int open) {
    // 1.7.88: only with a song to play instead (audiomath.h): the public download has none, and silencing the game for nothing left a silent menu
    const int songThere = song_exists();
    if (open && g_ctl.menuMuteGame && !songThere && !InterlockedExchange(&g_noSongLogged, 1))
      log_line("AUDIO no song file (gbvr_menu_music.mp3): the game's own sound is left alone while the menu is open, nothing would play instead");
    const int wantMute = audio::want_mute(open, (int)g_ctl.menuMuteGame, songThere, musicDead);
    if (wantMute && !muteActive) {
      muteActive = 1; InterlockedExchange(&g_stMuteActive, 1); InterlockedIncrement(&g_stMuteEvents);
      free_sessions();
      scan_sessions(!firstScanLogged); firstScanLogged = 1; lastScanMs = nowMs;
      set_flag(1, nss > 0 ? ss[0].orig : 1.0f);
      log_line("AUDIO game sound mute: %d session(s) of the game", nss);
    }
    if (!muteActive) return;
    if (wantMute) {
      if (nowMs - lastScanMs >= 1000.0) { scan_sessions(0); lastScanMs = nowMs; }
      gameGain -= dt / 0.25;
      if (gameGain < 0.0) gameGain = 0.0;
      apply_game_gain(0);
    } else {
      gameGain += dt / 0.6;
      if (gameGain >= 1.0) {
        gameGain = 1.0;
        scan_sessions(0);        // sessions that appeared while muted get their value back too
        apply_game_gain(1);
        free_sessions();
        set_flag(0, 1.0f);
        muteActive = 0; InterlockedExchange(&g_stMuteActive, 0); InterlockedIncrement(&g_stRestored);
        log_line("AUDIO game sound given back");
      } else apply_game_gain(0);
    }
  }

  // ---- 1.7.88 what the sound setup looks like (log only) ----
  void probe_now() {
    if (!enumr) { log_line("AUDIO probe: the Windows audio system cannot be reached from the game (com=%d)", comOk); return; }
    IMMDevice* dev = nullptr;
    if (SUCCEEDED(enumr->GetDefaultAudioEndpoint(eRender, eConsole, &dev)) && dev) {
      LPWSTR id = nullptr;
      if (SUCCEEDED(dev->GetId(&id)) && id) { log_line("AUDIO probe: default playback device %ls", id); if (coFree) coFree(id); }
      IAudioClient* c = nullptr;
      if (SUCCEEDED(dev->Activate(kIidClient, CLSCTX_ALL, nullptr, (void**)&c)) && c) {
        WAVEFORMATEX* mix = nullptr;
        if (SUCCEEDED(c->GetMixFormat(&mix)) && mix) {
          log_line("AUDIO probe: that device mixes at %d Hz, %d channels, %d bits, format tag %d (the game's sound is played through it; a game that asks for another rate is converted)",
                   (int)mix->nSamplesPerSec, (int)mix->nChannels, (int)mix->wBitsPerSample, (int)mix->wFormatTag);
          if (coFree) coFree(mix);
        }
        c->Release();
      }
      dev->Release();
    } else log_line("AUDIO probe: no default playback device");
    scan_sessions(1);   // one AUDIO session line per sound stream on the PC: process, state (1 = playing), volume
    log_line("AUDIO probe: the game has %d sound stream(s) of its own, %d belong to other programs. State 1 = playing; volume 0%% would be a muted game. song file present=%d, mute-while-menu setting=%d",
             nss, (int)g_stOtherSessions, song_exists() ? 1 : 0, (int)g_ctl.menuMuteGame);
    free_sessions();
  }

  // ---- crash recovery ----
  void recover_begin(double nowMs) {
    HANDLE f = CreateFileW(flagPath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    float val = 1.0f;
    if (f != INVALID_HANDLE_VALUE) {
      char b[24]; DWORD r = 0; ZeroMemory(b, sizeof(b));
      if (ReadFile(f, b, 16, &r, nullptr) && r > 0) { int n = 0; for (DWORD i = 0; i < r && b[i] >= '0' && b[i] <= '9'; ++i) n = n * 10 + (b[i] - '0'); if (n >= 300 && n <= 1000) val = (float)n / 1000.f; }
      CloseHandle(f);
    }
    recoverVal = val; recoverUntilMs = nowMs + 90000.0; recoverNextMs = nowMs + 3000.0; recoverDoneMs = 0;
    log_line("AUDIO marker file found: the last run ended while the game sound was muted; looking for sessions to give back (%d%%)", (int)(val * 100.f + 0.5f));
  }

  void recover_step(double nowMs) {
    if (recoverUntilMs <= 0 || muteActive) return;
    if (recoverDoneMs > 0 && nowMs >= recoverDoneMs) { recoverUntilMs = 0; free_sessions(); set_flag(0, 1.f); log_line("AUDIO recovery finished"); return; }
    if (nowMs >= recoverUntilMs) { recoverUntilMs = 0; free_sessions(); set_flag(0, 1.f); log_line("AUDIO recovery: no muted session found within 90 s; marker removed"); return; }
    if (nowMs < recoverNextMs) return;
    recoverNextMs = nowMs + 1500.0;
    free_sessions();
    scan_sessions(0);
    int fixed = 0;
    for (int i = 0; i < nss; ++i) {
      float cur = 1.f;
      if (ss[i].vol && SUCCEEDED(ss[i].vol->GetMasterVolume(&cur)) && cur < 0.02f) { ss[i].vol->SetMasterVolume(recoverVal, nullptr); ++fixed; }
    }
    free_sessions();
    if (fixed) { InterlockedExchangeAdd(&g_stRecovered, fixed); log_line("AUDIO recovery: %d session(s) were silent from the last run and are back to %d%%", fixed, (int)(recoverVal * 100.f + 0.5f)); if (recoverDoneMs <= 0) recoverDoneMs = nowMs + 6000.0; }
  }

  // ---- thread ----
  void run() {
    zero();
    lstrcpynW(flagPath, g_selfDir, MAX_PATH);
    lstrcatW(flagPath, L"gbvr_audio_muted.flag");
    ole = LoadLibraryW(L"ole32.dll");
    if (ole) {
      coInit = (PFN_CoInit)GetProcAddress(ole, "CoInitializeEx");
      coUninit = (PFN_CoUninit)GetProcAddress(ole, "CoUninitialize");
      coCreate = (PFN_CoCreate)GetProcAddress(ole, "CoCreateInstance");
      coFree = (PFN_CoFree)GetProcAddress(ole, "CoTaskMemFree");
    }
    if (coInit && coCreate) {
      HRESULT hr = coInit(nullptr, COINIT_MULTITHREADED);
      comOk = SUCCEEDED(hr);
      if (comOk) {
        hr = coCreate(kClsidEnum, nullptr, CLSCTX_ALL, kIidEnum, (void**)&enumr);
        if (FAILED(hr) || !enumr) { log_line("AUDIO cannot reach the Windows audio system (0x%08X)", (unsigned)hr); enumr = nullptr; }
      } else log_line("AUDIO COM start failed (0x%08X)", (unsigned)hr);
    } else log_line("AUDIO ole32 functions missing");
    log_line("AUDIO thread up (com=%d enumerator=%d)", comOk, enumr != nullptr);
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);

    const int64_t f = qpc_freq();
    int64_t last = qpc_now();
    if (InterlockedCompareExchange(&g_recover, 0, 1) == 1) recover_begin((double)last * 1000.0 / (double)f);
    for (;;) {
      if (g_quit) break;
      const int64_t t = qpc_now();
      double dt = (double)(t - last) / (double)f; last = t;
      if (dt < 0.001) dt = 0.001; if (dt > 0.25) dt = 0.25;
      const double nowMs = (double)t * 1000.0 / (double)f;
      const int open = g_open != 0;
      if (enumr) { music_step(dt, nowMs, open); game_step(dt, nowMs, open); recover_step(nowMs); }
      if (g_probe && !muteActive && recoverUntilMs <= 0) { InterlockedExchange(&g_probe, 0); probe_now(); }
      Sleep((running || muteActive) ? 8 : 40);
    }
    // closing: give everything back at once
    if (muteActive) { gameGain = 1.0; scan_sessions(0); apply_game_gain(1); free_sessions(); set_flag(0, 1.f); muteActive = 0; log_line("AUDIO game sound given back (closing)"); }
    close_client();
    free_sessions();
    rel(enumr);
    if (data) { HeapFree(GetProcessHeap(), 0, data); data = nullptr; }
    if (comOk && coUninit) coUninit();
    log_line("AUDIO thread ended");
  }
};

Worker g_w;

DWORD WINAPI audio_thread(LPVOID) { g_w.run(); return 0; }

void ensure_thread() {
  if (g_threadUp) return;
  if (InterlockedCompareExchange(&g_threadUp, 1, 0) != 0) return;
  // a big committed stack: the MP3 decoder keeps ~16 KB of work space on the stack and this build has no stack probes
  g_thread = CreateThread(nullptr, 512 * 1024, audio_thread, nullptr, 0, nullptr);
  if (!g_thread) { log_line("AUDIO could not start its thread (%lu)", GetLastError()); }
}

}  // namespace

void audio_boot() {
  static LONG done;
  if (InterlockedCompareExchange(&done, 1, 0) != 0) return;
  wchar_t p[MAX_PATH + 40];
  lstrcpynW(p, g_selfDir, MAX_PATH);
  lstrcatW(p, L"gbvr_audio_muted.flag");
  if (GetFileAttributesW(p) != INVALID_FILE_ATTRIBUTES) { InterlockedExchange(&g_recover, 1); ensure_thread(); }
}

void audio_menu(int open) {
  InterlockedExchange(&g_open, open ? 1 : 0);
  if (audio::thread_needed(open ? 1 : 0, (int)g_ctl.menuMusic, (int)g_ctl.menuMuteGame, song_exists())) ensure_thread();   // 1.7.88: no song file = no thread, no audio calls
}

// 1.7.88: log the PC's sound setup once (default device and format, every sound stream and its volume): for reports of "no sound" / "broken sound"
void audio_probe() {
  InterlockedExchange(&g_probe, 1);
  ensure_thread();
}

void audio_shutdown() {
  InterlockedExchange(&g_quit, 1);
  InterlockedExchange(&g_open, 0);
  if (g_thread) {
    const DWORD w = WaitForSingleObject(g_thread, 700);
    log_line("AUDIO shutdown: thread %s", w == WAIT_OBJECT_0 ? "ended" : "still busy (left to the process end)");
  }
}

void audio_report(LONG frame) {
  log_line("AUDIO frame=%d thread=%d open=%d | song: file=%d bytes=%d src=%dHz/%dch out=%dHz/%dch %s ready=%d playing=%d gain=%d%% framesPlayed=%d loops=%d underruns=%d reopened=%d lastErr=0x%08X | "
           "game: muteActive=%d muteEvents=%d given-back=%d scans=%d endpoints=%d gameSessions=%d otherProcessSessions=%d gameGain=%d%% recovered=%d",
           (int)frame, (int)g_threadUp, (int)g_open, (int)(g_w.fileOk), (int)g_stBytes, (int)g_stHz, (int)g_stCh, (int)g_stOutHz, (int)g_stOutCh,
           g_stOutFloat ? "float" : "16-bit", (int)g_stInit, (int)g_stRunning, (int)g_stGainPct, (int)g_stPlayed, (int)g_stLoops, (int)g_stUnder,
           (int)g_stReinit, (unsigned)g_stErr, (int)g_stMuteActive, (int)g_stMuteEvents, (int)g_stRestored, (int)g_stScans, (int)g_stEndpoints,
           (int)g_stSessions, (int)g_stOtherSessions, (int)g_stGamePct, (int)g_stRecovered);
}

#endif
