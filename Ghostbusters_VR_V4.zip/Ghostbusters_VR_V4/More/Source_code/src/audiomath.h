// 1.7.88 when the mod may touch the game's own sound (audio.cpp). Plain logic, tested by tests/test_audiomute.cpp.
//
// While the menu is open the mod can silence the game's sound so the menu's own song (gbvr_menu_music.mp3 in the game folder) can be heard.
// The public download has no song file. Silencing the game with nothing to replace it left players with a silent menu - and, when Windows (or
// Proton) did not hand the volume back cleanly, a silent game. So the game's sound is only touched when there is a song to play instead.
#pragma once

namespace audio {

inline int want_mute(int menuOpen, int muteSetting, int songFilePresent, int songDead) {
  return (menuOpen && muteSetting && songFilePresent && !songDead) ? 1 : 0;
}

// start the audio thread (COM, the Windows audio system) only when it has a job
inline int thread_needed(int menuOpen, int musicSetting, int muteSetting, int songFilePresent) {
  return (menuOpen && songFilePresent && (musicSetting || muteSetting)) ? 1 : 0;
}

}  // namespace audio
