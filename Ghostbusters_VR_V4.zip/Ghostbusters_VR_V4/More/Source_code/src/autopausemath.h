// 0.52 auto-pause. When the player leaves the game in VR (opens the SteamVR menu, takes the headset off, SteamVR
// quits) the game keeps running and the player, who can no longer see it, is stuck. The tool then "presses Start"
// for the game. Pure logic, no Windows dependency; unit-tested in tests/test_autopause.cpp.
//
// Rules:
//  * only when the game is really running (not already paused / in a menu / loading): Start toggles the pause
//    menu, so pressing it in a menu would CLOSE the menu
//  * the press is held 180 ms (the game wants a press and a release)
//  * 1.2 s later the game is asked again whether it runs; if it still does the press is repeated (3 tries in all)
#pragma once
#include <stdint.h>

namespace autop {

enum { kHoldMs = 180, kCheckMs = 1200, kMaxTries = 3 };

struct Pauser {
  int seen;                 // leave events already handled
  int phase;                // 0 idle, 1 start held, 2 waiting to see whether the game stopped
  int tries;
  uint32_t holdFrom, holdUntil, checkAt;
  // counters for the log
  int events, started, skipOff, skipNotRunning, skipBusy, retries, paused, failed;
  int lastResult;           // 0 none yet, 1 paused, 2 gave up
  uint32_t lastStartMs;

  void reset() {
    seen = 0; phase = 0; tries = 0; holdFrom = holdUntil = checkAt = 0;
    events = started = skipOff = skipNotRunning = skipBusy = retries = paused = failed = 0;
    lastResult = 0; lastStartMs = 0;
  }
  // Call regularly (every game loop iteration). leaveCount: how many "player left" events SteamVR gave so far.
  // running: 1 if the game simulates normally right now. Returns what happened for the log:
  // 0 nothing, 1 attempt started, 2 skipped (switched off), 3 skipped (game not running), 4 skipped (busy),
  // 5 game stopped = success, 6 retry, 7 gave up
  int update(uint32_t now, int leaveCount, int running, int enabled) {
    int what = 0;
    if (leaveCount != seen) {
      int fresh = leaveCount - seen;
      if (fresh < 0 || fresh > 1000) fresh = 1;
      seen = leaveCount;
      events += fresh;
      if (!enabled) { skipOff++; what = 2; }
      else if (phase != 0) { skipBusy++; what = 4; }
      else if (!running) { skipNotRunning++; what = 3; }
      else {
        phase = 1; tries = 1; started++;
        holdFrom = now; holdUntil = now + kHoldMs; lastStartMs = now;
        what = 1;
      }
    }
    if (phase == 1 && (int32_t)(now - holdUntil) >= 0) {
      phase = 2;
      checkAt = now + kCheckMs;
    }
    if (phase == 2 && (int32_t)(now - checkAt) >= 0) {
      if (!running) { phase = 0; paused++; lastResult = 1; what = 5; }
      else if (tries < kMaxTries) { tries++; retries++; phase = 1; holdFrom = now; holdUntil = now + kHoldMs; what = 6; }
      else { phase = 0; failed++; lastResult = 2; what = 7; }
    }
    return what;
  }
  // 1 while the Start button must be reported as held
  int held(uint32_t now) const {
    return phase == 1 && (int32_t)(now - holdFrom) >= 0 && (int32_t)(now - holdUntil) < 0;
  }
};

// The game counts as running when its main loop simulated within the last 400 ms.
inline int running_from_stamp(uint32_t now, uint32_t lastSimMs) {
  return lastSimMs != 0 && (int32_t)(now - lastSimMs) >= 0 && (now - lastSimMs) < 400;
}

}  // namespace autop
