#pragma once
#include <stdint.h>
// Remember the game's confirmed trap-completion events. A pointer may be
// reused after the actor leaves the list; an absent scan expires that record.
namespace barlife {
struct Ledger {
  struct Entry { uintptr_t id; unsigned scan; } e[128] = {};
  unsigned scan = 0, next = 0;
  uintptr_t world = 0;
  void begin(uintptr_t w) {
    if (w != world) { for (auto& x : e) x = {}; world = w; scan = next = 0; }
    ++scan;
  }
  void caught(uintptr_t id) {
    if (!id) return;
    for (auto& x : e) if (x.id == id) { x.scan = scan; return; }
    e[next++ % 128] = {id, scan};
  }
  int finished(uintptr_t id) {
    for (auto& x : e) if (x.id == id) {
      if ((unsigned)(scan - x.scan) > 1) { x = {}; return 0; }
      x.scan = scan;
      return 1;
    }
    return 0;
  }
};
}
