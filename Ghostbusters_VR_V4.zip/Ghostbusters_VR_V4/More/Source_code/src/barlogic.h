// 1.7.30 "smart health bars": pure decisions (tests/test_barlogic.cpp). No game memory in here.
//
// The 1.7.29 report: "health bars spawn before ghosts do, and also health bars stay after ghosts are in trap".
//  1) The game keeps a ghost "lockable" (active) before the ghost is drawn (behind a wall, still spawning in). The 1.7.29 log: the game's drawn-recently test passed only 18 % of the time for ghosts the bar
//     rule had accepted. The bar must wait until the ghost has been SEEN once; after that it stays (also behind a wall: the 19:45 rule), until the ghost is gone for a while.
//  2) A ghost that was held by the capture stream and ended up at the trap stays in the game's list, stationary and still "lockable". It is remembered as trapped and gets no bar.
// The drawn-recently test is checked against ghosts that are surely in view (just hit, or in the capture stream). If it keeps failing for those it is not trusted and the old rule (active = bar) is used.
#pragma once
#include <stdint.h>
#include "vmath.h"

namespace barlogic {

// 1 = the drawn-recently test can be used. Needs a verdict from ghosts that are surely in view (known visible): trusted until it has failed 12 or more times with fewer than 1 pass in 6 fails.
inline int trust_drawn(long knownPass, long knownFail) { return !(knownFail >= 12 && knownPass * 6 < knownFail); }

// seen: has this ghost been in the picture since it became active? drawn: -1 unreadable, 0 no, 1 yes. knownVisible: just hit / in the stream.
inline int seen_step(int seen, int drawn, int knownVisible, int trusted) {
  if (seen) return 1;
  if (knownVisible) return 1;
  if (!trusted) return 1;            // the test is no use: the 1.7.29 rule (active = bar)
  if (drawn < 0) return 1;           // unreadable: the old rule
  return drawn == 1;
}

// forgetting: a ghost that is neither active nor drawn for forgetS seconds starts again (a ghost that despawns and comes back must be seen again). inactiveQ = when that began (0 = not now).
// Returns the new seen flag; updates inactiveQ.
inline int forget_step(int seen, int active, int drawn, int64_t* inactiveQ, int64_t now, int64_t freq, double forgetS) {
  if (active || drawn == 1) { *inactiveQ = 0; return seen; }
  if (!*inactiveQ) { *inactiveQ = now; return seen; }
  if ((double)(now - *inactiveQ) / (double)freq > forgetS) return 0;
  return seen;
}

inline double dist3(const float* a, const float* b) {
  const double dx = (double)a[0] - b[0], dy = (double)a[1] - b[1], dz = (double)a[2] - b[2];
  return vm::dsqrt(dx * dx + dy * dy + dz * dz);
}

// A trap lying on the floor (not carried): its height above the player's feet is small.
inline int trap_on_floor(const float* trapPos, const float* playerPos) { return (double)trapPos[1] - (double)playerPos[1] < 1.5; }

// The trapped latch. held = the ghost is in the capture stream now. trapDown = a trap lies on the floor and trapPos is valid.
// latched: 0 -> 1 when the ghost is held within enterFt of the trap; 1 -> 0 when it is more than leaveFt from where it was latched (it got away). anchor = where it was latched.
inline int trap_step(int latched, float* anchor, int held, int trapDown, const float* trapPos, const float* ghostPos, double enterFt, double leaveFt) {
  if (latched) {
    if (dist3(ghostPos, anchor) > leaveFt) return 0;
    return 1;
  }
  if (held && trapDown && dist3(ghostPos, trapPos) < enterFt) {
    anchor[0] = ghostPos[0]; anchor[1] = ghostPos[1]; anchor[2] = ghostPos[2];
    return 1;
  }
  return 0;
}

// The bar rule on top of the 1.7.29 ones (active, in front, in range). 1 = the bar may be drawn.
inline int bar_allowed(int seen, int trapped) { return seen && !trapped; }

// ---- 1.7.31 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The 1.7.30 report: "can still see trapped ghost health bars". Two findings in the 1.7.30 code:
//  1) the "held by the capture stream" test compared the ghost with player+0x24D80, which always holds the beam object (CProtonBeam), never the ghost: the trapped latch could not switch on. The held ghost is the LOCK TARGET.
//  2) distances were 3D, but a ghost hovers 4 ft or more above the floor trap it is dragged to, so the 4 ft entry circle was hardly ever reached. Now the entry is measured along the floor (x/z) with a height window.
// The second rule does not depend on any trap state at all: a ghost that was seen, is in front of you inside a narrow cone with a clear line to it, but that the game has not drawn for goneS seconds, is gone (sucked into the trap,
// finished, hidden): no bar until the game draws it again. Behind a wall (blocked line) the bar stays, as the 19:45 rule wants.

inline double dist_xz(const float* a, const float* b) {
  const double dx = (double)a[0] - b[0], dz = (double)a[2] - b[2];
  return vm::dsqrt(dx * dx + dz * dz);
}

// Trapped latch v2. lockedOnIt = the ghost is the player's lock target now; capRecent = the capture button was down in the last few seconds.
// Enter (a trap lies on the floor): along the floor within nearFt while the capture stream holds it, or within overFt whatever the stream does (right on top of the trap); the height difference must be inside the window.
// Leave: more than leaveFt along the floor from where it was latched (it got away), or the trap is gone and the ghost is not near where it was.
inline int trap_step2(int latched, float* anchor, int lockedOnIt, int capRecent, int trapDown, const float* trapPos, const float* ghostPos,
                      double nearFt, double overFt, double maxDyFt, double leaveFt) {
  if (latched) {
    if (dist_xz(ghostPos, anchor) > leaveFt) return 0;
    return 1;
  }
  if (!trapDown) return 0;
  const double dy = (double)ghostPos[1] - trapPos[1];
  if (dy < -3.0 || dy > maxDyFt) return 0;
  const double d = dist_xz(ghostPos, trapPos);
  if ((lockedOnIt && capRecent && d < nearFt) || (d < overFt && dy < 5.0)) {
    anchor[0] = ghostPos[0]; anchor[1] = ghostPos[1]; anchor[2] = ghostPos[2];
    return 1;
  }
  return 0;
}

// "Gone" timer: cond = seen, in the cone, line clear, not drawn (and the drawn test is trusted). Returns 1 once cond has held for goneS seconds without a break. sinceQ = when it began (0 = not now).
inline int vanish_step(int64_t* sinceQ, int cond, int64_t now, int64_t freq, double goneS) {
  if (!cond) { *sinceQ = 0; return 0; }
  if (!*sinceQ) { *sinceQ = now; return 0; }
  return (double)(now - *sinceQ) / (double)freq >= goneS;
}

// Self-check of the "gone" rule: among ghosts that are seen, active, in the cone with a clear line, the game's drawn test must say "drawn" for at least half of them (after 200 samples), or it does not describe what is on the screen
// and the rule stays off. inViewDrawn / inViewNot = counts of those samples.
inline int vanish_trusted(long inViewDrawn, long inViewNot) {
  const long total = inViewDrawn + inViewNot;
  return total < 200 || inViewDrawn * 2 >= total;
}

// The cone test for the "gone" rule: p = the ghost's centre in head space (z forward), 1 = within maxDeg of straight ahead, in front, and not nearer than the ghost's own size.
inline int in_cone(const float* p, double maxDeg) {
  if (!(p[2] > 0.3f)) return 0;
  const double hy = vm::dsqrt((double)p[0] * p[0] + (double)p[1] * p[1]);
  const double ang = vm::datan2(hy, (double)p[2]) * 180.0 / vm::kPi;
  return ang <= maxDeg;
}

}  // namespace barlogic
