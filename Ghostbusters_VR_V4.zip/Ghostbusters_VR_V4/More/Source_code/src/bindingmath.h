// Private VR action history. The engine may rewrite its binding buffer between
// updates; that buffer must not be the previous state of our virtual controller.
#pragma once
namespace binding {
struct Action {
  int state = 0;
  float hold = 0;
  void step(bool down, float dt) {
    if (!(dt > 0) || dt > 0.25f) dt = 0;
    if (down) {
      if (state != 1) { state = 1; hold = 0; }
      else hold += dt;
    } else if (state == 1) state = 2;
    else { state = 0; hold = 0; }
  }
  bool query(int kind) const {
    return kind == 0 ? state == 1 : kind == 1 ? state == 2 : state == 1 && hold == 0;
  }
};
}
