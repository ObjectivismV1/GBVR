// 0.52 the game's player body follows the real body. Pure math, no Windows dependency; unit-tested in tests/test_body.cpp.
//
// The game keeps the player actor where its own logic puts it; only the camera (eye) moved with the headset. 0.52 moves
// the actor's MODELS (body, pack, hose, extras - their world matrices, see engine_hooks.cpp hk_mat_mul) so that
//   * the body stands under the real head (room-scale steps, leaning),
//   * the torso turns after the head once it looked far enough to one side (like a real body would),
//   * the body is scaled so it is as tall as the camera's eye height says (and a calibration measures the real height).
// All in game feet, row-vector matrices (world = local * W, translation in row 3), yaw as the engine has it:
// forward = (sin yaw, 0, cos yaw), a positive yaw turns from +z towards +x.
#pragma once
#include <stdint.h>
#include "vmath.h"

namespace body {

inline double wrap_pi(double a) {
  const double kPi = 3.14159265358979323846;
  while (a > kPi) a -= 2.0 * kPi;
  while (a < -kPi) a += 2.0 * kPi;
  return a;
}

// 1 - exp(-x) without libm (x >= 0): a series that is good to 1e-4 up to x = 3, then saturates
inline double one_minus_exp(double x) {
  if (!(x > 0)) return 0;
  if (x > 6.0) return 1.0;
  // exp(-x) = (exp(-x/8))^8 with a short series for the small argument
  double y = x / 8.0;
  double e = 1.0 - y + y * y / 2.0 - y * y * y / 6.0 + y * y * y * y / 24.0;
  e = e * e; e = e * e; e = e * e;
  return 1.0 - e;
}

// The torso's yaw relative to the direction the game faces. It stays while the head looks within deadRad of it and
// follows the head (with a lag of lagSec) once the head looks further to the side.
struct Torso {
  double yaw;
  int init;
  void reset() { yaw = 0; init = 0; }
  // headYaw: head yaw relative to the game's facing (radians); dt in seconds. Returns the new torso yaw.
  double step(double headYaw, double dt, double deadRad, double lagSec) {
    if (!init) { yaw = 0; init = 1; }
    if (!(dt > 0) || dt > 0.5) dt = 0.0111;
    if (lagSec < 0.02) lagSec = 0.02;
    double diff = wrap_pi(headYaw - yaw);
    double ad = diff < 0 ? -diff : diff;
    if (ad > deadRad) {
      double over = ad - deadRad;
      yaw += (diff < 0 ? -over : over) * one_minus_exp(dt / lagSec);
    }
    yaw = wrap_pi(yaw);
    const double lim = 2.3;   // about 130 degrees: a body does not twist further
    if (yaw > lim) yaw = lim;
    if (yaw < -lim) yaw = -lim;
    return yaw;
  }
};

// 1.7.167 "improve the rig to follow the body better": people turn their chest toward their hands, not only toward where they look. The yaw the torso
// follows leans from the head's yaw toward the direction of the hands' midpoint (head -> hands, level), up to 45 %, when both hands are in front of you
// (closer than 100 deg to where you look) and away from the body (over 15 cm). headYaw: the engine yaw the torso uses; head34 / left34 / right34:
// OpenVR 3x4 tracking poses (metres, -z forward). Only the ANGLE between the head's look and the hands (both in tracking) is used, added to headYaw.
inline double hands_yaw(double headYaw, const float* head34, const float* left34, const float* right34, double* w) {
  *w = 0.0;
  if (!head34 || !left34 || !right34) return headYaw;
  const double mx = 0.5 * ((double)left34[3] + right34[3]) - head34[3], mz = 0.5 * ((double)left34[11] + right34[11]) - head34[11];
  const double d = vm::dsqrt(mx * mx + mz * mz);
  if (!(d > 0.15) || !(d < 3.0)) return headYaw;
  const double fx = -(double)head34[2], fz = -(double)head34[10];   // the head's forward (tracking, level part)
  if (fx * fx + fz * fz < 0.01) return headYaw;                       // looking straight up or down: no heading
  const double diff = wrap_pi(vm::datan2(mx, -mz) - vm::datan2(fx, -fz)), ad = diff < 0 ? -diff : diff;   // engine-style yaw (x right, z forward)
  const double kDeg = 3.14159265358979 / 180.0;
  const double k = ad <= 70.0 * kDeg ? 1.0 : (ad >= 100.0 * kDeg ? 0.0 : (100.0 * kDeg - ad) / (30.0 * kDeg));
  double closeK = (d - 0.15) / 0.15; if (closeK > 1.0) closeK = 1.0;
  *w = 0.45 * k * closeK;
  return wrap_pi(headYaw + diff * *w);
}

// Full-body chest geometry can cross the near eye when the player looks
// steeply down. Keep a small angle gap so the render-only switch does not
// chatter while the headset rests on the boundary.
inline int chest_occluded_step(int hidden, double forwardY, double horizontalLen) {
  if (!(horizontalLen > 0.01)) return forwardY < -0.01 ? 1 : 0;
  const double down = -forwardY / horizontalLen;
  return hidden ? (down > 0.7002075382) : (down > 1.1917535926); // 35 / 50 degrees
}

// One rigid-plus-scale placement of the player's models:
//   p' = s * ((p - A) * R(phi)) + A + d       A = the actor's feet, d = how far the real head is from the game's head
struct Xf {
  double s, sinP, cosP;
  double A[3], d[3];
  void set(double scale, double phi, const float* feet, const float* offset) {
    s = scale;
    vm::dsincos(phi, &sinP, &cosP);
    for (int i = 0; i < 3; ++i) { A[i] = feet[i]; d[i] = offset[i]; }
  }
  // Fade a tracked placement toward the game's original placement without
  // averaging rotation-matrix elements. A 180-degree difference would make
  // the old matrix midpoint singular and could spin/stretch the viewmodel.
  void set_blend(double scale, double phi, const float* feet, const float* offset, double gameBlend) {
    const double k = gameBlend < 0.0 ? 1.0 : gameBlend > 1.0 ? 0.0 : 1.0 - gameBlend;
    float off[3]; for (int i = 0; i < 3; ++i) off[i] = (float)((double)offset[i] * k);
    set(1.0 + (scale - 1.0) * k, phi * k, feet, off);
  }
  void point(const float* p, float* o) const {
    double x = (double)p[0] - A[0], y = (double)p[1] - A[1], z = (double)p[2] - A[2];
    double rx = x * cosP + z * sinP, rz = -x * sinP + z * cosP;   // row vector times R: rows (c,0,-s) (0,1,0) (s,0,c)
    o[0] = (float)(s * rx + A[0] + d[0]);
    o[1] = (float)(s * y + A[1] + d[1]);
    o[2] = (float)(s * rz + A[2] + d[2]);
  }
  void dir(const float* v, double* o) const {   // a direction (no translation, no scale)
    o[0] = (double)v[0] * cosP + (double)v[2] * sinP; o[1] = v[1]; o[2] = -(double)v[0] * sinP + (double)v[2] * cosP;
  }
  // world matrix (16 floats, row-vector form): rotation rows turned and scaled, translation placed
  void matrix(const float* W, float* o) const {
    for (int r = 0; r < 3; ++r) {
      double v[3] = {W[r * 4], W[r * 4 + 1], W[r * 4 + 2]};
      double t[3];
      dir_d(v, t);
      o[r * 4] = (float)(s * t[0]); o[r * 4 + 1] = (float)(s * t[1]); o[r * 4 + 2] = (float)(s * t[2]); o[r * 4 + 3] = W[r * 4 + 3];
    }
    point(W + 12, o + 12);
    o[15] = W[15];
  }
  void dir_d(const double* v, double* o) const { o[0] = v[0] * cosP + v[2] * sinP; o[1] = v[1]; o[2] = -v[0] * sinP + v[2] * cosP; }
};

// Body scale: the model's eye is nominally modelEyeFt above the feet; the camera's eye is camEyeFt above them.
inline double body_scale(double camEyeFt, double modelEyeFt) {
  if (!(modelEyeFt > 1.0) || !(camEyeFt > 0.5)) return 1.0;
  double s = camEyeFt / modelEyeFt;
  if (s < 0.85) s = 0.85;   // 1.7.13: was 0.6-1.6; a body scaled that far looked broken (stretched or squashed arms and hands)
  if (s > 1.2) s = 1.2;
  return s;
}

// 1.7.99: the body must not change size while you play. The target scale (camera eye / the model's measured eye) drifts as the measurement of the model's eye height (a histogram
// peak over the animations seen so far) settles, and every drift resized the whole body, arms and hands with it. A change smaller than kScaleBand is ignored; a larger,
// lasting one is followed slowly (1 % per second). prev <= 0 = no scale yet: the target is taken at once (new level, new character).
static const double kScaleBand = 0.05, kScaleRate = 0.002;   // 1.7.179: was 0.015 / 1 %: the 1.7.178 log drifted 1.00 -> 0.94 in 6 s (model eye 5.65 -> 5.92 ft) and the gun and hands shrank with it
inline double scale_hold(double prev, double target, double dt) {
  if (!(prev > 0.0) || !(target > 0.0)) return target;
  const double diff = target - prev;
  if (diff < kScaleBand && diff > -kScaleBand) return prev;
  const double step = (dt > 0.0 && dt < 0.25 ? dt : 0.0) * kScaleRate;
  if (diff > 0.0) return diff <= step ? target : prev + step;
  return -diff <= step ? target : prev - step;
}

// Calibration: the player's real eye height (metres above the floor) -> player-height percent (sizePct) so that
// the camera's eye height (eyeHeightFt * size) equals the real height scaled like everything else (world factor).
inline int size_pct_for(double eyeHeightM, double worldFactor, double eyeHeightFt) {
  if (!(eyeHeightM > 0.5) || !(eyeHeightFt > 1.0)) return 0;
  double ft = eyeHeightM * 3.280839895 * worldFactor;
  double pct = 100.0 * ft / eyeHeightFt;
  int v = (int)(pct + 0.5);
  if (v < 85) v = 85;   // 1.7.13: was 70-150 (a wrong measurement put the view at the stomach or made a giant)
  if (v > 120) v = 120;
  return v;
}

// 1.7.17: Calibration without lowering the view. The 1.7.16 log: the measured 161 cm gave player height 85 %: the camera dropped 0.83 ft and the torso was scaled, but the arms and hands kept
// their size and the wrist fell short of the controller by up to 1.13 ft (the view "sank into the stomach"). The character is no longer scaled and the eye never moves down;
// the WORLD is scaled to the player instead: the camera sits at the character's eye (eyeHeightFt above the feet) and the game moves (real eye height x worldFactor) feet for the
// player's real height, so worldFactor = eyeHeightFt / real eye height (feet) and the world percent is its inverse. Result 90..125 %.
inline int world_pct_for(double eyeHeightM, double avatarEyeFt) {
  if (!(eyeHeightM > 0.5) || !(avatarEyeFt > 1.0)) return 0;
  const double ft = eyeHeightM * 3.280839895;
  int v = (int)(100.0 * ft / avatarEyeFt + 0.5);
  if (v < 90) v = 90;
  if (v > 125) v = 125;
  return v;
}

// 1.7.110 HEIGHT METER. The old measure took the upper quarter of every head height seen in 1.5 s and refused only above 20 cm of movement: a nod, a lean or a glance up moved the result by
// centimetres, and everything the world size is matched to depends on it. Now the head heights are kept with their times and the STEADIEST one second is found (smallest spread): the
// result is the 70th percentile of that second (standing straight is the highest steady height; a dip does not lower it, a one-off high sample does not raise it). It finishes as soon as a
// second is steady within 4 cm (not before 1.5 s), keeps listening up to 3.5 s when it is not, and then accepts a second within 8 cm or refuses ("you moved").
struct HeightMeter {
  enum { kMax = 700 };
  float t[kMax], y[kMax]; int n;
  double minMs, maxMs, winMs, okRange, loRange;
  // result of the last step()
  double value, range, winStartMs, winEndMs; int winN, loose;
  void reset() { n = 0; minMs = 1500.0; maxMs = 3500.0; winMs = 1000.0; okRange = 0.04; loRange = 0.08; value = range = winStartMs = winEndMs = 0.0; winN = loose = 0; }
  void add(double tMs, double yM) { if (n < kMax && yM > 0.3 && yM < 2.6) { t[n] = (float)tMs; y[n] = (float)yM; ++n; } }
  // 0 keep measuring, 1 done (value), 2 refused (the steadiest second moved more than loRange, or no usable samples)
  int step(double nowMs) {
    if (n < 10 || nowMs < minMs) return nowMs >= maxMs ? 2 : 0;
    double bestR = 9.0; int bi = -1, bj = -1;
    int j0 = 0;
    for (int i = 0; i < n; ++i) {
      if (j0 < i) j0 = i;
      int j = j0;
      while (j + 1 < n && (double)t[j + 1] - (double)t[i] <= winMs) ++j;
      j0 = j;
      if (j - i + 1 < 10) continue;
      if ((double)t[j] - (double)t[i] < 0.6 * winMs) continue;
      float lo = y[i], hi = y[i];
      for (int k = i + 1; k <= j; ++k) { if (y[k] < lo) lo = y[k]; if (y[k] > hi) hi = y[k]; }
      const double r = (double)hi - (double)lo;
      if (r <= bestR) { bestR = r; bi = i; bj = j; }   // equal spread: the later second
    }
    if (bi < 0) return nowMs >= maxMs ? 2 : 0;
    float w[kMax]; int m = 0;
    for (int k = bi; k <= bj; ++k) w[m++] = y[k];
    for (int a = 1; a < m; ++a) { float v = w[a]; int b = a - 1; while (b >= 0 && w[b] > v) { w[b + 1] = w[b]; --b; } w[b + 1] = v; }
    range = bestR; winN = m; winStartMs = (double)t[bi]; winEndMs = (double)t[bj];
    value = (double)w[(m * 7) / 10 < m ? (m * 7) / 10 : m - 1];
    if (bestR <= okRange) { loose = 0; return 1; }
    if (nowMs >= maxMs) { if (bestR <= loRange) { loose = 1; return 1; } return 2; }
    return 0;
  }
};

// Calibration gesture: both conditions held for holdMs, the head height sampled meanwhile.
struct Calib {
  int active;
  double heldMs;
  int n;
  HeightMeter m;           // 1.7.110: the steadiest second of the head height (see HeightMeter)
  float peakHand;          // highest controller seen while holding (log only)
  struct Last { int n, winN, loose; double range, winStartMs, winEndMs; } last;   // the meter's numbers of the last finished measure (the meter itself is reset)
  void reset() { active = 0; heldMs = 0; n = 0; peakHand = 0; m.reset(); }
  // Returns 0 nothing, 1 started, 2 finished (the measured head height in *medianM), 3 cancelled / refused
  int update(double dtMs, int gestureHeld, double headY, double* medianM, double holdNeededMs = 1500.0) {
    if (!gestureHeld) {
      int was = active;
      reset();
      return was == 1 ? 3 : 0;
    }
    if (active == 2) return 0;   // already done, waiting for the player to let go
    int ev = 0;
    if (!active) { active = 1; heldMs = 0; n = 0; m.reset(); m.minMs = holdNeededMs; ev = 1; }
    heldMs += dtMs;
    m.add(heldMs, headY);
    n = m.n;
    const int r = m.step(heldMs);
    if (r != 0) { last.n = m.n; last.winN = m.winN; last.loose = m.loose; last.range = m.range; last.winStartMs = m.winStartMs; last.winEndMs = m.winEndMs; }
    if (r == 1) { *medianM = m.value; reset(); active = 2; return 2; }
    if (r == 2) { reset(); active = 2; return 3; }
    return ev;
  }
};

}  // namespace body
