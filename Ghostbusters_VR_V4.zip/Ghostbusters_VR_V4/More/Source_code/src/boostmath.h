// 1.7.8 / 1.7.9 Sprint as a plain speed boost (pure math, game feet and seconds; tested in tests/test_boost.cpp).
//
// The 1.7.6 / 1.7.7 sprint set the game's own run bit. The log proved the game really ran (its run timer ran for 4798 frames) but the character was not faster (6.7 ft/s against 7.5
// ft/s walking at a full stick) and the game's sprint locks the walk to the facing direction and plays its run animation: "sprint feels awful and only goes in one direction".
// Now the game's sprint is never started. While sprint is switched on (left stick click) and the left stick is pushed, the player just moves faster, in every direction,
// with the walk animation the game chose by itself.
//
// 1.7.9: the 1.7.8 log showed that the game's character update (the place the velocity and time ways hang on) never ran for the player, so the boost did nothing at all.
// The first way is now done in the game's main loop, right after every simulation, which is known to run: the character is moved on by (k - 1) times the step it just made.
// Three ways to make the character faster are built in because nothing could be run in the game to find out which one the game accepts:
//   3 nudge:    (main loop) the actor and its body are moved on by (k - 1) times the last step's motion          <- tried first
//   1 velocity: (character update, only when it really runs for the player) the physics body velocity is multiplied before the physics step uses it
//   2 time:     (character update, only when it really runs for the player) the update gets a longer time step
// The code measures the speed it really gets (average ft/s at a full stick, boosted against not boosted) and, in "auto", goes on to the next way when one does not work.
#pragma once

namespace boost {

enum Method { kOff = 0, kVelocity = 1, kTime = 2, kNudge = 3 };

struct Cfg {
  double K;            // wanted speed multiplier (1 = no boost)
  double upSec;        // seconds to ramp the boost in
  double downSec;      // ... and out
  double stickFull;    // samples count only at/above this push (0..1)
  double baseDefault;  // ft/s at a full stick when nothing was measured yet (1.7.7 log: 7.4 - 7.5)
  double settleSec;    // boosted seconds needed before the verdict
  double maxSec;       // after this many boosted seconds without a clear answer the weaker rule decides
  double capFtS;       // no write ever asks for more horizontal speed than this
};

inline Cfg make_cfg(int pct) {
  Cfg c;
  double k = (double)pct / 100.0;
  if (!(k >= 1.0)) k = 1.0;
  if (k > 3.0) k = 3.0;
  c.K = k;
  c.upSec = 0.30; c.downSec = 0.20; c.stickFull = 0.85; c.baseDefault = 7.4;
  c.settleSec = 1.2; c.maxSec = 3.0;
  c.capFtS = 7.6 * 3.0 + 2.0;
  return c;
}

struct State {
  double r;            // ramp 0..1
  double k;            // the multiplier now
  int method;          // in use now (kOff = given up, or the boost is off)
  int fixedMethod;     // the setting fixes the method (no automatic change)
  int pendingFixed;    // the setting fixes a character-update way that is not possible yet
  double trim;         // 1.7.9 nudge only: strength factor (0.25..1.6) that keeps the measured gain at the asked one (a game that feeds our nudge back into its velocity would run away)
  double aDist, aTime; // boosted samples collected for the next trim step
  int locked;          // the verdict "works" was reached for the method in use
  int verdict[4];      // per method: 0 not tried / unknown, +1 works, -1 does not
  int avail[4];        // per method: 1 = it can be used at all right now (the character-update ways only when that update really runs for the player)
  double gain[4];      // per method: last measured gain (boosted speed / plain speed)
  double baseDist, baseTime, bDist, bTime;   // plain / boosted full-stick walking
  long baseN, bN;
  long ticks, applied, switches;
  double lastGain;
};

inline void reset(State& s, int settingMethod) {
  State z = {};
  s = z;
  s.k = 1.0;
  s.trim = 1.0;
  s.avail[kVelocity] = 0; s.avail[kTime] = 0; s.avail[kNudge] = 1;   // the nudge is always possible; the others are switched on by the code that sees the character update run
  if (settingMethod == kNudge) { s.method = kNudge; s.fixedMethod = 1; }
  else { s.method = kNudge; s.fixedMethod = 0; }
  s.pendingFixed = (settingMethod == kVelocity || settingMethod == kTime) ? settingMethod : 0;
}

inline void set_avail(State& s, int m, int a) {
  if (m < kVelocity || m > kNudge) return;
  s.avail[m] = a ? 1 : 0;
  // a way the setting asked for becomes the way in use as soon as it is possible
  if (a && s.pendingFixed == m && s.method != m) { s.method = m; s.fixedMethod = 1; s.locked = 0; s.r = 0.0; s.k = 1.0; s.bDist = s.bTime = 0.0; s.bN = 0; }
}

// The way in use is no longer possible: go on to the next way that is (or off). Returns 1 when the way changed.
inline int ensure_available(State& s) {
  if (s.method == kOff || s.avail[s.method]) return 0;
  const int order[3] = {kNudge, kVelocity, kTime};
  int next = kOff;
  for (int i = 0; i < 3; ++i) if (s.avail[order[i]] && s.verdict[order[i]] == 0) { next = order[i]; break; }
  s.method = next; s.fixedMethod = 0; s.locked = 0; ++s.switches;
  s.bDist = s.bTime = 0.0; s.bN = 0; s.r = 0.0; s.k = 1.0;
  return 1;
}

// One step per player update. on = sprint is switched on and the left stick pushed. Returns the multiplier to use now.
inline double ramp(State& s, double dt, int on, const Cfg& c) {
  if (!(dt > 0.0) || dt > 0.25) dt = 0.011;
  if (on && s.method != kOff && c.K > 1.0) { s.r += dt / (c.upSec > 0.01 ? c.upSec : 0.01); if (s.r > 1.0) s.r = 1.0; }
  else { s.r -= dt / (c.downSec > 0.01 ? c.downSec : 0.01); if (s.r < 0.0) s.r = 0.0; }
  const double t = s.r * s.r * (3.0 - 2.0 * s.r);
  s.k = 1.0 + (c.K - 1.0) * t;
  return s.k;
}

// A boosted sample counts only once the ramp is done; a plain one only while no boost is in the ramp at all.
inline int settled(const State& s) { return s.r >= 0.97 && s.method != kOff; }

// dist = horizontal distance the actor moved over the last step (ft), dt = that step's game time (s, the plain one, not the scaled one), stick = left stick push (0..1)
inline void sample(State& s, double dist, double dt, double stick, const Cfg& c) {
  if (!(dt > 0.003) || dt > 0.25 || !(dist >= 0.0)) return;
  if (dist / dt > 45.0) return;   // a jump (level load, cut-scene cut), not a walk
  if (dist / dt < 0.35 * c.baseDefault) return;   // 1.7.9: standing against a wall or starting off: not a free full-stick walk (neither plain nor boosted counts)
  if (stick < c.stickFull) return;
  if (settled(s)) { s.bDist += dist; s.bTime += dt; ++s.bN; s.aDist += dist; s.aTime += dt; }
  else if (s.r <= 0.0) { s.baseDist += dist; s.baseTime += dt; ++s.baseN; }
}

inline double base_speed(const State& s, const Cfg& c) { return s.baseTime >= 0.6 ? s.baseDist / s.baseTime : c.baseDefault; }
inline double boosted_speed(const State& s) { return s.bTime > 0.0 ? s.bDist / s.bTime : 0.0; }

// After a "works" verdict the numbers keep coming; this says whether the speed has drifted far off (e.g. the game answered differently in another place).
inline int needs_recheck(const State& s, const Cfg& c) {
  if (!s.locked || s.bTime < 6.0) return 0;
  const double gain = boosted_speed(s) / base_speed(s, c);
  return gain < 1.0 + 0.2 * (c.K - 1.0);
}

// 0 = not enough data yet, +1 = the method makes the character faster as asked, -1 = it does not. Advances to the next method (auto only).
inline int judge(State& s, const Cfg& c) {
  if (s.method == kOff || c.K <= 1.0) return 0;
  if (s.locked) { if (!needs_recheck(s, c)) return 0; s.locked = 0; s.verdict[s.method] = 0; }   // it worked before and has stopped working: judge again
  if (s.bTime < c.settleSec) return 0;
  const double base = base_speed(s, c);
  if (!(base > 0.5)) return 0;
  const double gain = boosted_speed(s) / base;
  s.lastGain = gain; s.gain[s.method] = gain;
  const double worksAt = 1.0 + 0.55 * (c.K - 1.0), failsAt = 1.0 + 0.20 * (c.K - 1.0);
  int v = 0;
  if (gain >= worksAt) v = 1;
  else if (gain <= failsAt || s.bTime >= c.maxSec) v = -1;
  if (v == 0) return 0;
  s.verdict[s.method] = v;
  if (v > 0) { s.locked = 1; s.bDist = s.bTime = 0.0; s.bN = 0; return 1; }   // keep measuring afterwards for the log, but do not judge again
  if (s.fixedMethod) { s.bDist = s.bTime = 0.0; s.bN = 0; return -1; }
  const int order[3] = {kNudge, kVelocity, kTime};
  int next = kOff;
  for (int i = 0; i < 3; ++i) if (s.verdict[order[i]] == 0 && s.avail[order[i]]) { next = order[i]; break; }
  s.method = next; s.locked = 0; ++s.switches;
  s.bDist = s.bTime = 0.0; s.bN = 0; s.r = 0.0; s.k = 1.0; s.aDist = s.aTime = 0.0; s.trim = 1.0;
  return -1;
}

// 1.7.9: keeps the nudge from running away. Every 0.6 s of settled boosted walking: a gain more than 10 % above the wanted one (the game feeds the nudge back into its speed) turns the strength down;
// a gain more than 10 % below the wanted one, but clearly above plain walking (the game keeps only part of the nudge), turns it up. A gain near plain walking is left alone (more push does not help).
inline double adapt(State& s, const Cfg& c) {
  if (s.method != kNudge || s.aTime < 0.6) return s.trim;
  const double base = base_speed(s, c);
  const double gain = base > 0.5 ? (s.aDist / s.aTime) / base : 0.0;
  s.aDist = s.aTime = 0.0;
  if (!(gain > 0.0)) return s.trim;
  const double want = c.K;
  if (gain > want * 1.10) {
    double f = want / gain; f = f < 0.8 ? 0.8 : f; s.trim *= f;
  } else if (gain < want * 0.90 && gain > 1.0 + 0.30 * (want - 1.0)) {
    double f = want / gain; f = f > 1.25 ? 1.25 : f; s.trim *= f;
  }
  if (s.trim < 0.25) s.trim = 0.25;
  if (s.trim > 1.6) s.trim = 1.6;
  return s.trim;
}

// ---- the three ways, as pure functions ------------------------------------------------------------------------------------------------------------------------------------------
// velocity: the update set (vx, vz) for this step; scale it by k, never above capFtS horizontally
inline void vel_scale(double vx, double vz, double k, double capFtS, double* ox, double* oz) {
  double nx = vx * k, nz = vz * k;
  const double h2 = nx * nx + nz * nz;
  if (h2 > capFtS * capFtS && h2 > 0.0) {
    double h = h2; for (int i = 0; i < 24; ++i) h = 0.5 * (h + h2 / h);   // sqrt without libm
    const double f = capFtS / h; nx *= f; nz *= f;
  }
  *ox = nx; *oz = nz;
}
// nudge: (k - 1) times what the last step moved, never more than capFt in one step
inline void nudge_extra(double dx, double dz, double k, double capFt, double* ox, double* oz) {
  double ex = dx * (k - 1.0), ez = dz * (k - 1.0);
  const double h2 = ex * ex + ez * ez;
  if (h2 > capFt * capFt && h2 > 0.0) {
    double h = h2; for (int i = 0; i < 24; ++i) h = 0.5 * (h + h2 / h);
    const double f = capFt / h; ex *= f; ez *= f;
  }
  *ox = ex; *oz = ez;
}
// the step the game made on its own this tick: what the actor moved (md, ft; it includes what we added the tick before when the game kept it) minus what we added the tick before,
// never more than a plain full-stick step. 0 when nothing is left (blocked, or the game threw our nudge away: the measured gain then shows the way does not work).
inline double plain_step(double md, double lastNudge, double dt, const State& s, const Cfg& c) {
  double p = md - lastNudge;
  const double cap = base_speed(s, c) * dt * 1.15;
  if (p > cap) p = cap;
  return p > 0.0 ? p : 0.0;
}
// time: the step the update gets
inline double time_step(double dt, double k) { return dt * (k < 1.0 ? 1.0 : k > 3.0 ? 3.0 : k); }

}  // namespace boost
