#pragma once
namespace boson {
// A blocked grip must be released before it can fire again (menu, wheel,
// tracking loss or a hand at the pack must never turn into a delayed shot).
struct Grip {
  int heldBefore = 1, firing = 0;
  int update(int held, int allowed, int tracked) {
    if (!tracked) { heldBefore = 1; firing = 0; return 0; }
    if (!held) { heldBefore = firing = 0; return 0; }
    if (!heldBefore) firing = allowed;
    else if (!allowed) firing = 0;
    heldBefore = 1;
    return firing;
  }
};

}
