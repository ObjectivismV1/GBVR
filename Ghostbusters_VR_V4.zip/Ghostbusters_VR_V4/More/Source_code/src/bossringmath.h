// 1.7.106 health ring on bosses: the pure rules (no game memory), tested in tests/test_bossring.cpp.
//
// The game's own enemy health ring (CEnemyHealthBar) shows on the enemy the player has "focus" on. The headset view never gets a lock, so the probe answers the ring's
// two questions (where is the focus, how healthy is it) for the enemy you look at (damage.cpp, ring pick). Until 1.7.105 that pick only took enemies the game says can be
// locked onto (virtual +0x360) and only within 60 m of the bounds centre, and a boss's body is neither (a huge body whose centre is far off the line of sight, and not
// lockable except at its weak points). These rules let a boss be picked, by the size of its body instead of its centre.
//
// Head space: x right, y up, z forward, the same unit as the bars (feet divided by the world scale), centre = the bounds centre, rad = the bounds radius.
#pragma once
#include "vmath.h"

namespace bossring {

// the classes that are bosses, by the names in the game's class table (damage.cpp kEnemies). Not a guess at more: a class missing here is still taken when its maximum health is big.
inline int name_is_boss(const char* n) {
  if (!n) return 0;
  static const char* const kBoss[] = {"CStayPuftBoss", "COrreryBoss", "CGolem", "CGolemBase", "CAzetlor", "CLibrarian", "CSpiderWitch", "CArchitect", "CNightmare", "CBipedLarge"};
  for (unsigned i = 0; i < sizeof(kBoss) / sizeof(kBoss[0]); ++i) {
    const char* a = n; const char* b = kBoss[i];
    while (*a && *a == *b) { ++a; ++b; }
    if (!*a && !*b) return 1;
  }
  return 0;
}
// the game's tweak data (README 1.7.24): ordinary ghosts have 150 health, the Architect 1600, the Chairman 1000
inline int big_health(double maxHealth) { return maxHealth >= 1000.0; }
inline int is_boss(const char* name, double maxHealth) { return name_is_boss(name) || big_health(maxHealth); }

// how far the body (a sphere) is from where you look, in degrees: 0 while the gaze passes through it; the angle to the near edge otherwise. 180 = behind you.
inline double body_angle_deg(const double* c, double rad) {
  const double hy = vm::dsqrt(c[0] * c[0] + c[1] * c[1]);
  const double d = vm::dsqrt(c[0] * c[0] + c[1] * c[1] + c[2] * c[2]);
  if (!(d > 1e-6) || !(c[2] > 0.0)) return 180.0;
  const double ang = vm::datan2(hy, c[2]) * 57.29577951308232;
  double half = 0.0;
  if (rad > 0.0 && rad < d) half = vm::datan2(rad, vm::dsqrt(d * d - rad * rad)) * 57.29577951308232;
  else if (rad >= d) return 0.0;   // inside the sphere
  const double e = ang - half;
  return e < 0.0 ? 0.0 : e;
}

inline double smooth01(double t) { t = t < 0.0 ? 0.0 : (t > 1.0 ? 1.0 : t); return t * t * (3.0 - 2.0 * t); }

// where the ring sits on the body: on the centre while the centre is in front of you (up to 20 degrees off), sliding to the point of the body you are looking at as the
// centre leaves the view (by 60 degrees it is fully the gaze point). The gaze point is where the line of sight is closest to the centre, held inside 0.8 of the radius.
// Returns 0 when the body is behind you (nothing to put a ring on).
inline int ring_point(const double* c, double rad, double* out) {
  if (!(c[2] > 0.3)) return 0;
  const double hy = vm::dsqrt(c[0] * c[0] + c[1] * c[1]);
  const double ang = vm::datan2(hy, c[2]) * 57.29577951308232;
  double gx = 0.0, gy = 0.0, gz = c[2];   // the nearest point of the gaze line (the z axis) to the centre
  const double vx = gx - c[0], vy = gy - c[1], vz = gz - c[2];   // from the centre to that point (vz = 0)
  const double vl = vm::dsqrt(vx * vx + vy * vy + vz * vz);
  const double keep = 0.8 * (rad > 0.0 ? rad : 0.0);
  if (vl > keep && vl > 1e-9) { const double s = keep / vl; gx = c[0] + vx * s; gy = c[1] + vy * s; gz = c[2] + vz * s; }
  const double w = smooth01((ang - 20.0) / 40.0);
  out[0] = c[0] + (gx - c[0]) * w; out[1] = c[1] + (gy - c[1]) * w; out[2] = c[2] + (gz - c[2]) * w;
  return 1;
}

// is the boss really there? The game keeps enemies that are not in the level yet in its list at full health, and a boss is far bigger than any of them, so the ring
// waits for a sign that it is there.
// 1.7.116: until 1.7.115 "the game drew it in the last frames" or "there is a clear line to it" were enough for a named boss. They are not signs of anything: the game's drawn counter says
// "drawn" for bodies that are not in the level yet (the unspawned floaters did the same) and the open sky gives a clear line. The report showed the ring floating at the end of the roof,
// 85 m away at 100 %, before Stay Puft had appeared. Now only a sign that cannot be true before the boss is there counts:
//   engaged  = it lost health, or it is the capture stream's held target, within the last seconds (the caller keeps that latch: engage_s()), or
//   lockOk + drawnRecently = the game's own can-lock test says yes (it says no to everything that is not active) AND the game draws it.
// A body that is only "big" (1000+ health, not a named boss) is often an enemy that sits in another room, out of the level (the 1.7.108 report): its second way also needs strictLine
// (a clear line from the headset itself, no fallback points).
inline int present(int engaged, int lockOk, int drawnRecently, int named = 1, int strictLine = 0) {
  if (engaged) return 1;
  if (!(lockOk > 0 && drawnRecently > 0)) return 0;
  return named || strictLine > 0;
}
// how long a boss stays "engaged" after the last hit / hold (seconds): a fight has pauses (he stomps, you dodge), the ring should not blink out in them
inline double engage_s() { return 20.0; }
// 1.7.142: a named boss that MOVES only counts as there (ring before the first hit) while it is close. The 1.7.119 rule had no range: in the Times Square escort
// ("Escort Ecto-1 in pursuit of Stay Puft") he walks 84-130 m ahead and cannot be fought, and a YouTube review video showed his full ring on his chest the whole
// way (14:27-16:48). The roof phase it was made for logs 43-44 m; the fight itself is engaged by hits and the fight scene anyway.
inline double move_range_m() { return 60.0; }
inline int moving_counts(int moving, double distM) { return moving && distM >= 0.0 && distM <= move_range_m() ? 1 : 0; }
// the hit test for a boss, over a window instead of frame to frame: a boss has 100 health in all and the stream takes little of it per frame, so the 0.4 % per frame the ghosts' test needs can be
// missed. fracThen = its health (0..1) 0.4 s ago, fracNow = now. Health that went UP (a restart, a stage change) clears the latch: the boss is treated as a fresh one.
inline int lost_health(double fracThen, double fracNow) { return fracThen - fracNow > 0.002; }
inline int healed(double fracThen, double fracNow) { return fracNow - fracThen > 0.02; }

// the ring's size for a boss: the same apparent size at any distance (a boss is far larger than a ghost, a ring the size of the boss would fill the view)
inline double ring_radius(double distHead, double floorHead) {
  const double r = distHead * 0.075;
  return r < floorHead ? floorHead : r;
}

// head space <-> world feet, the same maths as damage.cpp's to_head (view9: the headset's axes, row r = axis r in world; hc: head centre in world feet; inv = 1 / feet per metre).
inline void world_to_head(const float* view9, const float* hc, double inv, const float* w, double* o) {
  const double d[3] = {(double)w[0] - hc[0], (double)w[1] - hc[1], (double)w[2] - hc[2]};
  for (int c = 0; c < 3; ++c) o[c] = ((double)view9[0 * 3 + c] * d[0] + (double)view9[1 * 3 + c] * d[1] + (double)view9[2 * 3 + c] * d[2]) * inv;
}
inline void head_to_world(const float* view9, const float* hc, double inv, const double* h, float* w) {
  for (int r = 0; r < 3; ++r) w[r] = (float)((double)hc[r] + ((double)view9[r * 3 + 0] * h[0] + (double)view9[r * 3 + 1] * h[1] + (double)view9[r * 3 + 2] * h[2]) / inv);
}

// how far away a boss still gets a ring (head units, metres): its body can be a hundred metres tall
inline double max_range_m() { return 450.0; }

// the fallback: the probe's own ring shows only when the game's ring has not been on the screen for a while although there is something to show it on.
// nowMs: a clock in ms; ogMs: when the game's ring was last drawn on screen (0 = never); sinceMs: when the wait began (0 = not waiting); returns 1 = draw the probe's ring.
// graceMs avoids a flash while the game's ring is still fading in.
inline int fallback_due(int haveFocus, long long nowMs, long long ogMs, long long* sinceMs, long long recentMs, long long graceMs) {
  if (!haveFocus) { *sinceMs = 0; return 0; }
  if (ogMs && nowMs - ogMs <= recentMs) { *sinceMs = 0; return 0; }
  if (!*sinceMs) *sinceMs = nowMs;
  return nowMs - *sinceMs >= graceMs;
}

}  // namespace bossring
