// 1.7.29 "calm walking": pure math (tests/test_calm.cpp).
//
// While the character walks, the game's animation moves the eyes a little against the pelvis (the walk's head bob, the sway of the shoulders, small jumps when the animation
// steps). The eye match (armcore.h, torso_pass step 4) puts the avatar's eyes exactly at the headset's eye every frame, so the BODY (pelvis, chest, shoulders, the pack and the
// hose on them) takes every one of those small moves in your head's frame: it bobs and shakes while the head stays calm. Here the eye-to-pelvis offset is low-passed instead: the
// pelvis stays where the smoothed offset puts it, the head (which is hidden, a child of the chest) slides the small remainder so the eyes still sit on the headset's eye.
//   off  = the avatar's eye minus its pelvis, in the world (feet), after the lean and the head turn
//   out  = the smoothed offset (follows off with time constant tau, never more than maxLag behind it)
//   d    = off - out: the small remainder the head slides (|d| <= maxLag)
// A jump of the offset (a different animation, a roll, a cutscene) is taken at once, and the filter restarts after a long gap.
#pragma once
#include "vmath.h"

namespace calm {

struct Filter { double lp[3]; int has; };

inline void reset(Filter* f) { f->has = 0; f->lp[0] = f->lp[1] = f->lp[2] = 0.0; }

inline double len3(const double* a) { return vm::dsqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); }

// 1 = smoothed (out lags behind off by at most maxLagFt), 0 = restarted (out = off).
inline int step(Filter* f, const double* off, double dtS, double tauS, double maxLagFt, double snapFt, double* out) {
  int finite = 1;
  for (int i = 0; i < 3; ++i) if (!vm::is_finite_f((float)off[i])) finite = 0;
  if (!finite) { reset(f); out[0] = out[1] = out[2] = 0.0; return 0; }
  if (!(tauS > 0.001) || !(dtS >= 0.0) || dtS > 0.25 || !f->has) {   // dtS 0 = the same frame again: hold (below), no step
    for (int i = 0; i < 3; ++i) f->lp[i] = out[i] = off[i];
    f->has = (tauS > 0.001) ? 1 : 0;
    return 0;
  }
  double diff[3] = {off[0] - f->lp[0], off[1] - f->lp[1], off[2] - f->lp[2]};
  if (len3(diff) > snapFt) { for (int i = 0; i < 3; ++i) f->lp[i] = out[i] = off[i]; return 0; }
  const double a = dtS / (tauS + dtS);
  for (int i = 0; i < 3; ++i) f->lp[i] += a * diff[i];
  double lag[3] = {off[0] - f->lp[0], off[1] - f->lp[1], off[2] - f->lp[2]};
  const double ll = len3(lag);
  if (ll > maxLagFt && ll > 1e-9) { const double k = maxLagFt / ll; for (int i = 0; i < 3; ++i) f->lp[i] = off[i] - lag[i] * k; }
  for (int i = 0; i < 3; ++i) out[i] = f->lp[i];
  return 1;
}

// The "shake" of a sampled position series: the second difference (feet) at the newest sample, the same number the hand-feel log uses (a steady glide gives ~0, a tremble gives a lot).
inline double second_diff(const double* p0, const double* p1, const double* p2) {
  double d[3] = {p2[0] - 2.0 * p1[0] + p0[0], p2[1] - 2.0 * p1[1] + p0[1], p2[2] - 2.0 * p1[2] + p0[2]};
  return len3(d);
}

}  // namespace calm
