#pragma once
#include <stdint.h>
namespace capbridge {
struct Result { uint32_t mask; bool owned; bool added; bool removed; };
inline Result step(uint32_t mask, bool held, bool owned) {
  const bool added = held && !(mask & 0x40u);
  const bool removed = !held && owned;
  if (added) mask |= 0x40u;
  if (removed) mask &= ~0x40u;
  return {mask, held ? (owned || added) : false, added, removed};
}
}
