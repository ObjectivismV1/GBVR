// 1.7.38 chest camera (the PC window's own view): pure maths, no game access, so tests/test_chestcam.cpp can check it.
#pragma once
#include "vmath.h"
namespace chest {
static const double kUpLimit = 5.0 * 3.14159265358979323846 / 180.0;      // looks up at most this much (the head above the lens stays out of the picture)
static const double kDownLimit = -30.0 * 3.14159265358979323846 / 180.0;  // and down this much

inline double clamp_pitch(double p, int* limited) {
  if (p > kUpLimit) { if (limited) *limited = 1; return kUpLimit; }
  if (p < kDownLimit) { if (limited) *limited = 1; return kDownLimit; }
  return p;
}
inline double wrap_pi(double a) { while (a > vm::kPi) a -= 2.0 * vm::kPi; while (a < -vm::kPi) a += 2.0 * vm::kPi; return a; }
// one smoothing step toward a target angle (about tau seconds of smoothing); dt <= 0 or huge = jump
inline double smooth_angle(double cur, double target, double dt, double tau) {
  if (!(dt > 0.0) || dt > 0.5) return target;
  return cur + (dt / (tau + dt)) * wrap_pi(target - cur);
}
// engine view matrix (row-major 3x3, columns right, up, forward) for a yaw (forward = (sin yaw, ., cos yaw)) and pitch (up positive), horizon level
inline void basis(double yaw, double pitch, float* v) {
  double sy, cy, sp, cp;
  vm::dsincos(yaw, &sy, &cy);
  vm::dsincos(pitch, &sp, &cp);
  v[0] = (float)cy;          v[1] = (float)(-sp * sy); v[2] = (float)(cp * sy);
  v[3] = 0.0f;               v[4] = (float)cp;         v[5] = (float)sp;
  v[6] = (float)(-sy);       v[7] = (float)(-sp * cy); v[8] = (float)(cp * cy);
}
// lens position: below the head centre and behind it along the body's heading
inline void position(const float* head, double bodyYaw, double downFt, double backFt, float* out) {
  double s, c;
  vm::dsincos(bodyYaw, &s, &c);
  out[0] = (float)((double)head[0] - s * backFt);
  out[1] = (float)((double)head[1] - downFt);
  out[2] = (float)((double)head[2] - c * backFt);
}
}  // namespace chest
