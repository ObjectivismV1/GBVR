// 1.7.26 cutscene guard: "sometimes the rigs get messed up in in-game cutscenes". In a cutscene the game animates the character (walks it,
// turns it, gestures); the probe kept pulling the arms to the controllers, the body to the head and the gun to the hand against that
// animation. This turns the probe's rig changes down to nothing while the game is in charge, and eases them back in afterwards.
// Input per camera frame: is the game moving the character by force (forcedmath.h), did the character jump (a cut), and the time step.
// Output: blend 0..1 (1 = the game is in charge: the probe leaves body, arms and gun alone; 0 = normal play).
// A short knock-back (ghost hit, under about half a second) must NOT let go of the gun: the guard only engages after the game has
// moved the character for engageSec in a row. A jump (cut, respawn, level load) engages at once.
// Pure math, no libm; unit-tested in tests/test_cine.cpp.
#pragma once

namespace cine {

struct Guard {
  double forcedSec;     // how long the game has been moving the character in a row
  double holdSec;       // after the last trigger the guard stays on this much longer
  double blend;         // 0..1 smoothed
  int active;           // target state: 1 = the game is in charge
  int events;           // how many times the guard engaged
  int byMove, byJump;   // ... caused by a long forced move / by a jump
  double activeTotal;   // seconds with the guard engaged
  double longest;       // longest engaged stretch, seconds
  double cur;           // current engaged stretch, seconds
  double engageSec;     // forced move needed before the guard engages
  double holdAfterSec;  // stay engaged this long after the game lets go
  double jumpHoldSec;   // ... after a jump
  double riseSec;       // blend 0 -> 1
  double fallSec;       // blend 1 -> 0
  int lastTeleports;
  int jumpEngages;      // 1.7.156: 1 = a jump engages the guard (the 1.7.26 rule); 0 = only a long forced move does

  void reset() {
    forcedSec = holdSec = blend = 0; active = 0; events = byMove = byJump = 0; activeTotal = longest = cur = 0; lastTeleports = 0;
    engageSec = 0.55; holdAfterSec = 0.6; jumpHoldSec = 1.5; riseSec = 0.12; fallSec = 0.7; jumpEngages = 1;
  }

  // forced: forcedmath's state now; teleports: its running count of jumps; dt: seconds since the last call (a tiny dt = second eye of a pair, ignored).
  // Returns the blend.
  double update(int forced, int teleports, double dt) {
    if (!(dt > 0.003)) return blend;
    if (dt > 0.5) dt = 0.5;
    int trigger = 0, jump = 0;
    if (teleports != lastTeleports) { if (teleports > lastTeleports && jumpEngages) jump = 1; lastTeleports = teleports; }
    if (forced) forcedSec += dt; else forcedSec = 0;
    if (jump) { trigger = 1; if (holdSec < jumpHoldSec) holdSec = jumpHoldSec; if (!active) ++byJump; }
    if (forced && forcedSec >= engageSec) { trigger = 1; if (holdSec < holdAfterSec) holdSec = holdAfterSec; if (!active && !jump) ++byMove; }
    if (trigger) {
      if (!active) { active = 1; ++events; cur = 0; }
    } else if (active) {
      holdSec -= dt;
      if (holdSec <= 0 && !forced) { active = 0; holdSec = 0; }
    }
    if (active) { activeTotal += dt; cur += dt; if (cur > longest) longest = cur; }
    if (active) { blend += dt / riseSec; if (blend > 1.0) blend = 1.0; }
    else { blend -= dt / fallSec; if (blend < 0.0) blend = 0.0; }
    return blend;
  }
};

// Mix of two matrices (16 floats): the probe's placement p and the game's own placement g. blend 0 = p, 1 = g.
inline void mix16(const float* p, const float* g, double blend, float* out) {
  const float k = (float)(blend < 0 ? 0.0 : blend > 1 ? 1.0 : blend), j = 1.0f - k;
  for (int i = 0; i < 16; ++i) out[i] = p[i] * j + g[i] * k;
}

}  // namespace cine
