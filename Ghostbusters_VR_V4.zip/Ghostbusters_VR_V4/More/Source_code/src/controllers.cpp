// 0.33 Quest / Touch controllers.
//
// Render thread (inside the game's Present, right after the headset pose):
// controllers_poll() reads both controllers from SteamVR, turns them into the
// Xbox pad state the game already understands (padmath.h) and into hand poses
// in the same engine-local frame as the head, and publishes one snapshot.
// Game thread: the XInput bridge (xinput_bridge.cpp) and the aim hook read
// that snapshot; they never call SteamVR. Rumble goes the other way: the game's
// vibration request is stored here and played as a haptic pulse by the next poll.
#include "knockmath.h"
#include "gbvr.h"

#if GBVR_HEADTRACK
#include "vmath.h"
#include "vr_pose.h"
#include "padmath.h"
#include "ctlprofile.h"
#include "handmath.h"
#include "aimmath.h"
#include "weightmath.h"
#include "hapticmath.h"
#include "bodymath.h"
#include "vmenumath.h"
#include "fightmath.h"
#include "gearmath.h"
#include "ctlmap.h"
#include "bosonmath.h"
#include "gungatemath.h"
#include "followmath.h"

extern volatile LONG g_dartHitsSeen;   // 1.7.221 (damage.cpp)
namespace {
struct Snap {
  uint32_t seq;
  int64_t qpc;
  int validL, validR;
  int wheelOpen, wheelSel, wheelPicked, wheelPickLocked, trapHeld; float stickX, stickY;   // 0.77 (0.78: wheelOpen = drawn, open or closing)
  float wheelOpenT, wheelFlash, wheelCurX, wheelCurY, wheelHov[10], wheelPose[12];           // 0.78
  pad::State pad;
  float rotL[9], posL[3], rotR[9], posR[3];
  uint64_t pressedL, pressedR;
  float poseL[12], poseR[12];   // 0.34: raw tracking-space poses (for drawing the hands)
  float trigL, trigR;
  float gripAnaL, gripAnaR; int thumbTL, thumbTR, trigTL, trigTR;   // 1.7.111 analog grip, thumb / trigger touch
  int holstered;                // 0.38
  int wandValid, wandTwo;       // 0.51: the weighted wand pose below is usable / held in two hands
  float wandPose[12];           // 0.51: tracking space (OpenVR 3x4)
  float wandRot[9], wandPos[3]; // 0.51: the same in engine-local axes (aim)
};
SRWLOCK g_lock = SRWLOCK_INIT;
Snap g_snap;
int g_have;
volatile LONG g_rumbleL, g_rumbleR;
volatile int64_t g_rumbleQpc;
struct Stats {
  volatile LONG polls, noHand, published, haptics, rumbleSets, packTouches, ventStarts, ventPolls;
  volatile LONG rumbleNonZero, rumbleMax, rumbleLast;
  // 0.51 gun weight statistics (render thread)
  volatile LONG wN[2], wLagSumX100[2], wLagMaxX100[2], wEngage, wFireN[2], wFireLagSumX100[2], wFatigueMaxX100;
  volatile LONG wSag1X100, wSag2X100;
  volatile LONG wPkeN, wPkeLagSumX100, wPkeLagMaxX100, wPkeLagOverX100;   // 0.95 the PKE's own weight: polls, mean / max lag (1/100 degree), polls beyond 5 degrees
  volatile LONG wStrainMaxX100, wOneFireN, wOneFireSwaySumX100, wOneFireSwayMaxX100, wOneFireRecMaxX100;   // 0.95 one-handed shots: strain, mean / max sway, max climb
  volatile LONG wPosN, wPosLagSumMm, wPosLagMaxMm, wPosCapped;   // 0.58 position lag of the heavy gun (millimetres)
  volatile LONG slamSwings, slamSwingsNoMeter, slamCaptureSamples, slamPressSamples, slamMaxSpeedX100, slamMaxDownX100;   // 0.76 slam swing
  uint64_t seenL, seenR;      // every button bit ever pressed (diagnosis of the mapping)
  float maxTrig[2];
  int lastValidL, lastValidR;
} g_cs;
volatile LONG g_leftApplied;   // 1.7.181: left-handed as APPLIED (set in the poll that swaps the controllers)
volatile LONG g_moveMag;   // 1.7.5: the left stick push x1000
// 1.7.85 INPUTFLOW: what the controller layer saw / delivered since the last log line
static volatile LONG g_flowPadHit, g_flowPadMiss, g_flowButtons, g_flowStick;
static volatile uint64_t g_flowRaw;
volatile int64_t g_sprintWantQ;   // 1.7.6: when the probe last wanted the game to sprint (sprint on + left stick pushed)
long g_sprintWantFrames, g_sprintYieldFrames, g_walkCapFrames, g_walkCapMax;
long g_walkRotFrames, g_walkRot10, g_walkRot35, g_walkRot90, g_walkRotStale; int g_walkRotLogged; double g_walkRotSumDeg, g_walkRotMaxDeg;   // 1.7.8 walk where the head points
long g_menuOpens, g_menuOldOnly, g_menuOldFrames, g_menuZoneFrames;   // 1.7.7 menu gesture counters   // 1.7.6 counters for the log
volatile LONG g_turnUserMag, g_turnBlocked;                       // 1.5: your own right-stick push (x1000), and 1 while turning makes no sense
long g_snapFlicks, g_snapSent, g_pushFrames, g_snapBlocked;
long g_smPolls, g_smTurnPolls; double g_smDegTotal; int64_t g_smQpc;   // 1.7.81 smooth turn: polls looked at, polls that turned, degrees asked, last poll time        // 1.5 counters for the log
follow::Flick g_flick;

pad::Holster g_holster;
alignas(8) static volatile LONG64 g_reloadInputQ;
alignas(8) static volatile LONG64 g_altInputQ;   // 1.7.226: the last poll with the left trigger down and a gun in hand
alignas(8) static volatile LONG64 g_trapInputQ;   // 1.7.173: when the game's trap throw was last asked for
static gungate::DrawMemory g_gunDrawMemory;   // 1.7.117: drawn / holstered as the player left it, across level and cut-scene gates
static gungate::Gate g_gunGate;   // 1.7.99: may the player hold a gun right now? (gungatemath.h)
fight::Swing g_swing;   // 0.76 (kept for its tests; 0.77 uses g_sweep)
gear::Sweep g_sweep;    // 0.77 slam by sweeping the gun any way
gear::PullDir g_pull;   // 1.7 which way the gun hand is pulling
gear::TrigSlam g_trigSlam;   // 1.7 slam on the left trigger
struct { long samples, hotFrames, pressFrames, flickFrames, buzzed, capHeldPolls, capForcedPolls, releaseFrames, releasedHeld; int logged; double lastLen; } g_ts;   // 1.7 slam counters
struct { int prevClick, latched; double clickAge, idleSecs; long taps, latchOns, latchOffs, latchFrames, holdFrames, stickOffs; int64_t q; int logged; } g_sp;   // 1.7 sprint
gear::Wheel g_wheel;    // 0.77 weapon wheel (0.78: Alyx style, opened by holding the right A button)
gear::Trap g_trap;      // 0.77 ghost trap on the left hip (0.78: taken with the left X button)
gear::TapHold g_aHold;  // 0.78 right A: tap = Interact, hold = weapon wheel
gear::TapHold g_yHold;  // 0.98 left Y: tap = the game's Y (PKE), hold 0.3 s = the D layer (right stick = D-pad, stick click = Vent, B = HUD, A = Select)
long g_jumpSprintFrames;
long g_yTaps, g_yClaims, g_layerFrames, g_layerDpad, g_layerVent, g_layerHud, g_layerSelect, g_sprintFrames, g_altFireFrames; int g_layerPrevOn;
float g_wPose[12]; double g_wOrigin[3]; int g_wPoseOk;   // 0.78 where the wheel stands and where the right hand was when it opened
double g_wheelDtMs = 11.0;
int64_t g_trapQpc, g_wheelQpc, g_sweepQpc;
int64_t g_xFromQ, g_xUntilQ, g_yFromQ, g_yUntilQ, g_dpadUntilQ; unsigned g_dpadMask;
struct { int want; int64_t nextQ; int tries; int forced; } g_pend;   // 0.93: a PKE / PRO pick that is checked, and retried if the game did not do it unsigned g_dpadMask;      // pulses the wheel / trap send as pad presses
int g_trapSuppressBtn, g_prevWheelSel = -1;
long g_aTaps, g_aClaims, g_xReplays, g_ctlMapLogged;
volatile int64_t g_fireHoldQ;   // 1.7.177
float g_throwRot[9]; volatile int64_t g_throwAimUntilQ;   // 0.77: after a trap throw the game aims where the hand threw for a moment
struct GearStats { long wheelOpens, wheelChosen, wheelCancel, wheelTaps, items, dpad, notch, notchPosted, trapGrabs, trapThrows, trapPutbacks, sweeps, dpadSeen, handPicks, pkeByY; double trapMaxSpeed, trapLastSpeed; } g_gs;
weight::State g_wState;
weight::PosState g_pState;   // 0.58 the gun's position inertia
int64_t g_wPrevQpc;
int g_prevTwo, g_prevRt, g_prevLt, g_helloDone;
uint64_t g_prevPressL, g_prevPressR;
// 0.45 pack zone (metres, head yaw frame): centre this far behind and below the head
const double kPackBackM = 0.22, kPackDropM = 0.15, kPackRadiusM = 0.26;
int g_ventIn[2];
int g_ventOn;
long g_dartStarts, g_dartPolls;   // 1.7.41

pad::Config config() {
  pad::Config c;
  c.deadzonePct = (int)g_ctl.stickDeadzonePct;
  c.twoHandFire = g_ctl.twoHandFire != 0;
  c.dpadWithGrip = 1;
  c.ltCapture = 0;   // 1.7.57: legacy only; the physical left trigger is always the game's LT / alternate fire
  c.sprintClick = g_ctl.sprintClick != 0;   // left click = Sprint; normal right click = Capture / wrangle
  return c;
}

pad::Hand to_hand(const GbvrHandRaw& r) {
  pad::Hand h;
  h.valid = r.valid; h.away = 0; h.layer = 0;
  h.stickX = r.stickX; h.stickY = r.stickY; h.trigger = r.trigger; h.pressed = r.pressed;
  return h;
}

void note_buttons(const char* name, uint64_t now, uint64_t* seen) {
  uint64_t fresh = now & ~*seen;
  if (!fresh) return;
  *seen |= fresh;
  for (int b = 0; b < 64; ++b)
    if ((fresh >> b) & 1u) log_line("CONTROLLERS first press of button id %d on the %s controller (A=7, menu=1, grip=2, stick=32, trigger=33)", b, name);
}
}  // namespace

void controllers_flow_take(ControllersFlow* f) {
  f->polls = g_cs.polls; f->published = g_cs.published; f->noHand = g_cs.noHand;
  f->padHit = InterlockedExchange(&g_flowPadHit, 0); f->padMiss = InterlockedExchange(&g_flowPadMiss, 0);
  f->padButtons = (unsigned)InterlockedExchange(&g_flowButtons, 0); f->stick = (int)InterlockedExchange(&g_flowStick, 0);
  f->rawButtons = g_flowRaw; g_flowRaw = 0;
  f->validL = g_cs.lastValidL; f->validR = g_cs.lastValidR;
}
long g_twoFlips, g_slimeLtEdges;   // 1.7.74 (logged by engine_hooks)

static body::Calib g_calib;
static int64_t g_calibQpc;
static double g_calibTickMs;

static struct { long swaps; int lastHanded; int logged; long seatedRecenters; int lastSeated; int famSeen[2]; } g_hnd;
void controllers_poll() {
  {   // 1.7.19: left-handed play, seated play and the controller family are looked at every poll, even before the pad layer runs
    vr_capi_set_compat((int)g_ctl.controllerLayout, (int)g_ctl.stickAxisForce);   // 1.7.117: the settings-file controller overrides (cheap, every poll)
    if (g_hnd.lastHanded != (int)g_ctl.leftHanded) {
      g_hnd.lastHanded = (int)g_ctl.leftHanded; ++g_hnd.swaps;
      vr_capi_set_handed((int)g_ctl.leftHanded);
      InterlockedExchange(&g_leftApplied, (LONG)g_ctl.leftHanded);   // 1.7.181: the value the game thread and the render thread use: it flips together with the controller swap
      { engine_holds_reset("left-handed play was switched"); g_wState.reset(); g_sp.latched = 0; g_sp.prevClick = 0; }   // 1.7.173 "float happened after switching between modes": nothing learned with the other hand is kept
      log_line("HANDED left-handed play is %s: the physical %s controller is now the gun hand (everything - gun, fingers, trap, PKE, menu pointer, buzz - follows)", g_ctl.leftHanded ? "ON" : "off", g_ctl.leftHanded ? "LEFT" : "RIGHT");
    }
    if (g_hnd.lastSeated != (int)g_ctl.seated + 1) {
      const int firstPoll = (g_hnd.lastSeated == 0);
      g_hnd.lastSeated = (int)g_ctl.seated + 1;   // 1.7.180: a saved seated=1 on the first poll (game loading) does not arm the 4 s recentre
      if (g_ctl.seated) { if (!firstPoll) InterlockedExchange(&g_ctl.seatRecenterAt, (LONG)(GetTickCount() + 4000u) | 1); log_line("SEATED seated play is ON: sit the way you will play; your view is recentered 4 seconds from now (the menu can stay open); head drops no longer crouch the body; seat height %d cm", (int)g_ctl.seatCm); }
      else { if (!firstPoll) InterlockedExchange(&g_ctl.seatRecenterAt, (LONG)(GetTickCount() + 4000u) | 1); log_line("SEATED seated play is off (standing: head drops crouch the body again; the view is recentered 4 seconds from now, stand the way you will play)"); }
    }
    const LONG due = g_ctl.seatRecenterAt;
    if (due && (LONG)(GetTickCount() - (DWORD)(due & ~1)) >= 0) {
      InterlockedExchange(&g_ctl.seatRecenterAt, 0); InterlockedExchange(&g_ctl.recenterRequest, 1); ++g_hnd.seatedRecenters;
      log_line("SEATED recentered where you are now (%s, seat height %d cm)", g_ctl.seated ? "seated" : "standing", (int)g_ctl.seatCm);
    }
  }
  if (!g_ctl.padEnabled || !vr_capi_is_scene()) return;
  InterlockedIncrement(&g_cs.polls);
  GbvrHandRaw l, r;
  vr_capi_set_hand_predict_ms((int)g_ctl.handPredictMs);
  vr_capi_hand(0, &l);
  vr_capi_hand(1, &r);
  for (int fh = 0; fh < 2; ++fh) {   // 1.7.19: which controller family each hand is (logged once per change); Touch-style is the default layout, Index / Windows MR read their thumb stick from the right axis in the OpenVR layer
    char fn[48]; const int fam = vr_capi_family(fh, fn, (int)sizeof(fn));
    if (fam != g_hnd.famSeen[fh] && (fh ? r.valid : l.valid)) {
      g_hnd.famSeen[fh] = fam;
      static const char* const kFam[6] = {"unknown (read like Touch-style; the stick axis is found from SteamVR's axis types / which axis moves)", "Touch-style (Quest / Rift / Pico / Focus 3 / Frame: the default layout)", "Valve Index (stick on axis 3 or 0; the edge-push \"click\" is dropped; a quick right-grip tap = A in a level)", "Vive wand (the trackpad is the stick; clicking the lower pad = A, elsewhere = stick click; menu button = B/Y)", "Windows Mixed Reality (thumb stick on axis 2; trackpad click = A)", "other (stick axis found from SteamVR's axis types / which axis moves; a trackpad-only controller gets A on the lower pad)"};
      int pk[5], look = 0;
      vr_capi_axis_peaks(fh, pk, &look);
      log_line("CONTROLLERFAMILY the %s hand is \"%s\" (type|maker): %s%s", fh ? "logical RIGHT (gun)" : "logical LEFT", fn[0] ? fn : "?", kFam[fam >= 0 && fam < 6 ? fam : 0],
               look ? " - NOT made by Valve: an Index look-alike (Virtual Desktop \"Emulate Index Controllers\" or another driver); the thumb stick is read from axis 3 OR axis 0, whichever is pushed further" : "");
      {   // 1.7.88: Valve's Steam Frame controllers (type "frame_controller"): SteamVR hands a game without Frame bindings the Touch layout
        const char* k = "frame_controller"; int hit = 0;
        for (const char* a = fn; *a && !hit; ++a) { int j = 0; while (k[j] && a[j] == k[j]) ++j; hit = !k[j]; }
        if (hit) log_line("ENVCHECK Steam Frame controllers: SteamVR gives a game without Frame bindings the Oculus Touch layout (Valve's documented remap; a player reported the same): the D-pad buttons act as the face buttons (left D-pad up / left / right = Y: PKE, menu hold; down = X, the ghost trap), on the right hand X / Y / B act as B (jump), the bumpers act as extra triggers. Separate bumpers would need Frame bindings, which this mod does not have yet.");
      }
    }
  }
  {   // 1.7.117: what the controller decoder is doing, a few times per session (axis types SteamVR reports, the stick axis in use, how often the Index edge-push / trackpad A rules fired)
    static DWORD s_layoutT[2]; static int s_layoutN[2];
    for (int fh = 0; fh < 2; ++fh) {
      if (!(fh ? r.valid : l.valid)) continue;
      const DWORD now = GetTickCount();
      const DWORD gap = s_layoutN[fh] < 1 ? 0 : (s_layoutN[fh] < 3 ? 20000 : 120000);
      if (s_layoutN[fh] < 12 && (s_layoutN[fh] == 0 || now - s_layoutT[fh] >= gap)) {
        char rep[420]; vr_capi_layout_report(fh, rep, (int)sizeof(rep));
        log_line("CONTROLLERLAYOUT %s hand: %s", fh ? "logical RIGHT (gun)" : "logical LEFT", rep);
        s_layoutT[fh] = now; ++s_layoutN[fh];
      }
    }
  }
  const uint64_t rawPressedL = l.pressed, rawPressedR = r.pressed;   // before the tap / hold splitting below (the first-press diagnosis wants the real buttons)
  Snap s;
  ZeroMemory(&s, sizeof(s));
  s.qpc = qpc_now();
  if (!g_ctlMapLogged) {   // 0.78: the whole controller map once, with the result of the conflict check (also tested in tests/test_ctlmap.cpp)
    g_ctlMapLogged = 1;
    int ca = -1, cb = -1;
    const int nconf = ctlmap::conflicts(&ca, &cb);
    log_line("CONTROLMAP %d uses of the Touch controller buttons, conflicts between two uses of the same button that could be active together: %d, new features on a grip: %d",
             ctlmap::kMapN, nconf, ctlmap::new_on_grip());
    for (int i = 0; i < ctlmap::kMapN; ++i)
      log_line("CONTROLMAP %s %s%s: %s", ctlmap::hand_name(ctlmap::kMap[i].hand), ctlmap::button_name(ctlmap::kMap[i].button), ctlmap::kMap[i].isNew078 == 2 ? " [new in 0.98]" : ctlmap::kMap[i].isNew078 ? " [new in 0.78]" : "", ctlmap::kMap[i].what);
  }
  s.validL = l.valid; s.validR = r.valid;
  if (!l.valid && !r.valid) InterlockedIncrement(&g_cs.noHand);
  // ---- 0.78 the ghost trap on the left hip: press the LEFT X button with the hand at the hip to take it (no grip), swing the hand out fast to throw it.
  // The game's own X button (deploy trap) is pressed for the throw, and the game aims where the hand threw for a moment. While the trap is in the hand X is
  // not sent to the game. X anywhere else, or at the hip with the trap feature off, goes straight to the game as before; a quick tap at the hip is replayed.
  float headP[12];
  const int haveHeadP = (l.valid || r.valid) && vr_capi_hmd_pose(headP, nullptr);
  int itSt[8] = {0, 0, 0, 0, 0, 0, 0, 0}, itCur = -1;
  const int inGame = fight_items(itSt, &itCur);   // 1 = the game is running a level right now (the player object was published within half a second)
  {   // 1.7.96 VALVE INDEX. (1) The stick may live on axis 0 instead of axis 3 (the first Index report): say which axis is in use, once per hand.
      // (2) SteamVR's legacy layer hands the Index A button over as the Grip button (id 2; B comes as id 1 = the menu button). Outside a level (the game's menus, loading) a
      // grip press is therefore also given to the game as A, so the menus can be confirmed with the controllers; in a level nothing changes (the grip keeps its jobs).
    static int s_axisLogged[2], s_aLogs; static long s_aGiven;
    int look[2] = {0, 0}, famIdx[2] = {0, 0}; int pk[5];
    for (int fh = 0; fh < 2; ++fh) famIdx[fh] = vr_capi_axis_peaks(fh, pk, &look[fh]);
    for (int fh = 0; fh < 2; ++fh) {
      if ((fh ? r.valid : l.valid) && famIdx[fh] == 2 && !s_axisLogged[fh] && vr_capi_stick_axis(fh) == 0 && !look[fh]) {
        s_axisLogged[fh] = 1;
        log_line("STICKAXIS the %s hand's Valve Index stick is read from analog axis 0: axis 3 has not moved while axis 0 has (peaks per mille: axis0 %d, axis3 %d). SteamVR's own legacy bindings put the stick there",
                 fh ? "right" : "left", pk[0], pk[3]);
      }
    }
    const int idxPad = (famIdx[0] == 2 && !look[0]) || (famIdx[1] == 2 && !look[1]);
    if (idxPad && r.valid && !inGame && ((l.valid && pad::vr_pressed(l.pressed, pad::kVrGrip)) || pad::vr_pressed(r.pressed, pad::kVrGrip))) {
      r.pressed |= (1ull << pad::kVrA); ++s_aGiven;
      if (s_aLogs < 6 && (s_aGiven == 1 || s_aGiven % 200 == 0)) { ++s_aLogs; log_line("INDEXA a Valve Index A button (arrives as the grip, id 2) is given to the game as A outside a level, so its menus work (frames so far %ld)", s_aGiven); }
    }
  }
  int trapEvent = 0;
  double lastZd = -1.0;   // 0.90: hand-to-hip distance, for the log
  {
    const int64_t nq = qpc_now();
    if (g_ctl.trapThrow && l.valid && haveHeadP && !vrmenu_is_open() && !g_holster.holstered && (inGame || g_trap.held) && (g_trap.held || engine_trap_idle())) {   // 1.7.177: a trap that is already OUT (thrown, state 3) is not taken from the hip: the log showed the carry fighting the game 503 times over a trap lying 75 ft away; X then goes to the game, which calls it back
      const double dt = g_trapQpc ? (double)(nq - g_trapQpc) / (double)qpc_freq() : 0.011;
      g_trapQpc = nq;
      const double zd = pad::hip_dist(headP, l.pose34, g_ctl.leftHanded ? 0.22 : -0.22, (double)g_ctl.trapHipDropCm / 100.0);   // 1.7.176: left-handed: the trap hangs on the RIGHT hip   // 0.90: how far below the head the hip is (was 0.55; the log showed 0 grabs)
      lastZd = zd;
      const int inZone = zd >= 0.0 && zd <= (double)g_ctl.trapHipRadiusCm / 100.0;
      const double pos[3] = {(double)l.pose34[3] - headP[3], (double)l.pose34[7] - headP[7], (double)l.pose34[11] - headP[11]};
      const int xBtn = pad::vr_pressed(l.pressed, pad::kVrA);   // the left hand's bottom face button (X)
      const int gripNow = xBtn || pad::vr_pressed(l.pressed, pad::kVrGrip);   // 0.91: hold X or the grip (as asked): the trap stays in the hand; a throw needs force on letting go
      double dir[3] = {0, 0, 1}, spd = 0;
      // 1.7.37 trap_free: a freer throw (a lazy lob works): the hand only has to leave the hip by 8 cm (was 16), the release speed needed is half (0.55 m/s, was 1.1), and the pause after a throw is 0.5 s (was 1.2)
      g_trap.armDist = g_ctl.trapFree ? 0.05 : 0.16; g_trap.coolS = g_ctl.trapFree ? 0.35 : 1.2;   // 1.7.103: easier again (was 8 cm / 0.5 s): the hand only has to leave the hip by 5 cm, the next throw can come after 0.35 s
      trapEvent = g_trap.update(dt, gripNow, inZone, zd < 0.0 ? 1.0 : zd, pos, g_ctl.trapFree ? 0.40 : 1.1, dir, &spd);   // 1.7.19: 1.1 m/s (was 1.6): a gentle lob throws too
      if (trapEvent == 1) { ++g_gs.trapGrabs; haptics_add(0, hap::kSrcMark, 0.8f, 90); log_line("TRAP taken from the left hip with the X button (hand %.0f cm from the hip point)", zd * 100.0); }
      if (trapEvent == 3) {
        ++g_gs.trapPutbacks; haptics_add(0, hap::kSrcMark, 0.35f, 60);
        if (g_trap.tapLike && engine_trap_deploy_now()) { ++g_xReplays; fight_trap_watch(); fight_trap_thrown(); log_line("TRAP quick tap of X at the hip: thrown at once by the game's own throw function (no animation, X not replayed)"); }   // 1.7.175
        else if (g_trap.tapLike) { InterlockedExchange64(&g_trapInputQ, qpc_now()); if (g_ctl.trapNoAnim && g_ctl.trapFromHand) engine_trap_button_launch(); ++g_xReplays; g_xFromQ = 0; g_xUntilQ = nq + qpc_freq() * 25 / 100; fight_trap_watch(); log_line("TRAP quick tap of X at the hip (held %.2f s, hand still): X is replayed so the game deploys the trap as usual", g_trap.heldMs); }
        else log_line("TRAP put back (let go without a throw; fastest hand while holding it %.1f m/s)", g_trap.peak);
      }
      if (trapEvent == 2) {
        ++g_gs.trapThrows; g_gs.trapLastSpeed = spd; if (spd > g_gs.trapMaxSpeed) g_gs.trapMaxSpeed = spd;
        const int deployedNow = engine_trap_deploy_now();   // 1.7.175: the game's own no-animation throw, from the hand, this frame
        if (!deployedNow) { g_xFromQ = nq + qpc_freq() * 12 / 100; g_xUntilQ = nq + qpc_freq() * 42 / 100; }   // fallback: the old delayed X press
        fight_trap_watch();
        float ap[12];
        gear::aim_pose(dir, ap);
        float pr[3];
        // the hand's direction is in tracking space: turn it into the game's engine-local axes with the headset's own conversion
        float tmp[12];
        for (int i = 0; i < 12; ++i) tmp[i] = ap[i];
        tmp[3] = headP[3]; tmp[7] = headP[7]; tmp[11] = headP[11];
        if (vr_pose_to_engine_local(tmp, g_throwRot, pr)) g_throwAimUntilQ = nq + (deployedNow ? qpc_freq() * 15 / 100 : qpc_freq() * 11 / 10);   // 1.7.175: with the instant throw the aim follows the swing only for the 0.15 s it takes to throw (was a 1.1 s lock)
        haptics_add(0, hap::kSrcBlast, 1.0f, 120);
        if (!deployedNow) { InterlockedExchange64(&g_trapInputQ, qpc_now());   // 1.7.173
        if (g_ctl.trapFromHand) engine_trap_launch_request(); }   // 1.7.37: the game's trap starts from the hand that threw it
        fight_trap_thrown();
        log_line("TRAP thrown at %.1f m/s, direction (tracking axes) %.2f,%.2f,%.2f, head looks %.2f,%.2f,%.2f; X is pressed for 0.25 s and the aim follows the throw for 0.7 s | 1.7.19 the direction is your swing over the last 0.16 s (%.0f deg away from the plain release velocity)",
                 spd, dir[0], dir[1], dir[2], -(double)headP[2], -(double)headP[6], -(double)headP[10], g_trap.swingDirDeg);
      }
      if (trapEvent == 2 || trapEvent == 3) g_trapSuppressBtn = gripNow;
      if (g_trap.held) g_trapSuppressBtn = 1;
      if (g_trap.held && l.valid) l.pressed &= ~(1ull << pad::kVrGrip);   // 0.91: the grip that holds the trap must not start the two-hand hold
    } else {
      if (g_trap.held) log_line("TRAP put back (feature off, menu open or tracking lost)");
      g_trap.reset(); g_trapQpc = 0;
    }
    {   // 0.83: a plain X press (not at the hip, no trap in the hand): watch what the game does with it
      static int s_xPrev;
      const int xNow = l.valid && pad::vr_pressed(l.pressed, pad::kVrA) && !g_trap.held && !g_trapSuppressBtn && trapEvent == 0;
      if (xNow && !s_xPrev && inGame) { fight_trap_watch();
        if (engine_trap_deploy_now()) { g_trapSuppressBtn = 1; fight_trap_thrown(); log_line("TRAP plain X press: thrown at once by the game's own throw function from your off hand (no animation, X not sent to the game)"); }   // 1.7.175
        else if (g_ctl.trapNoAnim) { InterlockedExchange64(&g_trapInputQ, qpc_now()); if (g_ctl.trapFromHand) engine_trap_button_launch(); }   // 1.7.173: the trap leaves from the off hand (it showed up in the gun hand with the game's throw animation)
        log_line("TRAP plain X press (the game's own trap button, nothing taken from the hip): hand-to-hip distance %.2f m (zone %.2f m, hip drop %.2f m): the trap state is logged for 4 s", lastZd, (double)g_ctl.trapHipRadiusCm / 100.0, (double)g_ctl.trapHipDropCm / 100.0); }
      s_xPrev = xNow;
    }
    if (g_trapSuppressBtn) {   // X belongs to the trap until it is let go: the game does not see it (the throw sends its own X)
      if (l.valid && pad::vr_pressed(l.pressed, pad::kVrA)) l.pressed &= ~(1ull << pad::kVrA);
      else g_trapSuppressBtn = 0;
    }
  }
  // ---- 0.78 the right A button has two jobs: a quick tap is the game's Interact (replayed when the button comes up, at least 90 ms long), holding it for
  // 0.2 s opens the weapon wheel (no grip). The game does not see A while it is undecided or held for the wheel. With the wheel off, in the menu or outside a
  // level the button goes straight through as before.
  // ---- 0.98 the left Y button has two jobs (the same pattern as A): a quick tap is the game's Y (the PKE meter, replayed when the button comes up, at least 90 ms),
  // holding it for 0.3 s is the "D layer": the right stick sends D-pad presses (equipment select / review), the right stick click is Vent, right B is the HUD button
  // (R3), right A is Select (Back). No grip, no Menu button. Needs the current Sprint/D-layer layout and a running level; the wheel (A held) goes first.
  int yToGame = 0, layerOn = 0;
  const int yRaw = l.valid && pad::vr_pressed(l.pressed, pad::kVrMenu);   // the real button (Menu + grip = Start below still wants it)
  {
    const double dtY = g_wheelQpc ? (double)(qpc_now() - g_wheelQpc) * 1000.0 / (double)qpc_freq() : 11.0;
    if (l.valid) {
      const int can = config().sprintClick && haveHeadP && !vrmenu_is_open() && (inGame || g_yHold.state == 2) && g_aHold.state != 2 &&
                      !pad::vr_pressed(l.pressed, pad::kVrGrip);
      const int ev = g_yHold.update(yRaw, can, dtY, 300.0, 90.0, &yToGame);
      if (ev == 2) ++g_yTaps;
      if (ev == 1) { ++g_yClaims; haptics_add(0, hap::kSrcButton, 0.35f, 30); if (g_yClaims <= 12) log_line("DLAYER on: Y held 0.3 s (right stick = D-pad, right stick click = Vent, right B = HUD, right A = Select) - tap #%ld claim #%ld", g_yTaps, g_yClaims); }
      if (yRaw) l.pressed &= ~(1ull << pad::kVrMenu);   // the game gets Y only through yToGame
      layerOn = g_yHold.state == 2;
    } else {
      g_yHold.reset();
    }
  }
  int aToGame = 0;
  {
    const int64_t nq = qpc_now();
    g_wheelDtMs = g_wheelQpc ? (double)(nq - g_wheelQpc) * 1000.0 / (double)qpc_freq() : 11.0;
    g_wheelQpc = nq;
    if (r.valid && layerOn) {
      g_aHold.reset();   // the D layer owns the right hand's buttons: no wheel, no Interact (A = Select, see pad::build)
    } else if (r.valid) {
      const int aNow = pad::vr_pressed(r.pressed, pad::kVrA);
      const int can = g_ctl.weaponWheel && haveHeadP && !vrmenu_is_open() && (inGame || g_aHold.state == 2);
      const int ev = g_aHold.update(aNow, can, g_wheelDtMs, 200.0, 90.0, &aToGame);
      if (ev == 2) { ++g_aTaps; haptics_add(1, hap::kSrcButton, 0.40f, 28); }
      if (ev == 1) ++g_aClaims;
      if (aNow) r.pressed &= ~(1ull << pad::kVrA);   // the game gets A only through aToGame
    } else {
      g_aHold.reset();
    }
  }
  {   // 1.7.117 VALVE INDEX in a level: its A button reaches SteamVR's legacy layer as the grip, so a QUICK tap of the right grip (released within 0.25 s, trigger never touched, hand not at the pack) is the game's A (Interact).
      // A longer squeeze is still the grip (holster / draw / two-hand hold work as before). The weapon wheel (A held) needs a Touch-style A button.
    static GbvrGripTap s_idxTap; static double s_idxReplayMs; static long s_idxTaps;
    int idxPk[5], idxLookR = 0; const int idxFamR = vr_capi_axis_peaks(1, idxPk, &idxLookR);
    const int realIdxR = r.valid && idxFamR == 2 && !idxLookR;
    if (realIdxR && inGame && haveHeadP && !layerOn && !vrmenu_is_open() && !held_menu_active() && !stereo_in_flat_mode()) {
      const int inZone = pad::pack_hit(headP, r.pose34, kPackBackM, kPackDropM, kPackRadiusM);
      if (gbvr_grip_tap(&s_idxTap, pad::vr_pressed(r.pressed, pad::kVrGrip), r.trigger, inZone, 1, g_wheelDtMs, 250.0)) {
        s_idxReplayMs = 90.0; ++s_idxTaps; haptics_add(1, hap::kSrcButton, 0.40f, 28);
        if (s_idxTaps <= 6 || s_idxTaps % 100 == 0) log_line("INDEXA quick right-grip tap #%ld = A (Interact) in a level (Valve Index: its A button arrives as the grip)", s_idxTaps);
      }
    } else { s_idxTap.down = 0; s_idxTap.cancel = 0; s_idxTap.heldMs = 0.0; }
    if (s_idxReplayMs > 0.0) { aToGame = 1; s_idxReplayMs -= g_wheelDtMs; }
  }
  {   // 1.7.111 capture_tap=1: the right-stick click is a toggle (tap to grab / wrangle, tap again to let go) instead of being held; off in the D layer, the VR menu and out of the game
    static int s_capPrev, s_capOn, s_capSaw; static long s_capTaps; static double s_capLostQ;
    if (g_ctl.captureTap && r.valid && !layerOn && inGame && !vrmenu_is_open() && !g_holster.holstered && !engine_pke_item() && !g_wheel.open && !engine_player_forced()) {   // 1.7.180: also not with the gun holstered, the PKE out, the wheel open or in a forced move
      const int now = pad::vr_pressed(r.pressed, pad::kVrStick);
      if (now && !s_capPrev) { s_capOn = !s_capOn; ++s_capTaps; haptics_add(1, hap::kSrcButton, s_capOn ? 0.45f : 0.25f, 30); if (s_capTaps <= 12) log_line("CAPTURETAP right-stick tap #%ld: the grab is now %s (capture_tap=1)", s_capTaps, s_capOn ? "ON until you tap again" : "OFF"); }
      s_capPrev = now;
      if (s_capOn) {   // 1.7.180: the latch lets go by itself 0.4 s after the ghost is gone (slam, kill, trap), so the next click grabs again instead of switching off
        const int w = fight_wrangled();
        if (w > 0) { s_capSaw = 1; s_capLostQ = 0.0; }
        else if (w == 0 && s_capSaw) { if (s_capLostQ <= 0.0) s_capLostQ = qpc_ms() + 0.001; else if (qpc_ms() - s_capLostQ > 400.0) { s_capOn = 0; s_capSaw = 0; s_capLostQ = 0; haptics_add(1, hap::kSrcButton, 0.25f, 30); } }
      } else { s_capSaw = 0; s_capLostQ = 0; }
      if (s_capOn) r.pressed |= (1ull << pad::kVrStick); else r.pressed &= ~(1ull << pad::kVrStick);
    } else { s_capOn = 0; s_capPrev = r.valid ? (int)pad::vr_pressed(r.pressed, pad::kVrStick) : 0; }
  }
  pad::Hand hl = to_hand(l), hr = to_hand(r);
  {   // Diagnose a missing grab without changing any button mapping.
    static int prevClick; static long clicks;
    const int click = r.valid && pad::vr_pressed(r.pressed, pad::kVrStick);
    if (click && !prevClick && ++clicks <= 20)
      log_line("CAPTUREBTN right-stick click #%ld: D layer=%d, gameplay=%d, grab toggle=%d (normal gameplay sends LB)", clicks, layerOn, inGame, (int)g_ctl.captureTap);
    prevClick = click;
  }
  hl.away = l.valid && r.valid && pad::hands_apart(l.pose34, r.pose34, (double)g_ctl.dpadAwayCm / 100.0);   // 0.77: 45 cm (was 80)
  hl.layer = layerOn;
  pad::Hand hlStart = hl;
  if (yRaw) hlStart.pressed |= (1ull << pad::kVrMenu);   // Menu + grip = Start still sees the real Y
  s.pad = pad::with_start(pad::build(hl, hr, config()), hlStart);
  if (aToGame) s.pad.buttons |= pad::kA;   // 0.78: a live or replayed tap of the right A button (the wheel button): the game's Interact
  if (yToGame) s.pad.buttons |= pad::kY;   // 0.98: a live or replayed tap of the left Y button: the game's Y (PKE)
  int sprintOnNow = 0;   // 1.7.58: sprint toggle is a true persistent toggle
  {
    const double dtS = g_wheelDtMs * 0.001;
    const int clickRaw = (s.pad.buttons & pad::kLeftThumb) != 0;
    const double lmag = vm::dsqrt((double)s.pad.lx * (double)s.pad.lx + (double)s.pad.ly * (double)s.pad.ly) / 32767.0;
    const int canSprintInput = l.valid && inGame && !vrmenu_is_open() && !g_wheel.open && !layerOn;

    if (!inGame) {   // leaving gameplay is the only automatic reset for the toggle
      g_sp.latched=0; g_sp.prevClick=clickRaw; g_sp.idleSecs=0.0; g_sp.clickAge=0.0;
    }
    else if (g_ctl.sprintLatch && config().sprintClick && l.valid) {
      if (g_ctl.sprintToggle) {
        // Temporary menu/layer states suppress the speed request but NEVER clear the latch.
        // prevClick still follows the physical switch so closing a menu while it is held cannot
        // create a fake new toggle edge.
        if (canSprintInput && clickRaw && !g_sp.prevClick) {
          ++g_sp.taps; g_sp.latched=!g_sp.latched;
          if (g_sp.latched) ++g_sp.latchOns; else ++g_sp.latchOffs;
          haptics_add(0, hap::kSrcButton, g_sp.latched ? 0.45f : 0.25f, 35);
          if (g_sp.logged < 40) { ++g_sp.logged; log_line("SPRINTPAD toggle #%ld: left stick click -> speed boost %s (stays that way until YOU click again)", g_sp.taps, g_sp.latched ? "ON" : "off"); }
        }
        if (clickRaw) ++g_sp.holdFrames;
        g_sp.prevClick=clickRaw;
        if (g_sp.latched) ++g_sp.latchFrames;
        s.pad.buttons &= ~pad::kLeftThumb;   // probe speed only; do not invoke the game's native run state
      } else if (canSprintInput) {
        // Legacy tap-latch mode retained for users who explicitly turn sprint_toggle off.
        if (clickRaw) { if (!g_sp.prevClick) g_sp.clickAge=0.0; else g_sp.clickAge+=dtS; ++g_sp.holdFrames; }
        else if (g_sp.prevClick && g_sp.clickAge < 0.35) {
          ++g_sp.taps; g_sp.latched=!g_sp.latched; g_sp.idleSecs=0.0;
          if (g_sp.latched) ++g_sp.latchOns; else ++g_sp.latchOffs;
          haptics_add(0, hap::kSrcButton, g_sp.latched ? 0.45f : 0.25f, 35);
        }
        g_sp.prevClick=clickRaw;
        if (g_sp.latched) {
          if (lmag > 0.30) g_sp.idleSecs=0.0; else g_sp.idleSecs+=dtS;
          if (g_sp.idleSecs > 0.45) { g_sp.latched=0; ++g_sp.stickOffs; }
          else ++g_sp.latchFrames;
        }
        s.pad.buttons &= ~pad::kLeftThumb;
      } else {
        g_sp.prevClick=clickRaw;   // blocked temporarily; preserve latch and avoid a false edge
      }
    } else {
      // If the feature is disabled, do not carry a hidden latch.  A temporary menu is handled above.
      g_sp.latched=0; g_sp.prevClick=clickRaw; g_sp.idleSecs=0.0; g_sp.clickAge=0.0;
    }

    // 1.7.62: a physical L3 hold always requests the 170% mechanic even in
    // toggle mode.  The latch still persists after release, but a missed edge
    // can no longer make sprint appear dead for the whole session.
    sprintOnNow = (g_sp.latched || clickRaw) ? 1 : 0;
    if (g_ctl.sprintSpeedPct > 100 && sprintOnNow && canSprintInput && lmag > 0.30) {
      g_sprintWantQ=qpc_now();
      const LONG sf = InterlockedIncrement(&g_sprintWantFrames);
      if (sf == 1) log_line("SPEEDBOOST request active: %d%%, method %d, L3 toggle=%d (request refreshes while moving)", (int)g_ctl.sprintSpeedPct, (int)g_ctl.sprintSpeedMethod, (int)g_ctl.sprintToggle);
    }
  }
  if (g_ctl.walkCapPct < 100 && g_ctl.walkCapPct >= 40 && l.valid && inGame && !vrmenu_is_open() && !g_wheel.open && !layerOn && !sprintOnNow) {
    // 1.7.6: full stick makes the game play its run; this keeps the push at the chosen share so you stay in the walk (sprint on = no limit)
    const double mg = vm::dsqrt((double)s.pad.lx * (double)s.pad.lx + (double)s.pad.ly * (double)s.pad.ly) / 32767.0;
    const double cap = (double)g_ctl.walkCapPct / 100.0;
    if (mg > cap) { const double k = cap / mg; s.pad.lx = (decltype(s.pad.lx))((double)s.pad.lx * k); s.pad.ly = (decltype(s.pad.ly))((double)s.pad.ly * k); ++g_walkCapFrames; }
    if ((long)(mg * 1000.0) > g_walkCapMax) g_walkCapMax = (long)(mg * 1000.0);
  }
  {   // knock-down comfort replacement: the ORIGINAL fall is intercepted in engine_hooks.
    // Movement is slowed only by the fixed replacement envelope.  Do not tie
    // locomotion to the game's big-hurt animation length if an unrelated path
    // momentarily reports that animation anyway.
    double kf = 1.0;
    if (inGame) { const double kw = knock::walk_factor(engine_knock_strength(), (double)g_ctl.knockWalkPct); if (kw < kf) kf = kw; }
    if (inGame) { const double kr = engine_knock_strength(); if (kr > 0.0) { const float lv = (float)(0.10 + 0.16 * kr); haptics_add(0, hap::kSrcKnock, lv, 60); haptics_add(1, hap::kSrcKnock, lv, 60); } }   // 1.7.190: a light rumble all through the knock-down window, fading out with it
    { static int s_kw; if (kf < 0.995 && !s_kw) { s_kw = 1; log_line("KNOCKWALK stick scaled to %.0f%% (strength %.2f)", kf * 100.0, engine_knock_strength()); } if (kf >= 0.995) s_kw = 0; }
    if (kf < 0.995) {
      s.pad.lx = (decltype(s.pad.lx))((double)s.pad.lx * kf);
      s.pad.ly = (decltype(s.pad.ly))((double)s.pad.ly * kf);
      g_sprintWantQ = 0;  // a sprint held through the hit must not cancel the slowdown
    }
  }
  {   // 0.98 counters for the log: what the new layout really sent
    if (layerOn) { ++g_layerFrames; const unsigned b = s.pad.buttons; if (b & (pad::kDpadUp | pad::kDpadDown | pad::kDpadLeft | pad::kDpadRight)) ++g_layerDpad; if (b & pad::kRightShoulder) ++g_layerVent; if (b & pad::kRightThumb) ++g_layerHud; if (b & pad::kBack) ++g_layerSelect; }
    if (s.pad.buttons & pad::kLeftThumb) ++g_sprintFrames;
    if (s.pad.lt == 255) ++g_altFireFrames;
    if (layerOn != g_layerPrevOn) { g_layerPrevOn = layerOn; if (!layerOn && g_yClaims <= 12) log_line("DLAYER off (frames in it so far %ld: D-pad %ld, vent %ld, HUD %ld, select %ld)", g_layerFrames, g_layerDpad, g_layerVent, g_layerHud, g_layerSelect); }
  }
  s.pressedL = l.pressed; s.pressedR = r.pressed;
  s.stickX = r.stickX; s.stickY = r.stickY; s.trapHeld = g_trap.held;
  // ---- 0.78 the weapon wheel (Alyx style): hold the right A button, point with the right stick or move the right hand toward a disc, let go to pick it
  {
    const int64_t nq = qpc_now();
    const double dtMs = g_wheelDtMs;
    {
      const int wheelOk = g_ctl.weaponWheel && r.valid && haveHeadP && !vrmenu_is_open();
      const int held = wheelOk && g_aHold.state == 2;
      if (held && !g_wheel.open) {   // opening now: pin the wheel in front of you where the hand is
        const double hp0[3] = {(double)r.pose34[3], (double)r.pose34[7], (double)r.pose34[11]};
        g_wPoseOk = gear::wheel_anchor(headP, hp0, g_wPose);
        for (int i = 0; i < 3; ++i) g_wOrigin[i] = hp0[i];
      }
      double hx = 0, hy = 0;
      if (held && g_wPoseOk) {
        const double hp1[3] = {(double)r.pose34[3], (double)r.pose34[7], (double)r.pose34[11]};
        gear::wheel_hand_offset(g_wPose, g_wOrigin, hp1, &hx, &hy);
      }
      const unsigned unusable = inGame ? gear::unusable_mask(itSt) : 0u;
      int slot = -1, hoverChanged = 0;
      const int ev = g_wheel.update(held, held ? r.stickX : 0.0, held ? r.stickY : 0.0, hx, hy, dtMs, gear::kSlots, unusable, &slot, &hoverChanged);
      if (ev == 1) {
        ++g_gs.wheelOpens; haptics_add(1, hap::kSrcMark, 0.45f, 50);
        if (g_gs.wheelOpens <= 40) {
          char lk[80]; int ln = 0;
          for (int i = 0; i < gear::kSlots; ++i) if (inGame && gear::slot_status(i, itSt) == gear::kLocked && ln < 60) ln += wsprintfA(lk + ln, " %s", gear::kWheel[i].label);
          lk[ln] = 0;
          log_line("WHEEL opened at (%.2f,%.2f,%.2f) m from the head; inventory %s: states %d %d %d %d %d %d %d %d, shown as ?:%s", g_wPose[3] - headP[3], g_wPose[7] - headP[7], g_wPose[11] - headP[11],
                   inGame ? "known" : "not known", itSt[0], itSt[1], itSt[2], itSt[3], itSt[4], itSt[5], itSt[6], itSt[7], ln ? lk : " none");
        }
      }
      if (hoverChanged && g_wheel.sel >= 0) {   // a tick for every disc that lights up (a softer, shorter one for discs that refuse)
        const int refuses = (int)((unusable >> g_wheel.sel) & 1u);
        haptics_add(1, hap::kSrcMark, refuses ? 0.14f : 0.30f, refuses ? 18 : 25);
        if (g_wheel.src == 2) ++g_gs.handPicks;
      }
      g_prevWheelSel = g_wheel.open ? g_wheel.sel : -1;
      if (ev == 4 && slot >= 0 && slot < gear::kSlots) {
        haptics_add(1, hap::kSrcMark, 0.60f, 140);
        const gear::Slot& sl = gear::kWheel[slot];
        log_line("WHEEL picked %s but it is %s - refused, nothing changes (inventory state %d)", sl.label, gear::slot_status(slot, itSt) == gear::kLocked ? "LOCKED (not unlocked in the campaign yet, shown as ?)" : "switched off right now",
                 (sl.kind == gear::kKindItem && sl.arg >= 0 && sl.arg < 8) ? itSt[sl.arg] : -1);
      }
      if (ev == 2 && slot >= 0 && slot < gear::kSlots) {
        const gear::Slot& sl = gear::kWheel[slot];
        ++g_gs.wheelChosen;
        int st[8], cur = -1;
        const int fresh = fight_items(st, &cur);
        const int usable = gear::slot_usable(slot, fresh ? st : nullptr);
        if (sl.kind == gear::kKindItem) {
          ++g_gs.items;
          g_pend.want = 0; g_pend.forced = 0;
          if (usable && sl.arg == gear::kItemMeter) {   // 0.84: the PKE is brought out with the game's own Y button; calling its ready function a second time froze the game (every log since 0.81)
            if (cur != gear::kItemMeter) { g_yFromQ = 0; g_yUntilQ = nq + qpc_freq() * 18 / 100; ++g_gs.pkeByY; g_pend.want = gear::kItemMeter; g_pend.nextQ = nq + qpc_freq() * 7 / 10; g_pend.tries = 1; fight_switch_note(1, 1); }
          } else if (usable && sl.arg == gear::kItemProton && cur == gear::kItemMeter) {   // 0.93: PRO while the PKE is out: put the PKE away with the same Y button that brought it out (the game goes back to its stream). The ready-item call left the game unable to bring the PKE out again (every Y press after it did nothing in the 0.90 log)
            g_yFromQ = 0; g_yUntilQ = nq + qpc_freq() * 18 / 100; ++g_gs.pkeByY; g_pend.want = gear::kItemProton; g_pend.nextQ = nq + qpc_freq() * 7 / 10; g_pend.tries = 1; fight_switch_note(1, 1);
          } else if (usable) fight_request_item(sl.arg);
          log_line("WHEEL picked %s (item %d): %s (inventory %s: state %d, in hand %d)", sl.label, sl.arg, usable ? "the game is asked to ready it" : "NOT available (not owned / switched off) - nothing done",
                   fresh ? "known" : "not known yet", fresh ? st[sl.arg] : -1, cur);
        } else if (sl.kind == gear::kKindDpad) {
          ++g_gs.dpad; g_dpadMask = (unsigned)sl.arg; g_dpadUntilQ = nq + qpc_freq() * 14 / 100;
          log_line("WHEEL picked %s: D-pad press 0x%x for 0.14 s (the game's own 'proton equipment' button; in hand now %d)", sl.label, sl.arg, cur);
        } else {
          ++g_gs.notch;
          POINT cp = {0, 0};
          GetCursorPos(&cp);
          const LONG delta = sl.arg > 0 ? 120 : -120;
          const BOOL ok = g_ctl.gameHwnd ? PostMessageW(g_ctl.gameHwnd, WM_MOUSEWHEEL, (WPARAM)((((DWORD)(WORD)(short)delta) << 16)), MAKELPARAM((WORD)cp.x, (WORD)cp.y)) : FALSE;
          if (ok) ++g_gs.notchPosted;
          log_line("WHEEL picked %s: one mouse-wheel notch %+d sent to the game window (%s); in hand before: %d", sl.label, (int)delta, ok ? "posted" : "FAILED", cur);
        }
        haptics_add(1, hap::kSrcMark, 0.85f, 90);
      }
      if (ev == 3) { ++g_gs.wheelCancel; haptics_add(1, hap::kSrcMark, 0.2f, 40); }
      if (g_wheel.open) {   // while the wheel is open the stick only picks: no turning, no D-pad, no shot, no vent click
        s.pad.rx = 0; s.pad.ry = 0; s.pad.rt = 0;
        s.pad.buttons &= (uint16_t)~(pad::kDpadUp | pad::kDpadDown | pad::kDpadLeft | pad::kDpadRight | pad::kRightShoulder);
      }
    }
    s.wheelOpen = g_wheel.active(); s.wheelSel = g_wheel.sel; s.wheelPicked = g_wheel.picked; s.wheelPickLocked = g_wheel.pickLocked;
    s.wheelOpenT = (float)g_wheel.openT; s.wheelFlash = (float)g_wheel.flash; s.wheelCurX = (float)g_wheel.curX; s.wheelCurY = (float)g_wheel.curY;
    for (int i = 0; i < gear::kSlots; ++i) s.wheelHov[i] = (float)g_wheel.hov[i];
    for (int i = 0; i < 12; ++i) s.wheelPose[i] = g_wPose[i];
    g_gs.wheelTaps = g_aTaps;
    if (nq >= g_xFromQ && nq < g_xUntilQ) s.pad.buttons |= pad::kX;
    if (g_pend.want && nq >= g_pend.nextQ) {   // 0.93: did the game do it? if not, press again; the last tries first send the game's equipment button (D-pad up), which cleared the same stuck state in the 0.90 log
      int st2[8], c2 = -1;
      const int ok2 = fight_items(st2, &c2);
      if (ok2 && c2 == g_pend.want) { log_line("WHEEL check: the game now has item %d in hand (try %d) - done", c2, g_pend.tries); g_pend.want = 0; haptics_add(1, hap::kSrcMark, 0.55f, 70); }   // 1.1: a short buzz in the right hand when the switch has landed
      else if (g_pend.tries >= 8 && g_pend.want == gear::kItemProton && c2 == gear::kItemMeter && ok2 && !g_pend.forced) {   // 0.97 last resort: the 0.96 log never got the gun back after the PKE (4 picks x 8 presses, the item in hand stayed 5 for 9000 frames)
        g_pend.forced = 1;
        fight_request_item(gear::kItemProton);
        g_pend.nextQ = nq + qpc_freq() * 12 / 10;
        log_line("WHEEL last resort: the Y presses did not put the PKE away after %d tries (gun holstered=%d), so the game's own ready-item function is asked for the proton gun once (the 0.90 log: afterwards Y may not bring the PKE out again)", g_pend.tries, (int)g_holster.holstered);
      }
      else if (g_pend.tries >= 8) { fight_switch_note(3, g_pend.tries); haptics_add(1, hap::kSrcMark, 0.25f, 40); log_line("WHEEL check: item %d still NOT in hand after %d tries%s (in hand %d; item states %d %d %d %d %d %d %d %d, fresh %d, gun holstered=%d)", g_pend.want, g_pend.tries, g_pend.forced ? " and the ready-item request" : "", c2, st2[0], st2[1], st2[2], st2[3], st2[4], st2[5], st2[6], st2[7], ok2, (int)g_holster.holstered); g_pend.want = 0; }   // 0.94: 8 tries (the 0.93 log: the first PKE pick failed 4 tries in a row and the very next one worked at once - the game was busy with something)
      else {
        ++g_pend.tries;
        fight_switch_note(2, g_pend.tries - 1);   // 1.1: what the game's own checks say right now
        const int helpTry = g_ctl.switchHelp && (g_pend.tries & 1) == 0;   // 1.1: even tries do not press Y (a second press right after a late switch would toggle it straight back): the game thread finishes a stuck switch and queues the item the way Y does
        if (helpTry) fight_switch_help(g_pend.want);
        else if (g_pend.tries >= 3 && (g_pend.tries & 1)) { g_dpadMask = 0x1u; g_dpadUntilQ = nq + qpc_freq() * 14 / 100; g_yFromQ = nq + qpc_freq() * 30 / 100; g_yUntilQ = nq + qpc_freq() * 48 / 100; fight_switch_note(1, g_pend.tries); }
        else { g_yFromQ = 0; g_yUntilQ = nq + qpc_freq() * 18 / 100; fight_switch_note(1, g_pend.tries); }
        g_pend.nextQ = nq + qpc_freq() * (g_pend.tries >= 4 ? 14 : 8) / 10;   // 0.94: later tries wait longer (a busy game gets time)
        log_line("WHEEL check: item %d not in hand yet (in hand %d) - try %d%s", g_pend.want, c2, g_pend.tries, helpTry ? " (no Y press: the game is asked to finish a stuck switch and the item is queued the way Y does)" : (g_pend.tries >= 3 ? " (equipment button first)" : ""));
      }
    }
    if (nq >= g_yFromQ && nq < g_yUntilQ) s.pad.buttons |= pad::kY;                                          // 0.84: the wheel's PKE
                                             // the trap throw: the game's own deploy-trap button
    if (nq < g_dpadUntilQ) s.pad.buttons |= (uint16_t)g_dpadMask;                          // the wheel's D-pad picks
    const unsigned dp = s.pad.buttons & (pad::kDpadUp | pad::kDpadDown | pad::kDpadLeft | pad::kDpadRight);
    static unsigned s_prevDp;
    if (dp && !s_prevDp) { ++g_gs.dpadSeen; if (nq >= g_dpadUntilQ) { haptics_add(1, hap::kSrcMark, 0.5f, 40); log_line("DPAD pressed by the right stick (left grip with the free hand %d cm from the gun hand%s): 0x%x", (int)g_ctl.dpadAwayCm, g_layerPrevOn ? ", or the D layer: Y is held" : "", dp); } }
    s_prevDp = dp;
  }
  // ---- 0.52 height calibration: stand straight, hold left Menu + right Grip for 1.5 s (or Ctrl+F9) --------------------
  int calibGest = 0;
  {
    double dtMs = g_calibQpc ? (double)(s.qpc - g_calibQpc) * 1000.0 / (double)qpc_freq() : 11.0;
    g_calibQpc = s.qpc;
    if (dtMs > 100.0) dtMs = 100.0;
    calibGest = 0;   // 0.53: the left Menu button clashes with Virtual Desktop: the menu's "Measure my height" and Ctrl+F9 do this now
    const int viaKey = g_ctl.calibrateRequest != 0;
    float hp[12];
    int haveHp = 0;
    if (calibGest || viaKey || g_calib.active) haveHp = vr_capi_hmd_pose(hp, nullptr);
    double med = 0;
    const int ev = g_calib.update(dtMs, (calibGest || viaKey) ? 1 : 0, haveHp ? (double)hp[7] : 0.0, &med);
    if (ev == 1) { g_calibTickMs = 0; log_line("CALIBRATE started (%s): stand straight and look ahead for 1.5 seconds", "menu or Ctrl+F9"); haptics_add(1, hap::kSrcMark, 0.3f, 120); }
    if (g_calib.active == 1) {   // a light tick every 0.3 s while measuring
      g_calibTickMs += dtMs;
      if (g_calibTickMs >= 300.0) { g_calibTickMs = 0; haptics_add(1, hap::kSrcMark, 0.22f, 70); haptics_add(0, hap::kSrcMark, 0.22f, 70); }
    }
    if (ev == 2) {
      log_line("CALIBRATE meter: %d samples, steadiest second %.2f..%.2f s had %d samples spread %.1f cm (%s), result %.3f m", g_calib.last.n, g_calib.last.winStartMs / 1000.0, g_calib.last.winEndMs / 1000.0, g_calib.last.winN, g_calib.last.range * 100.0, g_calib.last.loose ? "loose" : "steady", med);
      body_calibrate_apply(med, l.valid ? (double)l.pose34[7] : 0.0, r.valid ? (double)r.pose34[7] : 0.0);
      InterlockedExchange(&g_ctl.calibrateRequest, 0);
      haptics_add(0, hap::kSrcMark, 0.9f, 200); haptics_add(1, hap::kSrcMark, 0.9f, 200);
    } else if (ev == 3) {
      if (g_calib.active != 2) { log_line("CALIBRATE cancelled: the button was released too early"); }
      else log_line("CALIBRATE failed: the headset height was not tracked (%d samples) - nothing changed", g_calib.n);
      InterlockedExchange(&g_ctl.calibrateRequest, 0);
    }
    if (calibGest) s.pad.buttons &= (uint16_t)~pad::kY;   // the Menu button is the game's Y: not while calibrating
  }
  // head pose for the body-relative zones (holster at the hip, pack on the back)
  float head[12];
  int haveHead = (g_ctl.holster || g_ctl.ventGesture) && (l.valid || r.valid) && vr_capi_hmd_pose(head, nullptr);
  // 1.7.99 THE GAME DECIDES WHEN YOU MAY HOLD THE GUN. Not allowed (cut-scene, forced walk, between levels, nothing equipped) = the gun is put in the holster and cannot be drawn.
  // A gun the game GIVES you (level start, after a cut-scene) stays holstered until you draw it yourself; the right hand buzzes when you may. The PKE and the trap change nothing.
  int gunBlocked = 0;
  if (g_ctl.holster && g_ctl.gunWaitDraw) {
    static int s_refusedLogs; static long s_gainN, s_lostN;
    const double nowS = (double)GetTickCount() * 0.001;
    const int why = !inGame ? 1 : engine_player_forced() ? 2 : itCur == 0 ? 3 : 0;
    static double s_forcedSince = -1.0; static long s_knockKept;
    const int forcedNow = engine_player_forced() ? 1 : 0;   // 1.7.117: a knock-down (a short forced move) keeps the gun in hand
    if (!forcedNow || !inGame) { if (s_forcedSince >= 0.0 && inGame && g_gunGate.stable && nowS - s_forcedSince > 0.3 && nowS - s_forcedSince < gungate::kKnockGraceS) { ++s_knockKept; if (s_knockKept <= 12) log_line("HOLSTER knock-down #%ld: the game moved the character for %.1f s; the gun stayed as it was (not put away)", s_knockKept, nowS - s_forcedSince); } s_forcedSince = -1.0; }
    else if (s_forcedSince < 0.0) s_forcedSince = nowS;
    const int ev = gungate::step(&g_gunGate, nowS, gungate::raw_knock(inGame, forcedNow, itCur, s_forcedSince >= 0.0 ? nowS - s_forcedSince : 0.0, gungate::kKnockGraceS));
    if (ev == gungate::kLost && inGame) {
      ++s_lostN;
      gungate::remember_loss(&g_gunDrawMemory, g_holster.holstered);
      if (!g_holster.holstered) { g_holster.holstered = 1; haptics_add(1, hap::kSrcHolster, 0.5f, 100); }
      log_line("HOLSTER gun put away #%ld: the game does not allow a gun in hand now (%s; item %d)", s_lostN, why == 2 ? "it moves the character by force" : why == 3 ? "nothing is equipped" : "no gun", itCur);
    }
    if (ev == gungate::kGained) {
      ++s_gainN;
      g_holster.holstered = gungate::restore_on_gain(&g_gunDrawMemory);
      haptics_add(1, hap::kSrcHolster, g_holster.holstered ? 0.9f : 0.5f, g_holster.holstered ? 260 : 120);
      log_line("HOLSTER gun ready #%ld: the game allows a gun now (item %d); %s (right trigger + grip over the right shoulder puts it away / draws it) - the right hand buzzed", s_gainN, itCur, g_holster.holstered ? "it stays in the holster until you draw it" : "it is in your hand (as you left it, or the first one of this session)");
    }
    gunBlocked = gungate::blocked(g_gunGate, inGame);
    if (gunBlocked && !g_holster.holstered) g_holster.holstered = 1;
    static int s_prevRefuse;
    const int tryDraw = gunBlocked && r.valid && r.trigger > 0.6f && pad::vr_pressed(r.pressed, pad::kVrGrip);
    if (tryDraw && !s_prevRefuse && s_refusedLogs < 20) { ++s_refusedLogs; log_line("HOLSTER draw refused: the game does not allow a gun in hand right now (%s)", why == 2 ? "forced move" : why == 3 ? "nothing equipped" : "no gun"); }
    s_prevRefuse = tryDraw;
  } else {
    g_gunGate.stable = 0; g_gunGate.loseSince = g_gunGate.gainSince = -1.0;
  }
  // 0.83 holster on the back: the right trigger AND grip squeezed together with the right hand over the shoulder (at the pack) toggles holstered
  int holsterGest = 0;
  if (g_ctl.holster && r.valid) {
    if (haveHead) {
      int before = g_holster.holstered;
      const int rZone = pad::pack_hit(head, r.pose34, kPackBackM, kPackDropM, kPackRadiusM);
      // 1.7.108: while a menu is up (the pages in the hand, the game's pause menu) the right trigger + grip is a menu click, never a holster / draw
      const int menuUp = vrmenu_is_open() || held_menu_active() || stereo_in_flat_mode();
      holsterGest = rZone && pad::vr_pressed(r.pressed, pad::kVrGrip) && r.trigger > 0.6f && !calibGest && !menuUp;
      if (holsterGest) s.pad.rt = 0;   // the squeeze must not fire the beam
      g_holster.update(holsterGest, rZone && !gunBlocked);
      if (g_holster.holstered != before) { gungate::remember_player_choice(&g_gunDrawMemory, g_holster.holstered); haptics_add(1, hap::kSrcHolster, 0.8f, 140); log_line("HOLSTER wand %s", g_holster.holstered ? "holstered" : "drawn"); }
    }
  } else {
    g_holster.holstered = 0;
  }
  // 0.45 pack vent: a hand over the shoulder (on the pack) with its grip squeezed = the game's Vent button (RB).
  // A short buzz tells the hand it has found the pack; the stick click (RB) still works as before.
  if (g_ctl.ventGesture && haveHead) {
    int in[2] = {l.valid && pad::pack_hit(head, l.pose34, kPackBackM, kPackDropM, kPackRadiusM),
                 r.valid && pad::pack_hit(head, r.pose34, kPackBackM, kPackDropM, kPackRadiusM)};
    int grip[2] = {l.valid && pad::vr_pressed(l.pressed, pad::kVrGrip), r.valid && pad::vr_pressed(r.pressed, pad::kVrGrip)};
    for (int h = 0; h < 2; ++h) {
      if (in[h] && !g_ventIn[h]) { haptics_add(h, hap::kSrcPack, 0.55f, 90); InterlockedIncrement(&g_cs.packTouches); }
      g_ventIn[h] = in[h];
    }
    if (g_ctl.holster && r.valid && r.trigger > 0.6f) grip[1] = 0;   // 0.83: trigger + grip over the shoulder is the holster, not the vent
    int venting = (in[0] && grip[0]) || (in[1] && grip[1]);
    if (venting) {
      for (int h = 0; h < 2; ++h) if (in[h] && grip[h]) haptics_add(h, hap::kSrcVent, 0.5f, 100);   // steady buzz while venting
      s.pad.buttons |= pad::kRightShoulder;
      InterlockedIncrement(&g_cs.ventPolls);
    }
    if (venting != g_ventOn) {
      g_ventOn = venting;
      if (venting) { InterlockedIncrement(&g_cs.ventStarts); haptics_add(in[1] && grip[1] ? 1 : 0, hap::kSrcVent, 1.0f, 200); }
      log_line("VENT %s (hand on the pack with grip squeezed, left=%d/%d right=%d/%d)", venting ? "started" : "stopped", in[0], grip[0], in[1], grip[1]);
    }
  } else if (g_ventOn) {
    g_ventOn = 0;
    log_line("VENT stopped (gesture off or no head pose)");
  }
  // Holstering suppresses the BLASTER triggers, not the PKE controls. If Y
  // brings the PKE out while the gun remains on the back, its scan/trigger
  // inputs must still reach the game.
  // 1.7.108: only in real play. In the game's own menus (pause, objectives) the holster state means nothing and the triggers must reach the game (the gun gate puts the gun in the holster whenever a menu is up).
  if (g_holster.holstered && !engine_pke_item() && inGame && !stereo_in_flat_mode() && !held_menu_active()) { s.pad.rt = 0; s.pad.lt = 0; }
  // 1.7.41 Boson Dart: squeezing the GRIP of the hand that holds the gun fires the game's secondary fire (its left-trigger action; the dart). Not over the shoulder (that is the holster / vent), not while
  // the weapon wheel or a menu is open or the gun is holstered. The right stick click still does the same.
  {
    static int s_dartOn; static long s_dartPolls, s_dartStarts; static int s_dartLogs;
    static boson::Grip dartGrip;
    const int rg = r.valid && pad::vr_pressed(r.pressed, pad::kVrGrip);
    int fireDart = 0;
    float hd[12];
    const int haveHd = r.valid && vr_capi_hmd_pose(hd, nullptr);
    const int inPack = haveHd && pad::pack_hit(hd, r.pose34, kPackBackM, kPackDropM, kPackRadiusM);
    const int allowed = g_ctl.bosonGrip && inGame && itCur == gear::kItemProton && haveHd && !inPack &&
      !g_holster.holstered && !g_wheel.open && !vrmenu_is_open() && !held_menu_active() && !layerOn && !calibGest;
    fireDart = dartGrip.update(rg, allowed, r.valid);
    if (fireDart) { s.pad.lt = 255; ++s_dartPolls; ++g_altFireFrames; }
    if (fireDart && !s_dartOn) { ++s_dartStarts; haptics_add(1, hap::kSrcBlast, 0.8f, 90); if (s_dartLogs < 40) { ++s_dartLogs; log_line("BOSONGRIP the gun hand's grip was squeezed: secondary fire (Boson Dart) pressed (start #%ld, %ld polls so far)", s_dartStarts, s_dartPolls); } }
    s_dartOn = fireDart;
    g_dartStarts = s_dartStarts; g_dartPolls = s_dartPolls;
  }
  {   // 1.7.222 DARTLT (data only): the left trigger with the proton gun in hand is handed to the game EXACTLY as the controller gives it. 1.7.221 reshaped it into a clean full press and the
      // Boson Dart stopped working, so that is gone for good (the setting dart_clean_press is ignored). Each pull is logged so the next report shows what was sent and what the game did.
    static int s_rawWas, s_peak, s_cleanLogs; static unsigned s_rawDownAt; static long s_rawPresses;
    const unsigned nowT = GetTickCount();
    const int raw = s.pad.lt, rawDown = raw > 60;
    if (rawDown && !s_rawWas) { s_rawDownAt = nowT; s_peak = raw; ++s_rawPresses; }
    if (rawDown && inGame && (itCur == gear::kItemProton || itCur == gear::kItemSlime || itCur == gear::kItemShotgun || itCur == gear::kItemRailgun)) InterlockedExchange64(&g_altInputQ, s.qpc);
    if (rawDown && raw > s_peak) s_peak = raw;
    if (!rawDown && s_rawWas && inGame && itCur == gear::kItemProton) {
      const unsigned heldMs = nowT - s_rawDownAt;
      if (s_cleanLogs < 120) { ++s_cleanLogs; log_line("DARTLT left trigger let go (press #%ld): pulled %u ms, peak %d of 255, sent to the game unchanged, right trigger %d, holstered %d, dart hits the game reported so far %ld", s_rawPresses, heldMs, s_peak, (int)s.pad.rt, g_holster.holstered ? 1 : 0, (long)g_dartHitsSeen); }
    }
    s_rawWas = rawDown;
    // 1.7.224 "darts shoot only after each failed attempt": in the 1.7.223 report every left-trigger pull had the right trigger (the stream) held, and the game only ever asked "is the
    // secondary held", never "just pressed". Data-based guess: the dart does not leave the gun while the stream is on. So while the left trigger is down with the proton gun in hand,
    // the stream trigger is let go for the game. Not while a ghost is wrangled (the capture stream needs it), with the gun holstered, the wheel/menu open or the PKE out.
    {
      static int s_pauseWas; static unsigned s_pauseAt; static long s_pauses; static unsigned s_pausedMsSum; static int s_pauseLogs;
      const int pause = g_ctl.dartPauseStream && rawDown && s.pad.rt > 60 && inGame && itCur == gear::kItemProton && !engine_pke_item() && !g_holster.holstered &&
                        !g_wheel.open && !vrmenu_is_open() && !held_menu_active() && fight_wrangled() != 1;
      if (pause) { s.pad.rt = 0; if (!s_pauseWas) { s_pauseAt = nowT; ++s_pauses; } }
      if (!pause && s_pauseWas) { const unsigned ms = nowT - s_pauseAt; s_pausedMsSum += ms;
        if (s_pauseLogs < 60) { ++s_pauseLogs; log_line("DARTPAUSE 1.7.224 the stream trigger was let go for %u ms while the left trigger was pulled (pause #%ld, %u ms in all, dart hits the game reported so far %ld)", ms, s_pauses, s_pausedMsSum, (long)g_dartHitsSeen); } }
      s_pauseWas = pause;
    }
  }
  {   // 1.7.74 (as 1.7.73): the slime blower's alternate fire (the tether) gets ONE short press per squeeze of the left trigger, so the first end point stays and a
      // second squeeze sets the second one (a held trigger kept firing / re-aiming the first end)
    static int s_ltWas, s_ltPolls; static long s_ltEdges;
    if (g_ctl.slimeLtEdge && inGame && itCur == gear::kItemSlime) {
      const int down = s.pad.lt > 60;
      if (down && !s_ltWas) { s_ltPolls = 0; ++s_ltEdges; g_slimeLtEdges = s_ltEdges; }
      if (down) { if (s_ltPolls < 1000) ++s_ltPolls; if (s_ltPolls > 8) s.pad.lt = 0; }
      s_ltWas = down;
    } else s_ltWas = s.pad.lt > 60;
  }
  // 0.53 in-VR menu: left hand beside the head + left grip squeezed opens / closes it.
  // 1.7.7: "beside the head" is the zone beside the LEFT EAR (vmenu::ear_zone), the hand must stay in about one spot for 0.6 s, and it must not be on the gun (the two-hand hold wins).
  // The old rule (a 30 cm ball around the headset, 0.5 s) opened the menu when the left hand held the gun up in front of the face. menu_strict 0 brings the old rule back.
  {
    static uint32_t s_since, s_oldSince; static int s_latched, s_oldLatched; static float s_start[3];
    float hp2[12];
    const int gripOn = l.valid && pad::vr_pressed(l.pressed, pad::kVrGrip);
    const int haveHmd = gripOn && vr_capi_hmd_pose(hp2, nullptr);
    const int strict = g_ctl.menuStrict != 0;
    vmenu::EarInfo ei = {0, 0, 0, 0};
    const int oldRule = haveHmd && vmenu::near_head(hp2, l.pose34, 0.30);
    const int ear = haveHmd && vmenu::ear_zone(hp2, l.pose34, &ei, g_ctl.leftHanded ? 1 : 0);
    const int onGun = r.valid && !hl.away;   // the left hand is near the gun hand: it holds the gun, it is not going to the ear
    const int zone = strict ? (ear && !onGun) : oldRule;
    uint32_t nowMs = GetTickCount();
    if (oldRule) ++g_menuOldFrames;
    if (zone) ++g_menuZoneFrames;
    if (!zone) { s_since = 0; s_latched = 0; }
    else {
      const float cur[3] = {l.pose34[3], l.pose34[7], l.pose34[11]};
      const double mvd = vm::dsqrt((double)(cur[0] - s_start[0]) * (cur[0] - s_start[0]) + (double)(cur[1] - s_start[1]) * (cur[1] - s_start[1]) + (double)(cur[2] - s_start[2]) * (cur[2] - s_start[2]));
      if (!s_since || (strict && mvd > 0.10)) { s_since = nowMs; for (int i = 0; i < 3; ++i) s_start[i] = cur[i]; }   // a hand that is still travelling restarts the wait
      if (!s_latched && nowMs - s_since >= (strict ? 600u : 500u)) {
        s_latched = 1;
        ++g_menuOpens;
        if (g_menuOpens <= 40) log_line("MENUGESTURE #%ld opens the menu: left hand %.0f cm right, %.0f cm up, %.0f cm ahead of the headset (%.0f cm away), held %.2f s, strict=%d, hands apart=%d", g_menuOpens, ei.right * 100.0, ei.up * 100.0, ei.fwd * 100.0, ei.dist * 100.0, (double)(nowMs - s_since) * 0.001, (int)strict, (int)hl.away);
        haptics_add(0, hap::kSrcMark, 0.6f, 90);
        vrmenu_toggle("left hand at head");
      }
    }
    // data: what the OLD rule would have done that the new one did not (the player's "it opened and my hand was not by my head")
    if (!oldRule) { s_oldSince = 0; s_oldLatched = 0; }
    else {
      if (!s_oldSince) s_oldSince = nowMs;
      if (!s_oldLatched && nowMs - s_oldSince >= 500) {
        s_oldLatched = 1;
        if (!zone) { ++g_menuOldOnly; if (g_menuOldOnly <= 20) log_line("MENUGESTURE the old rule would have opened the menu now but the ear zone did not (#%ld): left hand %.0f cm right, %.0f cm up, %.0f cm ahead of the headset, hands apart=%d", g_menuOldOnly, ei.right * 100.0, ei.up * 100.0, ei.fwd * 100.0, (int)hl.away); }
      }
    }
    if (zone) { s.pad.buttons = 0; s.pad.lt = 0; s.pad.rt = 0; }
  }
  if (vrmenu_is_open()) {   // while the menu is open the game gets nothing from the controllers (no shots, no vent, no holster)
    ZeroMemory(&s.pad, sizeof(s.pad));
  }
  int slamStickSet = 0;   // 1.5: the slam swing flicks the aim stick on purpose; the snap turn must not wipe that
  // ---- 1.7.57 slam: hold Capture on the RIGHT stick click, then squeeze the LEFT trigger (normal LT / alt-fire) all the way with a full meter.
  // The game's slam needs capture held + the fire trigger pressed + a full meter; this presses fire for 0.45 s and flicks the aim stick toward the pull (no pull = the game slams down by itself).
  {
    static int s_tsInit; static int64_t s_tsQpc;
    if (!s_tsInit) { g_trigSlam.reset(); g_trigSlam.slams = g_trigSlam.denied = g_trigSlam.flickless = g_trigSlam.noGhost = g_trigSlam.pings = 0; g_pull.reset(); s_tsInit = 1; }
    if (g_ctl.slamTrigger && r.valid && l.valid && haveHeadP && !g_holster.holstered && !vrmenu_is_open() && !g_wheel.open && inGame) {
      const double pos[3] = {(double)r.pose34[3] - headP[3], (double)r.pose34[7] - headP[7], (double)r.pose34[11] - headP[11]};
      const double right[3] = {headP[0], headP[4], headP[8]}, up[3] = {headP[1], headP[5], headP[9]};
      const double dt = s_tsQpc ? (double)(s.qpc - s_tsQpc) / (double)qpc_freq() : 0.011;
      s_tsQpc = s.qpc;
      g_pull.push(dt, pos, right, up);
      const int capture = (s.pad.buttons & pad::kLeftShoulder) != 0;
      double sx = 0, sy = 0; int started = 0, denied = 0, force = 0, ping = 0;
      const int held = fight_wrangled();   // 1.7.2: 1 the capture stream holds a ghost, 0 nothing, -1 the field is not trusted yet
      const int press = g_trigSlam.update(dt, (double)hl.trigger, capture, fight_slam_ready(), held, (double)g_ctl.slamTrigPct * 0.01, g_pull, &sx, &sy, &force, &started, &denied, &ping);
      ++g_ts.samples;
      const float k = (float)g_ctl.slamBuzzPct * 0.01f;
      if (started) {
        g_ts.lastLen = g_trigSlam.lastLen;
        fight_slam_note(1, g_trigSlam.fx, g_trigSlam.fy);
        slam_assist_request((long long)qpc_now());   // 1.7.24: the slam helper (engine_hooks.cpp) logs the game's capture/slam state and, if needed, asks the game to start the slam
        if (k > 0.0f) { haptics_add(1, hap::kSrcSlam, 1.0f * k, 220); haptics_add(0, hap::kSrcSlam, 0.8f * k, 180); ++g_ts.buzzed; }
        if (g_ts.logged < 60) { ++g_ts.logged; log_line("SLAMTRIG #%ld: left trigger squeezed to %d%% (capture button %s) with the meter full and %s -> the probe holds capture for %.2f s, keeps fire unchanged and requests the native slam (extra fire duration %.2f s, sequence %d)%s (pull: side %.2f, up %.2f, strongest hand move in the last 1.5 s: %.0f cm)",
                                                    g_trigSlam.slams, (int)(hl.trigger * 100.0f), capture ? "down" : "UP", held > 0 ? "a ghost held" : "the held-ghost field not trusted yet", g_trigSlam.capHold, g_trigSlam.fireLen, (g_trigSlam.variant - 1) % 3 + 1, (g_trigSlam.fx != 0.0 || g_trigSlam.fy != 0.0) ? " and the aim stick flicked the way you pull" : ", no pull seen so the game slams downward by itself", g_trigSlam.fx, g_trigSlam.fy, g_trigSlam.lastLen * 100.0); }
      }
      if (ping && k > 0.0f) { haptics_add(1, hap::kSrcSlam, 0.35f * k, 70); haptics_add(0, hap::kSrcSlam, 0.35f * k, 70); }   // 1.7.2: the meter just filled: a short double tap says "now you can slam" (let go of the trigger and squeeze it again)
      if (denied) {
        if (k > 0.0f) haptics_add(0, hap::kSrcSlam, denied == 2 ? 0.15f * k : 0.25f * k, 45);
        if (g_ts.logged < 60 && ((denied == 1 ? g_trigSlam.denied : g_trigSlam.noGhost) % 20) == 1) { ++g_ts.logged; log_line(denied == 2 ? "SLAMTRIG the left trigger was squeezed all the way and the meter reads full, but the game says the stream holds no ghost: nothing to slam" : "SLAMTRIG the left trigger was squeezed all the way but the slam meter is not full (keep the stream on the ghost and tug it until it fills)"); }
      }
      if (force) { s.pad.buttons |= pad::kLeftShoulder; ++g_ts.capHeldPolls; if (!capture) ++g_ts.capForcedPolls; }   // 1.7.2: the game must see capture AND fire together, even after a quick tap
      if (g_trigSlam.releaseNow) { if (s.pad.rt > 0) ++g_ts.releasedHeld; s.pad.rt = 0; ++g_ts.releaseFrames; }   // 1.7.23: fire is let go first, so the press below is a NEW press for the game
      { static int s_prevPress; if (press && !s_prevPress && k > 0.0f) { haptics_add(1, hap::kSrcSlam, 1.0f * k, 140); haptics_add(0, hap::kSrcSlam, 0.7f * k, 100); }   // 1.7.23 gun feel: a hard thump in both hands at the instant the slam press really happens
        s_prevPress = press; }
      if (press) { if (s.pad.rt < 255) s.pad.rt = 255; ++g_ts.pressFrames; }
      if ((sx != 0.0 || sy != 0.0) && g_ctl.slamFlickPct > 0) {
        s.pad.rx = pad::axis16(sx * (double)g_ctl.slamFlickPct * 0.01);
        s.pad.ry = pad::axis16(sy * (double)g_ctl.slamFlickPct * 0.01);
        slamStickSet = 1; ++g_ts.flickFrames;
      }
    } else { g_pull.reset(); s_tsQpc = 0; g_trigSlam.prevHot = 0; g_trigSlam.prevSq = 0; g_trigSlam.sqAge = 99.0; }
  }
  // ---- 0.76 slam swing: with the capture stream held (right stick click in the current layout), a quick down-swing of the gun hand presses the fire trigger for a moment.
  // That is exactly the game's slam (capture held + fire pressed + full slam meter); the swing just does the trigger press for you.
  {
    static int s_swInit; static int s_swLogged;
    if (!s_swInit) { g_sweep.reset(); g_sweep.sweeps = 0; g_sweep.maxSpeed = 0; s_swInit = 1; }
    if (g_ctl.slamGesture && r.valid && haveHeadP && !g_holster.holstered && !vrmenu_is_open() && !g_wheel.open) {
      const double pos[3] = {(double)r.pose34[3] - headP[3], (double)r.pose34[7] - headP[7], (double)r.pose34[11] - headP[11]};   // relative to the head: walking or ducking is not a sweep
      const double right[3] = {headP[0], headP[4], headP[8]}, up[3] = {headP[1], headP[5], headP[9]};                                // the head's own right and up
      const double dt = g_sweepQpc ? (double)(s.qpc - g_sweepQpc) / (double)qpc_freq() : 0.011;
      g_sweepQpc = s.qpc;
      const int capture = (s.pad.buttons & pad::kLeftShoulder) != 0;
      const long before = g_sweep.sweeps;
      double fx = 0, fy = 0;
      const int press = g_sweep.update(dt, pos, capture, (double)g_ctl.slamSpeedDeci / 10.0, right, up, &fx, &fy);
      const double spd = vm::dsqrt(g_sweep.v[0] * g_sweep.v[0] + g_sweep.v[1] * g_sweep.v[1] + g_sweep.v[2] * g_sweep.v[2]);
      if (capture) { InterlockedIncrement(&g_cs.slamCaptureSamples); if (spd * 100.0 > g_cs.slamMaxSpeedX100) g_cs.slamMaxSpeedX100 = (LONG)(spd * 100.0); }
      if (g_sweep.sweeps != before) {
        const int ready = fight_slam_ready();
        InterlockedIncrement(&g_cs.slamSwings);
        if (!ready) InterlockedIncrement(&g_cs.slamSwingsNoMeter);
        ++g_gs.sweeps;
        haptics_add(1, ready ? hap::kSrcBlast : hap::kSrcMark, ready ? 1.0f : 0.3f, ready ? 140 : 60);
        if (ready) haptics_add(0, hap::kSrcBlast, 0.6f, 120);
        if (s_swLogged < 60) { ++s_swLogged; log_line("SLAM sweep #%ld: hand speed %.1f m/s, side %.2f up %.2f (head axes), slam meter %s -> fire is pressed for 0.45 s%s", g_sweep.sweeps, spd, g_sweep.fx, g_sweep.fy, ready ? "FULL (a slam should start)" : "not full (no slam yet)",
                                                   (g_ctl.slamFlickPct > 0 && (g_sweep.fx != 0 || g_sweep.fy != 0)) ? " and the aim stick is flicked that way for 0.3 s" : ""); }
      }
      if (press) { if (s.pad.rt < 255) s.pad.rt = 255; InterlockedIncrement(&g_cs.slamPressSamples); }
      if ((fx != 0 || fy != 0) && g_ctl.slamFlickPct > 0) {   // the game slams toward the side the aim stick points: flick it toward the side the gun went
        s.pad.rx = pad::axis16(fx * (double)g_ctl.slamFlickPct * 0.01);
        s.pad.ry = pad::axis16(fy * (double)g_ctl.slamFlickPct * 0.01);
        slamStickSet = 1;
      }
    } else { g_sweep.reset(); g_sweepQpc = 0; }
  }
  s.pad.buttons |= (uint16_t)autopause_buttons();   // 0.52: the auto-pause presses Start
  s.holstered = g_holster.holstered;
  {  // 1.5 snap turn (flick the right stick) and the push that makes the body follow your head (engine_hooks.cpp decides how hard)
    const int dpadMode = config().dpadWithGrip && hl.valid && hl.away && pad::vr_pressed(l.pressed, pad::kVrGrip);   // the right stick is the D-pad then
    const int blocked = layerOn || dpadMode || s.wheelOpen || vrmenu_is_open() || !inGame;
    const double mx = r.valid ? (double)r.stickX : 0.0, my = r.valid ? (double)r.stickY : 0.0;
    g_turnUserMag = (LONG)(vm::dsqrt(mx * mx + my * my) * 1000.0);
    g_turnBlocked = blocked;
    g_moveMag = (LONG)(vm::dsqrt((double)s.pad.lx * (double)s.pad.lx + (double)s.pad.ly * (double)s.pad.ly) / 32767.0 * 1000.0);
    const int snapOn = g_ctl.turnSnap;   // 1.7.8: always (1.7.6 gave snap up after two misses and let the real stick through; the game never answered it either: "right stick did not work")
    if (snapOn && r.valid && !blocked) {
      const int dir = follow::flick(g_flick, mx, my);
      if (dir) {
        ++g_snapFlicks;
        follow_snap_request(dir);
        haptics_add(1, hap::kSrcButton, 0.30f, 22);
        if (g_snapFlicks <= 12) log_line("TURNPAD snap flick #%ld: right stick %s (x %.2f, y %.2f) -> one step of %d deg asked", g_snapFlicks, dir > 0 ? "RIGHT" : "LEFT", mx, my, (int)g_ctl.turnSnapDeg);
      }
      if (!slamStickSet) s.pad.rx = 0;   // the game's own smooth turn is off while the stick snaps (the slam swing's own flick stays)
    } else if (!snapOn && g_ctl.turnSmoothOwn && r.valid && !blocked) {
      // 1.7.81 SMOOTH TURN made by the mod: hold the right stick sideways and the picture turns steadily (the body follows, like after a snap). The game's own stick turn is off meanwhile,
      // otherwise both would turn you. followmath.h smooth_deg has the dead zone, the ramp and the limits.
      const double dtS = g_smQpc ? (double)(s.qpc - g_smQpc) / (double)qpc_freq() : 0.011;
      g_smQpc = s.qpc;
      const double dg = follow::smooth_deg(mx, my, (double)g_ctl.turnSmoothDps, dtS);
      ++g_smPolls;
      if (dg != 0.0) { ++g_smTurnPolls; g_smDegTotal += dg < 0 ? -dg : dg; follow_smooth_request(dg); }
      if (!slamStickSet) s.pad.rx = 0;
    } else if (blocked) {
      g_flick.armed = 0;
      if (snapOn && r.valid) ++g_snapBlocked;
    }
    if (snapOn || !g_ctl.turnSmoothOwn || blocked || !r.valid) g_smQpc = 0;   // a gap in smoothing: the next poll starts a fresh time step
    const float push = follow_push_get();
    if (push != 0.0f && !blocked && s.pad.rx == 0) {   // your own push (smooth turn) always wins
      s.pad.rx = pad::axis16(push);
      ++g_pushFrames;
    }
    // 1.7.8 WALK WHERE THE HEAD POINTS. The 1.7.5 / 1.7.7 reports: the game's heading stayed the same for the whole session, so the left stick walked relative to a heading you were not looking
    // along. The stick is turned by the head's angle from that heading, so the game walks along the head whatever its camera does.
    if (g_ctl.walkHead && l.valid && !blocked && (s.pad.lx != 0 || s.pad.ly != 0)) {
      double e = 0.0;
      if (follow_head_yaw(&e)) {
        double ox, oy;
        follow::rotate_stick((double)s.pad.lx, (double)s.pad.ly, e, &ox, &oy);
        ox = ox > 32767.0 ? 32767.0 : ox < -32767.0 ? -32767.0 : ox; oy = oy > 32767.0 ? 32767.0 : oy < -32767.0 ? -32767.0 : oy;
        s.pad.lx = (decltype(s.pad.lx))ox; s.pad.ly = (decltype(s.pad.ly))oy;
        const double ae = e < 0 ? -e : e;
        ++g_walkRotFrames; g_walkRotSumDeg += ae * 57.29578; if (ae * 57.29578 > g_walkRotMaxDeg) g_walkRotMaxDeg = ae * 57.29578;
        if (ae > 0.1745) ++g_walkRot10; if (ae > 0.6109) ++g_walkRot35; if (ae > 1.5708) ++g_walkRot90;
        if (g_walkRotLogged < 12 && ae > 0.6109) { ++g_walkRotLogged; log_line("WALKHEAD the left stick is turned by %.0f deg (head from the game's heading): you walk where the headset points", e * 57.29578); }
      } else ++g_walkRotStale;
    }
  }
  {  // 0.48 marker: both grips and both stick clicks together = "something happened now" (log MARK + snapshot, a buzz in both hands)
    static int s_markHeld;
    const int all = l.valid && r.valid && pad::vr_pressed(l.pressed, pad::kVrGrip) && pad::vr_pressed(r.pressed, pad::kVrGrip) &&
                    pad::vr_pressed(l.pressed, pad::kVrStick) && pad::vr_pressed(r.pressed, pad::kVrStick);
    if (all && !s_markHeld) { probe_mark("controllers"); haptics_add(0, hap::kSrcMark, 1.0f, 300); haptics_add(1, hap::kSrcMark, 1.0f, 300); }
    s_markHeld = all;
  }
  // ---- 0.51 wand pose with weight ------------------------------------------------------------------
  {
    int64_t q = s.qpc;
    double dt = g_wPrevQpc ? (double)(q - g_wPrevQpc) / (double)qpc_freq() : 0.0;
    g_wPrevQpc = q;
    if (r.valid) {
      float two[12];
      const int pkeOut = engine_pke_item();
      // 1.7.74 two-hand hold debounced (walking made it flicker on/off): it starts after 3 good polls in a row, and once on, the left hand may drift 25 % farther before it lets go
      static int s_twoOn; static hand::SupportHold s_twoHold; static long s_twoFlips;
      const double maxD = (double)g_ctl.dpadAwayCm / 100.0 * (s_twoOn ? 1.25 : 1.0);
      // Use the same confirmed proximity hold as the visible support hand.
      // Do not synthesize a grip button: that would also trigger trap/menu/vent
      // actions and the Index A-button workaround.
      const int contactSupport = g_ctl.foreGrab && g_ctl.foreNearCm > 0 &&
          inGame && !g_holster.holstered && !g_trap.held && !s.wheelOpen &&
          !vrmenu_is_open() && !held_menu_active() && engine_offhand_support();
      const int requested = hand::support_requested(pad::vr_pressed(l.pressed, pad::kVrGrip), contactSupport, g_ctl.twoHandLine);
      const int twoRaw = !pkeOut && l.valid && requested && hand::two_hand_pose_ref(r.pose34, l.pose34, s_twoOn ? 0.08 : 0.12, maxD, (double)g_ctl.twoHandPitchDeci / 10.0, (double)g_ctl.twoHandRefCm / 100.0, two);
      const int twoNow = s_twoHold.step(requested, twoRaw);
      if (twoNow != s_twoOn) { s_twoOn = twoNow; ++s_twoFlips; g_twoFlips = s_twoFlips; }
      const int twoOk = twoNow;
      { static int wasContact; static long nContact;
        if (twoOk && contactSupport && !g_ctl.twoHandLine && !wasContact && ++nContact <= 12)
          log_line("GRAB support #%ld: confirmed barrel contact supplies two-hand steadiness (legacy grip button not required)", nContact);
        wasContact = twoOk && contactSupport && !g_ctl.twoHandLine;
      }
      // A confirmed two-hand hold steers the beam along both hands by default; two_hand_line=0 keeps the right-controller-only choice.
      const int lineOn = twoOk && g_ctl.twoHandLine;
      const float* base = lineOn ? two : r.pose34;
      double tgt[9], out[9];
      for (int i = 0; i < 9; ++i) tgt[i] = base[(i / 3) * 4 + (i % 3)];
      // LT stays native alternate fire. Capture/wrangle is right-stick click;
      // only the gun's real fire trigger adds recoil to the held weapon.
      const int firing = s.pad.rt > 60;
      if (firing && !g_ctl.gunFireFx) InterlockedExchange64(&g_fireHoldQ, qpc_now());   // 1.7.177: the game's own firing animation of the body is kept off the view while the trigger is down
      const int firingFx = firing && g_ctl.gunFireFx;   // 1.7.173 "firing has too much effect on the viewmodel, get rid of it": off by default
      const int raised = (-tgt[5]) > -0.57;   // pointing less than 35 degrees below level
      weight::Params wp = {(double)g_ctl.gunWeightPct / 100.0, (double)g_ctl.gunTwistPct / 100.0};
      wp.punish = (double)g_ctl.gunPunishPct / 100.0;   // 0.95: how hard a one-handed shot is
      int firingW = firingFx;
      if (pkeOut) {   // 0.95: the PKE has a little weight of its own (0.94: none) - a light device: some inertia and give, no recoil or kick
        wp = weight::pke_params((double)g_ctl.pkeWeightPct, (double)g_ctl.gunTwistPct / 100.0);
        firingW = 0;
      }
      // Keep the grip position on the controller. During a one-handed shot the
      // muzzle can climb and shake, but a resting gun and the PKE stay rigid.
      int raisedW = raised;
      if (g_ctl.handLock) {   // 1.7.155: the gun has its weight and its one-handed punishment again (rotation only; see weight::locked_params). The PKE stays rigid.
        wp = weight::locked_params((double)g_ctl.gunWeightPct, (double)g_ctl.gunPunishPct, pkeOut, firingFx, raised, &raisedW);
        // 1.7.177 "the weight and the one-hand punishment are gone": they are back without the trigger: the gun is heavier to turn and loose with ONE hand even when not firing
        // (looseOne), the arm slowly tires while it is held up one-handed. Firing itself still moves nothing (firingFx stays gun_fire_fx).
        if (!pkeOut) { wp.looseOne = 1.0; if (!g_ctl.gunFireFx) raisedW = raised; }
        if (wp.heaviness <= 0.001) g_wState.reset();
      }
      weight::Out wi;
      if (g_holster.holstered) g_wState.have = 0;   // drawn again: start from the hand
      weight::step(&g_wState, wp, tgt, dt, twoOk, firingW, raisedW, out, &wi);
      {  // 1.7.36 knock-down comfort: a harder aim (the gun sways) while the fall that was skipped would have lasted
        const double ks = engine_knock_strength();
        if (ks > 0.0 && g_ctl.knockAimDeg > 0 && !pkeOut) {
          double yawD, pitD; knock::sway(engine_knock_time_sec(), ks, (double)g_ctl.knockAimDeg, &yawD, &pitD);
          double sy, cy, sp, cp; vm::dsincos(yawD * 0.017453292519943295, &sy, &cy); vm::dsincos(pitD * 0.017453292519943295, &sp, &cp);
          const double R[9] = {cy, sy * sp, sy * cp,  0.0, cp, -sp,  -sy, cy * sp, cy * cp};
          double o2[9];
          for (int r2 = 0; r2 < 3; ++r2) for (int c2 = 0; c2 < 3; ++c2) o2[r2 * 3 + c2] = R[r2 * 3] * out[c2] + R[r2 * 3 + 1] * out[3 + c2] + R[r2 * 3 + 2] * out[6 + c2];
          for (int i = 0; i < 9; ++i) out[i] = o2[i];
        }
        // 1.7.190 "arms slower for about 3 seconds": the gun's turn trails the controller (a low-pass on its rotation, the lag is longest at the start and fades with the window)
        static double s_kPrev[9]; static int s_kHave;
        if (ks > 0.0 && !pkeOut) {
          const double tau = 0.40 * ks, al = dt / (dt + tau);   // 1.7.200: 0.22 -> 0.40, the arms follow you visibly slower for the knock-down
          if (!s_kHave) { for (int i = 0; i < 9; ++i) s_kPrev[i] = out[i]; s_kHave = 1; }
          else {
            double m[9];
            for (int i = 0; i < 9; ++i) m[i] = s_kPrev[i] + (out[i] - s_kPrev[i]) * al;
            // back to a clean rotation: row 0 unit, row 1 made square to it, row 2 their cross product
            double l0 = vm::dsqrt(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]);
            if (l0 > 1e-6) {
              for (int i = 0; i < 3; ++i) m[i] /= l0;
              const double d = m[3] * m[0] + m[4] * m[1] + m[5] * m[2];
              for (int i = 0; i < 3; ++i) m[3 + i] -= d * m[i];
              const double l1 = vm::dsqrt(m[3] * m[3] + m[4] * m[4] + m[5] * m[5]);
              if (l1 > 1e-6) {
                for (int i = 0; i < 3; ++i) m[3 + i] /= l1;
                const double e0 = m[6] * m[0] + m[7] * m[1] + m[8] * m[2], e1 = m[6] * m[3] + m[7] * m[4] + m[8] * m[5];   // the third row squared to the first two (keeps the hand-ness of the input)
                for (int i = 0; i < 3; ++i) m[6 + i] -= e0 * m[i] + e1 * m[3 + i];
                const double l2 = vm::dsqrt(m[6] * m[6] + m[7] * m[7] + m[8] * m[8]);
                if (l2 > 1e-6) { for (int i = 0; i < 3; ++i) m[6 + i] /= l2; for (int i = 0; i < 9; ++i) { s_kPrev[i] = m[i]; out[i] = m[i]; } }
                else { for (int i = 0; i < 9; ++i) s_kPrev[i] = out[i]; }
              } else { for (int i = 0; i < 9; ++i) s_kPrev[i] = out[i]; }
            } else { for (int i = 0; i < 9; ++i) s_kPrev[i] = out[i]; }
          }
        } else s_kHave = 0;
      }
      // 0.58 the gun is also hard to move: its position (relative to the head, so walking drags nothing) trails a quick sweep
      double gpos[3] = {base[3], base[7], base[11]};
      {
        float hp[12];
        if (g_holster.holstered) g_pState.have = 0;
        if (vr_capi_hmd_pose(hp, nullptr)) {
          const double rel[3] = {gpos[0] - hp[3], gpos[1] - hp[7], gpos[2] - hp[11]};
          double o[3];
          const double lag = weight::step_pos(&g_pState, g_ctl.handLock ? 0.0 : wp.heaviness, rel, dt, g_wState.two, o, g_wState.stiff, wp.punish);
          for (int i = 0; i < 3; ++i) gpos[i] = (i == 0 ? hp[3] : i == 1 ? hp[7] : hp[11]) + o[i];
          const LONG mm = (LONG)(lag * 1000.0);
          InterlockedIncrement(&g_cs.wPosN);
          InterlockedExchangeAdd(&g_cs.wPosLagSumMm, mm);
          if (mm > g_cs.wPosLagMaxMm) g_cs.wPosLagMaxMm = mm;
          if (lag >= weight::kPosCapM * 0.98) InterlockedIncrement(&g_cs.wPosCapped);
        } else g_pState.have = 0;
      }
      for (int rr = 0; rr < 3; ++rr) { for (int c = 0; c < 3; ++c) s.wandPose[rr * 4 + c] = (float)out[rr * 3 + c]; s.wandPose[rr * 4 + 3] = (float)gpos[rr]; }
      s.wandTwo = lineOn;   // 1.7.113: 1 only when the aim really runs along the line between the hands (the hand-pitch offset is skipped then)
      s.wandValid = vr_pose_to_engine_local(s.wandPose, s.wandRot, s.wandPos) ? 1 : 0;
      // statistics
      int k = twoOk ? 1 : 0;
      LONG lag100 = (LONG)(wi.lagDeg * 100.0);
      if (!pkeOut) {   // 0.95: these are the GUN's figures (the PKE has its own below)
        InterlockedIncrement(&g_cs.wN[k]);
        InterlockedExchangeAdd(&g_cs.wLagSumX100[k], lag100);
        if (lag100 > g_cs.wLagMaxX100[k]) g_cs.wLagMaxX100[k] = lag100;
      }
      if (firing && !pkeOut) { InterlockedIncrement(&g_cs.wFireN[k]); InterlockedExchangeAdd(&g_cs.wFireLagSumX100[k], lag100); }
      if (pkeOut) {   // 0.95 data for the PKE's weight
        InterlockedIncrement(&g_cs.wPkeN);
        InterlockedExchangeAdd(&g_cs.wPkeLagSumX100, lag100);
        if (lag100 > g_cs.wPkeLagMaxX100) g_cs.wPkeLagMaxX100 = lag100;
        if (lag100 > 500) InterlockedIncrement(&g_cs.wPkeLagOverX100);
      } else if (firing && !twoOk) {   // 0.95 data for one-handed shots
        InterlockedIncrement(&g_cs.wOneFireN);
        const LONG sw = (LONG)(wi.swayDeg * 100.0), rc = (LONG)(wi.recoilDeg * 100.0), st = (LONG)(wi.strain * 100.0);
        InterlockedExchangeAdd(&g_cs.wOneFireSwaySumX100, sw);
        if (sw > g_cs.wOneFireSwayMaxX100) g_cs.wOneFireSwayMaxX100 = sw;
        if (rc > g_cs.wOneFireRecMaxX100) g_cs.wOneFireRecMaxX100 = rc;
        if (st > g_cs.wStrainMaxX100) g_cs.wStrainMaxX100 = st;
      }
      if ((LONG)(wi.fatigue * 100.0) > g_cs.wFatigueMaxX100) g_cs.wFatigueMaxX100 = (LONG)(wi.fatigue * 100.0);
      if (twoOk && !g_prevTwo) { InterlockedIncrement(&g_cs.wEngage); haptics_add(0, hap::kSrcTwoHand, 0.6f, 60); haptics_add(1, hap::kSrcTwoHand, 0.4f, 60); }
      if (!twoOk && g_prevTwo) haptics_add(1, hap::kSrcTwoHand, 0.25f, 40);   // 0.75: a soft tick in the gun hand when the off hand lets go (the gun gets light again)
      g_prevTwo = twoOk;
      // hands-free sag figures (level pointing): droop in hundredths of a degree
      if (wi.droopDeg > 0) { if (twoOk) g_cs.wSag2X100 = (LONG)(wi.droopDeg * 100.0); else g_cs.wSag1X100 = (LONG)(wi.droopDeg * 100.0); }
    } else {
      g_wState.have = 0; g_prevTwo = 0; g_pState.have = 0;
    }
  }
  // ---- 0.51 controller motors -----------------------------------------------------------------------
  {
    if (!g_helloDone && (l.valid || r.valid)) { g_helloDone = 1; haptics_test(0); }
    const double nowS = (double)s.qpc / (double)qpc_freq();
    const int rt = s.pad.rt > 60, lt = s.pad.lt > 60;
    const int twoNow = g_prevTwo;
    static double s_fireStart; static int s_kickPending, s_streamWas;
    // 0.79: the buzz only plays while the game REALLY fires (the player's stream is updating). Where the game refuses to fire (cutscene, no-fire zone) the gun stays quiet.
    // 1.7.36: the stream detection is flaky (it missed shots one- and two-handed), so the gun now ALWAYS rumbles when the trigger is down, except where the game truly will not fire:
    // PKE out, gun holstered, a menu or frozen world, a cutscene walk. A real stream seen in the last 600 ms also counts (covers the cases above where the detection is right).
    const int realStream = engine_stream_recent(600);
    const int fireOk = !engine_pke_item() && !g_holster.holstered && !vrmenu_is_open() && !engine_freeze_active() && !engine_player_forced();
    const int streaming = realStream || fireOk;
    {   // per-pull log: did the real stream show up, or did the fallback carry the rumble
      static int s_pullWas; static double s_pullT; static int s_pullLogged; static long s_pulls, s_viaFallback;
      if (rt && !s_pullWas) { s_pullT = nowS; ++s_pulls; }
      if (rt && s_pullWas == 0) s_pullWas = 1;
      if (rt && s_pullWas == 1 && nowS - s_pullT > 0.35) { s_pullWas = 2; if (!engine_stream_recent(400)) ++s_viaFallback;
        if (s_pullLogged < 60) { ++s_pullLogged; log_line("FIRERUMBLE pull #%ld: real stream within 400 ms of the 0.35 s mark=%d, rumble played=%d (fireOk %d: pke=%d holstered=%d menu=%d freeze=%d forced=%d, two hands %d; %ld of %ld pulls so far needed the fallback)",
          s_pulls, engine_stream_recent(400), streaming, fireOk, engine_pke_item(), (int)g_holster.holstered, vrmenu_is_open(), engine_freeze_active(), engine_player_forced(), (int)g_prevTwo, s_viaFallback, s_pulls); } }
      if (!rt) s_pullWas = 0;
    }
    if (rt && !g_prevRt) { s_fireStart = nowS; s_kickPending = 1; }
    if (!rt) s_kickPending = 0;
    if (!rt && g_prevRt && s_streamWas) {   // 0.52: a small tick when the stream stops; 1.2: it is a thud that grows with how long you fired, then a soft tail (the pack settling)
      double run = nowS - s_fireStart; if (run < 0.0) run = 0.0; if (run > 3.0) run = 3.0;
      float k = (float)(run / 3.0);
      haptics_add(1, hap::kSrcFireKick, 0.30f + 0.30f * k, 45);
      haptics_add(1, hap::kSrcTrigger, 0.12f + 0.10f * k, 150);
      if (twoNow) haptics_add(0, hap::kSrcTrigger, 0.10f + 0.08f * k, 120);
    }
    if (rt && s_kickPending && streaming) {   // the kick comes with the first stream update (a trigger pull the game ignores gives nothing)
      s_kickPending = 0;
      haptics_add(1, hap::kSrcFireKick, twoNow ? 0.70f : 0.95f, 55);
      if (twoNow) haptics_add(0, hap::kSrcFireKick, 0.45f, 55);
    }
    if (rt && streaming) {   // the stream: a buzz with a rhythm, the off hand feels half of it
      double ph = nowS * 11.0; ph -= (double)(long long)ph;
      double swell = (nowS - s_fireStart) / 3.0; if (swell > 1.0) swell = 1.0; if (swell < 0.0) swell = 0.0;   // 0.52: the buzz grows the longer the stream runs (the pack gets hot)
      float lv = (float)(0.22 + 0.10 * swell + (ph < 0.5 ? 0.18 : 0.0));
      if (!twoNow && !engine_pke_item()) lv += (float)(0.14 * g_wState.strain * (double)(g_ctl.gunPunishPct > 100 ? 100 : g_ctl.gunPunishPct) / 100.0);   // 0.95: a one-handed burst makes the arm tremble: the buzz grows with the strain
      {   // 1.3: the stream spins up (a soft start over 0.3 s, after the kick) and, once the pack is hot (1.8 s+), throbs slowly on top
        const double since = nowS - s_fireStart;
        const double ramp = since < 0.0 ? 0.0 : since > 0.30 ? 1.0 : since / 0.30;
        lv *= (float)(0.60 + 0.40 * ramp);
        if (since > 1.8) { double th = nowS * 2.2; th -= (double)(long long)th; lv += (float)(th < 0.5 ? 0.07 : -0.03); }
      }
      {   // 1.4: hits you can feel: while a ghost is losing health under the stream (a health drop in the last 0.35 s) the buzz gets a quick bright flutter on top; it fades out over 0.35 s after the last hit
        const int hitMs = fight_hit_age_ms();
        if (hitMs >= 0 && hitMs < 350 && !engine_pke_item()) {
          double fl = nowS * 14.0; fl -= (double)(long long)fl;
          const double fade = 1.0 - (double)hitMs / 350.0;
          lv += (float)((fl < 0.5 ? 0.12 : 0.03) * fade);
        }
      }
      if (lv > 1.0f) lv = 1.0f;
      if (lv < 0.0f) lv = 0.0f;
      haptics_add(1, hap::kSrcFireHold, lv, 90);
      if (twoNow) haptics_add(0, hap::kSrcFireHold, lv * 0.5f, 90);
    }
    s_streamWas = rt && streaming;
    if (rt && !streaming) { static long s_mute; if (++s_mute % 600 == 1) log_line("FIREQUIET trigger down but the game fires no stream (cutscene or no-fire zone): no vibration (%ld samples so far)", s_mute); }
    {   // 1.7.57 CAPWHY: why a grab does or does not happen. While the Capture button (normal right stick click = LB) is down: twice a second, log targets and slam state
      static double s_capT; static long s_capLogged, s_capLines;
      { static int s_capWas; const int cn = bindings_capture_down(); if (cn && !s_capWas) { s_capT = 0.0; ++s_capLogged; } s_capWas = cn; }
      const int capNow = bindings_capture_down();
      if (capNow && s_capLines < 120 && nowS - s_capT >= 0.5) {
        s_capT = nowS;
        fight::Bar bars[fight::kMaxBars]; int64_t bq = 0;
        const int nb = fight_bars_read(bars, fight::kMaxBars, &bq);
        char buf[420]; int o = 0; int shown = 0;
        for (int i = 0; i < nb && shown < 4; ++i) {
          const double d = vm::dsqrt((double)bars[i].p[0] * bars[i].p[0] + (double)bars[i].p[1] * bars[i].p[1] + (double)bars[i].p[2] * bars[i].p[2]);
          if (!(d > 0.05)) continue;
          const double c = (double)bars[i].p[2] / d;   // cos of the angle from the head's forward
          double a = 0.0; { const double c2 = c > 1.0 ? 1.0 : c < -1.0 ? -1.0 : c; const double sn = vm::dsqrt(1.0 - c2 * c2); a = vm::datan2(sn, c2) * 57.29577951308232; }
          o += wsprintfA(buf + o, "%s%d deg/%d.%d m/%d%%", shown ? "; " : "", (int)a, (int)d, (int)(d * 10.0) % 10, (int)(bars[i].frac * 100.0f));
          ++shown;
        }
        if (!shown) lstrcpyA(buf, "none in view");
        ++s_capLines;
        log_line("CAPWHY pull #%ld: capture held; ghosts with bars in view: %s | held-ghost test %d (1 = a ghost is locked, 0 = nothing, -1 = not trusted) | slam meter %s | rt %d | PKE out %d, holstered %d, flat %d",
                 s_capLogged, buf, fight_wrangled(), fight_slam_ready() ? "FULL" : "not full", (int)s.pad.rt, engine_pke_item(), (int)g_holster.holstered, vrmenu_is_open());
      }
    }
    if (lt && !g_prevLt) { haptics_add(1, hap::kSrcBlast, 1.0f, 110); haptics_add(0, hap::kSrcBlast, twoNow ? 0.7f : 0.3f, 110); }
    g_prevRt = rt; g_prevLt = lt;
    // a short tick for every other button press, on the hand that pressed it
    const uint64_t trigBit = 1ull << pad::kVrTrigger;
    uint64_t nl = l.pressed & ~g_prevPressL & ~trigBit, nr = r.pressed & ~g_prevPressR & ~trigBit;
    if (l.valid && nl) haptics_add(0, hap::kSrcButton, 0.40f, 28);
    if (r.valid && nr) haptics_add(1, hap::kSrcButton, 0.40f, 28);
    g_prevPressL = l.pressed; g_prevPressR = r.pressed;
  }
  if (l.valid) {
    for (int i = 0; i < 12; ++i) s.poseL[i] = l.pose34[i];
    s.trigL = l.trigger; s.gripAnaL = l.grip; s.thumbTL = l.thumbTouch; s.trigTL = l.trigTouch;
    note_buttons("left", rawPressedL, &g_cs.seenL);
    if (!vr_pose_to_engine_local(l.pose34, s.rotL, s.posL)) s.validL = 0;
    if (l.trigger > g_cs.maxTrig[0]) g_cs.maxTrig[0] = l.trigger;
  }
  if (r.valid) {
    for (int i = 0; i < 12; ++i) s.poseR[i] = r.pose34[i];
    s.trigR = r.trigger; s.gripAnaR = r.grip; s.thumbTR = r.thumbTouch; s.trigTR = r.trigTouch;
    note_buttons("right", rawPressedR, &g_cs.seenR);
    if (!vr_pose_to_engine_local(r.pose34, s.rotR, s.posR)) s.validR = 0;
    if (r.trigger > g_cs.maxTrig[1]) g_cs.maxTrig[1] = r.trigger;
  }
  if (s.validL != g_cs.lastValidL || s.validR != g_cs.lastValidR) {
    log_line("CONTROLLERS tracked: left=%d right=%d", s.validL, s.validR);
    g_cs.lastValidL = s.validL; g_cs.lastValidR = s.validR;
  }
  {   // 1.7.87: no controller at all for a long stretch is almost always a Virtual Desktop / Quest setting, not the mod: say so once, in plain words
    static int64_t s_lastAnyQ; static int s_noCtlHint;
    const int64_t nq = qpc_now();
    if (!s_lastAnyQ || s.validL || s.validR) s_lastAnyQ = nq;
    else if (!s_noCtlHint && (nq - s_lastAnyQ) > 25 * qpc_freq()) {
      s_noCtlHint = 1;
      log_line("ENVHINT SteamVR has reported no controller for 25 seconds, so the pad and the hands cannot work. Quest + Virtual Desktop: press a button on each controller to wake it, switch OFF hand tracking (Quest: Settings > Movement tracking > Hand tracking; Virtual Desktop: the hand tracking option) so the controllers are used, check their batteries, and make sure they show in SteamVR (its small window lists them).");
    }
  }
  {   // 1.7.85: INPUTFLOW data
    InterlockedOr(&g_flowButtons, (LONG)s.pad.buttons);
    g_flowRaw |= rawPressedL | rawPressedR;
    int st = 0; const int v[4] = {s.pad.lx, s.pad.ly, s.pad.rx, s.pad.ry};
    for (int i = 0; i < 4; ++i) { const int a = v[i] < 0 ? -v[i] : v[i]; if (a > st) st = a; }
    if (st > g_flowStick) InterlockedExchange(&g_flowStick, st);
  }
  bindings_sample(s.pad.lt > 60, s.pad.rt > 60);
  if (inGame && (s.pad.buttons & pad::kRightShoulder)) InterlockedExchange64(&g_reloadInputQ, s.qpc);
  bindings_pad((unsigned)s.pad.buttons, s.pad.lt, s.pad.rt);
  AcquireSRWLockExclusive(&g_lock);
  s.seq = ++g_snap.seq;
  g_snap = s;
  g_have = 1;
  ReleaseSRWLockExclusive(&g_lock);
  InterlockedIncrement(&g_cs.published);

}

static int read_fresh(Snap* out, int maxMs) {
  ZeroMemory(out, sizeof(*out));   // 0.33.1: never leave it uninitialised (0.33 fell off the end of controllers_report)
  AcquireSRWLockShared(&g_lock);
  int have = g_have;
  if (have) *out = g_snap;
  ReleaseSRWLockShared(&g_lock);
  if (!have) return 0;
  return (qpc_now() - out->qpc) * 1000 / qpc_freq() <= maxMs;
}

// Game thread: the pad state the controllers make right now. 0 if there is none
// (feature off, no controller tracked, or the snapshot is older than 250 ms).
int controllers_move_mag() { return (int)g_moveMag; }
int controllers_left_applied() { return (int)g_leftApplied; }
int controllers_sprint_want() { const int64_t q = g_sprintWantQ; return q && qpc_now() - q < qpc_freq() / 4; }   // 1.7.6
void controllers_turn_info(int* userMagX1000, int* blocked) {
  if (userMagX1000) *userMagX1000 = (int)g_turnUserMag;
  if (blocked) *blocked = (int)g_turnBlocked;
}

// 1.7.92: the same pad state without touching the "handed / missed" counters of the INPUTFLOW line (the stuck watch looks ten times a second and must not change what those count)
int controllers_pad_peek(pad::State* out) {
  if (!g_ctl.padEnabled) return 0;
  Snap s = {};
  if (!read_fresh(&s, 250) || (!s.validL && !s.validR)) return 0;
  *out = s.pad;
  return 1;
}
static volatile LONG64 g_padLastQ; static volatile LONG g_padGraceN;   // 1.7.166
int controllers_pad_state(pad::State* out) {
  if (!g_ctl.padEnabled) return 0;
  Snap s = {};
  if (!read_fresh(&s, 250) || (!s.validL && !s.validR)) { InterlockedIncrement(&g_flowPadMiss); return 0; }
  *out = s.pad;
  InterlockedIncrement(&g_flowPadHit);
  InterlockedExchange64(&g_padLastQ, qpc_now());
  return 1;
}

// 1.7.166 "weird freeze when throwing the trap": the report showed both controllers losing tracking for 4.8 s right after the throw; the pad then
// vanished for the game, which paused with its own controller screen (a flat screen) and asked to reconnect. For a short loss the pad now stays
// connected to the game with nothing pressed, so the game keeps running and the hands come back on their own. After 10 s it is let go as before
// (headset off, controllers asleep).
int controllers_pad_grace(pad::State* out) {
  if (!g_ctl.padEnabled) return 0;
  const int64_t last = InterlockedCompareExchange64(&g_padLastQ, 0, 0);
  if (!last) return 0;
  const double ago = (double)(qpc_now() - last) / (double)qpc_freq();
  if (!(ago >= 0.0) || ago > 10.0) return 0;
  *out = pad::State();
  if (InterlockedIncrement(&g_padGraceN) == 1 || (g_padGraceN % 900) == 0) log_line("PADGRACE the controllers are not tracked (%.1f s): the game keeps a connected pad with nothing pressed, so it does not pause; %ld calls so far", ago, (long)g_padGraceN);
  return 1;
}

void controllers_set_rumble(unsigned left, unsigned right) {
  InterlockedExchange(&g_rumbleL, (LONG)left);
  InterlockedExchange(&g_rumbleR, (LONG)right);
  g_rumbleQpc = qpc_now();
  InterlockedIncrement(&g_cs.rumbleSets);
  // 0.51: every request is played at once for at least 100 ms (0.33-0.50 only looked at the latest value once per frame
  // and dropped anything the game switched on and off between two frames)
  LONG m = (LONG)(left > right ? left : right);
  g_cs.rumbleLast = m;
  if (m > g_cs.rumbleMax) g_cs.rumbleMax = m;
  double st = hap::rumble_strength(left, right);
  if (st > 0.0) {
    InterlockedIncrement(&g_cs.rumbleNonZero);
    haptics_add(1, hap::kSrcGame, (float)st, 120);
    haptics_add(0, hap::kSrcGame, (float)(st * 0.8), 120);
  }
}

// Hand aim in game-world axes. The left grip held (and the hands at least 12 cm
// apart) = aim along the line from the right hand to the left hand; otherwise
// the right controller's pointing direction, tilted by hand_pitch.
int controllers_hand_aim(const float* level, float* out) {
  Snap s = {};
  if (!read_fresh(&s, 120) || !s.validR) return 0;
  if (g_throwAimUntilQ > qpc_now() && pad::hand_forward_world(level, g_throwRot, 0.0, out)) return 1;   // 0.77: a trap was just thrown by hand: the game aims where the hand threw
  if (s.wandValid && pad::hand_forward_world(level, s.wandRot, s.wandTwo ? 0.0 : g_ctl.handPitchDeci / 10.0, out)) return 1;   // 0.51: the wand's (weighted) direction
  if (g_ctl.twoHandLine && s.validL && pad::vr_pressed(s.pressedL, pad::kVrGrip) &&
      pad::two_hand_line_world(level, s.posR, s.posL, 0.12, out))
    return 1;
  return pad::hand_forward_world(level, s.rotR, g_ctl.handPitchDeci / 10.0, out);
}

// Latest tracked hands for drawing (fresh within 120 ms). Returns 1 if either hand is usable.
int controllers_raw(HandsRaw* out) {
  ZeroMemory(out, sizeof(*out));
  Snap s = {};
  if (!g_ctl.padEnabled || !read_fresh(&s, 120)) return 0;
  out->sampleQ = s.qpc;
  out->validL = s.validL; out->validR = s.validR;
  for (int i = 0; i < 12; ++i) { out->poseL[i] = s.poseL[i]; out->poseR[i] = s.poseR[i]; }
  out->trigL = s.trigL; out->trigR = s.trigR;
  out->gripAnaL = s.gripAnaL; out->gripAnaR = s.gripAnaR; out->thumbTL = s.thumbTL; out->thumbTR = s.thumbTR; out->trigTL = s.trigTL; out->trigTR = s.trigTR;
  out->holstered = s.holstered;
  out->gripL = pad::vr_pressed(s.pressedL, pad::kVrGrip);
  out->gripR = pad::vr_pressed(s.pressedR, pad::kVrGrip);
  out->wandValid = s.wandValid && s.validR; out->wandTwo = s.wandTwo;
  for (int i = 0; i < 12; ++i) out->wandPose[i] = s.wandPose[i];
  out->wheelOpen = s.wheelOpen; out->wheelSel = s.wheelSel; out->wheelPicked = s.wheelPicked; out->wheelPickLocked = s.wheelPickLocked; out->trapHeld = s.trapHeld; out->stickX = s.stickX; out->stickY = s.stickY;
  out->wheelOpenT = s.wheelOpenT; out->wheelFlash = s.wheelFlash; out->wheelCurX = s.wheelCurX; out->wheelCurY = s.wheelCurY;
  for (int i = 0; i < 10; ++i) out->wheelHov[i] = s.wheelHov[i];
  for (int i = 0; i < 12; ++i) out->wheelPose[i] = s.wheelPose[i];
  return s.validL || s.validR;
}

int controllers_fire_hold_active() {   // 1.7.177: trigger down (or released less than 0.25 s ago) with gun_fire_fx=0
  const int64_t q = InterlockedCompareExchange64(&g_fireHoldQ, 0, 0);
  return !g_ctl.gunFireFx && q && aim::is_fresh(qpc_now(), q, qpc_freq(), 250);
}
int controllers_trap_held() { return g_trap.held; }
int controllers_trap_anim_active() {
  const int64_t q = InterlockedCompareExchange64(&g_trapInputQ, 0, 0);
  return g_ctl.trapNoAnim && q && aim::is_fresh(qpc_now(), q, qpc_freq(), 1500);
}
int controllers_reload_active() {
  const int64_t q = InterlockedCompareExchange64(&g_reloadInputQ, 0, 0);
  return q && aim::is_fresh(qpc_now(), q, qpc_freq(), 1500);
}
int controllers_alt_fire_active() {
  const int64_t q = InterlockedCompareExchange64(&g_altInputQ, 0, 0);
  return q && aim::is_fresh(qpc_now(), q, qpc_freq(), 700);
}
int controllers_holstered() {
  Snap s = {};
  return g_ctl.padEnabled && read_fresh(&s, 250) && s.holstered;
}

int controllers_active() {
  Snap s = {};
  return g_ctl.padEnabled && read_fresh(&s, 250) && (s.validL || s.validR);
}

static const char* ev_name(unsigned t) {
  switch (t) {
    case 100: return "TrackedDeviceActivated"; case 101: return "TrackedDeviceDeactivated"; case 102: return "TrackedDeviceUpdated";
    case 103: return "UserInteractionStarted"; case 104: return "UserInteractionEnded"; case 105: return "IpdChanged";
    case 106: return "EnterStandbyMode"; case 107: return "LeaveStandbyMode"; case 108: return "TrackedDeviceRoleChanged"; case 111: return "PropertyChanged";
    case 400: return "InputFocusCaptured"; case 401: return "InputFocusReleased"; case 404: return "SceneApplicationChanged"; case 406: return "InputFocusChanged";
    case 409: return "ActionBindingReloaded"; case 410: return "HideRenderModels"; case 411: return "ShowRenderModels"; case 412: return "SceneApplicationStateChanged";
    case 502: return "DashboardActivated"; case 503: return "DashboardDeactivated"; case 700: return "Quit"; case 701: return "ProcessQuit";
    case 800: return "ChaperoneDataHasChanged"; case 1306: return "ProcessConnected"; case 1307: return "ProcessDisconnected";
    case 1410: return "ChaperoneBoundsShown"; case 1411: return "ChaperoneBoundsHidden"; case 1412: return "DisplayDisconnected"; case 1413: return "DisplayReconnected";
    case 1414: return "HDCPError"; case 1415: return "ApplicationNotResponding"; case 1416: return "ApplicationResumed"; case 1417: return "OutOfVideoMemory";
    case 1418: return "DisplayModeNotSupported"; case 1420: return "RequestDisconnectReconnect";
    case 9000: return "HeadsetActivity:unknown"; case 9001: return "HeadsetActivity:idle"; case 9002: return "HeadsetActivity:worn";
    case 9003: return "HeadsetActivity:worn-timeout"; case 9004: return "HeadsetActivity:standby"; case 9005: return "HeadsetActivity:idle-timeout";
    default: return "?";
  }
}

void controllers_report(LONG frame) {
  Snap s = {};
  int fresh = read_fresh(&s, 250);
  log_line("TURNPAD frame=%d right stick turn=%s step=%ddeg | smooth: speed %d deg/s, polls %ld, turning polls %ld, %.0f deg asked | flicks=%ld (asked from the camera thread; each makes one step) blocked frames=%ld | push frames on the right stick axis=%ld | now: your push %d/1000, blocked %d",
           (int)frame, g_ctl.turnSnap ? "SNAP" : g_ctl.turnSmoothOwn ? "SMOOTH (made by the mod)" : "smooth (the game's own stick)", (int)g_ctl.turnSnapDeg, (int)g_ctl.turnSmoothDps, g_smPolls, g_smTurnPolls, g_smDegTotal, g_snapFlicks, g_snapBlocked, g_pushFrames, (int)g_turnUserMag, (int)g_turnBlocked);
  {  // 0.51: what SteamVR says about the headset and both controllers (first report, then every 12th: battery, role changes), and device / focus events
    static int s_devCalls;
    if (s_devCalls++ % 12 == 0) {
      static const char* const names[3] = {"headset", "leftController", "rightController"};
      char buf[900];
      for (int w = 0; w < 3; ++w) { vr_capi_device_report(buf, sizeof(buf), w); if (buf[0]) log_line("DEVICE frame=%d %s %s", (int)frame, names[w], buf); }
    }
    unsigned et, ed, ea;
    for (int i = 0; i < 40 && vr_capi_event_pop(&et, &ed, &ea); ++i) log_line("VREVENT %s (type %u) device=%u %u ms ago, frame=%d, inputAvailable=%d", ev_name(et), et, ed, ea, (int)frame, vr_capi_input_available());
  }
  {
    LONG n0 = g_cs.wN[0] ? g_cs.wN[0] : 1, n1 = g_cs.wN[1] ? g_cs.wN[1] : 1, f0 = g_cs.wFireN[0] ? g_cs.wFireN[0] : 1, f1 = g_cs.wFireN[1] ? g_cs.wFireN[1] : 1;
    log_line("WEIGHT frame=%d heaviness=%d%% twistLock=%d%% (gun only; the PKE has its own line WEIGHT2) polls(one/two hand)=%d/%d meanLagDeg(one/two)=%d.%02d/%d.%02d maxLagDeg=%d.%02d/%d.%02d "
             "posLagMm(mean/max/capped of polls)=%d/%d/%d firing(polls %d/%d meanLagDeg %d.%02d/%d.%02d) twoHandGrabs=%d maxFatigue=%d%% droopDeg(one/two)=%d.%02d/%d.%02d wandValid=%d two=%d",
             (int)frame, (int)g_ctl.gunWeightPct, (int)g_ctl.gunTwistPct, (int)g_cs.wN[0], (int)g_cs.wN[1],
             (int)(g_cs.wLagSumX100[0] / n0 / 100), (int)(g_cs.wLagSumX100[0] / n0 % 100), (int)(g_cs.wLagSumX100[1] / n1 / 100), (int)(g_cs.wLagSumX100[1] / n1 % 100),
             (int)(g_cs.wLagMaxX100[0] / 100), (int)(g_cs.wLagMaxX100[0] % 100), (int)(g_cs.wLagMaxX100[1] / 100), (int)(g_cs.wLagMaxX100[1] % 100),
             (int)(g_cs.wPosLagSumMm / (g_cs.wPosN ? g_cs.wPosN : 1)), (int)g_cs.wPosLagMaxMm, (int)g_cs.wPosCapped,
             (int)g_cs.wFireN[0], (int)g_cs.wFireN[1], (int)(g_cs.wFireLagSumX100[0] / f0 / 100), (int)(g_cs.wFireLagSumX100[0] / f0 % 100),
             (int)(g_cs.wFireLagSumX100[1] / f1 / 100), (int)(g_cs.wFireLagSumX100[1] / f1 % 100), (int)g_cs.wEngage, (int)g_cs.wFatigueMaxX100,
             (int)(g_cs.wSag1X100 / 100), (int)(g_cs.wSag1X100 % 100), (int)(g_cs.wSag2X100 / 100), (int)(g_cs.wSag2X100 % 100), s.wandValid, s.wandTwo);
    {   // 0.95: the PKE's weight and the one-handed shot, in their own line
      const LONG pn = g_cs.wPkeN ? g_cs.wPkeN : 1, on = g_cs.wOneFireN ? g_cs.wOneFireN : 1;
      log_line("WEIGHT2 frame=%d pkeWeight=%d%% gunPunish=%d%% | PKE: polls=%d meanLagDeg=%d.%02d maxLagDeg=%d.%02d pollsOver5deg=%d | one-handed shots: polls=%d meanSwayDeg=%d.%02d maxSwayDeg=%d.%02d maxClimbDeg=%d.%02d maxStrain=%d%%",
               (int)frame, (int)g_ctl.pkeWeightPct, (int)g_ctl.gunPunishPct, (int)g_cs.wPkeN, (int)(g_cs.wPkeLagSumX100 / pn / 100), (int)(g_cs.wPkeLagSumX100 / pn % 100),
               (int)(g_cs.wPkeLagMaxX100 / 100), (int)(g_cs.wPkeLagMaxX100 % 100), (int)g_cs.wPkeLagOverX100, (int)g_cs.wOneFireN,
               (int)(g_cs.wOneFireSwaySumX100 / on / 100), (int)(g_cs.wOneFireSwaySumX100 / on % 100), (int)(g_cs.wOneFireSwayMaxX100 / 100), (int)(g_cs.wOneFireSwayMaxX100 % 100),
               (int)(g_cs.wOneFireRecMaxX100 / 100), (int)(g_cs.wOneFireRecMaxX100 % 100), (int)g_cs.wStrainMaxX100);
    }
    log_line("RUMBLE game requests=%d nonZero=%d maxValue=%d lastValue=%d (the game's own XInputSetState calls; played at once for 100+ ms)",
             (int)g_cs.rumbleSets, (int)g_cs.rumbleNonZero, (int)g_cs.rumbleMax, (int)g_cs.rumbleLast);
  }
  log_line("BOSONGRIP frame=%d on=%d | gun-hand grip squeezed away from the pack: %ld presses, %ld polls of alternate fire (Boson Dart); the physical left trigger is the normal alternate-fire control", (int)frame, (int)g_ctl.bosonGrip, g_dartStarts, g_dartPolls);
  log_line("VENTGESTURE frame=%d on=%d packTouches=%d ventStarts=%d ventPolls=%d venting=%d", (int)frame, (int)g_ctl.ventGesture,
           (int)g_cs.packTouches, (int)g_cs.ventStarts, (int)g_cs.ventPolls, g_ventOn);
  log_line("CONTROLLERS frame=%d enabled=%d fresh=%d left=%d right=%d polls=%d noHand=%d haptics=%d rumbleSets=%d pad(buttons=%04x lt=%d rt=%d L=%d,%d R=%d,%d) seenL=%x_%08x seenR=%x_%08x maxTrig=%.2f/%.2f",
           (int)frame, (int)g_ctl.padEnabled, fresh, s.validL, s.validR, (int)g_cs.polls, (int)g_cs.noHand, (int)g_cs.haptics,
           (int)g_cs.rumbleSets, s.pad.buttons, s.pad.lt, s.pad.rt, s.pad.lx, s.pad.ly, s.pad.rx, s.pad.ry,
           (unsigned)(g_cs.seenL >> 32), (unsigned)g_cs.seenL, (unsigned)(g_cs.seenR >> 32), (unsigned)g_cs.seenR, (double)g_cs.maxTrig[0], (double)g_cs.maxTrig[1]);
  log_line("SLAMTRIG on=%d level=%d%% buzz=%d%% | slams started=%ld (no pull seen, game slams down: %ld) squeezed-but-meter-not-full=%ld, squeezed-with-nothing-held=%ld, meter-full pings=%ld | fire held %ld polls, aim stick flicked %ld polls, capture held by the probe %ld polls (of those after you had let go: %ld), vibration bursts %ld | last pull travel %.0f cm | samples %ld | 1.7.23: fire let go first for %ld polls (your trigger was still held in %ld of them), then pressed fresh",
           (int)g_ctl.slamTrigger, (int)g_ctl.slamTrigPct, (int)g_ctl.slamBuzzPct, g_trigSlam.slams, g_trigSlam.flickless, g_trigSlam.denied, g_trigSlam.noGhost, g_trigSlam.pings, g_ts.pressFrames, g_ts.flickFrames, g_ts.capHeldPolls, g_ts.capForcedPolls, g_ts.buzzed, g_ts.lastLen * 100.0, g_ts.samples, g_ts.releaseFrames, g_ts.releasedHeld);
  log_line("SPRINTPAD easy_sprint=%d latch=%d turn_free=%d | the click was held in %ld polls, quick taps %ld (kept on %ld times, off %ld times, stick let go %ld times), the probe held the button for %ld polls | 1.7.3: the click also held the game's Jump/Evade/Sprint button in %ld polls (sprint_via_jump=%d) | in the game: see SPRINT",
           (int)g_ctl.easySprint, (int)g_ctl.sprintLatch, (int)g_ctl.sprintTurnFree, g_sp.holdFrames, g_sp.taps, g_sp.latchOns, g_sp.latchOffs, g_sp.stickOffs, g_sp.latchFrames, g_jumpSprintFrames, (int)g_ctl.sprintViaJump);
  log_line("MENUGESTURE strict=%d (1 = the zone beside the left ear, not on the gun, hand still for 0.6 s) | opens by the hand=%ld | polls with the grip squeezed in the ear zone %ld, in the old 30 cm ball %ld | times the old rule alone would have opened it=%ld",
           (int)g_ctl.menuStrict, g_menuOpens, g_menuZoneFrames, g_menuOldFrames, g_menuOldOnly);
  log_line("WALKHEAD on=%d | polls where the left stick was turned to the headset: %ld (mean %.1f deg, biggest %.0f deg; over 10 deg %ld, over 35 deg %ld, over 90 deg %ld) | polls with no fresh head angle %ld (1.7.8: you walk where the headset points, the game's own heading no longer matters)",
           (int)g_ctl.walkHead, g_walkRotFrames, g_walkRotFrames ? g_walkRotSumDeg / (double)g_walkRotFrames : 0.0, g_walkRotMaxDeg, g_walkRot10, g_walkRot35, g_walkRot90, g_walkRotStale);
  log_line("SPRINTWANT force=%d | polls where sprint was on and the left stick pushed (the probe asked the game to run): %ld, held back because a trigger was squeezed: %ld | WALKCAP limit=%d%% (100 = off): polls held back %ld, strongest left-stick push seen while walking %ld per mille",
           (int)g_ctl.sprintForce, g_sprintWantFrames, g_sprintYieldFrames, (int)g_ctl.walkCapPct, g_walkCapFrames, g_walkCapMax);
  log_line("SLAMSWING on=%d sweeps=%ld (without a full meter %ld) fireHeldSamples=%ld, samples with Capture held=%ld, fastest hand while capturing %.1f m/s (a sweep counts above %.1f m/s, any direction), stick flick %d%%, legacy lt_capture=%d",
           (int)g_ctl.slamGesture, (long)g_cs.slamSwings, (long)g_cs.slamSwingsNoMeter, (long)g_cs.slamPressSamples, (long)g_cs.slamCaptureSamples,
           0.01 * (double)g_cs.slamMaxSpeedX100, 0.1 * (double)g_ctl.slamSpeedDeci, (int)g_ctl.slamFlickPct, (int)g_ctl.ltCapture);
  log_line("NEWPAD frame=%d layout=%s | Sprint (left stick click = the game's L3) polls=%ld | alternate fire (physical left trigger = LT) full-pull polls=%ld | Y taps=%ld, D layer claimed=%ld, polls in the layer=%ld (D-pad %ld, Vent %ld, HUD %ld, Select %ld)",
           (int)frame, config().sprintClick ? "1.7.57 (left click Sprint, right click Capture, left trigger Alt Fire)" : "legacy clicks (left trigger still Alt Fire)", g_sprintFrames, g_altFireFrames, g_yTaps, g_yClaims, g_layerFrames, g_layerDpad, g_layerVent, g_layerHud, g_layerSelect);
  log_line("GEAR2 PKE brought out by a Y press from the wheel: %ld times (the wheel no longer calls the game's ready-item function for the PKE)", g_gs.pkeByY);
  log_line("GEAR wheel on=%d (right A held 0.2 s) opens=%ld picked=%ld refused(locked/off)=%ld cancelled=%ld, discs lit by the hand=%ld | A quick taps replayed as Interact=%ld, A holds claimed=%ld | items %ld, D-pad %ld, wheel notches %ld sent %ld | trap (left X at the hip) on=%d grabs=%ld throws=%ld putBacks=%ld quickTapsReplayed=%ld fastestThrow=%.1f m/s lastThrow=%.1f m/s | right-stick D-pad presses=%ld (free hand >%d cm away) | two-hand barrel tilt %.1f deg, hold limit %d cm",
           (int)g_ctl.weaponWheel, g_gs.wheelOpens, g_gs.wheelChosen, g_wheel.lockedPicks, g_gs.wheelCancel, g_gs.handPicks, g_aTaps, g_aClaims, g_gs.items, g_gs.dpad, g_gs.notch, g_gs.notchPosted,
           (int)g_ctl.trapThrow, g_gs.trapGrabs, g_gs.trapThrows, g_gs.trapPutbacks, g_xReplays, g_gs.trapMaxSpeed, g_gs.trapLastSpeed, g_gs.dpadSeen, (int)g_ctl.dpadAwayCm,
           0.1 * (double)g_ctl.twoHandPitchDeci, (int)g_ctl.dpadAwayCm);
}

#endif
