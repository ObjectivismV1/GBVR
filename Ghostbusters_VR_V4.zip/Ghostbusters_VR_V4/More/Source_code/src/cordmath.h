// 0.75: the tube is one seamless piece of black rubber (no rings, no collar bands): smooth colours baked per vertex (a soft sheen along the top),
// rounded boots that flare into dark metal at both ends and sit a little into the pack and the gun, 12 sides, 3 rings per rope segment.
// 0.73 the proton hose as a real physics cord. Pure math, no Windows dependency; unit-tested in tests/test_cord.cpp.
// 0.74 rebuilt: the cord reels in and out (its length follows the distance between pack and wand, so slack never piles up into a ball),
// a bending limit stops hairpin folds, it leaves the pack and the wand along a set direction, the torso is an ellipse (not a fat pipe), the tube
// is smoothed with a spline and is black rubber with dark metal collars so it blends in with the game's own hose.
//
// A Verlet rope of kN points in tracking space (metres, OpenVR axes: y up, forward = -z). One end is pinned to the pack outlet on the
// player's back (it follows the head, turned by a slow "body" yaw, so a quick head turn does not swing the pack), the other end to the rear
// of the wand in the right hand. Between them the cord has gravity, damping, a rest length that follows the distance, a floor, and an ellipse
// around the torso so it lies over the hip instead of through the body.
#pragma once
#include "vmath.h"

namespace cord {

enum { kN = 22, kSides = 12, kSub = 3 };
enum { kRings = (kN - 1) * kSub + 1 };
static const double kRadiusM = 0.0125;    // thickness (the game's hose is about 2.5 cm across)
static const double kGravity = 9.0;
static const double kMinLenM = 0.50, kMaxLenM = 1.90;
static const double kBendMin = 0.95;      // two neighbouring segments may not fold closer than this fraction of their length (about 36 degrees per joint)

struct Rope {
  double p[kN][3], q[kN][3];
  int have;
  double yaw;                              // slow body yaw (radians; 0 = looking along -z)
  int yawHave;
  double len;                              // rest length used in the last step
  long steps, resets, taut, floorHits, capsuleHits, bendHits;
  double dMin, dMax, dSum, maxSpeed;       // A-B distance statistics, fastest point (m/s)
  double lenMin, lenMax, lenSum, foldMin;  // 0.74: cord length statistics, the tightest bend seen (1 = straight)
  double sagSum, sagMax; long sagN;        // 0.74: how far the middle hangs below the line between the ends (m)
  void reset_stats() {
    steps = resets = taut = floorHits = capsuleHits = bendHits = 0; dMin = 1e9; dMax = 0; dSum = 0; maxSpeed = 0;
    lenMin = 1e9; lenMax = 0; lenSum = 0; foldMin = 1e9; sagSum = 0; sagMax = 0; sagN = 0;
  }
  void init() { have = 0; yawHave = 0; yaw = 0; len = 0.0; reset_stats(); }
};

inline double wrap_pi(double a) { while (a > vm::kPi) a -= 2.0 * vm::kPi; while (a < -vm::kPi) a += 2.0 * vm::kPi; return a; }
inline double len3(const double* a) { return vm::dsqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); }
inline double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

// The body yaw follows the head's yaw with a dead zone (like the avatar's torso): inside +-25 degrees it stays, beyond that it turns after the head.
inline void body_yaw(Rope* r, double headYaw, double dt) {
  if (!r->yawHave) { r->yaw = headYaw; r->yawHave = 1; return; }
  const double dead = 25.0 * vm::kPi / 180.0;
  double d = wrap_pi(headYaw - r->yaw);
  if (d > dead) r->yaw += (d - dead) * (dt * 4.0 > 1.0 ? 1.0 : dt * 4.0);
  else if (d < -dead) r->yaw += (d + dead) * (dt * 4.0 > 1.0 ? 1.0 : dt * 4.0);
  r->yaw = wrap_pi(r->yaw);
}

// forward / right of a yaw (OpenVR: yaw 0 looks along -z)
inline void yaw_axes(double yaw, double* fwd, double* right) {
  double s, c;
  vm::dsincos(yaw, &s, &c);
  fwd[0] = s; fwd[1] = 0; fwd[2] = -c;
  right[0] = c; right[1] = 0; right[2] = s;
}

// Yaw of a 3x4 head pose (forward = -z column).
inline double pose_yaw(const float* p34) {
  const double fx = -(double)p34[2], fz = -(double)p34[10];
  if (fx * fx + fz * fz < 1e-4) return 0.0;
  return vm::datan2(fx, -fz);
}

// Where the cord leaves the pack: the game's own hose starts about 7 cm to the right, 18 cm behind and 56 cm below the eye (log BODYREL of 0.73).
// scale: the player's size against 1.6 m. exitA: the way it leaves (down and out to the right, a little forward), a unit vector.
inline void pack_anchor(const float* head34, double yaw, double scale, double* A, double* exitA = nullptr, double outM = 0.0, double downM = 0.0) {
  double f[3], r[3];
  yaw_axes(yaw, f, r);
  const double s = clampd(scale, 0.6, 1.5);
  // 0.75: the avatar stands outM in front of the real eye and downM lower (menu: Push the body out / View higher), so its pack does too
  const double behind = 0.18 * s - outM;
  for (int i = 0; i < 3; ++i) A[i] = (double)head34[i * 4 + 3] + r[i] * 0.075 * s - f[i] * behind;
  A[1] -= 0.56 * s + downM;
  if (exitA) {
    double d[3] = {r[0] * 0.45 + f[0] * 0.20, -0.85, r[2] * 0.45 + f[2] * 0.20};
    const double l = len3(d);
    for (int i = 0; i < 3; ++i) exitA[i] = d[i] / l;
  }
}

// Where the cord plugs into the wand: behind the grip along the wand, a little below. pose34 = the wand's pose (device axes: -z = the way it points).
inline void wand_anchor(const float* pose34, double* B, double* outDir) {
  const double back[3] = {pose34[2], pose34[6], pose34[10]}, up[3] = {pose34[1], pose34[5], pose34[9]};
  for (int i = 0; i < 3; ++i) { B[i] = (double)pose34[i * 4 + 3] + back[i] * 0.13 - up[i] * 0.04; outDir[i] = back[i]; }
}

// The cord's length for a given distance between its ends: some slack that hangs in a gentle curve, less slack the farther the hand is (like a reel).
inline double want_length(double dist) {
  const double slack = 0.95 - 0.70 * clampd((dist - 0.4) / 0.8, 0.0, 1.0);   // 0.81: more slack (was 0.30 - 0.20): the hose can drape around the body instead of pulling taut through it
  const double w = clampd(dist + slack, kMinLenM, kMaxLenM);
  return w > dist * 1.03 ? w : dist * 1.03;   // never shorter than the distance (it may stretch 3 percent when the hands are far apart)
}

inline void straight_init(Rope* r, const double* A, const double* B, double L) {
  for (int i = 0; i < kN; ++i) {
    const double t = (double)i / (double)(kN - 1);
    for (int k = 0; k < 3; ++k) r->p[i][k] = r->q[i][k] = A[k] + (B[k] - A[k]) * t;
    const double sag = 4.0 * t * (1.0 - t) * 0.12;   // a little hang so the first frames do not look like a rod
    r->p[i][1] -= sag; r->q[i][1] -= sag;
  }
  r->len = L;
  r->have = 1;
}

// One physics step. A, B: the pinned ends (tracking metres); exitA / exitB: unit vectors the cord leaves the pack / the wand along.
// head: head position; scale: player size against 1.6 m (the torso ellipse). floorY: the floor in tracking space (0).
inline void step(Rope* r, const double* A, const double* exitA, const double* B, const double* exitB, const double* head, double scale, double floorY, double dt) {
  if (!(dt > 0)) return;
  if (dt > 0.05) dt = 0.05;
  double AB[3] = {B[0] - A[0], B[1] - A[1], B[2] - A[2]};
  const double dist = len3(AB);
  const double want = want_length(dist);
  if (!r->have) { straight_init(r, A, B, want); ++r->resets; }
  else {   // pinned end jumped (teleport, recenter): start again
    const double j0 = vm::dsqrt((r->p[0][0] - A[0]) * (r->p[0][0] - A[0]) + (r->p[0][1] - A[1]) * (r->p[0][1] - A[1]) + (r->p[0][2] - A[2]) * (r->p[0][2] - A[2]));
    if (j0 > 1.2) { straight_init(r, A, B, want); ++r->resets; }
  }
  // the cord reels: it gets longer at once when the hand moves away, shorter at 0.8 m/s when the hand comes back (so a quick move does not make it jerk)
  if (want >= r->len) r->len = want;
  else { r->len -= 0.8 * dt; if (r->len < want) r->len = want; }
  const double L = r->len;
  if (dist > 0.93 * L) ++r->taut;
  const double seg = L / (double)(kN - 1);
  ++r->steps;
  r->dSum += dist; if (dist < r->dMin) r->dMin = dist; if (dist > r->dMax) r->dMax = dist;
  r->lenSum += L; if (L < r->lenMin) r->lenMin = L; if (L > r->lenMax) r->lenMax = L;
  const double s = clampd(scale, 0.6, 1.5);
  double fw[3], rt[3];
  yaw_axes(r->yaw, fw, rt);
  // pinned points: both ends and the one next to each end (so the cord leaves along a set direction)
  unsigned char pin[kN];
  for (int i = 0; i < kN; ++i) pin[i] = (i <= 1 || i >= kN - 2) ? 1 : 0;
  // sub-steps of at most 8 ms
  int sub = (int)(dt / 0.008) + 1;
  if (sub > 6) sub = 6;
  const double h = dt / (double)sub;
  const double damp = 1.0 - 2.2 * h > 0.5 ? 1.0 - 2.2 * h : 0.5;
  const double top = head[1] - 0.10 * s, bot = head[1] - 0.95 * s;
  const double cx = head[0] - fw[0] * 0.04 * s, cz = head[2] - fw[2] * 0.04 * s;   // the torso is a little behind the eye
  const double Wd = 0.20 * s, Dp = 0.13 * s;                                         // half width (sideways) and half depth (front to back)
  for (int it = 0; it < sub; ++it) {
    for (int i = 0; i < kN; ++i) {
      if (pin[i]) continue;
      double* P = r->p[i]; double* Q = r->q[i];
      double v[3] = {(P[0] - Q[0]) * damp, (P[1] - Q[1]) * damp, (P[2] - Q[2]) * damp};
      const double sp = len3(v) / h;
      if (sp > r->maxSpeed) r->maxSpeed = sp;
      Q[0] = P[0]; Q[1] = P[1]; Q[2] = P[2];
      P[0] += v[0]; P[1] += v[1] - kGravity * h * h; P[2] += v[2];
    }
    for (int k = 0; k < 3; ++k) {
      r->p[0][k] = A[k]; r->q[0][k] = A[k]; r->p[kN - 1][k] = B[k]; r->q[kN - 1][k] = B[k];
      r->p[1][k] = A[k] + exitA[k] * seg; r->q[1][k] = r->p[1][k];
      r->p[kN - 2][k] = B[k] + exitB[k] * seg; r->q[kN - 2][k] = r->p[kN - 2][k];
    }
    for (int c = 0; c < 12; ++c) {
      for (int i = 0; i < kN - 1; ++i) {   // keep every segment its length
        double* a = r->p[i]; double* b = r->p[i + 1];
        double d[3] = {b[0] - a[0], b[1] - a[1], b[2] - a[2]};
        const double dl = len3(d);
        if (dl < 1e-9) continue;
        const double e = (dl - seg) / dl;
        const double wa = pin[i] ? 0.0 : 1.0, wb = pin[i + 1] ? 0.0 : 1.0;
        const double ws = wa + wb;
        if (ws <= 0) continue;
        for (int k = 0; k < 3; ++k) { a[k] += d[k] * e * (wa / ws); b[k] -= d[k] * e * (wb / ws); }
      }
      for (int i = 0; i < kN - 2; ++i) {   // bending limit: two neighbouring segments do not fold back on themselves
        double* a = r->p[i]; double* b = r->p[i + 2];
        double d[3] = {b[0] - a[0], b[1] - a[1], b[2] - a[2]};
        const double dl = len3(d), mn = 2.0 * seg * kBendMin;
        if (dl >= mn || dl < 1e-9) continue;
        const double wa = pin[i] ? 0.0 : 1.0, wb = pin[i + 2] ? 0.0 : 1.0;
        const double ws = wa + wb;
        if (ws <= 0) continue;
        const double e = (dl - mn) / dl * 0.6;
        for (int k = 0; k < 3; ++k) { a[k] += d[k] * e * (wa / ws); b[k] -= d[k] * e * (wb / ws); }
        if (c == 0) ++r->bendHits;
      }
      // floor and the torso (an ellipse seen from above: wider than deep, from the shoulders to the hips)
      for (int i = 1; i < kN - 1; ++i) {
        double* P = r->p[i];
        if (P[1] < floorY + kRadiusM) { P[1] = floorY + kRadiusM; if (c == 0) ++r->floorHits; }
        if (i >= 3 && i <= kN - 3 && P[1] < top && P[1] > bot) {
          const double dx = P[0] - cx, dz = P[2] - cz;
          const double u = dx * rt[0] + dz * rt[2], v = dx * fw[0] + dz * fw[2];   // sideways, forward
          const double g = vm::dsqrt((u * u) / (Wd * Wd) + (v * v) / (Dp * Dp));
          if (g < 1.0) {
            double uu = u, vv = v;
            if (g < 1e-4) { uu = Wd; vv = 0.0; }
            else { uu = u / g; vv = v / g; }
            P[0] = cx + rt[0] * uu + fw[0] * vv; P[2] = cz + rt[2] * uu + fw[2] * vv;
            if (c == 0) ++r->capsuleHits;
          }
        }
      }
    }
    for (int k = 0; k < 3; ++k) {
      r->p[0][k] = A[k]; r->p[kN - 1][k] = B[k];
      r->p[1][k] = A[k] + exitA[k] * seg; r->p[kN - 2][k] = B[k] + exitB[k] * seg;
    }
  }
  for (int i = 0; i < kN; ++i) for (int k = 0; k < 3; ++k) if (!vm::is_finite_f((float)r->p[i][k])) { r->have = 0; return; }
  {   // data: the tightest bend (1 = straight) and how far the middle hangs below the line between the ends
    double fold = 1e9;
    for (int i = 0; i < kN - 2; ++i) {
      double d[3] = {r->p[i + 2][0] - r->p[i][0], r->p[i + 2][1] - r->p[i][1], r->p[i + 2][2] - r->p[i][2]};
      const double f = len3(d) / (2.0 * seg);
      if (f < fold) fold = f;
    }
    if (fold < r->foldMin) r->foldMin = fold;
    const int m = kN / 2;
    const double lineY = 0.5 * (A[1] + B[1]);
    const double sag = lineY - r->p[m][1];
    r->sagSum += sag; ++r->sagN; if (sag > r->sagMax) r->sagMax = sag;
  }
}

// ---- the tube ---------------------------------------------------------------------------------------------------------------------
struct V { float p[3]; float n[3]; float c[4]; };   // same layout as hand::Vertex

enum { kVerts = (kRings - 1) * kSides * 6 };
inline int vertex_count() { return (int)kVerts; }

static const double kBootM = 0.045;       // 0.75: the rounded end boots (they flare from the tube's thickness to 1.45 times it)
static const double kEmbedM = 0.010;      // 0.75: each end sits this far into the pack / the gun, so no gap shows

// 0.75 the colour of one point of the tube. ny = the surface normal's upward part (tracking space), f = 0 in the hose, 1 at the very end of a boot.
// Smooth over the whole tube: black rubber with a soft sheen along its top, the boots blend into dark metal. The probe's shader multiplies this by its own light.
// 0.78: the hose's colour follows the game's own hose texture: a per-channel multiplier on the neutral shading below (1,1,1 = the 0.77 black rubber).
// Set from handmodel.cpp each frame (hosetex_color), read here.
inline float* hose_tint() { static float t[3] = {1.0f, 1.0f, 1.0f}; return t; }
inline void tube_color(double ny, double f, float* c) {
  const double top = ny > 0.0 ? ny : 0.0;
  const double t2 = top * top, t4 = t2 * t2, t8 = t4 * t4;
  // 0.77: black like the game's own hose (the ghostbuster NPCs'): a neutral near-black with only a faint sheen (0.75-0.76 were a bluish dark grey)
  const double rub = 0.050 * (0.72 + 0.55 * top) + 0.050 * t8;
  const double met = 0.20 * (0.80 + 0.40 * top) + 0.12 * t8;
  const double v = rub * (1.0 - f) + met * f;
  const float* tn = hose_tint();
  double r = v * tn[0], g = v * tn[1], b = v * 1.02 * tn[2];
  if (r > 1.0) r = 1.0; if (g > 1.0) g = 1.0; if (b > 1.0) b = 1.0;
  c[0] = (float)r; c[1] = (float)g; c[2] = (float)b; c[3] = 0.0f;
}

static const double kShieldBack = 0.17, kShieldWd = 0.17, kShieldDp = 0.085;   // 0.79 metres at 1.6 m player size: centre behind the eye, half width, half depth
// 0.77 chest shield: the torso the cord is kept out of (see step) as an upright elliptic tube, drawn into the depth buffer only, so the cord
// is hidden where it passes behind your chest instead of showing through it. head: the head position used by step, scale: its player size factor.
inline int build_shield(const double* head, double yaw, double scale, V* out, int cap) {
  enum { kSeg = 20 };
  if (cap < kSeg * 6) return 0;
  const double s = clampd(scale, 0.6, 1.5);
  double fw[3], rt[3];
  yaw_axes(yaw, fw, rt);
  // 0.79: the 0.77 chest was built around the eye (the eye stood INSIDE it), so every ray to the cord crossed its wall and the whole cord vanished.
  // Now it is a chest that starts below the chin and lies behind the eye plane: rays to the cord at your side or in front of you miss it,
  // only the cord that really runs behind your chest is hidden.
  const double top = head[1] - 0.16 * s, bot = head[1] - 0.95 * s;
  const double cx = head[0] - fw[0] * kShieldBack * s, cz = head[2] - fw[2] * kShieldBack * s;
  const double Wd = kShieldWd * s, Dp = kShieldDp * s;
  int n = 0;
  double px[kSeg + 1], pz[kSeg + 1];
  for (int i = 0; i <= kSeg; ++i) {
    double sn, cs;
    vm::dsincos(2.0 * vm::kPi * (double)(i % kSeg) / (double)kSeg, &sn, &cs);
    const double u = Wd * cs, v = Dp * sn;
    px[i] = cx + rt[0] * u + fw[0] * v; pz[i] = cz + rt[2] * u + fw[2] * v;
  }
  auto put = [&](double x, double y, double z) {
    V& o = out[n++];
    o.p[0] = (float)x; o.p[1] = (float)y; o.p[2] = (float)z; o.n[0] = 0; o.n[1] = 1; o.n[2] = 0; o.c[0] = o.c[1] = o.c[2] = o.c[3] = 0;
  };
  for (int i = 0; i < kSeg; ++i) {
    put(px[i], top, pz[i]); put(px[i], bot, pz[i]); put(px[i + 1], top, pz[i + 1]);
    put(px[i + 1], top, pz[i + 1]); put(px[i], bot, pz[i]); put(px[i + 1], bot, pz[i + 1]);
  }
  // 0.84: no lid and no floor (they hid the cord whenever you looked down at it from above)
  return n;
}

// Builds the triangle list (tracking-space metres). Returns the number of vertices written.
// The centre line is a Catmull-Rom spline through the rope points (kSub rings per segment), so it is smooth even where the rope bends.
inline int build_mesh(const Rope& r, V* out, int cap) {
  if (cap < vertex_count()) return 0;
  static double cen[kRings][3];
  for (int m = 0; m < kRings; ++m) {
    int i = m / kSub; double t = (double)(m % kSub) / (double)kSub;
    if (i >= kN - 1) { i = kN - 2; t = 1.0; }
    const int i0 = i > 0 ? i - 1 : 0, i3 = i + 2 < kN ? i + 2 : kN - 1;
    const double t2 = t * t, t3 = t2 * t;
    for (int k = 0; k < 3; ++k) {
      const double p0 = r.p[i0][k], p1 = r.p[i][k], p2 = r.p[i + 1][k], p3 = r.p[i3][k];
      cen[m][k] = 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3);
    }
  }
  {   // the two end rings sit a little inside the pack and the gun (along the cord's own direction there)
    double t0[3], t1[3];
    for (int k = 0; k < 3; ++k) { t0[k] = cen[1][k] - cen[0][k]; t1[k] = cen[kRings - 1][k] - cen[kRings - 2][k]; }
    const double l0 = len3(t0), l1 = len3(t1);
    if (l0 > 1e-9) for (int k = 0; k < 3; ++k) cen[0][k] -= t0[k] / l0 * kEmbedM;
    if (l1 > 1e-9) for (int k = 0; k < 3; ++k) cen[kRings - 1][k] += t1[k] / l1 * kEmbedM;
  }
  static double sArc[kRings];
  sArc[0] = 0;
  for (int m = 1; m < kRings; ++m) {
    double d[3] = {cen[m][0] - cen[m - 1][0], cen[m][1] - cen[m - 1][1], cen[m][2] - cen[m - 1][2]};
    sArc[m] = sArc[m - 1] + len3(d);
  }
  const double total = sArc[kRings - 1];
  static double ring[kRings][kSides][3], nrm[kRings][kSides][3];
  static float colr[kRings][kSides][4];
  double prevN[3] = {0, 1, 0};
  for (int m = 0; m < kRings; ++m) {
    double T[3];
    const int a = m == 0 ? 0 : m - 1, b = m == kRings - 1 ? kRings - 1 : m + 1;
    for (int k = 0; k < 3; ++k) T[k] = cen[b][k] - cen[a][k];
    double tl = len3(T);
    if (tl < 1e-9) { T[0] = 0; T[1] = 0; T[2] = 1; tl = 1; }
    for (int k = 0; k < 3; ++k) T[k] /= tl;
    // parallel transport of the ring's first axis
    double N1[3] = {prevN[0], prevN[1], prevN[2]};
    double d = N1[0] * T[0] + N1[1] * T[1] + N1[2] * T[2];
    for (int k = 0; k < 3; ++k) N1[k] -= T[k] * d;
    double nl = len3(N1);
    if (nl < 1e-6) { N1[0] = 1; N1[1] = 0; N1[2] = 0; d = N1[0] * T[0]; for (int k = 0; k < 3; ++k) N1[k] -= T[k] * d; nl = len3(N1); if (nl < 1e-6) { N1[0] = 0; N1[1] = 1; N1[2] = 0; nl = 1; } }
    for (int k = 0; k < 3; ++k) { N1[k] /= nl; prevN[k] = N1[k]; }
    double N2[3] = {T[1] * N1[2] - T[2] * N1[1], T[2] * N1[0] - T[0] * N1[2], T[0] * N1[1] - T[1] * N1[0]};
    // rounded boots at both ends: smoothstep from the hose's thickness up to 1.45 times it, and from rubber to metal
    const double toEnd = sArc[m] < total - sArc[m] ? sArc[m] : total - sArc[m];
    double e = 1.0 - toEnd / kBootM; e = e < 0.0 ? 0.0 : (e > 1.0 ? 1.0 : e);
    const double f = e * e * (3.0 - 2.0 * e);
    const double rad = kRadiusM * (1.0 + 0.45 * f);
    for (int s = 0; s < kSides; ++s) {
      double sn, cs;
      vm::dsincos(2.0 * vm::kPi * (double)s / (double)kSides, &sn, &cs);
      for (int k = 0; k < 3; ++k) {
        nrm[m][s][k] = N1[k] * cs + N2[k] * sn;
        ring[m][s][k] = cen[m][k] + nrm[m][s][k] * rad;
      }
      tube_color(nrm[m][s][1], f, colr[m][s]);
    }
  }
  int n = 0;
  for (int m = 0; m < kRings - 1; ++m) {
    for (int s = 0; s < kSides; ++s) {
      const int s2 = (s + 1) % kSides;
      const double* P[6] = {ring[m][s], ring[m + 1][s], ring[m][s2], ring[m][s2], ring[m + 1][s], ring[m + 1][s2]};
      const double* Nn[6] = {nrm[m][s], nrm[m + 1][s], nrm[m][s2], nrm[m][s2], nrm[m + 1][s], nrm[m + 1][s2]};
      const float* Cc[6] = {colr[m][s], colr[m + 1][s], colr[m][s2], colr[m][s2], colr[m + 1][s], colr[m + 1][s2]};
      for (int v = 0; v < 6; ++v) {
        V& o = out[n++];
        for (int k = 0; k < 3; ++k) { o.p[k] = (float)P[v][k]; o.n[k] = (float)Nn[v][k]; }
        for (int k = 0; k < 4; ++k) o.c[k] = Cc[v][k];
      }
    }
  }
  return n;
}

}  // namespace cord
