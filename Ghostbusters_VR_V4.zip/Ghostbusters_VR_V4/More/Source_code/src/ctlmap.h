// 0.78 the controller map, written down once so it can be CHECKED (tests/test_ctlmap.cpp) and logged (CONTROLMAP lines).
// Rule (standing instruction from the user): whenever a new mapping is added, it must not interfere with any other control. Two uses of the same
// physical button are only allowed when they can never be active together: different contexts of the same group (a tap versus a hold, inside versus
// outside a body zone, ...), or an explicit "resolved" note that says which one wins and why. The test fails on anything else, and on any new feature
// that uses a grip (the user asked for no grip use in the wheel and the trap).
#pragma once

namespace ctlmap {

enum Hand { kLeft = 0, kRight = 1 };
// the physical buttons of a Touch controller (names as the user sees them)
enum Button { kFaceBottom = 0, kFaceTop, kGrip, kTrigger, kStickClick, kStick, kButtons };
// context groups: two uses in the same group with different contexts are mutually exclusive
enum Group { kNoGroup = 0, kGTapHold, kGHipLeft, kGBodyZone, kGStickMode, kGHands, kGLayer, kGHeldMenu };
enum Ctx {
  kAlways = 0,
  kTap, kHold,                       // group TapHold: a quick tap or a hold of the same button
  kAtLeftHip, kAwayFromLeftHip,      // group HipLeft: the left hand at the left hip or anywhere else
  kAtRightHip, kAtShoulder, kAtShoulderTrig, kNearHead, kAwayFromPack,   // group BodyZone: the three body zones (hip / pack on the back / beside the head)
  kModeNormal, kModeDpad, kModeWheel,    // group StickMode: the right stick turns, or sends D-pad presses, or picks a wheel disc
  kHandsNear, kHandsFar,                 // group Hands: the free hand near the gun hand (two-hand hold) or far from it (D-pad gesture)
  kLayerOff, kLayerOn,                   // group Layer (0.98): the left Y button is held (the D layer) or not
  kHeldMenuOn                            // group HeldMenu (1.7.29): the game's pause menu is held in the left hand (the flat screen; the game gets no VR buttons then)
};
struct Use {
  int hand, button, ctx, group;
  const char* what;       // what it does, in plain words
  int isNew078;           // 1 = added in 0.78, 2 = added in 0.98 (both are checked against the no-grip rule; 3 = 1.7.22, also checked)
  const char* resolved;   // null, or why a possible overlap with another use is harmless
};

static const Use kMap[] = {
  // ---- right hand
  {kRight, kFaceBottom, kTap,  kGTapHold, "A tap = Interact (the game's A, replayed on release)", 1, nullptr},
  {kRight, kFaceBottom, kHold, kGTapHold, "A hold (0.2 s) = weapon wheel", 1, nullptr},
  {kRight, kFaceBottom, kLayerOn, kGLayer, "0.98: A while Y is held (the D layer) = Select / Back (the game's Back)", 2, nullptr},
  {kRight, kFaceTop, kLayerOff, kGLayer, "B = Jump (the game's B)", 0, nullptr},
  {kRight, kFaceTop, kLayerOn, kGLayer, "0.98: B while Y is held (the D layer) = HUD on / off (the game's R3)", 2, nullptr},
  {kRight, kStick, kLayerOn, kGLayer, "0.98: stick while Y is held (the D layer) = D-pad (equipment select), no turning", 2, nullptr},
  {kRight, kStick, kModeNormal, kGStickMode, "stick = turn (1.5: snap turn by default: one flick left or right = one step of 30 degrees, or the smooth turn; the head-follow adds its own push to this same axis only when you are not pushing the stick yourself, and never in the D layer, the wheel or the D-pad mode; no new button)", 0, nullptr},
  {kRight, kStick, kModeDpad, kGStickMode, "stick = D-pad (left grip held, free hand far from the gun)", 0, nullptr},
  {kRight, kStick, kModeWheel, kGStickMode, "stick = pick a wheel disc (wheel open: no turning, no D-pad)", 1, nullptr},
  {kRight, kStickClick, kLayerOff, kGLayer, "1.7.57: normal stick click = Capture / wrangle (the game's LB); masked while the wheel is open", 2, nullptr},
  {kRight, kStickClick, kLayerOn, kGLayer, "0.98: stick click while Y is held (the D layer) = Vent (the game's RB). Vent also stays over the shoulder (grip zone)", 2, nullptr},
  // 1.7.29 the hand-held game menu (flat screen after the menu gesture): the right hand points; none of these reach the game as buttons
  {kRight, kTrigger, kHeldMenuOn, kGHeldMenu, "1.7.29: trigger while the hand-held game menu is up = click (the ring freezes when you start to squeeze)", 3, nullptr},
  {kRight, kStick, kHeldMenuOn, kGHeldMenu, "1.7.29: stick up/down while the hand-held game menu is up = scroll the list", 3, nullptr},
  {kRight, kFaceBottom, kHeldMenuOn, kGHeldMenu, "1.7.29: A (bottom button) while the hand-held game menu is up = close it (never a grip, never Menu)", 3, nullptr},
  {kRight, kTrigger, kAlways, kNoGroup, "trigger = fire (masked while the wheel is open or the gun is holstered); with the PKE out the same trigger is the scan (the game's own Primary; 1.4 also starts the scan by itself when the PKE points at a ghost: no button involved)", 0, nullptr},
  {kRight, kGrip, kAtShoulderTrig, kGBodyZone, "0.83: trigger + grip with the right hand over the shoulder = holster / draw the gun on your back (the user asked for exactly this)", 0, nullptr},
  {kRight, kGrip, kAtShoulder, kGBodyZone, "grip alone over the shoulder = vent the pack (not while the trigger is squeezed too)", 0, nullptr},
  {kRight, kGrip, kAwayFromPack, kGBodyZone, "optional legacy shortcut (boson_grip=1): fresh gun-hand grip squeeze away from the pack = Boson Dart; default is OFF in 1.7.57 because alternate fire belongs on the physical LEFT TRIGGER", 0, nullptr},
  // ---- left hand
  {kLeft, kFaceBottom, kAtLeftHip, kGHipLeft, "X at the left hip = take the ghost trap (a quick tap there still deploys it)", 1, nullptr},
  {kLeft, kFaceBottom, kAwayFromLeftHip, kGHipLeft, "X anywhere else = deploy trap (the game's X, live)", 0, nullptr},
  {kLeft, kFaceTop, kTap,  kGTapHold, "0.98: Y tap = PKE meter (the game's Y, replayed on release). Never the Menu button.", 2, nullptr},
  {kLeft, kFaceTop, kHold, kGTapHold, "0.98: Y hold (0.3 s) = the D layer (right stick = D-pad, right stick click = Vent, right B = HUD, right A = Select)", 2, nullptr},
  {kLeft, kStick, kAlways, kNoGroup, "stick = move; 1.7.22 (option, off by default): a double-tap of the stick itself (push hard, back to the middle, push hard again within half a second) = a short blink dash in the walking direction. It uses the stick only: no new button, no grip", 3, nullptr},
  {kLeft, kStickClick, kAlways, kNoGroup, "0.98: stick click = Sprint (the game's L3); 1.7: a tap keeps the sprint on until you tap again or stop moving, and the sprint starts at once instead of after the game's half-second hold; 1.7.5: every click is a toggle (click on, click off, stops by itself after 1.2 s without a stick push; a long press does not hold it); 1.7.8: the click is never sent to the game; it only switches the probe's sprint speed boost on and off (the game's own run is not started), and Jump is not held unless sprint_via_jump is switched on (1.7.3 way: the click also held the Jump/Evade button, the same one the right B sends)", 2, nullptr},
  {kLeft, kTrigger, kAlways, kNoGroup, "1.7.57: trigger = alternate fire (the game's LT) for every beam / weapon. For a slam, hold Capture on the right stick click, then full-squeeze this trigger with a charged meter", 0, nullptr},
  {kLeft, kGrip, kHandsNear, kGHands, "grip, hand near the gun hand = two-hand hold", 0, nullptr},
  {kLeft, kGrip, kHandsFar, kGHands, "grip, hand far from the gun hand + right stick = D-pad", 0, nullptr},
  {kLeft, kGrip, kNearHead, kGBodyZone, "grip beside the LEFT EAR (1.7.7: a zone in the headset's own axes: within 24 cm, not more than 8 cm to the right, not more than 12 cm in front of the face) with the hand held still for 0.6 s = the menu (1.7.28: the game's own pause menu, held in the left hand; the same gesture closes it; with held_menu off: the old floating VR menu) (the pad is cleared while it holds)", 0, "1.7.7: the ear zone only counts while the left hand is NOT near the gun hand, so the two-hand hold (grip near the gun hand) always wins; hands near each other never open the menu"},
  {kLeft, kGrip, kAtShoulder, kGBodyZone, "grip over the shoulder = vent the pack", 0, nullptr},
};
static const int kMapN = (int)(sizeof(kMap) / sizeof(kMap[0]));

// Pairs that overlap on purpose and are settled in code (grip uses whose zones or hand distances can coincide; the order of the checks decides):
//  - left grip: two-hand hold / D-pad (hand distance) versus the head and shoulder zones: the head zone clears the whole pad state (it is checked last and wins),
//    the shoulder vent only adds the RB press; the D-pad also needs the right stick pushed, which the two-hand hold never does.
struct Settled { int hand, button, ctxA, ctxB; const char* why; };
static const Settled kSettled[] = {
  // 0.98: the D layer (left Y held) takes the right hand's buttons; the tap/hold machine of A and the stick modes are reset while it is on, so these never act together
  {kRight, kFaceBottom, kTap, kLayerOn, "while the D layer is on the A machine is reset: A only means Select"},
  {kRight, kFaceBottom, kHold, kLayerOn, "while the D layer is on the A machine is reset: no wheel, A only means Select"},
  {kRight, kStick, kModeNormal, kLayerOn, "the layer sends D-pad and zeroes the turn"},
  {kRight, kStick, kModeDpad, kLayerOn, "the layer sends D-pad and zeroes the turn (same D-pad)"},
  {kRight, kStick, kModeWheel, kLayerOn, "the wheel cannot claim A while the layer is on, so it is never open together"},
  // 1.7.29: while the hand-held game menu is up the screen is flat and the XInput bridge injects no VR buttons, so none of the gameplay uses of these buttons is active
  {kRight, kFaceBottom, kTap, kHeldMenuOn, "the flat menu screen: the game gets no VR buttons, the A machine's Interact does nothing; A only closes the menu"},
  {kRight, kFaceBottom, kHold, kHeldMenuOn, "the flat menu screen: no weapon wheel; A only closes the menu"},
  {kRight, kFaceBottom, kLayerOn, kHeldMenuOn, "the flat menu screen: the D layer's Select / Back is not injected; A only closes the menu"},
  {kRight, kStick, kModeNormal, kHeldMenuOn, "the flat menu screen: no turning; the stick only scrolls"},
  {kRight, kStick, kModeDpad, kHeldMenuOn, "the flat menu screen: no D-pad; the stick only scrolls"},
  {kRight, kStick, kModeWheel, kHeldMenuOn, "the flat menu screen: no wheel; the stick only scrolls"},
  {kRight, kStick, kLayerOn, kHeldMenuOn, "the flat menu screen: no D-pad; the stick only scrolls"},
  {kRight, kTrigger, kAlways, kHeldMenuOn, "the flat menu screen: the trigger does not fire or scan (no VR buttons reach the game); it only clicks"},
  {kLeft, kGrip, kHandsNear, kNearHead, "head zone clears the pad state last: it wins"},
  {kLeft, kGrip, kHandsNear, kAtShoulder, "vent only adds RB; a two-hand hold at the shoulder is not a normal pose"},
  {kLeft, kGrip, kHandsFar, kNearHead, "head zone clears the pad state last: it wins"},
  {kLeft, kGrip, kHandsFar, kAtShoulder, "vent only adds RB; the D-pad also needs the right stick pushed"},
  {kLeft, kGrip, kHandsNear, kHandsFar, "same group, different distances: exclusive"},
};

inline int settled(const Use& a, const Use& b) {
  for (const Settled& s : kSettled)
    if (a.hand == s.hand && a.button == s.button && b.hand == s.hand && b.button == s.button &&
        ((a.ctx == s.ctxA && b.ctx == s.ctxB) || (a.ctx == s.ctxB && b.ctx == s.ctxA))) return 1;
  return 0;
}

// number of pairs of uses of the same button that can be active together and are not settled (must be 0)
inline int conflicts(int* firstA, int* firstB) {
  int n = 0;
  for (int i = 0; i < kMapN; ++i)
    for (int j = i + 1; j < kMapN; ++j) {
      const Use &a = kMap[i], &b = kMap[j];
      if (a.hand != b.hand || a.button != b.button) continue;
      if (a.group != kNoGroup && a.group == b.group && a.ctx != b.ctx) continue;   // exclusive contexts of one group
      if (settled(a, b)) continue;
      if (n == 0) { if (firstA) *firstA = i; if (firstB) *firstB = j; }
      ++n;
    }
  return n;
}
// number of new-in-0.78 features that sit on a grip (must be 0)
inline int new_on_grip() { int n = 0; for (int i = 0; i < kMapN; ++i) if (kMap[i].isNew078 && kMap[i].button == kGrip) ++n; return n; }   // 0.98: the new uses (isNew078 == 2) count too

inline const char* hand_name(int h) { return h == kLeft ? "left" : "right"; }
inline const char* button_name(int b) {
  switch (b) { case kFaceBottom: return "bottom face button (A / X)"; case kFaceTop: return "top face button (B / Y)"; case kGrip: return "grip"; case kTrigger: return "trigger";
               case kStickClick: return "stick click"; case kStick: return "stick"; default: return "?"; }
}

}  // namespace ctlmap
