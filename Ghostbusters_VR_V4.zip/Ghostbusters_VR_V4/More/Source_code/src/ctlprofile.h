// 1.7.117 controller compatibility: one pure place that turns SteamVR's legacy controller state into what the mod expects (a Touch-style
// vocabulary: stick on axis 0, bit 1 = B/Y, bit 7 = A/X, bit 2 = grip, bit 32 = stick click). Plain C so vr_openvr.c (C) and tests/test_ctlprofile.cpp share it.
//
// Rules this file keeps:
//  * Touch-style controllers (Quest, Rift, Pico, Focus 3, Steam Frame) come out EXACTLY as before (handaxismath.h unchanged for them).
//  * Nothing here talks to SteamVR; the caller reads the properties and hands them in.
//
// What it adds, per controller kind (all from Valve's own legacy bindings for each controller, Valve's SteamVR driver files, summarised in docs/CHANGES_1.7.117.md):
//  * Valve Index: the stick has no real click, SteamVR fires the "click" bit when the stick is pushed past 80 % - that is not a sprint / capture click, so it is dropped.
//    (A real Valve Index only; an Index look-alike such as Virtual Desktop's "Emulate Index Controllers" has the Quest's real click and is left alone.)
//  * Vive wand: the trackpad is the stick; a click on the LOWER part of the pad is the A button, a click elsewhere is the stick click.
//  * Windows MR: the trackpad click is the A button (the stick has its own click).
//  * Unknown / other controllers: the stick is found from SteamVR's own axis types (joystick, then trackpad) or, when it tells nothing, from which axis really moves.
//  * Grip squeeze: where the grip has no analog value (everything but Touch) it follows the grip button; where axis 2 is the stick it is never read as the grip.
//  * Settings-file overrides (controller_layout, stick_axis) beat the detection.
#pragma once
#include <stdint.h>
#include "handaxismath.h"

enum { GBVR_LAYOUT_AUTO = 0, GBVR_LAYOUT_TOUCH = 1, GBVR_LAYOUT_INDEX = 2, GBVR_LAYOUT_VIVE = 3, GBVR_LAYOUT_WMR = 4, GBVR_LAYOUT_GENERIC = 5 };
enum { GBVR_AXT_NONE = 0, GBVR_AXT_TRACKPAD = 1, GBVR_AXT_JOYSTICK = 2, GBVR_AXT_TRIGGER = 3 };   /* EVRControllerAxisType */

struct GbvrDecodeIn {
  int family;              /* detected: 0 unknown, 1 Touch-style, 2 Index, 3 Vive, 4 Windows MR, 5 other */
  int layoutOverride;      /* 0 = automatic, else GBVR_LAYOUT_* (1..5 are family numbers) */
  int stickAxisForce;      /* -1 = automatic, else 0..4 */
  int lookalike;           /* Index-type controller not made by Valve */
  int axisType[5];         /* EVRControllerAxisType per axis, -1 = SteamVR did not say */
  float peaks[5];          /* largest push seen so far on each axis (before this sample) */
  float ax[5], ay[5];      /* rAxis[i].x / .y */
  uint64_t pressed, touched;
};
struct GbvrDecodeOut {
  float x, y, grip;        /* stick (normalized to the Touch layout) and grip squeeze 0..1 */
  uint64_t pressed, touched;
  int axis;                /* the analog axis the stick was read from */
  int family;              /* the family actually used (after the override) */
  int padA;                /* 1 = A was made from a trackpad click this sample */
};
struct GbvrDecState {      /* per hand, lives with the controller */
  int edgeBlock, clickPrev;   /* Index edge-push guard */
  int padLatch, padIsA;       /* trackpad click zone decision, held until release */
  long edgeSupp, padAClicks, padStickClicks;   /* counters for the log */
};

static inline int gbvr_effective_family(int detected, int layoutOverride) {
  return (layoutOverride >= 1 && layoutOverride <= 5) ? layoutOverride : detected;
}
static inline float gbvr_clamp01(float v) { return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v); }

/* the stick's analog axis for an unknown / other controller: SteamVR's axis types first, then which axis really moves, else axis 0 (the Touch way) */
static inline int gbvr_generic_axis(const int* axisType, const float* peaks) {
  static const int order[4] = {0, 2, 3, 4};
  int i;
  for (i = 0; i < 4; ++i) if (axisType[order[i]] == GBVR_AXT_JOYSTICK) return order[i];
  for (i = 0; i < 4; ++i) if (axisType[order[i]] == GBVR_AXT_TRACKPAD) return order[i];
  if (peaks[0] < 0.2f) {
    int best = 0; float bp = 0.2f;
    for (i = 1; i < 4; ++i) if (peaks[order[i]] > bp) { bp = peaks[order[i]]; best = order[i]; }
    return best;
  }
  return 0;
}

/* the stick's click arrives as the bit of ITS axis (32 + axis); the mod expects bit 32. Returns the raw click bit of axis 0 (the trackpad's own click) through *padRaw. */
static inline void gbvr_move_click(int ax, uint64_t pressed, uint64_t touched, uint64_t* pr, uint64_t* tc, int* padRaw) {
  const uint64_t bit0 = 1ull << 32;
  *padRaw = (pressed & bit0) ? 1 : 0;
  *pr = pressed; *tc = touched;
  if (ax) {
    const uint64_t bitAx = 1ull << (32 + ax);
    *pr = pressed & ~bit0; *tc = touched & ~bit0;
    if (pressed & bitAx) *pr |= bit0;
    if (touched & bitAx) *tc |= bit0;
  }
}

static inline void gbvr_decode(const struct GbvrDecodeIn* in, struct GbvrDecState* st, struct GbvrDecodeOut* o) {
  const uint64_t bit0 = 1ull << 32, bitA = 1ull << 7, bitGrip = 1ull << 2;
  const int fam = gbvr_effective_family(in->family, in->layoutOverride);
  int trackpadStick = 0;     /* the stick is really a trackpad (Vive wand, or a generic pad): bottom of the pad = A */
  int padClickToA = 0;       /* the trackpad's own click is the A button (Windows MR) */
  int padRaw = 0;
  o->family = fam; o->padA = 0;
  if (in->stickAxisForce >= 0 && in->stickAxisForce <= 4) {   /* the player said where the stick is */
    const int ax = in->stickAxisForce;
    o->axis = ax; o->x = in->ax[ax]; o->y = in->ay[ax];
    gbvr_move_click(ax, in->pressed, in->touched, &o->pressed, &o->touched, &padRaw);
    trackpadStick = in->axisType[ax] == GBVR_AXT_TRACKPAD && ax == 0;
    padClickToA = ax != 0 && in->axisType[0] == GBVR_AXT_TRACKPAD;
  } else if (fam == 0 || fam == 5) {
    const int ax = gbvr_generic_axis(in->axisType, in->peaks);
    o->axis = ax; o->x = in->ax[ax]; o->y = in->ay[ax];
    gbvr_move_click(ax, in->pressed, in->touched, &o->pressed, &o->touched, &padRaw);
    trackpadStick = in->axisType[ax] == GBVR_AXT_TRACKPAD && ax == 0;
    padClickToA = ax != 0 && in->axisType[0] == GBVR_AXT_TRACKPAD;
  } else {
    struct GbvrStickRead sr;
    gbvr_pick_stick(fam, fam == 2 ? in->lookalike : 0, in->peaks[3] > 0.2f, in->ax, in->ay, in->pressed, in->touched, &sr);
    o->axis = sr.axis; o->x = sr.x; o->y = sr.y; o->pressed = sr.pressed; o->touched = sr.touched;
    padRaw = (in->pressed & bit0) ? 1 : 0;
    trackpadStick = fam == 3;
    padClickToA = fam == 4;
  }

  /* grip squeeze: Touch reports it on axis 2; where axis 2 is the stick, or nothing reports it, it follows the grip button */
  o->grip = gbvr_clamp01(in->ax[2]);
  if (fam != 1 || o->axis == 2) {
    if (o->axis == 2) o->grip = 0.0f;
    if (o->grip < 0.05f && (o->pressed & bitGrip)) o->grip = 1.0f;
  }

  /* Valve Index: the stick's "click" is the 80 % edge push, not a click */
  if (fam == 2 && !(fam == 2 && in->lookalike)) {
    const float mag2 = o->x * o->x + o->y * o->y;
    const int click = (o->pressed & bit0) ? 1 : 0;
    if (!click) { st->edgeBlock = 0; }
    else {
      if (!st->edgeBlock && !st->clickPrev && mag2 >= 0.49f) { st->edgeBlock = 1; ++st->edgeSupp; }
      if (st->edgeBlock) o->pressed &= ~bit0;
    }
    st->clickPrev = (o->pressed & bit0) ? 1 : 0;
  }

  /* trackpad controllers have no A button: the lower part of the pad is one */
  if (trackpadStick) {
    const int click = (o->pressed & bit0) ? 1 : 0;
    if (click) {
      if (!st->padLatch) { st->padLatch = 1; st->padIsA = (o->y < -0.5f && o->x > -0.8f && o->x < 0.8f) ? 1 : 0; if (st->padIsA) ++st->padAClicks; else ++st->padStickClicks; }
      if (st->padIsA) { o->pressed &= ~bit0; o->pressed |= bitA; o->padA = 1; }
    } else { st->padLatch = 0; st->padIsA = 0; }
  } else if (padClickToA && padRaw) {
    o->pressed |= bitA; o->padA = 1;
  }
}

/* A "quick grip tap" detector for the Valve Index: its A button reaches the legacy layer as the grip (bit 2), so the two cannot be told apart. A grip press that is
 * released within tapMs, never saw the trigger, started away from the pack zone and is allowed counts as ONE A tap on release; a longer press is a normal grip. */
struct GbvrGripTap { int down, cancel; double heldMs; long taps; };
static inline int gbvr_grip_tap(struct GbvrGripTap* g, int gripNow, float trigger, int inZone, int allowed, double dtMs, double tapMs) {
  int tap = 0;
  if (dtMs < 0.0 || dtMs > 250.0) dtMs = 250.0;
  if (gripNow && !g->down) { g->down = 1; g->heldMs = 0.0; g->cancel = (inZone || !allowed) ? 1 : 0; }
  if (g->down) {
    if (gripNow) {
      g->heldMs += dtMs;
      if (trigger > 0.3f || g->heldMs > tapMs) g->cancel = 1;
    } else {
      if (!g->cancel && g->heldMs <= tapMs) { tap = 1; ++g->taps; }
      g->down = 0; g->cancel = 0; g->heldMs = 0.0;
    }
  }
  return tap;
}
