// 1.7.151 "in the in-game cutscenes the player switches places quickly and it is very disorienting".
// A cutscene is shown on the flat 2D screen. Between its shots the game's camera is, for a second or less, back on the player's own
// camera; the mod took that for play and put you INSIDE the character in 3D (somewhere else in the room), then the next shot threw you
// back to the 2D screen: 2D - 3D - 2D - 3D within seconds (reports: 3D bursts of 50..85 frames between 3..9 s of 2D).
// Rule: once the 2D screen is up, 3D only comes back after the game's play camera has been there WITHOUT A BREAK for holdSec.
// Meanwhile the game's own picture of that shot stays on the 2D screen (nothing is hidden, nothing is changed in the game).
// No wait at all: after the game's own pause menu or a loss of headset tracking; when the 2D screen was only up briefly (3D was shown less than
// minFlatSec ago: a short camera blip in the middle of play is not a cutscene); and the moment you push the move stick (you want to play).
// (Not the trigger: on the 2D screen the trigger is a click, people use it to skip cutscenes.)
// Pure math, no libm; tests/test_cuthold.cpp and tests/test_cuthold_stress.cpp.
#pragma once

namespace cuthold {

struct Hold {
  double okSince;      // start of the current unbroken run of playable frames (-1 = none)
  double lastOk;       // time of the last playable frame
  int menuRun;         // this run started right after the game's pause menu / lost tracking: no wait
  int quickRun;        // this run started soon after 3D was last shown: no wait
  double last3D;       // last time a frame was let through to 3D (-1 = never)
  int freed;           // this run was let through (stays through until 3D is up)
  int holding;         // 1 while frames are being kept on the 2D screen
  long holds, shortShots, fullWaits, byInput, byMenu, byQuick;   // episodes begun / ended by a new shot / by the full wait / by the player / skipped for a menu
  double longestShort; // longest playable run that was NOT shown in 3D (a cutscene shot), seconds
  void reset() { okSince = lastOk = last3D = -1.0; menuRun = quickRun = freed = holding = 0; holds = shortShots = fullWaits = byInput = byMenu = byQuick = 0; longestShort = 0.0; }
};

// Called for every frame the game's play camera passed all checks (a frame that could be shown in 3D).
//   now: seconds, flat: the 2D screen is up now, pausedAgo: seconds since the game's pause menu was last seen (big = never),
//   input: the player pushes the move stick, holdSec: the wait (0 = off), minFlatSec: 3D must have been gone this long for a wait.
// Returns 1 = keep this frame on the 2D screen, 0 = show it in 3D.
inline int step(Hold* h, double now, int flat, double pausedAgo, int input, double holdSec, double minFlatSec = 2.0) {
  const double kBreak = 0.25;   // no playable frame for this long = the run was broken (another shot, a video, a menu)
  if (!(now == now)) return 0;
  const int broken = h->okSince < 0.0 || !(now - h->lastOk <= kBreak) || now < h->lastOk;
  if (broken) {
    if (h->holding) { ++h->shortShots; const double len = h->lastOk - h->okSince; if (len > h->longestShort) h->longestShort = len; }
    h->okSince = now; h->freed = 0; h->holding = 0;
    h->menuRun = pausedAgo >= 0.0 && pausedAgo < 2.5;   // the menu may take a moment to close
    h->quickRun = h->last3D >= 0.0 && now >= h->last3D && now - h->last3D < minFlatSec;
  }
  h->lastOk = now;
  if (!flat) { h->holding = 0; h->freed = 1; h->last3D = now; return 0; }          // 3D is up: nothing to hold
  if (!(holdSec > 0.0)) { h->holding = 0; h->last3D = now; return 0; }
  if (h->freed) { h->last3D = now; return 0; }                      // already let through; the 3D picture is a frame or two away
  if (h->menuRun) { h->freed = 1; ++h->byMenu; h->last3D = now; return 0; }
  if (h->quickRun) { h->freed = 1; ++h->byQuick; h->last3D = now; return 0; }
  if (input) { h->freed = 1; if (h->holding) { h->holding = 0; ++h->byInput; } h->last3D = now; return 0; }
  if (now - h->okSince >= holdSec) { h->freed = 1; if (h->holding) { h->holding = 0; ++h->fullWaits; } h->last3D = now; return 0; }
  if (!h->holding) { h->holding = 1; ++h->holds; }
  return 1;
}

}  // namespace cuthold
