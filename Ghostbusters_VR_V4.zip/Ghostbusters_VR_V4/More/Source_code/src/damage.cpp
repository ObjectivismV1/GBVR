// 0.76 fight module: more beam damage, the enemy list for the health bars, the slam meter and the gun's real hose end.
//
// DAMAGE. Every enemy class of the game derives from CCharacter and takes damage through the virtual function in vtable slot 34
// (offset +0x110): bool hurt(CCharacter* this, SDamageInfo* info) - the player's beam code calls it as `call [rax+0x110]` on the victim.
// SDamageInfo: +0x08 damage type, +0x18 ammo type, +0x20 strength, +0x28 continuousStrength, +0x50 the weapon / attacker. Each enemy class
// has its own override (21 different functions, listed below with the vtable they sit in). The overrides are replaced in the vtables by
// small thunks; a thunk multiplies strength and continuousStrength of a BEAM damage by beam_damage_pct / 100 and then calls the original.
// Beam = damage type ProtonBeam / Slime / Wrangle (capture stream) / WrangleSlam / Freeze (stasis) or ammo type SuperBeam .. BoltBeam,
// slimes (fightmath.h). Nothing else (bullets, explosions, the enemies' own attacks on you) is touched. A guard stops a hurt call that is
// made from inside another hurt call being boosted twice. The player's side (CGhostbuster) never goes through these slots.
//
// BARS. The actor list starts at [world + 0x3ADC0] (world pointer = global at RVA 0xDCF680), next = [actor + 0x288], vtable pointer first.
// An actor whose vtable is one of the enemy vtables is an enemy; health = [+0xB860], max health = [+0xB868], bounding radius [+0x184],
// bounds centre [+0x188..+0x190] (world, feet; the game's own script calls getBoundsCenter / getBoundingSphereRadius read exactly these).
#include "gbvr.h"
#include "trapholdmath.h"

#if GBVR_HEADTRACK
#include "layout.h"
#include "memcache.h"
#include "vmath.h"
#include "fightmath.h"
#include "barlogic.h"
#include "barlifemath.h"
#include "bossringmath.h"   // 1.7.106
#include "healthposmath.h"
#include "hapticmath.h"
#include "MinHook.h"

volatile LONG g_dartHitsSeen;   // 1.7.221: Boson Dart hits the game reported
namespace {

struct EnemyClass { const char* name; uint32_t vt; uint32_t fn; };
// vtable RVA and the RVA of the function that sits in slot 34 (checked at install: a different exe leaves everything alone)
const EnemyClass kEnemies[] = {
  {"CArchitect", 0x7386b0, 0x24370},  {"CAzetlor", 0x73a630, 0x2aff0},   {"CBiped", 0x73f3a0, 0x35880},        {"CBipedLarge", 0x741cf8, 0x3ce70},
  {"CBlinkers", 0x744a48, 0x45cd0},   {"CFloater", 0x75d4c8, 0x9c100},   {"CFlyerMedium", 0x760f88, 0xa3010},  {"CFlyerSmall", 0x7624e8, 0xa8020},
  {"CGargoyle", 0x765258, 0xaf640},   {"CGhost", 0x76a748, 0xbd450},     {"CGolem", 0x778328, 0xfe800},        {"CGolemBase", 0x7798a8, 0x103960},
  {"CLibrarian", 0x77f730, 0x116d80}, {"CNightmare", 0x786730, 0x12a780}, {"COrreryBoss", 0x789360, 0x132490}, {"CPhantom", 0x78c198, 0x136520},
  {"CScuttler", 0x797520, 0x1545e0},  {"CSlimer", 0x799910, 0x15ad70},   {"CSpiderWitch", 0x79cce0, 0x162c80}, {"CStayPuftMinion", 0x79de98, 0x166840},
  {"CStayPuftBoss", 0x7a0678, 0x16e2b0}};
const int kNE = (int)(sizeof(kEnemies) / sizeof(kEnemies[0]));
const uint32_t kHurtSlot = 34;
const uint32_t kRvaWorldPtr = 0xDCF680, kOffActorList = 0x3ADC0, kOffNext = 0x288, kOffHealth = 0xB860, kOffHealthMax = 0xB868, kOffRadius = 0x184, kOffCenter = 0x188;
const uint32_t kRvaGolemPartVtable = 0x7793E0;   // 1.7.38 CGolemPartBase (named in the 1.7.38 log)
const uint32_t kOffSlamGauge = 0x24A40, kOffSlamActive = 0x24A48, kOffActionMask = 0xC7A8, kRvaSlamThreshold = 0xDCD278;
// 0.77: an actor stores the render frame counter of the last time it passed the game's cull test at +0x298; the global counter is at RVA 0x25241A4
// (the game's own "was visible" test is  counter - 1 <= actor[+0x298] ). The game's line-of-sight test (the script function behind
// canSeeActor): bool los(CActor* from, const float* worldFt3) - 1 when no world geometry is between the actor's eye point and the point.
const uint32_t kRvaFrameCounter = 0x25241A4, kOffSeenFrame = 0x298, kRvaLosTest = 0x7BCE0;
// the player's inventory (EInventoryItem 0..7): state dword at +0xCFE0 + 0x18*item; the game's own "ready this item" function (this, item) is at RVA 0xE3EF0
const uint32_t kOffItems = 0xCFE0, kOffItemStride = 0x18, kOffPrevItem = 0xD0A4, kOffReqItem = 0x24CDC, kOffTrapObj = 0x24D88, kOffTrapState = 0xD040, kRvaReadyItem = 0xE3EF0, kRvaDeployTrap = 0xE3A40;
typedef unsigned char(__fastcall* LosFn)(void* from, const float* to);
typedef unsigned char(__fastcall* ReadyFn)(void* player, int item);
typedef unsigned char(__fastcall* DeployFn)(void* player, unsigned char arg);   // 1.7.175: the game's own 'throw the trap now' (no windup animation)

typedef unsigned char(__fastcall* HurtFn)(void* self, uint8_t* info);
enum { kMaxThunks = 24 };
HurtFn g_orig[kMaxThunks];
int g_nThunks;
int g_installed;       // number of vtables patched
int g_failed;
volatile LONG g_depth;

struct SeenKey { int type, ammo; LONG n, boosted; int cls; };
SeenKey g_seen[24];
int g_nSeen;
struct { volatile LONG calls, boosted, nested, skipped, bad, off; double extra; } g_dm;

const char* class_name_of_vtable(uintptr_t vp) {
  for (int i = 0; i < kNE; ++i) if (vp == rva(kEnemies[i].vt)) return kEnemies[i].name;
  return "?";
}
int class_index(uintptr_t vp) {
  for (int i = 0; i < kNE; ++i) if (vp == rva(kEnemies[i].vt)) return i;
  return -1;
}

void note_seen(int type, int ammo, int cls, int boosted) {
  for (int i = 0; i < g_nSeen; ++i)
    if (g_seen[i].type == type && g_seen[i].ammo == ammo && g_seen[i].cls == cls) { ++g_seen[i].n; if (boosted) ++g_seen[i].boosted; return; }
  if (g_nSeen < 24) { g_seen[g_nSeen].type = type; g_seen[g_nSeen].ammo = ammo; g_seen[g_nSeen].cls = cls; g_seen[g_nSeen].n = 1; g_seen[g_nSeen].boosted = boosted ? 1 : 0; ++g_nSeen;
    log_line("DMGSEEN new damage: type 0x%x ammo 0x%x on %s -> %s", type, ammo, kEnemies[cls >= 0 ? cls : 0].name, boosted ? "a beam: boosted" : "not a beam: left alone"); }
}

struct SlamMask { long samples, lockEnemy, capture, captureAndLock, gaugeUp, gaugeUpAndLock, windowSamples, winCapture, winFire, winBoth, winLock; int nMasks, heldNow; unsigned masks[16]; } g_sm;   // 1.7.21
struct { long hits[2]; double damage[2]; int logged; float lastBefore, lastAfter; volatile int64_t slamQ; float slamStrength; long slamHitsNoDamage; } g_hitlog;   // [0] capture stream (0x72)  [1] slam (0x73)
unsigned char hurt_common(int k, void* self, uint8_t* info) {
  const HurtFn orig = g_orig[k];
  const LONG pct = g_ctl.beamDamagePct;
  if (!info || !self) { InterlockedIncrement(&g_dm.off); return orig(self, info); }   // 1.7.2: was also taken when the boost was off (pct <= 100), which also silenced the hit log and the touch buzz
  const LONG depth = InterlockedIncrement(&g_depth);
  InterlockedIncrement(&g_dm.calls);
  float* s = nullptr; float* c = nullptr; float s0 = 0.0f, c0 = 0.0f, s1 = 0.0f, c1 = 0.0f;
  int boosted = 0;
  int logKind = -1, logType = 0, logCls = -1;
  float hpBefore = -1.0f;
  if (depth == 1 && memcache::readable(info, 0x60, 0, 1)) {
    const int type = *(const int*)(info + 0x08), ammo = *(const int*)(info + 0x18);
    const int cls = memcache::readable(self, 8, 0, 1) ? class_index(*(const uintptr_t*)self) : -1;
    const int beam = fight::is_beam(type, ammo);
    note_seen(type, ammo, cls, beam);
    if (ammo == 0x11 || ammo == 0x12) InterlockedIncrement(&g_dartHitsSeen);   // 1.7.221: Boson Dart hits the game reported (compared with the DARTLT presses)
    if (type == fight::kDmgWrangle || type == fight::kDmgWrangleSlam) {   // 0.77: the capture stream and the slam, one line per hit (first 80)
      logKind = type == fight::kDmgWrangleSlam ? 1 : 0; logType = type; logCls = cls;
      if (memcache::readable((const uint8_t*)self + kOffHealth, 8, 0, 1)) hpBefore = *(const float*)((const uint8_t*)self + kOffHealth);
    }
    if (beam && pct > 100) {
      s = (float*)(info + 0x20);
      c = (float*)(info + 0x28);
      s0 = *s; c0 = *c;
      if ((s0 > 0.0f || c0 > 0.0f) && s0 == s0 && c0 == c0) {
        s1 = fight::boost(s0, (int)pct);
        c1 = fight::boost(c0, (int)pct);
        *s = s1; *c = c1;
        boosted = 1;
        g_dm.extra += (double)(s1 - s0) + (double)(c1 - c0);
        InterlockedIncrement(&g_dm.boosted);
      } else InterlockedIncrement(&g_dm.skipped);
    }
  } else if (depth > 1) InterlockedIncrement(&g_dm.nested);
  const unsigned char r = orig(self, info);
  // the caller may use the same damage record for several victims or frames: hand it back as it was, so the boost never stacks up
  if (boosted) { if (*s == s1) *s = s0; if (*c == c1) *c = c0; }
  if (logKind >= 0) {
    float hpAfter = -1.0f;
    if (memcache::readable((const uint8_t*)self + kOffHealth, 8, 0, 1)) hpAfter = *(const float*)((const uint8_t*)self + kOffHealth);
    const float sA = (boosted ? s1 : (s ? *s : 0.0f));
    ++g_hitlog.hits[logKind];
    if (logKind == 1) { g_hitlog.slamQ = qpc_now(); g_hitlog.slamStrength = sA; if (hpBefore >= 0 && hpAfter >= 0 && hpBefore - hpAfter < 0.05f) ++g_hitlog.slamHitsNoDamage; }
    if (g_ctl.slamBuzzPct > 0) {   // 1.7 vibration when the stream touches the ghost (a firm pulse on first contact, a soft tug while it holds) and a thud when a slam lands
      static volatile int64_t s_buzzWr, s_buzzSlam;
      const int64_t nq = qpc_now(); const float kb = (float)g_ctl.slamBuzzPct * 0.01f;
      if (logKind == 1) { if (!s_buzzSlam || nq - s_buzzSlam > qpc_freq() * 3 / 10) { haptics_add(1, hap::kSrcSlam, 1.0f * kb, 240); haptics_add(0, hap::kSrcSlam, 0.9f * kb, 200); } s_buzzSlam = nq; }
      else { const int first = !s_buzzWr || nq - s_buzzWr > qpc_freq() * 4 / 10; haptics_add(1, hap::kSrcSlam, (first ? 0.75f : 0.28f) * kb, first ? 130 : 90); if (first) haptics_add(0, hap::kSrcSlam, 0.5f * kb, 100); s_buzzWr = nq; }
    }
    if (hpBefore >= 0 && hpAfter >= 0) g_hitlog.damage[logKind] += (double)(hpBefore - hpAfter);
    g_hitlog.lastBefore = hpBefore; g_hitlog.lastAfter = hpAfter;
    if (g_hitlog.logged < 80 && (logKind == 1 || (g_hitlog.hits[0] % 40) == 1)) {
      ++g_hitlog.logged;
      log_line("HIT %s (type 0x%x) on %s: strength=%.1f health %.1f -> %.1f (max %.1f) hurt() returned %d", logKind ? "SLAM" : "capture stream", logType,
               logCls >= 0 ? kEnemies[logCls].name : "?", (double)sA, (double)hpBefore, (double)hpAfter,
               memcache::readable((const uint8_t*)self + kOffHealthMax, 4, 0, 1) ? (double)*(const float*)((const uint8_t*)self + kOffHealthMax) : -1.0, (int)r);
    }
  }
  InterlockedDecrement(&g_depth);
  return r;
}
template <int K> unsigned char __fastcall hurt_thunk(void* self, uint8_t* info) { return hurt_common(K, self, info); }
void* const kThunks[kMaxThunks] = {
  (void*)hurt_thunk<0>, (void*)hurt_thunk<1>, (void*)hurt_thunk<2>, (void*)hurt_thunk<3>, (void*)hurt_thunk<4>, (void*)hurt_thunk<5>, (void*)hurt_thunk<6>, (void*)hurt_thunk<7>,
  (void*)hurt_thunk<8>, (void*)hurt_thunk<9>, (void*)hurt_thunk<10>, (void*)hurt_thunk<11>, (void*)hurt_thunk<12>, (void*)hurt_thunk<13>, (void*)hurt_thunk<14>, (void*)hurt_thunk<15>,
  (void*)hurt_thunk<16>, (void*)hurt_thunk<17>, (void*)hurt_thunk<18>, (void*)hurt_thunk<19>, (void*)hurt_thunk<20>, (void*)hurt_thunk<21>, (void*)hurt_thunk<22>, (void*)hurt_thunk<23>};

// ---- bars ---------------------------------------------------------------------------------------------------------------------
struct BarFrame { float view[9], head[3]; double fpm; };
struct { volatile LONG seq; BarFrame frame; } g_barFrame;
struct Snap { volatile LONG seq; int n; fight::Bar b[fight::kMaxBars]; BarFrame frame; int64_t qpc; };
Snap g_snap;
struct Track { uintptr_t id; int64_t useQ; float frac, hitBase; int64_t changeQ; float shown; int64_t shownQ; int seen; int64_t inactiveQ; int trapped; float trapAnchor[3]; int64_t goneQ; int vanished; int64_t losQ; int los; int64_t watchQ; int caught; int64_t rlosQ; int rlos; float moveAnchor[3]; int64_t moveAnchorQ, moveQ; float healthAnchor[3], bossAnchor[3]; int64_t healthAnchorQ, bossAnchorQ; float healthVel[3], bossVel[3]; };   // smoothed world anchors for health bars and circular rings
static inline void track_reset(struct Track& t, uintptr_t actor, float frac) { t.caught = 0; t.id = actor; t.frac = frac; t.hitBase = frac; t.changeQ = 0; t.shownQ = 0; t.seen = 0; t.inactiveQ = 0; t.trapped = 0; t.trapAnchor[0] = t.trapAnchor[1] = t.trapAnchor[2] = 0.0f; t.goneQ = 0; t.vanished = 0; t.losQ = 0; t.los = 0; t.watchQ = 0; t.rlosQ = 0; t.rlos = 0; t.moveAnchor[0] = t.moveAnchor[1] = t.moveAnchor[2] = 0.0f; t.moveAnchorQ = 0; t.moveQ = 0; t.healthAnchorQ = t.bossAnchorQ = 0; for (int k = 0; k < 3; ++k) t.healthVel[k] = t.bossVel[k] = 0.0f; }
static volatile int64_t g_lastHitQ;   // 1.4: when any bar's ghost last lost health

// 1.7.116: 256 slots (it was 48) and trackslot.h decides where a record lives. The game keeps every enemy of the level in its list, also the ones that have not spawned (a pack of floaters is dozens),
// and a long session meets many; each got a slot for good. When 48 were met, a new ghost took slot (address >> 4) % 48 that another ghost owned: the two reset each other's record every scan, so
// "this ghost just lost health" (what shows the ring on a ghost you shoot) never held for either. Now a new ghost takes a free slot, or the slot that was not used for the longest time (a ghost
// that left the list); if every slot was used in this very scan, the spare slot (index kTrackN, reset every time) so nobody's record is taken.
#include "trackslot.h"
#include "ghostmovemath.h"   // 1.7.118: a ghost that is flying about is out (one that has not spawned stands still)
static const int kTrackN = 256;
Track g_track[kTrackN + 1];
static long g_trackEvict, g_trackUsed, g_trackThrash;   // records taken over from a stale ghost / most slots in use / ghosts that had to use the spare slot (= the table is too small)
static int track_slot(uintptr_t actor, float frac, int64_t now) {
  int fresh = 0, evicted = 0, used = 0;
  const int ti = trackslot::pick(g_track, kTrackN, actor, now, &fresh, &evicted, &used);
  if (fresh) {
    track_reset(g_track[ti], actor, frac); g_track[ti].useQ = now;
    if (used + 1 > g_trackUsed) g_trackUsed = used + 1;
    if (evicted) ++g_trackEvict;
    if (ti == kTrackN) ++g_trackThrash;
  }
  return ti;
}
static SRWLOCK g_lifeLock = SRWLOCK_INIT;
static barlife::Ledger g_life;
static struct { int installed, deadState; long events, hiddenDead, hiddenCaught; } g_lifeSt;
typedef void(__fastcall* TrapCompleteFn)(void*);
static TrapCompleteFn o_trapComplete;
static void __fastcall hk_trap_complete(void* self) {
  AcquireSRWLockExclusive(&g_lifeLock);
  g_life.caught((uintptr_t)self);
  ++g_lifeSt.events;
  ReleaseSRWLockExclusive(&g_lifeLock);
  if (g_lifeSt.events <= 40) log_line("BARLIFE confirmed trap completion #%ld for actor %p; its bar is retired", g_lifeSt.events, self);
  o_trapComplete(self);
}
static void install_bar_lifecycle() {
  if (g_lifeSt.installed) return;
  g_lifeSt.installed = -1;
  // CCharacter::isDead (script wrapper 0x84D20 -> 0x7B170) calls
  // vslot 0x328 -> 0x7B100, which reads death state at +0xB874.
  static const uint8_t deadCode[] = {0x81,0x79,0x50,0x23,0xa1,0x78,0x00,0xb8,0x02,0x00,0x00,0x00,0x75,0x06,0x8b,0x81,0x74,0xb8,0x00,0x00,0xc3};
  const uint8_t* dc = (const uint8_t*)rva(0x7B100);
  int same = memcache::readable(dc, sizeof(deadCode), 0, 1);
  for (unsigned i = 0; same && i < sizeof(deadCode); ++i) if (dc[i] != deadCode[i]) same = 0;
  g_lifeSt.deadState = same;
  // CGhostTrap completion at 0xF3FAB calls 0xBC080(ghost), which
  // dispatches gotTrappedEvent (+0xDFA0), then clears its trap state.
  static const uint8_t trapCode[16] = {0x40,0x56,0x41,0x56,0x48,0x83,0xec,0x48,0x48,0x8b,0x05,0x11,0x33,0xd5,0x00,0x48};
  const uint8_t* tc = (const uint8_t*)rva(0xBC080);
  same = memcache::readable(tc, sizeof(trapCode), 0, 1);
  for (unsigned i = 0; same && i < sizeof(trapCode); ++i) if (tc[i] != trapCode[i]) same = 0;
  MH_STATUS status = MH_ERROR_UNSUPPORTED_FUNCTION;
  if (same) {
    status = MH_CreateHook((void*)tc, (void*)hk_trap_complete, (void**)&o_trapComplete);
    if (status == MH_OK) status = MH_EnableHook((void*)tc);
    if (status == MH_OK) g_lifeSt.installed = 1;
  }
  log_line("BARLIFE trap-completion hook=%d status=%d, verified character death state=%d (read only; no damage changes)", g_lifeSt.installed, (int)status, g_lifeSt.deadState);
}

// 1.5: which ghost gets the game's own health ring (the ghost you look at; it stays a moment after you look away or fire)
struct RingPick { volatile LONG seq; int valid; float pos[3]; float frac; int64_t qpc; uintptr_t actor; };
RingPick g_rp;
struct { uintptr_t cur; int64_t lastInQ; long scans, picks, switches, held, none, noCandidate; float lastAng, lastDistM, lastFrac; int logged; long cls[8];
         long lockChecks, notLockable, droppedGone, lockUnreadable, goneLogged, beamPicks, lockOverride, overHit, overHeld, overDrawn, overMoving; } g_rps;
// 1.6 the game's own "can the player lock onto this enemy" test: virtual +0x360 of the actor (CGhost / CFloater / CSlimer: the ghost is active and in a state that can be locked; the other classes: the lock-on capability flag).
// The 1.5 log: the ring was put on, and held at, ghosts that were not really there any more (the game keeps hidden / finished / not-yet-active enemies in its actor list at full health).
// Used as an extra test for the ring only. 1 = lockable (or not readable: then the old behaviour).
static int actor_lockable(uintptr_t actor, uintptr_t player) {
  if (!actor || !player || !memcache::readable((const void*)actor, 8, 0, 1)) return 1;
  const uintptr_t lo = rva(0), hi = lo + layout::kExpectedSizeOfImage;
  const uintptr_t vt = *(const uintptr_t*)actor;
  if (vt < lo || vt >= hi || !memcache::readable((const void*)(vt + 0x360), 8, 0, 1)) { ++g_rps.lockUnreadable; return 1; }
  const uintptr_t fn = *(const uintptr_t*)(vt + 0x360);
  if (fn < lo || fn >= hi) { ++g_rps.lockUnreadable; return 1; }
  ++g_rps.lockChecks;
  return ((unsigned char(__fastcall*)(void*, void*))fn)((void*)actor, (void*)player) != 0;
}
struct { long scans, enemies, shown, noWorld, dead, fartherThanRange, behind, centerLocal, centerWorld; int maxSeen, lastSeen; int logged; int64_t logQ; float lastFrac; int lastCls; float lastDistM, lastRadFt;
         float lastCenterOff;
         // 1.7.2: the length of the game's actor list (the 1.7.1 log proved the scan stopped at 700: the counts of every other kind added up to exactly 699 + 1 enemy, and real ghosts come later in the list)
         long eased, easing, listLast, listMax, capHits, listLogged, scanUsSum, scanUsMax, slowSkips, skipLeft, listOver700; } g_bs;
// 1.7.2: how many actors of the game's list are walked at most per scan (the 1.7.1 limit of 700 hid every real ghost)
static const int kMaxActors = 20000;
// 1.7.106 BOSS data (bossringmath.h): what the scan saw of the big enemies, and why a boss did or did not get the game's health ring
static struct { long scans, present, byHit, byHeld, byDrawn, byMove, byLine, absent, tooFar, ringCand, picked, barsMade, lockYes, lockNo, bigNotListed, wallSkipped, wallRefused; float lastHealth, lastMax, lastDistM, lastAng; char lastName[24]; int logged; uintptr_t seen[12]; int nSeen; } g_boss;
// 1.7.108 RING WALL: the ring goes only to an enemy you can see (a clear line from the headset), or one you are hitting / holding. Counters for the 30 s line.
static struct { long tests, clear, refused, byHit, byHeld, bigRefused; } g_rw;

// slam / game state of the player
struct { volatile LONG ready; float gauge, thr; int active; unsigned mask; int64_t logQ; int lastReady, lastActive; unsigned lastMask; long samples, readyEdges, activeEdges, fireEdges; int logged;
         // 1.7.2: the game's "wrangled target" field (player+0x24D80): a ghost held by the capture stream. wrSeen counts samples where it was non-null (0 = the field was never seen used: not trusted)
         volatile LONG wrangled; long wrSeen, wrSamples; uintptr_t wrPtr; char wrName[40]; int wrLogged;
         uintptr_t lockPtr; int64_t capQ; long golemHeld; } g_sl;   // 1.7.31: lockPtr = the ghost the player is locked onto now (the one the capture stream holds), capQ = when the capture button was last down
// 1.7.2: every slam the left trigger started is followed for 3.2 s and judged in the log (SLAMRESULT): did the meter drop, did the game's slam hit land
struct SlamSeq { int pending; int64_t q; double pullX, pullY; float gauge0; int wr0; long hits0; float g[5]; int got; int n; };
struct { SlamSeq s; long started, landed, usedNoHit, nothing, heldAtPress, notHeldAtPress, logged; } g_sq;
static const double kSeqAt[5] = {0.25, 0.5, 1.0, 2.0, 3.2};

// 1.7 easy sprint: the game's own sprint tuning values (its tuning table: 'Sprint start delay time' 0.55 s, 'Sprint max duration' 5 s, 'Sprint blocked time (after expire)' 2.5 s, 'Sprint turn rate clamp (degrees)' 65).
// The 1.6 log: 28 taps of the sprint button of 0.16-0.43 s each, every one shorter than the 0.55 s the game waits before it sprints. Four floats in a row at 0xDCCFF4.

// 1.7: the living enemies of the last scan (position and size), so a world point can be asked "is this a ghost?" (the aim assist only pulls toward ghosts, never toward tables or chairs the game can also lock onto)
struct EnemyPt { float pos[3], c[3], rad; };
struct { volatile LONG seq; int n; EnemyPt e[64]; int64_t qpc; long asks, ghost, notGhost, unknown; int logged; } g_census;

// 0.77: gate for the bars (only enemies the game itself drew in the last frames AND that have a clear line to you) and per-hit logs of capture / slam
static long s_trapHidden;   // 1.7.25
// 1.7.30 smart health bars (barlogic.h): what the seen-once latch and the trapped latch did
struct { long calPass, calFail, drawnYes, drawnNo, untrustedChecks, firstSeen, forgotten, latched, unlatched, unseenHidden, trappedHidden, floorTrapHidden;
         long inViewDrawn, inViewNot, vlosCalls, vlosClear, vlosBlocked, goneSet, goneCleared, goneHidden, goneOffChecks, heldLatched, watchLines, caughtHidden; int logged, trapLogged, goneLogged, watchLogged; int64_t watchQ; } g_smart;   // 1.7.31: the "gone" rule and the TRAPWATCH log
struct { long visPass, visFail, losClear, losBlocked, losCalls, gateIgnored, shownGate, spawnedHidden, wallHidden, activeAsks, activeHit, activeYes, activeDrawn, notSpawned, activeMoving; int visGateOk; int visBad; long frontSeen; int logged; } g_gate;

// 0.77: the weapon wheel and the trap throw reach the game through here (game thread, once per eye frame)
struct { volatile LONG itemReq; int calls, okReturns, failReturns, skippedMenu, logged; int lastItem, lastRet; } g_cmd;
struct { volatile LONG seq; int st[8]; int cur; int64_t qpc; uintptr_t player; int lastSt[8]; int lastCur; int changes; int owned; } g_inv;
struct { uintptr_t player, boss, world; int64_t qpc, focusQ; float mouth[3]; int stage, focusValid; } g_puft;

// 1.1: the checks the game makes before it switches gear (found in the game's code, see docs 1.1). The 1.0 log: the first PKE came out, then every later Y press was seen by the game and nothing
// happened. Here the fields behind those checks are read about 25 times a second, a line is logged when one changes or the wheel asks for it, and a switch the game leaves half done is finished
// the game's own way (the same call the game makes when it cancels a switch).
namespace sw {
const uint32_t kRvaFinish = 0xE50E0;   // finish a pending switch now: runs the 'stowed' / 'drawn' handlers the animation events would run, clears both pending fields
const uint32_t kRvaPred[6] = {0x7CF10, 0x7D1B0, 0x7D1F0, 0x7D230, 0x7D380, 0xD7070};   // 'is the player in animation state X' checks (pure readers)
enum { kBits = 17 };
const char* const kNames[kBits] = {"switchPending", "cantSwitch(24D74=0)", "script(24858)", "lockTimer(24838)", "flag2485B", "flag2482B", "object88C0", "state C7F0", "object24E78", "item0InHand",
                                   "anim7CF10", "anim7D1B0", "anim7D1F0", "anim7D230", "anim7D380", "animD7070", "requestQueued"};
const unsigned kLogMask = 0x103FFu;    // a change in these bits makes a log line (the animation bits flap during play, they only show up inside lines)
}
typedef unsigned char(__fastcall* PredFn)(void* player);
typedef unsigned char(__fastcall* FinishFn)(void* player);
struct {
  volatile LONG helpReq, noteReq;
  unsigned mask, lastLogMask, flags; int p8, pC, rq, ret, prev, st0;
  unsigned char can, b24858, b2485b, b2482b, b2468, pred[6]; float timer;
  int64_t qpc, pendQ, lastFixQ, lastLogQ, helpQ; int pendA, pendB;
  long samples, logged, noteLogged, fixes, autoFixes, queued, queueSkipped, helps, bitFrames[sw::kBits], maxPendMs, pendEpisodes;
} g_sw;
struct { volatile LONG trackFrames; int64_t trackUntilQ, lastLogQ; int logged; int lastState; float startPos[3]; long throws; } g_trapT;

// 1.7.6 forced sprint. The game never started its own sprint: 1.7.1 held L3 for 3826 polls (0 sprints), 1.7.5 held Jump for 194 polls (0 sprints). The game keeps the sprint in one bit of the action mask
// (player+0xC7A8, bit 0x8000000); that bit picks the sprint (run) animation in 0xD67A0 and is cleared when the sprint timer runs out. While sprint is switched on (click) and the left stick is pushed
// the probe sets the bit itself, once per frame. The mask is read here after the game's own update, so the bit is there when the next update chooses the animation.
// SPRINTGATE lines show the fields the game's start code looks at (found in the code: hold timer 247B4, run timer 247B8, blocked timer 247BC, ring focus 2E8, 24E78, C7F0, 88C0, 24AC1 and the six animation checks).

// the gun's hose end: raw world position asked for by the hose actor, then re-posed with the gun
struct { float raw[3]; int64_t rawQ; uintptr_t asker; long rawN; float posed[3]; int64_t posedQ; long posedN, rejectedFar, noRaw; float head[3]; int64_t headQ; float lastOffFt; float maxOffFt; } g_hs;

int safe_float3(const float* p) { return vm::is_finite_f(p[0]) && vm::is_finite_f(p[1]) && vm::is_finite_f(p[2]); }

// 1.7: everything else in the world (items on the ground are not enemies): the game's own class name (from its type information), how many, the nearest, and how many lie on the floor around you.
// Only for the log: the next version can use it to put a soft light on the right things.
struct WorldCls { uintptr_t vt; int n, nNear, nGround; float nearFt, nearDy, groundFt; char name[40]; int newLogged; };
struct { WorldCls c[64]; int nc; int64_t lastQ; int sumLogged, newLogged, overflow, scans; } g_wc;
static void rtti_name(uintptr_t vp, char* out, int cap) {
  lstrcpyA(out, "?");
  if (cap < 8 || !vp) return;
  const uintptr_t* slot = (const uintptr_t*)vp - 1;
  if (!memcache::readable(slot, 8, 0, 1)) return;
  const uintptr_t col = *slot;
  if (!col || !memcache::readable((const void*)col, 24, 0, 1)) return;
  const uint32_t td = *(const uint32_t*)(col + 12);   // 64-bit complete-object locator: the type descriptor is stored as an offset from the module start
  if (!td || td > 0x10000000u) return;
  const char* nm = (const char*)(g_game.base + td + 16);
  if (!memcache::readable(nm, 48, 0, 1)) return;
  int o = 0, i = 0;
  if (nm[0] == '.' && nm[1] == '?' && nm[2] == 'A') i = 4;
  for (; i < 44 && o < cap - 1; ++i) {
    const char ch = nm[i];
    if (ch == 0 || (ch == '@' && nm[i + 1] == '@')) break;
    out[o++] = (ch >= 32 && ch < 127) ? ch : '_';
  }
  out[o] = 0;
  if (!o) lstrcpyA(out, "?");
}

// 1.7.188 data ("no health bar on the construction ghosts on the roof"): every class in the game's actor list that is NOT one of the enemy classes above, with how many of them hold a plausible health value
// (the construction ghosts are probably one of these). Counted per scan, logged with the 30 s health summary as ACTORKINDS.
static struct UnkKind { uintptr_t vt; char name[40]; long scans, withHealth; float nearFt; int maxN, nowN, thisScan; } g_unk[40];
static int g_nUnk;
static void unk_note(uintptr_t vp, uintptr_t actor, const float* playerPos) {
  int k = -1;
  for (int i = 0; i < g_nUnk; ++i) if (g_unk[i].vt == vp) { k = i; break; }
  if (k < 0) { if (g_nUnk >= 40) return; k = g_nUnk++; g_unk[k].vt = vp; g_unk[k].name[0] = 0; rtti_name(vp, g_unk[k].name, (int)sizeof(g_unk[k].name)); g_unk[k].nearFt = 1e9f; }
  ++g_unk[k].scans; ++g_unk[k].thisScan;
  if (memcache::readable((const void*)(actor + kOffHealth), 16, 0, 1)) {
    const float cur = *(const float*)(actor + kOffHealth), mx = *(const float*)(actor + kOffHealthMax);
    if (cur == cur && mx == mx && mx > 0.0f && mx < 1.0e6f && cur > 0.0f && cur <= mx * 1.001f) {
      ++g_unk[k].withHealth;
      if (playerPos && memcache::readable((const void*)(actor + layout::kActorPos), 12, 0, 1)) {
        const float* ap = (const float*)(actor + layout::kActorPos);
        const double dx = (double)ap[0] - playerPos[0], dy = (double)ap[1] - playerPos[1], dz = (double)ap[2] - playerPos[2];
        const double d2 = dx * dx + dy * dy + dz * dz;
        if (d2 == d2 && d2 < 1.0e8 && (float)vm::dsqrt(d2) < g_unk[k].nearFt) g_unk[k].nearFt = (float)vm::dsqrt(d2);
      }
    }
  }
}
// 1.7.39: is this vtable one of the boss's parts (CGolemPartBase or any other "CGolem..." class that is not one of the enemy classes)? One-entry cache: the lock target is asked every update.
static int golem_part_vt(uintptr_t vt) {
  if (!vt) return 0;
  if (vt == rva(kRvaGolemPartVtable)) return 1;
  if (class_index(vt) >= 0) return 0;
  static uintptr_t s_vt; static int s_res;
  if (vt == s_vt) return s_res;
  char nm[40]; nm[0] = 0;
  rtti_name(vt, nm, (int)sizeof(nm));
  s_vt = vt; s_res = nm[0] == 'C' && nm[1] == 'G' && nm[2] == 'o' && nm[3] == 'l' && nm[4] == 'e' && nm[5] == 'm';
  return s_res;
}
// 1.7.2: "an artifact won't show up". The game's collectibles are CTrinket objects (2 in the 1.7.1 log's level). Log each one close to you: where it is, how far, and how long ago the game's own
// cull test last let it be drawn (+0x298 = the render frame counter of the last time it passed). A big, growing age while you look right at it = the game is culling it.
static const uint32_t kVtTrinket = 0x7A4408;
static struct { uintptr_t id; int64_t q; } g_trk[8];
static struct { int logged; long seen, closeSeen; float nearestFt; } g_trn;
// 1.7.3: glowing markers on the collectibles (CTrinket) and, with the PKE out, on the PKE scan targets (CPKESource, vtable +0x791568 in the 1.7.1 log). Picked-up trinkets are
// recognised the way the game does it (CTrinket::hasBeenPickedUp, RVA 0x179510): the save-table entry of the trophy id (actor+0x4FC) at world+0x4F560 + 16*(id+1) is non-zero.
static const uint32_t kVtPkeSource = 0x791568, kOffTrophyId = 0x4FC, kOffPickTable = 0x4F560;
static struct { volatile LONG seq; int n; fight::Marker m[fight::kMaxMarkers]; int64_t qpc; } g_msnap;
static struct { long scans, trinkets, pickedUp, noId, pkeSrc, published, maxShown, logged, reveals, pings, hidden, proxLogged; double proxNearFt, proxMinFt; uintptr_t seenId[24]; } g_mk;
static struct { uintptr_t id; int64_t aimStartQ, lastAimQ, revealUntilQ; int revealed; } g_mkt[24];   // 1.7.3 per-collectible scan state
static int64_t g_pingQ;
static void trinket_note(uintptr_t actor, const float* pos, const float* pp, int64_t now) {
  if (!safe_float3(pos)) return;
  const double dx = (double)pos[0] - pp[0], dy = (double)pos[1] - pp[1], dz = (double)pos[2] - pp[2];
  const double d = vm::dsqrt(dx * dx + dy * dy + dz * dz);
  ++g_trn.seen;
  if (g_trn.nearestFt == 0.0f || d < g_trn.nearestFt) g_trn.nearestFt = (float)d;
  if (d > 60.0) return;
  ++g_trn.closeSeen;
  int slot = -1;
  for (int i = 0; i < 8; ++i) if (g_trk[i].id == actor) { slot = i; break; }
  if (slot < 0) { for (int i = 0; i < 8; ++i) if (!g_trk[i].id) { slot = i; g_trk[i].id = actor; g_trk[i].q = 0; break; } }
  if (slot < 0 || (g_trk[slot].q && now - g_trk[slot].q < qpc_freq() * 5) || g_trn.logged >= 60) return;
  g_trk[slot].q = now; ++g_trn.logged;
  const int* fc = (const int*)rva(kRvaFrameCounter);
  const int age = memcache::readable(fc, 4, 0, 1) ? *fc - *(const int*)(actor + kOffSeenFrame) : -1;
  log_line("TRINKET a collectible (CTrinket) is %.1f ft away at %.1f,%.1f,%.1f (%+.1f ft up); the game's cull test last let it be drawn %d frames ago (small = it is being drawn; large and growing = the game is culling it); actor %p", d, (double)pos[0], (double)pos[1], (double)pos[2], dy, age, (void*)actor);
}
static void world_note(uintptr_t vp, const float* pos, const float* pp) {
  if (!safe_float3(pos)) return;
  const double dx = (double)pos[0] - pp[0], dy = (double)pos[1] - pp[1], dz = (double)pos[2] - pp[2];
  const double flat = vm::dsqrt(dx * dx + dz * dz);
  WorldCls* w = nullptr;
  for (int i = 0; i < g_wc.nc; ++i) if (g_wc.c[i].vt == vp) { w = &g_wc.c[i]; break; }
  if (!w) {
    if (g_wc.nc >= 64) { ++g_wc.overflow; return; }
    w = &g_wc.c[g_wc.nc++];
    w->vt = vp; w->n = w->nNear = w->nGround = 0; w->nearFt = w->groundFt = 9999.0f; w->nearDy = 0.0f; w->newLogged = 0;
    rtti_name(vp, w->name, (int)sizeof(w->name));
  }
  ++w->n;
  const double d3 = vm::dsqrt(flat * flat + dy * dy);
  if (d3 < 40.0) ++w->nNear;
  if (d3 < w->nearFt) { w->nearFt = (float)d3; w->nearDy = (float)dy; }
  if (flat < 25.0 && dy > -2.5 && dy < 1.5) { ++w->nGround; if (flat < w->groundFt) w->groundFt = (float)flat; }
}


}  // namespace
int fight_actor_dead(uintptr_t actor) { return g_lifeSt.deadState && actor && memcache::readable((const void*)(actor + 0xB874), 4, 0, 1) && *(const int*)(actor + 0xB874) != 0; }   // 1.7.197 the game's death state of a character (read only; 0 when the code is not the verified one)


void damage_install() {
  g_gate.visGateOk = 1;
  if (!g_game.identityOK) { log_line("DMG not installed: the game executable is not the verified build"); return; }
  install_bar_lifecycle();
  // 1.7.21 "make damage from everything the game base, don't affect any damage files": at 100 % nothing is patched (the game's damage code runs exactly as shipped).
  // damage_watch = 1 installs the passthrough hook only for the hit log / slam buzz.
  if (g_ctl.beamDamagePct <= 100 && !g_ctl.damageWatch) {
    log_line("DMG NOT installed (1.7.21): beam damage is the game's own (100 %%) and damage_watch is 0, so no damage code or table is touched. Hit logs and the slam hit buzz are off with it.");
    return;
  }
  int slotFn[kNE];
  for (int i = 0; i < kNE; ++i) {
    slotFn[i] = -1;
    uintptr_t* slot = (uintptr_t*)(rva(kEnemies[i].vt) + 8 * kHurtSlot);
    if (!memcache::readable(slot, 8, 0, 1)) { log_line("DMG %s: vtable not readable - skipped", kEnemies[i].name); ++g_failed; continue; }
    if (*slot != rva(kEnemies[i].fn)) {
      if (g_nThunks && *slot == (uintptr_t)kThunks[0]) { /* already patched (second install call) */ }
      log_line("DMG %s: slot 34 holds %p, expected %p - skipped", kEnemies[i].name, (void*)*slot, (void*)rva(kEnemies[i].fn));
      ++g_failed;
      continue;
    }
    int k = -1;
    for (int j = 0; j < i; ++j) if (slotFn[j] >= 0 && kEnemies[j].fn == kEnemies[i].fn) { k = slotFn[j]; break; }
    if (k < 0) {
      if (g_nThunks >= kMaxThunks) { log_line("DMG %s: out of thunks - skipped", kEnemies[i].name); ++g_failed; continue; }
      k = g_nThunks++;
      g_orig[k] = (HurtFn)rva(kEnemies[i].fn);
    }
    DWORD old = 0;
    if (!VirtualProtect(slot, 8, PAGE_READWRITE, &old)) { log_line("DMG %s: could not make the vtable writable (%lu) - skipped", kEnemies[i].name, (unsigned long)GetLastError()); ++g_failed; continue; }
    *slot = (uintptr_t)kThunks[k];
    DWORD o2 = 0;
    VirtualProtect(slot, 8, old, &o2);
    slotFn[i] = k;
    ++g_installed;
  }
  log_line("DMG installed: %d of %d enemy classes patched (%d hurt functions, %d skipped); beams do %d%% damage (setting beam_damage_pct; 100 = off)", g_installed, kNE, g_nThunks, g_failed, (int)g_ctl.beamDamagePct);
}

void fight_hose_raw(const float* worldFt3, uintptr_t asker) {
  if (!worldFt3 || !safe_float3(worldFt3)) return;
  for (int i = 0; i < 3; ++i) g_hs.raw[i] = worldFt3[i];
  g_hs.rawQ = qpc_now(); g_hs.asker = asker; ++g_hs.rawN;
}

// the render pass that poses the game's wand model (a = the game's own wand matrix, W2 = the matrix it is drawn with): where is the "hose"
// attachment on the drawn gun? Measured in the game's gun frame, carried over to the posed one.
void fight_hose_posed(const float* a, const float* W2) {
  const int64_t now = qpc_now();
  if (!g_hs.rawQ || now - g_hs.rawQ > qpc_freq() / 5) { ++g_hs.noRaw; return; }
  double d[3] = {(double)g_hs.raw[0] - a[12], (double)g_hs.raw[1] - a[13], (double)g_hs.raw[2] - a[14]};
  const double dist = vm::dsqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
  if (dist > 3.5) { ++g_hs.rejectedFar; return; }   // another Ghostbuster's hose
  double l[3], p2[3] = {W2[12], W2[13], W2[14]};
  for (int i = 0; i < 3; ++i) {
    const double rx = a[i * 4], ry = a[i * 4 + 1], rz = a[i * 4 + 2];
    const double n2 = rx * rx + ry * ry + rz * rz;
    if (!(n2 > 1e-6)) return;
    l[i] = (d[0] * rx + d[1] * ry + d[2] * rz) / n2;
  }
  for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) p2[j] += l[i] * (double)W2[i * 4 + j];
  for (int j = 0; j < 3; ++j) g_hs.posed[j] = (float)p2[j];
  if (!safe_float3(g_hs.posed)) return;
  g_hs.posedQ = now; ++g_hs.posedN;
  g_hs.lastOffFt = (float)dist;
  if (g_hs.lastOffFt > g_hs.maxOffFt) g_hs.maxOffFt = g_hs.lastOffFt;
}

int fight_hose_end(float* p3) {
  if (!g_hs.headQ || qpc_now() - g_hs.headQ > qpc_freq() / 4) return 0;
  for (int i = 0; i < 3; ++i) p3[i] = g_hs.head[i];
  return 1;
}

int fight_slam_ready() { return g_sl.ready; }
// 1.7.2 1 = the game says the capture stream holds a ghost; 0 = it does not; -1 = the field has never been seen used in this run (not trusted: the caller must not depend on it)
int fight_wrangled() { return g_sl.wrSeen > 0 ? (int)g_sl.wrangled : -1; }
int fight_slam_active() { const SlamSeq& q = g_sq.s; return (q.pending && q.q && (double)(qpc_now() - q.q) / (double)qpc_freq() < 3.2) ? 1 : 0; }   // 1.7.196 a slam the left trigger started is still playing out
void fight_slam_note(int phase, double a, double b) {
  if (phase == 1) {   // a slam the left trigger started: follow it for 3.2 s (judged in fight_publish)
    SlamSeq& q = g_sq.s;
    q.pending = 1; q.q = qpc_now(); q.pullX = a; q.pullY = b; q.gauge0 = g_sl.gauge; q.wr0 = fight_wrangled(); q.hits0 = g_hitlog.hits[1]; q.got = 0; ++g_sq.started; q.n = (int)g_sq.started;
    if (q.wr0 > 0) ++g_sq.heldAtPress; else if (q.wr0 == 0) ++g_sq.notHeldAtPress;
  }
}

// 1.7.2 the game's own lock on the proton stream (player+0xB550: the stream ends at that actor) and its ring focus (player+0x2E8). The game also locks on tables, chairs and other props it can grab;
// with lock_ghost_only they are let go (the stream then runs straight along the aim). Anything that is one of the 21 enemy classes is left alone. Called from the stream's tip request, before the game looks at the lock.
static struct { long calls, none[3], enemy[3], other[3], cleared[3], unreadable, keptForGrab; int kinds, logged, grabLogged; struct { uintptr_t vt; char name[40]; long n; int golem; } k[24]; long golemKept; } g_lg;
int fight_lock_guard(uintptr_t player) {
  if (!player) return 0;
  ++g_lg.calls;
  static const uint32_t offs[3] = {0xB550u, layout::kOffLockTarget, 0x24D80u};   // 1.7.19: the third slot (what the capture stream holds) is only audited and logged, never cleared
  const uintptr_t lo = rva(0), hi = lo + layout::kExpectedSizeOfImage;
  int cleared = 0;
  const int grabbing = bindings_capture_down();
  for (int k = 0; k < 3; ++k) {
    uintptr_t* slot = (uintptr_t*)(player + offs[k]);
    if (!memcache::readable(slot, 8, 0, 1)) { ++g_lg.unreadable; continue; }
    const uintptr_t t = *slot;
    if (!t) { ++g_lg.none[k]; continue; }
    if (k == 0) { ++g_lg.enemy[0]; continue; }   // 1.7.27: player+0xB550 is the game's HUD (CGameView), not a lock: never touched here (the 1.7.2-1.7.26 guard wiped it, which switched off the PKE goggles and more). The stream update hides it for its own call only (engine_hooks.cpp hk_stream_update).
    if (!memcache::readable((const void*)t, 0x60, 0, 1)) { ++g_lg.unreadable; continue; }
    const uintptr_t vt = *(const uintptr_t*)t;
    if (vt < lo || vt >= hi) { ++g_lg.unreadable; continue; }
    if (class_index(vt) >= 0) { ++g_lg.enemy[k]; continue; }
    // 1.7.38: the parts of a boss golem (CGolemPartBase, CGolemPart: the head, the key part) are wrangled by the game's own lock. The 1.7.2 guard let that lock go as "not a ghost", so the head could never be grabbed (1.7.38 log:
    // "let go" on CGolemPartBase 43 times). Anything named CGolem* is now left alone.
    if (vt == rva(kRvaGolemPartVtable)) { ++g_lg.enemy[k]; ++g_lg.golemKept; continue; }
    int slotK = -1;
    for (int i = 0; i < g_lg.kinds; ++i) if (g_lg.k[i].vt == vt) { slotK = i; break; }
    if (slotK < 0 && g_lg.kinds < 24) {
      slotK = g_lg.kinds++; g_lg.k[slotK].vt = vt; g_lg.k[slotK].n = 0; rtti_name(vt, g_lg.k[slotK].name, (int)sizeof(g_lg.k[slotK].name));
      g_lg.k[slotK].golem = (g_lg.k[slotK].name[0] == 'C' && g_lg.k[slotK].name[1] == 'G' && g_lg.k[slotK].name[2] == 'o' && g_lg.k[slotK].name[3] == 'l' && g_lg.k[slotK].name[4] == 'e' && g_lg.k[slotK].name[5] == 'm');
      if (g_lg.logged < 30) { ++g_lg.logged; log_line("LOCKGUARD the game's %s lock sits on a %s (not a ghost) at %.1f,%.1f,%.1f ft%s", k == 2 ? "capture-held" : (k ? "ring" : "stream"), g_lg.k[slotK].name,
                                                     (double)*(const float*)(t + layout::kActorPos), (double)*(const float*)(t + layout::kActorPos + 4), (double)*(const float*)(t + layout::kActorPos + 8), k == 2 ? ": only noted" : (g_ctl.lockGhostOnly ? ": let go" : ": left alone (lock_ghost_only is off)")); }
    }
    if (slotK >= 0 && g_lg.k[slotK].golem) { ++g_lg.enemy[k]; ++g_lg.golemKept; continue; }
    ++g_lg.other[k];
    if (slotK >= 0) ++g_lg.k[slotK].n;
    // 1.7.38: while the capture/grab button is down the game's own lock on a prop (table, chair, barrel) is LEFT ALONE, so a prop can be grabbed. Props are let go only while you are not grabbing.
    if (k == 1 && grabbing) { ++g_lg.keptForGrab; if (g_lg.grabLogged < 20 && (g_lg.keptForGrab % 30) == 1) { ++g_lg.grabLogged; log_line("GRABKEEP the capture button is down and the game's lock sits on a %s: kept so it can be grabbed (%ld times)", g_lg.k[slotK >= 0 ? slotK : 0].name, g_lg.keptForGrab); } continue; }
    if (k < 2 && g_ctl.lockGhostOnly) { *slot = 0; ++g_lg.cleared[k]; ++cleared; }
  }
  return cleared;
}
int fight_enemy_stats(long* asks, long* ghost, long* notGhost, long* unknown) { if (asks) *asks = g_census.asks; if (ghost) *ghost = g_census.ghost; if (notGhost) *notGhost = g_census.notGhost; if (unknown) *unknown = g_census.unknown; return g_census.n; }
// 1.7: 1 = a living enemy (ghost) sits at this world point (within its size + padFt), 0 = none there (a table, a chair, a wall), -1 = no recent enemy scan (unknown)
int fight_enemy_near(const float* w3, double padFt) {
  if (!w3) return -1;
  ++g_census.asks;
  EnemyPt e[64]; int n = 0; int64_t q = 0;
  int ok = 0;
  for (int tries = 0; tries < 3 && !ok; ++tries) {
    const LONG s0 = g_census.seq;
    if (s0 & 1) continue;
    n = g_census.n; if (n > 64) n = 64; if (n < 0) n = 0;
    for (int i = 0; i < n; ++i) e[i] = g_census.e[i];
    q = g_census.qpc;
    if (g_census.seq == s0) ok = 1;
  }
  if (!ok || !q || qpc_now() - q > qpc_freq() * 2 / 5) { ++g_census.unknown; return -1; }
  for (int i = 0; i < n; ++i) {
    const double r = (double)(e[i].rad > 0.05f && e[i].rad < 60.0f ? e[i].rad : 3.0) + padFt;
    double dx = (double)w3[0] - e[i].c[0], dy = (double)w3[1] - e[i].c[1], dz = (double)w3[2] - e[i].c[2];
    if (dx * dx + dy * dy + dz * dz <= r * r) { ++g_census.ghost; return 1; }
    dx = (double)w3[0] - e[i].pos[0]; dy = (double)w3[1] - e[i].pos[1]; dz = (double)w3[2] - e[i].pos[2];
    if (dx * dx + dy * dy + dz * dz <= r * r) { ++g_census.ghost; return 1; }
  }
  ++g_census.notGhost;
  return 0;
}

// 0.77: the weapon wheel asks the game (on its own thread, at the next eye frame) to ready an item (1 proton, 2 meson, 3 boson, 4 trap, 5 PKE, 6 light, 7 slime)
void fight_request_item(int item) { if (item >= 0 && item < 8) InterlockedExchange(&g_cmd.itemReq, item + 1); }
// 1.1: the wheel's retry steps ask for help from the game thread: finish a stuck switch, queue the item the way the Y button does
void fight_switch_help(int want) { if (want >= 1 && want < 8) InterlockedExchange(&g_sw.helpReq, want); }
void fight_switch_note(int reason, int tries) { InterlockedExchange(&g_sw.noteReq, reason * 100 + (tries > 99 ? 99 : tries)); }
// the inventory as the game holds it (state per item 0..7, the item in hand or -1); 1 = fresh (under half a second old)
int fight_items(int* st8, int* current) {
  for (int i = 0; i < 8; ++i) st8[i] = g_inv.st[i];
  *current = g_inv.cur;
  return g_inv.player && g_inv.qpc && qpc_now() - g_inv.qpc < qpc_freq() / 2 && !stereo_in_flat_mode();
}
// Published by the existing shared actor scan; no extra world walk.
int fight_staypuft(uintptr_t player, uintptr_t* boss, uintptr_t* world) {
  *boss = 0; *world = 0;
  // 1.7.57: the actor scan can clear the Stay Puft pointer as soon as he falls,
  // while the rooftop/fall dialogue camera is still active. Preserve the last
  // verified world/player identity even when the boss pointer is gone so the
  // scene-view latch can finish the scripted transition instead of snapping
  // the normal game view-model back into the headset.
  if (!player || player != g_puft.player || !g_puft.qpc) return 0;
  *boss = g_puft.boss; *world = g_puft.world;
  if (qpc_now() - g_puft.qpc > qpc_freq() / 2) return -1;
  return g_puft.boss ? 1 : 0;
}
int fight_staypuft_focus(uintptr_t player, float* mouth, int* stage) {
  if (player != g_puft.player || !g_puft.boss || !g_puft.focusValid || !g_puft.focusQ ||
      qpc_now() - g_puft.focusQ > qpc_freq() / 2) return 0;
  for (int i = 0; i < 3; ++i) mouth[i] = g_puft.mouth[i];
  *stage = g_puft.stage;
  return 1;
}
// a trap was thrown by the player's hand: log where it goes for the next 4 seconds
// 0.83: the same 4-second log after a plain X press (nothing taken from the hip): does the game itself deploy the trap from a normal press?
int fight_trap_state(uintptr_t player) {   // 1.7.174: 1 idle, 3 deploying / out; -1 unknown
  if (!player || !memcache::readable((const void*)(player + kOffTrapState), 4, 0, 1)) return -1;
  return *(const int*)(player + kOffTrapState);
}
void fight_trap_watch() { g_trapT.trackUntilQ = qpc_now() + 4 * qpc_freq(); g_trapT.lastLogQ = 0; }
void fight_trap_thrown() { g_trapT.trackUntilQ = qpc_now() + 4 * qpc_freq(); g_trapT.lastLogQ = 0; ++g_trapT.throws; }


// 0.79: the game's own ghost trap (the actor at the player's side, [player+0x24D88]) goes into the left hand while the trap button is held, instead of a model of the probe.
// Called on the game thread right after the camera step, before the frame is drawn. lpos = the left controller in game world feet (null when not tracked).
static struct { int carrying; float lastWrote[3]; long frames, reverted, noObj, started, logged, rotWrites, rotBad; float e0[9]; double b0[9]; int upAxis; double upSign, hang; double hangG, sf, N[3]; int haveN; long holdLogs, gravFrames; } g_carry;   // 1.7.182: hangG, sf, N, haveN: the gravity hold
// 1.7.103: the trap in the hand. The game's trap object is moved to the left hand (as before). New (trap_hold): its rotation is the rotation it had when you took it, turned by every turn of your wrist since
// (it feels held, not glued with a fixed tilt), and its origin hangs below the hand so the hand is at the TOP of the trap, where a handle is, not in the middle of the box. The game's own trap is held
// by the bone R_Trap of the right hand (item 4 in the exe's item-to-bone table); which end the handle is on is not read from the model yet, so the top is assumed (TRAPSHAPE logs the numbers).
static void basis_from(const float* fwd, const float* up, double* B) {   // columns: forward, up, side
  double f[3] = {fwd[0], fwd[1], fwd[2]}, u[3] = {up[0], up[1], up[2]};
  double fl = vm::dsqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2]); if (!(fl > 1e-6)) fl = 1.0;
  for (int i = 0; i < 3; ++i) f[i] /= fl;
  const double d = f[0] * u[0] + f[1] * u[1] + f[2] * u[2];
  for (int i = 0; i < 3; ++i) u[i] -= d * f[i];
  double ul = vm::dsqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]); if (!(ul > 1e-6)) { u[0] = 0; u[1] = 1; u[2] = 0; ul = 1.0; }
  for (int i = 0; i < 3; ++i) u[i] /= ul;
  const double sd[3] = {f[1] * u[2] - f[2] * u[1], f[2] * u[0] - f[0] * u[2], f[0] * u[1] - f[1] * u[0]};
  for (int i = 0; i < 3; ++i) { B[i * 3 + 0] = f[i]; B[i * 3 + 1] = u[i]; B[i * 3 + 2] = sd[i]; }
}
void fight_trap_carry(uintptr_t player, int held, const float* lpos, const float* lfwd, const float* lup) {
  if (!player || !memcache::readable((const void*)(player + kOffTrapObj), 8, 0, 1)) { if (held) ++g_carry.noObj; return; }
  const uintptr_t obj = *(const uintptr_t*)(player + kOffTrapObj);
  if (!obj || !memcache::readable((const void*)(obj + layout::kActorPos), 12, 0, 1)) { if (held) ++g_carry.noObj; g_carry.carrying = 0; return; }
  float* p = (float*)(obj + layout::kActorPos);
  float* rot = (float*)(obj + layout::kOffEntityRot);
  const int canRot = g_ctl.trapHold && lfwd && lup && safe_float3(lfwd) && safe_float3(lup) && memcache::readable((const void*)rot, 36, 0, 1);
  if (held && lpos && safe_float3(lpos)) {
    double B[9];
    if (canRot) basis_from(lfwd, lup, B);
    if (!g_carry.carrying) {
      g_carry.carrying = 1; ++g_carry.started;
      if (canRot) {
        for (int i = 0; i < 9; ++i) { g_carry.e0[i] = rot[i]; g_carry.b0[i] = B[i]; }
        // which of the model's three axes points most nearly up in the world (y), and which way: that end is the top
        int best = 0; double bv = 0.0;
        for (int j = 0; j < 3; ++j) { const double v = (double)rot[3 * 1 + j]; if (vm::dabs(v) > vm::dabs(bv)) { bv = v; best = j; } }
        g_carry.upAxis = best; g_carry.upSign = bv >= 0.0 ? 1.0 : -1.0;
        float rad = memcache::readable((const void*)(obj + kOffRadius), 4, 0, 1) ? *(const float*)(obj + kOffRadius) : 0.0f;
        // 1.7.176: the video of 1.7.175 showed the trap floating a whole trap-height beyond the fist (0.55 x radius from the controller point); the photo of the right hold has the fist
        // ON the trap's grip end, the trap overlapping the hand. The centre now sits only 0.18 x radius from the controller point.
        double hh = (rad > 0.05f && rad < 20.0f) ? 0.18 * (double)rad : 0.12;
        if (hh < 0.06) hh = 0.06;
        if (hh > 0.25) hh = 0.25;
        g_carry.hang = hh;
        g_carry.hangG = 0.30 * (double)g_ctl.trapHangPct * 0.01 * (double)((rad > 0.05f && rad < 20.0f) ? rad : 0.7f);   // 1.7.198: -30 % (the centre 2 cm ABOVE the fist; 1.7.197: +40 %, 1.7.193: +100 %) ("move the trap up more, still not on the handle")
           // 1.7.182: the grip end at the fist, the body hanging below: the centre is about 0.62 x radius under the hand
        if (g_carry.hangG < -0.30) g_carry.hangG = -0.30;   // 1.7.198: negative = the trap's centre is ABOVE the fist (the handle is below the trap's top end)
        if (g_carry.hangG > 0.30) g_carry.hangG = 0.30;
        g_carry.haveN = 0; g_carry.sf = 1.0;
        if (lfwd && lup) {   // 1.7.193: the flat face turns with the controller's pointing (fully rotatable); which way it looked at the grab decides its sign
          const double dl[3] = {-(double)lup[0], -(double)lup[1], -(double)lup[2]};
          double fv[3] = {(double)lfwd[0], (double)lfwd[1], (double)lfwd[2]};
          const double dd = fv[0] * dl[0] + fv[1] * dl[1] + fv[2] * dl[2];
          for (int i = 0; i < 3; ++i) fv[i] -= dd * dl[i];
          const double fl = vm::dsqrt(fv[0] * fv[0] + fv[1] * fv[1] + fv[2] * fv[2]);
          if (fl > 0.2) {
            g_carry.N[0] = fv[0] / fl; g_carry.N[1] = fv[1] / fl; g_carry.N[2] = fv[2] / fl; g_carry.haveN = 1;
            const int fa0 = (best + 2) % 3;
            const double d0 = g_carry.N[0] * (double)rot[fa0] + g_carry.N[1] * (double)rot[3 + fa0] + g_carry.N[2] * (double)rot[6 + fa0];
            g_carry.sf = d0 >= 0.0 ? 1.0 : -1.0;
          }
        }
        if (g_carry.logged < 30) { ++g_carry.logged; log_line("TRAPSHAPE the trap object: bounds radius %.2f ft, model axes (columns) x %.2f,%.2f,%.2f  y %.2f,%.2f,%.2f  z %.2f,%.2f,%.2f, the axis nearest up is #%d (%s), hangs %.2f ft below the hand; your left hand points %.2f,%.2f,%.2f, up %.2f,%.2f,%.2f",
                 (double)rad, (double)rot[0], (double)rot[3], (double)rot[6], (double)rot[1], (double)rot[4], (double)rot[7], (double)rot[2], (double)rot[5], (double)rot[8], best, g_carry.upSign > 0 ? "plus" : "minus", hh, (double)lfwd[0], (double)lfwd[1], (double)lfwd[2], (double)lup[0], (double)lup[1], (double)lup[2]); }
      }
      if (g_carry.logged < 30) { ++g_carry.logged; log_line("TRAPCARRY start: the game's trap object %p moves into your left hand (it was at %.1f,%.1f,%.1f, the hand is at %.1f,%.1f,%.1f ft)", (void*)obj, (double)p[0], (double)p[1], (double)p[2], (double)lpos[0], (double)lpos[1], (double)lpos[2]); }
    } else {   // did the game put it back where it wants it since our last write?
      const float dx = p[0] - g_carry.lastWrote[0], dy = p[1] - g_carry.lastWrote[1], dz = p[2] - g_carry.lastWrote[2];
      if (dx * dx + dy * dy + dz * dz > 0.01f) ++g_carry.reverted;
    }
    float np[3] = {lpos[0], lpos[1], lpos[2]};
    if (canRot && g_carry.carrying) {
      // turn = B(now) * B0^T ; new model axes = turn * (the model axes at the grab)
      double R[9];
      for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { double v = 0; for (int k = 0; k < 3; ++k) v += B[i * 3 + k] * g_carry.b0[j * 3 + k]; R[i * 3 + j] = v; }
      float E[9]; int ok = 1;
      for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { double v = 0; for (int k = 0; k < 3; ++k) v += R[i * 3 + k] * (double)g_carry.e0[k * 3 + j]; E[i * 3 + j] = (float)v; if (!(v == v) || v > 1.01 || v < -1.01) ok = 0; }
      if (ok && g_ctl.trapGravity && lfwd && lup && g_carry.haveN) {
        // 1.7.182 "rotate the trap, it is still not held right": the trap was turned to the controller's up, so with the hand hanging at the hip it stuck out forward like a sign on a stick, and its
        // turn about that line was whatever the hand happened to be doing when it was taken. Now it is held like a case by its handle: the grip end in the fist, the body hanging straight down,
        // its flat face turned the way the controller faces (the palm side); it follows the wrist's turn about the vertical.
        const int ua = g_carry.upAxis, fa = (ua + 2) % 3, wa = (ua + 1) % 3;
        // 1.7.193 "make it fully rotatable, held by the grip": the trap is rigid with the controller in all three turns. Its handle end is in the fist, its body points the way the controller's
        // underside points (minus the controller's up), its flat face follows the controller's pointing. (Before: only the turn about the vertical was followed, the body always hung straight down.)
        double c[3][3], dv[3];
        traphold::build(lfwd, lup, ua, g_carry.upSign, g_carry.sf, g_carry.N, c, dv);
        for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) rot[i * 3 + j] = (float)c[j][i];
        ++g_carry.rotWrites; ++g_carry.gravFrames;
        np[0] = (float)((double)lpos[0] + dv[0] * g_carry.hangG); np[1] = (float)((double)lpos[1] + dv[1] * g_carry.hangG); np[2] = (float)((double)lpos[2] + dv[2] * g_carry.hangG);   // 1.7.193: along the body direction, not straight down
        if ((g_carry.gravFrames % 120) == 1 && g_carry.holdLogs < 40) {   // data: the trap's axes in the controller's own frame
          ++g_carry.holdLogs;
          const double f[3] = {lfwd[0], lfwd[1], lfwd[2]}, u[3] = {lup[0], lup[1], lup[2]};
          const double sd[3] = {f[1] * u[2] - f[2] * u[1], f[2] * u[0] - f[0] * u[2], f[0] * u[1] - f[1] * u[0]};
          double q[3][3];
          for (int j = 0; j < 3; ++j) { q[j][0] = c[j][0] * f[0] + c[j][1] * f[1] + c[j][2] * f[2]; q[j][1] = c[j][0] * u[0] + c[j][1] * u[1] + c[j][2] * u[2]; q[j][2] = c[j][0] * sd[0] + c[j][1] * sd[1] + c[j][2] * sd[2]; }
          log_line("TRAPHOLD #%ld hanging hold (trap_gravity=1): top end at the fist, body %.2f ft below it, flat face turned %s | controller points %.2f,%.2f,%.2f up %.2f,%.2f,%.2f | the trap's axes in the controller's frame (along its pointing, up, side): top end %.2f,%.2f,%.2f  flat face %.2f,%.2f,%.2f  width %.2f,%.2f,%.2f",
                   (long)g_carry.holdLogs, g_carry.hangG, g_carry.sf > 0 ? "with the palm side" : "against the palm side", (double)lfwd[0], (double)lfwd[1], (double)lfwd[2], (double)lup[0], (double)lup[1], (double)lup[2],
                   q[ua][0], q[ua][1], q[ua][2], q[fa][0], q[fa][1], q[fa][2], q[wa][0], q[wa][1], q[wa][2]);
        }
      } else if (ok && g_ctl.trapHang && lup) {
        // 1.7.166 "the trap is held wrong": the turn above keeps whatever angle the trap had to the hand when it was taken from the hip, so with the hand
        // raised the trap stood out in front of the fist like a sign on a stick (the video). Now it is held the way a hand holds a case by its handle: its
        // top turned to the controller's up (the back of the fist) and it hangs below the fist along that line; only its turn about that line follows the grab.
        const int ua = g_carry.upAxis;
        double u[3] = {g_carry.upSign * (double)E[0 * 3 + ua], g_carry.upSign * (double)E[1 * 3 + ua], g_carry.upSign * (double)E[2 * 3 + ua]};
        double w[3] = {(double)lup[0], (double)lup[1], (double)lup[2]};
        const double ul = vm::dsqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]), wl = vm::dsqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2]);
        if (ul > 1e-6 && wl > 1e-6) {
          for (int i = 0; i < 3; ++i) { u[i] /= ul; w[i] /= wl; }
          double ax[3] = {u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]};
          const double sn = vm::dsqrt(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]), cs = u[0] * w[0] + u[1] * w[1] + u[2] * w[2];
          double A[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
          if (sn > 1e-6) {   // Rodrigues: the smallest turn taking the trap's top to the controller's up
            for (int i = 0; i < 3; ++i) ax[i] /= sn;
            const double c1 = 1.0 - cs, x = ax[0], y = ax[1], z = ax[2];
            const double R2[9] = {cs + x * x * c1, x * y * c1 - z * sn, x * z * c1 + y * sn,
                                  y * x * c1 + z * sn, cs + y * y * c1, y * z * c1 - x * sn,
                                  z * x * c1 - y * sn, z * y * c1 + x * sn, cs + z * z * c1};
            for (int i = 0; i < 9; ++i) A[i] = R2[i];
          } else if (cs < 0.0) { A[0] = -1; A[4] = 1; A[8] = -1; }   // upside down exactly: half a turn
          float E2[9]; int ok2 = 1;
          for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { double v = 0; for (int k = 0; k < 3; ++k) v += A[i * 3 + k] * (double)E[k * 3 + j]; E2[i * 3 + j] = (float)v; if (!(v == v) || v > 1.01 || v < -1.01) ok2 = 0; }
          if (ok2) for (int i = 0; i < 9; ++i) E[i] = E2[i];
        }
        for (int i = 0; i < 9; ++i) rot[i] = E[i];
        ++g_carry.rotWrites;
        { const double L2 = vm::dsqrt((double)lup[0] * lup[0] + (double)lup[1] * lup[1] + (double)lup[2] * lup[2]); const double k = L2 > 1e-6 ? g_carry.hang / L2 : 0.0;
          for (int i = 0; i < 3; ++i) np[i] = (float)((double)lpos[i] - (double)lup[i] * k); }   // below the fist, along the controller's up
      } else if (ok) {
        for (int i = 0; i < 9; ++i) rot[i] = E[i];
        ++g_carry.rotWrites;
        const int ua = g_carry.upAxis;
        for (int i = 0; i < 3; ++i) np[i] = (float)((double)lpos[i] - g_carry.upSign * (double)E[i * 3 + ua] * g_carry.hang);
      } else ++g_carry.rotBad;
    }
    for (int i = 0; i < 3; ++i) { p[i] = np[i]; g_carry.lastWrote[i] = np[i]; }
    ++g_carry.frames;
  } else if (g_carry.carrying) {
    g_carry.carrying = 0;
    if (g_carry.logged < 30) { ++g_carry.logged; log_line("TRAPCARRY end: let go (the game's trap is at %.1f,%.1f,%.1f ft); frames carried so far %ld, game moved it back %ld times, turned with the wrist %ld times", (double)p[0], (double)p[1], (double)p[2], g_carry.frames, g_carry.reverted, g_carry.rotWrites); }
  }
}
// 1.7.37 the thrown trap starts at the hand. After a hand throw the probe presses the game's trap button and the game spawns the trap at the player's side (TRAPFLIGHT: 0.3 m from the player) and throws it along the aim.
// For its first few frames the actor's position is put at the hand that threw it (handFt = game feet). The game's own throw direction and speed are not touched. handFt = null: nothing pending.
// 1.7.166 "a weird freeze when throwing it, and it re-registers": the 1.7.37 code put the trap at the hand for only 8 writes (about 0.1 s), but the game
// starts its own throw about 0.5 s later. The report: the trap flickered between the hand and the player's side for 8 frames, sat at the player's side
// for 0.4 s, then flew from there. Now it stays at the hand until the game's own throw moves it, and for the first 0.35 s of the flight it is pulled
// from the hand onto the game's path (the pull fades out), so it leaves from your hand. The game's direction and speed are still not touched.
static struct { int writes, frames; float lastWrote[3]; long launches, reverted, tooFar, noObj, logged, flights, pinned; int active, haveSpawn, flying; int64_t q0, flyQ; float spawn[3], off[3]; } g_launch;
void fight_trap_launch(uintptr_t player, const float* handFt, const float* aimDir) {
  if (!handFt) { if (g_launch.active) { g_launch.active = 0; } return; }
  const int64_t now = qpc_now();
  if (!g_launch.active) { g_launch.active = 1; g_launch.writes = 0; g_launch.frames = 0; g_launch.q0 = now; g_launch.haveSpawn = 0; g_launch.flying = 0; ++g_launch.launches; }
  if (!player || !memcache::readable((const void*)(player + kOffTrapObj), 8, 0, 1)) { ++g_launch.noObj; return; }
  const uintptr_t obj = *(const uintptr_t*)(player + kOffTrapObj);
  if (!obj || !memcache::readable((const void*)(obj + layout::kActorPos), 12, 0, 1) || !memcache::readable((const void*)(player + layout::kActorPos), 12, 0, 1)) { ++g_launch.noObj; return; }
  float* p = (float*)(obj + layout::kActorPos);
  const float* pp = (const float*)(player + layout::kActorPos);
  if (!safe_float3(p) || !safe_float3(handFt)) return;
  ++g_launch.frames;
  const double since = (double)(now - g_launch.q0) / (double)qpc_freq();
  if (!g_launch.haveSpawn) {
    const float dx = p[0] - pp[0], dy = p[1] - pp[1], dz = p[2] - pp[2];
    if (dx * dx + dy * dy + dz * dz > 30.0f) { ++g_launch.tooFar; return; }   // not spawned at the player's side (about 5 ft): leave it alone
    for (int i = 0; i < 3; ++i) g_launch.spawn[i] = p[i];
    g_launch.haveSpawn = 1;
  }
  const float sx = p[0] - g_launch.spawn[0], sy = p[1] - g_launch.spawn[1], sz = p[2] - g_launch.spawn[2];
  const float wx = p[0] - g_launch.lastWrote[0], wy = p[1] - g_launch.lastWrote[1], wz = p[2] - g_launch.lastWrote[2];
  const int ours = g_launch.writes > 0 && wx * wx + wy * wy + wz * wz < 1e-6f;   // still exactly where we put it (the game has not moved it since)
  // until the game throws: the trap flies on from the hand by itself (along where you aim, a gentle arc), so it never hangs still in the air
  float sim[3];
  { double d[3] = {0.0, 0.0, 1.0}; if (aimDir && safe_float3(aimDir)) { const double l = vm::dsqrt((double)aimDir[0] * aimDir[0] + (double)aimDir[1] * aimDir[1] + (double)aimDir[2] * aimDir[2]); if (l > 1e-6) for (int i = 0; i < 3; ++i) d[i] = (double)aimDir[i] / l; }
    const double t = since < 0.9 ? since : 0.9;
    for (int i = 0; i < 3; ++i) sim[i] = (float)((double)handFt[i] + d[i] * 11.0 * t);
    sim[1] = (float)((double)sim[1] + 5.0 * t - 16.0 * t * t);
    if (sim[1] < g_launch.spawn[1]) sim[1] = g_launch.spawn[1]; }
  if (!g_launch.flying && !ours && sx * sx + sy * sy + sz * sz > 1.0f) {   // the game's throw has begun: away from its spawn spot by itself
    g_launch.flying = 1; g_launch.flyQ = now; ++g_launch.flights;
    for (int i = 0; i < 3; ++i) g_launch.off[i] = sim[i] - p[i];
    if (g_launch.logged < 12) { ++g_launch.logged; log_line("TRAPLAUNCH #%ld the game's throw began %.2f s after the throw (it flew on from the hand meanwhile, %ld writes): the game's flight is pulled onto that path for 0.35 s (offset %.1f,%.1f,%.1f ft, fading)", g_launch.launches, since, (long)g_launch.writes, (double)g_launch.off[0], (double)g_launch.off[1], (double)g_launch.off[2]); }
  }
  if (!g_launch.flying) {
    if (since > 0.9) return;   // the game never threw it: leave it to the game
    if (g_launch.logged < 12 && g_launch.writes == 0) { ++g_launch.logged; log_line("TRAPLAUNCH #%ld the game's trap %p spawned at its spot %.1f ft from the player: flies on from the hand %.1f,%.1f,%.1f ft by itself until the game's throw begins", g_launch.launches, (void*)obj, (double)vm::dsqrt((double)(p[0] - pp[0]) * (p[0] - pp[0]) + (double)(p[1] - pp[1]) * (p[1] - pp[1]) + (double)(p[2] - pp[2]) * (p[2] - pp[2])), (double)handFt[0], (double)handFt[1], (double)handFt[2]); }
    for (int i = 0; i < 3; ++i) { p[i] = sim[i]; g_launch.lastWrote[i] = sim[i]; }
    ++g_launch.writes; ++g_launch.pinned;
    return;
  }
  const double tf = (double)(now - g_launch.flyQ) / (double)qpc_freq() / 0.35;
  if (tf >= 1.0 || ours) return;   // the pull is over, or this frame's game position already has it
  const double k = 1.0 - tf * tf * (3.0 - 2.0 * tf);
  for (int i = 0; i < 3; ++i) { p[i] = (float)((double)p[i] + (double)g_launch.off[i] * k); g_launch.lastWrote[i] = p[i]; }
  ++g_launch.writes;
}
// 1.7.175 NO TRAP THROW ANIMATION / NO SOFT LOCK. The game's trap button, with a gun in hand, plays a throw animation and only releases the trap 0.2-0.5 s later (that wait is the
// "soft lock"). With no gun in hand the same button calls deployTrap(player, 1) at once. This calls that function ourselves, on the game thread, with the trap's position first put at
// the off hand: the trap leaves the hand in the same frame, with the game's own physics, and no animation or busy state. If the game refuses 3 times, or the function's bytes are not
// the expected ones, it turns itself off for the session and the old path (the game's own button) is used.
static struct { volatile LONG req; float pos[3]; int havePos, broken, sigChecked; long queued, okRet, failRet, logged, whyLogged; } g_dep;
int fight_trap_deploy_request(uintptr_t player, const float* handFt) {
  // 1.7.176: handFt may be null (the hand position is not fresh): the trap is then thrown from wherever the game has it, still with no animation
  const char* why = nullptr; int st = -9;
  if (g_dep.broken) why = "switched off after the game refused it";
  else if (!player) why = "no player";
  else { st = fight_trap_state(player); if (st != 1) why = "trap state is not 1 (idle)"; else if (!memcache::readable((const void*)(player + kOffTrapObj), 8, 0, 1) || !*(const uintptr_t*)(player + kOffTrapObj)) why = "no trap object"; }
  if (why) { if (++g_dep.whyLogged <= 12) log_line("TRAPDEPLOY not used: %s (state %d): the game's own trap button is used", why, st); return 0; }
  g_dep.havePos = handFt && safe_float3(handFt);
  if (g_dep.havePos) for (int i = 0; i < 3; ++i) g_dep.pos[i] = handFt[i];
  InterlockedExchange(&g_dep.req, 1); ++g_dep.queued;
  return 1;
}
// 1.7.188 THE CRASH of the 22:45 report: the throw was called from the camera-prepare hook (fight_publish), in the middle of the game's drawing: the trap is a new thing in the game's draw lists, which the
// render thread / the draw list builder was reading (crash at ghost+0x385b78, a draw-list table with a garbage pointer, 0.2 s after the 4th throw). It is now called at the start of the game's own simulation
// (hk_app_simulate_impl), after the render queue is empty - where the game's own button deploys the trap too.
int fight_trap_deploy_pending() { return g_dep.req != 0; }
void fight_trap_deploy_drop() { InterlockedExchange(&g_dep.req, 0); }
static void trap_deploy_run(uintptr_t player, int menuOpen);
void fight_trap_deploy_run(uintptr_t player) { trap_deploy_run(player, vrmenu_is_open()); }
static void trap_deploy_run(uintptr_t player, int menuOpen) {
  if (!InterlockedExchange(&g_dep.req, 0)) return;
  if (menuOpen || g_dep.broken) return;
  if (!g_dep.sigChecked) {
    static const unsigned char sig[16] = {0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x7c,0x24,0x10,0x55,0x48,0x8b,0xec,0x48,0x83};
    const unsigned char* f = (const unsigned char*)rva(kRvaDeployTrap);
    g_dep.sigChecked = 1;
    if (!memcache::readable(f, 16, 0, 1) || memcmp(f, sig, 16) != 0) { g_dep.broken = 1; log_line("TRAPDEPLOY the game's deploy function is not where expected (other game version?): off, the game's own trap button is used"); return; }
  }
  const int st = fight_trap_state(player);
  const uintptr_t obj = memcache::readable((const void*)(player + kOffTrapObj), 8, 0, 1) ? *(const uintptr_t*)(player + kOffTrapObj) : 0;
  if (st != 1 || !obj || !memcache::readable((const void*)(obj + layout::kActorPos), 12, 0, 1)) { if (g_dep.logged < 20) { ++g_dep.logged; log_line("TRAPDEPLOY skipped: trap state %d, trap object %p", st, (void*)obj); } return; }
  float* p = (float*)(obj + layout::kActorPos);
  const float before[3] = {p[0], p[1], p[2]};
  if (g_dep.havePos) for (int i = 0; i < 3; ++i) p[i] = g_dep.pos[i];
  const unsigned char ret = ((DeployFn)rva(kRvaDeployTrap))((void*)player, 1);
  if (ret) ++g_dep.okRet; else { ++g_dep.failRet; if (g_dep.failRet >= 3 && !g_dep.okRet) g_dep.broken = 1; for (int i = 0; i < 3; ++i) p[i] = before[i]; }
  if (g_dep.logged < 40) { ++g_dep.logged; log_line("TRAPDEPLOY #%ld the game's own throw function returned %d with the trap put at %s (%.1f,%.1f,%.1f ft); trap state now %d (3 = thrown); ok %ld refused %ld%s", g_dep.queued, (int)ret, g_dep.havePos ? "your hand" : "the game's own spot (hand position not fresh)", (double)g_dep.pos[0], (double)g_dep.pos[1], (double)g_dep.pos[2], fight_trap_state(player), g_dep.okRet, g_dep.failRet, g_dep.broken ? " - OFF for this session, the game's own button is used" : ""); }
}
void fight_trap_carry_report() {
  log_line("TRAPLAUNCH launches=%ld writes(now)=%d frames=%d movedOnByTheGame=%ld notAtPlayersSide=%ld noObject=%ld (setting trap_from_hand=%d, trap_free=%d)", g_launch.launches, g_launch.writes, g_launch.frames, g_launch.reverted, g_launch.tooFar, g_launch.noObj, (int)g_ctl.trapFromHand, (int)g_ctl.trapFree);
  log_line("TRAPCARRY carries=%ld framesInHand=%ld gameMovedItBack=%ld noTrapObject=%ld (the game's own trap model in the left hand; own model drawn: %d)", g_carry.started, g_carry.frames, g_carry.reverted, g_carry.noObj, (int)g_ctl.trapOwnModel);
}
// 0.94 PKE SOURCES. The scannable "PKE Source" actors (CPKESource, vtable layout::kRvaPkeSourceVtable) sit in the same world actor list as the enemies. While the PKE is the item in
// hand their positions (game feet, entity position at +0x54) are published; the aim code pulls the PKE's scan ray toward one that is nearly in line (things on the floor, in odd places).
struct PkeSrcSnap { volatile LONG seq; int n; float p[16][3]; int64_t qpc; };
static PkeSrcSnap g_psrc;
static struct { LONG scans, found, maxFound, logged, noWorld; uintptr_t seen[24]; int nSeen; LONG skipDormant, skipScanned, trinketsUsed, sourcesUsed; double lastNearUsedFt; } g_psrcSt;   // 1.7.29: the skip counters
static double g_pkeNearFt = 1.0e9; static int64_t g_pkeNearQ;   // 1.7.13: the nearest scannable source that is NOT scanned yet (distance in feet, when measured)
static void pke_sources_scan(uintptr_t player, int64_t now) {
  static int64_t s_lastQ;
  if (s_lastQ && now - s_lastQ < qpc_freq() / 10) return;   // ten times a second is plenty
  s_lastQ = now;
  // 1.7.31: the game's own line-of-sight test (the one the wall rule uses), for the "gone" rule: 1 = a clear line from the player to the ghost's centre, or to its upper body / near side (any clear line is enough)
  auto los_probe = [&](const float* w, double radFt) -> int {
    if (!player || !memcache::readable((const void*)player, 0x60, 0, 1)) return 1;
    const LosFn fn = (LosFn)rva(kRvaLosTest);
    float t[3] = {w[0], w[1], w[2]};
    ++g_smart.vlosCalls;
    int los = fn((void*)player, t) != 0;
    if (!los) {
      const float* pp = (const float*)(player + layout::kActorPos);
      double dx = (double)pp[0] - w[0], dy = ((double)pp[1] + 4.5) - w[1], dz = (double)pp[2] - w[2];
      const double len = vm::dsqrt(dx * dx + dy * dy + dz * dz);
      if (len > 1.0) {
        double step = radFt * 0.8; if (step > len * 0.5) step = len * 0.5; if (step > 5.0) step = 5.0;
        t[0] = (float)(w[0] + dx / len * step); t[1] = (float)(w[1] + dy / len * step); t[2] = (float)(w[2] + dz / len * step);
        ++g_smart.vlosCalls;
        los = fn((void*)player, t) != 0;
        if (!los) {
          t[0] = w[0]; t[1] = (float)(w[1] + radFt * 0.6); t[2] = w[2];
          ++g_smart.vlosCalls;
          los = fn((void*)player, t) != 0;
        }
      }
    }
    if (los) ++g_smart.vlosClear; else ++g_smart.vlosBlocked;
    return los;
  };
  const uintptr_t* wp = (const uintptr_t*)rva(kRvaWorldPtr);
  if (!memcache::readable(wp, 8, 0, 1) || !*wp || !memcache::readable((const void*)(*wp + kOffActorList), 8, 0, 1)) { ++g_psrcSt.noWorld; return; }
  float pp[3] = {0, 0, 0};
  if (player && memcache::readable((const void*)(player + layout::kActorPos), 12, 0, 1)) for (int i = 0; i < 3; ++i) pp[i] = *(const float*)(player + layout::kActorPos + 4 * i);
  float tmp[16][3]; double tmpD[16]; int nt = 0; double nearUn = 1.0e9;
  uintptr_t actor = *(const uintptr_t*)(*wp + kOffActorList);
  for (int guard = 0; actor && guard < kMaxActors; ++guard) {   // 1.7.2: was 900 (the list is longer than that)
    if (!memcache::readable((const void*)actor, 0x2A0, 0, 1)) break;
    const uintptr_t vt0 = *(const uintptr_t*)actor;
    const int isSource = vt0 == rva(layout::kRvaPkeSourceVtable);
    const int isTrinket = vt0 == rva(layout::kRvaTrinketVtable);   // 1.7.29: collectibles are scanned with the PKE too (the 1.7.28 run: the aim help ignored them)
    if (isSource || isTrinket) {
      const float* pos = (const float*)(actor + layout::kActorPos);
      float c[3] = {pos[0], pos[1], pos[2]};
      if (isTrinket) c[1] += 0.3f;   // the thing lies on the floor: aim at its middle, not at the floor under it
      if (safe_float3(c)) {
        const double dx = (double)c[0] - pp[0], dy = (double)c[1] - pp[1], dz = (double)c[2] - pp[2];
        const double dist = vm::dsqrt(dx * dx + dy * dy + dz * dz);
        int known = 0;
        for (int k = 0; k < g_psrcSt.nSeen; ++k) if (g_psrcSt.seen[k] == actor) known = 1;
        if (!known && g_psrcSt.nSeen < 24) {
          g_psrcSt.seen[g_psrcSt.nSeen++] = actor;
          log_line("PKESRC new scannable source %p at %.1f,%.1f,%.1f ft, %.1f ft from you (%.1f ft above your feet) [state dwords +0x470..: %08x %08x]", (void*)actor, (double)c[0], (double)c[1], (double)c[2], dist, dy,
                   memcache::readable((const void*)(actor + 0x468), 8, 0, 1) ? *(const unsigned*)(actor + 0x468) : 0u, memcache::readable((const void*)(actor + 0x46C), 8, 0, 1) ? *(const unsigned*)(actor + 0x46C) : 0u);
        }
        if (dist < 120.0 && dist < nearUn) { const int sc = engine_pke_source_scanned(actor); if (sc != 1) nearUn = dist; }   // 1.7.13
        // 1.7.29: the aim help pulled the PKE toward sources the game would not scan (not active yet, or already scanned): the 1.7.28 log had one such source "0.0 deg off the line" for
        // 650+ updates while the thing the player wanted was 55 deg away. Only what can be scanned right now is a target.
        int usable = 1;
        if (dist < 60.0) {
          int sa = 1, sd = 0;
          if (engine_pke_target_state(actor, &sa, &sd)) {
            if (!sa) { usable = 0; ++g_psrcSt.skipDormant; }
            else if (sd) { usable = 0; ++g_psrcSt.skipScanned; }
          }
        }
        if (dist < 120.0 && usable) {
          if (isTrinket) ++g_psrcSt.trinketsUsed; else ++g_psrcSt.sourcesUsed;
          if (nt < 16) { for (int i = 0; i < 3; ++i) tmp[nt][i] = c[i]; tmpD[nt] = dist; ++nt; }
          else { int farI = 0; for (int q = 1; q < nt; ++q) if (tmpD[q] > tmpD[farI]) farI = q; if (dist < tmpD[farI]) { for (int i = 0; i < 3; ++i) tmp[farI][i] = c[i]; tmpD[farI] = dist; } }
        }
      }
    }
    actor = *(const uintptr_t*)(actor + kOffNext);
  }
  g_pkeNearFt = nearUn; g_pkeNearQ = now;
  ++g_psrcSt.scans; g_psrcSt.found += nt; if (nt > g_psrcSt.maxFound) g_psrcSt.maxFound = nt;
  g_psrc.seq += 1;
  g_psrc.n = nt;
  for (int i = 0; i < nt; ++i) for (int k = 0; k < 3; ++k) g_psrc.p[i][k] = tmp[i][k];
  g_psrc.qpc = now;
  g_psrc.seq += 1;
}
int fight_pke_sources(float (*out)[3], int cap, int64_t* qpc) {
  for (int tries = 0; tries < 3; ++tries) {
    const LONG s0 = g_psrc.seq;
    if (s0 & 1) continue;
    int n = g_psrc.n; if (n > cap) n = cap; if (n > 16) n = 16;
    for (int i = 0; i < n; ++i) for (int k = 0; k < 3; ++k) out[i][k] = g_psrc.p[i][k];
    const int64_t q = g_psrc.qpc;
    if (g_psrc.seq != s0) continue;
    if (qpc) *qpc = q;
    if (!q || qpc_now() - q > qpc_freq() / 3) return 0;   // older than a third of a second: not used
    return n;
  }
  return 0;
}

void fight_publish(const float* view9, const float* hc, double fpm, uintptr_t player, int scanActors) {
  if (!view9 || !hc || !(fpm > 0.1 && fpm < 100.0)) return;
  ++g_barFrame.seq;
  for (int i = 0; i < 9; ++i) g_barFrame.frame.view[i] = view9[i];
  for (int i = 0; i < 3; ++i) g_barFrame.frame.head[i] = hc[i];
  g_barFrame.frame.fpm = fpm; ++g_barFrame.seq;
  const double inv = 1.0 / fpm;
  const int64_t now = qpc_now();
  auto to_head = [&](const float* w, float* o) {
    const double dx = (double)w[0] - hc[0], dy = (double)w[1] - hc[1], dz = (double)w[2] - hc[2];
    for (int c = 0; c < 3; ++c) o[c] = (float)(((double)view9[0 * 3 + c] * dx + (double)view9[1 * 3 + c] * dy + (double)view9[2 * 3 + c] * dz) * inv);
  };
  auto from_head = [&](const double* h, float* w) { bossring::head_to_world(view9, hc, inv, h, w); };   // 1.7.106
  // the gun's hose end
  if (g_hs.posedQ && now - g_hs.posedQ < qpc_freq() / 5) { to_head(g_hs.posed, g_hs.head); if (safe_float3(g_hs.head)) g_hs.headQ = now; }
  {   // 1.7.223 DARTTRACE: what the game does while the left trigger (Boson Dart) is pulled. One line per pull (first 14): every ~15 ms the time since the pull, right trigger held, the game's action
      // bits (player+0xC7A8: 0x40 primary, 0x80/0x100/0x200000 secondary), its secondary-press state (+0x24860), the 0.25 s timer (+0x24864), the primary timer (+0x24834) and the byte at +0x2485a, then how
      // often the game asked "held / released / just pressed" about the secondary during the pull and how often it was told yes.
    static char buf[1100]; static int n, active, pulls; static unsigned lastAge; static long ask0[3], yes0[3];
    unsigned age = 0; int rt = 0;
    const int down = engine_secondary_press(&age, &rt);
    if (down && !active) { active = 1; n = 0; lastAge = 0; buf[0] = 0; for (int k = 0; k < 3; ++k) ask0[k] = engine_secondary_asks(k, &yes0[k]); }
    if (active && down && player && n < 1000 && age >= lastAge + 15 && age < 800 &&
        memcache::readable((const void*)(player + 0x24830), 0x40, 0, 1) && memcache::readable((const void*)(player + 0xC7A8), 4, 0, 1)) {
      lastAge = age;
      n += wsprintfA(buf + n, " %u:%d:%x:%d:%d:%d:%d", age, rt, *(const unsigned*)(player + 0xC7A8), *(const int*)(player + 0x24860), (int)(*(const float*)(player + 0x24864) * 1000.0f),
                     (int)(*(const float*)(player + 0x24834) * 1000.0f), (int)*(const unsigned char*)(player + 0x2485a));
    }
    if (active && !down) {
      active = 0;
      if (++pulls <= 14) {
        long y[3], a[3]; for (int k = 0; k < 3; ++k) { a[k] = engine_secondary_asks(k, &y[k]) - ask0[k]; y[k] -= yes0[k]; }
        log_line("DARTTRACE pull #%d (age:rtHeld:actionBits:pressState:timerMs:primaryTimerMs:flag) %s | the game asked held %ld (yes %ld), released %ld (yes %ld), just-pressed %ld (yes %ld) | just-pressed told late (after 50 ms) in %ld pulls so far",
                 pulls, buf, a[0], y[0], a[1], y[1], a[2], y[2], engine_secondary_late());
      }
    }
  }
  // the player's slam meter
  if (player && memcache::readable((const void*)(player + kOffSlamGauge), 16, 0, 1) && memcache::readable((const void*)(player + kOffActionMask), 4, 0, 1)) {
    const float gauge = *(const float*)(player + kOffSlamGauge);
    const int active = *(const unsigned char*)(player + kOffSlamActive) != 0;
    const unsigned mask = *(const unsigned*)(player + kOffActionMask);
    const float* thrp = (const float*)rva(kRvaSlamThreshold);
    const float thr = memcache::readable(thrp, 4, 0, 1) ? *thrp : 0.0f;
    const int ready = gauge == gauge && thr > 0.0f && gauge >= thr;
    ++g_sl.samples;
    if (ready != g_sl.lastReady) { ++g_sl.readyEdges; if (g_sl.logged < 60) { ++g_sl.logged; log_line("SLAM meter %s: gauge %.2f of %.2f (slam active %d)", ready ? "FULL" : "below the threshold", (double)gauge, (double)thr, active); } }
    if (active != g_sl.lastActive) { ++g_sl.activeEdges; if (g_sl.logged < 60) { ++g_sl.logged; log_line("SLAM %s (gauge %.2f of %.2f, fire held %d, capture state bit %d)", active ? "STARTED" : "ended", (double)gauge, (double)thr, (mask & 0x200000) != 0, (mask & 0x40) != 0); } }
    if ((mask & 0x200000) && !(g_sl.lastMask & 0x200000)) { ++g_sl.fireEdges; if (g_sl.logged < 60 && (mask & 0x40)) { ++g_sl.logged; log_line("SLAM fire pressed while the capture state is on: gauge %.2f of %.2f, active %d -> %s", (double)gauge, (double)thr, active, ready ? "a slam should start" : "meter not full: no slam"); } }
    {   // 0.91/0.93: the meter never moved in 34000 samples: while the capture stream is held, log every float (and small whole number) near the gauge that changes (finds the real meter / state if 0x24A40 is the wrong field)
      static float prevF[320]; static unsigned prevU[320]; static int havePrev, shown, shownU;
      if (g_ctl.probeData && (mask & 0x40) && memcache::readable((const void*)(player + 0x24800), 320 * 4, 0, 1)) {
        const float* fl = (const float*)(player + 0x24800);
        const unsigned* ul = (const unsigned*)(player + 0x24800);
        for (int k = 0; k < 320; ++k) {
          if (havePrev && fl[k] == fl[k] && vm::dabs((double)fl[k] - prevF[k]) > 0.02f && vm::dabs((double)fl[k]) < 1e6f && vm::dabs((double)prevF[k]) < 1e6f && shown < 150) { ++shown; log_line("SLAMSCAN capture held: player+0x%X changed %.3f -> %.3f (gauge field 0x24A40 = %.3f)", 0x24800 + k * 4, (double)prevF[k], (double)fl[k], (double)gauge); }
          if (havePrev && ul[k] != prevU[k] && ul[k] < 4096u && prevU[k] < 4096u && shownU < 100) { ++shownU; log_line("SLAMSCAN capture held: player+0x%X whole number %u -> %u", 0x24800 + k * 4, prevU[k], ul[k]); }
          prevF[k] = fl[k]; prevU[k] = ul[k];
        }
        havePrev = 1;
      } else havePrev = 0;
    }
    g_sl.gauge = gauge; g_sl.thr = thr; g_sl.active = active; g_sl.mask = mask; g_sl.lastReady = ready; g_sl.lastActive = active; g_sl.lastMask = mask;
    InterlockedExchange(&g_sl.ready, ready);
    {   // 1.7.2 the target the capture stream holds (player+0x24D80, from the 0.77 notes): a ghost, or nothing
      int wr = 0; uintptr_t wp2 = 0;
      if (memcache::readable((const void*)(player + 0x24D80), 8, 0, 1)) {
        wp2 = *(const uintptr_t*)(player + 0x24D80);
        const uintptr_t lo = rva(0), hi = lo + layout::kExpectedSizeOfImage;
        if (wp2 && memcache::readable((const void*)wp2, 8, 0, 1)) { const uintptr_t vt = *(const uintptr_t*)wp2; wr = (vt >= lo && vt < hi); }
      }
      ++g_sl.wrSamples;
      if (wr) {
        ++g_sl.wrSeen;
        if (wp2 != g_sl.wrPtr) { g_sl.wrPtr = wp2; rtti_name(*(const uintptr_t*)wp2, g_sl.wrName, (int)sizeof(g_sl.wrName)); if (g_sl.wrLogged < 30) { ++g_sl.wrLogged; log_line("WRANGLE the capture stream now holds %s at %p (meter %.2f of %.2f)", g_sl.wrName, (void*)wp2, (double)gauge, (double)thr); } }
      } else if (g_sl.wrPtr) { g_sl.wrPtr = 0; if (g_sl.wrLogged < 30) { ++g_sl.wrLogged; log_line("WRANGLE the capture stream lets go (meter %.2f of %.2f)", (double)gauge, (double)thr); } }
      {   // 1.7.21: player+0x24D80 always holds the beam object (CProtonBeam), so it can never say "a ghost is held" (the 1.7.20 log: "yes" at every press). The game's processWrangling runs only
        // while the lock target (player+0x2E8) is set, so "a ghost is held" = that target is a ghost (an enemy class).
        int lockEnemy = 0; uintptr_t lockedPtr = 0;
        if (memcache::readable((const void*)(player + layout::kOffLockTarget), 8, 0, 1)) {
          const uintptr_t lt = *(const uintptr_t*)(player + layout::kOffLockTarget);
          if (lt && memcache::readable((const void*)lt, 8, 0, 1)) {
            const uintptr_t lvt = *(const uintptr_t*)lt;
            lockEnemy = class_index(lvt) >= 0;
            if (!lockEnemy && golem_part_vt(lvt)) { lockEnemy = 1; ++g_sl.golemHeld; }   // 1.7.39: a boss's part (CGolemPartBase) counts as "something is held": the 1.7.38 log said "the stream holds no ghost: nothing to slam" with the lock on the Kitchen Golem's parts
            if (lockEnemy) lockedPtr = lt;
          }
        }
        g_sl.lockPtr = lockedPtr; if (mask & 0x40) g_sl.capQ = now;   // 1.7.31: which ghost is held (the 1.7.30 test compared with player+0x24D80, which is the beam object, never the ghost)
        ++g_sm.samples; if (lockEnemy) ++g_sm.lockEnemy;
        if (mask & 0x40) { ++g_sm.capture; if (lockEnemy) ++g_sm.captureAndLock; }
        if (gauge > 0.001f) { ++g_sm.gaugeUp; if (lockEnemy) ++g_sm.gaugeUpAndLock; }
        if (g_sq.s.pending && (double)(now - g_sq.s.q) / (double)qpc_freq() < 0.8) {   // the 0.8 s after the probe's slam press: what the game's action mask looked like
          ++g_sm.windowSamples; if (mask & 0x40) ++g_sm.winCapture; if (mask & 0x200000) ++g_sm.winFire; if ((mask & 0x40) && (mask & 0x200000)) ++g_sm.winBoth; if (lockEnemy) ++g_sm.winLock;
          int seen = 0; for (int i = 0; i < g_sm.nMasks; ++i) if (g_sm.masks[i] == mask) seen = 1;
          if (!seen && g_sm.nMasks < 16) { g_sm.masks[g_sm.nMasks++] = mask; log_line("SLAMMASK new action mask %08x in the 0.8 s after a slam press (capture bit 0x40=%d, fire bit 0x200000=%d, locked ghost=%d, gauge %.2f)", mask, (mask & 0x40) != 0, (mask & 0x200000) != 0, lockEnemy, (double)gauge); }
        }
        wr = lockEnemy; g_sm.heldNow = lockEnemy;
      }
      InterlockedExchange(&g_sl.wrangled, wr);
    }
    if (g_sq.s.pending) {   // follow the slam the left trigger started
      SlamSeq& q = g_sq.s;
      const double el = (double)(now - q.q) / (double)qpc_freq();
      while (q.got < 5 && el >= kSeqAt[q.got]) { q.g[q.got] = gauge; ++q.got; }
      if (q.got >= 5) {
        const int hit = g_hitlog.hits[1] > q.hits0;
        // 1.7.24: a slam costs 0.25 of the meter (it is NOT "below the threshold" after a slam from a full meter): the meter DROPPING by about 0.15 or more after the press is what shows a slam started
        float lowest = q.g[0]; for (int gi = 1; gi < 4; ++gi) if (q.g[gi] < lowest) lowest = q.g[gi];
        const int used = lowest < q.gauge0 - 0.15f || q.g[0] < thr || q.g[1] < thr || q.g[2] < thr || q.g[3] < thr;
        const char* verdict = hit ? "the game's slam HIT landed" : used ? "the meter was used up but I saw no slam hit (the hit may have missed everything)" : "NOTHING happened (the meter did not drop)";
        ++g_sq.logged;
        if (hit) ++g_sq.landed; else if (used) ++g_sq.usedNoHit; else ++g_sq.nothing;
        if (g_sq.logged <= 80) log_line("SLAMRESULT #%d: pull (%.2f, %.2f), ghost held at the press: %s, meter %.2f at the press, then %.2f/%.2f/%.2f/%.2f/%.2f after 0.25/0.5/1/2/3.2 s, slam hits %ld -> %s",
          q.n, q.pullX, q.pullY, q.wr0 > 0 ? "yes" : (q.wr0 == 0 ? "NO" : "unknown"), (double)q.gauge0, (double)q.g[0], (double)q.g[1], (double)q.g[2], (double)q.g[3], (double)q.g[4], (long)(g_hitlog.hits[1] - q.hits0),
          verdict);
        q.pending = 0;
      }
    }
  }
  hosetex_game_step(player);   // 0.78: the hose's colour from the game's own texture (throttled inside; walks the player's model parts every few seconds)
  // 0.77: the player's inventory (the weapon wheel shows it) and the commands the wheel / the trap throw send to the game
  if (player && memcache::readable((const void*)player, 8, 0, 1) &&
      *(const uintptr_t*)player == rva(layout::kRvaGhostbusterVtable) &&
      memcache::readable((const void*)(player + kOffItems), kOffItemStride * 8, 0, 1)) {
    int st[8], cur = -1, owned = 0;
    for (int i = 0; i < 8; ++i) { st[i] = *(const int*)(player + kOffItems + kOffItemStride * i); if (st[i] == 2 && cur < 0) cur = i; if (st[i] == 1 || st[i] == 2) ++owned; }
    if (cur < 0 && memcache::readable((const void*)(player + kOffPrevItem), 4, 0, 1)) cur = *(const int*)(player + kOffPrevItem);
    if (cur < -1 || cur > 7) cur = -1;
    int changed = cur != g_inv.lastCur;
    for (int i = 0; i < 8; ++i) if (st[i] != g_inv.lastSt[i]) changed = 1;
    if (changed) {
      ++g_inv.changes;
      if (g_inv.changes <= 60) log_line("ITEMS state of items 0..7 (0 none, 1 owned, 2 in hand, 3 switched off) = %d %d %d %d %d %d %d %d, in hand: item %d (1 proton, 2 meson, 3 boson, 4 trap, 5 PKE, 6 light, 7 slime), requested last: %d",
                                         st[0], st[1], st[2], st[3], st[4], st[5], st[6], st[7], cur,
                                         memcache::readable((const void*)(player + kOffReqItem), 4, 0, 1) ? *(const int*)(player + kOffReqItem) : -9);
      for (int i = 0; i < 8; ++i) g_inv.lastSt[i] = st[i];
      g_inv.lastCur = cur;
    }
    for (int i = 0; i < 8; ++i) g_inv.st[i] = st[i];
    g_inv.cur = cur; g_inv.owned = owned; g_inv.player = player; g_inv.qpc = now;
    {   // ---- 1.1 the gear switch watch ----
      const double freqSw = (double)qpc_freq();
      const LONG noteReq = InterlockedExchange(&g_sw.noteReq, 0);
      if ((noteReq > 0 || !g_sw.qpc || (double)(now - g_sw.qpc) / freqSw >= 0.04) && memcache::readable((const void*)(player + 0x24CD8), 0x10, 0, 1) && memcache::readable((const void*)(player + 0x24D74), 1, 0, 1) &&
          memcache::readable((const void*)(player + 0x24838), 4, 0, 1) && memcache::readable((const void*)(player + 0x88C0), 8, 0, 1) && memcache::readable((const void*)(player + 0xC7F0), 8, 0, 1) &&
          memcache::readable((const void*)(player + 0x24E78), 8, 0, 1) && memcache::readable((const void*)(player + 0xC7A8), 4, 0, 1) && memcache::readable((const void*)(player + 0x2482B), 0x40, 0, 1) &&
          memcache::readable((const void*)(player + 0x2468), 1, 0, 1)) {
        g_sw.qpc = now; ++g_sw.samples;
        g_sw.p8 = *(const int*)(player + 0x24CD8); g_sw.pC = *(const int*)(player + 0x24CDC); g_sw.rq = *(const int*)(player + 0x24CE0); g_sw.ret = *(const int*)(player + 0x24CE4);
        g_sw.can = *(const unsigned char*)(player + 0x24D74); g_sw.b24858 = *(const unsigned char*)(player + 0x24858); g_sw.timer = *(const float*)(player + 0x24838);
        g_sw.b2485b = *(const unsigned char*)(player + 0x2485B); g_sw.b2482b = *(const unsigned char*)(player + 0x2482B); g_sw.b2468 = *(const unsigned char*)(player + 0x2468);
        g_sw.flags = *(const unsigned*)(player + 0xC7A8); g_sw.prev = *(const int*)(player + kOffPrevItem); g_sw.st0 = st[0];
        for (int i = 0; i < 6; ++i) g_sw.pred[i] = g_sw.b2468 ? (((PredFn)rva(sw::kRvaPred[i]))((void*)player) != 0) : 0;
        const int pending = g_sw.p8 != -1 || g_sw.pC != -1;
        unsigned m = 0;
        if (pending) m |= 1u << 0;
        if (!g_sw.can) m |= 1u << 1;
        if (g_sw.b24858) m |= 1u << 2;
        if (g_sw.timer > 0.0f) m |= 1u << 3;
        if (g_sw.b2485b) m |= 1u << 4;
        if (g_sw.b2482b) m |= 1u << 5;
        if (*(const uintptr_t*)(player + 0x88C0)) m |= 1u << 6;
        if (*(const uintptr_t*)(player + 0xC7F0)) m |= 1u << 7;
        if (*(const uintptr_t*)(player + 0x24E78)) m |= 1u << 8;
        if (st[0] == 2) m |= 1u << 9;
        for (int i = 0; i < 6; ++i) if (g_sw.pred[i]) m |= 1u << (10 + i);
        if (g_sw.rq != -1) m |= 1u << 16;
        g_sw.mask = m;
        for (int b = 0; b < sw::kBits; ++b) if ((m >> b) & 1u) ++g_sw.bitFrames[b];
        // how long the same half-done switch has been waiting
        if (!pending) { if (g_sw.pendQ) { const long ms = (long)((double)(now - g_sw.pendQ) * 1000.0 / freqSw); if (ms > g_sw.maxPendMs) g_sw.maxPendMs = ms; } g_sw.pendQ = 0; }
        else if (!g_sw.pendQ || g_sw.p8 != g_sw.pendA || g_sw.pC != g_sw.pendB) {
          if (g_sw.pendQ) { const long ms = (long)((double)(now - g_sw.pendQ) * 1000.0 / freqSw); if (ms > g_sw.maxPendMs) g_sw.maxPendMs = ms; }
          g_sw.pendQ = now; g_sw.pendA = g_sw.p8; g_sw.pendB = g_sw.pC; ++g_sw.pendEpisodes;
        }
        const double pendSec = pending && g_sw.pendQ ? (double)(now - g_sw.pendQ) / freqSw : 0.0;
        auto describe = [&](char* out, int cap) {
          int n = 0;
          for (int b = 0; b < sw::kBits && n < cap - 40; ++b) if ((m >> b) & 1u) n += wsprintfA(out + n, "%s%s", n ? "," : "", sw::kNames[b]);
          if (!n) lstrcpyA(out, "none");
        };
        auto finish_now = [&](const char* why) -> int {
          const int a0 = *(const int*)(player + 0x24CD8), b0 = *(const int*)(player + 0x24CDC);
          ((FinishFn)rva(sw::kRvaFinish))((void*)player);
          ++g_sw.fixes; g_sw.lastFixQ = now;
          if (g_sw.fixes <= 60) log_line("SWITCHFIX %s: the game's own 'finish the switch now' was called (pending before %d/%d after %d/%d, items in hand %d, state of the PKE %d, gun %d)", why, a0, b0,
                                          *(const int*)(player + 0x24CD8), *(const int*)(player + 0x24CDC), cur, *(const int*)(player + kOffItems + kOffItemStride * 5), *(const int*)(player + kOffItems + kOffItemStride * 1));
          return 1;
        };
        // a switch that stays half done for 3 s: finish it (a draw / stow takes about 1 s; a late animation signal after that finds nothing waiting, which is what the game's own cancel does too)
        if (g_ctl.switchHelp && pending && pendSec > 3.0 && (double)(now - g_sw.lastFixQ) / freqSw > 2.0 && !vrmenu_is_open()) { finish_now("pending switch stuck for 3 s"); ++g_sw.autoFixes; }
        // the wheel asks: finish what hangs, then queue the item the way the Y button does
        const LONG helpReq = InterlockedExchange(&g_sw.helpReq, 0);
        if (helpReq > 0 && !vrmenu_is_open()) {
          ++g_sw.helps;
          const int want = (int)helpReq;
          if (g_ctl.switchHelp) {
            if ((*(const int*)(player + 0x24CD8) != -1 || *(const int*)(player + 0x24CDC) != -1) && pendSec > 1.2) finish_now("the wheel asked and a switch hung for over 1.2 s");
            const int stw = *(const int*)(player + kOffItems + kOffItemStride * want);
            if (cur != want && stw == 1) {
              *(int*)(player + 0x24CE0) = want;
              *(unsigned*)(player + 0xC7A8) |= 0x400000u;
              ++g_sw.queued; g_sw.helpQ = now;
              if (g_sw.queued <= 60) log_line("SWITCHFIX queued item %d the way the Y button does (request field 24CE0 = %d, flag 0x400000 set; item in hand %d, its state %d)", want, want, cur, stw);
            } else { ++g_sw.queueSkipped; if (g_sw.queueSkipped <= 20) log_line("SWITCHFIX nothing queued for item %d (in hand %d, its state %d: it has to be 1 = owned and not in hand)", want, cur, stw); }
          }
        }
        // log: a change in the game's own switch checks, or the wheel asks (a press, a failed check, giving up)
        const int changedMask = ((m ^ g_sw.lastLogMask) & sw::kLogMask) != 0;
        if (noteReq > 0 || (changedMask && g_sw.logged < 160 && (double)(now - g_sw.lastLogQ) / freqSw > 0.25)) {
          char names[260]; describe(names, (int)sizeof(names));
          if (noteReq > 0) ++g_sw.noteLogged; else ++g_sw.logged;
          if (noteReq > 0 ? g_sw.noteLogged <= 160 : 1) {
            const char* why = noteReq <= 0 ? "changed" : (noteReq / 100 == 1 ? "wheel pressed Y" : (noteReq / 100 == 2 ? "wheel check failed" : "wheel gave up"));
            char tag[64];
            if (noteReq > 0) wsprintfA(tag, "%s, try %d", why, (int)(noteReq % 100)); else lstrcpyA(tag, why);
            log_line("SWITCHGATE (%s): blockers=[%s] pending=%d/%d request=%d returnTo=%d canSwitch=%d script24858=%d lockTimer=%.2f flags=0x%08X prev=%d item0=%d in hand %d, states PKE %d gun %d | anim checks 5F0/600/604/608/61C/47D4 = %d%d%d%d%d%d",
                     tag, names, g_sw.p8, g_sw.pC, g_sw.rq, g_sw.ret, (int)g_sw.can, (int)g_sw.b24858, (double)g_sw.timer, g_sw.flags, g_sw.prev, g_sw.st0, cur,
                     st[5], st[1], (int)g_sw.pred[0], (int)g_sw.pred[1], (int)g_sw.pred[2], (int)g_sw.pred[3], (int)g_sw.pred[4], (int)g_sw.pred[5]);
          }
          g_sw.lastLogMask = m; g_sw.lastLogQ = now;
        }
      }
    }
    const LONG req = InterlockedExchange(&g_cmd.itemReq, 0);
    if (req > 0) {
      const int item = (int)req - 1;
      if (vrmenu_is_open()) ++g_cmd.skippedMenu;
      else if (item >= 0 && item < 8) {
        const unsigned char ret = ((ReadyFn)rva(kRvaReadyItem))((void*)player, item);
        ++g_cmd.calls; if (ret) ++g_cmd.okReturns; else ++g_cmd.failReturns;
        g_cmd.lastItem = item; g_cmd.lastRet = ret;
        if (g_cmd.logged < 80) {
          ++g_cmd.logged;
          log_line("WHEEL ready item %d: the game's ready-item function returned %d (before: state %d, in hand %d; right after: state %d, the game's 'requested item' field %d)", item, (int)ret, st[item], cur,
                   *(const int*)(player + kOffItems + kOffItemStride * item), *(const int*)(player + kOffReqItem));
        }
      }
    }
    // the trap in flight: where it is and what the throw state of the player does (for 4 s after a throw)
    if (g_trapT.trackUntilQ && now < g_trapT.trackUntilQ && now - g_trapT.lastLogQ >= qpc_freq() / 5 && g_trapT.logged < 150 &&
        memcache::readable((const void*)(player + kOffTrapState), 4, 0, 1) && memcache::readable((const void*)(player + kOffTrapObj), 8, 0, 1)) {
      g_trapT.lastLogQ = now; ++g_trapT.logged;
      const int state = *(const int*)(player + kOffTrapState);
      const uintptr_t obj = *(const uintptr_t*)(player + kOffTrapObj);
      float tp[3] = {0, 0, 0};
      int haveObj = obj && memcache::readable((const void*)(obj + layout::kActorPos), 12, 0, 1);
      if (haveObj) for (int i = 0; i < 3; ++i) tp[i] = *(const float*)(obj + layout::kActorPos + 4 * i);
      const float* pp = (const float*)(player + layout::kActorPos);
      log_line("TRAPFLIGHT t=%.1fs player trap state=%d (1 idle, 3 deploying) trap object=%s at %.1f,%.1f,%.1f ft from the player (%.1f m along the floor), trap in hand: %d, owned items %d, action mask 0x%08X, in hand item %d | item states %d%d%d%d%d%d%d%d (0 none, 1 owned, 2 in hand, 3 off; item 4 = trap)",
               (double)(now - (g_trapT.trackUntilQ - 4 * qpc_freq())) / (double)qpc_freq(), state, haveObj ? "found" : "none",
               haveObj ? (double)(tp[0] - pp[0]) : 0.0, haveObj ? (double)(tp[1] - pp[1]) : 0.0, haveObj ? (double)(tp[2] - pp[2]) : 0.0,
               haveObj ? vm::dsqrt(((double)tp[0] - pp[0]) * ((double)tp[0] - pp[0]) + ((double)tp[2] - pp[2]) * ((double)tp[2] - pp[2])) * 0.3048 : 0.0, st[4] == 2, owned, memcache::readable((const void*)(player + kOffActionMask), 4, 0, 1) ? *(const unsigned*)(player + kOffActionMask) : 0u, cur, st[0], st[1], st[2], st[3], st[4], st[5], st[6], st[7]);
      g_trapT.lastState = state;
    }
  }
  // Second eye shares the first eye's actor/bar census. Player inputs, item
  // requests, health and attachment updates above still run for each eye.
  if (!scanActors) return;
  // 0.94 the scannable PKE sources, while the PKE is the item in hand
  if (g_ctl.pkeAssistDeg > 0 && g_inv.cur == 5) pke_sources_scan(player, now);
  else if (g_psrc.n) { g_psrc.seq += 1; g_psrc.n = 0; g_psrc.qpc = 0; g_psrc.seq += 1; }
  // 1.7.2: a long walk through the actor list (it can hold thousands of objects) is thinned out when it costs too much: the last result is still fresh for a few frames
  if (g_bs.skipLeft > 0) { --g_bs.skipLeft; ++g_bs.slowSkips; return; }
  // the enemies
  const int doBars = g_ctl.hbar != 0 && g_ctl.ringAssist != 0;   // 1.7.180: Ghost health Off = the mod adds no ghost health at all
  if (!doBars && g_snap.n) { g_snap.seq += 1; g_snap.n = 0; g_snap.qpc = 0; g_snap.seq += 1; }
  const int doRing = g_ctl.ringAssist != 0 && !engine_pke_item();   // 1.5: with the PKE out the game's own ring belongs to the PKE's target
  struct { uintptr_t id; float pos[3]; float frac; double ang, distM; } ringBest = {}, ringCur = {};
  double ringBestEff = 1.0e9;
  uintptr_t ringBossId = 0;   // 1.7.106: the boss that won the ring this scan (for the BOSS data)
  const int64_t holdQ = (int64_t)g_ctl.ringHoldDs * qpc_freq() / 10;
  const double coneDeg = (double)g_ctl.ringConeDeg;
  // 0.77: which enemies get a bar. The game's own "drawn in the last frames" test and its line-of-sight test (no wall between you and the ghost).
  auto gate_pass = [&](uintptr_t actor, const float* w, double radFt, double distM, float zHead, int engaged) -> int {
    (void)actor; (void)radFt; (void)distM; (void)zHead;
    if (!g_ctl.hbarGate || !g_ctl.hbarWallHide) return 1;
    if (engaged) { ++g_gate.shownGate; return 1; }   // 1.7.209: an enemy you are hurting needs no wall test (its centre lies inside its own body)
    if (!player || !memcache::readable((const void*)player, 0x60, 0, 1)) return 0;
    const LosFn fn = (LosFn)rva(kRvaLosTest);
    float target[3] = {w[0], w[1], w[2]};
    ++g_gate.losCalls;
    if (!fn((void*)player, target)) { ++g_gate.losBlocked; ++g_gate.wallHidden; return 0; }
    ++g_gate.losClear; ++g_gate.shownGate; return 1;
  };
  // 1.7.19: the game keeps hidden / not-yet-spawned / finished enemies in its list at full health (the 1.7.18 log: its own can-lock test said "no" 53236 times in 73912). They get no bar.
  // A ghost you just hit, or the one in the capture stream, always counts as there.
  auto drawn_recent = [&](uintptr_t actor) -> int {   // the game drew it in the last frames
    const int* fcp = (const int*)rva(kRvaFrameCounter);
    if (!memcache::readable(fcp, 4, 0, 1) || !memcache::readable((const void*)(actor + kOffSeenFrame), 4, 0, 1)) return 0;
    return (*fcp - 3) <= *(const int*)(actor + kOffSeenFrame);
  };
  auto bar_active = [&](uintptr_t actor, int hitRecent, int moving) -> int {
    if (!g_ctl.hbarGate) return 1;
    ++g_gate.activeAsks;
    if (hitRecent || (g_sl.wrPtr && g_sl.wrPtr == actor)) { ++g_gate.activeHit; return 1; }
    if (actor_lockable(actor, player)) { ++g_gate.activeYes; return 1; }
    // Movement/render timestamps do not prove that an enemy has spawned.
    (void)moving; //   // 1.7.118: a ghost that is out and flying about (not one waiting in the level's list)
    // 1.7.114: no "the game drew it" shortcut here: the 1.7.113 report showed ghosts that had not spawned yet (a pack of floaters, 85 m away at 100 %) counted as drawn and got a ring and bars before they appeared
    ++g_gate.notSpawned;
    return 0;
  };
  // 1.7.25 "could see ghost health bar when it was in trap": a trap that is out on the floor (more than 4 ft from you) takes the bars of the ghosts within 3.5 ft of it
  float trapPos[3] = {0, 0, 0}; int haveTrap = 0;
  int trapDown = 0;   // 1.7.30: a trap lies on the floor (not carried), wherever you stand: the 1.7.29 rule needed it more than 4 ft from you, so a ghost trapped at your feet kept its bar
  int trapState = -1;   // 1.7.31: the player's trap state (1 idle, 3 deploying, others unknown: logged next to the ghosts near the trap)
  if (player && memcache::readable((const void*)(player + kOffTrapState), 4, 0, 1)) trapState = *(const int*)(player + kOffTrapState);
  if (player && memcache::readable((const void*)(player + kOffTrapObj), 8, 0, 1)) {
    const uintptr_t tobj = *(const uintptr_t*)(player + kOffTrapObj);
    if (tobj && memcache::readable((const void*)(tobj + layout::kActorPos), 12, 0, 1) && memcache::readable((const void*)(player + layout::kActorPos), 12, 0, 1)) {
      for (int k = 0; k < 3; ++k) trapPos[k] = *(const float*)(tobj + layout::kActorPos + 4 * k);
      const float* pl = (const float*)(player + layout::kActorPos);
      if (safe_float3(trapPos)) {
        const double ex = (double)trapPos[0] - pl[0], ey = (double)trapPos[1] - pl[1], ez = (double)trapPos[2] - pl[2];
        haveTrap = vm::dsqrt(ex * ex + ey * ey + ez * ez) > 4.0;
        trapDown = barlogic::trap_on_floor(trapPos, pl);
      }
    }
  }
  auto in_trap = [&](const float* gp) -> int {
    const double dx = (double)gp[0] - trapPos[0], dy = (double)gp[1] - trapPos[1], dz = (double)gp[2] - trapPos[2];
    const double d2 = dx * dx + dy * dy + dz * dz;
    if (haveTrap && d2 < 3.5 * 3.5) { ++s_trapHidden; return 1; }
    if (g_ctl.hbarSmart && trapDown && d2 < 2.0 * 2.0) { ++g_smart.floorTrapHidden; return 1; }   // 1.7.30: a ghost right at a trap on the floor, however near you are
    return 0;
  };
  // 1.7.31: the game's own line-of-sight test (the one the wall rule uses), for the "gone" rule: 1 = a clear line from the player to the ghost's centre, or to its upper body / near side (any clear line is enough)
  auto los_probe = [&](const float* w, double radFt) -> int {
    if (!player || !memcache::readable((const void*)player, 0x60, 0, 1)) return 1;
    const LosFn fn = (LosFn)rva(kRvaLosTest);
    float t[3] = {w[0], w[1], w[2]};
    ++g_smart.vlosCalls;
    int los = fn((void*)player, t) != 0;
    if (!los) {
      const float* pp = (const float*)(player + layout::kActorPos);
      double dx = (double)pp[0] - w[0], dy = ((double)pp[1] + 4.5) - w[1], dz = (double)pp[2] - w[2];
      const double len = vm::dsqrt(dx * dx + dy * dy + dz * dz);
      if (len > 1.0) {
        double step = radFt * 0.8; if (step > len * 0.5) step = len * 0.5; if (step > 5.0) step = 5.0;
        t[0] = (float)(w[0] + dx / len * step); t[1] = (float)(w[1] + dy / len * step); t[2] = (float)(w[2] + dz / len * step);
        ++g_smart.vlosCalls;
        los = fn((void*)player, t) != 0;
        if (!los) {
          t[0] = w[0]; t[1] = (float)(w[1] + radFt * 0.6); t[2] = w[2];
          ++g_smart.vlosCalls;
          los = fn((void*)player, t) != 0;
        }
      }
    }
    if (los) ++g_smart.vlosClear; else ++g_smart.vlosBlocked;
    return los;
  };
  // 1.7.108: the strict line: the game's own test to the ghost's centre, then to its upper body. No fallback point on the near side of the ghost (those pass a thin wall).
  auto los_strict = [&](const float* w, double radFt) -> int {
    if (!player || !memcache::readable((const void*)player, 0x60, 0, 1)) return 0;
    const LosFn fn = (LosFn)rva(kRvaLosTest);
    float t[3] = {w[0], w[1], w[2]};
    ++g_rw.tests;
    int los = fn((void*)player, t) != 0;
    (void)radFt;
    if (los) ++g_rw.clear;
    return los;
  };
  const uintptr_t* wp = (const uintptr_t*)rva(kRvaWorldPtr);
  if (!memcache::readable(wp, 8, 0, 1) || !*wp || !memcache::readable((const void*)(*wp + kOffActorList), 8, 0, 1)) { ++g_bs.noWorld; return; }
  uintptr_t actor = *(const uintptr_t*)(*wp + kOffActorList);
  AcquireSRWLockExclusive(&g_lifeLock);
  g_life.begin(*wp);
  ReleaseSRWLockExclusive(&g_lifeLock);
  fight::Bar tmp[fight::kMaxBars];
  double tmpD[fight::kMaxBars];
  int nt = 0, seen = 0;
  EnemyPt cen[64]; int ncen = 0;   // 1.7: living enemies of this scan
  ++g_bs.scans;
  float ppw[3] = {0, 0, 0}; int havePP = 0;   // 1.7: the world census needs the player's own position
  if (player && memcache::readable((const void*)(player + layout::kActorPos), 12, 0, 1)) {
    for (int k = 0; k < 3; ++k) ppw[k] = *(const float*)(player + layout::kActorPos + 4 * k);
    havePP = safe_float3(ppw);
  }
  for (int i = 0; i < g_wc.nc; ++i) { WorldCls& w = g_wc.c[i]; w.n = w.nNear = w.nGround = 0; w.nearFt = w.groundFt = 9999.0f; w.nearDy = 0.0f; }
  ++g_wc.scans;
  fight::Marker mkr[fight::kMaxMarkers]; double mkrD[fight::kMaxMarkers]; int nMk = 0;   // 1.7.3
  const int doMark = g_ctl.collectMarkers != 0 && havePP;
  const int pkeOut = g_inv.cur == 5;
  if (doMark) ++g_mk.scans;
  const int scanMode = doMark && !g_ctl.collectMarkerAlways;   // 1.7.3: markers only after a scan: PKE out, point near it for a moment
  float aimD[3] = {0, 0, 1}, aimG[3] = {0, 0, 0};
  const int aimOk = scanMode && pkeOut && engine_pke_aim(aimD, aimG);
  double pingMin = 1.0e9;
  auto mark_consider = [&](uintptr_t act, uintptr_t vp, const float* pos) {
    if (!doMark) return;
    int kind = -1;
    if (vp == rva(kVtTrinket)) kind = 0; else if (vp == rva(kVtPkeSource) && pkeOut) kind = 1;
    if (kind < 0 || !safe_float3(pos)) return;
    const double dx = (double)pos[0] - ppw[0], dy = (double)pos[1] - ppw[1], dz = (double)pos[2] - ppw[2];
    const double distFt = vm::dsqrt(dx * dx + dy * dy + dz * dz);
    if (distFt > (kind == 0 ? 120.0 : 70.0)) return;
    if (kind == 0) {
      ++g_mk.trinkets;
      int id = -1; float val = 0.0f; int picked = 0;
      if (memcache::readable((const void*)(act + kOffTrophyId), 4, 0, 1)) id = *(const int*)(act + kOffTrophyId);
      const uintptr_t* wpp = (const uintptr_t*)rva(kRvaWorldPtr);
      if (id >= 0 && id <= 0x7B && memcache::readable(wpp, 8, 0, 1) && *wpp && memcache::readable((const void*)(*wpp + kOffPickTable + 16 * (uintptr_t)(id + 1)), 4, 0, 1)) {
        val = *(const float*)(*wpp + kOffPickTable + 16 * (uintptr_t)(id + 1));
        picked = val != 0.0f;
      } else ++g_mk.noId;
      int slot = -1;
      for (int i = 0; i < 24; ++i) if (g_mk.seenId[i] == act) { slot = i; break; }
      if (slot < 0 && g_mk.logged < 24) {
        g_mk.seenId[g_mk.logged++] = act;
        log_line("MARKER a collectible (CTrinket, trophy id %d) is %.1f ft away at %.1f,%.1f,%.1f ft; the game's picked-up table says %.1f -> %s", id, distFt, (double)pos[0], (double)pos[1], (double)pos[2], (double)val,
                 picked ? "already collected: no marker" : "not collected yet: a marker is drawn");
      }
      if (picked) { ++g_mk.pickedUp; return; }
    } else ++g_mk.pkeSrc;
    if (scanMode) {
      if (!pkeOut) { ++g_mk.hidden; return; }
      if (distFt < pingMin) pingMin = distFt;
      int ti = -1;
      for (int i = 0; i < 24; ++i) if (g_mkt[i].id == act) { ti = i; break; }
      if (ti < 0) for (int i = 0; i < 24; ++i) if (!g_mkt[i].id) { ti = i; g_mkt[i].id = act; g_mkt[i].aimStartQ = g_mkt[i].lastAimQ = g_mkt[i].revealUntilQ = 0; g_mkt[i].revealed = 0; break; }
      if (ti < 0) ti = (int)((act >> 4) % 24);
      auto& t = g_mkt[ti];
      if (aimOk && distFt <= 40.0) {
        const double vx = (double)pos[0] - aimG[0], vy = (double)pos[1] - aimG[1], vz = (double)pos[2] - aimG[2];
        const double vl = vm::dsqrt(vx * vx + vy * vy + vz * vz);
        if (vl > 0.5) {
          double c = (vx * aimD[0] + vy * aimD[1] + vz * aimD[2]) / vl;
          if (c > 1.0) c = 1.0; if (c < -1.0) c = -1.0;
          const double ang = vm::datan2(vm::dsqrt(1.0 - c * c), c) * 57.29577951308232;
          const double cone = vl < 10.0 ? 50.0 : 32.0;   // a wide cone: you do not have to be exact
          if (ang <= cone) {
            if (!t.lastAimQ || now - t.lastAimQ > qpc_freq() / 4) t.aimStartQ = now;
            t.lastAimQ = now;
            if (now - t.aimStartQ >= qpc_freq() * 6 / 10) {
              if (!t.revealed || t.revealUntilQ < now) {
                ++g_mk.reveals; haptics_add(1, hap::kSrcScan, 0.9f, 180);
                if (g_mk.reveals <= 40) log_line("REVEAL the PKE scan found a %s %.1f ft away (%.0f deg off the PKE's aim): its marker is shown for 12 s", kind == 0 ? "collectible" : "scan target", distFt, ang);
              }
              t.revealed = 1; t.revealUntilQ = now + qpc_freq() * 12;
            }
          }
        }
      }
      if (!(t.revealed && t.revealUntilQ > now)) { ++g_mk.hidden; return; }
    }
    float p[3];
    to_head(pos, p);
    if (!safe_float3(p)) return;
    fight::Marker m;
    m.p[0] = p[0]; m.p[1] = p[1]; m.p[2] = p[2]; m.kind = kind; m.distFt = (float)distFt;
    if (nMk < fight::kMaxMarkers) { mkr[nMk] = m; mkrD[nMk] = distFt; ++nMk; }
    else { int farIdx = 0; for (int q = 1; q < nMk; ++q) if (mkrD[q] > mkrD[farIdx]) farIdx = q; if (distFt < mkrD[farIdx]) { mkr[farIdx] = m; mkrD[farIdx] = distFt; } }
  };
  const int64_t scanQ0 = qpc_now();
  uintptr_t puftBoss = 0; double puftDist2 = 500.0 * 500.0;
  int walked = 0, capHit = 0;
  for (int guard = 0; actor; ++guard) {
    if (guard >= kMaxActors) { capHit = 1; break; }   // 1.7.2: was 700: it cut the list short, so real ghosts (later in the list) were never seen
    if (!memcache::readable((const void*)actor, 0x2A0, 0, 1)) break;
    ++walked;
    const uintptr_t vp = *(const uintptr_t*)actor;
    const int cls = class_index(vp);
    if (cls < 0) unk_note(vp, actor, havePP ? ppw : nullptr);
    if (cls >= 0) {
      ++seen;
      AcquireSRWLockExclusive(&g_lifeLock);
      const int confirmedCaught = g_life.finished(actor);
      ReleaseSRWLockExclusive(&g_lifeLock);
      const int confirmedDead = g_lifeSt.deadState && memcache::readable((const void*)(actor + 0xB874), 4, 0, 1) && *(const int*)(actor + 0xB874) != 0;
      if (confirmedCaught || confirmedDead) {
        if (confirmedCaught) ++g_lifeSt.hiddenCaught; else ++g_lifeSt.hiddenDead;
        ++g_bs.dead;
        actor = *(const uintptr_t*)(actor + kOffNext);
        continue;
      }
      if (memcache::readable((const void*)(actor + kOffHealth), 16, 0, 1)) {
        const float cur = *(const float*)(actor + kOffHealth), mx = *(const float*)(actor + kOffHealthMax);
        const double f = fight::health_frac(cur, mx);
        const float* pos = (const float*)(actor + layout::kActorPos);
        float c[3] = {*(const float*)(actor + kOffCenter), *(const float*)(actor + kOffCenter + 4), *(const float*)(actor + kOffCenter + 8)};
        const float rad = *(const float*)(actor + kOffRadius);
        if (f < 0.0 || !safe_float3(c) || !safe_float3(pos)) { ++g_bs.dead; }
        else if (f <= 0.0) { ++g_bs.dead; }
        else {
          if (vp == rva(0x7A0678) && havePP && g_lifeSt.deadState &&
              memcache::readable((const void*)(actor + 0xB874), 4, 0, 1)) {
            const double dx = (double)pos[0] - ppw[0], dy = (double)pos[1] - ppw[1], dz = (double)pos[2] - ppw[2];
            const double d2 = dx * dx + dy * dy + dz * dz;
            if (d2 < puftDist2) {
              puftBoss = actor; puftDist2 = d2;
            }
          }
          // the bounds centre is a world position; if it is nowhere near the actor it is an offset from it
          double off = vm::dsqrt(((double)c[0] - pos[0]) * ((double)c[0] - pos[0]) + ((double)c[1] - pos[1]) * ((double)c[1] - pos[1]) + ((double)c[2] - pos[2]) * ((double)c[2] - pos[2]));
          const double radOk = (rad > 0.05f && rad < 300.0f) ? (double)rad : 3.0;
          float w[3] = {c[0], c[1], c[2]};
          if (off > radOk * 2.5 + 12.0) { w[0] = pos[0] + c[0]; w[1] = pos[1] + c[1]; w[2] = pos[2] + c[2]; ++g_bs.centerLocal; off = -off; } else ++g_bs.centerWorld;
          g_bs.lastCenterOff = (float)off;
          if (ncen < 64) { EnemyPt& ce = cen[ncen++]; for (int k2 = 0; k2 < 3; ++k2) { ce.pos[k2] = pos[k2]; ce.c[k2] = w[k2]; } ce.rad = (float)radOk; }   // 1.7
          float p[3];
          to_head(w, p);
          const double distM = vm::dsqrt((double)p[0] * p[0] + (double)p[1] * p[1] + (double)p[2] * p[2]);
          // 1.4/1.5: every living enemy is followed for hits (the gun's flutter and the ring both need it), whether bars are drawn or not
          const int ti0 = track_slot(actor, (float)f, now);
          float markerWorld[3], markerP[3];
          healthpos::step_v(g_track[ti0].healthAnchor, g_track[ti0].healthVel, &g_track[ti0].healthAnchorQ,
                          w, now, qpc_freq(), markerWorld);
          to_head(markerWorld, markerP);
          // Weak/continuous firing modes can remove less than 0.4% between
          // actor scans. Compare against the last confirmed damage baseline,
          // not only the previous scan; healing resets that baseline.
          Track& healthTrack = g_track[ti0];
          if (fight::health_drop((float)f, &healthTrack.hitBase)) {
            healthTrack.changeQ = now; g_lastHitQ = now;
          }
          healthTrack.frac = (float)f;
          const int hitRecent = g_track[ti0].changeQ && now - g_track[ti0].changeQ < qpc_freq() * 3 / 2;
          // 1.7.209: the game's can-lock test says "no" to every enemy in VR, so the 1.5 s hit window was all that kept a bar up. An enemy hurt in the last 10 s stays "engaged":
          // it keeps its bar, is not wall-tested and may be farther than 45 m (big bodies lost their bars to the wall test).
          const int barEngaged = g_track[ti0].changeQ && now - g_track[ti0].changeQ < qpc_freq() * 10;
          const double barRangeM = barEngaged ? 90.0 : 45.0;
          ghostmove::step(g_track[ti0].moveAnchor, &g_track[ti0].moveAnchorQ, &g_track[ti0].moveQ, pos, now, qpc_freq());
          const int movingNow = ghostmove::moving(g_track[ti0].moveQ, now, qpc_freq());
          // 1.7.106 BOSSES: the game's health ring and the bars skipped them: a boss's body is not something the game lets you lock onto (it asks that of the weak points), it is far
          // bigger than 45 / 60 m allow, and its centre is rarely where you look. A boss gets the ring by the size of its body, once there is a sign that it is really there.
          const int isBoss = bossring::is_boss(kEnemies[cls].name, (double)mx);
          int bossShown = 0, bossProven = 0; double bossHead[3] = {0, 0, 0}; float bossWorld[3] = {0, 0, 0}; double bossAng = 180.0;
          if (isBoss) {
            ++g_boss.scans;
            if (!bossring::name_is_boss(kEnemies[cls].name)) ++g_boss.bigNotListed;
            const double radH = radOk * inv;
            const double cH[3] = {(double)p[0], (double)p[1], (double)p[2]};
            const int lockedOnB = g_sl.lockPtr && g_sl.lockPtr == actor;
            const int heldB = lockedOnB && g_sl.capQ && (double)(now - g_sl.capQ) / (double)qpc_freq() < 4.0;
            int drawnB = -1;
            { const int* fcp = (const int*)rva(kRvaFrameCounter); if (memcache::readable(fcp, 4, 0, 1) && memcache::readable((const void*)(actor + kOffSeenFrame), 4, 0, 1)) drawnB = (*fcp - 3) <= *(const int*)(actor + kOffSeenFrame); }
            static struct { uintptr_t id; int64_t q, lq, sq, engQ, refQ, provQ; int los, lock, strict, was; float ref; } bl[6];
            int bs = -1;
            for (int k = 0; k < 6; ++k) if (bl[k].id == actor) { bs = k; break; }
            if (bs < 0) { for (int k = 0; k < 6; ++k) if (!bl[k].id) { bs = k; break; } if (bs < 0) bs = (int)((actor >> 4) % 6); bl[bs].id = actor; bl[bs].q = 0; bl[bs].lq = 0; bl[bs].sq = 0; bl[bs].los = 0; bl[bs].lock = -1; bl[bs].strict = 0; bl[bs].engQ = 0; bl[bs].refQ = 0; bl[bs].provQ = 0; bl[bs].ref = 0.0f; bl[bs].was = 0; }
            if (!bl[bs].q || now - bl[bs].q > qpc_freq() / 6) { bl[bs].los = los_probe(w, radOk); bl[bs].q = now; }   // the game's own line-of-sight test, six times a second at most
            if (!bl[bs].lq || now - bl[bs].lq > qpc_freq()) { bl[bs].lock = actor_lockable(actor, player); bl[bs].lq = now; if (bl[bs].lock) ++g_boss.lockYes; else ++g_boss.lockNo; }   // data only: what the game says about locking onto this body
            const int namedB = bossring::name_is_boss(kEnemies[cls].name);
            // 1.7.116 ENGAGED: a boss is there once it LOST HEALTH or is HELD (bossringmath.h present()). The hit test is over a window (its health 0.4 s ago against now): a boss has 100 health in all and the
            // stream takes little per frame. The latch holds 20 s (a fight has pauses). Health going up (a restart) clears it. "Drawn" and "a clear line" no longer count: the unspawned Stay Puft had both.
            if (!bl[bs].refQ) { bl[bs].ref = (float)f; bl[bs].refQ = now; }
            else if (now - bl[bs].refQ >= qpc_freq() * 2 / 5) {
              if (bossring::lost_health((double)bl[bs].ref, f)) { bl[bs].engQ = now; bl[bs].provQ = now; }
              else if (bossring::healed((double)bl[bs].ref, f)) { bl[bs].engQ = 0; bl[bs].provQ = 0; }
              bl[bs].ref = (float)f; bl[bs].refQ = now;
            }
            if (hitRecent || heldB) { bl[bs].engQ = now; bl[bs].provQ = now; }
            // 1.7.119: a named boss that is MOVING (it jumps onto the roof, walks) or that the Stay Puft fight scene is built round is out: the ring waits for no hit. Before, the short phase in
            // which he dies from one hit never showed a ring (the first hit was the last). One that stands where the level put it (not spawned) still gets nothing.
            if (namedB && (bossring::moving_counts(movingNow, distM) || engine_scene_arms(0))) { bl[bs].engQ = now; ++g_boss.byMove; }
            else if (namedB && movingNow) {   // 1.7.142 data: moving, but too far to count (the escort walk)
              static int s_farMoveLogs;
              if (s_farMoveLogs < 6) { ++s_farMoveLogs; log_line("BOSS %s moves %.0f m away (more than %.0f m): no ring until it is closer, loses health or the fight scene starts", kEnemies[cls].name, distM, bossring::move_range_m()); }
            }
            const int engagedB = bl[bs].engQ && (double)(now - bl[bs].engQ) / (double)qpc_freq() < bossring::engage_s();
            bossProven = bl[bs].provQ && (double)(now - bl[bs].provQ) / (double)qpc_freq() < bossring::engage_s();   // 1.7.206
            if (!namedB && g_ctl.ringWall && !engagedB) {   // 1.7.108: a 1000+ health body that is not a named boss: its lock + drawn way needs the strict line as well
              if (!bl[bs].sq || now - bl[bs].sq > qpc_freq() / 6) { bl[bs].strict = los_strict(w, radOk); bl[bs].sq = now; }
            } else bl[bs].strict = 1;
            const int pres = bossring::present(engagedB, bl[bs].lock > 0, drawnB, namedB, bl[bs].strict);
            if (!pres && g_ctl.ringWall && !namedB) ++g_rw.bigRefused;
            if (pres) { ++g_boss.present; if (heldB) ++g_boss.byHeld; else if (engagedB) ++g_boss.byHit; else ++g_boss.byDrawn; } else ++g_boss.absent;
            if (bl[bs].los) ++g_boss.byLine;   // data only since 1.7.116: how often there was a clear line (it proved nothing)
            if (pres != bl[bs].was) {   // 1.7.116: the moment a boss starts / stops counting as there (40 lines at most)
              static int s_flipLogged;
              if (s_flipLogged < 40) {
                ++s_flipLogged;
                log_line("BOSSNOW %s is %s: health %.0f%%, %.0f m away | signs: hit just now %d, held %d, lost health within the last %.0f s %d, drawn by the game %d, the game's lock test %d, clear line %d (data only) | %s", kEnemies[cls].name, pres ? "THERE now (its health ring may show)" : "not counted as there any more",
                         f * 100.0, distM, hitRecent, heldB, bossring::engage_s(), engagedB, drawnB, bl[bs].lock, bl[bs].los,
                         pres ? (heldB ? "held in the capture stream" : (engagedB ? "it lost health, moved or the fight scene is on" : "the game says it can be locked and draws it")) : "no hit for a while");
              }
              bl[bs].was = pres;
            }
            if (distM > bossring::max_range_m()) ++g_boss.tooFar;
            else if (pres && safe_float3(p) && bossring::ring_point(cH, radH, bossHead)) {
              from_head(bossHead, bossWorld);
              if (safe_float3(bossWorld)) {
                float smoothed[3];
                healthpos::step(g_track[ti0].bossAnchor, &g_track[ti0].bossAnchorQ,   /* 1.7.164: a boss's marker point slides over its body as you look around: no prediction (it would overshoot after a head turn) */
                                bossWorld, now, qpc_freq(), smoothed);
                for (int k = 0; k < 3; ++k) bossWorld[k] = smoothed[k];
                float bp[3]; to_head(bossWorld, bp);
                for (int k = 0; k < 3; ++k) bossHead[k] = bp[k];
                bossShown = 1; bossAng = bossring::body_angle_deg(cH, radH); ++g_boss.ringCand;
              }
            }
            g_boss.lastHealth = (float)f; g_boss.lastMax = mx; g_boss.lastDistM = (float)distM; g_boss.lastAng = (float)bossAng; lstrcpyA(g_boss.lastName, kEnemies[cls].name);
            {   // the first time each boss is met: what it looks like in the game's data (once per actor, 40 lines at most)
              int known = 0; for (int k = 0; k < g_boss.nSeen; ++k) if (g_boss.seen[k] == actor) { known = 1; break; }
              if (!known && g_boss.logged < 40) {
                if (g_boss.nSeen < 12) g_boss.seen[g_boss.nSeen++] = actor;
                ++g_boss.logged;
                log_line("BOSS %s found: health %.0f of %.0f (%.0f%%), %.0f m away, body radius %.1f ft (%s), listed as a boss=%d, the game's lock test says %d | signs: hit lately %d, held %d, engaged (lost health within %.0f s) %d, drawn by the game %d (not a sign since 1.7.116), clear line %d (not a sign) -> %s | ring %.1f deg from the gaze", kEnemies[cls].name,
                         (double)cur, (double)mx, f * 100.0, distM, (double)rad, (rad > 0.05f && rad < 300.0f) ? "read" : "not plausible, 3 ft used", bossring::name_is_boss(kEnemies[cls].name), bl[bs].lock, hitRecent, heldB, bossring::engage_s(), engagedB, drawnB, bl[bs].los,
                         bossShown ? "gets the health ring" : (distM > bossring::max_range_m() ? "too far" : "not there yet (waits for a hit or hold)"), bossAng);
              }
            }
          }
          // 1.7.30 smart health bars (barlogic.h): no bar before the ghost was seen once, none once it is in the trap. Runs for every ghost within range, in front or not, so the latches follow it.
          int actCached = -1, smartHide = 0;
          if (doBars && g_ctl.hbarSmart && g_ctl.hbarGate && player && distM <= barRangeM) {
            Track& tk = g_track[ti0];
            // 1.7.31: the held ghost is the player's LOCK TARGET while the capture button works (player+0x24D80 is the beam object, so the 1.7.30 test could never be true)
            const int lockedOn = g_sl.lockPtr && g_sl.lockPtr == actor;
            const int capRecent = g_sl.capQ && (double)(now - g_sl.capQ) / (double)qpc_freq() < 4.0;
            const int heldNow = lockedOn && capRecent;
            const int knownVis = hitRecent || heldNow;
            int dr = -1;
            {
              const int* fcp = (const int*)rva(kRvaFrameCounter);
              if (memcache::readable(fcp, 4, 0, 1) && memcache::readable((const void*)(actor + kOffSeenFrame), 4, 0, 1)) dr = (*fcp - 3) <= *(const int*)(actor + kOffSeenFrame);
            }
            if (dr >= 0) { if (dr) ++g_smart.drawnYes; else ++g_smart.drawnNo; if (knownVis) { if (dr) ++g_smart.calPass; else ++g_smart.calFail; } }
            const int trusted = barlogic::trust_drawn(g_smart.calPass, g_smart.calFail);
            if (!trusted) ++g_smart.untrustedChecks;
            actCached = bar_active(actor, barEngaged, movingNow);
            const int wasSeen = tk.seen;
            tk.seen = barlogic::seen_step(tk.seen, dr, knownVis, trusted);
            if (tk.seen && !wasSeen) {
              ++g_smart.firstSeen;
              if (g_smart.logged < 40) { ++g_smart.logged; log_line("BARSEEN %s at %.1f ft: first seen (drawn=%d, hit or held=%d, drawn-test trusted=%d, active now=%d) - its bar may show from now on", kEnemies[cls].name, distM / 0.3048, dr, knownVis, trusted, actCached); }
            }
            const int beforeForget = tk.seen;
            tk.seen = barlogic::forget_step(tk.seen, actCached, dr, &tk.inactiveQ, now, qpc_freq(), 2.0);
            if (beforeForget && !tk.seen) { ++g_smart.forgotten; tk.trapped = 0; tk.vanished = 0; tk.goneQ = 0; }
            // trapped latch v2 (along the floor, with a height window)
            const int wasTr = tk.trapped;
            // A living ghost may hover over a trap (the report hid one at
            // 74% health). With the confirmed completion hook available,
            // proximity alone must not retire its bar.
            tk.trapped = g_lifeSt.installed == 1 ? 0 : barlogic::trap_step2(tk.trapped, tk.trapAnchor, lockedOn, capRecent, trapDown, trapPos, pos, 4.0, 1.5, 14.0, 8.0);
            if (tk.trapped && !wasTr) {
              ++g_smart.latched; if (heldNow) ++g_smart.heldLatched;
              if (g_smart.trapLogged < 40) { ++g_smart.trapLogged; log_line("BARTRAPPED %s at %.1f,%.1f,%.1f ft is in the trap (%.1f ft along the floor from a trap on the floor, %.1f ft above it, locked on=%d, capture button lately=%d, trap state %d, drawn=%d, health %.0f%%): no bar from now on", kEnemies[cls].name, (double)pos[0], (double)pos[1], (double)pos[2], barlogic::dist_xz(pos, trapPos) , (double)pos[1] - trapPos[1], lockedOn, capRecent, trapState, dr, f * 100.0); }
            }
            if (!tk.trapped && wasTr) ++g_smart.unlatched;
            // the "gone" rule: seen, active, in front inside a narrow cone, a clear line to it, and the game has not drawn it for 1 s -> it is gone (sucked into the trap, finished, hidden). Behind a wall (blocked line) the bar stays.
            {
              const int inCone = tk.seen && actCached == 1 && distM < 30.0 && barlogic::in_cone(p, 30.0);
              int losOk = 0;
              if (inCone && trusted && dr >= 0) {
                if (!tk.losQ || now - tk.losQ > qpc_freq() / 6) { tk.los = los_probe(w, radOk); tk.losQ = now; }
                losOk = tk.los;
              }
              if (inCone && losOk && dr >= 0 && !hitRecent && !tk.trapped) { if (dr) ++g_smart.inViewDrawn; else ++g_smart.inViewNot; }
              const int goneOk = barlogic::vanish_trusted(g_smart.inViewDrawn, g_smart.inViewNot);
              if (!goneOk) ++g_smart.goneOffChecks;
              const int cond = inCone && losOk && dr == 0 && trusted && goneOk && !barEngaged;
              const int wasGone = tk.vanished;
              tk.vanished = barlogic::vanish_step(&tk.goneQ, cond, now, qpc_freq(), 1.0);
              if (tk.vanished && !wasGone) {
                ++g_smart.goneSet;
                if (g_smart.goneLogged < 40) { ++g_smart.goneLogged; log_line("BARGONE %s at %.1f,%.1f,%.1f ft (%.1f m away, health %.0f%%) was seen, is in front of you with a clear line, but the game has not drawn it for 1 s: no bar until it is drawn again (locked on=%d, trapped latch=%d, trap state %d)", kEnemies[cls].name, (double)pos[0], (double)pos[1], (double)pos[2], distM, f * 100.0, lockedOn, tk.trapped, trapState); }
              }
              if (!tk.vanished && wasGone) ++g_smart.goneCleared;
            }
            // Finished actors are excluded by the game state/event above;
            // low health and release of capture alone do not prove a catch.
            if (!barlogic::bar_allowed(tk.seen, tk.trapped) || tk.vanished) {
              smartHide = 1;
              if (actCached == 1) { if (tk.trapped) ++g_smart.trappedHidden; else if (tk.vanished) ++g_smart.goneHidden; else ++g_smart.unseenHidden; }
            }
            // TRAPWATCH: what a ghost near a trap on the floor looks like in the game's data (the first 150 lines, at most 4 a second): the next log shows what a catch really does
            if (trapDown && g_smart.watchLogged < 150 && barlogic::dist_xz(pos, trapPos) < 12.0 && ((double)pos[1] - trapPos[1] < 25.0 && (double)trapPos[1] - pos[1] < 25.0) && now - g_smart.watchQ >= qpc_freq() / 4) {
              g_smart.watchQ = now; ++g_smart.watchLogged;
              log_line("TRAPWATCH %s %.1f ft along the floor from the trap, %.1f ft above it | locked on=%d, capture button %.1f s ago, trap state %d | drawn=%d (age %d frames), active=%d, seen=%d, health %.0f%%, hit lately=%d | trapped latch=%d, gone=%d", kEnemies[cls].name,
                       barlogic::dist_xz(pos, trapPos), (double)pos[1] - trapPos[1], lockedOn, g_sl.capQ ? (double)(now - g_sl.capQ) / (double)qpc_freq() : -1.0, trapState, dr,
                       memcache::readable((const void*)rva(kRvaFrameCounter), 4, 0, 1) && memcache::readable((const void*)(actor + kOffSeenFrame), 4, 0, 1) ? *(const int*)rva(kRvaFrameCounter) - *(const int*)(actor + kOffSeenFrame) : -1,
                       actCached, tk.seen, f * 100.0, hitRecent, tk.trapped, tk.vanished);
            }
          }
          int lockable = 1;
          if (isBoss) lockable = 0;   // 1.7.106: bosses are taken below, by the size of their body
          else if (doRing && g_ctl.ringClearGone && player) {
            lockable = actor_lockable(actor, player);
            if (!lockable) {   // 1.7.113: the game's can-lock test says no to ghosts that are plainly there: one you hit, hold or that the game drew this moment still gets health
              const int heldL = g_sl.lockPtr && g_sl.lockPtr == actor && g_sl.capQ && (double)(now - g_sl.capQ) / (double)qpc_freq() < 4.0;
              if (g_ctl.healthAny && hitRecent) { lockable = 1; ++g_rps.overHit; }
              else if (g_ctl.healthAny && heldL) { lockable = 1; ++g_rps.overHeld; }
              // Do not activate health merely because an unspawned actor moved. //   // 1.7.118: flying about and drawn = out, even before the first hit
              if (lockable) ++g_rps.lockOverride;
            }
            if (!lockable) {
              ++g_rps.notLockable; if (actor == g_rps.cur) ++g_rps.droppedGone;
              if (g_rps.goneLogged < 40) { ++g_rps.goneLogged; log_line("RINGGONE %s at %.1f,%.1f,%.1f ft (health %.0f%%, %.1f m away) is not a lockable enemy right now (hidden / finished / not active): the ring ignores it%s", kEnemies[cls].name, (double)pos[0], (double)pos[1], (double)pos[2], f * 100.0, distM, actor == g_rps.cur ? " - it was the ring's ghost: the ring is let go" : ""); }
            }
          }
          if (doRing && lockable && safe_float3(p) && safe_float3(pos)) {
            double ang = 180.0;
            if (p[2] > 0.3f) { const double hy = vm::dsqrt((double)p[0] * p[0] + (double)p[1] * p[1]); ang = vm::datan2(hy, (double)p[2]) * 180.0 / vm::kPi; }
            const int isCur = actor == g_rps.cur;
            // 1.7.111 the ring follows the ghost you are BEAMING: one you hold (locked + capture) or hit within the last 1.5 s takes the ring wherever your head looks (it used to need to be
            // within 35-56 degrees of the gaze, so a ghost shot to the side lost to whatever stood in front: the ring sat on a far body while the real ghosts flew about)
            const int lockedS = g_sl.lockPtr && g_sl.lockPtr == actor;
            const int heldS = lockedS && g_sl.capQ && (double)(now - g_sl.capQ) / (double)qpc_freq() < 4.0;
            const int strongS = g_ctl.ringFollow && (hitRecent || heldS);
            const double limit = strongS ? 110.0 : ((isCur || hitRecent) ? coneDeg * 1.6 : coneDeg);
            if (isCur) { ringCur.id = actor; ringCur.pos[0] = markerWorld[0]; ringCur.pos[1] = markerWorld[1]; ringCur.pos[2] = markerWorld[2]; ringCur.frac = (float)f; ringCur.ang = ang; ringCur.distM = distM; }
            int seenOk = 1;   // 1.7.108 RING WALL: no ring on a ghost behind a wall (the game would not lock onto it; the mod's own pick used to)
            if (distM < 60.0 && ang < limit && g_ctl.ringWall && player) {
              seenOk = los_strict(w, 0.0);
              if (!seenOk) ++g_rw.refused;
            }
            if (!seenOk && ringCur.id == actor) ringCur.id = 0;
            if (distM < (strongS ? 120.0 : 60.0) && ang < limit && seenOk) {
              double eff = ang;
              if (isCur) eff *= 0.7;
              if (hitRecent) eff *= 0.4;
              if (strongS) {   // the beamed ghost beats every ghost that is only looked at: held first, then the most recent hit
                const double hitAge = g_track[ti0].changeQ ? (double)(now - g_track[ti0].changeQ) / (double)qpc_freq() : 1.5;
                eff = (heldS ? -2000.0 : -1000.0) + hitAge * 10.0 + ang * 0.01;
                ++g_rps.beamPicks;
              }
              if (eff < ringBestEff) { ringBestEff = eff; ringBest.id = actor; ringBest.pos[0] = markerWorld[0]; ringBest.pos[1] = markerWorld[1]; ringBest.pos[2] = markerWorld[2]; ringBest.frac = (float)f; ringBest.ang = ang; ringBest.distM = distM; }
            }
          }
          if (isBoss && bossShown) {   // 1.7.206: a boss you hit or hold in the last 20 s needs no wall test (the ray into its own body was refused 90-95 % of scans in the kitchen)
            if (bossProven) ++g_boss.wallSkipped;
            else if (!los_strict(bossWorld, 0.0)) { bossShown = 0; ++g_boss.wallRefused; }
          }
          if (isBoss && doRing && bossShown) {   // 1.7.106: the ring candidate of a boss: the ring goes where you look on its body; a ghost nearer your gaze wins (4 degrees of preference)
            const int isCurB = actor == g_rps.cur;
            const int heldBS = g_sl.lockPtr && g_sl.lockPtr == actor && g_sl.capQ && (double)(now - g_sl.capQ) / (double)qpc_freq() < 4.0;
            const int strongB = g_ctl.ringFollow && (hitRecent || heldBS);   // 1.7.111: a boss you are hitting or holding takes the ring like any ghost
            const double limitB = strongB ? 110.0 : ((isCurB || hitRecent) ? coneDeg * 1.6 : coneDeg);
            if (isCurB) { ringCur.id = actor; ringCur.pos[0] = bossWorld[0]; ringCur.pos[1] = bossWorld[1]; ringCur.pos[2] = bossWorld[2]; ringCur.frac = (float)f; ringCur.ang = bossAng; ringCur.distM = distM; }
            if (bossAng < limitB) {
              double eff = bossAng + 4.0;
              if (isCurB) eff *= 0.7;
              if (hitRecent) eff *= 0.4;
              if (strongB) eff = (heldBS ? -2000.0 : -1000.0) + bossAng * 0.01;
              if (eff < ringBestEff) { ringBestEff = eff; ringBest.id = actor; ringBest.pos[0] = bossWorld[0]; ringBest.pos[1] = bossWorld[1]; ringBest.pos[2] = bossWorld[2]; ringBest.frac = (float)f; ringBest.ang = bossAng; ringBest.distM = distM; ringBossId = actor; }
            }
          }
          if (isBoss && doBars && bossShown) {   // 1.7.106: a boss's bar (the probe's own ring is the fallback if the game's is not on the screen): at the ring's spot, the same size at any distance
            fight::Bar bar;
            bar.p[0] = (float)bossHead[0]; bar.p[1] = (float)bossHead[1]; bar.p[2] = (float)bossHead[2];
            bar.radius = (float)bossring::ring_radius(vm::dsqrt(bossHead[0] * bossHead[0] + bossHead[1] * bossHead[1] + bossHead[2] * bossHead[2]), 0.4);
            bar.frac = (float)f; bar.flags = fight::kFlagBoss; bar.actor = (unsigned long long)actor;   // 1.7.164: marked as a boss (no size fitting)
            {   // the drawn health slides toward the real one, like the ghosts' bars
              Track& tk = g_track[ti0];
              const double dtS = tk.shownQ ? (double)(now - tk.shownQ) / (double)qpc_freq() : 0.0;
              const double was = tk.shownQ ? (double)tk.shown : -1.0;
              tk.shown = (float)fight::ease_shown(was, f, dtS);
              tk.shownQ = now;
              bar.frac = tk.shown;
            }
            if (g_track[ti0].changeQ && now - g_track[ti0].changeQ < qpc_freq() * 4) bar.flags |= fight::kFlagRecent;
            const double bd = vm::dsqrt(bossHead[0] * bossHead[0] + bossHead[1] * bossHead[1] + bossHead[2] * bossHead[2]);
            if (nt < fight::kMaxBars) { tmp[nt] = bar; tmpD[nt] = bd; ++nt; }
            else { int farIdx = 0; for (int q = 1; q < nt; ++q) if (tmpD[q] > tmpD[farIdx]) farIdx = q; if (bd < tmpD[farIdx]) { tmp[farIdx] = bar; tmpD[farIdx] = bd; } }
            ++g_boss.barsMade;
          }
          else if (!(p[2] > 0.3f)) ++g_bs.behind;
          else if (distM > barRangeM) ++g_bs.fartherThanRange;
          else if (doBars && safe_float3(p) && !smartHide && !in_trap(pos) && (actCached >= 0 ? actCached : bar_active(actor, barEngaged, movingNow)) && gate_pass(actor, w, radOk, distM, p[2], barEngaged)) {
            fight::Bar bar;
            bar.p[0] = markerP[0]; bar.p[1] = markerP[1]; bar.p[2] = markerP[2];
            bar.radius = (float)(radOk * inv);
            bar.frac = (float)f;   // (eased below once the slot is known)
            bar.flags = 0;
            bar.actor = (unsigned long long)actor;   // 1.7.103: which ghost (the ring is put on one of them)
            // recently hit?
            const int ti = ti0;   // 1.7.116: the same record as above (the second lookup found the same slot and its drop test could never fire: the health was already stored)
            {   // 1.7.19: the drawn health slides toward the real one (colour follows)
              Track& tk = g_track[ti];
              const double dtS = tk.shownQ ? (double)(now - tk.shownQ) / (double)qpc_freq() : 0.0;
              const double was = tk.shownQ ? (double)tk.shown : -1.0;
              tk.shown = (float)fight::ease_shown(was, f, dtS);
              tk.shownQ = now;
              bar.frac = tk.shown;
              ++g_bs.eased; if (vm::dabs(f - (double)tk.shown) > 0.02) ++g_bs.easing;
            }
            if (g_track[ti].changeQ && now - g_track[ti].changeQ < qpc_freq() * 4) bar.flags |= fight::kFlagRecent;
            // keep the nearest kMaxBars
            if (nt < fight::kMaxBars) { tmp[nt] = bar; tmpD[nt] = distM; ++nt; }
            else { int farIdx = 0; for (int q = 1; q < nt; ++q) if (tmpD[q] > tmpD[farIdx]) farIdx = q; if (distM < tmpD[farIdx]) { tmp[farIdx] = bar; tmpD[farIdx] = distM; } }
            g_bs.lastFrac = (float)f; g_bs.lastCls = cls; g_bs.lastDistM = (float)distM; g_bs.lastRadFt = rad;
          }
          else if (barEngaged) {   // 1.7.209 BARMISS (data only): an enemy hurt within 10 s that still got no bar, and why
            static int s_missLogged;
            if (s_missLogged < 40) { ++s_missLogged; log_line("BARMISS %s hurt within 10 s, %.1f m away, health %.0f%%: no bar because %s", kEnemies[cls].name, distM, f * 100.0,
              !doBars ? "bars are off" : smartHide ? "the seen / trapped / gone rule hid it" : actCached == 0 ? "bar_active said no" : "trap radius or the wall test"); }
          }
        }
      }
    }
    else if (havePP) { if (g_ctl.probeData) { world_note(vp, (const float*)(actor + layout::kActorPos), ppw); if (vp == rva(kVtTrinket)) trinket_note(actor, (const float*)(actor + layout::kActorPos), ppw, now); } if (doMark) mark_consider(actor, vp, (const float*)(actor + layout::kActorPos)); }   // 1.7: not an enemy: the log learns what it is (1.7.2: the collectibles get their own lines)
    actor = *(const uintptr_t*)(actor + kOffNext);
  }
  if (!actor || puftBoss) {
    if (!puftBoss || puftBoss != g_puft.boss || *wp != g_puft.world || player != g_puft.player) {
      g_puft.focusValid = 0; g_puft.focusQ = 0;
    }
    if (puftBoss && (!g_puft.focusQ || now - g_puft.focusQ > qpc_freq() / 10)) {
      g_puft.focusQ = now;
      g_puft.focusValid = engine_boss_mouth(puftBoss, g_puft.mouth);
      g_puft.stage = memcache::readable((const void*)(puftBoss + 0xD154), 4, 0, 1) ? *(const int*)(puftBoss + 0xD154) : 0;
    }
    g_puft.player = player; g_puft.world = *wp; g_puft.boss = puftBoss;
    g_puft.qpc = now;
  }
  {   // 1.7.2: how long the list is, how long the walk took, and a slow walk is thinned out
    g_bs.listLast = walked; if (walked > g_bs.listMax) g_bs.listMax = walked;
    if (walked > 700) ++g_bs.listOver700;
    if (capHit) ++g_bs.capHits;
    const int64_t us = (qpc_now() - scanQ0) * 1000000 / (qpc_freq() ? qpc_freq() : 1);
    g_bs.scanUsSum += us; if (us > g_bs.scanUsMax) g_bs.scanUsMax = us;
    if (us > 2500) { g_bs.skipLeft = 2; }   // the walk cost over 2.5 ms: the next two frames reuse this one's result
    if (g_bs.listLogged < 6 && (walked > 700 || capHit) && (g_bs.listLogged == 0 || walked > g_bs.listMax - 1)) {
      ++g_bs.listLogged;
      log_line("ACTORLIST the game's actor list is %d long (1.7.1 stopped at 700: the real ghosts come later in the list); %d enemies found in it; the walk took %d us%s", walked, seen, (int)us, capHit ? " - STOPPED AT THE LIMIT, the list is even longer" : "");
    }
  }
  if (g_ctl.probeData && havePP && g_wc.nc) {   // 1.7: log what is around you (new kinds as they show up, a summary every 8 s)
    for (int i = 0; i < g_wc.nc; ++i) {
      WorldCls& w = g_wc.c[i];
      if (!w.newLogged && w.n > 0 && g_wc.newLogged < 160) {
        w.newLogged = 1; ++g_wc.newLogged;
        log_line("WORLDCLASS new kind of object: %s (vtable +0x%X): %d now in the world list, nearest %.1f ft (height difference %+.1f ft), %d lie on the floor within 25 ft", w.name, (unsigned)(w.vt - g_game.base), w.n, (double)w.nearFt, (double)w.nearDy, w.nGround);
      }
    }
    if (now - g_wc.lastQ >= qpc_freq() * 8 && g_wc.sumLogged < 90) {
      g_wc.lastQ = now; ++g_wc.sumLogged;
      char buf[900]; int o = 0;
      int used[64] = {0};
      for (int pick = 0; pick < 10; ++pick) {
        int bi = -1; float bd = 9998.0f;
        for (int i = 0; i < g_wc.nc; ++i) if (!used[i] && g_wc.c[i].n > 0 && g_wc.c[i].nearFt < bd) { bd = g_wc.c[i].nearFt; bi = i; }
        if (bi < 0) break;
        used[bi] = 1;
        const WorldCls& w = g_wc.c[bi];
        o += wsprintfA(buf + o, "%s%s x%d nearest %d.%d ft (%s%d.%d up)%s", pick ? "; " : "", w.name, w.n, (int)w.nearFt, (int)(w.nearFt * 10.0f) % 10,
                       w.nearDy < 0 ? "-" : "+", (int)(w.nearDy < 0 ? -w.nearDy : w.nearDy), (int)((w.nearDy < 0 ? -w.nearDy : w.nearDy) * 10.0f) % 10, w.nGround ? " [on the floor]" : "");
        if (o > 760) break;
      }
      log_line("WORLD around you (nearest kinds of object that are not enemies; %d kinds seen so far%s): %s", g_wc.nc, g_wc.overflow ? ", list full" : "", buf);
    }
  }
  {   // 1.7: publish the census (the aim assist asks it whether a world point is a ghost)
    g_census.seq += 1;
    g_census.n = ncen;
    for (int i = 0; i < ncen; ++i) g_census.e[i] = cen[i];
    g_census.qpc = now;
    g_census.seq += 1;
  }
  {   // 1.7.13 the PKE's proximity buzz: the right hand buzzes faster AND stronger the closer the nearest thing to scan is (an unscanned PKE source, or a collectible you are scanning for)
    double nearD = 1.0e9;
    if (pkeOut && g_pkeNearQ && (double)(now - g_pkeNearQ) / (double)qpc_freq() < 0.6 && g_pkeNearFt < nearD) nearD = g_pkeNearFt;
    if (scanMode && pkeOut && pingMin < nearD) nearD = pingMin;
    g_mk.proxNearFt = nearD < 1.0e8 ? nearD : -1.0;
    if (pkeOut && g_ctl.pkeProxBuzz && nearD < hap::kProxRangeFt) {
      const double period = hap::prox_period_s(nearD);
      if (!g_pingQ || (double)(now - g_pingQ) / (double)qpc_freq() >= period) {
        g_pingQ = now; ++g_mk.pings;
        haptics_add(1, hap::kSrcScan, (float)hap::prox_level(nearD), hap::prox_ms(nearD));
        if (nearD < g_mk.proxMinFt || g_mk.proxMinFt <= 0.0) g_mk.proxMinFt = nearD;
        if (g_mk.proxLogged < 30 && (g_mk.pings % 25) == 1) { ++g_mk.proxLogged; log_line("PKEPROX buzz: nearest unscanned thing %.1f ft away -> strength %.2f, every %.2f s, %d ms (the closer, the faster and stronger)", nearD, hap::prox_level(nearD), period, hap::prox_ms(nearD)); }
      }
    }
  }
  {   // 1.7.3: publish the markers (older than 0.4 s they are not drawn)
    g_msnap.seq += 1;
    g_msnap.n = doMark ? nMk : 0;
    for (int i = 0; i < nMk && doMark; ++i) g_msnap.m[i] = mkr[i];
    g_msnap.qpc = now;
    g_msnap.seq += 1;
    if (doMark) { g_mk.published += nMk; if (nMk > g_mk.maxShown) g_mk.maxShown = nMk; }
  }
  g_bs.enemies += seen; g_bs.lastSeen = seen;
  if (seen > g_bs.maxSeen) g_bs.maxSeen = seen;
  g_bs.shown += nt;
  if (doBars) {
    g_snap.seq += 1;   // odd: being written
    g_snap.n = nt;
    for (int i = 0; i < nt; ++i) g_snap.b[i] = tmp[i];
    for (int i = 0; i < 9; ++i) g_snap.frame.view[i] = view9[i];
    for (int i = 0; i < 3; ++i) g_snap.frame.head[i] = hc[i];
    g_snap.frame.fpm = fpm;
    g_snap.qpc = now;
    g_snap.seq += 1;
  }
  {   // 1.5 the ring: the ghost in the look cone (or the one you just hit), else the last one for a moment
    ++g_rps.scans;
    const uintptr_t was = g_rps.cur;
    uintptr_t useId = 0; const float* usePos = nullptr; float useFrac = 0; double useAng = 0, useDist = 0; int held = 0;
    if (doRing && ringBest.id) {
      if (ringBossId && ringBest.id == ringBossId) ++g_boss.picked;
      useId = ringBest.id; usePos = ringBest.pos; useFrac = ringBest.frac; useAng = ringBest.ang; useDist = ringBest.distM;
      g_rps.lastInQ = now;
    } else if (doRing && ringCur.id && g_rps.lastInQ && now - g_rps.lastInQ < holdQ) {
      useId = ringCur.id; usePos = ringCur.pos; useFrac = ringCur.frac; useAng = ringCur.ang; useDist = ringCur.distM; held = 1;
    }
    g_rps.cur = useId;
    g_rp.seq += 1;
    if (useId && usePos) {
      g_rp.valid = 1; g_rp.pos[0] = usePos[0]; g_rp.pos[1] = usePos[1]; g_rp.pos[2] = usePos[2]; g_rp.frac = useFrac; g_rp.actor = useId; g_rp.qpc = now;
      ++g_rps.picks; if (held) ++g_rps.held;
      g_rps.lastAng = (float)useAng; g_rps.lastDistM = (float)useDist; g_rps.lastFrac = useFrac;
      if (useId != was) {
        ++g_rps.switches;
        if (g_rps.logged < 60) { ++g_rps.logged; log_line("RINGPICK the game's ring goes to the ghost at %.1f,%.1f,%.1f ft: %.1f deg from where you look, %.1f m away, health %.0f%% (switch #%ld, ring object seen %s)", (double)usePos[0], (double)usePos[1], (double)usePos[2], useAng, useDist, (double)useFrac * 100.0, g_rps.switches, g_rps.picks > 1 ? "yes" : "not yet"); }
      }
    } else {
      g_rp.valid = 0;
      if (doRing) { if (seen) ++g_rps.noCandidate; else ++g_rps.none; }
      if (was && g_rps.logged < 60) { ++g_rps.logged; log_line("RINGPICK the ring is released (nothing within %d deg of where you look%s)", (int)g_ctl.ringConeDeg, was ? ", or it died" : ""); }
    }
    g_rp.seq += 1;
    if (doBars) {   // 1.7.103 the round ring: the bar of the ghost the game's ring belongs to (the one you look at, or the one you hold) is marked
      g_snap.seq += 1;
      for (int i = 0; i < g_snap.n; ++i) {
        const unsigned long long id = g_snap.b[i].actor;
        const int focus = id && ((useId && id == (unsigned long long)useId) || (g_sl.lockPtr && id == (unsigned long long)g_sl.lockPtr));
        if (focus) g_snap.b[i].flags |= fight::kFlagFocus; else g_snap.b[i].flags &= ~(unsigned)fight::kFlagFocus;
      }
      g_snap.seq += 1;
    }
  }
}

int fight_bars_read(void* out, int cap, int64_t* qpc) {
  fight::Bar* o = (fight::Bar*)out;
  for (int tries = 0; tries < 3; ++tries) {
    const LONG s0 = g_snap.seq;
    if (s0 & 1) continue;
    int n = g_snap.n;
    if (n > cap) n = cap;
    for (int i = 0; i < n; ++i) o[i] = g_snap.b[i];
    const int64_t q = g_snap.qpc;
    const BarFrame source = g_snap.frame;
    if (g_snap.seq != s0) continue;
    if (qpc) *qpc = q;
    if (!q || qpc_now() - q > qpc_freq() / 6) return 0;   // older than 160 ms: not shown
    for (int attempt = 0; attempt < 3; ++attempt) {
      const LONG frameSeq = g_barFrame.seq;
      if (frameSeq & 1) continue;
      const BarFrame current = g_barFrame.frame;
      if (frameSeq != g_barFrame.seq) continue;
      if (!(source.fpm > 0.1 && current.fpm > 0.1)) return 0;
      for (int i = 0; i < n; ++i) fight::rebase_bar(o[i], source.view, source.head, source.fpm, current.view, current.head, current.fpm);
      return n;
    }
    return 0;
  }
  return 0;
}

int fight_markers_read(void* out, int cap) {
  fight::Marker* o = (fight::Marker*)out;
  for (int tries = 0; tries < 3; ++tries) {
    const LONG s0 = g_msnap.seq;
    if (s0 & 1) continue;
    int n = g_msnap.n;
    if (n > cap) n = cap;
    for (int i = 0; i < n; ++i) o[i] = g_msnap.m[i];
    const int64_t q = g_msnap.qpc;
    if (g_msnap.seq != s0) continue;
    if (!q || qpc_now() - q > qpc_freq() * 2 / 5) return 0;
    return n;
  }
  return 0;
}

int fight_ring_pick(float* pos3, float* frac, uintptr_t* actor) {
  for (int tries = 0; tries < 3; ++tries) {
    const LONG s0 = g_rp.seq;
    if (s0 & 1) continue;
    const int valid = g_rp.valid;
    float p[3] = {g_rp.pos[0], g_rp.pos[1], g_rp.pos[2]};
    const float f = g_rp.frac;
    const uintptr_t a = g_rp.actor;
    const int64_t q = g_rp.qpc;
    if (g_rp.seq != s0) continue;
    if (!valid || !q || qpc_now() - q > qpc_freq() / 4) return 0;   // older than a quarter second: not used
    if (pos3) { pos3[0] = p[0]; pos3[1] = p[1]; pos3[2] = p[2]; }
    if (frac) *frac = f;
    if (actor) *actor = a;
    return 1;
  }
  return 0;
}

// 1.7.116 HEALTH30: the health ring / bars / boss numbers in the player's log too (damage_report() below only runs in the developer's full-diagnostics mode, so the 1.7.113-1.7.115 reports had
// none of them). Called every 30 s by engine_issue_report(); it prints the change since the last call and never touches the counters.
void damage_issue_report() {
  static struct { long scans, enemies, shown, picks, held, switches, notLockable, overHit, overHeld, beamPicks, rwRefused, rwHit, rwHeld, actAsks, actYes, actHit, notSpawned, bScans, bPresent, bHit, bHeld, bLock, bAbsent, bFar, bCand, bPicked, bBars, evict, thrash; } p;
  struct Cur { long scans, enemies, shown, picks, held, switches, notLockable, overHit, overHeld, beamPicks, rwRefused, rwHit, rwHeld, actAsks, actYes, actHit, notSpawned, bScans, bPresent, bHit, bHeld, bLock, bAbsent, bFar, bCand, bPicked, bBars, evict, thrash; } c;
  c.scans = g_bs.scans; c.enemies = g_bs.enemies; c.shown = g_bs.shown; c.picks = g_rps.picks; c.held = g_rps.held; c.switches = g_rps.switches; c.notLockable = g_rps.notLockable;
  c.overHit = g_rps.overHit; c.overHeld = g_rps.overHeld; c.beamPicks = g_rps.beamPicks; c.rwRefused = g_rw.refused; c.rwHit = g_rw.byHit; c.rwHeld = g_rw.byHeld;
  c.actAsks = g_gate.activeAsks; c.actYes = g_gate.activeYes; c.actHit = g_gate.activeHit; c.notSpawned = g_gate.notSpawned;
  c.bScans = g_boss.scans; c.bPresent = g_boss.present; c.bHit = g_boss.byHit; c.bHeld = g_boss.byHeld; c.bLock = g_boss.byDrawn; c.bAbsent = g_boss.absent; c.bFar = g_boss.tooFar; c.bCand = g_boss.ringCand; c.bPicked = g_boss.picked; c.bBars = g_boss.barsMade;
  c.evict = g_trackEvict; c.thrash = g_trackThrash;
  auto d = [](long now, long was) { return now >= was ? now - was : now; };   // a counter that was reset starts again from 0
  const long sc = d(c.scans, p.scans);
  log_line("HEALTH30 (30 s window) health_style=%d (0 ring, 1 bars) health_any=%d ring_wall=%d | %ld scans: enemies in the game's list now %d (most at once %d), ghost records in use %ld of %d, taken over from another ghost %ld (in the same scan %ld: the table is too small if that is not 0) | "
           "RING: on a ghost in %ld scans (kept %ld after you looked away), switches %ld, ghosts you hit or hold %ld, the game's can-lock test said no %ld times: let in anyway because you hit it %ld / hold it %ld, kept off because a wall is in the way %ld | "
           "BARS: asked %ld, shown as active %ld (hit or held %ld), not spawned %ld, drawn per scan %.1f | "
           "BOSS: bodies met %ld, counted as there %ld (lost health %ld, held %ld, lock test yes + drawn %ld), waiting for a hit or hold %ld, too far %ld, ring candidates %ld, won the ring %ld, bars %ld",
           (int)g_ctl.healthStyle, (int)g_ctl.healthAny, (int)g_ctl.ringWall, sc, g_bs.lastSeen, g_bs.maxSeen, g_trackUsed, kTrackN, d(c.evict, p.evict), d(c.thrash, p.thrash),
           d(c.picks, p.picks), d(c.held, p.held), d(c.switches, p.switches), d(c.beamPicks, p.beamPicks), d(c.notLockable, p.notLockable), d(c.overHit, p.overHit), d(c.overHeld, p.overHeld), d(c.rwRefused, p.rwRefused),
           d(c.actAsks, p.actAsks), d(c.actYes, p.actYes), d(c.actHit, p.actHit), d(c.notSpawned, p.notSpawned), sc > 0 ? (double)d(c.shown, p.shown) / (double)sc : 0.0,
           d(c.bScans, p.bScans), d(c.bPresent, p.bPresent), d(c.bHit, p.bHit), d(c.bHeld, p.bHeld), d(c.bLock, p.bLock), d(c.bAbsent, p.bAbsent), d(c.bFar, p.bFar), d(c.bCand, p.bCand), d(c.bPicked, p.bPicked), d(c.bBars, p.bBars));
  p.scans = c.scans; p.enemies = c.enemies; p.shown = c.shown; p.picks = c.picks; p.held = c.held; p.switches = c.switches; p.notLockable = c.notLockable; p.overHit = c.overHit; p.overHeld = c.overHeld; p.beamPicks = c.beamPicks;
  { // 1.7.188 data: the classes in the game's list that are not one of the enemy classes (name, scans, scans with a plausible health value, nearest such one to you in ft)
    char buf[900]; int o = 0; buf[0] = 0;
    for (int i = 0; i < g_nUnk && o < 780; ++i) {
      if (g_unk[i].withHealth <= 0) continue;
      o += wsprintfA(buf + o, " %s x%ld(health %ld, nearest %d ft)", g_unk[i].name, g_unk[i].scans, g_unk[i].withHealth, g_unk[i].nearFt < 1e8f ? (int)g_unk[i].nearFt : -1);
    }
    log_line("ACTORKINDS classes in the game's list that are not one of the known enemy classes and hold a health value (whole run):%s", o ? buf : " none");
  }
  { // 1.7.118 data: ghosts let in because they fly about (ring / bars), and how many records see a ghost moving now (whole run so far)
    int movingRecs = 0; const int64_t nowQ = qpc_now();
    for (int i = 0; i < kTrackN; ++i) if (g_track[i].id && ghostmove::moving(g_track[i].moveQ, nowQ, qpc_freq())) ++movingRecs;
    log_line("HEALTHFLY ghosts that fly about get health before the first hit (health_any=%d): ring let in %ld times, bars let in %ld times (whole run) | ghosts moving right now %d of %ld records in use", (int)g_ctl.healthAny, g_rps.overMoving, g_gate.activeMoving, movingRecs, g_trackUsed);
  }
  p.rwRefused = c.rwRefused; p.rwHit = c.rwHit; p.rwHeld = c.rwHeld; p.actAsks = c.actAsks; p.actYes = c.actYes; p.actHit = c.actHit; p.notSpawned = c.notSpawned;
  p.bScans = c.bScans; p.bPresent = c.bPresent; p.bHit = c.bHit; p.bHeld = c.bHeld; p.bLock = c.bLock; p.bAbsent = c.bAbsent; p.bFar = c.bFar; p.bCand = c.bCand; p.bPicked = c.bPicked; p.bBars = c.bBars; p.evict = c.evict; p.thrash = c.thrash;
}

void damage_report(LONG frame) {
  log_line("RINGLOCK frame=%d clear_gone=%d | the game's own can-lock test asked %ld times (unreadable %ld): not lockable %ld times, of which the ring's own ghost %ld times (the ring lets go of it at once)", (int)frame, (int)g_ctl.ringClearGone, g_rps.lockChecks, g_rps.lockUnreadable, g_rps.notLockable, g_rps.droppedGone);
  log_line("RINGFOLLOW ring_follow=%d health_style=%d health_any=%d (0 = round ring, 1 = bars) | ghost candidates you held or hit (beam picks, wherever you looked): %ld | the game's can-lock test said no but the ghost still got health: hit %ld, held %ld, drawn on screen %ld", (int)g_ctl.ringFollow, (int)g_ctl.healthStyle, (int)g_ctl.healthAny, g_rps.beamPicks, g_rps.overHit, g_rps.overHeld, g_rps.overDrawn);
  g_rps.beamPicks = 0; g_rps.overHit = g_rps.overHeld = g_rps.overDrawn = 0;
  log_line("RINGPICK frame=%d on=%d cone=%ddeg hold=%.1fs | scans=%ld picks=%ld (held after looking away: %ld) switches=%ld nobody in view=%ld none-around=%ld | last: %.1f deg, %.1f m, health %.0f%% | the game's own ring is %s",
           (int)frame, (int)g_ctl.ringAssist, (int)g_ctl.ringConeDeg, (double)g_ctl.ringHoldDs / 10.0, g_rps.scans, g_rps.picks, g_rps.held, g_rps.switches, g_rps.noCandidate, g_rps.none,
           (double)g_rps.lastAng, (double)g_rps.lastDistM, (double)g_rps.lastFrac * 100.0, g_ctl.ringMode ? "HIDDEN (ring_mode 1)" : "shown");
  fight_trap_carry_report();
  log_line("DELUXESAFE frame=%d game numbers the probe may change: beam_damage_pct=%d (100 = none; the game / Deluxe mod values stand), easy_sprint=%d (0 = the sprint tuning is left alone), aim_assist_pct=%d (0 = the beam is not bent). 1.7.25: Deluxe's enemy health and tuning are never touched.", (int)frame, (int)g_ctl.beamDamagePct, (int)g_ctl.easySprint, (int)g_ctl.aimAssistPct);
  log_line("DMG frame=%d beam_damage=%d%% patched=%d/%d hurtFunctions=%d calls=%ld boosted=%ld nested=%ld zeroDamageBeam=%ld off=%ld extraStrengthTotal=%.1f", (int)frame, (int)g_ctl.beamDamagePct,
           g_installed, kNE, g_nThunks, (long)g_dm.calls, (long)g_dm.boosted, (long)g_dm.nested, (long)g_dm.skipped, (long)g_dm.off, g_dm.extra);
  char b[800]; int n = 0;
  for (int i = 0; i < g_nSeen && n < 700; ++i)
    n += wsprintfA(b + n, " [type 0x%x ammo 0x%x %s: %ld hits, %ld boosted]", g_seen[i].type, g_seen[i].ammo, g_seen[i].cls >= 0 ? kEnemies[g_seen[i].cls].name : "?", (long)g_seen[i].n, (long)g_seen[i].boosted);
  b[n] = 0;
  log_line("DMGSEEN damage kinds that reached the enemies:%s", n ? b : " none yet");
  log_line("BOSS og_health=%d (30 s window): boss bodies met %ld times (%ld not on the name list but with 1000+ health), present %ld (lost health %ld, held %ld, lock test yes + drawn %ld; clear line seen %ld, not a sign), not there yet %ld, too far (over %.0f m) %ld | ring candidates %ld, won the ring %ld times, bars made %ld | the game's own lock test: can lock %ld, cannot %ld | last: %s health %.0f of %.0f, %.0f m away, %.1f deg from the gaze | wall test skipped (you hit it) %ld, refused %ld",
           (int)g_ctl.ogHealth, g_boss.scans, g_boss.bigNotListed, g_boss.present, g_boss.byHit, g_boss.byHeld, g_boss.byDrawn, g_boss.byLine, g_boss.absent, bossring::max_range_m(), g_boss.tooFar, g_boss.ringCand, g_boss.picked, g_boss.barsMade,
           g_boss.lockYes, g_boss.lockNo, g_boss.lastName[0] ? g_boss.lastName : "none yet", (double)g_boss.lastHealth, (double)g_boss.lastMax, (double)g_boss.lastDistM, (double)g_boss.lastAng, g_boss.wallSkipped, g_boss.wallRefused);
  log_line("RINGWALL ring_wall=%d (30 s window): line tests to the ghost %ld (clear %ld) | an ordinary ghost was kept off the ring because a wall is in the way %ld times, taken because you were hitting it %ld / holding it %ld | a 1000+ health body (not a named boss) was refused %ld times",
           (int)g_ctl.ringWall, g_rw.tests, g_rw.clear, g_rw.refused, g_rw.byHit, g_rw.byHeld, g_rw.bigRefused);
  memset(&g_rw, 0, sizeof(g_rw));
  { const int keepLog = g_boss.logged, keepN = g_boss.nSeen; uintptr_t keepSeen[12]; for (int k = 0; k < 12; ++k) keepSeen[k] = g_boss.seen[k];
    const float lh = g_boss.lastHealth, lm = g_boss.lastMax, ld = g_boss.lastDistM, la = g_boss.lastAng; char ln[24]; lstrcpyA(ln, g_boss.lastName);
    memset(&g_boss, 0, sizeof(g_boss)); g_boss.logged = keepLog; g_boss.nSeen = keepN; for (int k = 0; k < 12; ++k) g_boss.seen[k] = keepSeen[k];
    g_boss.lastHealth = lh; g_boss.lastMax = lm; g_boss.lastDistM = ld; g_boss.lastAng = la; lstrcpyA(g_boss.lastName, ln); }
  log_line("BARS frame=%d on=%d scans=%ld enemiesSeenTotal=%ld mostAtOnce=%d barsShown=%ld dead/hidden=%ld behind=%ld beyond45m=%ld noWorld=%ld centreWorld=%ld centreOffset=%ld lastCentreOffsetFt=%.1f last: class=%s health=%.0f%% dist=%.1f m radius=%.1f ft | 1.7.2 actor list: %ld long now, %ld longest, hit the %d limit %ld times, longer than the old 700 in %ld scans | walk %ld us on average, %ld us at most, thinned out %ld times",
           (int)frame, (int)g_ctl.hbar, g_bs.scans, g_bs.enemies, g_bs.maxSeen, g_bs.shown, g_bs.dead, g_bs.behind, g_bs.fartherThanRange, g_bs.noWorld, g_bs.centerWorld, g_bs.centerLocal,
           (double)g_bs.lastCenterOff, g_bs.scans ? kEnemies[g_bs.lastCls >= 0 ? g_bs.lastCls : 0].name : "-", (double)g_bs.lastFrac * 100.0, (double)g_bs.lastDistM, (double)g_bs.lastRadFt,
           g_bs.listLast, g_bs.listMax, kMaxActors, g_bs.capHits, g_bs.listOver700, g_bs.scans ? g_bs.scanUsSum / g_bs.scans : 0L, g_bs.scanUsMax, g_bs.slowSkips);
  log_line("SLAMMASK frame=%d samples=%ld | a ghost is the lock target in %ld, capture bit down in %ld (with a locked ghost %ld), meter above 0 in %ld (with a locked ghost %ld) | the 0.8 s after the probe's slam presses: %ld samples, capture bit %ld, fire bit %ld, BOTH %ld, locked ghost %ld (the game slams only on both + a full meter)",
           (int)frame, g_sm.samples, g_sm.lockEnemy, g_sm.capture, g_sm.captureAndLock, g_sm.gaugeUp, g_sm.gaugeUpAndLock, g_sm.windowSamples, g_sm.winCapture, g_sm.winFire, g_sm.winBoth, g_sm.winLock);
  log_line("SLAM frame=%d samples=%ld gauge=%.2f of %.2f ready=%d active=%d actionMask=%08x meterFullEdges=%ld slamStarts=%ld firePresses=%ld", (int)frame, g_sl.samples, (double)g_sl.gauge, (double)g_sl.thr,
           (int)g_sl.ready, g_sl.active, g_sl.mask, g_sl.readyEdges, g_sl.activeEdges, g_sl.fireEdges);
  {   // 1.7.2 the lock guard, the wrangled target and the slams the left trigger started
    char b2[700]; int n2 = 0;
    for (int i = 0; i < g_lg.kinds && n2 < 560; ++i) n2 += wsprintfA(b2 + n2, " [%s: %ld]", g_lg.k[i].name, g_lg.k[i].n);
    b2[n2] = 0;
    log_line("LOCKGUARD frame=%d lock_ghost_only=%d asks=%ld | HUD pointer (player+0xB550, left alone since 1.7.27): null %ld, present %ld, other %ld, wiped %ld | ring focus (player+0x2E8): none %ld, ghost %ld, other thing %ld (let go %ld) | kept for a grab (capture button down) %ld, golem parts left alone %ld | unreadable %ld | capture-held (player+0x24D80): none %ld, ghost %ld, other thing %ld | what the lock sat on:%s",
             (int)frame, (int)g_ctl.lockGhostOnly, g_lg.calls, g_lg.none[0], g_lg.enemy[0], g_lg.other[0], g_lg.cleared[0], g_lg.none[1], g_lg.enemy[1], g_lg.other[1], g_lg.cleared[1], g_lg.keptForGrab, g_lg.golemKept, g_lg.unreadable, g_lg.none[2], g_lg.enemy[2], g_lg.other[2], n2 ? b2 : " nothing but ghosts");
    log_line("WRANGLEFIELD frame=%d the capture stream's held target (player+0x24D80) was a real object in %ld of %ld samples (%s) | holds now: %s | slams started by the left trigger: %ld (ghost held at the press: yes %ld, NO %ld) -> game slam hit landed %ld, meter used but no hit %ld, nothing happened %ld | game slam hits %ld (no damage %ld), last strength %.1f | 1.7.39: updates where a boss part was counted as held %ld",
             (int)frame, g_sl.wrSeen, g_sl.wrSamples, g_sl.wrSeen ? "field works" : "field never used: not trusted", g_sl.wrPtr ? g_sl.wrName : "nothing", g_sq.started, g_sq.heldAtPress, g_sq.notHeldAtPress, g_sq.landed, g_sq.usedNoHit, g_sq.nothing, g_hitlog.hits[1], g_hitlog.slamHitsNoDamage, (double)g_hitlog.slamStrength, g_sl.golemHeld);
  }
  log_line("PKEPROX frame=%d on=%d | proximity buzz pulses=%ld, nearest unscanned thing now %.1f ft (-1 = none within reach), closest it has been %.1f ft | PKE sources within 120 ft: %ld seen in total", (int)frame, (int)g_ctl.pkeProxBuzz, g_mk.pings, g_mk.proxNearFt, g_mk.proxMinFt, g_psrcSt.found);
  log_line("MARKERS frame=%d on=%d size=%d%% always=%d scans=%ld | scan reveals=%ld, ping ticks=%ld, hidden until scanned=%ld | collectibles considered=%ld (already collected %ld, trophy id unreadable %ld), PKE scan targets considered=%ld (only counted with the PKE out) | markers published=%ld, most at once=%ld (the drawing counters are in the HANDS line: MARKDRAW)",
           (int)frame, (int)g_ctl.collectMarkers, (int)g_ctl.collectMarkerPct, (int)g_ctl.collectMarkerAlways, g_mk.scans, g_mk.reveals, g_mk.pings, g_mk.hidden, g_mk.trinkets, g_mk.pickedUp, g_mk.noId, g_mk.pkeSrc, g_mk.published, g_mk.maxShown);
  log_line("TRINKETSUM frame=%d collectibles (CTrinket) in the world list now/ever seen %ld, within 60 ft %ld, nearest %.1f ft (TRINKET lines: where they are and whether the game draws them)", (int)frame, g_trn.seen, g_trn.closeSeen, (double)g_trn.nearestFt);
  log_line("HITS capture stream: %ld hits, total health taken %.1f | slam: %ld hits, total health taken %.1f (a slam hit with a ghost left at about 1 health is the game's own floor: ghosts are weakened, not killed)",
           g_hitlog.hits[0], g_hitlog.damage[0], g_hitlog.hits[1], g_hitlog.damage[1]);
  log_line("BARCOLOUR frame=%d the bar colour is a 5-stop green-lime-yellow-orange-red ramp and the drawn health eases toward the real one (about 0.2 s): bar updates %ld, of them still sliding by more than 2 %% %ld", (int)frame, g_bs.eased, g_bs.easing);
  log_line("BARTRAP frame=%d bars hidden because the ghost is in or at the trap (1.7.25): %ld checks", (int)frame, s_trapHidden);
  log_line("BARSMART frame=%d on=%d | the drawn-test on ghosts surely in view (just hit / in the stream): passed %ld, failed %ld -> %s | all checks: drawn %ld, not drawn %ld, untrusted checks %ld | ghosts first seen %ld, forgotten (gone 2 s) %ld, bar held back because not seen yet (checks) %ld | trapped latch: set %ld, released %ld, bar hidden because trapped (checks) %ld, hidden at a trap on the floor within 2 ft %ld",
           (int)frame, (int)g_ctl.hbarSmart, g_smart.calPass, g_smart.calFail, barlogic::trust_drawn(g_smart.calPass, g_smart.calFail) ? "trusted" : "NOT trusted: the old rule is used", g_smart.drawnYes, g_smart.drawnNo, g_smart.untrustedChecks, g_smart.firstSeen, g_smart.forgotten,
           g_smart.unseenHidden, g_smart.latched, g_smart.unlatched, g_smart.trappedHidden, g_smart.floorTrapHidden);
  log_line("BARLIFE frame=%d hook=%d deathStateVerified=%d confirmed catches=%ld hiddenCaught=%ld hiddenDead=%ld (actor census once per eye pair)", (int)frame, g_lifeSt.installed, g_lifeSt.deadState, g_lifeSt.events, g_lifeSt.hiddenCaught, g_lifeSt.hiddenDead);
  log_line("BARGONE frame=%d the \"gone\" rule (1.7.31: seen, in front, clear line, not drawn for 1 s -> no bar): ghosts set gone %ld, drawn again %ld, bar hidden because gone (checks) %ld | in view with a clear line: drawn %ld, not drawn %ld -> rule %s | game line-of-sight calls %ld (clear %ld, blocked %ld) | trapped latch set while locked on and holding capture %ld of %ld | TRAPWATCH lines %ld",
           (int)frame, g_smart.goneSet, g_smart.goneCleared, g_smart.goneHidden, g_smart.inViewDrawn, g_smart.inViewNot, barlogic::vanish_trusted(g_smart.inViewDrawn, g_smart.inViewNot) ? "usable" : "OFF (the drawn test does not match what is in view)", g_smart.vlosCalls, g_smart.vlosClear, g_smart.vlosBlocked, g_smart.heldLatched, g_smart.latched, g_smart.watchLogged);
  log_line("BARVIS frame=%d gate=%d | 1.7.19 bars only for ghosts that are really there: asked %ld times, shown because active %ld (just hit / in the capture stream %ld; 1.7.113 the game drew it this moment although its can-lock test said no: %ld), NOT SPAWNED (hidden in the game's list) %ld | wall test: bars hidden behind a wall (blocked for 0.3 s) %ld",
           (int)frame, (int)g_ctl.hbarGate, g_gate.activeAsks, g_gate.activeYes, g_gate.activeHit, g_gate.activeDrawn, g_gate.notSpawned, g_gate.wallHidden);
  log_line("BARGATE frame=%d gate=%d drawnRecentlyTest(pass/fail/unreadable)=%ld/%ld/%d used=%d lineOfSight(calls/clear/blocked)=%ld/%ld/%ld hiddenBars(spawned-but-not-drawn or behind a wall)=%ld barsPassed=%ld",
           (int)frame, (int)g_ctl.hbarGate, g_gate.visPass, g_gate.visFail, g_gate.visBad, g_gate.visGateOk, g_gate.losCalls, g_gate.losClear, g_gate.losBlocked, g_gate.spawnedHidden, g_gate.shownGate);
  log_line("WHEELCMD frame=%d readyItemCalls=%d returnedTrue=%d returnedFalse=%d skippedMenuOpen=%d lastItem=%d lastReturn=%d inventoryChanges=%d ownedItems=%d inHand=%d trapThrowsTracked=%ld", (int)frame, g_cmd.calls, g_cmd.okReturns, g_cmd.failReturns,
           g_cmd.skippedMenu, g_cmd.lastItem, g_cmd.lastRet, g_inv.changes, g_inv.owned, g_inv.cur, g_trapT.throws);
  {
    char b[640]; int n = 0;
    for (int i = 0; i < sw::kBits && n < 560; ++i) if (g_sw.bitFrames[i]) n += wsprintfA(b + n, "%s%s=%ld", n ? " " : "", sw::kNames[i], g_sw.bitFrames[i]);
    if (!n) lstrcpyA(b, "none");
    log_line("SWITCHSUM frame=%d help=%d samples=%ld pendingEpisodes=%ld longestPendingMs=%ld finishCalls=%ld (of those on the 3 s timer %ld) wheelHelps=%ld queuedLikeY=%ld skipped=%ld gateLines=%ld noteLines=%ld | samples with each check set: %s",
             (int)frame, (int)g_ctl.switchHelp, g_sw.samples, g_sw.pendEpisodes, g_sw.maxPendMs, g_sw.fixes, g_sw.autoFixes, g_sw.helps, g_sw.queued, g_sw.queueSkipped, g_sw.logged, g_sw.noteLogged, b);
  }
  log_line("PKESRC frame=%d assist=%ddeg/%d%% scans=%ld sourcesSeenTotal=%ld mostAtOnce=%ld distinct=%d noWorld=%ld (scannable PKE sources near you while the PKE is in hand) | 1.7.29 the aim help only follows what can be scanned now: used sources %ld, collectibles %ld, left out because not active yet %ld, because already scanned %ld",
           (int)frame, (int)g_ctl.pkeAssistDeg, (int)g_ctl.pkeAssistPct, g_psrcSt.scans, g_psrcSt.found, g_psrcSt.maxFound, g_psrcSt.nSeen, g_psrcSt.noWorld, g_psrcSt.sourcesUsed, g_psrcSt.trinketsUsed, g_psrcSt.skipDormant, g_psrcSt.skipScanned);
  log_line("HOSEEND frame=%d rawAsks=%ld posed=%ld rejectedFar=%ld noRaw=%ld lastAskerIsPlayerWand(dist ft)=%.2f max=%.2f", (int)frame, g_hs.rawN, g_hs.posedN, g_hs.rejectedFar, g_hs.noRaw, (double)g_hs.lastOffFt, (double)g_hs.maxOffFt);
}

#endif

// 1.4: milliseconds since a ghost in the bar list last lost health (-1 = none yet / long ago); the gun's buzz feels hits with it
int fight_hit_age_ms() {
  const int64_t q = g_lastHitQ;
  if (!q) return -1;
  const int64_t d = qpc_now() - q;
  if (d < 0) return 0;
  const double ms = (double)d * 1000.0 / (double)qpc_freq();
  return ms > 5000.0 ? -1 : (int)ms;
}
