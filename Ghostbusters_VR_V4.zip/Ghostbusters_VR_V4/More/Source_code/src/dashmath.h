// 1.7.22 Blink dash (pure math; tested in tests/test_dash.cpp).
//
// Double-tap the left stick (push hard, let go, push hard again within half a second) and the player gets a short burst of speed in the direction he is walking (about 3 m in 0.3 s),
// while the comfort vignette pulses. It is NOT a teleport: the game's own walking does the moving (so walls still stop you); the probe only adds extra steps, with the same
// "nudge" way as the sprint boost (boostmath.h). Off by default (blink_dash = 0).
//
// Anti-misfire rules: the first push must be a quick tap (a held stick is just walking), the stick must really come back to the middle in between (continuous walking never
// triggers it), and a cooldown of 1.2 s follows every dash.
#pragma once

namespace dash {

struct Cfg { double hi, lo, tapMaxSec, windowSec, cooldownSec, durSec, K, capFt; };
inline Cfg make_cfg() { Cfg c; c.hi = 0.85; c.lo = 0.30; c.tapMaxSec = 0.40; c.windowSec = 0.50; c.cooldownSec = 1.2; c.durSec = 0.30; c.K = 4.0; c.capFt = 0.6; return c; }

struct State {
  int phase;          // 0 waiting for the first push, 1 first push held, 2 released (waiting for the second), 3 hold off until the stick is back in the middle
  double held, timer, cool, left;   // seconds: first push held so far, since release, cooldown left, dash time left
  long triggers, blockedByCooldown, hardHolds, windowMisses, taps;
};
inline void reset(State& s) { s.phase = 0; s.held = s.timer = s.cool = s.left = 0.0; s.triggers = s.blockedByCooldown = s.hardHolds = s.windowMisses = s.taps = 0; }

inline double smooth(double x) { x = x < 0.0 ? 0.0 : (x > 1.0 ? 1.0 : x); return x * x * (3.0 - 2.0 * x); }

// The speed multiplier for the burst: quick rise, flat, softer fall. left/dur = how much of the dash is still to come.
inline double multiplier(const Cfg& c, double left) {
  if (!(left > 0.0) || !(c.durSec > 0.0)) return 1.0;
  double p = 1.0 - left / c.durSec;
  if (p < 0.0) p = 0.0;
  if (p > 1.0) p = 1.0;
  const double shape = p < 0.15 ? smooth(p / 0.15) : (p < 0.65 ? 1.0 : 1.0 - smooth((p - 0.65) / 0.35));
  return 1.0 + (c.K - 1.0) * shape;
}

// One game tick. mag = left-stick push 0..1, dt seconds, enabled = the setting is on and the game is in a state where a dash makes sense.
// Returns the multiplier to apply now (1 = no dash). *started is set to 1 on the tick a dash begins.
inline double feed(State& s, const Cfg& c, double mag, double dt, int enabled, int* started) {
  if (started) *started = 0;
  if (!(dt > 0.0) || dt > 0.25) dt = 0.0;
  if (s.cool > 0.0) { s.cool -= dt; if (s.cool < 0.0) s.cool = 0.0; }
  if (s.left > 0.0) { s.left -= dt; if (s.left < 0.0) s.left = 0.0; }
  if (!enabled) { s.phase = 0; s.left = 0.0; return 1.0; }
  switch (s.phase) {
    case 0:
      if (mag >= c.hi) { s.phase = 1; s.held = 0.0; }
      break;
    case 1:
      s.held += dt;
      if (mag <= c.lo) { s.phase = 2; s.timer = 0.0; ++s.taps; }
      else if (s.held > c.tapMaxSec) { s.phase = 3; ++s.hardHolds; }
      break;
    case 2:
      s.timer += dt;
      if (mag >= c.hi) {
        if (s.cool <= 0.0) { s.left = c.durSec; s.cool = c.cooldownSec; ++s.triggers; if (started) *started = 1; }
        else ++s.blockedByCooldown;
        s.phase = 3;
      } else if (s.timer > c.windowSec) { s.phase = 0; ++s.windowMisses; }
      break;
    default:
      if (mag <= c.lo) s.phase = 0;
      break;
  }
  return multiplier(c, s.left);
}

}  // namespace dash
