// 1.7.98 the game's OWN draw animation, shown on the VR hand (view only). Pure math (tests/test_drawanim.cpp).
//
// When the equipped item changes (a weapon switch, the PKE coming out, the gun drawn after a cut-scene) the game plays its own draw animation: the gun / meter
// travels from where it was stowed (the back, the belt) to the hand while the fingers close. The mod keeps the hand on your controller, so what is left to show
// of the game's animation is that travel RELATIVE TO THE HAND: the gun comes in from the back to your hand, the game's own fingers close on it.
// Until 1.7.97 a relation farther than 25-30 cm from the hand was thrown away (it is not the hold) and the gun simply appeared in the hand.
//
// A Window opens at the switch and stays open until the game's relation has arrived at the hold (or kWindowS passed). While it is open and the relation is
// still far from the hold, the caller places the prop through the game's live relation instead of the stored hold. The stored hold, the aim, the trigger and the beam
// direction are never touched, so this changes only how the first fraction of a second looks. When the relation arrives, a small leftover position offset fades out.
#pragma once
#include "vmath.h"

namespace drawanim {

static const double kWindowS = 1.5;    // the longest a window stays open after a switch
static const double kCapFt = 3.3;      // a relation longer than this (about 100 cm) is never drawn: it is a stowed / streamed / cut-scene pose, not a draw
static const double kNearFt = 0.10;    // within about 3 cm of the hold = the animation has arrived
static const double kCalmS = 0.06;     // arrived for this long closes the window
static const double kFadeS = 0.08;     // a leftover position offset (the last drawn spot against the hold) fades out in this time

struct Window {
  int open;
  int slot;
  double startS, nearSinceS, lastShownS, endS;
  long shown, frames;
  double maxLenFt;
  int closedBy;   // 1 arrived, 2 time ran out, 3 another item
  int endLogged;  // the caller wrote its closing log line
};

inline void reset(Window* w) {
  if (!w) return;
  w->open = 0; w->slot = -9; w->startS = w->nearSinceS = w->lastShownS = w->endS = 0.0;
  w->shown = w->frames = 0; w->maxLenFt = 0.0; w->closedBy = 0; w->endLogged = 0;
}

// items that are drawn through the wand slot with a hand-held model: proton 1, meson 2, boson 3, light 6, slime 7 (4 = trap and 5 = PKE have their own paths, 0 = nothing)
inline int is_gun_item(int slot) { return slot == 1 || slot == 2 || slot == 3 || slot == 6 || slot == 7; }

inline void begin(Window* w, int slot, double nowS) {
  if (!w) return;
  reset(w);
  w->open = 1; w->slot = slot; w->startS = nowS; w->nearSinceS = -1.0;
}

// One look at the game's live relation. Returns 1 = draw the prop through the live relation now, 0 = use the normal hold.
//   liveLenFt  length of the game's live prop-in-hand relation (feet)
//   haveHold   a stored / locked hold exists
//   distFt     distance of the live relation from that hold (feet; used when haveHold)
//   holdMaxFt  how far from the hand the normal path still follows the live relation by itself (the gun 1.0 ft, the meter 0.82 ft)
inline int step(Window* w, int slot, double nowS, double liveLenFt, int haveHold, double distFt, double holdMaxFt) {
  if (!w || !w->open) return 0;
  if (slot != w->slot) { w->open = 0; w->endS = nowS; w->closedBy = 3; return 0; }
  if (nowS - w->startS > kWindowS) { w->open = 0; w->endS = nowS; w->closedBy = 2; return 0; }
  if (!vm::is_finite_f((float)liveLenFt) || !vm::is_finite_f((float)distFt)) return 0;
  ++w->frames;
  const int arrived = haveHold ? (distFt <= kNearFt) : (liveLenFt <= holdMaxFt);
  if (arrived) {
    if (w->nearSinceS < 0.0) w->nearSinceS = nowS;
    if (nowS - w->nearSinceS >= kCalmS) { w->open = 0; w->endS = nowS; w->closedBy = 1; }
    return 0;
  }
  w->nearSinceS = -1.0;
  if (liveLenFt > kCapFt) return 0;
  ++w->shown; w->lastShownS = nowS;
  if (liveLenFt > w->maxLenFt) w->maxLenFt = liveLenFt;
  return 1;
}

// Fade factor (1 -> 0) of the leftover offset `sinceS` seconds after the animation stopped being drawn.
inline double fade(double sinceS) {
  if (!(sinceS >= 0.0)) return 1.0;
  const double k = 1.0 - sinceS / kFadeS;
  return k < 0.0 ? 0.0 : k > 1.0 ? 1.0 : k;
}

}  // namespace drawanim
