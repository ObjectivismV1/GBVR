// Early engine camera path (reconstruction of probe 0.16, extended since).
//
// Flow on the game's camera thread (verified in ghost.exe):
//   camera render (0x450DD0)
//     -> Prepare(camera, ctx)            0x455010  [hooked: gates + arm]
//          -> SetProjection(zoom, mode)   0x302520  [hooked: stereo field of view, 0.21]
//          -> SetEye(camera+0x08)         0x3021C0  [hooked: first-person eye 0.19, stereo eye 0.21]
//          -> SetNearFar(near, far)       0x300EB0  [hooked: first-person near plane, 0.20]
//          -> SetOrientationFromEuler     0x3019B0
//               -> SetCameraBasis(m[9])   0x3019F0  [hooked: M' = M * R; stereo: level yaw * head]
//          -> snapshot prepared view into ctx+0x6A3C8 (uses the new eye + basis)
//     -> VisibilityStage(camera, ctx)    0x450740  [hooked: audit + arm query]
//          -> MainSpatial(view, cam+0x6C) 0x42C620  [hooked: same eye for culling, 0.19]
//
// The camera's own fields (eye, Euler angles, pivot, distance) are never
// written. Only the temporary values passed to the engine's normal setters
// are replaced, inside a verified active-camera call chain, so visibility and
// culling use the same view that is rendered. No shader buffers are touched.
#include "gunbarmath.h"
#include "knockmath.h"
#include "packmath.h"
#include "forcedmath.h"
#include "cinemath.h"
#include "gungatemath.h"   // 1.7.156: the knock grace the game-in-charge guard shares with the gun gate
#include "cutholdmath.h"   // 1.7.151
#include "assistmath.h"
#include "gbvr.h"
#include "sceneviewmath.h"
#include "armmath.h"
#include "padmath.h"
#include "bindingmath.h"
#include "capturemath.h"
#include "layout.h"
#include "safetymath.h"
#include "vmath.h"
#include "stereomath.h"
#include "chestmath.h"
#include "aimmath.h"
#include "handmath.h"
#include "tipmath.h"
#include "wandmath.h"
#include "autopausemath.h"
#include "bodymath.h"
#include "solidmath.h"
#include "pkemath.h"
#include "handprop.h"
#include "drawanimmath.h"   // 1.7.98
#include "pkeeasymath.h"
#include "followmath.h"
#include "boostmath.h"
#include "dashmath.h"
#include "hapticmath.h"
#include "MinHook.h"
#include "memcache.h"
#include "stairsmath.h"   // 1.7.71
#include "pkedrawmath.h"  // 1.7.71
#include "foregripmath.h"   // 1.7.104
#include "foregrabmath.h"   // 1.7.105
#include "pkerelmath.h"   // 1.7.172
#include "gunshift.h"   // 1.7.193
static int memory_readable(const void* p, size_t n);

// The shipped game's CCharacter::isPlayingBigHurtAni() at RVA 0x7D1B0
// checks the live animation. The known knockBack and fall-consumer routes are
// intercepted BEFORE playback and replaced by the timed VR comfort envelope.
// This predicate is only a safety detector for an unknown route: if one slips
// through, hide the falling avatar and start the same replacement effects.
// Refuse to use the address if the executable differs from the inspected one.
static volatile LONG g_knockActive;
static volatile LONG64 g_knockQ;
static LONG g_knockEvents, g_knockFrames;
static void knock_begin(const char* source);
static int knock_guard_actor(uintptr_t actor);
static int knock_comfort_on(uintptr_t player);   // 1.7.93
int knockdown_active() {
#if GBVR_HEADTRACK
  return g_knockActive && qpc_now() - g_knockQ < qpc_freq() / 5;
#else
  return 0;
#endif
}
static void knockdown_update(void* actor) {
#if GBVR_HEADTRACK
  static int verified;
  if (!verified) {
    const uint8_t* code = (const uint8_t*)rva(0x7D1B0);
    static const uint8_t expected[] = {0x48,0x83,0xec,0x28,0x80,0xb9,0x68,0x24,0x00,0x00,0x00};
    verified = g_game.identityOK && memory_readable(code, sizeof(expected)) ? 1 : -1;
    if (verified > 0) for (unsigned i = 0; i < sizeof(expected); ++i) if (code[i] != expected[i]) { verified = -1; break; }
    log_line("KNOCKDOWN animation check %s (game RVA 0x7D1B0)", verified > 0 ? "available" : "not available for this executable");
  }
  int active = 0;
  if (verified > 0 && actor && memory_readable((uint8_t*)actor + 0xB604, 4) && memory_readable((uint8_t*)actor + 0x2468, 1)) {
    typedef uint8_t(__fastcall* PFN_BigHurt)(void*);
    active = ((PFN_BigHurt)rva(0x7D1B0))(actor) != 0;
  }
  const int was = g_knockActive;
  InterlockedExchange(&g_knockActive, active);
  InterlockedExchange64(&g_knockQ, qpc_now());
  if (active) {
    ++g_knockFrames;
    if (knock_comfort_on((uintptr_t)actor)) knock_guard_actor((uintptr_t)actor);
  }
  if (active && !was) {
    ++g_knockEvents;
    if (knock_comfort_on((uintptr_t)actor)) knock_begin("verified big-hurt animation fallback");
    const int32_t slot = memory_readable((uint8_t*)actor + 0xB600, 8) ? *(const int32_t*)((uint8_t*)actor + 0xB600) : -2;
    const int32_t second = memory_readable((uint8_t*)actor + 0xB604, 4) ? *(const int32_t*)((uint8_t*)actor + 0xB604) : -2;
    const int flag = memory_readable((uint8_t*)actor + layout::kOffKnockFlag, 1) ? *((const uint8_t*)actor + layout::kOffKnockFlag) : -1;
    log_line("KNOCKDOWN big-hurt animation detected #%ld; slot=%d second=%d flag=%d (first-person avatar hidden)", g_knockEvents, slot, second, flag);
  }
  if (!active && was) log_line("KNOCKDOWN big-hurt animation ended #%ld (%ld sampled frames)", g_knockEvents, g_knockFrames);
#else
  (void)actor;
#endif
}

typedef void(__fastcall* PFN_Prepare)(void* camera, void* ctx);
typedef void(__fastcall* PFN_Basis)(const float* m);
typedef void(__fastcall* PFN_Visibility)(void* camera, void* ctx);
typedef void(__fastcall* PFN_SetEye)(const float* eye);
typedef void(__fastcall* PFN_MainSpatial)(void* view, const float* eye);
typedef void(__fastcall* PFN_SetNearFar)(float zNear, float zFar);
typedef void(__fastcall* PFN_SetProjection)(float zoom, int mode);
typedef void(__fastcall* PFN_SetScales)(float scaleX, float scaleY);
typedef void(__fastcall* PFN_AppTick)(void* app, float fps);
typedef void(__fastcall* PFN_AppSimulate)(void* app);

static PFN_Prepare o_prepare;
static PFN_Basis o_basis;
static PFN_Visibility o_visibility;
static PFN_SetEye o_setEye;
static PFN_MainSpatial o_mainSpatial;
static PFN_SetNearFar o_setNearFar;
static PFN_SetProjection o_setProjection;
static PFN_AppTick o_appTick;
static PFN_AppSimulate o_appSimulate;

// ---- Per-prepare state (owned by one thread at a time) ---------------------
static volatile LONG g_ownerTid;     // thread inside an armed prepare, or 0
static int g_armRotValid;            // rotate the basis this prepare
static float g_armRot[9];            // camera-local rotation to apply
static double g_armDegrees;          // manual mode degrees (math check)
static LONG g_armMode;
static int g_armSample;              // log details for this prepare
static int g_armApplied;
static float g_armOriginal[9], g_armOut[9];
static int g_armEyeValid;            // replace the eye this prepare
static float g_armEye[3];
static int g_armEyeApplied;
static int g_armNearValid;           // first-person near plane wanted this prepare
static int g_armNearApplied;

// 0.21 stereo: everything for one eye's frame is decided before the engine's
// prepare runs, then handed to the engine through its own setters.
struct ArmStereo {
  int valid;
  int eye;                 // 0 left, 1 right
  double yaw;              // camera yaw the level basis was built from
  float level[9];          // yaw-only basis (horizon always level in the headset)
  float view[9];           // level * head rotation = basis the engine receives
  float pose34[12];        // headset pose for the compositor
  double needH, needV;     // half-FOV tangents that cover both eyes
  int fovApplied;
  int wide;                // 0.24: separate horizontal / vertical field of view
  int reused;              // 0.24: second eye of a pair, camera state taken from the first
  int64_t pairQ;           // unique first-eye QPC stamp, shared with the second eye
  int pairRole;            // 0.27: 1 = first eye of a pair, 2 = second eye, 0 = not in pair mode
  float zoomIn, zoomOut, tanH0, tanV0, tanH, tanV, tanVTarget;
  float eyeWorld[3];       // completed eye position, for render-pass diagnostics
  float headCenter[3];     // 0.34: head centre in game world (feet), without the eye offset
  double headHeading; int headHeadingOk;   // 1.7.220: the head's heading in the game world before the roof's downward turn
  double feetPerMetre;     // 0.34: game feet per real metre in this view (world size setting)
  int spec;                // 1.7.38: this frame is the chest-camera picture for the PC window (not an eye picture)
};
static ArmStereo g_armStereo;
static SRWLOCK g_drawStereoLock = SRWLOCK_INIT;
static ArmStereo g_drawStereo;
static int64_t g_drawStereoQ;
static int draw_stereo(ArmStereo* out) {
  AcquireSRWLockShared(&g_drawStereoLock);
  *out = g_drawStereo;
  const int64_t q = g_drawStereoQ;
  ReleaseSRWLockShared(&g_drawStereoLock);
  const int64_t age = qpc_now() - q;
  return out->valid && q && age >= 0 && age < qpc_freq() / 10;
}

// 0.24 eye pairs: the two eyes are rendered in two consecutive game frames a
// few milliseconds apart. The first frame of a pair records the camera state
// it used; the second frame reuses it, so both eyes look from the same place
// in the same direction with the same head pose even if the player moved or
// turned in between.
#if GBVR_HEADTRACK
struct PairState {
  int valid;
  int64_t qpc;
  double yaw;
  float baseEye[3];
  GbvrPose pose;
};
static PairState g_pair;
#endif

// Last completed prepare, for the visibility-stage pairing.
static DWORD g_lastTid;
static void* g_lastCamera;
static int g_lastModified;
static float g_lastOut[9];
static int g_lastEyeApplied;
// 0.98 BODYEYE: per eye (0 left, 1 right), what happened to the PLAYER's own parts (body, pack, extra body pass). "near a wall the body is gone in the right eye" (0.97):
// the log must tell whether the game even asks for the part in that eye, draws it, or refuses it. The eye is that of the frame being prepared / drawn.
static struct {
  volatile LONG eye;                                // eye of the frame being prepared and then drawn (0 left, 1 right)
  volatile LONG asked[2], drawn[2], refused[2], markHidden[2], pkeShown[2];   // mirror-only asks (prepare), the game's predicate answers (render job), the probe's own hide mark, parts shown despite the PKE view
  void* actor;                                      // the player's CGhostbuster of the last main render (kept for the render job that follows)
} g_be;
static float g_lastEye[3];

// Visibility-stage window in which the main spatial query gets our eye.
static volatile LONG g_visEyeTid;
static float g_visEye[3];
static int g_visEyeApplied;

struct Stats {
  volatile LONG prepareCalls, verifiedPrepares, otherCallerPrepares;
  volatile LONG basisCalls, basisMatched, modifiedCalls, armedWithoutBasis, invalidBasis;
  volatile LONG applyVerifyOK, applyVerifyFail;
  volatile LONG visibilityCalls, visibilityPaired, visibilityBasisMatch, visibilityBasisDiffer;
  volatile LONG mathChecks;
  volatile LONG eyeArmed, eyeApplied, eyeVerifyOK, eyeArmedNoCall, spatialApplied, spatialVerifyOK, fpGateFails;
  volatile LONG nearApplied, suspendedFrames;
  volatile LONG stereoSpec;   // 1.7.38: chest-camera pictures prepared
  volatile LONG stereoArmed, stereoFrames, stereoIncomplete, stereoPostVerifyFail, fovApplied, fovVerifyOK;
  volatile LONG stereoYawAgree, stereoYawDiffer, stereoOverlap;
  volatile LONG pairFirst, pairReused, pairNoState, tickCalls, tickLifted, wideApplied;
  // 0.27 same moment
  volatile LONG tickAfterFirst, tickAfterSecond;               // ticks that followed a published first / second eye
  volatile LONG sameMoment, sameMomentOK, sameMomentSkipped, sameMomentZero;
  volatile LONG simSkipped, simSkipExpired, drainBeforeSim, simKeptForInput;
  volatile LONG menuTickBad;
  volatile LONG pairTickUncapped, tickCapSet, tickGapOver50;                // 0.58: pair-mode ticks that would have waited for the menu cap of 30 FPS; ticks that started with the cap byte set; gaps over 50 ms
  double tickGapSumMs, tickGapMaxMs; LONG tickGapN;
  volatile LONG menuTickLifted;                                // 0.43: ticks that ran at the loop's 120 instead of the menu cap of 30
  volatile LONG shortTicksLast, longTicksLast;                 // game ticks (1/65536 s) the last short / normal pair tick produced
  volatile LONG stepSamples[2];                                // per eye role: prepares sampled
  double stepSumMs[2];                                         // ... and the game's time step in force at that prepare
  volatile LONG stereoEye[2];
};
static Stats g_st;
static double g_worstMathError, g_worstApplyError;
static volatile LONG g_sampleRequest;   // render thread asks camera thread for one detailed sample
static volatile LONG g_samplesTaken;

static inline int readable_floats_ok(const float* p, int n) {
  for (int i = 0; i < n; ++i) if (!vm::is_finite_f(p[i])) return 0;
  return 1;
}

static float g_timeScaleSeen = 1.0f;  // 0.27: the game's time scale measured on the last normal pair tick
static long g_roofNotShort;      // ROOFEYE (log only): short same-moment ticks refused while in the roof fight
static volatile LONG g_tickRole;      // 0.27: eye role of the frame just prepared and published (1 first, 2 second)
static int g_skipSim;                 // 0.27: the next App::Simulate is left out (second eye = same game moment)
static int g_prevTickShort;
static int g_drainBeforeSim;          // 0.27: finish drawing the second eye before the world moves on
static void* g_appSeen;               // App object, from the tick hook

static double max_abs_diff(const float* a, const float* b, int n) {
  double w = 0;
  for (int i = 0; i < n; ++i) { double d = vm::dabs((double)a[i] - b[i]); if (d > w) w = d; }
  return w;
}

// Committed, readable, not a guard page, and [p, p+n) inside one region.
static int memory_readable(const void* p, size_t n);
// 0.52: the same without the 4-byte alignment rule (single bytes, strings)
static int memory_readable_any(const void* p, size_t n) { return memcache::readable(p, n, 0, 0); }
static int memory_readable(const void* p, size_t n) { return memcache::readable(p, n, 0, 1); }

static void log_floats(const char* tag, const float* f, int n) {
  char buf[640]; int len = 0;
  for (int i = 0; i < n && len < 600; ++i) len += log_fmt(buf + len, (int)sizeof(buf) - len, i ? ",%.9g" : "%.9g", (double)f[i]);
  buf[len < (int)sizeof(buf) ? len : (int)sizeof(buf) - 1] = 0;
  log_line("%s floats=%d,%s", tag, n, buf);
}

// ---- Suspend / resume (0.20) -----------------------------------------------------
// A failed gate no longer switches anything off: the frame is simply left
// unmodified and the effect resumes by itself when the gate passes again.
// Only F6 turns modes off. Transitions are logged once each.
static const char* g_suspendReason;
static void gate_suspend(const char* why) {
  InterlockedIncrement(&g_st.suspendedFrames);
  if (g_suspendReason != why) {
    g_suspendReason = why;
    log_line("SUSPENDED: %s (frame=%d)", why, (int)g_ctl.worldFrames);
  }
}
static void gate_resume() {
  if (g_suspendReason) {
    log_line("RESUMED after: %s (frame=%d)", g_suspendReason, (int)g_ctl.worldFrames);
    g_suspendReason = nullptr;
  }
}

// ---- Gate evaluation --------------------------------------------------------
struct CamCheck { int caller, active, vtable, context, fields, mode; int projMode; };

static int verify_camera(void* ret, void* cam, void* ctx, CamCheck* c) {
  c->caller = (uintptr_t)ret == rva(layout::kRvaPrepareReturn);
  void* active = *(void* volatile*)rva(layout::kRvaActiveCameraPtr);
  c->active = cam != nullptr && cam == active;
  c->vtable = c->active && *(uintptr_t*)cam == rva(layout::kRvaCameraVtable);
  c->context = ctx == (void*)rva(layout::kRvaRenderContext);
  c->fields = 0; c->mode = 0; c->projMode = -1;
  if (c->vtable) {
    const uint8_t* b = (const uint8_t*)cam;
    const float* eye = (const float*)(b + layout::kCamEye);
    const float* eul = (const float*)(b + layout::kCamEuler);
    float fov = *(const float*)(b + layout::kCamFov);
    c->fields = readable_floats_ok(eye, 3) && readable_floats_ok(eul, 3) && vm::is_finite_f(fov) && fov > 1.0f &&
                fov < 179.0f;
    c->projMode = *(const int*)(b + layout::kCamProjMode);
    c->mode = c->projMode == 0;
  }
  return c->caller && c->active && c->vtable && c->context && c->fields && c->mode;
}

// A scripted camera may be far from the player while still following the same
// CGhostbuster and pivot. Keep its world in VR; the Stay Puft encounter alone
// temporarily switches the view model to tracked arms.
static volatile LONG g_sceneArms;
static uintptr_t g_sceneActor;
static int64_t g_sceneQ;
static sceneview::Encounter g_sceneFight;
static sceneview::Station g_sceneStation;
static struct { volatile LONG n, exact, beamFree, bendN, bendSumX10, bendMaxX10; double sumBarrelAim, maxBarrelAim, sumGameAim, maxGameAim; long nb, ng; int64_t q; LONG logs; } g_stAim;
static volatile LONG g_sceneRecenter;
static volatile float g_roofHeadShiftCm;   // 1.7.218: how far the pitched roof head movement moved the eye (cm), for the ROOFAIM log

// 1.7.220 ROOF AUTO-CENTRE (logic in sceneviewmath.h AutoCenter): the roof view is placed once, with your head wherever it was ~2 s into the fight; if you then rest your head
// 12+ deg off the boss direction the ground looks turned by that much, so once per fight the view re-centres the way the recenter does. Setting roof_auto_center (1 on).
void engine_comfort_recenter();
static void roof_auto_center_step(double headHeading) {
  static sceneview::AutoCenter s_ac; static long s_logs;
  double off = 0, rate = 0, age = 0;
  const double now = (double)qpc_now() / (double)qpc_freq();
  if (s_ac.step(now, g_sceneStation.boss, g_sceneStation.yaw, headHeading, g_sceneStation.facingYaw, g_ctl.roofAutoCenter != 0, &off, &rate, &age)) {
    engine_comfort_recenter();
    if (++s_logs <= 20) log_line("ROOFAUTO the roof view re-centred itself once: your head rested %.1f deg off the boss direction (turning %.1f deg/s), %.1f s after the view was placed", off, rate, age);
  }
}
static volatile LONG g_torsoResetReq;
void engine_comfort_recenter() { InterlockedExchange(&g_sceneRecenter, 1); InterlockedExchange(&g_torsoResetReq, 1); }   // 1.7.180: the chest twist is relative to the old head yaw, so it starts again with the new front
int engine_scene_arms(uintptr_t actor) {
  return g_ctl.stereoActive && g_ctl.firstPerson && g_sceneArms && g_sceneActor &&
         (!actor || actor == g_sceneActor) && qpc_now() - g_sceneQ < qpc_freq() / 4;
}

// First-person eye (0.19): the followed actor's position + eye height, nudged
// forward along the camera heading. Validated against the pivot the game's
// own third-person camera computed this frame. Returns a failure reason or null.
#if GBVR_HEADTRACK
static uintptr_t head_aim_actor();  // last player confirmed by the VR camera path
#else
static uintptr_t head_aim_actor() { return 0; }
#endif
// 1.7.197 "remove the dead body after dying, keep the rig the same with a pulsing red edge": the player is dying when the health is about 0 (2 % or less) or the game says it is dead
// while the health is low. Held 0.6 s after it ends so it cannot flicker. Read about every 20 ms.
#if !GBVR_HEADTRACK
int engine_player_downed() { return 0; }
#else
int engine_player_downed() {
  static int64_t s_q, s_until; static int s_v; static long s_n, s_logs;
  if (!g_ctl.downVignette || !g_ctl.stereoActive || !g_ctl.firstPerson) return 0;
  const int64_t now = qpc_now();
  if (s_q && now - s_q < qpc_freq() / 50) return s_v;
  s_q = now;
  int d = 0;
  const uintptr_t pl = head_aim_actor();
  if (pl && memory_readable((const void*)(pl + 0xB860), 12)) {
    const float cur = *(const float*)(pl + 0xB860), mx = *(const float*)(pl + 0xB868);
    if (mx > 1.0f && cur == cur) { const float f = cur / mx; d = (f <= 0.02f || (f <= 0.2f && fight_actor_dead(pl))) ? 1 : 0; }
  }
  if (d) s_until = now + qpc_freq() * 6 / 10;
  const int v = (d || now < s_until) ? 1 : 0;
  if (v != s_v) { s_v = v; if (++s_logs <= 30) log_line("DOWNED %s: the body is %s, the edges %s (health about 0 or the game's death state; #%ld)", v ? "start" : "end", v ? "hidden (the arms stay)" : "drawn again", v ? "pulse red" : "normal", s_logs); }
  if (v) ++s_n;
  return v;
}
#endif
// 1.7.186 "walking over an object the guns float": the eye height is eased (the stairs ramp), the actor's own height is not. This is how far the eye is from the actor's feet height now (ft x 1000, + = eye above),
// so everything that follows the actor's raw position (the held aim, the body's eye match) can follow the EYE instead.
static volatile LONG g_eyeLagMft; static volatile LONG g_stepLagFrames, g_stepLagMaxMft, g_stepAimMoved, g_stepCapRaised;
static inline double eye_lag_ft() { return (double)g_eyeLagMft * 0.001; }
static volatile LONG g_stairLifts; static double g_stairLiftFt;   // 1.7.71: the speed boost's extra step lifted onto the stair (boost_after_sim)
static const char* compute_first_person_eye(void* cam, float* eyeOut, int sample) {
  const uint8_t* b = (const uint8_t*)cam;
  void* actor = *(void* const*)(b + layout::kCamFollowTarget);
  if (!memory_readable(actor, layout::kActorPos + 12)) return "no readable follow target";
  const float* pos = (const float*)((const uint8_t*)actor + layout::kActorPos);
  if (!readable_floats_ok(pos, 3)) return "follow target position not finite";
  float posHold[3] = {pos[0], pos[1], pos[2]};
#if GBVR_HEADTRACK
  {   // 1.7.203 "no going down, being down and getting back up": while the player is downed (and 2 s after) the eye stays at the height it had standing, as long as the player has not been moved somewhere else (a respawn)
    static float s_stand[3]; static int s_haveStand; static int64_t s_holdUntil, s_logQ; static int s_wasHold; static double s_minDrop; static long s_holdN;
    const int64_t nowQ = qpc_now();
    const int dn = g_ctl.downVignette ? engine_player_downed() : 0;
    if (dn) s_holdUntil = nowQ + qpc_freq() * 2;
    const int holding = dn || nowQ < s_holdUntil;
    if (!holding) { s_stand[0] = pos[0]; s_stand[1] = pos[1]; s_stand[2] = pos[2]; s_haveStand = 1; if (s_wasHold) { s_wasHold = 0; static LONG s_dl; if (InterlockedIncrement(&s_dl) <= 12) log_line("DOWNEYE the eye hold is over: it was applied on %ld eye reads, the actor was at most %.2f ft below its standing height", s_holdN, s_minDrop); s_holdN = 0; s_minDrop = 0.0; } }
    else if (s_haveStand) {
      const double dx = (double)pos[0] - s_stand[0], dz = (double)pos[2] - s_stand[2], dy = (double)pos[1] - s_stand[1];
      if (dx * dx + dz * dz < 9.0 && dy < -0.02 && dy > -5.0) { posHold[1] = s_stand[1]; s_wasHold = 1; ++s_holdN; if (-dy > s_minDrop) s_minDrop = -dy; }
      else s_wasHold = 1;
    }
  }
#endif
  pos = posHold;
  const float* pivot = (const float*)(b + layout::kCamPivot);
  const float* tpEye = (const float*)(b + layout::kCamEye);
  // 0.25: in the headset view the player-height setting scales the eye height.
  // (0.26: eye separation and head movement follow worldPct, see arm_stereo.)
  double size = g_ctl.stereoActive ? (double)g_ctl.sizePct / 100.0 : 1.0;
  double h = (double)g_ctl.eyeHeightCenti / 100.0 * size;
  double fwd = (double)g_ctl.eyeForwardCenti / 100.0;
  double yaw = *(const float*)(b + layout::kCamEuler + 4);
  double s, c;
  vm::dsincos(yaw, &s, &c);  // horizontal forward = (sin yaw, 0, cos yaw)
  double base[3] = {pos[0], pos[1] + h, pos[2]};
  // Sanity: the game's pivot is actor + (shoulder offset, pivot height 5.5);
  // it must be close to the actor's head, and the third-person eye must be
  // near. Checked against the nominal head point so that the player's own
  // height / size tuning cannot trip it.
  double ref[3] = {pos[0], pos[1] + 5.5, pos[2]};
  double dp = 0, de = 0;
  for (int i = 0; i < 3; ++i) {
    dp += (pivot[i] - ref[i]) * (pivot[i] - ref[i]);
    de += (tpEye[i] - ref[i]) * (tpEye[i] - ref[i]);
  }
  dp = vm::dsqrt(dp); de = vm::dsqrt(de);
  if (sample)
    log_line("FPEYE frame=%d actor=%p actorPos=%.3f,%.3f,%.3f pivot=%.3f,%.3f,%.3f thirdPersonEye=%.3f,%.3f,%.3f "
             "height=%.2f (size %.2f) forward=%.2f pivotDist=%.2f eyeDist=%.2f camDistance=%.2f",
             (int)g_ctl.worldFrames, actor, pos[0], pos[1], pos[2], pivot[0], pivot[1], pivot[2], tpEye[0], tpEye[1],
             tpEye[2], h, size, fwd, dp, de, (double)*(const float*)(b + layout::kCamDistance));
  if (!readable_floats_ok(pivot, 3)) return "camera pivot is invalid";
  const int farCandidate = dp > 8.0 || de > 40.0;
  // 1.7.85: "same player" no longer locks itself out after a cut re-creates the player (sceneview::same_player), and a refusal says why.
  const uintptr_t headActor = farCandidate ? head_aim_actor() : 0;
  const int headAlive = headActor && memory_readable((const void*)headActor, 8) && *(const uintptr_t*)headActor == rva(layout::kRvaGhostbusterVtable);
  const int actorIsGb = farCandidate && memory_readable(actor, 8) && *(const uintptr_t*)actor == rva(layout::kRvaGhostbusterVtable);
  const int samePlayer = farCandidate && sceneview::same_player((uintptr_t)actor, headActor, headAlive);
  const int scene = sceneview::mode(dp, de, g_ctl.stereoActive, samePlayer, actorIsGb);
  if (scene < 0) {
    // data for the next report: which of the four rules refused the scripted camera (first 12 changes, then one line in 400)
    static LONG s_rej; static int s_lastWhy = -1;
    const int why = !(dp >= 0.0 && de >= 0.0) ? 1 : !g_ctl.stereoActive ? 2 : !actorIsGb ? 3 : !samePlayer ? 4 : 5;
    const LONG n = InterlockedIncrement(&s_rej);
    if ((why != s_lastWhy && n <= 40) || n % 400 == 0)
      log_line("SCENEVIEW refused #%ld (%s): pivot %.1f ft, camera %.1f ft from the player's head | follow target %p %s, verified player %p %s, last followed %p | needs: VR on, a CGhostbuster target that is the verified player, both distances 8..2000 ft",
               n, why == 1 ? "distance unreadable" : why == 2 ? "VR is off" : why == 3 ? "the camera follows something that is not a CGhostbuster" : why == 4 ? "the camera follows a different live Ghostbuster" : "camera farther than 2000 ft",
               dp, de, actor, actorIsGb ? "(CGhostbuster)" : "(other class)", (void*)headActor, headAlive ? "(alive)" : "(gone or none)", (void*)g_sceneActor);
    s_lastWhy = why;
    return "scripted camera does not follow the verified player";
  }
  const int distant = scene == 1;
  // Commit scene changes at the first eye so both eyes use the same body mode.
  if (!(g_ctl.stereoPair && (g_ctl.stereoNextEye & 1) && g_sceneActor == (uintptr_t)actor)) {
  if (g_sceneActor && g_sceneActor != (uintptr_t)actor) { g_sceneStation.have = 0; g_sceneStation.suppressed = 0; }
  uintptr_t boss = 0, world = 0; int alive = 0;
#if GBVR_HEADTRACK
  if (g_ctl.stereoActive) alive = fight_staypuft((uintptr_t)actor, &boss, &world);
#endif
  const int fightArms = g_sceneFight.update(world, (uintptr_t)actor, boss, alive, distant);
  if (!fightArms && alive >= 0 && (g_sceneStation.have || g_sceneStation.suppressed)) {
#if GBVR_HEADTRACK
    if (g_sceneStation.have) stereo_comfort_transition();
#endif
    g_sceneStation.have = 0; g_sceneStation.suppressed = 0;
  }
  if (fightArms != g_sceneArms) log_line("SCENEVIEW %s; boss=%p camera/pivot offset %.1f/%.1f ft", fightArms ? "Stay Puft fight: floating tracked arms" : alive < 0 ? "waiting for fresh fight state" : "scripted rooftop view finished: full-body IK restored", (void*)boss, de, dp);
#if GBVR_HEADTRACK
  if (fightArms && !g_sceneArms && g_ctl.cutFade && g_ctl.stereoActive) stereo_comfort_hold(1);   // 1.7.183: black until the roof spot is found (no wall view)
  if (!fightArms && g_sceneArms) stereo_comfort_hold(0);
#endif
  InterlockedExchange(&g_sceneArms, fightArms);
  }
  g_sceneActor = (uintptr_t)actor;
  g_sceneQ = qpc_now();
  if (g_ctl.stereoActive) {   // 1.7.69 stairs: the eye hangs on the character's feet, which step up / down each stair; the height is eased (stairs_smooth_ms)
    static double s_y, s_vy, s_px, s_pz; static int s_have; static int64_t s_q; static uintptr_t s_act;
    static stairs::Ramp s_ramp; static uintptr_t s_rampAct;
    static struct { int on; double t0, dy, hdist, secs; int sprint; double stickSum; long stickN; } s_st; static LONG s_stLogs;
    const int64_t nq = qpc_now(); const double fq = (double)qpc_freq();
    const double y = pos[1];
    if (!s_have || s_act != (uintptr_t)actor || vm::dabs(y - s_y) > 3.0) { s_y = y; s_have = 1; s_act = (uintptr_t)actor; s_q = nq; s_vy = 0; s_px = pos[0]; s_pz = pos[2]; s_st.on = 0; stairs::reset(s_ramp); s_rampAct = (uintptr_t)actor; }
    else {
      double dt = (double)(nq - s_q) / fq;
      if (dt > 0.003) {
        if (dt > 0.1) dt = 0.1;
        const double tau = (double)g_ctl.stairsSmoothMs / 1000.0;
        const double prevY = s_y;
        if (g_ctl.stairsRamp && tau > 0.001) {   // 1.7.71: a flight of stairs becomes a smooth slope (stairsmath.h)
          if (s_rampAct != (uintptr_t)actor) { stairs::reset(s_ramp); s_rampAct = (uintptr_t)actor; }
          s_y = stairs::step(s_ramp, (double)nq / fq, y, 0.5, tau * 0.5);
        }
        else if (tau > 0.001) { s_y += (y - s_y) * (dt / (tau + dt)); if (y - s_y > 1.0) s_y = y - 1.0; if (s_y - y > 1.0) s_y = y + 1.0; }
        else s_y = y;
        // data: a stretch of walking up or down (STAIRS line when it ends)
        const double hx = (double)pos[0] - s_px, hz = (double)pos[2] - s_pz;
        const double hd = vm::dsqrt(hx * hx + hz * hz);
        s_vy = 0.8 * s_vy + 0.2 * ((s_y - prevY) / dt);
        const int going = vm::dabs(s_vy) > 0.6 && hd / dt > 0.5 && hd / dt < 60.0;
        if (going && !s_st.on) { s_st.on = 1; s_st.t0 = qpc_ms() / 1000.0; s_st.dy = 0; s_st.hdist = 0; s_st.secs = 0; s_st.sprint = 0; s_st.stickSum = 0; s_st.stickN = 0; }
        if (s_st.on) {
          s_st.dy += s_y - prevY; s_st.hdist += hd < 3.0 ? hd : 0.0; s_st.secs += dt;
#if GBVR_HEADTRACK
          if (controllers_sprint_want()) s_st.sprint = 1;
          s_st.stickSum += (double)controllers_move_mag() * 0.001; ++s_st.stickN;   // 1.7.71: how far the stick was pushed (slow stairs = a short push, or the game?)
#endif
         
          if (!going && vm::dabs(s_vy) < 0.2) {
            if (s_st.secs > 0.5 && InterlockedIncrement(&s_stLogs) <= 40)
              log_line("STAIRS t=%.1fs %s %.1f ft in %.1f s (%.1f ft/s up/down), along the floor %.1f ft/s, sprint %s, eye eased over %d ms, ramp %d, stick %.0f%% | boost lift on stairs: %ld lifts, %.2f ft in all",
                       s_st.t0, s_st.dy > 0 ? "up" : "down", vm::dabs(s_st.dy), s_st.secs, vm::dabs(s_st.dy) / s_st.secs, s_st.hdist / s_st.secs, s_st.sprint ? "on" : "off", (int)g_ctl.stairsSmoothMs, (int)g_ctl.stairsRamp,
                       s_st.stickN ? 100.0 * s_st.stickSum / s_st.stickN : 0.0, g_stairLifts, g_stairLiftFt);
            s_st.on = 0;
          }
        }
        s_px = pos[0]; s_pz = pos[2]; s_q = nq;
      }
    }
    base[1] = s_y + h;
    {   // 1.7.186: published for the held aim and the body shift cap
      const double lag = s_y - y; InterlockedExchange(&g_eyeLagMft, (LONG)(vm::is_finite_f((float)lag) ? lag * 1000.0 : 0.0));
      const LONG a = (LONG)(vm::dabs(lag) * 1000.0); if (a > 300) InterlockedIncrement(&g_stepLagFrames); if (a > g_stepLagMaxMft) InterlockedExchange(&g_stepLagMaxMft, a);
    }
  }
  eyeOut[0] = (float)(base[0] + s * fwd);
  eyeOut[1] = (float)base[1];
  eyeOut[2] = (float)(base[2] + c * fwd);
  return readable_floats_ok(eyeOut, 3) ? nullptr : "first-person eye not finite";
}

#if GBVR_HEADTRACK
// Stereo (0.21): decide this frame's eye, its position and the basis the
// engine will receive. fpEye = 1 if g_armEye already holds the first-person
// eye; otherwise the game's own (third-person) eye is the base. On success
// g_armEye holds the final eye position. Returns a failure reason or null.
static struct { LONG n, clamped; float mn[3], mx[3], last[3]; } g_hm;   // 0.48: how far the head moved from the start point (metres)
// ---- 0.52 the player's models follow the real body -----------------------------------------------------------------
// Written by arm_stereo (game thread, once per frame), read by the matrix hook on the render thread (seqlock).
static struct {
  volatile LONG seq;
  LONG valid;
  int64_t qpc;
  uintptr_t actor;
  float feet[3], d[3];
  double phi, s;
  float headYawDeg;
  float lean[3];      // 0.61: head target minus where the placed animation has the head (game feet)
  float view[9];      // 0.61: headset orientation in game world
  double yaw;         // 0.61: yaw the placed body faces
  float eye[3];       // 0.68: the camera's (cyclopean) eye in game world, set back a little: where the avatar's eyes must be
  int eyeOk;
  float fade;         // 0.69: 1 = the body corrections work fully, 0 = off (the game is moving the character by force)
} g_body;

// 0.81 PKE MODE: the PKE meter is in the player's hands (inventory item 5 in hand). The body is then shown (only the head is hidden) and the game's own
// animation holds the PKE in both hands: the probe's arm / gun overrides step aside.
static struct { volatile LONG frames, switches, wandSkips, armSkips, gunHidden; int last; } g_pke;
static struct { volatile LONG frames; } g_glove;   // 0.83
static int pke_item_held() {   // 0.83: the PKE is the item in hand (whatever the PKE-body setting is)
  int st[8], cur = -1;
  const int fresh = fight_items(st, &cur);
  return fresh && cur == 5;
}
int engine_pke_own() { return g_ctl.pkeOwn && g_ctl.realModels && pke_item_held(); }   // 0.93
int engine_pke_item() { return pke_item_held(); }   // 0.94
int engine_glove_mode() { return g_ctl.glovesOnly && g_ctl.armsOnly && g_ctl.armIk == 1 && g_ctl.realModels && g_ctl.firstPerson && !pke_item_held(); }
static int pke_mode() {
  if (!g_ctl.pkeBody) return 0;
  int st[8], cur = -1;
  const int fresh = fight_items(st, &cur);
  const int on = fresh && cur == 5;
  if (on != g_pke.last) { g_pke.last = on; InterlockedIncrement(&g_pke.switches); if (g_pke.switches <= 20) log_line("PKEMODE %s: %s", on ? "ON" : "off", on ? "body shown (head hidden), the body is shown (head hidden); arms and the PKE follow your controllers like the gun" : "arms and gun follow the controllers again"); }
  return on;
}
int engine_pke_mode() { return pke_mode(); }

// 0.81 SOLID BODY: where a point (game world feet) must move to stay out of the avatar's torso. 1 = pushed.
static struct { volatile LONG calls, pushed, maxX100; } g_solid;
static int solid_delta(const float* P3, double* delta) {
  delta[0] = delta[1] = delta[2] = 0;
  if (!g_ctl.solidBody) return 0;
  float eye[3], yaw = 0, sc = 1.0f; int ok = 0;
  for (int tries = 0; tries < 3 && !ok; ++tries) {
    const LONG s0 = g_body.seq;
    if (s0 & 1) continue;
    for (int i = 0; i < 3; ++i) eye[i] = g_body.eye[i];
    yaw = (float)g_body.yaw; sc = (float)g_body.s;
    ok = g_body.seq == s0 && g_body.valid && g_body.eyeOk;
  }
  if (!ok) return 0;
  const double e[3] = {eye[0], eye[1], eye[2]}, P[3] = {P3[0], P3[1], P3[2]};
  InterlockedIncrement(&g_solid.calls);
  if (!solid::push_out(e, (double)yaw, (double)sc, P, 0.10, delta)) return 0;
  InterlockedIncrement(&g_solid.pushed);
  const LONG m = (LONG)(vm::dsqrt(delta[0] * delta[0] + delta[2] * delta[2]) * 100.0);
  if (m > g_solid.maxX100) g_solid.maxX100 = m;
  return 1;
}
static forced::Detector g_forced;   // 0.69
static LONG g_forcedLogged;
// 1.7.26 cutscene guard (cinemath.h): blend 0..1, 1 = the game is in charge of the character. Written by body_update (game thread), read by the render-thread hooks.
static volatile LONG g_poseLostTick;   // 1.7.151: GetTickCount of the last frame refused for the headset pose (0 = never)
static cuthold::Hold g_cutHold; static int g_cutHoldInit; static LONG g_cutHoldLogs; static volatile LONG g_cutFades;   // 1.7.151
static cine::Guard g_cine;
static int g_cineInit;
static volatile LONG g_cineBlendX1000;
static LONG g_cineLogged;
static struct { volatile LONG bodyPass, packPass, hosePass, wandPass, mixed, armSkips, turnQuiet, turnForced, frames, frames1; } g_cineSt;
// A confirmed scripted move must take the body, arms and wand together even
// when keep_control keeps ordinary platform/knockback eye matching enabled.
// The headset camera itself remains tracked; this only gates the model hooks.
static inline double cine_blend() { return g_ctl.cineGuard ? (double)g_cineBlendX1000 * 0.001 : 0.0; }
// 1.7.79: "the character is moved by the game" for the TURN code only; with keep_control on, turning keeps working on platforms, stairs and in portals
static inline int forced_turn_block() { return (g_ctl.keepControl ? 0 : (g_forced.forced ? 1 : 0)); }
// 1.7.6 how fast the character really moves for each left-stick push (and with the forced run): finds where the game switches from walk to run, and whether the forced run is faster
struct { double dist, secs; long n; double peak; } g_spd[2][4];
static body::Torso g_torso;
static int64_t g_torsoQpc;
static struct {
  volatile LONG updates, notFp, noActor, applied[3], notPlayer[3], stale, bad, off;     // [0] body base, [1] extras, [2] hose
  volatile LONG packMoved, packNoMotion, packDropMaxX100, modelEyeX100, fadeX100;     // 0.68 / 0.69
  volatile LONG lastPhiX10, lastHeadYawX10, lastDx100, lastDz100, lastScaleX1000, maxPhiX10, maxOffX100, calibrations, lastCalibPct, lastCalibCm;
} g_bodyMv;

static void body_publish_invalid() {
  InterlockedIncrement(&g_body.seq);
  g_body.valid = 0;
  InterlockedIncrement(&g_body.seq);
}

// ---- 0.75 WALL: the player's report "the character freaks out near walls and the view crosses" ------------------------------------------------
// The game's third-person camera is pulled in by walls (camDistance 4.5 ft shrinks toward ~1.2 ft). The headset eye does not depend on that
// distance, but something does change. This watches the camera distance against the distance its spring is heading for; while the camera is
// pulled in it counts everything that could go wrong (gate failures, incomplete eye pairs, body / arm failures) and saves a both-eyes picture
// once per episode. Nothing here changes behaviour: it is the data for the next version.
static struct {
  int active; int calm; int bad; int events; int shots; int shotDone;
  LONG frames; float minDist, minRatio, startDist, startWant;
  int64_t startQ, lastShotQ, lastSampleQ;
  LONG c[10]; ArmsWallSnap a0; float p0[3]; double yaw0; LONG be0[8];
  LONG total, pulledFrames; float minEver;
} g_wall;

static LONG wall_counter(int i) {
  switch (i) {
    case 0: return g_st.fpGateFails;
    case 1: return g_st.stereoIncomplete;
    case 2: return g_st.stereoPostVerifyFail;
    case 3: return g_st.suspendedFrames;
    case 4: return g_bodyMv.stale;
    case 5: return g_bodyMv.bad;
    case 6: return g_bodyMv.notPlayer[0];
    case 7: return g_bodyMv.noActor;
    case 8: return g_bodyMv.notFp;
    default: return g_st.eyeArmedNoCall;
  }
}

static void trap_carry_step();   // 0.79 (defined after g_headAim)
static void wall_watch(void* cam) {
  const uint8_t* b = (const uint8_t*)cam;
  if (!memory_readable(b + layout::kCamDistTarget, 4) || !memory_readable(b + layout::kCamDistance, 4)) return;
  const float dist = *(const float*)(b + layout::kCamDistance), want = *(const float*)(b + layout::kCamDistTarget);
  if (!vm::is_finite_f(dist) || !vm::is_finite_f(want) || want < 0.5f || want > 30.0f) return;
  ++g_wall.total;
  if (g_wall.total == 1 || dist < g_wall.minEver) g_wall.minEver = dist;
  const float ratio = dist / want;
  const int pulled = ratio < 0.75f;
  if (pulled) ++g_wall.pulledFrames;
  const int64_t now = qpc_now();
  const void* actor = *(void* const*)(b + layout::kCamFollowTarget);
  const float* pos = (actor && memory_readable((const uint8_t*)actor + layout::kActorPos, 12)) ? (const float*)((const uint8_t*)actor + layout::kActorPos) : nullptr;
  const double yaw = *(const float*)(b + layout::kCamEuler + 4);
  if (!g_wall.active) {
    if (pulled) ++g_wall.bad; else g_wall.bad = 0;
    if (g_wall.bad >= 3 && g_wall.events < 40) {
      g_wall.active = 1; g_wall.calm = 0; g_wall.frames = 0; ++g_wall.events; g_wall.shotDone = 0;
      g_wall.minDist = dist; g_wall.minRatio = ratio; g_wall.startDist = dist; g_wall.startWant = want; g_wall.startQ = now; g_wall.lastSampleQ = now;
      for (int i = 0; i < 10; ++i) g_wall.c[i] = wall_counter(i);
      arms_wall_snap(&g_wall.a0);
      for (int i = 0; i < 2; ++i) { g_wall.be0[i] = g_be.asked[i]; g_wall.be0[2 + i] = g_be.drawn[i]; g_wall.be0[4 + i] = g_be.refused[i]; g_wall.be0[6 + i] = g_be.markHidden[i]; }
      if (pos) for (int i = 0; i < 3; ++i) g_wall.p0[i] = pos[i];
      g_wall.yaw0 = yaw;
      log_line("WALL #%d start: the game's camera is pulled in: distance %.2f ft of the %.2f ft it wants (%.0f%%) | actor %.1f,%.1f,%.1f yaw %.0f deg | frame %d",
               g_wall.events, (double)dist, (double)want, (double)ratio * 100.0, pos ? (double)pos[0] : 0.0, pos ? (double)pos[1] : 0.0, pos ? (double)pos[2] : 0.0, yaw * 57.29578, (int)g_ctl.worldFrames);
    }
    return;
  }
  ++g_wall.frames;
  if (dist < g_wall.minDist) g_wall.minDist = dist;
  if (ratio < g_wall.minRatio) g_wall.minRatio = ratio;
  // one picture of both eyes a short while into the episode (when "crossed" would be on screen), at most 3 per run, 20 s apart
  if (!g_wall.shotDone && g_wall.frames >= 20 && g_wall.shots < 3 && (!g_wall.lastShotQ || now - g_wall.lastShotQ > qpc_freq() * 20)) {
    g_wall.shotDone = 1; ++g_wall.shots; g_wall.lastShotQ = now;
    shot_request();
    log_line("WALL #%d picture requested (both eyes, %d frames into the episode; camera distance %.2f of %.2f ft)", g_wall.events, (int)g_wall.frames, (double)dist, (double)want);
  }
  if (now - g_wall.lastSampleQ > qpc_freq() / 2 && g_wall.frames < 600) {   // while it lasts: twice a second
    g_wall.lastSampleQ = now;
    log_line("WALL #%d ...: %d frames, camera distance %.2f of %.2f ft (min %.2f) | actor moved %.2f,%.2f,%.2f ft, yaw turned %.0f deg",
             g_wall.events, (int)g_wall.frames, (double)dist, (double)want, (double)g_wall.minDist,
             pos ? (double)(pos[0] - g_wall.p0[0]) : 0.0, pos ? (double)(pos[1] - g_wall.p0[1]) : 0.0, pos ? (double)(pos[2] - g_wall.p0[2]) : 0.0, (yaw - g_wall.yaw0) * 57.29578);
  }
  if (!pulled) ++g_wall.calm; else g_wall.calm = 0;
  if (g_wall.calm >= 10) {
    g_wall.active = 0; g_wall.bad = 0;
    LONG d[10];
    for (int i = 0; i < 10; ++i) d[i] = wall_counter(i) - g_wall.c[i];
    ArmsWallSnap a1; arms_wall_snap(&a1);
    log_line("WALLEYE #%d the player's own parts during the episode, left/right: asked %d/%d, game said draw %d/%d, game said no %d/%d, probe-hidden %d/%d (an eye with 0 asked/drawn = the game itself never offered the body in that eye)",
             g_wall.events, (int)(g_be.asked[0] - g_wall.be0[0]), (int)(g_be.asked[1] - g_wall.be0[1]), (int)(g_be.drawn[0] - g_wall.be0[2]), (int)(g_be.drawn[1] - g_wall.be0[3]),
             (int)(g_be.refused[0] - g_wall.be0[4]), (int)(g_be.refused[1] - g_wall.be0[5]), (int)(g_be.markHidden[0] - g_wall.be0[6]), (int)(g_be.markHidden[1] - g_wall.be0[7]));
    log_line("WALL #%d end: %d frames (%.2f s), camera distance fell from %.2f to %.2f ft of %.2f (lowest %.0f%%) | during it: eye gate fails %d, incomplete eye pairs %d, view changed after set %d, suspended frames %d | "
             "body: stale %d, bad %d, other-actor %d, no-actor %d, not-first-person %d, eye-no-call %d | arms: calls %d, moved %d, badSpace %d, badLen %d, clamped %d, nonFinite %d, gripNoPose %d, torsoFail %d, missOver %d, shiftCapped %d, verifyLost %d, forced %d, eyeErrMax %.2f ft",
             g_wall.events, (int)g_wall.frames, (double)(now - g_wall.startQ) / (double)qpc_freq(), (double)g_wall.startDist, (double)g_wall.minDist, (double)g_wall.startWant, (double)g_wall.minRatio * 100.0,
             (int)d[0], (int)d[1], (int)d[2], (int)d[3], (int)d[4], (int)d[5], (int)d[6], (int)d[7], (int)d[8], (int)d[9],
             a1.calls - g_wall.a0.calls, a1.moved - g_wall.a0.moved, a1.badSpace - g_wall.a0.badSpace, a1.badLen - g_wall.a0.badLen, a1.clamped - g_wall.a0.clamped,
             a1.nonFinite - g_wall.a0.nonFinite, a1.gripNoPose - g_wall.a0.gripNoPose, a1.torsoFail - g_wall.a0.torsoFail, a1.missOver - g_wall.a0.missOver,
             a1.shiftCapped - g_wall.a0.shiftCapped, a1.verifyLost - g_wall.a0.verifyLost, a1.forcedCalls - g_wall.a0.forcedCalls, (double)a1.eyeErrMaxX100 / 100.0);
  }
}

// 1.7.100 THE STORY CHANGES THE MODEL (a new outfit, a new rig, other hands and fingers). Whatever the probe stored about the OLD model (the gun's and the PKE's locked hold against the
// hand, the hand's follow state, the body size, the draw window) is dropped when the arm layer looks at a new skeleton, so nothing from the old model is applied to the new one. A skeleton
// that flaps (more than 3 changes in 5 s) is left alone: resetting every frame would be worse. The finger bones are found again by name by the arm layer itself on every new skeleton.
static volatile LONG g_modelGen;
static volatile LONG g_handKeepGen;   // 1.7.181: the model-generation number made by a left/right switch (the body size is kept then: it is the same body)
static void model_gen_poll() {
  static int s_last = -1; static int64_t s_winQ; static int s_winN; static LONG s_logs, s_flap;
  const int r = arms_revalidations();
  if (s_last < 0) { s_last = r; return; }
  if (r == s_last) return;
  const int was = s_last; s_last = r;
  const int64_t nq = qpc_now();
  if (!s_winQ || (double)(nq - s_winQ) / (double)qpc_freq() > 5.0) { s_winQ = nq; s_winN = 0; }
  if (++s_winN > 3) { if (InterlockedIncrement(&s_flap) == 1) log_line("MODELCHANGE the player's skeleton keeps changing (more than 3 times in 5 s): the stored holds are kept as they are"); return; }
  InterlockedIncrement(&g_modelGen);
  if (InterlockedIncrement(&s_logs) <= 20) log_line("MODELCHANGE #%ld t=%.2fs: the game gave the player a new model / skeleton (look #%d -> #%d): the stored gun and PKE holds, the hand follow, the body size and the draw window start again from the new model", s_logs, qpc_ms() / 1000.0, was, r);
}
void engine_holds_reset(const char* why) {
  InterlockedIncrement(&g_modelGen);
  if (why && why[0] == 'l') InterlockedExchange(&g_handKeepGen, g_modelGen);   // "left-handed play was switched"
  log_line("MODELCHANGE holds reset (%s): the stored gun and PKE holds, the hand follow, the body size and the draw window start again", why ? why : "");
}
static double g_headOnlyYaw; static int g_handsYawHave;   // 1.7.196
static void body_update(const uint8_t* camb, const float* base, const float* headCenter, const GbvrPose* pose, double camYaw, int fp, const float* headFeet, const float* view) {
  model_gen_poll();   // 1.7.100
  if (!g_ctl.bodyFollow || !g_ctl.realModels || !g_ctl.stereoActive) { InterlockedIncrement(&g_bodyMv.off); body_publish_invalid(); return; }
  if (!fp) { InterlockedIncrement(&g_bodyMv.notFp); body_publish_invalid(); return; }
  void* actor = *(void* const*)(camb + layout::kCamFollowTarget);
  if (!actor || !memory_readable(actor, layout::kActorPos + 12)) { InterlockedIncrement(&g_bodyMv.noActor); body_publish_invalid(); return; }
  const float* pos = (const float*)((const uint8_t*)actor + layout::kActorPos);
  if (!readable_floats_ok(pos, 3)) { InterlockedIncrement(&g_bodyMv.noActor); body_publish_invalid(); return; }
  const int64_t now = qpc_now();
  double dt = g_torsoQpc ? (double)(now - g_torsoQpc) / (double)qpc_freq() : 0.0;
  g_torsoQpc = now;
  double headYaw = 0;
  if (!stereo::basis_yaw(pose->m, &headYaw)) headYaw = g_torso.yaw;
  const double kDeg = 3.14159265358979 / 180.0;
  if (g_ctl.bodyHandsYaw) {   // 1.7.167: the chest turns toward your hands too
    HandsRaw hrB; double w = 0.0;
    if (controllers_raw(&hrB) && hrB.validL && hrB.validR) {
      const double hy = body::hands_yaw(headYaw, pose->raw34, hrB.poseL, hrB.poseR, &w);
      static long s_n, s_used; static double s_sumDeg, s_maxDeg; static int64_t s_q; static LONG s_logs;
      ++s_n; if (w > 0.0) { ++s_used; const double dd = vm::dabs(stereo::angle_diff(hy, headYaw)) / kDeg; s_sumDeg += dd; if (dd > s_maxDeg) s_maxDeg = dd; }
      if (hy == hy) { g_headOnlyYaw = headYaw; headYaw = hy; g_handsYawHave = 1; }
      const int64_t nq = qpc_now();
      if ((!s_q || (double)(nq - s_q) / (double)qpc_freq() >= 30.0) && s_logs < 40) { s_q = nq; ++s_logs;
        log_line("BODYFOLLOW the chest turned toward your hands in %ld of %ld updates, by %.1f deg on average (most %.1f deg) | torso dead zone %d deg, lag %d ms", s_used, s_n, s_used ? s_sumDeg / s_used : 0.0, s_maxDeg, (int)g_ctl.torsoDeadDeg, (int)g_ctl.torsoLagMs); }
    }
  }
  if (InterlockedExchange(&g_torsoResetReq, 0)) g_torso.reset();
  // 1.7.196 a ghost held in the beam / a slam: the chest does not chase the hands (they swing a lot) and twists at most 30 deg from the head, so the body cannot spin round
  static double s_calm; static long s_calmN, s_capN; static double s_calmMax;
  {
    const int calmNow = g_ctl.bodyCalmSlam && (fight_wrangled() == 1 || fight_slam_active());
    const double step = (dt > 0.0 && dt < 0.5 ? dt : 0.011) / 0.25;
    s_calm += calmNow ? step : -step; if (s_calm < 0.0) s_calm = 0.0; if (s_calm > 1.0) s_calm = 1.0;
    if (g_handsYawHave && s_calm > 0.0) headYaw = g_headOnlyYaw + body::wrap_pi(headYaw - g_headOnlyYaw) * (1.0 - s_calm);   // 1.7.211: signed (angle_diff is absolute)
    g_handsYawHave = 0;
  }
  double phi = g_torso.step(headYaw, dt, (double)g_ctl.torsoDeadDeg * kDeg, (double)g_ctl.torsoLagMs / 1000.0);
  if (s_calm > 0.0) {
    ++s_calmN; const double ap = phi < 0 ? -phi : phi; if (ap / kDeg > s_calmMax) s_calmMax = ap / kDeg;
    double dk = 0.0;   // 1.7.211: looking down the chest follows the head (the 30 deg cap left the pack 70-130 deg off your view); the cap stays for looking ahead
    { const double hl = vm::dsqrt((double)pose->m[2] * pose->m[2] + (double)pose->m[8] * pose->m[8]); const double pd = vm::datan2(-(double)pose->m[5], hl > 1e-6 ? hl : 1e-6) * 57.29577951308232;
      dk = (pd - 20.0) / 40.0; dk = dk < 0.0 ? 0.0 : (dk > 1.0 ? 1.0 : dk); dk = dk * dk * (3.0 - 2.0 * dk); }
    const double lim = (130.0 - 100.0 * s_calm * (1.0 - dk)) * kDeg;
    if (phi > lim) { phi = lim; ++s_capN; } else if (phi < -lim) { phi = -lim; ++s_capN; }
    static int64_t s_cq; const int64_t nq2 = qpc_now(); static LONG s_cl;
    if ((!s_cq || (double)(nq2 - s_cq) / (double)qpc_freq() >= 5.0) && s_cl < 30) { s_cq = nq2; ++s_cl; log_line("BODYCALM a ghost is held in the beam or a slam plays: chest twist kept within 30 deg of the head (frames so far %ld, capped %ld, largest twist wanted %.0f deg, ramp %.2f)", s_calmN, s_capN, s_calmMax, s_calm); }
  }
  const double fwd = (double)g_ctl.eyeForwardCenti / 100.0;
  double s0, c0, s1, c1;
  vm::dsincos(camYaw, &s0, &c0);
  vm::dsincos(camYaw + phi, &s1, &c1);
  float d[3];
  d[0] = (float)((double)headCenter[0] - (double)base[0] + fwd * (s0 - s1));
  d[1] = 0.0f;
  d[2] = (float)((double)headCenter[2] - (double)base[2] + fwd * (c0 - c1));
  // 0.61 full body: a small move of the head is a LEAN (feet stay), only a bigger one moves the feet; crouching is the head going down
  float lean[3] = {0, 0, 0};
  if (g_ctl.fullBody && view) {
    const double Lc = (double)g_ctl.bodyLeanCm * 0.01 * 3.28084;
    const double dm = vm::dsqrt((double)d[0] * d[0] + (double)d[2] * d[2]);
    if (Lc > 0 && dm > 1e-4) { const double k = dm <= Lc ? 1.0 : Lc / dm; lean[0] = (float)(d[0] * k); lean[2] = (float)(d[2] * k); d[0] -= lean[0]; d[2] -= lean[2]; }
    if (headFeet && headFeet[1] < 0.0f) lean[1] = headFeet[1];
  }
  double camEye = (double)g_ctl.eyeHeightCenti / 100.0 * (double)g_ctl.sizePct / 100.0;
  // 0.69 eyes at the camera: the body scale comes from the avatar's own eye height (the tallest peak of what the torso pass measured on the model);
  // the rest is taken out per frame by the torso pass (it shifts the whole body so the avatar's eyes are exactly at the camera)
  double modelEye = (double)g_ctl.bodyEyeCenti / 100.0;
  int eyeOk = 0;
  float eyeT[3] = {0, 0, 0};
  if (g_ctl.fullBody && g_ctl.bodyEyeAlign && view) {
    const float lme = arms_model_eye_ft();
    if (lme > 3.5f && lme < 8.0f) modelEye = (double)lme;
    const double back = (double)g_ctl.eyeBackCm * 0.01 * 3.28084;   // the camera sits a little in front of the face, so the face is never in the picture
    for (int i = 0; i < 3; ++i) eyeT[i] = (float)((double)headCenter[i] - back * (double)view[i * 3 + 2]);
    eyeOk = readable_floats_ok(eyeT, 3);
  }
  // 0.69 forced moves: the game moves the character itself (cutscene, knock-back, level start) while the stick is untouched
  double fade = 1.0;
  if (g_ctl.forcedDetect) {
    pad::State ps;
    const double stick = controllers_pad_state(&ps) ? (double)(vm::dsqrt((double)ps.lx * ps.lx + (double)ps.ly * ps.ly) / 32767.0) : 1.0;
    const double ap[3] = {pos[0], pos[1], pos[2]};
    const int was = g_forced.forced;
    fade = g_forced.update(ap, stick, dt);
    if (g_ctl.keepControl) fade = 1.0;   // 1.7.79: the eye match (body to the eyes) never fades out, so the game cannot leave you looking at the character
    if (stick >= 0.30 && !g_forced.forced && dt > 0.0 && dt < 0.2 && g_forced.speed >= 0.0 && g_forced.speed < 80.0 && !vrmenu_is_open()) {
      const int run = controllers_sprint_want() ? 1 : 0, bk = stick < 0.50 ? 0 : stick < 0.70 ? 1 : stick < 0.90 ? 2 : 3;
      g_spd[run][bk].dist += g_forced.speed * dt; g_spd[run][bk].secs += dt; ++g_spd[run][bk].n;
      if (g_forced.speed > g_spd[run][bk].peak) g_spd[run][bk].peak = g_forced.speed;
    }
    {   // 1.7.151: the game jumped the character to another place while you are in 3D: through black instead of a lurch
      static int s_tp = -1;
      // every jump counts (also the 2nd, 3rd cut of a row); a real jump is hundreds of ft/s - 5 ft covered during a long hitch while running (20 ft/s) is not one
      if (s_tp >= 0 && g_forced.jumpsAll > s_tp && (g_forced.speed > 80.0 || g_forced.lastStep > 15.0) &&   /* 1.7.154: at a low frame rate a real jump is slower per second: far enough also counts */ g_ctl.cutFade && g_ctl.stereoActive && !stereo_in_flat_mode() && !engine_scene_arms(0)) { stereo_comfort_transition(); InterlockedIncrement(&g_cutFades); }
      s_tp = g_forced.jumpsAll;
    }
    if (g_forced.forced != was) {
      if (InterlockedIncrement(&g_forcedLogged) <= 60)
        log_line("FORCEDMOVE %s: the character %s (speed %.1f ft/s, move stick %.2f, event #%d, jumps %d, longest %.1f ft/s so far); body eye-match fade %.2f (keep_control %d)",
                 g_forced.forced ? "start" : "end", g_forced.forced ? "is being moved by the game" : "stands again or you have the controls back", g_forced.speed, stick, g_forced.events,
                 g_forced.teleports, g_forced.maxSpeed, fade, (int)g_ctl.keepControl);
    }
  } else g_forced.fade = 1.0;
  {   // 1.7.26 cutscene guard
    if (!g_cineInit) { g_cine.reset(); g_cineInit = 1; }
    const int was = g_cine.active;
    double cb = 0.0;
    // 1.7.156 "the gun floats out of the hand when fired". The report log: hit by a ghost in a fight -> the game shoved the character for 1.1 s -> this guard
    // (0.55 s) handed the body, arms and gun to the game's animation for two seconds: the gun left the hand, the body left the arms. With keep_control (default)
    // the guard now only engages for what the gun gate also calls "not in play": the game moving the character for longer than its knock grace (6 s: a scripted
    // walk). Hits, knock-downs, stairs, platforms, hitches and cuts no longer take anything out of your hands. keep_control=0 keeps the 1.7.26 rules.
    g_cine.engageSec = g_ctl.keepControl ? gungate::kKnockGraceS : 0.55;
    g_cine.jumpEngages = g_ctl.keepControl ? 0 : 1;
    if (g_ctl.cineGuard) cb = g_cine.update(g_forced.forced, g_forced.teleports, dt);
    else { g_cine.active = 0; g_cine.blend = 0.0; }
    InterlockedExchange(&g_cineBlendX1000, (LONG)(cb * 1000.0));
    InterlockedIncrement(&g_cineSt.frames);
    if (cb > 0.5) InterlockedIncrement(&g_cineSt.frames1);
    if (g_cine.active != was && InterlockedIncrement(&g_cineLogged) <= 60)
      log_line("CINE %s: the game is %s (cause: %s, forced move %.2f s, jumps %d, event #%d, longest so far %.1f s); the probe %s the body, arms and gun (keep_control %d)",
               g_cine.active ? "start" : "end", g_cine.active ? "in charge of the character" : "no longer in charge", g_cine.active ? (g_cine.byJump && g_cine.byJump >= g_cine.byMove ? "a jump (cut / respawn)" : "a long forced move") : "calm again",
               g_cine.forcedSec, g_forced.teleports, g_cine.events, g_cine.longest, g_cine.active ? "hands back to the game's animation for" : "eases back in to", (int)g_ctl.keepControl);
  }
  double scale = g_ctl.bodyScale ? body::body_scale(camEye, modelEye) : 1.0;
  {   // 1.7.99 the body keeps its size while you play (see bodymath.h scale_hold); BODYSCALE says when the target moved and what was drawn
    static double s_heldScale; static uintptr_t s_heldActor; static LONG s_bsLogs; static double s_bsLogTarget; static double s_bsMin = 9.0, s_bsMax = 0.0;
    static LONG s_scaleGen;
    if (s_heldActor == (uintptr_t)actor && s_scaleGen != g_modelGen && g_modelGen == g_handKeepGen) s_scaleGen = g_modelGen;   // 1.7.181: a hand switch keeps the body size (no pop)
    if (s_heldActor != (uintptr_t)actor || s_scaleGen != g_modelGen) { s_heldActor = (uintptr_t)actor; s_scaleGen = g_modelGen; s_heldScale = 0.0; s_bsLogTarget = scale; }   // a new actor or a new model takes its own size at once
    const double target = scale;
    s_heldScale = body::scale_hold(s_heldScale, target, dt);
    scale = s_heldScale;
    if (scale < s_bsMin) s_bsMin = scale;
    if (scale > s_bsMax) s_bsMax = scale;
    if ((target - s_bsLogTarget > 0.01 || s_bsLogTarget - target > 0.01) && InterlockedIncrement(&s_bsLogs) <= 40) {
      log_line("BODYSCALE t=%.2fs the size the model's eye height asks for moved %.3f -> %.3f (camera eye %.2f ft, model eye %.2f ft); drawn %.3f (held, followed slowly), range drawn so far %.3f..%.3f", qpc_ms() / 1000.0, s_bsLogTarget, target, camEye, modelEye, scale, s_bsMin, s_bsMax);
      s_bsLogTarget = target;
    }
  }
  g_bodyMv.modelEyeX100 = (LONG)(modelEye * 100.0);
  g_bodyMv.fadeX100 = (LONG)(fade * 100.0);
  if (!vm::is_finite_f(d[0]) || !vm::is_finite_f(d[2]) || !(phi == phi)) { InterlockedIncrement(&g_bodyMv.bad); body_publish_invalid(); return; }
  InterlockedIncrement(&g_body.seq);
  g_body.valid = 1;
  g_body.qpc = now;
  g_body.actor = (uintptr_t)actor;
  for (int i = 0; i < 3; ++i) { g_body.feet[i] = pos[i]; g_body.d[i] = d[i]; }
  g_body.phi = phi;
  g_body.s = scale;
  g_body.headYawDeg = (float)(headYaw / kDeg);
  for (int i = 0; i < 3; ++i) g_body.lean[i] = lean[i];
  if (view) for (int i = 0; i < 9; ++i) g_body.view[i] = view[i];
  g_body.yaw = camYaw + phi;
  for (int i = 0; i < 3; ++i) g_body.eye[i] = eyeT[i];
  g_body.eyeOk = eyeOk;
  g_body.fade = (float)fade;
  InterlockedIncrement(&g_body.seq);
  InterlockedIncrement(&g_bodyMv.updates);
  g_bodyMv.lastPhiX10 = (LONG)(phi / kDeg * 10.0);
  g_bodyMv.lastHeadYawX10 = (LONG)(headYaw / kDeg * 10.0);
  g_bodyMv.lastDx100 = (LONG)(d[0] * 100.0f); g_bodyMv.lastDz100 = (LONG)(d[2] * 100.0f);
  g_bodyMv.lastScaleX1000 = (LONG)(scale * 1000.0);
  LONG ap = g_bodyMv.lastPhiX10 < 0 ? -g_bodyMv.lastPhiX10 : g_bodyMv.lastPhiX10;
  if (ap > g_bodyMv.maxPhiX10) g_bodyMv.maxPhiX10 = ap;
  double off = vm::dsqrt((double)d[0] * d[0] + (double)d[2] * d[2]) * 100.0;
  if ((LONG)off > g_bodyMv.maxOffX100) g_bodyMv.maxOffX100 = (LONG)off;
}

// Height calibration (gesture left Menu + right Grip for 1.5 s, or Ctrl+F9): the real eye height (metres above the floor)
// sets the player-height percent so that the camera's eye height is the real one (scaled like the rest of the world), and
// the head position is re-zeroed. The body is scaled from that (body_update).
void body_last_calibration(int* cm, int* pct, int* count) { *cm = (int)g_bodyMv.lastCalibCm; *pct = (int)g_bodyMv.lastCalibPct; *count = (int)g_bodyMv.calibrations; }
void body_calibrate_apply(double eyeM, double leftHandM, double rightHandM) {
  // 1.7.17: the view is never lowered and the character is never scaled (that sank the camera into the stomach and left the arms too short): the world size is matched to your real height instead
  const double avatarEyeFt = (double)g_ctl.eyeHeightCenti / 100.0;
  int pct = body::world_pct_for(eyeM, avatarEyeFt);
  const LONG oldW = g_ctl.worldPct, oldS = g_ctl.sizePct;
  if (pct && (eyeM < 1.0 || eyeM > 2.3 || (g_ctl.seated && eyeM < 1.35))) { log_line("CALIBRATE refused: %.2f m is not a usable standing head height%s (1.7.180: the same checks for the menu and Ctrl+F9)", eyeM, g_ctl.seated ? " with seated play on" : ""); pct = 0; }
  if (pct) {
    InterlockedExchange(&g_ctl.worldPct, pct);
    InterlockedExchange(&g_ctl.sizePct, 100);
    if (!g_ctl.seated) InterlockedExchange(&g_ctl.recenterRequest, 1);   // 1.7.180: a standing measure while seated would put the zero at the standing head height
    g_torso.reset();
    settings_changed();
    engine_request_sample();
  }
  InterlockedIncrement(&g_bodyMv.calibrations);
  g_bodyMv.lastCalibPct = pct;
  g_bodyMv.lastCalibCm = (LONG)(eyeM * 100.0 + 0.5);
  log_line("CALIBRATE real eye height %.3f m (%.2f ft); the character's eye is %.2f ft; world size %d%% -> %d%% (player height %d%% -> %d%%: the view is not lowered, the character is not scaled)%s; head position re-zeroed",
           eyeM, eyeM * 3.280839895, avatarEyeFt, (int)oldW, (int)(pct ? pct : oldW), (int)oldS, (int)(pct ? 100 : oldS), pct ? "" : " - height not usable, nothing changed");
}

// ---- 1.7.38 chest camera for the PC window ------------------------------------------------------------------------------------------------
// With chest_cam on (and the monitor view on) the render thread asks for one extra game picture after every chest_cam_every eye pairs. This is
// that picture's camera: a spot on the upper chest (chest_cam_down_cm below the head, chest_cam_back_cm behind it), looking where the gun points
// (smoothed, pitch limited so the head above it stays out of the picture), level horizon. It reuses the state of the pair that just finished
// (same moment, same hands), so the arms and the gun stand where they stand in the headset. The picture is only for the PC window.
static struct ChestCam {
  int have; double yaw, pitch; int64_t q;
  long frames, noPair, noAim, pitchLimited; int logged;
  double yawSum, pitchSum;
} g_cc;

static void chest_cam_build(ArmStereo& a, float* eyeOut, int sample) {
  float f[3];
  const int aim = controllers_hand_aim(a.level, f);
  if (!aim) { ++g_cc.noAim; f[0] = a.view[2]; f[1] = a.view[5]; f[2] = a.view[8]; }
  double fl = vm::dsqrt((double)f[0] * f[0] + (double)f[2] * f[2]);
  double yawT = fl > 1e-4 ? vm::datan2((double)f[0], (double)f[2]) : a.yaw;
  double pitchT = vm::datan2((double)f[1], fl > 1e-4 ? fl : 1e-4);
  { int lim = 0; pitchT = chest::clamp_pitch(pitchT, &lim); g_cc.pitchLimited += lim; }
  const int64_t now = qpc_now();
  const double dt = g_cc.q ? (double)(now - g_cc.q) / (double)qpc_freq() : 1e9;
  g_cc.q = now;
  if (!g_cc.have || dt > 0.5) { g_cc.yaw = yawT; g_cc.pitch = pitchT; g_cc.have = 1; }
  else {
    g_cc.yaw = chest::smooth_angle(g_cc.yaw, yawT, dt, 0.08);   // about 80 ms of smoothing: the picture follows the gun without shaking
    g_cc.pitch = chest::smooth_angle(g_cc.pitch, pitchT, dt, 0.08);
  }
  chest::basis(g_cc.yaw, g_cc.pitch, a.view);
  chest::position(a.headCenter, a.yaw, (double)g_ctl.chestCamDownCm * 0.01 * a.feetPerMetre, (double)g_ctl.chestCamBackCm * 0.01 * a.feetPerMetre, eyeOut);
  ++g_cc.frames;
  g_cc.yawSum += g_cc.yaw; g_cc.pitchSum += g_cc.pitch;
  if (sample || g_cc.logged < 3) {
    ++g_cc.logged;
    log_line("CHESTCAM frame=%d aim=%d aimDir=%.3f,%.3f,%.3f yaw=%.1f deg pitch=%.1f deg (limits -30..+5) body yaw=%.1f deg head=%.3f,%.3f,%.3f camera=%.3f,%.3f,%.3f (down %d cm, back %d cm)",
             (int)g_ctl.worldFrames, aim, f[0], f[1], f[2], g_cc.yaw * 180.0 / vm::kPi, g_cc.pitch * 180.0 / vm::kPi, a.yaw * 180.0 / vm::kPi,
             a.headCenter[0], a.headCenter[1], a.headCenter[2], eyeOut[0], eyeOut[1], eyeOut[2], (int)g_ctl.chestCamDownCm, (int)g_ctl.chestCamBackCm);
  }
}

static const char* arm_stereo(void* cam, const GbvrPose& poseNow, int fpEye, int sample) {
  StereoParams sp;
  if (!stereo_get_params(&sp)) return "stereo gate: headset eye data not ready";
  if (stereo_frame_pending() && InterlockedIncrement(&g_st.stereoOverlap) <= 5)
    log_line("STEREO warning: a new frame is being prepared before the previous eye picture was presented (frame=%d)",
             (int)g_ctl.worldFrames);
  const uint8_t* b = (const uint8_t*)cam;
  ArmStereo& a = g_armStereo;
  // Camera state of this frame ...
  double yaw = *(const float*)(b + layout::kCamEuler + 4);
  float base[3];
  const float* src = fpEye ? g_armEye : (const float*)(b + layout::kCamEye);
  for (int i = 0; i < 3; ++i) base[i] = src[i];
  const GbvrPose* pose = &poseNow;
  // ... or, for the second eye of a pair, the state the first eye used.
  int pairMode = g_ctl.stereoPair != 0, phase = g_ctl.stereoPairPhase & 1, reused = 0, spec = 0;
  if (InterlockedExchange(&g_ctl.stereoSpecNext, 0)) {   // 1.7.38: the render thread asked for the chest-camera picture (a pair has just been shown)
    if (pairMode && phase == 0 && g_ctl.chestCam && g_ctl.monitorView && g_pair.valid) {
      const double ageMs = (double)(qpc_now() - g_pair.qpc) * 1000.0 / (double)qpc_freq();
      if (ageMs >= 0 && ageMs < 100.0) spec = 1;
    }
    if (!spec) ++g_cc.noPair;
  }
  if (spec) {   // same moment, same hands as the pair that just finished
    yaw = g_pair.yaw;
    for (int i = 0; i < 3; ++i) base[i] = g_pair.baseEye[i];
    pose = &g_pair.pose;
    reused = 1;
  } else if (pairMode && phase == 1) {
    double ageMs = (double)(qpc_now() - g_pair.qpc) * 1000.0 / (double)qpc_freq();
    if (g_pair.valid && ageMs >= 0 && ageMs < 100.0) {
      yaw = g_pair.yaw;
      for (int i = 0; i < 3; ++i) base[i] = g_pair.baseEye[i];
      pose = &g_pair.pose;
      reused = 1;
      InterlockedIncrement(&g_st.pairReused);
    } else {
      InterlockedIncrement(&g_st.pairNoState);
    }
  }
  if (!reused && engine_scene_arms((uintptr_t)g_sceneActor)) {
    if (g_sceneStation.release_if_walking(base, controllers_move_mag() > 300 && !g_forced.forced)) {
      stereo_comfort_transition();
      log_line("SCENEVIEW player moved more than 3 ft from the scene view anchor; headset follows the player again until this encounter ends");
    }
    float mouth[3]; int stage = 0;
    // 1.7.185: why does the roof spot take about 2 s to be found? (SCENEWAIT, a few times a second while the black is held)
    static struct { int64_t q0, lastQ; long focusFail, placeFail, logs; uintptr_t actor; } s_wait;
    if (s_wait.actor != g_sceneActor || g_sceneStation.have) { s_wait.actor = g_sceneActor; s_wait.q0 = 0; s_wait.focusFail = s_wait.placeFail = 0; s_wait.lastQ = 0; }
    const int focusOk = fight_staypuft_focus(g_sceneActor, mouth, &stage);
    if (!g_sceneStation.have && !g_sceneStation.suppressed) {
      const int64_t nowW = qpc_now();
      if (!s_wait.q0) s_wait.q0 = nowW;
      if (!focusOk) ++s_wait.focusFail;
      if (s_wait.logs < 40 && (!s_wait.lastQ || (double)(nowW - s_wait.lastQ) / (double)qpc_freq() >= 0.3)) {
        s_wait.lastQ = nowW; ++s_wait.logs;
        log_line("SCENEWAIT %.2f s into the fight scene: roof spot not placed yet | boss focus readable now %d (unreadable %ld times so far) | placement refused %ld times | boss %p stage %d",
                 (double)(nowW - s_wait.q0) / (double)qpc_freq(), focusOk, s_wait.focusFail, s_wait.placeFail, (void*)g_sceneFight.boss, stage);
      }
    }
    if (focusOk) {
      const int recenter = InterlockedExchange(&g_sceneRecenter, 0);
      if (!g_sceneStation.have || g_sceneStation.boss != g_sceneFight.boss || g_sceneStation.stage != stage || recenter) {
        double headYaw = 0;
        if (!stereo::robust_heading(pose->m, &headYaw)) stereo::basis_yaw(pose->m, &headYaw);   // 1.7.216: also right while you look steeply up / down (the old yaw fell back to 0 there = a view turned off-centre)
        if (!g_sceneStation.place(g_sceneFight.boss, stage, base, mouth, yaw, headYaw)) ++s_wait.placeFail;
        else {
          stereo_comfort_hold(0);   // 1.7.182: placed: the held black fades up now
          stereo_comfort_transition();
          log_line("SCENEVIEW rooftop station stage=%d mouth=%.1f,%.1f,%.1f eye=%.1f,%.1f,%.1f yaw=%.1f down=%.1f; headset motion remains tracked", stage,
                   (double)mouth[0], (double)mouth[1], (double)mouth[2], (double)g_sceneStation.eye[0], (double)g_sceneStation.eye[1], (double)g_sceneStation.eye[2], g_sceneStation.yaw * 57.2957795, g_sceneStation.pitchDown * 57.2957795);
        }
      }
    }
    if (g_sceneStation.have) {
      g_sceneStation.offset(base, yaw);
      for (int i = 0; i < 3; ++i) base[i] = g_sceneStation.eye[i];
      yaw = g_sceneStation.yaw;
    }
  }
  if (pairMode && !reused) {
    g_pair.valid = 1;
    g_pair.qpc = qpc_now();
    g_pair.yaw = yaw;
    for (int i = 0; i < 3; ++i) g_pair.baseEye[i] = base[i];
    g_pair.pose = poseNow;
    if (phase == 0) InterlockedIncrement(&g_st.pairFirst);
  }
  if (!pairMode) g_pair.valid = 0;

  a.yaw = yaw;
  a.reused = reused;
  a.pairQ = pairMode ? g_pair.qpc : 0;
  a.spec = spec;
  a.pairRole = spec ? 2 : (pairMode ? (phase == 1 ? 2 : 1) : 0);
  stereo::level_basis(a.yaw, a.level);
  vm::mul(a.level, pose->m, a.view);
  a.headHeadingOk = stereo::robust_heading(a.view, &a.headHeading);
  if (!spec && engine_scene_arms(0) && g_sceneStation.have)
    sceneview::aim_down(a.view, g_sceneStation.facingYaw, g_sceneStation.pitchDown);
  if (!spec && !reused && a.headHeadingOk && engine_scene_arms(0) && g_sceneStation.have) roof_auto_center_step(a.headHeading);
  if (!vm::is_rotation(a.view)) return "stereo gate: view basis not a valid rotation";
  a.eye = spec ? 1 : (g_ctl.stereoNextEye & 1);  // the render thread alternates it once per presented frame (1.7.38: the chest-camera picture counts as the second eye of the pair before it)
  {
    // 1.7.9: while the monitor view is on, the game draws wider than the headset needs (monitor_wide_pct, 125 = a quarter wider: about 121 degrees across instead of 110). The headset only uses the
    // middle (its texture window shrinks with the real tangents), the pixel density stays above the panel's; the PC window can show the whole width.
    double widen = 1.0;
    if (g_ctl.monitorView) { widen = (double)g_ctl.monitorWidePct / 100.0; if (!(widen >= 1.0)) widen = 1.0; if (widen > 1.5) widen = 1.5; }
    a.needH = (double)sp.needTanH * widen;
    a.needV = (double)sp.needTanV * widen;
  }
  a.wide = g_ctl.stereoWide != 0;
  for (int i = 0; i < 12; ++i) a.pose34[i] = pose->raw34[i];
  double strength = (double)g_ctl.stereoStrengthPct / 100.0;
  // 0.26: apparent world size. The eyes' distance and the head's movement are
  // divided by it: eyes closer together = everything looks bigger. (The eye
  // height has its own factor, sizePct, in compute_first_person_eye.)
  double world = stereo::world_factor((int)g_ctl.worldPct);
  double eyeXFeet = (double)sp.eyeX[a.eye] * stereo::kFeetPerMetre * strength * world * (g_ctl.swapEyes ? -1.0 : 1.0);
  float headFeet[3] = {0, 0, 0};
  int move = g_ctl.headMove != 0;
  if (move) {
    for (int i = 0; i < 3; ++i) {
      double m = pose->pos[i];
      if (m > 1.0) m = 1.0;   // never more than 1 m from the recenter point
      if (m < -1.0) m = -1.0;
      headFeet[i] = (float)(m * stereo::kFeetPerMetre * world);
      if (pose->pos[i] > 1.0 || pose->pos[i] < -1.0) ++g_hm.clamped;
      g_hm.last[i] = (float)pose->pos[i];
      if (pose->pos[i] > g_hm.mx[i]) g_hm.mx[i] = (float)pose->pos[i];
      if (pose->pos[i] < g_hm.mn[i]) g_hm.mn[i] = (float)pose->pos[i];
    }
    ++g_hm.n;
  }
  float fin[3];
  // 1.7.216: on the roof the picture is pitched down toward Stay Puft (aim_down) and so are the tracked hands / gun, but the head's own movement from the recenter point
  // was still laid out on the level (yaw-only) axes: lean, nod and look about moved the eyes in a different direction from the way the picture was turned (eyes felt off-centre,
  // "the view is forced down for VR"). The head movement is pitched by the same turn now, about the roof anchor. Only while the roof view is active.
  float levelEye[9];
  for (int i = 0; i < 9; ++i) levelEye[i] = a.level[i];
  if (!spec && engine_scene_arms(0) && g_sceneStation.have) sceneview::aim_down(levelEye, g_sceneStation.facingYaw, g_sceneStation.pitchDown);
  stereo::eye_position(base, levelEye, a.view, move ? headFeet : nullptr, eyeXFeet, fin);
  if (!readable_floats_ok(fin, 3)) return "stereo gate: eye position not finite";
  if (!spec && engine_scene_arms(0) && g_sceneStation.have) {   // 1.7.218 data: how far the pitched head movement (1.7.216) moved the eye compared with the old level layout
    float finOld[3]; stereo::eye_position(base, a.level, a.view, move ? headFeet : nullptr, eyeXFeet, finOld);
    const double dx = (double)fin[0] - finOld[0], dy = (double)fin[1] - finOld[1], dz = (double)fin[2] - finOld[2];
    g_roofHeadShiftCm = (float)(vm::dsqrt(dx * dx + dy * dy + dz * dz) * 30.48);
  }
  for (int i = 0; i < 3; ++i) g_armEye[i] = fin[i];
  stereo::eye_position(base, levelEye, a.view, move ? headFeet : nullptr, 0.0, a.headCenter);
  a.feetPerMetre = stereo::kFeetPerMetre * world;
  if (spec) {   // 1.7.38: the chest camera replaces the eye's view and position (hands, body and gun state stay the pair's)
    float cam[3];
    ArmStereo t = a;
    chest_cam_build(t, cam, sample);
    if (readable_floats_ok(cam, 3)) {
      for (int i = 0; i < 9; ++i) a.view[i] = t.view[i];
      for (int i = 0; i < 3; ++i) g_armEye[i] = cam[i];
    } else a.spec = 0;
  }
  if (!reused) body_update(b, base, a.headCenter, pose, yaw, fpEye, move ? headFeet : nullptr, a.view);   // 0.52
  a.feetPerMetre = stereo::kFeetPerMetre * world;
  if (sample)
    log_line("STEREOEYE frame=%d eye=%s pair=%d phase=%d reused=%d yaw=%.4f eyeXFeet=%.4f strength=%d height=%d world=%d swap=%d headMove=%d "
             "headFeet=%.3f,%.3f,%.3f base=%.3f,%.3f,%.3f final=%.3f,%.3f,%.3f firstPerson=%d", (int)g_ctl.worldFrames,
             a.eye ? "right" : "left", pairMode, phase, reused, a.yaw, eyeXFeet, (int)g_ctl.stereoStrengthPct,
             (int)g_ctl.sizePct, (int)g_ctl.worldPct, (int)g_ctl.swapEyes, move, headFeet[0], headFeet[1], headFeet[2], base[0], base[1], base[2], fin[0], fin[1],
             fin[2], fpEye);
  return nullptr;
}
#endif

#if GBVR_HEADTRACK
// ---- 1.5 the body follows your head (and snap turn) ----------------------------------------------------------------------------------------
// followmath.h explains the idea. Here: once per prepared frame (camera thread) the game's heading is measured, the headset rotation is turned back by what the
// probe itself made the game turn (vr_follow_add), the error between head and body is fed to follow::step, and the resulting push on the right stick axis is
// handed to controllers.cpp (follow_push_get). Snap turns arrive from controllers.cpp as step counts (follow_snap_request).
static struct FollowDrv {
  follow::State s;
  int haveCam, lastRun, lastSign, lastNoAnswer;
  double lastCam, lastE, runCam0, runE0, dt;
  int64_t lastQ, runQ0;
  volatile LONG uX1000, snapReq;
  volatile LONG smoothMd;      // 1.7.81: smooth-turn degrees x 1000 asked by controllers.cpp since the last frame (+ = right)
  long smoothFrames, smoothDropped; double smoothDegTotal;   // 1.7.81 numbers for the log
  volatile int64_t uQpc;
  volatile LONG eMicro;      // 1.7.8: the head's yaw from the game's heading (rad x 1e6), for the walk direction (controllers.cpp)
  volatile int64_t eQpc;
  long logged, framesAllowed, framesBlocked, framesUser, framesForced, snapsDone, snapsDropped;
  double bigRunDeg;
  // 1.7.8: is the game's own camera heading alive? (1.7.5 / 1.7.7 reports: it stayed at one value for the whole play)
  long camFrames, camMoved, camStillWalk, camStillPush, camStillLogged;
  int64_t snapQ; int64_t holdUntilQ; long holdFrames, holdHeldFrames, holdJumps, holdDegX100, holdMaxX100;   // 1.7.17 HOLDVIEW
  int64_t camMoveQ, camStillQ; double camFirst, camMin, camMax; int camSeen;
} g_fd;
int follow_gave_up() { return follow::gave_up(g_fd.s) ? 1 : 0; }   // 1.7.6: two misses in a row: controllers.cpp lets the real right stick turn the game
int follow_snap_request(int steps) { if (steps) InterlockedAdd(&g_fd.snapReq, steps); return steps; }
int follow_smooth_request(double deg) { const LONG md = (LONG)(deg * 1000.0); if (md) InterlockedAdd(&g_fd.smoothMd, md); return md != 0; }   // 1.7.81
int follow_turn_own() { return (g_ctl.turnSnap || g_ctl.turnSmoothOwn) ? 1 : 0; }   // 1.7.81: snap, or smooth made by the mod: the game's own stick turn is not used
float follow_push_get() {
  const int64_t q = g_fd.uQpc;
  if (!q || (qpc_now() - q) * 1000 / qpc_freq() > 150) return 0.0f;
  return (float)g_fd.uX1000 / 1000.0f;
}
static void follow_publish(double u) { g_fd.uX1000 = (LONG)(u * 1000.0); g_fd.uQpc = qpc_now(); }
int follow_head_yaw(double* eRad) {   // 1.7.8: fresh within 150 ms
  const int64_t q = g_fd.eQpc;
  if (!q || (qpc_now() - q) * 1000 / qpc_freq() > 150) return 0;
  if (eRad) *eRad = (double)g_fd.eMicro * 1.0e-6;
  return 1;
}
static void follow_pre(const uint8_t* camb) {
  FollowDrv& d = g_fd;
  const int64_t now = qpc_now();
  const double dt = d.lastQ ? (double)(now - d.lastQ) / (double)qpc_freq() : 0.011;
  d.lastQ = now;
  d.dt = (dt > 0.001 && dt < 0.25) ? dt : 0.011;   // the real frame time is used by follow_post too
  if (engine_scene_arms(0) && g_sceneStation.have) {
    // The station has a fixed horizon. Only explicit player turns rotate it.
    follow_publish(0.0); d.haveCam = 0;
    const LONG steps = InterlockedExchange(&d.snapReq, 0);
    const LONG smMd = InterlockedExchange(&d.smoothMd, 0);   // 1.7.81
    int mag = 0, blocked = 0; controllers_turn_info(&mag, &blocked);
    if (!blocked && !vrmenu_is_open()) {
      if (steps) vr_follow_add(follow::snap(d.s, (double)g_ctl.turnSnapDeg * steps));
      if (!g_ctl.turnSnap && g_ctl.turnSmoothOwn) {
        if (smMd) { vr_follow_add(follow::smooth(d.s, (double)smMd * 0.001)); ++d.smoothFrames; }   // 1.7.81: the same speed setting as everywhere
      } else if (!g_ctl.turnSnap) {
        HandsRaw raw;
        if (controllers_raw(&raw) && raw.validR && vm::dabs(raw.stickX) > 0.18)
          vr_follow_add(-follow::rad(90.0) * raw.stickX * d.dt);
      }
    }
    return;
  }
  if (!g_ctl.stereoActive || !memory_readable(camb + layout::kCamEuler + 4, 4)) { d.haveCam = 0; InterlockedExchange(&d.snapReq, 0); InterlockedExchange(&d.smoothMd, 0); return; }
  const double cy = *(const float*)(camb + layout::kCamEuler + 4);
  if (!(cy == cy) || cy > 1.0e4 || cy < -1.0e4) { d.haveCam = 0; InterlockedExchange(&d.snapReq, 0); InterlockedExchange(&d.smoothMd, 0); return; }
  const follow::Cfg c = follow::make_cfg(g_ctl.turnFollow != 0, (double)g_ctl.turnFollowDeg, g_ctl.turnFollowWalk != 0);
  if (d.haveCam) {
    const int wasSign = d.s.sign, wasNo = (int)d.s.noAnswer, wasCuts = (int)d.s.cuts;
    const double dA = follow::on_camera_delta(d.s, cy - d.lastCam, dt, c);
    if (dA != 0.0) vr_follow_add(dA);
    {   // 1.7.17 HOLDVIEW: the 1.7.16 log: while the capture stream / the stream was held the GAME turned its own heading (4.6 rad in 7 s, the pushes of the probe were not active) and the picture turned with it = "spin".
      // The picture follows the world, not the game's heading: a smooth heading change that is not ours is added to the picture offset while a trigger is held and for 1.5 s after.
      const double dcAll = follow::wrap(cy - d.lastCam);
      pad::State ps2; int held = 0;
      if (controllers_pad_state(&ps2)) held = ((ps2.buttons & 0x0100) || ps2.rt > 40 || ps2.lt > 40) ? 1 : 0;
      if (held) d.holdUntilQ = now + qpc_freq() * 3 / 2;
      int um4 = 0, bl4 = 0; controllers_turn_info(&um4, &bl4);
      const int userPush = !follow_turn_own() && um4 > 200;
      const double ad = dcAll < 0 ? -dcAll : dcAll;
      if (g_ctl.holdView && dA == 0.0 && (now - d.snapQ) > qpc_freq() * 6 / 10 && now < d.holdUntilQ && g_ctl.stereoActive && !vrmenu_is_open() && !bl4 && !forced_turn_block() && !userPush && ad > 1.0e-5) {
        if (ad <= follow::rad(170.0)) {   // 1.7.21: was 20 deg; the 1.7.20 log had 545 bigger jumps while a trigger was held = the spin you still saw
          vr_follow_add(dcAll);
          ++d.holdFrames; d.holdDegX100 += (long)(follow::deg(ad) * 100.0);
          if ((long)(follow::deg(ad) * 100.0) > d.holdMaxX100) d.holdMaxX100 = (long)(follow::deg(ad) * 100.0);
        } else ++d.holdJumps;
      }
      if (held) ++d.holdHeldFrames;
    }
    if (d.s.sign != wasSign && d.logged < 80) { ++d.logged; log_line("TURNFOLLOW learned: a push to the right on the right stick turns the game %s (the camera moved %.1f deg with the first push)", d.s.sign > 0 ? "RIGHT (as expected)" : "LEFT (so the probe pushes the other way from now on)", follow::deg(d.s.calibSum < 0 ? -d.s.calibSum : d.s.calibSum)); }
    if ((int)d.s.noAnswer != wasNo) {
      // 1.7.6: the 1.7.5 report: the game never turned, every snap turn still moved the picture, so the body, the walk direction and the aim stayed behind (movement and gun "reversed").
      // A miss puts the picture back on the body: the probe forgets the turning it did for you.
      // 1.7.8: the picture turn is KEPT (1.7.6 took it back, which left snap turns useless when the game's camera did not move): the stick is turned to the head, so the body goes where you look anyway
      const double a0 = vr_follow_total();
      if (d.logged < 80) { ++d.logged; log_line("TURNFOLLOW no answer #%ld (%ld in a row): the game's camera did not turn for %.1f s of pushing (menu, pause, cut-scene, a locked camera?) - the picture turn of %.0f deg is kept, the left stick walks to the head (WALKHEAD), resting for %.0f s", (long)d.s.noAnswer, d.s.noAnswerStreak, c.giveUpSec, follow::deg(a0), c.coolSec); }
    }
    {   // the game turned for your own right stick: it does answer, so the misses start from zero
      int um2 = 0, bl2 = 0; controllers_turn_info(&um2, &bl2);
      const double dc = follow::wrap(cy - d.lastCam);
      if (um2 > 200 && (dc > follow::rad(0.3) || dc < -follow::rad(0.3)) && d.s.noAnswerStreak) { follow::note_answer(d.s); if (d.logged < 80) { ++d.logged; log_line("TURNFOLLOW the game turned for your own right stick (%.1f deg): snap turn and follow are back", follow::deg(dc)); } }
    }
    if ((int)d.s.cuts != wasCuts && d.logged < 80) { ++d.logged; log_line("TURNFOLLOW camera jump of %.0f deg while following: not counted as our turn (cut-scene or respawn?)", follow::deg(follow::wrap(cy - d.lastCam))); }
  }
  if (d.haveCam) {   // 1.7.8: GAMECAM watchdog
    const double dcw = follow::wrap(cy - d.lastCam);
    int um3 = 0, bl3 = 0; controllers_turn_info(&um3, &bl3);
    const int walking = controllers_move_mag() > 300;
    ++d.camFrames;
    if (!d.camSeen) { d.camSeen = 1; d.camFirst = d.camMin = d.camMax = cy; d.camMoveQ = now; }
    if (cy < d.camMin) d.camMin = cy;
    if (cy > d.camMax) d.camMax = cy;
    if (dcw > 0.0005 || dcw < -0.0005) { ++d.camMoved; d.camMoveQ = now; d.camStillQ = 0; }
    else {
      if (walking) ++d.camStillWalk;
      if (um3 > 200) ++d.camStillPush;
      if (walking && !d.camStillQ) d.camStillQ = now;
      if (!walking) d.camStillQ = 0;
      if (d.camStillQ && (now - d.camStillQ) > 6 * qpc_freq() && d.camStillLogged < 6 && !bl3) {
        ++d.camStillLogged; d.camStillQ = now;
        log_line("GAMECAM the game's camera heading has stayed at %.3f rad for 6 s of walking (right stick push %.2f): this game state ignores the right stick; the probe walks to the head instead (WALKHEAD)", cy, (double)um3 / 1000.0);
      }
    }
  }
  d.lastCam = cy; d.haveCam = 1;
  const LONG n = InterlockedExchange(&d.snapReq, 0);
  const LONG smMd = InterlockedExchange(&d.smoothMd, 0);   // 1.7.81 smooth turn: degrees x 1000 since the last frame
  if (smMd) {
    int allowedS = g_ctl.stereoActive && !vrmenu_is_open();
    int umS = 0, blockedS = 0;
    controllers_turn_info(&umS, &blockedS);
    if (blockedS || forced_turn_block() || cine_blend() > 0.5) allowedS = 0;
    if (allowedS) {
      const double dg = (double)smMd * 0.001;
      vr_follow_add(follow::smooth(d.s, dg));
      d.snapQ = now;   // the HOLDVIEW rule waits 0.6 s after a turn of ours, so it never fights the smooth turn
      ++d.smoothFrames; d.smoothDegTotal += dg < 0 ? -dg : dg;
      if (d.smoothFrames == 1 || d.smoothFrames == 200) log_line("TURNSMOOTH #%ld: the picture turns by itself while the right stick is held sideways (this frame %+.2f deg, speed setting %d deg/s at full stick, head from body %.1f deg, game heading %.1f deg)", d.smoothFrames, dg, (int)g_ctl.turnSmoothDps, follow::deg(d.lastE), follow::deg(cy));
    } else ++d.smoothDropped;
  }
  if (n) {
    int allowed = g_ctl.stereoActive && !vrmenu_is_open();
    int um = 0, blocked = 0;
    controllers_turn_info(&um, &blocked);
    if (blocked || forced_turn_block() || cine_blend() > 0.5) allowed = 0;   // 1.7.26: also while the cutscene guard is on
    if (allowed) {
      const double stepDeg = (double)g_ctl.turnSnapDeg * (double)n;
      vr_follow_add(follow::snap(d.s, stepDeg));
      d.snapQ = now;
      ++d.snapsDone;
      if (d.logged < 80) { ++d.logged; log_line("TURNSNAP %+.0f deg: the picture turned at once, the body follows (head from body now %.1f deg, game heading %.1f deg, offset kept %.1f deg)", stepDeg, follow::deg(d.lastE), follow::deg(cy), follow::deg(vr_follow_total())); }
    } else { ++d.snapsDropped; if (d.logged < 80) { ++d.logged; log_line("TURNSNAP dropped (%s)", blocked ? "menu / wheel / D layer / not in a level" : "the game moves the character itself"); } }
  }
}
static void follow_post(const GbvrPose& p) {
  FollowDrv& d = g_fd;
  double e = 0.0;
  if (!stereo::basis_yaw(p.m, &e)) e = d.lastE;
  d.lastE = e;
  { double ew = follow::wrap(e); g_fd.eMicro = (LONG)(ew * 1.0e6); g_fd.eQpc = qpc_now(); }   // 1.7.8
  if (engine_scene_arms(0) && g_sceneStation.have) { follow_publish(0.0); d.s.active = 0; return; }
  const int64_t now = qpc_now();
  const double dt = d.dt > 0.0 ? d.dt : 0.011;
  const follow::Cfg c = follow::make_cfg(g_ctl.turnFollow != 0, (double)g_ctl.turnFollowDeg, g_ctl.turnFollowWalk != 0);
  int um = 0, blocked = 0;
  controllers_turn_info(&um, &blocked);
  int allowed = g_ctl.stereoActive && !vrmenu_is_open() && !blocked && !forced_turn_block() && !(cine_blend() > 0.5);   // 1.7.26
  const int userBusy = !follow_turn_own() && um > 200;   // smooth-turn mode: your own stick push wins; in snap mode the stick only makes the snap (1.7.8: also after misses)
  if (allowed) ++d.framesAllowed; else if (forced_turn_block()) ++d.framesForced; else ++d.framesBlocked;
  if (userBusy) ++d.framesUser;
  const int wasActive = d.s.active;
  const double mvMag = (double)controllers_move_mag() / 1000.0;
  const double u = follow::step(d.s, e, dt, c, allowed, userBusy, mvMag);
  follow_publish(u);
  if (d.s.active && !wasActive) {
    d.runQ0 = now; d.runCam0 = d.lastCam; d.runE0 = e;
    if (d.logged < 80) { ++d.logged; log_line("TURNFOLLOW start #%ld: head is %.1f deg from the body (limit %.0f deg, walking limit %.0f deg, left stick %.2f), sign %d, push %.2f", d.s.runs, follow::deg(e), follow::deg(c.startRad), follow::deg(c.walkStartRad), mvMag, d.s.sign, u); }
  } else if (!d.s.active && wasActive) {
    const double turned = follow::deg(follow::wrap(d.lastCam - d.runCam0));
    if (turned > d.bigRunDeg || -turned > d.bigRunDeg) d.bigRunDeg = turned < 0 ? -turned : turned;
    if (d.logged < 80) { ++d.logged; log_line("TURNFOLLOW end #%ld after %.2f s: the body turned %.1f deg (head from body %.1f -> %.1f deg), offset kept %.1f deg | strongest push %.2f, weakest the game answered so far %.2f", d.s.runs, (double)(now - d.runQ0) / (double)qpc_freq(), turned, follow::deg(d.runE0), follow::deg(e), follow::deg(vr_follow_total()), d.s.maxPush, d.s.learnedMin > c.minStick ? d.s.learnedMin : c.minStick); }
  }
}
static void follow_stop() { follow_publish(0.0); if (g_fd.s.active) { g_fd.s.active = 0; g_fd.s.forced = 0; g_fd.s.lastU = 0.0; } }
static void speed_report() {
  static const char* const nm[4] = {"0.30-0.50", "0.50-0.70", "0.70-0.90", "0.90-1.00"};
  char b[900]; int n = 0;
  for (int r = 0; r < 2; ++r) for (int k = 0; k < 4 && n < 760; ++k) {
    const double sp = g_spd[r][k].secs > 0.0 ? g_spd[r][k].dist / g_spd[r][k].secs : 0.0;
    n += wsprintfA(b + n, " [%s stick, %s: %d.%d ft/s over %d frames, fastest frame %d.%d]", nm[k], r ? "run asked" : "walking", (int)sp, (int)(sp * 10.0) % 10, (int)g_spd[r][k].n, (int)g_spd[r][k].peak, (int)(g_spd[r][k].peak * 10.0) % 10);
  }
  b[n] = 0;
  log_line("RUNSPEED average speed of the character by left-stick push (1 ft/s = 0.3 m/s; the game moves in steps, so single frames jump):%s", b);
}
static void speedboost_report(LONG frame);   // 1.7.8
static void goggles_report(LONG frame);      // 1.7.9
static void follow_report(LONG frame) {
  speed_report();
  speedboost_report(frame);
  goggles_report(frame);
  const FollowDrv& d = g_fd;
  log_line("GAMECAM frame=%d the game's camera heading: now %.4f rad, first %.4f, lowest %.4f, highest %.4f | frames %ld, heading moved in %ld | NOT moving while the left stick walked %ld frames, while the right stick was pushed %ld frames | seconds since it last moved %.1f (a heading that never moves = the game ignores the right stick here; 1.7.8 walks to the head instead)",
           (int)frame, d.lastCam, d.camFirst, d.camMin, d.camMax, d.camFrames, d.camMoved, d.camStillWalk, d.camStillPush, d.camMoveQ ? (double)(qpc_now() - d.camMoveQ) / (double)qpc_freq() : 0.0);
  log_line("HOLDVIEW frame=%d on=%d | frames a trigger was held (or 1.5 s after) %ld, heading changes of the GAME absorbed into the picture %ld (total %.1f deg, biggest single frame %.2f deg), too big to absorb (cut) %ld | 1.7.17: the picture stays on the world while the game turns its own heading during capture / fire",
           (int)frame, (int)g_ctl.holdView, d.holdHeldFrames, d.holdFrames, (double)d.holdDegX100 / 100.0, (double)d.holdMaxX100 / 100.0, d.holdJumps);
  log_line("TURNFOLLOW frame=%d follow=%d start=%ddeg snap=%d step=%ddeg | sign=%d runs=%ld activeFrames=%ld maxHeadFromBody=%.0fdeg biggestRun=%.0fdeg offsetKept=%.1fdeg camera-turns-counted=%ld (%.0f deg in all) cuts=%ld noAnswer=%ld flips=%ld | snaps done=%ld dropped=%ld | frames allowed=%ld blocked=%ld forced-move=%ld own-stick=%ld",
           (int)frame, (int)g_ctl.turnFollow, (int)g_ctl.turnFollowDeg, (int)g_ctl.turnSnap, (int)g_ctl.turnSnapDeg, d.s.sign, d.s.runs, d.s.activeSteps, follow::deg(d.s.maxErr), d.bigRunDeg, follow::deg(vr_follow_total()),
           d.s.attributedSteps, follow::deg(d.s.attributed < 0 ? -d.s.attributed : d.s.attributed), d.s.cuts, d.s.noAnswer, d.s.flips, d.snapsDone, d.snapsDropped, d.framesAllowed, d.framesBlocked, d.framesForced, d.framesUser);
  log_line("TURNMISS frame=%d noAnswer=%ld streak=%ld gaveUp=%d boosts=%ld realigns=%ld pushRaises=%ld weakestPush=%.2f firstPush=%.2f (1.7.6: a miss undoes the picture turn, the next push is full strength, a stalled push gets stronger)", (int)frame, (long)d.s.noAnswer, d.s.noAnswerStreak, follow::gave_up(d.s) ? 1 : 0, d.s.boosts, d.s.realigns, d.s.raises, d.s.learnedMin > 0.58 ? d.s.learnedMin : 0.58, 0.58);
  log_line("TURNWALK frame=%d walkBoost=%d walkRuns=%ld walkSteps=%ld of activeSteps=%ld walkLimit=%.0fdeg walkStop=%.0fdeg ramp up=%.1f/s down=%.1f/s | leftStick=%d/1000 sprintToggle=%d sprintViaJump=%d", (int)frame, (int)g_ctl.turnFollowWalk, d.s.walkRuns, d.s.walkSteps, d.s.activeSteps,
           follow::deg(follow::make_cfg(1, (double)g_ctl.turnFollowDeg, 1).walkStartRad), follow::deg(follow::make_cfg(1, (double)g_ctl.turnFollowDeg, 1).walkStopRad), follow::make_cfg(1, 35, 1).upRate, follow::make_cfg(1, 35, 1).downRate, controllers_move_mag(), (int)g_ctl.sprintToggle, (int)g_ctl.sprintViaJump);
}

static void head_aim_publish(void* cam, const ArmStereo& st);   // 0.32, defined with the head-aim hook
static uintptr_t head_aim_actor();   // 0.76: the player's actor as last published by head_aim_publish

// ---- 1.7.9 sprint = a plain speed boost, done in the game's main loop ---------------------------------------------------------------------------------------------------------------
// boostmath.h explains it. The 1.7.8 log proved that the game's character update (0x84390) never ran for the player (0 player ticks in 16000 frames), so nothing was boosted.
// Now the state machine lives in boost_after_sim(), called from the app-simulate hook right after every real simulation (the place that is known to run once per game tick):
//   * it measures the net motion of the player's actor since the last tick (pre-nudge to pre-nudge, so what we added and the game kept counts), judges which way works
//   * the "nudge" way adds (k - 1) x the step the game made on its own to the actor and to its physics body
// The character-update hook is kept: it counts every caller (so the log shows what 0x84390 really is) and, if it does run for the player, the velocity and time ways become possible.
typedef uintptr_t(__fastcall* PFN_CharUpdate)(void* self, float dt);
static PFN_CharUpdate o_charUpdate;
static struct SpeedBoost {
  boost::State s; boost::Cfg c; int cfgPct, cfgMethod, haveCfg, hooked;
  double prePos[3]; int havePos; int64_t lastQ; double lastDt, lastWall, lastDist, dirX, dirZ, lastNudge, lastStep;
  double lastW[2], lastPlain[2], lastK; int wroteLast;
  long simCalls, simTicks, boostedTicks, forcedSkips, badPos, noActor, pausedSkips, dtBad, noNudgeMove;
  long velWrites, velPersist, velSmall, velSeen, bodyBad, timeWrites, nudges, nudgeBody, nudgeBodyFar, nudgeScanBody, nudgeScanActor, scanLogged; int scanOffs[10], scanOffN;
  double vcSum, vcReal, posOffX, posOffZ, posOffMax, xfOffX, xfOffZ; long vcN, vcZero, posOffN, xfN;
  double maxK, nudgeSum, nudgeMax, wallSum, stepSum; long wallN; int lastMethod, lastLocked; long logged;
  double walkTotal, lastJump; long jumps, lastJumpFrame;   // PROGRESS: how far the player walked, and how often he was moved in one step by more than 5 ft (level change, cut-scene, respawn)
  // the character update, every caller
  long charAll, charPlayer; uintptr_t charThis[6], charVt[6]; long charThisN[6]; int charKinds;
  int dumpStand, dumpWalk; int dashHold;
} g_sb;
// 1.7.22 blink dash: the double-tap detector (dashmath.h) runs once per game tick next to the speed boost and asks the same nudge way for a short burst.
// 1.7.111 data for the log: what the analog finger inputs are doing (index 0 = right hand, 1 = left)
static struct { int g[2], th[2], tr[2], pt[2], anaSeen[2], thumbSeen[2], trigSeen[2]; long passes[2], pointPasses[2]; } g_fa;
static struct { long passes, onGunPasses, switches, blendPasses, freePasses; int lastWrapX100, lastThumbX100, lastIdxX100, lastPinkX100, lastGripL, lastTrigX100; } g_lf;   // 1.7.23 left-hand finger stats (LEFTFINGERS)
static dash::State g_dash;
static dash::Cfg g_dashCfg;
static struct DashStat { int init; long ticks, starts, noWay, blockedForced, nudges, skippedSamples; double feet, biggestK, lastK; long logged; } g_ds;
static const char* sb_name(int m) { return m == boost::kVelocity ? "velocity" : m == boost::kTime ? "time" : m == boost::kNudge ? "nudge" : "off"; }
static int sb_finite3(const float* p) { return vm::is_finite_f(p[0]) && vm::is_finite_f(p[1]) && vm::is_finite_f(p[2]); }
static uintptr_t sb_body(uintptr_t self) {   // the player's physics body (velocity at +0x170, position at +0x90), or 0
  if (!memory_readable((const void*)(self + layout::kOffCharBody), 8)) return 0;
  const uintptr_t b = *(const uintptr_t*)(self + layout::kOffCharBody);
  if (!b || (b & 7) || !memory_readable((const void*)b, 0x130)) return 0;
  return b;
}
static void sb_dump_body(const char* tag, uintptr_t body) {   // 80 floats of the body, +0x80 .. +0x1BF, in two lines
  if (!memory_readable((const void*)(body + 0x130), 0x90)) return;
  log_floats(tag, (const float*)(body + 0x80), 40);
  log_floats(tag, (const float*)(body + 0x120), 40);
}
static void sb_config(SpeedBoost& b) {
  const int pct = (int)g_ctl.sprintSpeedPct, meth = (int)g_ctl.sprintSpeedMethod;
  if (!b.haveCfg) { b.haveCfg = 1; b.cfgPct = pct; b.cfgMethod = meth; b.c = boost::make_cfg(pct); boost::reset(b.s, meth); b.lastMethod = b.s.method; }
  else {
    if (pct != b.cfgPct) { b.cfgPct = pct; b.c = boost::make_cfg(pct); }
    if (meth != b.cfgMethod) { b.cfgMethod = meth; boost::reset(b.s, meth); b.lastMethod = b.s.method; b.lastLocked = 0; }
  }
}
// ---- 1.7.36 knockdown comfort ---------------------------------------------------------------------------------------------------------------
// A ghost's knock-down on the player (CGhostbuster::knockBack, layout.h) is not played. For knock_ms the player walks slower (the body velocity is scaled),
// the edges go dark (handmodel vignette reads engine_knock_strength) and the gun sways (controllers.cpp). The game's own time is NOT slowed.
static struct { volatile unsigned startMs, durMs; volatile LONG active; long calls, took, passed, flagClears, consumerCalls, consumerIntercepts, walkTicks, logged, flagLogged; float lastPlain[2], lastW[2]; int wrote; int hooked, consumerHooked;
  // 1.7.93: the player's knock-backs (what the game sent), the Stay Puft level (comfort off there) and the rescue (comfort off for the run after a stuck player)
  volatile LONG off, rescueReq; long playerCalls, bossPassed, rescues, rescueAsked, callLogs; float impact[3], force; int haveImpact; int64_t takenQ; } g_kn;
typedef void (__fastcall *PFN_KnockBack)(void*, const float*, float);
static PFN_KnockBack o_knockBack;
typedef void (__fastcall *PFN_KnockConsumer)(void*, float);
static PFN_KnockConsumer o_knockConsumer;
int engine_player_forced() { return g_forced.forced ? 1 : 0; }
static void knock_begin(const char* source) {
  if (g_kn.active && engine_knock_strength() > 0.0) return;
  g_kn.startMs = GetTickCount(); g_kn.durMs = (unsigned)g_ctl.knockMs; g_kn.wrote = 0; g_kn.active = 1;
  haptics_add(0, hap::kSrcKnock, 0.30f, 140); haptics_add(1, hap::kSrcKnock, 0.30f, 140);   // 1.7.190: a light rumble starts it (the rest of the window renews it, controllers.cpp)
  if (g_kn.logged++ < 40) log_line("KNOCKDOWN comfort started via %s: %u ms, walk %d%%, gun sway %d deg, black edges %d%%", source, g_kn.durMs, (int)g_ctl.knockWalkPct, (int)g_ctl.knockAimDeg, (int)g_ctl.knockDarkPct);
}
static double knock_env() {
  if (!g_kn.active) return 0.0;
  const double s = knock::strength((double)(unsigned)(GetTickCount() - g_kn.startMs), (double)g_kn.durMs);
  if (knock::expired((unsigned)(GetTickCount() - g_kn.startMs), g_kn.durMs)) { g_kn.active = 0; g_kn.wrote = 0; static int s_ke; if (s_ke++ < 20) log_line("KNOCKDOWN comfort ended after %u ms", g_kn.durMs); }
  return s;
}
// 1.7.93: the comfort replacement for the game's knock-back is used only when it is on, the 3D view runs, the run has not been switched off by the rescue below, and the
// player is not in a level with Stay Puft. Why: the game's knock-back is what pushes the player away from where a thrown object lands (its impulse goes from the impact point
// through the player), and skipping it is the best suspect for the "stuck in Times Square after the sign is thrown" reports (the character stands inside the debris; the stick is
// pushed, the position does not change). The game's own fall plays in that level; the 3 s comfort window is for the ghosts' knock-downs everywhere else.
static int knock_boss_present(uintptr_t player) {
#if GBVR_HEADTRACK
  uintptr_t boss = 0, world = 0;
  return player && fight_staypuft(player, &boss, &world) == 1;
#else
  (void)player; return 0;
#endif
}
static int knock_comfort_on(uintptr_t player) {
  if (!g_ctl.knockComfort || !g_ctl.stereoActive || g_kn.off) return 0;
  // 1.7.190 "remove getting knocked down" (the 23:31 video: the roof fight's knock-down tumbled the view, switched the arms-only body off and the whole coat, the chest radio and a loose off hand showed for the rest of the fight):
  // in the Stay Puft ROOF fight (the scripted rooftop view, floating arms) the soft knock-down is used too. The Times Square escort keeps the game's own fall (the stuck-in-debris reports of 1.7.93).
  (void)knock_boss_present;   // 1.7.191: the soft knock-down is used in the WHOLE game (the stuck rescue below still protects the Times Square escort)
  return 1;
}
double engine_knock_strength() { return (g_ctl.knockComfort && !g_kn.off) ? knock_env() : 0.0; }
double engine_knock_time_sec() { return g_kn.active ? (double)(unsigned)(GetTickCount() - g_kn.startMs) * 0.001 : 0.0; }
static void __fastcall hk_knock_back(void* self, const float* dir, float force) {
  ++g_kn.calls;
  const uintptr_t ret = (uintptr_t)GBVR_RETURN_ADDRESS();
  const int isPlayer = self && (uintptr_t)self == head_aim_actor();
  const int take = isPlayer && knock_comfort_on((uintptr_t)self);
  if (isPlayer) {   // 1.7.93: what the game sent (from where, how hard, who called) and what was done with it; the first 40
    ++g_kn.playerCalls;
    float imp[3] = {0, 0, 0}; int haveImp = 0;
    if (dir && memory_readable(dir, 12)) { for (int i = 0; i < 3; ++i) imp[i] = dir[i]; haveImp = sb_finite3(imp); }
    const float* pp = memory_readable((const void*)((uintptr_t)self + layout::kActorPos), 12) ? (const float*)((uintptr_t)self + layout::kActorPos) : nullptr;
    double dist = -1.0; if (haveImp && pp && sb_finite3(pp)) { const double dx = (double)pp[0] - imp[0], dy = (double)pp[1] - imp[1], dz = (double)pp[2] - imp[2]; dist = vm::dsqrt(dx * dx + dy * dy + dz * dz); }
    if (take && haveImp) { for (int i = 0; i < 3; ++i) g_kn.impact[i] = imp[i]; g_kn.force = force; g_kn.haveImpact = 1; g_kn.takenQ = qpc_now(); }
    if (g_kn.callLogs++ < 40)
      log_line("KNOCK knockBack #%ld t=%.2fs: the game knocks the player back from %.1f,%.1f,%.1f (%.1f ft from the player), force %.1f, called from game RVA 0x%X | Stay Puft level %d, roof view %d | %s",
               g_kn.playerCalls, qpc_ms() / 1000.0, (double)imp[0], (double)imp[1], (double)imp[2], dist, (double)force, (unsigned)(ret - g_game.base), knock_boss_present((uintptr_t)self) ? 1 : 0, engine_scene_arms(0) ? 1 : 0,
               take ? "comfort window instead of the fall" : g_kn.off ? "the game's fall is played (comfort switched off for this run after a stuck player)" : "the game's own fall is played");
  }
  if (take) {
    ++g_kn.took;
    knock_begin("knockBack");
    return;
  }
  ++g_kn.passed;
  o_knockBack(self, dir, force);
}
// every tick: if the fall flag is up anyway (another way in), take the game's own reset sequence
static int knock_guard_actor(uintptr_t p) {
  if (!p || !memory_readable((const void*)(p + layout::kOffKnockFlag), 0x30)) return 0;
  uint8_t* f = (uint8_t*)(p + layout::kOffKnockFlag);
  if (!*f) return 0;
  *f = 0;
  *(uint64_t*)(p + layout::kOffKnockB6B4) = 0; *(int32_t*)(p + layout::kOffKnockB6B0) = 0;
  *(uint64_t*)(p + layout::kOffKnockVel + 4) = 0; *(int32_t*)(p + layout::kOffKnockVel) = 0; *(int32_t*)(p + layout::kOffKnockB6BC) = -1;
  ++g_kn.flagClears;
  knock_begin("fall animation request");
  if (g_kn.flagLogged++ < 30) log_line("KNOCK fall animation request intercepted before playback (#%ld)", g_kn.flagClears);
  return 1;
}
static void knock_guard() {
  const uintptr_t a = head_aim_actor();
  if (knock_comfort_on(a)) knock_guard_actor(a);
}
static void __fastcall hk_knock_consumer(void* self, float dt) {
  ++g_kn.consumerCalls;
  if (self && (uintptr_t)self == head_aim_actor() && g_kn.rescueReq && g_kn.haveImpact && g_kn.rescues < 3) {
    // 1.7.93 rescue (the game's thread): the player is stuck and a knock-back was skipped shortly before. Play that knock-back as the game would have (it pushes the player away from
    // where it was thrown) and keep the comfort replacement off for the rest of this run, so it cannot happen again.
    InterlockedExchange(&g_kn.rescueReq, 0); InterlockedExchange(&g_kn.off, 1); ++g_kn.rescues;
    log_line("KNOCK rescue #%ld t=%.2fs: the player was stuck %.0f s after a skipped knock-back: it is played now (from %.1f,%.1f,%.1f, force %.1f) and the comfort replacement stays off for this run",
             g_kn.rescues, qpc_ms() / 1000.0, (double)(qpc_now() - g_kn.takenQ) / (double)qpc_freq(), (double)g_kn.impact[0], (double)g_kn.impact[1], (double)g_kn.impact[2], (double)g_kn.force);
    float imp[3] = {g_kn.impact[0], g_kn.impact[1], g_kn.impact[2]};
    o_knockBack(self, imp, g_kn.force);
    g_kn.haveImpact = 0;   // 1.7.194: the stale impact is never replayed twice
  }
  if (knock_comfort_on((uintptr_t)self) && self && (uintptr_t)self == head_aim_actor() &&
      memory_readable((const uint8_t*)self + layout::kOffKnockFlag, 1) && *((const uint8_t*)self + layout::kOffKnockFlag)) {
    if (knock_guard_actor((uintptr_t)self)) ++g_kn.consumerIntercepts;
  }
  o_knockConsumer(self, dt);
}
// the player's walking speed during the window: the body's horizontal velocity, set by the update, is scaled by k (the update may read its own last value back, so the plain value is kept)
static uintptr_t knock_walk_update(void* selfv, float dt, double k) {
  const uintptr_t r = o_charUpdate(selfv, dt);
  const uintptr_t body = sb_body((uintptr_t)selfv);
  if (!body) return r;
  float* v = (float*)(body + layout::kBodyVel);
  if (!sb_finite3(v)) return r;
  float hx = v[0], hz = v[2];
  if (g_kn.wrote && vm::dabs((double)hx - g_kn.lastW[0]) < 1e-3 && vm::dabs((double)hz - g_kn.lastW[1]) < 1e-3) { hx = g_kn.lastPlain[0]; hz = g_kn.lastPlain[1]; }
  g_kn.lastPlain[0] = hx; g_kn.lastPlain[1] = hz;
  v[0] = (float)((double)hx * k); v[2] = (float)((double)hz * k);
  g_kn.lastW[0] = v[0]; g_kn.lastW[1] = v[2]; g_kn.wrote = 1; ++g_kn.walkTicks;
  return r;
}
static void install_knock_hook();
// 1.7.37 the player's own health for the bar on the gun. The game keeps it where it keeps every character's: current at +0xB860, maximum at +0xB868 (the character base the
// player shares with the ghosts; its constructor at 0x1FC6A sets both). Read-only. Returns the fraction 0..1, or 0 when the value is not plausible.
static struct { long reads, bad; int logged; float lastCur, lastMax, lastFrac; int64_t logQ; } g_php;
int engine_player_health(float* frac) {
  const uintptr_t p = head_aim_actor();
  if (!p || !memory_readable((const void*)(p + 0xB860), 12)) return 0;
  const float cur = *(const volatile float*)(p + 0xB860), mx = *(const volatile float*)(p + 0xB868);
  const double f = gunbar::fraction((double)cur, (double)mx);
  ++g_php.reads;
  const int64_t q = qpc_now();
  const int due = !g_php.logQ || (q - g_php.logQ) > 4 * qpc_freq();
  if (f < 0.0) { ++g_php.bad; if (g_php.logged < 40 && due) { ++g_php.logged; g_php.logQ = q; log_line("PLAYERHP not plausible: current %.3f, maximum %.3f (the gun bar is not drawn)", (double)cur, (double)mx); } return 0; }
  if (g_php.logged < 40 && (due || vm::dabs(f - (double)g_php.lastFrac) > 0.08)) { ++g_php.logged; g_php.logQ = q; log_line("PLAYERHP current %.3f of %.3f -> %.0f%% (gun bar; reads %ld, not plausible %ld)", (double)cur, (double)mx, f * 100.0, g_php.reads, g_php.bad); }
  g_php.lastCur = cur; g_php.lastMax = mx; g_php.lastFrac = (float)f;
  {   // 1.7.95 LIFE: the 1.7.92 Times Square report showed the player at 100 % -> 1 % -> 0 % inside about 40 s of the Stay Puft scene, with no stick pushed while down; this line (kept in the
      // player log) says when health crosses each step, how many hits the game sent by then, and whether the Stay Puft level was on, so "stuck" and "knocked out" can be told apart
    static int s_band; static int64_t s_bandQ; static int s_lifeLogs; static long s_knocksAtBand;
    const int nb = f <= 0.015 ? 4 : f < 0.10 ? 3 : f < 0.30 ? 2 : f < 0.60 ? 1 : 0;
    const int64_t nq = qpc_now();
    if (nb > s_band) {
      if (s_lifeLogs++ < 30) {
        static const char* const kName[] = {"full", "below 60 %", "below 30 %", "below 10 %", "about 0 %"};
        log_line("LIFE t=%.1fs: the player's health is now %.0f%% (%s) | %.1f s since the step before, %ld game knock-backs since then (%ld in all: comfort window took %ld, game's own fall %ld) | Stay Puft level %d",
                 qpc_ms() / 1000.0, f * 100.0, kName[nb], s_bandQ ? (double)(nq - s_bandQ) / (double)qpc_freq() : 0.0, g_kn.playerCalls - s_knocksAtBand, g_kn.playerCalls, g_kn.took, g_kn.passed, knock_boss_present(p) ? 1 : 0);
      }
      s_band = nb; s_bandQ = nq; s_knocksAtBand = g_kn.playerCalls;
    } else if (nb < s_band) {
      if (nb == 0 && s_lifeLogs++ < 30) log_line("LIFE t=%.1fs: the player's health is back to %.0f%% (new try or healed)", qpc_ms() / 1000.0, f * 100.0);
      s_band = nb; s_bandQ = nq; s_knocksAtBand = g_kn.playerCalls;
    }
  }
  *frac = (float)f;
  return 1;
}
// The character update, for every character. Only the player's tick is ever changed, and only by the velocity / time ways (which are possible only once this hook has seen the player's tick).
static uintptr_t __fastcall hk_char_update(void* selfv, float dt) {
  SpeedBoost& b = g_sb;
  const uintptr_t self = (uintptr_t)selfv;
  ++b.charAll;
  int slot = -1;
  for (int i = 0; i < b.charKinds; ++i) if (b.charThis[i] == self) { slot = i; break; }
  if (slot < 0 && b.charKinds < 6) { slot = b.charKinds++; b.charThis[slot] = self; b.charVt[slot] = (self && memory_readable((const void*)self, 8)) ? *(const uintptr_t*)self : 0; b.charThisN[slot] = 0; }
  if (slot >= 0) ++b.charThisN[slot];
  if (!self || self != head_aim_actor()) return o_charUpdate(selfv, dt);
  ++b.charPlayer;
  if (!b.haveCfg) return o_charUpdate(selfv, dt);
  const double k = b.s.k;
  const int m = b.s.method;
  const double dtd = (double)dt;
  if (!(k > 1.0005) || !(m == boost::kTime || m == boost::kVelocity) || g_forced.forced || !(dtd > 0.003 && dtd < 0.25)) { b.wroteLast = 0; return o_charUpdate(selfv, dt); }
  if (m == boost::kTime) { b.wroteLast = 0; ++b.timeWrites; return o_charUpdate(selfv, (float)boost::time_step(dtd, k)); }
  // velocity: let the update set the body's velocity for this step, then scale it before the physics step uses it
  const uintptr_t body = sb_body(self);
  int vok = body && sb_finite3((const float*)(body + layout::kBodyVel));
  const uintptr_t r = o_charUpdate(selfv, dt);
  if (!vok) { ++b.bodyBad; b.wroteLast = 0; return r; }
  const uintptr_t body2 = sb_body(self);
  float* v = body2 ? (float*)(body2 + layout::kBodyVel) : nullptr;
  if (!v || !sb_finite3(v)) { ++b.bodyBad; b.wroteLast = 0; return r; }
  double hx = (double)v[0], hz = (double)v[2];
  const double h = vm::dsqrt(hx * hx + hz * hz);
  ++b.velSeen;
  if (h < 0.5) { ++b.velSmall; b.wroteLast = 0; return r; }
  if (b.wroteLast && vm::dabs(hx - b.lastW[0]) < 1e-3 && vm::dabs(hz - b.lastW[1]) < 1e-3) { hx = b.lastPlain[0]; hz = b.lastPlain[1]; ++b.velPersist; }
  double ox, oz;
  const double cap = boost::base_speed(b.s, b.c) * 1.3 * k + 1.0;
  boost::vel_scale(hx, hz, k, cap, &ox, &oz);
  b.lastPlain[0] = hx; b.lastPlain[1] = hz; b.lastW[0] = ox; b.lastW[1] = oz; b.lastK = k; b.wroteLast = 1;
  v[0] = (float)ox; v[2] = (float)oz; ++b.velWrites;
  return r;
}
static int bytes_match(uint32_t r, const uint8_t* b, int n);   // defined further down
static void install_boost_hook() {
  if (!bytes_match(layout::kRvaCharUpdate, layout::kBytesCharUpdate, 16)) { g_sb.hooked = -1; log_line("SPEEDBOOST character-update hook not available (its bytes differ): only the main-loop nudge way is possible"); return; }
  void* t = (void*)rva(layout::kRvaCharUpdate);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_char_update, (void**)&o_charUpdate);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_sb.hooked = s == MH_OK ? 1 : -2;
  log_line("HOOK character-update %x status=%d (1.7.9: only counts who calls it; the velocity and time sprint ways need the player's tick to show up here)", layout::kRvaCharUpdate, (int)s);
}
// 1.7.194 "for a normal ghost hit that does not knock down, get rid of its effect on the model": CGhostbuster::hurt (player vtable 0x774440 slot 34, RVA 0xCE600) calls RVA 0xCEC80(player, damageInfo)
// to play the hit reaction (a canned animation; it sets the state +0x24A78 = 6). That animation moved the character for ~0.6 s (FORCEDMOVE lines of the 00:01 report) and handed the model to the game's
// pose (a floating gun). With the comfort replacement on, the player's hit reaction is not played; the health is still lost (that happens in hurt itself). The real knock-down (knockBack) is handled above.
typedef void (__fastcall *PFN_HitReact)(void*, void*);
static PFN_HitReact o_hitReact;
static struct { long calls, skipped, logged; int hooked; } g_hr;
static void __fastcall hk_hit_react(void* self, void* info) {
  ++g_hr.calls;
  int dying = 0;   // 1.7.194 audit: a player at (nearly) no health keeps the game's own reaction (death / game over must not depend on a skipped call)
  if (self && memory_readable((const uint8_t*)self + 0xB860, 12)) { const float cur = *(const float*)((const uint8_t*)self + 0xB860), mx = *(const float*)((const uint8_t*)self + 0xB868); dying = !(mx > 1.0f) || !(cur > 0.05f * mx); }
  if (self && (uintptr_t)self == head_aim_actor() && !dying && g_ctl.knockComfort && g_ctl.stereoActive && !g_kn.off) {
    ++g_hr.skipped;
    if (g_hr.logged++ < 60) {
      int type = -1, src = -1;
      if (info && memory_readable((const uint8_t*)info, 0x20)) { type = *(const int*)((const uint8_t*)info + 8); src = *(const int*)((const uint8_t*)info + 0x18); }
      log_line("HITREACT #%ld t=%.2fs: the game's hit reaction on the player is not played (damage type 0x%x, kind %d); health is still lost", g_hr.skipped, qpc_ms() / 1000.0, type, src);
    }
    // 1.7.199: the real knock-downs (boss hits, types 0x6E/0x6F) never reach knockBack in any report, so the comfort effects (dark edges, slow walk, slow arms) start here
    {   // 1.7.200: only the boss hit the GAME would knock you down with starts the comfort effect. The game's hit reaction (RVA 0xCEC80) rotates a counter (0xE40CC4, 0..3; it counts on only while the byte at 0xE40CC8 is set):
        // counter 3 = a plain stagger, every other value (and always when the byte is 0) = the knock-down (it sets the fall flag +0xB695); a hit whose attacker (info+0x50) is the player itself is never one.
        // Skipping the call froze that counter, so it is mirrored here (same rule, own copy) and the effect follows its answer. Logged as KNOCKHIT so the next report can check it.
      int t2 = -1; if (info && memory_readable((const uint8_t*)info, 0x20)) t2 = *(const int*)((const uint8_t*)info + 8);
      static int s_cnt = -1; static int s_kh;
      const uint8_t* gc = (const uint8_t*)rva(0xE40CC4); const int gcOk = memory_readable(gc, 8);
      const int flag = gcOk ? (gc[4] != 0) : 0;
      if (s_cnt < 0) s_cnt = gcOk ? (int)(*(const unsigned*)gc & 3u) : 0;
      const uintptr_t atk = (info && memory_readable((const uint8_t*)info, 0x58)) ? *(const uintptr_t*)((const uint8_t*)info + 0x50) : 0;
      // 1.7.204 "make sure normal ghost knock-downs work the same way": the game's own first test (RVA 0xCF8C0: does this hit get ANY reaction) is asked too, for every damage type, so the effect follows
      // exactly the hits the game would have reacted to; a boss hit and a ghost hit are treated alike. (The counter only moves for hits that pass it, as in the game.)
      typedef uint8_t (__fastcall *PFN_HitPass)(void*, void*);
      int passes = 1;
      { static const uint8_t* s_pc; if (!s_pc) s_pc = (const uint8_t*)rva(0xCF8C0); static const uint8_t k_pass[8] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x57, 0x48, 0x83}; if (s_pc && memory_readable(s_pc, 8) && memcmp(s_pc, k_pass, 8) == 0 && info) passes = ((PFN_HitPass)s_pc)(self, info) != 0; }
      const int plain = flag && s_cnt == 3;
      const int knocks = passes && !plain && !(atk && atk == (uintptr_t)self);
      const int cntNow = s_cnt;
      if (flag && passes) s_cnt = s_cnt >= 3 ? 0 : s_cnt + 1;
      const char* kind = t2 == 0x6E || t2 == 0x6F ? "boss hit" : "ghost hit";
      if (knocks) { const int was = g_kn.active && engine_knock_strength() > 0.0; knock_begin("a hit the game knocks down with"); if (s_kh++ < 60) log_line("KNOCKHIT #%d t=%.2fs %s (type 0x%x) that knocks down: comfort window %s (counter %d, counter-runs %d, knock_ms %d, walk %d%%, edges %d%%)", s_kh, qpc_ms() / 1000.0, kind, t2, was ? "already running" : "started", cntNow, flag, (int)g_ctl.knockMs, (int)g_ctl.knockWalkPct, (int)g_ctl.knockDarkPct); }
      else if (s_kh++ < 60) log_line("KNOCKHIT #%d t=%.2fs %s (type 0x%x) that does not knock down (game reacts at all: %d, counter %d, counter-runs %d, attacker is you %d): no comfort effect", s_kh, qpc_ms() / 1000.0, kind, t2, passes, cntNow, flag, (atk && atk == (uintptr_t)self) ? 1 : 0);
    }
    return;
  }
  o_hitReact(self, info);
}
static void install_knock_hook() {
  {
    static const uint8_t expect[] = {0x40, 0x53, 0x57, 0x48, 0x81, 0xEC, 0xE8, 0x01, 0x00, 0x00};
    const uint8_t* code = (const uint8_t*)rva(0xCEC80);
    int ok = g_game.identityOK && memory_readable(code, sizeof(expect));
    if (ok) for (unsigned i = 0; i < sizeof(expect); ++i) if (code[i] != expect[i]) { ok = 0; break; }
    if (ok) { MH_STATUS st = MH_CreateHook((void*)code, (void*)hk_hit_react, (void**)&o_hitReact); if (st == MH_OK) st = MH_EnableHook((void*)code); g_hr.hooked = st == MH_OK ? 1 : -2; }
    else g_hr.hooked = -1;
    log_line("HITREACT hook %s (game RVA 0xCEC80, the player's hit reaction; -1 = code differs, -2 = hook failed): %d", g_hr.hooked == 1 ? "installed" : "NOT installed", g_hr.hooked);
  }
  if (bytes_match(layout::kRvaKnockBack, layout::kBytesKnockBack, 16)) {
    void* t = (void*)rva(layout::kRvaKnockBack);
    MH_STATUS st = MH_CreateHook(t, (void*)hk_knock_back, (void**)&o_knockBack);
    if (st == MH_OK) st = MH_EnableHook(t);
    g_kn.hooked = st == MH_OK ? 1 : -2;
  } else g_kn.hooked = -1;
  if (bytes_match(layout::kRvaKnockConsumer, layout::kBytesKnockConsumer, 16)) {
    void* t = (void*)rva(layout::kRvaKnockConsumer);
    MH_STATUS st = MH_CreateHook(t, (void*)hk_knock_consumer, (void**)&o_knockConsumer);
    if (st == MH_OK) st = MH_EnableHook(t);
    g_kn.consumerHooked = st == MH_OK ? 1 : -2;
  } else g_kn.consumerHooked = -1;
  log_line("KNOCK hooks knockBack=%d fallConsumer=%d comfort=%d", g_kn.hooked, g_kn.consumerHooked, (int)g_ctl.knockComfort);
}
// 1.7.9: every copy of the actor's old position (x and z equal to 0.003 ft, y within 6 ft) inside a struct is moved on by the same step: the position the game really keeps is found without knowing its offset.
// skip0..skip1: the actor's own position triple, handled by the caller. Returns how many copies were moved; their offsets (up to 10) go to offs.
static double s_nudgeEy;   // 1.7.71: the stairs lift of this nudge (0 on the flat), applied to every copy of the position too
static int sb_nudge_matches(uintptr_t base, uint32_t size, double ox, double oy, double oz, double ex, double ez, uint32_t skip0, uint32_t skip1, int* offs, int* offN) {
  if (!memory_readable((const void*)base, size)) return 0;
  int n = 0;
  for (uint32_t i = 0; i + 12 <= size; i += 4) {
    if (i >= skip0 && i < skip1) continue;
    float* f = (float*)(base + i);
    if (!vm::is_finite_f(f[0]) || !vm::is_finite_f(f[2])) continue;
    if (vm::dabs((double)f[0] - ox) > 0.003 || vm::dabs((double)f[2] - oz) > 0.003) continue;
    if (!vm::is_finite_f(f[1]) || vm::dabs((double)f[1] - oy) > 6.0) continue;
    f[0] += (float)ex; f[1] += (float)s_nudgeEy; f[2] += (float)ez; ++n;
    if (offs && offN && *offN < 10) offs[(*offN)++] = (int)i;
    i += 8;
  }
  return n;
}
// Called right after every real simulation of the main loop (once per game tick; in eye-pair mode once per pair).
static void boost_after_sim(void* app) {
  SpeedBoost& b = g_sb;
  ++b.simCalls;
  sb_config(b);
  // the velocity / time ways are possible only when the character update has really shown the player's tick (30 times)
  const int charLive = b.charPlayer >= 30;
  boost::set_avail(b.s, boost::kVelocity, charLive);
  boost::set_avail(b.s, boost::kTime, charLive);
  if (boost::ensure_available(b.s)) log_line("SPEEDBOOST the way in use is not possible any more: now %s", sb_name(b.s.method));
  const uintptr_t pa = head_aim_actor();
  if (!pa) { ++b.noActor; b.havePos = 0; return; }
  float* ap = (float*)(pa + layout::kActorPos);
  if (!memory_readable(ap, 12) || !sb_finite3(ap)) { ++b.badPos; b.havePos = 0; return; }
  const uint8_t* a = (const uint8_t*)app;
  // this tick's game time (after the time scale) and the wall time since the last tick (the log compares the two)
  double dt = 0.0;
  if (a && memory_readable(a + layout::kAppStep, 4)) { const float st = *(const float*)(a + layout::kAppStep); if (vm::is_finite_f(st)) dt = (double)st; }
  const int paused = a && memory_readable(a + layout::kAppPaused, 1) && a[layout::kAppPaused];
  const int64_t q = qpc_now();
  double wall = 0.0;
  if (b.lastQ) wall = (double)(q - b.lastQ) / (double)qpc_freq();
  b.lastQ = q;
  if (wall > 0.0 && wall < 0.5 && dt > 0.0) { b.wallSum += wall; b.stepSum += dt; ++b.wallN; }
  if (paused) { ++b.pausedSkips; b.havePos = 0; b.lastNudge = 0.0; return; }
  const int dtOk = dt > 0.003 && dt < 0.25;
  if (!dtOk) ++b.dtBad;
  ++b.simTicks;
  const double stick = (double)controllers_move_mag() * 0.001;
  // 1.7.22 blink dash: double-tap the left stick (off unless switched on)
  if (!g_ds.init) { g_ds.init = 1; dash::reset(g_dash); g_dashCfg = dash::make_cfg(); }
  int dashStarted = 0;
  const int dashOn = g_ctl.blinkDash && !g_forced.forced && engine_knock_strength() <= 0.0 && !vrmenu_is_open() && dtOk;
  const double kDash = dash::feed(g_dash, g_dashCfg, stick, dtOk ? dt : 0.0, dashOn, &dashStarted);
  if (g_ctl.blinkDash && g_forced.forced && stick > 0.5) ++g_ds.blockedForced;
  if (dashStarted) {
    ++g_ds.starts;
    vignette_pulse(450);
    haptics_add(0, hap::kSrcButton, 0.55f, 120); haptics_add(1, hap::kSrcButton, 0.55f, 120);
    if (g_ds.logged < 20) { ++g_ds.logged; log_line("BLINKDASH #%ld started: left stick double-tap, walking direction (%.2f, %.2f), method %s, plain speed %.2f ft/s, burst x%.1f for %.2f s (about %.1f ft extra)", g_ds.starts, b.dirX, b.dirZ, sb_name(b.s.method), boost::base_speed(b.s, b.c), g_dashCfg.K, g_dashCfg.durSec, 0.55 * (g_dashCfg.K - 1.0) * boost::base_speed(b.s, b.c) * g_dashCfg.durSec); }
  }
  if (kDash > 1.0005) { ++g_ds.ticks; g_ds.lastK = kDash; if (kDash > g_ds.biggestK) g_ds.biggestK = kDash; if (b.s.method != boost::kNudge) ++g_ds.noWay; b.dashHold = 4; }
  else if (b.dashHold > 0) --b.dashHold;
  const double pre[3] = {(double)ap[0], (double)ap[1], (double)ap[2]};
  // what the player did since the last tick, with whatever we added then and the game kept
  double mx = 0.0, mz = 0.0, md = 0.0, my = 0.0;
  if (b.havePos) {
    mx = pre[0] - b.prePos[0]; mz = pre[2] - b.prePos[2]; my = pre[1] - b.prePos[1];
    const double d2 = mx * mx + mz * mz;
    md = d2 > 0.0 ? vm::dsqrt(d2) : 0.0;
    if (md < 5.0) b.walkTotal += md; else { ++b.jumps; b.lastJump = md; b.lastJumpFrame = b.simTicks; }
    if (dtOk && b.dashHold > 0) ++g_ds.skippedSamples;   // a burst must not count as plain or boosted walking in the speed measurement
    else if (dtOk) {
      boost::sample(b.s, md, dt, stick, b.c);
      const int was = b.s.method;
      const int v = boost::judge(b.s, b.c);
      if (v != 0 && b.logged < 40) {
        ++b.logged;
        log_line("SPEEDBOOST verdict: the %s way %s (boosted %.2f ft/s against plain %.2f ft/s at a full stick = gain %.2f, wanted %.2f)%s", sb_name(was), v > 0 ? "WORKS" : "does NOT make the character faster", boost::boosted_speed(b.s) > 0 ? boost::boosted_speed(b.s) : b.s.lastGain * boost::base_speed(b.s, b.c),
                 boost::base_speed(b.s, b.c), b.s.lastGain, b.c.K, v < 0 ? (b.s.method != was ? (b.s.method == boost::kOff ? "; no way left: the boost stays off" : "; trying the next way") : "; (this way is fixed in the settings)") : "");
      }
    }
  }
  for (int i = 0; i < 3; ++i) b.prePos[i] = pre[i];
  b.havePos = 1;
  b.lastDt = dt; b.lastWall = wall; b.lastDist = md;
  if (md > 1e-6) { b.dirX = mx / md; b.dirZ = mz / md; }
  const uintptr_t body = sb_body(pa);
  // plain walking at a full stick (nothing boosted): what the body says (its velocity, its place against the actor). Standing / walking dumps of the body's numbers for the next version.
  if (g_ctl.probeData && stick < 0.05 && b.dumpStand < 2 && b.simTicks > 600 && body && (b.simTicks % 300) == 0) { ++b.dumpStand; log_line("BODYSTAND the player stands; body %p, actor %p, body floats +0x80..+0x1C0 follow", (void*)body, (void*)pa); sb_dump_body("BODYSTAND", body); }
  if (stick >= 0.85 && b.s.r <= 0.0 && md > 0.0 && dtOk && !g_forced.forced && body) {
    const float* v = (const float*)(body + layout::kBodyVel);
    if (sb_finite3(v)) {
      const double h = vm::dsqrt((double)v[0] * (double)v[0] + (double)v[2] * (double)v[2]);
      b.vcSum += h; b.vcReal += md / dt; ++b.vcN; if (h < 0.05) ++b.vcZero;
    }
    if ((b.simTicks & 7) == 0) {
      const float* bp = (const float*)(body + layout::kBodyPos); const float* xp = (const float*)(body + layout::kBodyXformPos);
      if (sb_finite3(bp)) { const double ox = (double)bp[0] - pre[0], oz = (double)bp[2] - pre[2]; b.posOffX += ox; b.posOffZ += oz; ++b.posOffN; const double aa = vm::dsqrt(ox * ox + oz * oz); if (aa > b.posOffMax) b.posOffMax = aa; }
      if (sb_finite3(xp)) { b.xfOffX += (double)xp[0] - pre[0]; b.xfOffZ += (double)xp[2] - pre[2]; ++b.xfN; }
    }
    if (g_ctl.probeData && b.dumpWalk < 2 && (b.simTicks % 200) == 0) { ++b.dumpWalk; log_line("BODYWALK the player walks at a full stick (%.2f ft/s); body %p, actor %p, body floats +0x80..+0x1C0 follow", md / dt, (void*)body, (void*)pa); sb_dump_body("BODYWALK", body); }
  }
  const int recovering = engine_knock_strength() > 0.0;   // replacement timer only; original fall is intercepted
  const int want = !g_forced.forced && !recovering && controllers_sprint_want() && g_ctl.sprintSpeedPct > 100 && dtOk;   // speed increase only; no native run route
  if (g_forced.forced && controllers_sprint_want()) ++b.forcedSkips;
  double k = boost::ramp(b.s, dtOk ? dt : 0.011, want, b.c);
  if (kDash > k) k = kDash;   // 1.7.22: only the nudge way below reads this local k; the other ways read b.s.k and so never dash
  if (recovering) k = 1.0;   // the speed boost must not undo the temporary knockdown slowdown
  const int m = b.s.method;
  double nudgeLen = 0.0;
  if (k > 1.0005 && m != boost::kOff) {
    ++b.boostedTicks; if (k > b.maxK) b.maxK = k;
    if (m == boost::kNudge && dtOk && md > 1e-6 && md < 1.0) {
      // the game's own step = what the actor moved minus what we added last tick (taken as kept; if it was not kept this under-counts and the measured gain says so), never more than a plain full-stick step
      const double plain = boost::plain_step(md, b.lastNudge, dt, b.s, b.c);
      if (plain > 0.0) {
        double ex, ez;
        const double kEff = 1.0 + (k - 1.0) * (kDash > 1.0005 ? 1.0 : boost::adapt(b.s, b.c));
        boost::nudge_extra(b.dirX * plain, b.dirZ * plain, kEff, kDash > 1.0005 ? g_dashCfg.capFt : 0.35, &ex, &ez);
        if (ex != 0.0 || ez != 0.0) {
          const float ox = ap[0], oy = ap[1], oz = ap[2];
          // 1.7.71 stairs: going up, the extra step climbs with the stairs (it was pushed into the next riser and the physics pushed it back: slow, jerky stairs while sprinting)
          s_nudgeEy = (g_ctl.stairsLift && my < 0.12) ? stairs::lift_for(my, md, vm::dsqrt(ex * ex + ez * ez)) : 0.0;   // (a jump rises faster than a stair climb: not lifted)
          if (s_nudgeEy > 0.0) { InterlockedIncrement(&g_stairLifts); g_stairLiftFt += s_nudgeEy; }
          int offsB[10], nB = 0, offsA[10], nA = 0;
          // other copies of the position first (they are found by value, before anything is changed), in the body and in the actor itself
          if (body) b.nudgeScanBody += sb_nudge_matches(body, 0x300, (double)ox, (double)oy, (double)oz, ex, ez, 0xFFFFFFFFu, 0xFFFFFFFFu, offsB, &nB);
          b.nudgeScanActor += sb_nudge_matches(pa, 0x200, (double)ox, (double)oy, (double)oz, ex, ez, layout::kActorPos, layout::kActorPos + 12, offsA, &nA);
          ap[0] += (float)ex; ap[1] += (float)s_nudgeEy; ap[2] += (float)ez; ++b.nudges;
          nudgeLen = vm::dsqrt(ex * ex + ez * ez);
          if (kDash > 1.0005) { ++g_ds.nudges; g_ds.feet += nudgeLen; }
          b.nudgeSum += nudgeLen; if (nudgeLen > b.nudgeMax) b.nudgeMax = nudgeLen;
          if ((nB || nA) && b.scanLogged < 4) {
            ++b.scanLogged;
            char t[200]; int tn = 0;
            for (int i = 0; i < nB && tn < 90; ++i) tn += wsprintfA(t + tn, " body+%x", offsB[i]);
            for (int i = 0; i < nA && tn < 180; ++i) tn += wsprintfA(t + tn, " actor+%x", offsA[i]);
            t[tn] = 0;
            log_line("NUDGEFIELDS the actor's position (%.3f, %.3f, %.3f ft) was also found at:%s (moved on by %.4f, %.4f ft; body %p, actor %p)", (double)ox, (double)oy, (double)oz, t, ex, ez, (void*)body, (void*)pa);
          }
          if (body) {
            const uint32_t offs[2] = {layout::kBodyPos, layout::kBodyXformPos};
            for (int qq = 0; qq < 2; ++qq) {
              float* bp = (float*)(body + offs[qq]);
              if (!sb_finite3(bp)) continue;
              if (vm::dabs((double)bp[0] - ((double)ox + ex)) < 1e-4 && vm::dabs((double)bp[2] - ((double)oz + ez)) < 1e-4) continue;   // the scan above moved this one already
              // 1.7.41: a field that sits a constant distance from the actor (the transform copy is ~(258,-69) ft off) is moved too, when that distance is the one seen last time
              static double s_offX[2], s_offZ[2]; static int s_offOk[2];
              static uintptr_t s_body, s_actor;
              if (body != s_body || pa != s_actor) {
                s_offOk[0] = s_offOk[1] = 0;
                s_body = body; s_actor = pa;
              }
              const double dx = (double)bp[0] - (double)ox, dz = (double)bp[2] - (double)oz;
              const int near15 = vm::dabs(dx) < 1.5 && vm::dabs(dz) < 1.5;
              const int steady = s_offOk[qq] && vm::dabs(dx - s_offX[qq]) < 1.5 && vm::dabs(dz - s_offZ[qq]) < 1.5;
              s_offX[qq] = dx; s_offZ[qq] = dz; s_offOk[qq] = 1;
              // Actor and copy move by the same delta, so their relative
              // offset stays dx/dz. Adding ex/ez to that offset drifted the
              // reference used by the next sprint tick.
              if (near15 || steady) { bp[0] += (float)ex; bp[1] += (float)s_nudgeEy; bp[2] += (float)ez; ++b.nudgeBody; }
              else ++b.nudgeBodyFar;
            }
          } else ++b.bodyBad;
        }
      } else ++b.noNudgeMove;
    }
  }
  b.lastNudge = nudgeLen;   // the next tick's measured motion includes it when the game keeps it; prePos stays the position BEFORE the nudge
}
static void speedboost_report(LONG frame) {
  const SpeedBoost& b = g_sb;
  log_line("PROGRESS frame=%d the player is at x=%.1f y=%.1f z=%.1f ft | walked %.0f ft in all | moved by more than 5 ft in one step %ld times (last %.0f ft, %ld ticks ago) | game ticks seen %ld (paused %ld, no player %ld, bad position %ld, odd step %ld) | forced moves now=%d (if the story does not go on: tell me what the screen says and which room you are in)",
           (int)frame, b.prePos[0], b.prePos[1], b.prePos[2], b.walkTotal, b.jumps, b.lastJump, b.simTicks - b.lastJumpFrame, b.simTicks, b.pausedSkips, b.noActor, b.badPos, b.dtBad, (int)g_forced.forced);
  const boost::State& s = b.s;
  const double base = boost::base_speed(s, b.c), bs = boost::boosted_speed(s);
  log_line("SPEEDBOOST frame=%d hook=%d setting=%d%% way=%d (0 = auto) | now: %s way, verdict reached=%d, multiplier %.2f (biggest %.2f), way switches %ld | game ticks %ld, boosted ticks %ld, skipped as forced moves %ld | plain full-stick speed %.2f ft/s (%.1f s measured; 7.4 is assumed when none) | boosted full-stick speed %.2f ft/s over %.1f s now | last gain %.2f (wanted %.2f)",
           (int)frame, b.hooked, (int)g_ctl.sprintSpeedPct, (int)g_ctl.sprintSpeedMethod, sb_name(s.method), s.locked, s.k, b.maxK, s.switches, b.simTicks, b.boostedTicks, b.forcedSkips, base, s.baseTime, bs, s.bTime, s.lastGain, b.c.K > 0 ? b.c.K : 1.0);
  log_line("BLINKDASH frame=%d on=%d | double-taps that started a dash %ld (stick taps seen %ld, window missed %ld, stick held too long %ld, refused by the 1.2 s cooldown %ld) | dash ticks %ld (nudge writes %ld, %.1f ft added in all, biggest multiplier %.2f), ticks the nudge way was not in use %ld, speed samples skipped during bursts %ld, stick moves skipped as forced moves %ld",
           (int)frame, (int)g_ctl.blinkDash, g_ds.starts, g_dash.taps, g_dash.windowMisses, g_dash.hardHolds, g_dash.blockedByCooldown, g_ds.ticks, g_ds.nudges, g_ds.feet, g_ds.biggestK, g_ds.noWay, g_ds.skippedSamples, g_ds.blockedForced);
  log_line("SPEEDWAYS verdict per way (0 not tried, 1 works, -1 does not) / measured gain: nudge %d/%.2f, velocity %d/%.2f, time %d/%.2f | nudge: %ld writes (fixed body fields moved %ld, body too far from the actor %ld, body unreadable %ld, no step to copy %ld; copies of the position found by value: body %ld, actor %ld), strength trim %.2f, %.3f ft in all, biggest %.3f ft | velocity writes %ld (the update left our value alone %ld, body too slow to scale %ld, seen %ld), time writes %ld",
           s.verdict[3], s.gain[3], s.verdict[1], s.gain[1], s.verdict[2], s.gain[2], b.nudges, b.nudgeBody, b.nudgeBodyFar, b.bodyBad, b.noNudgeMove, b.nudgeScanBody, b.nudgeScanActor, s.trim, b.nudgeSum, b.nudgeMax, b.velWrites, b.velPersist, b.velSmall, b.velSeen, b.timeWrites);
  log_line("SPEEDCHAR the game's character update 0x84390: called %ld times in all, %ld of them for the player (the velocity / time ways need >= 30) | different objects seen %d: [%p vt=%p n=%ld] [%p vt=%p n=%ld] [%p vt=%p n=%ld] [%p vt=%p n=%ld] | player actor %p",
           b.charAll, b.charPlayer, b.charKinds, (void*)b.charThis[0], (void*)b.charVt[0], b.charThisN[0], (void*)b.charThis[1], (void*)b.charVt[1], b.charThisN[1], (void*)b.charThis[2], (void*)b.charVt[2], b.charThisN[2], (void*)b.charThis[3], (void*)b.charVt[3], b.charThisN[3], (void*)head_aim_actor());
  log_line("SPEEDTIME game step against wall clock: game steps add up to %.2f s over %.2f s of wall time (%ld ticks) -> game time runs at %.2fx; mean game step %.1f ms",
           b.stepSum, b.wallSum, b.wallN, b.wallSum > 0.0 ? b.stepSum / b.wallSum : 0.0, b.wallN ? b.stepSum / (double)b.wallN * 1000.0 : 0.0);
  log_line("SPEEDBODY plain walking at a full stick: the body's velocity says %.2f ft/s while the character really moves %.2f ft/s (%ld ticks, %ld with no velocity at all) | body position minus actor position (horizontal): mean %.2f,%.2f ft, biggest %.2f ft (%ld samples) | body transform minus actor: mean %.2f,%.2f ft (%ld samples)",
           b.vcN ? b.vcSum / (double)b.vcN : 0.0, b.vcN ? b.vcReal / (double)b.vcN : 0.0, b.vcN, b.vcZero, b.posOffN ? b.posOffX / (double)b.posOffN : 0.0, b.posOffN ? b.posOffZ / (double)b.posOffN : 0.0, b.posOffMax, b.posOffN,
           b.xfN ? b.xfOffX / (double)b.xfN : 0.0, b.xfN ? b.xfOffZ / (double)b.xfN : 0.0, b.xfN);
}

// ---- 1.7.9 the PKE goggles: the green view, and the marks / things that only show in it ---------------------------------------------------------------------------------------------------------
// layout.h explains how the game decides. The 1.7.8 log and video: with the PKE in the hand the VR player never held the goggle button, the game said "goggles off" every frame, so there was no
// green tint and the hidden things (the "spot on the wall") stayed hidden. isGogglesActive (0xD6580) is wrapped: at the three call sites that drive the HUD fader and the render view flag the answer
// is "yes" while the PKE is in the hand (and the game's own "not now" flag, bit 7 of player+0x4C, is clear). Nothing else is touched: [player+0xB568] stays as the game keeps it, so the PKE meter
// does not turn into a "mirror only" object and stays in the hand.
typedef uint8_t(__fastcall* PFN_IsGoggles)(void* player);
static PFN_IsGoggles o_isGoggles;
static struct GogglesDrv {
  int hooked;
  long calls[4], origTrue[4], forced[4];        // by caller: 0 HUD (CAB3E), 1 HUD every player update (D7AC3), 2 render view flag (141138), 3 the others (they keep the game's answer)
  long inHand, inHandNo;                        // asked while the PKE was in the hand / and the game said no
  long sig[16];                                 // why the game said no, by bits: 1 button byte is 0, 2 [player+0xB640] set, 4 [player+0x2468]&&[player+0xB604]>=0, 8 flags bit 7
  uintptr_t player; int havePlayer;
  long ticks, ticksInHand, hudHist[5], hudMissing, fallbackCalls, fallbackSkipped, uvWrites, uvRestores;
  int uvForced, uvOrig, uvNow, lastState; float progress; int logged;
  long flagSet, flagClear;
} g_gog;
static int gog_in_hand(uintptr_t p) {
  if (!p || !memory_readable((const void*)(p + layout::kOffPlayerInv + 5 * layout::kInvStride), 4)) return 0;
  return *(const int32_t*)(p + layout::kOffPlayerInv + 5 * layout::kInvStride) == 2;
}
static uint8_t __fastcall hk_is_goggles(void* playerv) {
  const uintptr_t ret = (uintptr_t)GBVR_RETURN_ADDRESS();
  GogglesDrv& g = g_gog;
  const uint8_t r = o_isGoggles(playerv);
  const uintptr_t rr = ret - g_game.base;
  const int site = rr == layout::kRetGogHud ? 0 : rr == layout::kRetGogHudFrame ? 1 : rr == layout::kRetGogRender ? 2 : 3;
  ++g.calls[site]; if (r) ++g.origTrue[site];
  const uintptr_t p = (uintptr_t)playerv;
  if (!p || !memory_readable((const void*)p, layout::kOffPlayerInv + 6 * layout::kInvStride + 8)) return r;
  if (site != 3) { g.player = p; g.havePlayer = 1; }
  const int inHand = gog_in_hand(p);
  if (inHand) {
    ++g.inHand;
    if (!r) {
      ++g.inHandNo;
      int sg = 0;
      if (*(const uint8_t*)(p + layout::kOffPlayerGogByte) == 0) sg |= 1;
      if (*(const uintptr_t*)(p + layout::kOffPlayerB640) != 0) sg |= 2;
      if (*(const uint8_t*)(p + 0x2468) != 0 && *(const int32_t*)(p + 0xB604) >= 0) sg |= 4;
      if ((*(const uint32_t*)(p + layout::kOffPlayerFlags) >> 7) & 1) sg |= 8;
      ++g.sig[sg];
    }
  }
  if (r || site == 3 || g_ctl.pkeGoggles < 1 || !inHand) { if (site == 2) { if (r) ++g.flagSet; else ++g.flagClear; } return r; }
  if ((*(const uint32_t*)(p + layout::kOffPlayerFlags) >> 7) & 1) return r;   // the game's own "not now" (cut-scene, hidden player)
  if (g_forced.forced) return r;
  ++g.forced[site];
  if (site == 2) ++g.flagSet;
  if (g.logged < 3) { ++g.logged; log_line("GOGGLES the game said no with the PKE in the hand (site %d): answering yes from now on while the PKE is in the hand (button byte %d, flags %08x)", site, (int)*(const uint8_t*)(p + layout::kOffPlayerGogByte), *(const uint32_t*)(p + layout::kOffPlayerFlags)); }
  return 1;
}
static void install_goggles_hook() {
  if (!bytes_match(layout::kRvaIsGoggles, layout::kBytesIsGoggles, 16)) { g_gog.hooked = -1; log_line("GOGGLES the game's goggle check differs from the expected bytes: the green PKE view stays as the game has it"); return; }
  void* t = (void*)rva(layout::kRvaIsGoggles);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_is_goggles, (void**)&o_isGoggles);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_gog.hooked = s == MH_OK ? 1 : -2;
  log_line("HOOK goggles-check %x status=%d (1.7.9: the green PKE view is on while the PKE is in the hand)", layout::kRvaIsGoggles, (int)s);
}
// every simulation: the HUD fader as it is, and (only when the three call sites never showed up, or at level 2) the direct ways
static void goggles_after_sim() {
  GogglesDrv& g = g_gog;
  ++g.ticks;
  const uintptr_t p = g.havePlayer ? g.player : head_aim_actor();
  if (!p || !memory_readable((const void*)(p + layout::kOffPlayerHud), 8)) return;
  const int inHand = gog_in_hand(p);
  const uintptr_t hud = *(const uintptr_t*)(p + layout::kOffPlayerHud);
  int state = -1;
  if (hud && memory_readable((const void*)(hud + layout::kOffHudGogState), 0x20)) {
    state = *(const int32_t*)(hud + layout::kOffHudGogState);
    g.progress = *(const float*)(hud + layout::kOffHudGogProgress);
  } else if (inHand) ++g.hudMissing;
  g.lastState = state;
  if (inHand) { ++g.ticksInHand; if (state >= 0 && state <= 3) ++g.hudHist[state]; else ++g.hudHist[4]; }
  // fallback: the goggle check was never asked by the HUD sites although the PKE is in the hand for a while: ask the HUD directly (setGoggles(true) does nothing when it is on already)
  if (g_ctl.pkeGoggles >= 1 && inHand && hud && state >= 0 && g.ticksInHand > 240 && g.calls[0] + g.calls[1] == 0 && state != 1 && state != 2 && !g_forced.forced) {
    if (bytes_match(layout::kRvaHudSetGoggles, layout::kBytesHudSetGoggles, 16)) {
      ((void(__fastcall*)(void*, unsigned char))rva(layout::kRvaHudSetGoggles))((void*)hud, 1); ++g.fallbackCalls;
      if (g.fallbackCalls == 1) log_line("GOGGLES the game never asked the goggle check from its HUD code with the PKE in the hand (%ld ticks): the HUD is told directly", g.ticksInHand);
    } else ++g.fallbackSkipped;
  }
  // level 2: the developer "show everything" byte follows the PKE in the hand
  uint8_t* uv = (uint8_t*)rva(layout::kRvaUvDebugByte);
  if (memory_readable_any(uv, 1)) {
    g.uvNow = *uv;
    if (g_ctl.pkeGoggles >= 2 && inHand && !g_forced.forced) { if (!g.uvForced) { g.uvOrig = *uv; g.uvForced = 1; } if (*uv != 1) { *uv = 1; ++g.uvWrites; } }
    else if (g.uvForced) { *uv = (uint8_t)g.uvOrig; g.uvForced = 0; ++g.uvRestores; }
  }
}
static void goggles_report(LONG frame) {
  const GogglesDrv& g = g_gog;
  log_line("GOGGLES frame=%d hook=%d setting=%d | the game's check was asked: HUD %ld (said yes %ld, made yes %ld) / HUD each update %ld (%ld, %ld) / render flag %ld (%ld, %ld) / other callers %ld (%ld, kept) | asked with the PKE in the hand %ld times, the game said no %ld times | render flag set %ld, clear %ld",
           (int)frame, g.hooked, (int)g_ctl.pkeGoggles, g.calls[0], g.origTrue[0], g.forced[0], g.calls[1], g.origTrue[1], g.forced[1], g.calls[2], g.origTrue[2], g.forced[2], g.calls[3], g.origTrue[3], g.inHand, g.inHandNo, g.flagSet, g.flagClear);
  char b[300]; int n = 0;
  for (int i = 0; i < 16 && n < 260; ++i) if (g.sig[i]) n += wsprintfA(b + n, " [%s%s%s%s%s: %ld]", i ? "" : "none ", (i & 1) ? "button-byte-0 " : "", (i & 2) ? "B640-set " : "", (i & 4) ? "7D1F0-like " : "", (i & 8) ? "flag-bit7 " : "", g.sig[i]);
  b[n] = 0;
  log_line("GOGGLEWHY why the game said no with the PKE in the hand (each reason listed together with the others that failed at the same time):%s", n ? b : " (never said no)");
  log_line("GOGGLEHUD frame=%d the HUD's goggle fader now: state %d (0 off, 1 fading in, 2 on, 3 fading out), amount %.2f | simulations %ld, PKE in the hand %ld of them: fader off %ld, in %ld, on %ld, out %ld, no HUD %ld | direct HUD calls %ld (skipped %ld) | developer byte now %d, set by the probe %ld times, put back %ld",
           (int)frame, g.lastState, (double)g.progress, g.ticks, g.ticksInHand, g.hudHist[0], g.hudHist[1], g.hudHist[2], g.hudHist[3], g.hudHist[4] + g.hudMissing, g.fallbackCalls, g.fallbackSkipped, g.uvNow, g.uvWrites, g.uvRestores);
}
#endif

static void hk_prepare_impl(void* cam, void* ctx, void* ret) {
  InterlockedIncrement(&g_st.prepareCalls);
  CamCheck cc;
  int verified = verify_camera(ret, cam, ctx, &cc);
  if (!cc.caller || !cc.active) {  // some other camera or code path: never touched
    InterlockedIncrement(&g_st.otherCallerPrepares);
    o_prepare(cam, ctx);
    return;
  }
  if (!verified) InterlockedExchange(&g_sceneArms, 0);
  if (verified) {
    InterlockedIncrement(&g_st.verifiedPrepares);
    InterlockedExchange(&g_ctl.prepareSeen, 1);
  }
  int sample = verified && g_ctl.probeData && InterlockedExchange(&g_sampleRequest, 0) != 0;
  if (sample) {
    const uint8_t* b = (const uint8_t*)cam;
    log_line("SOURCEAUDIT frame=%d tid=%u camera=%p context=%p callerRVA=%x activeMatch=%d vtableOK=%d contextOK=%d "
             "fieldsOK=%d projMode=%d", (int)g_ctl.worldFrames, GetCurrentThreadId(), cam, ctx,
             (unsigned)((uintptr_t)ret - g_game.base), cc.active, cc.vtable, cc.context, cc.fields, cc.projMode);
    log_floats("SOURCEINPUT", (const float*)(b + layout::kCamEye), 11);
  }

  LONG mode = control_mode();
  LONG fp = g_ctl.firstPerson;
  LONG stereoOn = g_ctl.stereoActive;
  int rotArmed = 0, eyeArmed = 0, nearArmed = 0, stereoArmed = 0;
#if GBVR_HEADTRACK
  GbvrPose headPose;
  headPose.valid = 0;
#endif
  if (mode != MODE_OFF || fp) {
    const char* fail = nullptr;
    if (!verified) fail = !cc.vtable ? "camera gate: unexpected camera class"
                       : !cc.context ? "camera gate: unexpected render context"
                       : !cc.fields ? "camera gate: invalid camera fields"
                                    : "camera gate: non-perspective camera";
    // The focus gate protects the desktop picture while the player is in
    // another window. In the headset (F4) the picture has to keep following
    // the head, so it does not apply there.
    else if (!stereoOn && !game_window_focused()) fail = "focus gate";
    if (!fail) {
      if (mode == MODE_MANUAL) {
        g_armDegrees = (double)g_ctl.manualCentiDeg / 100.0;
        vm::local_yaw(g_armDegrees, g_armRot);
        rotArmed = 1;
#if GBVR_HEADTRACK
      } else if (mode == MODE_HEAD) {
        GbvrPose& p = headPose;
        const int specPeek = g_ctl.stereoSpecNext && g_ctl.chestCam && g_ctl.monitorView && g_ctl.stereoPair;   // 1.7.38: the chest-camera picture is not part of the head-follow loop (it only looks)
        if (!specPeek) follow_pre((const uint8_t*)cam);   // 1.5: measure the game's heading, keep the picture steady, take snap turns
        int r = vr_read_snapshot(&p);
        int64_t ageTicks = qpc_now() - p.qpc;
        double ageMs = (double)ageTicks * 1000.0 / (double)qpc_freq();
        if (r && p.valid && ageMs >= 0 && ageMs <= 250.0 && vm::is_rotation(p.m)) {
          for (int i = 0; i < 9; ++i) g_armRot[i] = p.m[i];
          g_armDegrees = 0;
          rotArmed = 1;
          if (!specPeek) follow_post(p);   // 1.5: head from body -> the push on the right stick
          if (sample)
            log_line("HEADPOSE frame=%d seq=%u ageMs=%d yaw=%d pitch=%d roll=%d (degrees x100)", (int)g_ctl.worldFrames,
                     p.seq, (int)ageMs, (int)(p.yawDeg * 100), (int)(p.pitchDeg * 100), (int)(p.rollDeg * 100));
        } else {
          fail = !r || !p.valid ? "pose gate: no valid headset pose"
                 : ageMs > 250.0 ? "pose gate: pose older than 250 ms"
                                 : "pose gate: invalid rotation";
          p.valid = 0;
          follow_stop();
          { DWORD tk = GetTickCount(); InterlockedExchange(&g_poseLostTick, (LONG)(tk ? tk : 1)); }   // 1.7.151
        }
#endif
      }
      if (fp) {
        const char* why = compute_first_person_eye(cam, g_armEye, sample);
        if (why) {
          InterlockedIncrement(&g_st.fpGateFails);
          if (!fail) fail = why;
        } else {
          eyeArmed = 1;
          nearArmed = 1;
#if GBVR_HEADTRACK
          if (g_ctl.wallDiag && stereoOn) wall_watch(cam);   // 0.75
#endif
        }
      }
#if GBVR_HEADTRACK
      if (!fail && stereoOn) {   // 1.7.151: a cutscene's short shots on the play camera stay on the 2D screen (cutholdmath.h)
        if (!g_cutHoldInit) { g_cutHold.reset(); g_cutHoldInit = 1; }
        pad::State cps; int cin = 0;
        if (controllers_pad_peek(&cps)) cin = (double)cps.lx * cps.lx + (double)cps.ly * cps.ly > 16384.0 * 16384.0;   // the move stick past half (not the trigger: on the 2D screen it is a click / skip)
        const LONG pst = g_ctl.pauseSeenTick;
        double pausedAgo = g_ctl.pauseFlag ? 0.0 : pst ? (double)(DWORD)(GetTickCount() - (DWORD)pst) / 1000.0 : 1e9;
        { const LONG plt = g_poseLostTick; const double lostAgo = plt ? (double)(DWORD)(GetTickCount() - (DWORD)plt) / 1000.0 : 1e9; if (lostAgo < pausedAgo) pausedAgo = lostAgo; }   // the headset was off / untracked: not a cutscene
        const int wasHolding = g_cutHold.holding; const long fw = g_cutHold.fullWaits, bi = g_cutHold.byInput, ss = g_cutHold.shortShots;
        const int hold = cuthold::step(&g_cutHold, (double)qpc_now() / (double)qpc_freq(), stereo_in_flat_mode(), pausedAgo, cin, (double)g_ctl.cutHoldMs / 1000.0);
        if (g_cutHold.holding != wasHolding || g_cutHold.shortShots != ss) {
          if (InterlockedIncrement(&g_cutHoldLogs) <= 80)
            log_line("CUTHOLD %s (holds %ld, cutscene shots kept on the 2D screen %ld, longest of them %.2f s, full waits %ld, ended by the stick %ld, no wait: after the pause menu / lost tracking %ld, after a short 2D blip %ld; wait %d ms, frame=%d)",
                     g_cutHold.holding ? (g_cutHold.shortShots != ss ? "another short shot: the last one stayed on the 2D screen, waiting again" : "the play camera is back while the 2D screen is up: it stays on the 2D screen until it has lasted the wait")
                     : g_cutHold.fullWaits != fw ? "the play camera lasted the whole wait: 3D comes back" : g_cutHold.byInput != bi ? "you pushed the move stick: 3D comes back at once" : "ended",
                     g_cutHold.holds, g_cutHold.shortShots, g_cutHold.longestShort, g_cutHold.fullWaits, g_cutHold.byInput, g_cutHold.byMenu, g_cutHold.byQuick, (int)g_ctl.cutHoldMs, (int)g_ctl.worldFrames);
        }
        if (hold) follow_stop();   // no body turn is asked for while the shot is on the 2D screen (as for a lost pose)
        if (hold) fail = "cutscene hold: the play camera has not lasted long enough yet (the shot stays on the 2D screen)";
      }
      if (!fail && stereoOn && mode == MODE_HEAD && rotArmed && headPose.valid) {
        const char* why = arm_stereo(cam, headPose, eyeArmed, sample);
        if (why) fail = why;
        else { stereoArmed = 1; eyeArmed = 1; }
      }
#endif
      // Headset view: a frame is either a complete eye picture or the unmodified
      // game picture (shown on the flat screen), never something in between.
      // Without the headset view the 0.20 behaviour stays: whatever passed its
      // own gate is still applied.
      if (fail && stereoOn) { rotArmed = 0; eyeArmed = 0; nearArmed = 0; stereoArmed = 0; }
    }
    if (fail) gate_suspend(fail);
    else gate_resume();
  }

  DWORD tid = GetCurrentThreadId();
  if ((rotArmed || eyeArmed) && InterlockedCompareExchange(&g_ownerTid, (LONG)tid, 0) == 0) {
    g_armRotValid = rotArmed;
    g_armEyeValid = eyeArmed;
    g_armNearValid = nearArmed;
    g_armStereo.valid = stereoArmed;
    g_armStereo.fovApplied = 0;
    g_armMode = mode;
    g_armSample = sample;
    g_armApplied = 0;
    g_armEyeApplied = 0;
    g_armNearApplied = 0;
    if (eyeArmed) InterlockedIncrement(&g_st.eyeArmed);
    if (stereoArmed) InterlockedIncrement(&g_st.stereoArmed);
    o_prepare(cam, ctx);
#if GBVR_HEADTRACK
    if (stereoArmed) {
      // The render thread may only show this frame as an eye picture if every
      // part of it (view, eye position, field of view) reached the engine.
      // ... and is still what the engine holds now that its prepare finished.
      float tanH = *(const volatile float*)rva(layout::kRvaTanHalfFovH);
      float tanV = *(const volatile float*)rva(layout::kRvaTanHalfFovV);
      int complete = g_armApplied && g_armEyeApplied && g_armStereo.fovApplied;
      int still = complete && tanH == g_armStereo.tanH && tanV == g_armStereo.tanV &&
                  max_abs_diff((const float*)rva(layout::kRvaGlobalEye), g_armEye, 3) <= 1e-6 &&
                  max_abs_diff((const float*)rva(layout::kRvaGlobalBasis), g_armOut, 9) <= 1e-6;
      if (still) {
        StereoFrame f;
        f.seq = 0;
        f.eye = g_armStereo.eye;
        for (int i = 0; i < 12; ++i) f.pose34[i] = g_armStereo.pose34[i];
        f.tanH = tanH;
        f.tanV = tanV;
        f.spec = g_armStereo.spec;
        if (f.spec) {   // 1.7.38: the chest-camera picture: the render thread keeps it for the PC window; nothing else about the game's state is touched
          stereo_publish_frame(&f);
          InterlockedExchange(&g_tickRole, 2);
          InterlockedIncrement(&g_st.stereoSpec);
        } else {
        InterlockedExchange(&g_be.eye, f.eye & 1);
        head_aim_publish(cam, g_armStereo);
        AcquireSRWLockExclusive(&g_drawStereoLock);
        g_drawStereo = g_armStereo;
        for (int i = 0; i < 3; ++i) g_drawStereo.eyeWorld[i] = g_armEye[i];
        g_drawStereoQ = qpc_now();
        ReleaseSRWLockExclusive(&g_drawStereoLock);
        stereo_publish_frame(&f);   // 0.32: where the player looks = where the game aims
        {   // ROOFVIEW (log only): per-eye view facts in the roof fight, every 120th eye, at most 40 lines
          static long s_rv[2], s_rvLogged;   // 1.7.209: counted per eye (one shared counter only ever sampled the left eye)
          if (engine_scene_arms(0) && (++s_rv[g_armStereo.eye & 1] % 60) == 1 && s_rvLogged < 80) {
            ++s_rvLogged;
            log_line("ROOFVIEW eye=%d role=%d reused=%d | final eye %.3f,%.3f,%.3f | tanH/V %.4f/%.4f | basis fwd %.3f,%.3f,%.3f | station have %d | pair age %.1f ms",
                     g_armStereo.eye, g_armStereo.pairRole, g_armStereo.reused, (double)g_armEye[0], (double)g_armEye[1], (double)g_armEye[2],
                     (double)g_armStereo.tanH, (double)g_armStereo.tanV, (double)g_armStereo.view[2], (double)g_armStereo.view[5], (double)g_armStereo.view[8],
                     g_sceneStation.have, g_pair.valid ? (double)(qpc_now() - g_pair.qpc) * 1000.0 / (double)qpc_freq() : -1.0);
            if (g_sceneStation.have) {   // 1.7.216 ROOFAIM: how straight and centred the forced-down view is (data for the next report)
              const float* v = g_armStereo.view; const float* hc = g_armStereo.headCenter;
              double tm[3] = {(double)g_sceneStation.mouth[0] - hc[0], (double)g_sceneStation.mouth[1] - hc[1], (double)g_sceneStation.mouth[2] - hc[2]};
              double fw[3] = {v[2], v[5], v[8]}, ang = -1.0;
              if (vm::dsqrt(tm[0] * tm[0] + tm[1] * tm[1] + tm[2] * tm[2]) > 1e-3) {
                const double l = vm::dsqrt(tm[0] * tm[0] + tm[1] * tm[1] + tm[2] * tm[2]);
                double cs = (fw[0] * tm[0] + fw[1] * tm[1] + fw[2] * tm[2]) / l; cs = cs > 1.0 ? 1.0 : (cs < -1.0 ? -1.0 : cs);
                ang = vm::datan2(vm::dsqrt(1.0 - cs * cs), cs) * 57.29577951308232;
              }
              double rz = v[3]; rz = rz > 1.0 ? 1.0 : (rz < -1.0 ? -1.0 : rz);
              double fy = -v[5]; fy = fy > 1.0 ? 1.0 : (fy < -1.0 ? -1.0 : fy);
              double hy = 0.0; const int hOk = stereo::robust_heading(v, &hy);
              const double hOff = hOk ? stereo::angle_diff(hy, g_sceneStation.facingYaw) * 57.29577951308232 : 0.0;
              log_line("ROOFAIM eye=%d | view points %.1f deg away from the boss's mouth | looking %.1f deg below the horizon | horizon roll %.1f deg | heading %.1f deg off the boss direction | headset position in the play space (right, height, forward) %.2f,%.2f,%.2f m | the pitched head movement (1.7.216) moved this eye %.1f cm compared with the old level layout",
                       g_armStereo.eye, ang, vm::dasin(fy) * 57.29577951308232, vm::dasin(rz) * 57.29577951308232, hOff, (double)g_armStereo.pose34[3], (double)g_armStereo.pose34[7], (double)g_armStereo.pose34[11], (double)g_roofHeadShiftCm);
            }
          }
        }
        trap_carry_step();   // 0.79: the game's own trap in the left hand while it is taken
        fight_publish(g_armStereo.view, g_armStereo.headCenter, g_armStereo.feetPerMetre, head_aim_actor(), !g_armStereo.reused);   // share the actor scan across the stereo pair
        // 0.27: the tick that ends this loop iteration decides how far the game
        // moves before the next eye is drawn - tell it which eye this was.
        InterlockedExchange(&g_tickRole, g_armStereo.pairRole);
        if (g_armStereo.pairRole && g_appSeen && memory_readable((const uint8_t*)g_appSeen + layout::kAppStep, 4)) {
          int r = g_armStereo.pairRole - 1;
          float step = *(const volatile float*)((const uint8_t*)g_appSeen + layout::kAppStep);
          if (vm::is_finite_f(step)) { g_st.stepSumMs[r] += (double)step * 1000.0; InterlockedIncrement(&g_st.stepSamples[r]); }
        }
        InterlockedIncrement(&g_st.stereoFrames);
        InterlockedIncrement(&g_st.stereoEye[f.eye & 1]);
        }
      } else if (complete) {
        LONG n = InterlockedIncrement(&g_st.stereoPostVerifyFail);
        if (n <= 5)
          log_line("STEREO warning: the engine changed the view after it was set (tanH=%.5f/%.5f tanV=%.5f/%.5f)",
                   tanH, g_armStereo.tanH, tanV, g_armStereo.tanV);
      } else {
        LONG n = InterlockedIncrement(&g_st.stereoIncomplete);
        if (n <= 5)
          log_line("STEREO warning: incomplete frame (basis=%d eye=%d fov=%d)", g_armApplied, g_armEyeApplied,
                   g_armStereo.fovApplied);
      }
    }
#endif
    if (rotArmed && !g_armApplied) {
      LONG n = InterlockedIncrement(&g_st.armedWithoutBasis);
      if (n <= 5) log_line("ENGINEYAW warning: armed prepare finished without the expected basis call");
    }
    if (eyeArmed && !g_armEyeApplied) {
      LONG n = InterlockedIncrement(&g_st.eyeArmedNoCall);
      if (n <= 5) log_line("FIRSTPERSON warning: armed prepare finished without the expected eye call");
    }
    g_lastTid = tid; g_lastCamera = cam; g_lastModified = g_armApplied; g_lastEyeApplied = g_armEyeApplied;
    if (g_armApplied) for (int i = 0; i < 9; ++i) g_lastOut[i] = g_armOut[i];
    if (g_armEyeApplied) for (int i = 0; i < 3; ++i) g_lastEye[i] = g_armEye[i];
    g_armRotValid = 0;
    g_armEyeValid = 0;
    g_armNearValid = 0;
    g_armStereo.valid = 0;
    InterlockedExchange(&g_ownerTid, 0);
  } else {
    o_prepare(cam, ctx);
    g_lastTid = tid; g_lastCamera = cam; g_lastModified = 0; g_lastEyeApplied = 0;
  }
}

static GBVR_NOINLINE void __fastcall hk_prepare(void* cam, void* ctx) {
  stage_g(ST_G_PREPARE);
  hk_prepare_impl(cam, ctx, GBVR_RETURN_ADDRESS());
}

static void hk_set_eye_impl(const float* eye, void* ret) {
  if (g_ownerTid == (LONG)GetCurrentThreadId() && g_armEyeValid && !g_armEyeApplied &&
      (uintptr_t)ret == rva(layout::kRvaSetEyeReturn)) {
    g_armEyeApplied = 1;
    InterlockedIncrement(&g_st.eyeApplied);
    o_setEye(g_armEye);  // the engine's normal setter receives the first-person eye
    double d = max_abs_diff((const float*)rva(layout::kRvaGlobalEye), g_armEye, 3);
    if (d <= 1e-6) InterlockedIncrement(&g_st.eyeVerifyOK);
    if (g_armSample) {
      log_floats("EYEORIGINAL", eye, 3);
      log_floats("EYEAPPLIED", g_armEye, 3);
    }
    return;
  }
  o_setEye(eye);
}

static GBVR_NOINLINE void __fastcall hk_set_eye(const float* eye) { hk_set_eye_impl(eye, GBVR_RETURN_ADDRESS()); }

// First-person near plane: geometry closer than this to the eye (the inside
// of the player's own head: hair, eyes) is clipped. Game default 0.25 ft.
static void hk_set_near_far_impl(float zNear, float zFar, void* ret) {
  if (g_ownerTid == (LONG)GetCurrentThreadId() && g_armNearValid && !g_armNearApplied &&
      (uintptr_t)ret == rva(layout::kRvaNearFarReturn)) {
    g_armNearApplied = 1;
    float fpNear = (float)g_ctl.nearCenti / 100.0f;
    if (g_armStereo.valid && g_armStereo.spec) fpNear = (float)((double)g_ctl.chestCamNearCm * 0.01 * g_armStereo.feetPerMetre);   // 1.7.38: the chest camera's own nearest distance
    // 1.7.57: keep near/far identical for both eyes of a stereo pair. Some scripted/view-model
    // transitions rewrite the game's far plane between eye renders; that showed up as close/far geometry
    // flickering in only one eye. Cache the first eye's far value for the second eye.
    static int64_t s_nfPair; static float s_nfFar;
    float fpFar = zFar;
    if (g_armStereo.pairQ && g_armStereo.pairRole == 1 && zFar > fpNear * 2.0f && vm::is_finite_f(zFar)) { s_nfPair = g_armStereo.pairQ; s_nfFar = zFar; }
    else if (g_armStereo.pairQ && g_armStereo.pairRole == 2 && s_nfPair == g_armStereo.pairQ && s_nfFar > fpNear * 2.0f) fpFar = s_nfFar;
    if (fpNear > 0.03f && fpNear < fpFar * 0.5f) {   // 0.77: also LOWER than the game's 0.25 ft (the chest shows when you look down)
      InterlockedIncrement(&g_st.nearApplied);
      if (g_armSample) log_line("NEARPLANE game=%.3f firstPerson=%.3f far=%.1f%s", zNear, fpNear, fpFar, fpFar != zFar ? " (pair-stable)" : "");
      o_setNearFar(fpNear, fpFar);
      return;
    }
  }
  o_setNearFar(zNear, zFar);
}

static GBVR_NOINLINE void __fastcall hk_set_near_far(float zNear, float zFar) {
  hk_set_near_far_impl(zNear, zFar, GBVR_RETURN_ADDRESS());
}

#if GBVR_HEADTRACK
// Stereo field of view (0.21). The headset needs a much taller view than the
// game's 61 degrees, and the two eyes look through off-centre windows. The
// game keeps its normal centred view; it is only made wide enough to contain
// both windows, and the compositor is told which part belongs to each eye.
// The engine's half-FOV tangent is inversely proportional to its zoom value,
// so: run the original call, read the tangents it produced, then call again
// with the zoom scaled to the tangent the headset needs.
static void hk_set_projection_impl(float zoom, int mode, void* ret) {
  ArmStereo& a = g_armStereo;
  if (g_ownerTid == (LONG)GetCurrentThreadId() && a.valid && !a.fovApplied && mode == 0 &&
      (uintptr_t)ret == rva(layout::kRvaProjectionReturn)) {
    o_setProjection(zoom, mode);
    const volatile float* pH = (const volatile float*)rva(layout::kRvaTanHalfFovH);
    const volatile float* pV = (const volatile float*)rva(layout::kRvaTanHalfFovV);
    float tanH0 = *pH, tanV0 = *pV;
    if (vm::is_finite_f(tanH0) && vm::is_finite_f(tanV0) && tanH0 > 0.05f && tanV0 > 0.05f && tanH0 < 20.0f &&
        tanV0 < 20.0f && zoom > 0.01f) {
      double aspect = (double)tanH0 / tanV0;
      double targetV, targetH;
      float zoomOut = zoom;
      if (a.wide) {
        // 0.24 "sharp": horizontal and vertical field of view set separately
        // through the engine's own direct setter, each exactly as wide as the
        // headset needs. The 16:9 frame is then no longer half empty: every
        // eye gets about 1.85 times more pixels across (the picture in the
        // game window looks squeezed; the headset shows it undistorted).
        targetH = a.needH; targetV = a.needV;
        if (targetH < 0.3) targetH = 0.3;
        if (targetH > 3.0) targetH = 3.0;
        if (targetV < 0.3) targetV = 0.3;
        if (targetV > 3.0) targetV = 3.0;
        ((PFN_SetScales)rva(layout::kRvaSetScales))((float)(1.0 / targetH), (float)(1.0 / targetV));
        InterlockedIncrement(&g_st.wideApplied);
      } else {
        targetV = stereo::game_tan_v(a.needH, a.needV, aspect);
        if (targetV < 0.3) targetV = 0.3;
        if (targetV > 3.0) targetV = 3.0;  // 143 degrees: beyond this the frame cannot cover the headset
        targetH = targetV * aspect;
        zoomOut = (float)((double)zoom * tanV0 / targetV);
        o_setProjection(zoomOut, mode);
      }
      a.zoomIn = zoom; a.zoomOut = zoomOut; a.tanH0 = tanH0; a.tanV0 = tanV0;
      a.tanH = *pH; a.tanV = *pV; a.tanVTarget = (float)targetV;
      if (!(vm::is_finite_f(a.tanH) && vm::is_finite_f(a.tanV) && a.tanH > 0.05f && a.tanV > 0.05f)) {
        o_setProjection(zoom, mode);  // unusable result: put the game's own value back, frame stays incomplete
        return;
      }
      a.fovApplied = 1;
      InterlockedExchange(&g_ctl.pictureTanX1000, (LONG)((double)a.tanV * 1000.0));
      InterlockedIncrement(&g_st.fovApplied);
      if (vm::dabs((double)a.tanV - targetV) <= 1e-3 * targetV && vm::dabs((double)a.tanH - targetH) <= 1e-3 * targetH)
        InterlockedIncrement(&g_st.fovVerifyOK);
      if (g_armSample)
        log_line("STEREOFOV wide=%d zoom=%.5f->%.5f tanH=%.5f->%.5f tanV=%.5f->%.5f targetH=%.5f targetV=%.5f "
                 "aspect=%.5f needH=%.5f needV=%.5f", a.wide, zoom, zoomOut, tanH0, a.tanH, tanV0, a.tanV, targetH,
                 targetV, aspect, a.needH, a.needV);
    }
    return;
  }
  o_setProjection(zoom, mode);
}

static GBVR_NOINLINE void __fastcall hk_set_projection(float zoom, int mode) {
  hk_set_projection_impl(zoom, mode, GBVR_RETURN_ADDRESS());
}

// Frame limiter and "same moment" (0.24 / 0.27).
//
// One loop iteration of the game is: simulate (with the time step the
// previous tick measured) -> camera prepare (eye A or B) -> hand the frame to
// the render thread -> App::Tick (measure the time step for the next
// iteration). See layout.h.
//
// 0.24-0.26 only lifted the 120 FPS limit so that the second eye follows the
// first at once. The world, however, moved between the two eyes by the time
// step measured after the first eye's prepare - and that step contains the
// headset's frame wait: about 10.8 ms. A ghost flying at 20 ft/s was drawn
// 66 mm apart for the two eyes (the eyes themselves are 71 mm apart), so
// everything that moves had the wrong depth; effects that change every
// update (the proton stream) were different pictures.
//
// 0.27: after the FIRST eye of a pair was prepared
//   - the tick gets the engine's own "longest frame" limit set to 8 ticks
//     (0.12 ms) for this one call and put back right after it, so every time
//     value the engine derives is consistently tiny; the timer's "previous
//     tick" time is put back too (plus those 8 ticks), so the tick after the
//     second eye measures the whole headset frame and the game runs at its
//     normal speed;
//   - the next App::Simulate call is left out, exactly as the game's own
//     main loop does while it is paused: the second eye is drawn from the
//     very same world state. (Without this the physics would also be asked
//     for two 0.06 ms sub-steps.)
// Not zero ticks: the game divides by the step. In slow motion the game
// multiplies the ticks by its time scale and rounds down; the scale is
// measured on the normal ticks and the limit raised so that about 8 ticks
// are left (stereo::same_moment_limit); with an extreme scale the feature is
// skipped for that pair. Never two short ticks in a row.
static const int32_t kSameMomentTicks = 8, kSameMomentMaxLimit = 512;

static int32_t g_shortLimitUsed;  // ticks of the short step whose simulation is to be left out

// Input (see layout.h "Input"): the game reads keys only inside Simulate, and
// its input poll later in the same iteration clears every key whose release
// is pending. A key release or mouse-wheel notch that arrived after the last
// simulation must therefore reach the next one. True while any is waiting.
static int key_release_pending() {
  const volatile int32_t* pending = (const volatile int32_t*)rva(layout::kRvaKeyReleasePending);
  for (uint32_t i = 0; i < layout::kKeyCount; ++i)
    if (pending[i] == 1) return 1;
  return 0;
}

// 0.52 auto-pause: the player left the game in VR (SteamVR menu, headset off): press Start for him if the game still runs.
static volatile DWORD g_lastSimMs;            // GetTickCount of the last main-loop App::Simulate call (it is not called while paused / in a menu)
static autop::Pauser g_pauser;
static volatile LONG g_apOn;
static volatile DWORD g_apFrom, g_apUntil;
static volatile LONG g_manualLeave;
static volatile DWORD g_tapFrom, g_tapUntil;
void autopause_manual_leave() { InterlockedIncrement(&g_manualLeave); }
// 1.7.11: the player asks for the game's own pause menu (Objectives, Training, ...): the "leave the pause menu again" helper (no_pause_menu) waits 3 minutes before it may close it
static volatile DWORD g_userMenuUntil;
void game_menu_request();   // defined below autopause_tap

static volatile LONG g_startTapsTotal; static volatile DWORD g_lastStartTapTick;   // 1.7.9: for the exit log
void autopause_tap() { const DWORD now = GetTickCount(); g_tapFrom = now; g_tapUntil = now + autop::kHoldMs; InterlockedIncrement(&g_startTapsTotal); g_lastStartTapTick = now; }
void game_menu_request() {
  const DWORD now = GetTickCount();
  g_userMenuUntil = now + 180000; if (!g_userMenuUntil) g_userMenuUntil = 1;
  const int running = game_running_now();
  if (running) autopause_tap();   // Start once: the game's pause menu opens (if it is open already nothing is pressed)
  log_line("GAMEMENU the player asked for the game's pause menu (objectives): game running=%d, Start %s, the auto-close helper waits 3 minutes", running, running ? "tapped" : "not tapped (already paused)");
}
// 1.7.84: the live pages froze the game for a while (its simulation stamp is old now), so "running" would read false: the player was playing a moment ago, Start is tapped for sure
void game_menu_request_force() {
  const DWORD now = GetTickCount();
  g_userMenuUntil = now + 180000; if (!g_userMenuUntil) g_userMenuUntil = 1;
  autopause_tap();
  log_line("GAMEMENU the player asked for the game's pause menu from the live pages: Start tapped (the game was only frozen, it was running), the auto-close helper waits 3 minutes");
}
// 1.7.28 the hand-held game menu asks these: is the game paused, did the player ask for the pause menu, keep the latch while it is up, and close it again (Start once)
int game_paused_flag() {
  const uint8_t* a = (const uint8_t*)g_appSeen;
  const int p1 = a && memory_readable_any(a + layout::kAppPaused, 1) ? (a[layout::kAppPaused] ? 1 : 0) : 0;
  const int p2 = memory_readable_any((const void*)rva(0x20B01D0), 1) ? (*(volatile uint8_t*)rva(0x20B01D0) ? 1 : 0) : 0;
  return (p1 || p2) ? 1 : 0;
}
int game_menu_requested() { return g_userMenuUntil && (int32_t)(GetTickCount() - g_userMenuUntil) < 0; }
void game_menu_keep() { g_userMenuUntil = GetTickCount() + 20000; if (!g_userMenuUntil) g_userMenuUntil = 1; }
void game_menu_release() { g_userMenuUntil = 0; }   // 1.7.29: the hand-held menu is over (the game closed it itself): the request ends, nothing is pressed
void game_menu_close(const char* why) {
  g_userMenuUntil = 0;
  autopause_tap();   // Start once: the pause menu closes and the game runs on
  log_line("GAMEMENU the player closed the game's pause menu (%s): Start tapped, the auto-close helper is free again", why);
}
// 1.7.9: what the game looked like when it called ExitProcess (the 1.7.8 run ended by itself right after a pause-menu cycle)
void engine_exit_context(char* out, int n) {
  const DWORD now = GetTickCount();
  const uint8_t* a = (const uint8_t*)g_appSeen;
  const int paused = a && memory_readable_any(a + layout::kAppPaused, 1) ? (int)a[layout::kAppPaused] : -1;
  const int pausedB = memory_readable_any((const void*)rva(0x20B01D0), 1) ? (int)*(volatile uint8_t*)rva(0x20B01D0) : -1;
  wsprintfA(out, "Start taps made by the probe so far %ld, the last one %ld ms ago (-1 = never) | game paused flag %d / byte %d | sim ran %ld ms ago | menu open %d | present frames %ld",
            (long)g_startTapsTotal, g_lastStartTapTick ? (long)(now - g_lastStartTapTick) : -1L, paused, pausedB, g_lastSimMs ? (long)(now - g_lastSimMs) : -1L,
#if GBVR_HEADTRACK
            vrmenu_is_open(),
#else
            0,
#endif
            (long)render_present_count());
  (void)n;
}
// 0.54 the in-VR menu freezes the world: while pulses keep coming (each lasts 300 ms) the main loop's App::Simulate is left out,
// exactly what the game does itself when paused. Rendering, head and hand tracking go on, so the player still moves his arm.
static volatile DWORD g_freezeUntil;
static struct { volatile LONG skipped, starts; DWORD from, longestMs; } g_fz;
void engine_freeze_pulse(int on) {
  const DWORD now = GetTickCount();
  if (!on) { g_freezeUntil = 0; return; }
  g_freezeUntil = now + 300;
}
int engine_freeze_active() { return g_freezeUntil && (int32_t)(g_freezeUntil - GetTickCount()) > 0; }
int game_running_now() { return autop::running_from_stamp(GetTickCount(), g_lastSimMs); }
unsigned autopause_buttons() {
  const DWORD now = GetTickCount();
  if (g_tapUntil && (int32_t)(now - g_tapFrom) >= 0 && (int32_t)(now - g_tapUntil) < 0) return (unsigned)pad::kStart;
  if (!g_apOn) return 0;
  return ((int32_t)(now - g_apFrom) >= 0 && (int32_t)(now - g_apUntil) < 0) ? (unsigned)pad::kStart : 0u;
}
static void autopause_tick(void* app) {
  const DWORD now = GetTickCount();
  const int running = autop::running_from_stamp(now, g_lastSimMs) || engine_freeze_active();   // 0.54: frozen by the menu = the game would run
#if GBVR_HEADTRACK
  // 0.56: SteamVR's laser mode (menu open) takes and gives back the controllers: those focus events are not "the player left"
  static int s_prevRaw, s_ignored;
  const int rawLeaves = vr_capi_leave_count();
  if (vrmenu_quiet()) s_ignored += rawLeaves - s_prevRaw;
  s_prevRaw = rawLeaves;
  const int leaves = rawLeaves - s_ignored + (int)g_manualLeave;
#else
  const int leaves = 0;
#endif
  // 0.61 NOPAUSEMENU: the game's own pause menu kept popping up in VR and froze the game (0.60 log: my menu's "resume" tapped Start while the
  // world only stood still, which OPENED the pause menu; SteamVR focus events did the same). If the game reports "paused" for 1.5 s while the
  // headset view runs and my menu is closed, tap Start to get back in (3 tries, then 20 s rest).
  {
    static DWORD s_since, s_lastTap, s_rest; static int s_tries, s_taps, s_seen;
    const uint8_t* a = (const uint8_t*)app;
    const int paused = (a && memory_readable_any(a + layout::kAppPaused, 1) && a[layout::kAppPaused]) ||
                       (memory_readable_any((const void*)rva(0x20B01D0), 1) && *(volatile uint8_t*)rva(0x20B01D0));
    int menuOpen = 0;
#if GBVR_HEADTRACK
    menuOpen = vrmenu_is_open();
#endif
    static DWORD s_menuPausedSince;
    if (menuOpen && paused && g_ctl.stereoActive && !g_ctl.heldMenu) {   // 0.65 (1.7.28: not with the hand-held menu: the game is paused on purpose there) the game got paused while my menu is open (0.64 log: the player was stuck): close the menu, then the normal escape taps Start
      if (!s_menuPausedSince) s_menuPausedSince = now;
      if ((int32_t)(now - s_menuPausedSince) > 2500) { s_menuPausedSince = 0; log_line("NOPAUSEMENU the game stayed paused 2.5 s with my menu open: closing my menu"); 
#if GBVR_HEADTRACK
        vrmenu_toggle("game paused");
#endif
      }
    } else s_menuPausedSince = 0;
    const int userMenu = g_userMenuUntil && (int32_t)(now - g_userMenuUntil) < 0;   // 1.7.11
    if (!g_ctl.noPauseMenu || !g_ctl.stereoActive || menuOpen || !paused || userMenu) { if (s_since) { s_since = 0; s_tries = 0; } }
    else {
      if (!s_since) { s_since = now; ++s_seen; log_line("NOPAUSEMENU the game reports paused (appPaused/pausedByte): waiting 0.4 s before tapping Start (seen=%d taps=%d)", s_seen, s_taps); }
      if ((int32_t)(now - s_since) > 400 && (int32_t)(now - s_rest) >= 0 && (int32_t)(now - s_lastTap) > 2500) {   // 1.7.9: 2.5 s between taps (1.7.8: 0.9 s; the 1.7.8 run ended with a third tap right after the game had left its pause menu, a Start tap with no pause menu OPENS it)
        if (s_tries < 3) { ++s_tries; ++s_taps; s_lastTap = now; autopause_tap(); log_line("NOPAUSEMENU Start tapped to leave the game's pause menu (try %d)", s_tries); }
        else { s_rest = now + 20000; s_tries = 0; s_since = 0; log_line("NOPAUSEMENU gave up for 20 s (the game stayed paused)"); }
      }
    }
  }
  const int what = g_pauser.update(now, leaves, running, g_ctl.autoPause != 0);
  g_apFrom = g_pauser.holdFrom; g_apUntil = g_pauser.holdUntil;
  g_apOn = g_pauser.phase == 1;
  if (what) {
    static const char* const kWhat[] = {"", "Start pressed", "skipped: auto_pause is off", "skipped: the game is already paused / in a menu",
                                        "skipped: already pressing", "the game stopped: PAUSED", "the game still runs: pressing again", "the game still runs: gave up"};
    const uint8_t* a = (const uint8_t*)app;
    log_line("AUTOPAUSE %s (why=%d leaveEvents=%d running=%d simAgeMs=%d try=%d appPaused=%d pausedByte=%d pauseFlag=%d stereo=%d flat=%d)", kWhat[what],
             vr_capi_leave_why(), leaves, running, g_lastSimMs ? (int)(now - g_lastSimMs) : -1, g_pauser.tries,
             a && memory_readable_any(a + layout::kAppPaused, 1) ? (int)a[layout::kAppPaused] : -1,
             memory_readable_any((const void*)rva(0x20B01D0), 1) ? (int)*(volatile uint8_t*)rva(0x20B01D0) : -1, (int)g_ctl.pauseFlag, (int)g_ctl.stereoActive,
             stereo_in_flat_mode());
  }
}
void autopause_report(LONG frame) {
  {   // 0.63 SMOKE: one line saying whether this run is worth playtesting (VR-mod playbook "smoke test on every launch")
    static int s_smoke;
    if (!s_smoke && frame >= 900 && g_ctl.stereoActive) {
      s_smoke = 1;
      log_line("SMOKE version=%s stereo=%d flat=%d pad=%d realModels=%d bodyFollow=%d fullBody=%d armIk=%d menuOwnPointer=%d noPauseMenu=%d autoPause=%d menuFreeze=%d picture=%d gameTicks=%d "
               "gunGlue=%d armStretch=%d%% memCache=%d height=%d%% world=%d%% -> %s", GBVR_VERSION, (int)g_ctl.stereoActive, stereo_in_flat_mode(), (int)g_ctl.padEnabled, (int)g_ctl.realModels, (int)g_ctl.bodyFollow, (int)g_ctl.fullBody, (int)g_ctl.armIk,
               (int)g_ctl.menuOwnPointer, (int)g_ctl.noPauseMenu, (int)g_ctl.autoPause, (int)g_ctl.menuFreeze, (int)g_ctl.pictureLevel, (int)g_st.tickCalls,
               (int)g_ctl.gunGlue, (int)g_ctl.armStretchPct, (int)memcache::g_enabled, (int)g_ctl.sizePct, (int)g_ctl.worldPct,
               (g_ctl.bodyFollow && g_ctl.fullBody && g_ctl.armIk && g_ctl.realModels && g_st.tickCalls > 0) ? "OK: body layer enabled" : "WARNING: body layer disabled - do not judge the body");
    }
  }
  log_line("FREEZE frame=%d on=%d active=%d simsLeftOut=%d freezes=%d longestMs=%u", (int)frame, (int)g_ctl.menuFreeze, engine_freeze_active(), (int)g_fz.skipped, (int)g_fz.starts, g_fz.longestMs);
  log_line("AUTOPAUSE frame=%d on=%d events=%d started=%d paused=%d retries=%d failed=%d skipped(off/menu/busy)=%d/%d/%d last=%s", (int)frame, (int)g_ctl.autoPause,
           g_pauser.events, g_pauser.started, g_pauser.paused, g_pauser.retries, g_pauser.failed, g_pauser.skipOff, g_pauser.skipNotRunning,
           g_pauser.skipBusy, g_pauser.lastResult == 1 ? "paused" : g_pauser.lastResult == 2 ? "gave-up" : "none");
}

static void di_takeover_if_armed();
static GBVR_NOINLINE void hk_app_simulate_impl(void* app, void* ret) {
  int mainLoop = (uintptr_t)ret == rva(layout::kRvaAppSimulateRet);  // only the main loop's own call
  if (mainLoop) di_takeover_if_armed();   // 1.7.92
  if (mainLoop && engine_freeze_active()) {   // 0.54 the in-VR menu is open: the world stands still
    const DWORD now = GetTickCount();
    if (!g_fz.from) { g_fz.from = now; InterlockedIncrement(&g_fz.starts); }
    InterlockedIncrement(&g_fz.skipped);
    fight_trap_deploy_drop();   // 1.7.188: a trap throw asked for just before the menu opened is not thrown after it closes
    return;
  }
  if (mainLoop && g_fz.from) {
    const DWORD ms = GetTickCount() - g_fz.from;
    if (ms > g_fz.longestMs) g_fz.longestMs = ms;
    log_line("FREEZE ended after %u ms (simulations left out so far %d, freezes %d, longest %u ms)", ms, (int)g_fz.skipped, (int)g_fz.starts, g_fz.longestMs);
    g_fz.from = 0;
  }
  if (mainLoop) g_lastSimMs = GetTickCount();
  if (g_skipSim) {
    g_skipSim = 0;
    if (mainLoop) {
      if (!key_release_pending()) {
        InterlockedIncrement(&g_st.simSkipped);
        return;
      }
      // A key release / wheel notch is waiting: this simulation runs after
      // all (with the short step the tick gave it, so the two eyes are 0.12 ms
      // apart instead of exactly equal). That step is now real game time:
      // the timer's previous-tick time moves on by it, so the next long step
      // does not count it twice.
      InterlockedIncrement(&g_st.simKeptForInput);
      if (app == g_appSeen && memory_readable((const uint8_t*)app + layout::kAppLastTick, 12)) {
        *(volatile uint32_t*)((uint8_t*)app + layout::kAppLastTick) += (uint32_t)g_shortLimitUsed * layout::kTimerUnitsPerTick;
        // The timer's unlimited "real time since the previous tick" still says
        // the whole first-eye iteration; the next tick will count that time
        // again, so this simulation gets the short step there too.
        *(volatile float*)((uint8_t*)app + layout::kAppRealStep) = (float)g_shortLimitUsed / 65536.0f;
      }
    }
  }
  if (g_drainBeforeSim) {
    // The second eye's picture is still being drawn on the render thread.
    // The game would start moving the world now and wait for the render
    // thread afterwards; wait first instead (the engine's own wait, the one
    // the main loop calls right after the simulation), so that the second eye
    // is drawn from exactly the state the first eye was drawn from, whether or
    // not the renderer reads live objects.
    g_drainBeforeSim = 0;
    if (mainLoop) {
      ((void(__fastcall*)(void*))rva(layout::kRvaWaitQueue))((void*)rva(layout::kRvaRenderQueue));
      InterlockedIncrement(&g_st.drainBeforeSim);
    }
  }
#if GBVR_HEADTRACK
  if (mainLoop && fight_trap_deploy_pending()) {   // 1.7.188: the trap throw (the game's own deployTrap) runs HERE, with the render queue empty, not inside the drawing
    ((void(__fastcall*)(void*))rva(layout::kRvaWaitQueue))((void*)rva(layout::kRvaRenderQueue));
    fight_trap_deploy_run(head_aim_actor());
  }
#endif
  o_appSimulate(app);
#if GBVR_HEADTRACK
  if (mainLoop) trap_carry_step();   // 1.7.188 "the trap flickered": the game puts its trap back at its own place every simulation (2780 of 5566 frames in the report); it is moved to the hand again straight away, before anything is drawn from the new state
  if (mainLoop) { boost_after_sim(app); goggles_after_sim(); }   // 1.7.9: the sprint speed boost lives here (the character update it used to hang on never ran for the player); the goggles are watched here
#endif
}

static void __fastcall hk_app_simulate(void* app) { ProfScope ps(PF_SIM); stage_g(ST_G_SIMULATE); crumb("sim:in", 0); hk_app_simulate_impl(app, GBVR_RETURN_ADDRESS()); crumb("sim:out", 0); }

// 0.58 the eye-pair ticks go through here. With a menu open or the game paused App::Tick ignores the fps it is given and
// waits for 30 FPS (layout.h kAppFpsCapFlag); every eye of a pair is one Tick, so a paused game could not give the headset
// more than 15 pairs per second (0.55: 13 FPS "ran like crap"). The same one-call byte clear the menu path (menu_fast) uses.
static void tick_pair(void* app, float fps) {
  if (g_ctl.menuFast && memory_readable((const uint8_t*)app + layout::kAppFpsCapFlag, 1)) {
    volatile uint8_t* flag = (volatile uint8_t*)((uint8_t*)app + layout::kAppFpsCapFlag);
    if (*flag == 1) {
      *flag = 0;
      o_appTick(app, fps);
      *flag = 1;
      InterlockedIncrement(&g_st.pairTickUncapped);
      return;
    }
  }
  o_appTick(app, fps);
}

static volatile DWORD g_mainTid;

// ---- 0.60 where does the game's main thread wait? ---------------------------------------------------------------------
// 0.59 test: the level never finished loading, Presents kept coming, the main-loop stage stayed "game-wand-tip" = the main thread
// sat inside one call for a minute. Called once per second from the heartbeat thread: when the Tick count has not moved for
// 6 s, the main thread is suspended for a moment and its instruction pointer and the return addresses on its stack are logged
// (as ghost.exe offsets), again after 20 s and 60 s. Does nothing in normal play (ticks keep coming).
void engine_main_stall_check() {
  static LONG s_lastTicks = -1;
  static DWORD s_since;
  static int s_reports;
  const LONG t = g_st.tickCalls;
  if (t != s_lastTicks || t == 0) { s_lastTicks = t; s_since = GetTickCount(); s_reports = 0; return; }
  const DWORD secs = (GetTickCount() - s_since) / 1000;
  const DWORD due[5] = {2, 4, 8, 20, 60};   // 0.86: sooner (0.85 died 4 s after its last line)
  if (s_reports >= 5 || secs < due[s_reports]) return;
  ++s_reports;
  const DWORD tid = g_mainTid;
  HANDLE h = tid ? OpenThread(THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION, FALSE, tid) : nullptr;
  if (!h) { log_line("MAINSTALL no Tick for %u s (tid=%u): thread not opened", (unsigned)secs, (unsigned)tid); return; }
  alignas(16) CONTEXT cx;
  ZeroMemory(&cx, sizeof(cx));
  cx.ContextFlags = CONTEXT_CONTROL | CONTEXT_INTEGER;
  uintptr_t rip = 0, rsp = 0;
  uintptr_t found[24]; int nf = 0;
  const uintptr_t base = g_game.base, size = g_game.sizeOfImage;
  if (SuspendThread(h) != (DWORD)-1) {
    if (GetThreadContext(h, &cx)) {
      rip = (uintptr_t)cx.Rip; rsp = (uintptr_t)cx.Rsp;
      for (int i = 0; i < 192 && nf < 24; ++i) {
        const uintptr_t* q = (const uintptr_t*)(rsp + (uintptr_t)i * 8);
        if (!memory_readable(q, 8)) break;
        const uintptr_t v = *q;
        if (v > base && v < base + size) found[nf++] = v - base;
      }
    }
    ResumeThread(h);
  }
  CloseHandle(h);
  {   // 0.82: which module the stuck code belongs to (a graphics driver, SteamVR, the probe ...)
    char mod[120]; mod[0] = 0;
    HMODULE hm = nullptr;
    if (rip && GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)rip, &hm) && hm) {
      char path[260]; path[0] = 0;
      GetModuleFileNameA(hm, path, sizeof(path));
      const char* nm = path; for (const char* c = path; *c; ++c) if (*c == '\\' || *c == '/') nm = c + 1;
      log_fmt(mod, (int)sizeof(mod), "%s+0x%x", nm, (unsigned)(rip - (uintptr_t)hm));
    } else log_fmt(mod, (int)sizeof(mod), "(no module)");
    log_line("MAINSTALL the stuck instruction is in %s", mod);
  }
  char buf[400]; int len = 0;
  for (int i = 0; i < nf && len < 360; ++i) len += log_fmt(buf + len, (int)sizeof(buf) - len, " +0x%x", (unsigned)found[i]);
  buf[len < (int)sizeof(buf) ? len : (int)sizeof(buf) - 1] = 0;
  log_line("MAINSTALL no Tick for %u s: mainThread=%u stage=%s presents=%d rip=%s+0x%x rsp=%p ghost.exe return addresses on its stack:%s",
           (unsigned)secs, (unsigned)tid, stage_name(g_stageG), (int)g_ctl.worldFrames, (rip > base && rip < base + size) ? "ghost.exe" : "other-module", 
           (unsigned)((rip > base && rip < base + size) ? rip - base : rip), (void*)rsp, buf);
  log_flush_quiet();
}

// 0.74: one "same moment" tick: the game's Tick runs with a tiny step and the simulation that would follow is left out (the second eye of a pair,
// and with sim_every_n > 1 also the in-between pictures). Returns 1 if it did that, 0 if it could not (the caller then ticks normally).
static int g_simEveryCtr, g_simSkipFrame;
static int short_pair_tick(void* app, int prevShort) {
  const volatile int32_t* frameTicks = (const volatile int32_t*)rva(layout::kRvaFrameTicks);
  int32_t limit = stereo::short_tick_limit(1, g_ctl.stereoSameMoment != 0, prevShort, g_timeScaleSeen, kSameMomentTicks, kSameMomentMaxLimit);
  volatile int32_t* maxTicks = (volatile int32_t*)rva(layout::kRvaMaxFrameTicks);
  volatile uint32_t* last = (volatile uint32_t*)((uint8_t*)app + layout::kAppLastTick);
  const int32_t savedMax = *maxTicks;
  const uint32_t savedLast = *last;
  if (!(limit > 0 && savedMax >= 1024 && savedMax <= 65536)) return 0;   // the game's value is 4096; anything odd: leave it alone
  *maxTicks = limit;
  tick_pair(app, 1000.0f);
  *maxTicks = savedMax;
  int32_t got = *frameTicks;
  g_prevTickShort = 1;
  g_skipSim = o_appSimulate != nullptr;
  g_shortLimitUsed = limit;
  // The simulation that would have used this short step is left out, so none of its time is taken off the next (long) step.
  *last = savedLast + (g_skipSim ? 0u : (uint32_t)limit * layout::kTimerUnitsPerTick);
  InterlockedIncrement(&g_st.sameMoment);
  if (got >= 1 && got <= limit) InterlockedIncrement(&g_st.sameMomentOK);
  if (got == 0) InterlockedIncrement(&g_st.sameMomentZero);
  g_st.shortTicksLast = got;
  return 1;
}
static volatile LONG g_simEverySkipped, g_simEveryRan;

static void __fastcall hk_app_tick_inner(void* app, float fps) {
  stage_g(ST_G_TICK);
  g_mainTid = GetCurrentThreadId();
  autopause_tick(app);
  InterlockedIncrement(&g_st.tickCalls);
  {   // 0.58 time between ticks and whether the menu-cap byte was set when the tick started
    static int64_t s_lastTickQpc;
    const int64_t nowq = qpc_now();
    if (s_lastTickQpc) {
      const double gap = (double)(nowq - s_lastTickQpc) * 1000.0 / (double)qpc_freq();
      g_st.tickGapSumMs += gap; ++g_st.tickGapN;
      if (gap > g_st.tickGapMaxMs) g_st.tickGapMaxMs = gap;
      if (gap > 50.0) InterlockedIncrement(&g_st.tickGapOver50);
    }
    s_lastTickQpc = nowq;
    if (memory_readable((const uint8_t*)app + layout::kAppFpsCapFlag, 1) && *(const volatile uint8_t*)((const uint8_t*)app + layout::kAppFpsCapFlag) == 1) InterlockedIncrement(&g_st.tickCapSet);
  }
  g_appSeen = app;
  LONG role = InterlockedExchange(&g_tickRole, 0);
  {   // ROOFEYE (log only): in the roof fight, what happens to the tick after each eye
    static struct { long n[3], outOfBand, gapOver50; float fmin, fmax; int64_t q, lastFirstQ; } s_re;
    if (role && engine_scene_arms(0)) {
      ++s_re.n[role > 2 ? 0 : role];
      if (s_re.fmax == 0.0f) { s_re.fmin = s_re.fmax = fps; }
      if (fps < s_re.fmin) s_re.fmin = fps;
      if (fps > s_re.fmax) s_re.fmax = fps;
      if (!(fps > 100.0f && fps < 130.0f)) ++s_re.outOfBand;
      const int64_t nq = qpc_now();
      if (role == 1) s_re.lastFirstQ = nq;
      else if (s_re.lastFirstQ && (double)(nq - s_re.lastFirstQ) * 1000.0 / (double)qpc_freq() > 50.0) ++s_re.gapOver50;
      if (!s_re.q) s_re.q = nq;
      if ((double)(nq - s_re.q) / (double)qpc_freq() >= 5.0) {
        s_re.q = nq;
        log_line("ROOFEYE 5 s: ticks after first eye %ld, after second %ld | game's fps argument min %.1f max %.1f, outside 100..130 (same-moment branch skipped) %ld | first-eye tick -> second-eye tick gap over 50 ms %ld | short tick refused (normal tick between eyes) %ld | timeScale %.3f",
                 s_re.n[1], s_re.n[2], (double)s_re.fmin, (double)s_re.fmax, s_re.outOfBand, s_re.gapOver50, g_roofNotShort, (double)g_timeScaleSeen);
        s_re.n[1] = s_re.n[2] = s_re.outOfBand = s_re.gapOver50 = 0; s_re.fmin = s_re.fmax = 0.0f; g_roofNotShort = 0;
      }
    }
  }
  if (g_skipSim) {  // the iteration that just ended did not simulate at all (paused / loading): the request expires
    g_skipSim = 0;
    InterlockedIncrement(&g_st.simSkipExpired);
  }
  g_drainBeforeSim = 0;
  int prevShort = g_prevTickShort;
  g_prevTickShort = 0;
  if (role && g_ctl.stereoActive && g_ctl.stereoPair && fps > 100.0f && fps < 130.0f &&
      memory_readable((const uint8_t*)app + layout::kAppLastTick, 16)) {
    const volatile int32_t* frameTicks = (const volatile int32_t*)rva(layout::kRvaFrameTicks);
    if (role == 1) {  // the first eye was just prepared: the next iteration draws the second eye
      InterlockedIncrement(&g_st.tickAfterFirst);
      // 0.74 stuck-ghost test (setting sim_every_n): the game was built for 30 steps a second, the headset gives it about 72. With 2 the game simulates
      // only every second picture (about 36 steps a second, each about 28 ms): in the other pictures both ticks are short and leave the simulation out,
      // so the picture shows the same game moment again. (The usual "never two short ticks in a row" rule is lifted for this.)
      int effPrev = prevShort;
      if (g_ctl.simEveryN >= 2 && g_ctl.simEveryN <= 3 && g_ctl.stereoSameMoment && !engine_freeze_active()) {
        g_simEveryCtr = (g_simEveryCtr + 1) % (int)g_ctl.simEveryN;
        g_simSkipFrame = g_simEveryCtr != 0;
        effPrev = 0;
      } else { g_simEveryCtr = 0; g_simSkipFrame = 0; }
      // 1.7.211: in the Stay Puft roof fight the second eye gets a normal tick (full simulation) instead of the short same-moment one: the right eye showed only the health tube there (the scripted scene drew nothing for the no-simulate frame)
      if (!engine_scene_arms(0) && short_pair_tick(app, effPrev)) return;
      if (engine_scene_arms(0)) ++g_roofNotShort;   // ROOFEYE counter only
      if (g_ctl.stereoSameMoment) InterlockedIncrement(&g_st.sameMomentSkipped);
      tick_pair(app, 1000.0f);
      return;
    }
    // The second eye was just prepared. Without "same moment" this tick comes
    // only a few milliseconds after the previous one: no 120 FPS wait here.
    InterlockedIncrement(&g_st.tickAfterSecond);
    InterlockedIncrement(&g_st.tickLifted);
    if (g_simSkipFrame) {   // 0.74 sim_every_n: this picture leaves the simulation out
      g_simSkipFrame = 0;
      if (short_pair_tick(app, 0)) { InterlockedIncrement(&g_simEverySkipped); return; }
    } else if (g_ctl.simEveryN >= 2) InterlockedIncrement(&g_simEveryRan);
    g_drainBeforeSim = g_ctl.stereoSameMoment != 0 && o_appSimulate != nullptr;
    tick_pair(app, 1000.0f);
    int32_t scaled = *frameTicks;
    float raw = *(const volatile float*)((const uint8_t*)app + layout::kAppRawStep) * 65536.0f;
    g_st.longTicksLast = scaled;
    if (raw >= 64.0f && vm::is_finite_f(raw)) g_timeScaleSeen = (float)scaled / raw;  // 1.0 except in slow motion
    return;
  }
  // 0.43: menus and the pause screen. The game's main loop only clears App::Tick's "use the stored cap" byte
  // while it runs normally; with a menu open or the game paused the byte stays 1 and Tick waits for 30 FPS
  // whatever it is told (layout.h kAppFpsCapFlag). In the headset the compositor already paces every frame
  // (the render thread waits for it), so the extra wait only costs frame rate (flat mode: the Present wait is
  // removed too, flat_vsync_off): clear the byte for this one
  // call - exactly what the main loop does for normal play - and put it back.
  // 0.45: the same outside the headset (flat mode): the menus were held to 30 FPS there too (video: 27-30 FPS menus)
  if ((g_ctl.stereoActive ? g_ctl.stereoWanted != 0 : g_ctl.flatVsyncOff != 0) && g_ctl.menuFast && fps > 100.0f && fps < 130.0f &&
      memory_readable((const uint8_t*)app + layout::kAppFpsCapFlag, 1)) {
    volatile uint8_t* flag = (volatile uint8_t*)((uint8_t*)app + layout::kAppFpsCapFlag);
    if (*flag == 1) {
      *flag = 0;
      o_appTick(app, fps);
      *flag = 1;
      InterlockedIncrement(&g_st.menuTickLifted);
      // 0.44 fail-safe: the time step the game measured for this menu frame must be believable. Three odd ones
      // and the change switches itself off (the menus are held to 30 FPS again, nothing else is touched).
      // (the raw step, before the game's time scale: the scale is 0 while the game is paused, which is normal)
      float rawStep = *(const volatile float*)((const uint8_t*)app + layout::kAppRawStep);
      int32_t got = vm::is_finite_f(rawStep) && rawStep >= 0.0f && rawStep < 30000.0f ? (int32_t)(rawStep * 65536.0f) : -1;
      if (!safety::menu_tick_sane(got) && InterlockedIncrement(&g_st.menuTickBad) >= 3) {
        InterlockedExchange(&g_ctl.menuFast, 0);
        safety_issue(IS_MENUFAST_OFF);
        log_line("SAFETY menu_fast switched OFF: the game's frame time step in a menu was %d ticks (1/65536 s) three times (expected 1..70000)", (int)got);
        settings_changed();
      }
      return;
    }
  }
  o_appTick(app, fps);
}
// 0.73 stuck ghosts ("stuck in walls / floor", always, in every version): the game's behaviour callbacks read the UNLIMITED real time since the
// previous tick (App+0x1B4, layout.h), and the tick itself limits a step only at 4096 ticks (62 ms). Every hitch (level streaming, a slow frame:
// 43 stalls over 50 ms in one 8-minute log) therefore reached ghost movement as one big step, enough to carry a ghost through a wall or into the
// floor. Now (headset only, setting sim_step_cap_ms, default 33): the tick's own limit is lowered to the cap and the unlimited step is clamped to it
// after every tick. Normal steps (about 14 ms per eye pair) are untouched. A hitch becomes a moment of slow motion instead of a jump.
static struct {
  volatile LONG ticks, bucket[5], clamped, capApplied, capSeen;
  float maxMs; int hitchLogged; int32_t capTicks, gameCapTicks;
} g_stepSt;
static void step_guard_before() {
  const int ms = (int)g_ctl.simStepCapMs;
  if (!g_ctl.stereoActive || ms < 20) return;
  volatile int32_t* mt = (volatile int32_t*)rva(layout::kRvaMaxFrameTicks);
  if (!memory_readable((const void*)mt, 4)) return;
  const int32_t want = (int32_t)((double)ms * 65.536);
  const int32_t cur = *mt;
  if (cur >= 1024 && cur <= 65536) {
    if (!g_stepSt.gameCapTicks && cur > want) g_stepSt.gameCapTicks = cur;   // what the game itself had (4096)
    if (cur > want) { *mt = want; InterlockedIncrement(&g_stepSt.capApplied); }
    g_stepSt.capTicks = *mt;
  }
}
static void step_guard_after(void* app) {
  if (!memory_readable((const uint8_t*)app + layout::kAppRealStep, 4)) return;
  volatile float* rs = (volatile float*)((uint8_t*)app + layout::kAppRealStep);
  const float v = *rs;
  if (!vm::is_finite_f(v) || v < 0.0f || v > 1000.0f) return;
  const float ms = v * 1000.0f;
  InterlockedIncrement(&g_stepSt.ticks);
  InterlockedIncrement(&g_stepSt.bucket[ms < 10.0f ? 0 : ms < 20.0f ? 1 : ms < 33.0f ? 2 : ms < 62.0f ? 3 : 4]);
  if (ms > g_stepSt.maxMs) g_stepSt.maxMs = ms;
  const int capMs = (int)g_ctl.simStepCapMs;
  if (g_ctl.stereoActive && capMs >= 20 && ms > (float)capMs) {
    *rs = (float)capMs / 1000.0f;
    InterlockedIncrement(&g_stepSt.clamped);
    if (g_stepSt.hitchLogged < 30) {
      ++g_stepSt.hitchLogged;
      log_line("SIMSTEP hitch: the game saw %.0f ms since the previous tick; the steps ghosts and other behaviours get are limited to %d ms (frame %d, game stage %s, menu freeze %d)",
               (double)ms, capMs, (int)g_ctl.worldFrames, stage_name(g_stageG), engine_freeze_active());
    }
  }
}
void step_report(LONG frame) {
  log_line("SIMSTEP frame=%d cap=%dms gameCapTicks=%d nowCapTicks=%d ticks=%d steps(<10/10-20/20-33/33-62/>=62ms)=%d/%d/%d/%d/%d longestMs=%.0f clamped=%d capWrites=%d",
           (int)frame, (int)g_ctl.simStepCapMs, (int)g_stepSt.gameCapTicks, (int)g_stepSt.capTicks, (int)g_stepSt.ticks, (int)g_stepSt.bucket[0], (int)g_stepSt.bucket[1], (int)g_stepSt.bucket[2],
           (int)g_stepSt.bucket[3], (int)g_stepSt.bucket[4], (double)g_stepSt.maxMs, (int)g_stepSt.clamped, (int)g_stepSt.capApplied);
  log_line("SIMEVERY setting sim_every_n=%d: pictures that left the simulation out=%d, that ran it=%d", (int)g_ctl.simEveryN, (int)g_simEverySkipped, (int)g_simEveryRan);
}
static void gamepad_type_keep();   // 1.7.86 (defined with the controller-type code)
static void stuck_watch();         // 1.7.92
static void __fastcall hk_app_tick(void* app, float fps) {
  ProfScope ps(PF_TICK);
  crumb("tick:in", g_st.tickCalls);
  step_guard_before();
  hk_app_tick_inner(app, fps);
  step_guard_after(app);
  knock_guard();
  gamepad_type_keep();   // 1.7.86: the game reads the pad in play only while its controller type is "gamepad"
  stuck_watch();         // 1.7.92
  crumb("tick:out", g_st.tickCalls);
}
#endif

static void hk_basis_impl(const float* m, void* ret) {
  InterlockedIncrement(&g_st.basisCalls);
  if (g_ownerTid == (LONG)GetCurrentThreadId() && g_armRotValid && !g_armApplied &&
      (uintptr_t)ret == rva(layout::kRvaBasisReturn)) {
    InterlockedIncrement(&g_st.basisMatched);
    float in[9], out[9];
    for (int i = 0; i < 9; ++i) in[i] = m[i];
    if (vm::is_rotation(in)) {
      if (g_armStereo.valid) {
        // Headset: level yaw-only basis * head rotation (computed before the
        // prepare so the eye offset used the same axes). The game's own
        // pitch/roll are left out so the horizon stays level.
        for (int i = 0; i < 9; ++i) out[i] = g_armStereo.view[i];
        double y;
        if (g_armStereo.reused) {
          // second eye of a pair: deliberately the first eye's yaw, not this frame's
        } else if (stereo::basis_yaw(in, &y) && stereo::angle_diff(y, g_armStereo.yaw) <= 2e-3)
          InterlockedIncrement(&g_st.stereoYawAgree);
        else if (InterlockedIncrement(&g_st.stereoYawDiffer) <= 5)
          log_floats("STEREOYAW engine basis does not match the camera yaw field", in, 9);
      } else {
        vm::mul(in, g_armRot, out);
      }
      if (vm::is_rotation(out)) {
        g_armApplied = 1;
        for (int i = 0; i < 9; ++i) { g_armOriginal[i] = in[i]; g_armOut[i] = out[i]; }
        InterlockedIncrement(&g_st.modifiedCalls);
        o_basis(out);  // the engine's normal setter receives the rotated view
        // Read back what the engine stored for the prepared view.
        double applyErr = max_abs_diff((const float*)rva(layout::kRvaGlobalBasis), out, 9);
        if (applyErr <= 1e-6) InterlockedIncrement(&g_st.applyVerifyOK);
        else InterlockedIncrement(&g_st.applyVerifyFail);
        if (applyErr > g_worstApplyError) g_worstApplyError = applyErr;
        if (g_armMode == MODE_MANUAL) {
          double e = vm::yaw_math_error(in, out, g_armDegrees);
          InterlockedIncrement(&g_st.mathChecks);
          if (e > g_worstMathError) g_worstMathError = e;
        }
        if (g_armSample) {
          InterlockedIncrement(&g_samplesTaken);
          log_line("ENGINEYAW frame=%d tid=%u callerRVA=%x mode=%s centiDegrees=%d applied=1",
                   (int)g_ctl.worldFrames, GetCurrentThreadId(), (unsigned)((uintptr_t)ret - g_game.base),
                   g_armStereo.valid ? "stereo" : g_armMode == MODE_HEAD ? "head" : "manual",
                   (int)(g_armDegrees * 100.0));
          log_floats("YAWORIGINAL", in, 9);
          log_floats("YAWAPPLIED", out, 9);
          log_line("APPLYVERIFY globalBasisMaxDiff=%.3g", applyErr);
        }
        return;
      }
    }
    LONG n = InterlockedIncrement(&g_st.invalidBasis);
    if (n <= 5) log_floats("BASISINVALID", in, 9);
    o_basis(m);
    gate_suspend("basis gate: engine basis or result not a valid rotation");
    return;
  }
  o_basis(m);
}

static GBVR_NOINLINE void __fastcall hk_basis(const float* m) { hk_basis_impl(m, GBVR_RETURN_ADDRESS()); }

static void hk_visibility_impl(void* cam, void* ctx, void* ret) {
  InterlockedIncrement(&g_st.visibilityCalls);
  DWORD tid = GetCurrentThreadId();
  int paired = (uintptr_t)ret == rva(layout::kRvaVisibilityReturn) && g_lastTid == tid && g_lastCamera == cam;
  if (paired && g_lastModified) {
    InterlockedIncrement(&g_st.visibilityPaired);
    // The world query/hull is built from ctx+0x6A3C8, snapshotted from the
    // global basis. Confirm it still holds our rotated basis at this point.
    double d = max_abs_diff((const float*)rva(layout::kRvaGlobalBasis), g_lastOut, 9);
    if (d <= 1e-6) InterlockedIncrement(&g_st.visibilityBasisMatch);
    else InterlockedIncrement(&g_st.visibilityBasisDiffer);
  }
  if (paired && g_lastEyeApplied) {
    // The sector query must start from the same (first-person) eye.
    for (int i = 0; i < 3; ++i) g_visEye[i] = g_lastEye[i];
#if GBVR_HEADTRACK
    {   // 1.7.209: one sector point per eye pair: the second eye asks the game's sector/portal query from the first eye's point (the eyes are 0.2 ft apart; the picture is still drawn from each eye's own position). The right eye went missing in the Stay Puft roof fight and against walls.
      static int64_t s_vq; static float s_ve[3];
      if (g_armStereo.pairQ) {
        if (g_armStereo.pairRole == 1) { s_vq = g_armStereo.pairQ; for (int i = 0; i < 3; ++i) s_ve[i] = g_lastEye[i]; }
        else if (g_armStereo.pairRole == 2 && s_vq == g_armStereo.pairQ) for (int i = 0; i < 3; ++i) g_visEye[i] = s_ve[i];
      }
    }
#endif
    g_visEyeApplied = 0;
    InterlockedExchange(&g_visEyeTid, (LONG)tid);
    o_visibility(cam, ctx);
    InterlockedExchange(&g_visEyeTid, 0);
    return;
  }
  o_visibility(cam, ctx);
}

static GBVR_NOINLINE void __fastcall hk_visibility(void* cam, void* ctx) {
  hk_visibility_impl(cam, ctx, GBVR_RETURN_ADDRESS());
}

static void hk_main_spatial_impl(void* view, const float* eye, void* ret) {
  if (g_visEyeTid == (LONG)GetCurrentThreadId() && !g_visEyeApplied && (uintptr_t)ret == rva(layout::kRvaSpatialReturn)) {
    g_visEyeApplied = 1;
    InterlockedIncrement(&g_st.spatialApplied);
    o_mainSpatial(view, g_visEye);
    if (max_abs_diff((const float*)((uint8_t*)view + layout::kViewSpatialEye), g_visEye, 3) <= 1e-6)
      InterlockedIncrement(&g_st.spatialVerifyOK);
    return;
  }
  o_mainSpatial(view, eye);
}

static GBVR_NOINLINE void __fastcall hk_main_spatial(void* view, const float* eye) {
  hk_main_spatial_impl(view, eye, GBVR_RETURN_ADDRESS());
}

#if GBVR_HEADTRACK
// ---- Own body in first person (0.28, layout.h "Own body") --------------------
// In first person the eye sits inside the player's head, so the player's own
// body, head and proton pack were drawn around and below the eye. The game
// already has a way to hide exactly those: its first-person PKE-goggles view
// makes the player's items "mirror only" - they are still drawn in mirrors and
// into the shadow maps (the player keeps a shadow and a reflection) but not in
// the main view. The probe gives that same answer for the player's own items
// while the main view is being collected and the first-person eye was placed
// in that view; everything else (other Ghostbusters, the PKE meter, which also
// asks) gets the game's own answer. Nothing is written into the game: the
// answer only goes into this frame's draw blocks, so the body is back on the
// next frame when the feature is off.
//
// 0.30: "the body did not fully disappear" (0.28 pictures: the wand stayed, and
// the invisible body still threw its shadow right under the player - a dark
// shape on the floor, very visible while knocked down). Now:
//   - the wand is hidden with the body by default (Shift+F1 brings it back);
//   - the second item of the extra body pass (0x10B800, a thigh piece) is
//     included - 0.28/0.29 left it to the game's answer;
//   - shadow: the answer is 2 instead of 1. Every reader of the stored byte
//     only tests it for zero, so for the game it is the same answer (hose and
//     wand: the game itself overwrites it with 1 for up to 0.25 s after the PKE
//     goggles are switched - their shadow shows for that moment); the two
//     readers that decide shadow drawing (0xEEC70 for body, pack, hose, wand and
//     the extra body's own callback 0x10F340) are hooked and treat 2 as "mirror
//     views only". The mark lives in this frame's draw blocks only.
//   - other call sites that ask the check for the player during the main view
//     are counted and logged (return address), so a missed part shows up.
typedef void(__fastcall* PFN_CameraRender)(void* cam, void* ctx);
typedef uint8_t(__fastcall* PFN_MirrorOnly)(void* gb);
typedef uint8_t(__fastcall* PFN_DrawPredicate)(void* actor, uint8_t flag, void* drawCtx);
typedef void(__fastcall* PFN_Body2Callback)(void* drawCtx);
static PFN_CameraRender o_cameraRender;
static PFN_MirrorOnly o_mirrorOnly;
static PFN_DrawPredicate o_drawPredicate;
static PFN_Body2Callback o_body2Callback;
static int g_bodyHooks;              // 1 installed, 0 not yet, <0 why not
static int g_shadowHooks;            // 0.30: 1 installed, 0 not yet, <0 why not
static volatile LONG g_inMainRender; // inside the main loop's active-camera render call
static void* g_selfActor;            // the camera's follow target, if it is a CGhostbuster
static int g_bodyClassLogged;
enum { kSiteBody, kSitePack, kSiteHose, kSiteBody2, kSiteWand, kSiteBody2b, kSiteCount };
static struct {
  volatile LONG renders, renderFp, wrongClass, noActor, hidden[kSiteCount], gameTrue, otherSites;
  volatile LONG shadowSkipped, mainSkipped, mirrorKept, body2ShadowSkipped, body2Skipped;
  volatile LONG predMainDrawn, predMainRefused, predShadowDrawn, predShadowRefused;   // 0.76: what the game itself decided for the player's parts (not the probe's mark)
  volatile LONG pkeShown[kSiteCount], pkeShowFrames, pkeShowAsked;   // 0.98: parts the game hid for its PKE view that the probe drew anyway; frames with the PKE out; questions asked in those frames
} g_bodySt;
static volatile LONG g_pkeShowNow;   // 0.98: this main render has the PKE out and 'body stays with the PKE' on

// 0.73: the game's own hose is hidden while the probe's physics cord is being drawn (fresh within half a second)
int64_t engine_hose_ok_q();
// 1.7.149: the game's own hose is never hidden by the mod (only hose_off 1 hides it): bent to the drawn gun when it can be, the game's own pose otherwise
static inline int cord_hides_hose() { return (g_ctl.hoseOff && g_ctl.realModels && g_ctl.firstPerson) || (g_ctl.cordPhysics && g_ctl.realModels && g_ctl.firstPerson && handmodel_cord_active() && !pke_mode()); }   // 0.90: hose_off hides the game's hose always (PKE too)

static GBVR_NOINLINE void hk_camera_render_impl(void* cam, void* ctx, void* ret) {
  int mainView = (uintptr_t)ret == rva(layout::kRvaCameraRenderRet) &&
                 cam == *(void* volatile*)rva(layout::kRvaActiveCameraPtr);
  // 0.73: also entered while only the game's hose is hidden (the probe draws the physics cord in its place)
  // 0.98: with the PKE out the game's own PKE view makes the player's parts "mirror only" (log: gameSaidMirrorOnly rose only while the PKE was out).
  // The probe answers "draw" for body, pack and the extra body pass in that case, so the avatar stays visible with the PKE in hand.
  const int pkeShow = mainView && g_ctl.pkeShowBody && g_ctl.realModels && g_ctl.firstPerson && pke_item_held() && !engine_scene_arms(0);
  if (!mainView || !(gb_hide_body() || cord_hides_hose() || pkeShow || engine_scene_arms(0) || engine_player_downed())) {
    o_cameraRender(cam, ctx);
    return;
  }
  InterlockedExchange(&g_pkeShowNow, pkeShow);
  if (pkeShow) InterlockedIncrement(&g_bodySt.pkeShowFrames);
  InterlockedIncrement(&g_bodySt.renders);
  void* actor = nullptr;
  if (memory_readable((const uint8_t*)cam + layout::kCamFollowTarget, 8))
    actor = *(void* const*)((const uint8_t*)cam + layout::kCamFollowTarget);
  if (!actor || !memory_readable(actor, 8)) {
    InterlockedIncrement(&g_bodyMv.noActor);
    actor = nullptr;
  } else if (*(const uintptr_t*)actor != rva(layout::kRvaGhostbusterVtable)) {
    if (InterlockedIncrement(&g_bodySt.wrongClass) <= 3)
      log_line("BODY the camera follows an object of another class (vtable rva %llx): left alone",
               (unsigned long long)(*(const uintptr_t*)actor - g_game.base));
    actor = nullptr;
  } else if (!g_bodyClassLogged) {
    g_bodyClassLogged = 1;
    log_line("BODY the camera follows a CGhostbuster at %p (the player): its own body is hidden in first person", actor);
  }
  g_selfActor = actor;
  g_lastEyeApplied = 0;              // set again by this render's own prepare
  LONG before = g_bodySt.hidden[kSiteBody];
  InterlockedExchange(&g_inMainRender, 1);
  o_cameraRender(cam, ctx);
  InterlockedExchange(&g_inMainRender, 0);
  InterlockedExchange(&g_pkeShowNow, 0);
  if (actor) g_be.actor = actor;   // 0.98: the render job of this frame counts this actor's parts per eye
  g_selfActor = nullptr;
  if (g_bodySt.hidden[kSiteBody] != before) InterlockedIncrement(&g_bodySt.renderFp);  // frames with the body hidden
}

int body_hiding_available() { return g_bodyHooks == 1; }
int body_shadow_hiding_available() { return g_shadowHooks == 1; }
static void __fastcall hk_camera_render(void* cam, void* ctx) { crumb("camrender:in", 0); hk_camera_render_impl(cam, ctx, GBVR_RETURN_ADDRESS()); crumb("camrender:out", 0); }

// ---- 1.7.27 the same picture in both eyes ----------------------------------------------------------------------------------------------------------------------------------------------------------------
// "sometimes the PKE / gun / view model shows in one eye but not the other". BODYEYE (1.7.26 log): per eye the game said "draw" 114781 / 112623 times and "no" 15460 / 16230 times, the probe's own hide mark hit
// 48510 / 48014 times: the two eyes' answers are not the same one in fifty. Both eyes are one game moment (SAMEMOMENT), so the answers should be the same: the left eye's answer for each player part is remembered
// and the right eye gets the very same answer (the 'mirror only' check, which decides the probe's hide mark, and the game's draw rule). Every case where the right eye's own answer differed is counted and the first
// ones are logged (PARITY), so the cause can still be found.
// 1.7.30: the 1.7.29 log showed the table of 48 entries too small: the left eye asked 234,944 times and the right eye 211,261 (the game draws more views in the first frame of a pair), and the right eye found no
// left answer 22,776 times (10 %) because entries were pushed out. Now 8192 entries, hashed, each stamped with the pair it belongs to; the view's kind is part of the key for the draw rule so two views of one
// frame cannot overwrite each other.
enum { kPmSize = 8192, kPmProbe = 24 };
static struct PairMemEnt { uintptr_t key; LONG stamp; int64_t q; int val; } g_pm[kPmSize];
static volatile LONG g_pmLock;
static struct { volatile LONG stored[2], replayed[2], differed[2], missing[2], logged, evictedLive, probeMax, replacedSame; } g_pmSt;   // by kind: 0 'mirror only' asks, 1 the draw rule
// 1.7.30 VIEWDRAW: which views ask for the player's own parts, per eye. [eye][class 0 main / 1 mirror view / 2 shadow pass][view type 0..7][pass 0..15]; "others" = asks about other actors, per eye.
static struct { volatile LONG n[2][3][8][16]; volatile LONG others[2]; volatile LONG lastTypeSeen[8]; } g_vd;
static void pm_lock() { while (InterlockedCompareExchange(&g_pmLock, 1, 0) != 0) YieldProcessor(); }
static void pm_unlock() { InterlockedExchange(&g_pmLock, 0); }
static inline uint32_t pm_hash(uintptr_t key) { return (uint32_t)(((uint64_t)key * 0x9E3779B97F4A7C15ull) >> 40) & (kPmSize - 1); }
// own = the answer this eye would give; returns the answer to use. kind 0/1; key identifies the part (object + site / draw item + pass).
static int pair_same_answer(int kind, uintptr_t key, int own, int site) {
  if (!g_ctl.pairSame || !g_ctl.stereoPair || !key) return own;
  const int eye = (int)(g_be.eye & 1);
  const LONG stamp = g_st.pairFirst;
  const int64_t now = qpc_now();
  int ret = own;
  pm_lock();
  const uint32_t h0 = pm_hash(key);
  int slot = -1, freeSlot = -1, probes = 0;
  for (int i = 0; i < kPmProbe; ++i) {
    const uint32_t ix = (h0 + (uint32_t)i) & (kPmSize - 1);
    ++probes;
    if (g_pm[ix].key == key) { slot = (int)ix; break; }
    if (freeSlot < 0 && (!g_pm[ix].key || g_pm[ix].stamp != stamp)) freeSlot = (int)ix;
    if (!g_pm[ix].key) break;   // an empty slot ends the chain: the key is not in the table
  }
  if (probes > g_pmSt.probeMax) InterlockedExchange(&g_pmSt.probeMax, probes);
  if (eye == 0) {
    if (slot >= 0) { if (g_pm[slot].stamp == stamp) InterlockedIncrement(&g_pmSt.replacedSame); }   // the same part asked twice in one frame: the later answer wins
    else if (freeSlot >= 0) slot = freeSlot;
    else { slot = (int)h0; InterlockedIncrement(&g_pmSt.evictedLive); }   // every slot of the chain still belongs to this pair: the table is too full (logged)
    g_pm[slot].key = key; g_pm[slot].stamp = stamp; g_pm[slot].q = now; g_pm[slot].val = own;
    InterlockedIncrement(&g_pmSt.stored[kind]);
  } else if (slot >= 0 && g_pm[slot].stamp == stamp && (double)(now - g_pm[slot].q) / (double)qpc_freq() < 0.12) {
    ret = g_pm[slot].val;
    InterlockedIncrement(&g_pmSt.replayed[kind]);
    if (ret != own) {
      InterlockedIncrement(&g_pmSt.differed[kind]);
      if (InterlockedIncrement(&g_pmSt.logged) <= 40)
        log_line("PARITY the right eye would have answered differently for a player part: %s site %d key %p | left eye %d, right eye's own answer %d -> both eyes now use %d (frame %d)", kind ? "draw rule" : "mirror-only check", site, (void*)key, g_pm[slot].val, own, ret, (int)g_ctl.worldFrames);
    }
  } else InterlockedIncrement(&g_pmSt.missing[kind]);
  pm_unlock();
  return ret;
}
static void parity_report(LONG frame) {
  log_line("PARITY frame=%d same_picture=%d | 'mirror only' checks: left stored %ld, right replayed %ld, right would have differed %ld, right had no left answer %ld | draw rule: stored %ld, replayed %ld, differed %ld, no left answer %ld (1.7.27: the right eye uses the left eye's answer for every player part, gun and PKE included)",
           (int)frame, (int)g_ctl.pairSame, g_pmSt.stored[0], g_pmSt.replayed[0], g_pmSt.differed[0], g_pmSt.missing[0], g_pmSt.stored[1], g_pmSt.replayed[1], g_pmSt.differed[1], g_pmSt.missing[1]);
  log_line("PARITYTABLE frame=%d entries=%d chainLongest=%d stampedOver(two answers for one part in one frame)=%d tableFull(left answers that pushed a live one out)=%d (1.7.29 had 48 entries and lost 10 %% of the right eye's answers)", (int)frame, (int)kPmSize, (int)g_pmSt.probeMax, (int)g_pmSt.replacedSame, (int)g_pmSt.evictedLive);
}
static void viewdraw_report(LONG frame) {
  static int s_rep;
  ++s_rep;
  if (s_rep > 5 && (s_rep % 12) != 0) return;
  static const char* kCls[3] = {"main picture", "mirror view", "shadow pass"};
  int any = 0;
  for (int c = 0; c < 3; ++c) for (int t = 0; t < 8; ++t) for (int ps = 0; ps < 16; ++ps) {
    const LONG l = g_vd.n[0][c][t][ps], r = g_vd.n[1][c][t][ps];
    if (!l && !r) continue;
    ++any;
    log_line("VIEWDRAW frame=%d the player's own parts, %s, view kind %d, pass %d: left eye asked %d, right eye asked %d%s", (int)frame, kCls[c], t, ps, (int)l, (int)r,
             l > r + r / 8 + 50 ? "  <-- the left eye draws more here" : (r > l + l / 8 + 50 ? "  <-- the right eye draws more here" : ""));
  }
  log_line("VIEWDRAW frame=%d other actors asked: left %d, right %d (cells shown: %d)", (int)frame, (int)g_vd.others[0], (int)g_vd.others[1], any);
}

static GBVR_NOINLINE uint8_t hk_mirror_only_core(void* gb, void* ret, int* siteOut);
static GBVR_NOINLINE uint8_t hk_mirror_only_impl(void* gb, void* ret) {
  int site = -1;
  uint8_t v = hk_mirror_only_core(gb, ret, &site);
  if (site >= 0) v = (uint8_t)pair_same_answer(0, ((uintptr_t)gb << 3) ^ (uintptr_t)(site + 1), (int)v, site);
  if (site == kSiteWand && g_selfActor && pke_item_held()) {   // 1.7.27 "the PKE sometimes disappears altogether": when does the game / the probe take the PKE (wand slot) out of the picture, and what are the goggle fields then
    static int s_last = -1; static long s_n, s_hid; static int s_logged;
    ++s_n; if (v) ++s_hid;
    if ((int)v != s_last) {
      s_last = (int)v;
      const uintptr_t pl = (uintptr_t)g_selfActor;
      int btn = -1; float blend = -1.0f; unsigned fl = 0;
      if (memory_readable((const void*)pl, layout::kOffPlayerGogByte + 4) && memory_readable((const void*)(pl + 0x247C4), 4)) { btn = *(const uint8_t*)(pl + layout::kOffPlayerGogByte); blend = *(const float*)(pl + 0x247C4); fl = *(const uint32_t*)(pl + layout::kOffPlayerFlags); }
      if (s_logged < 40) { ++s_logged; log_line("PKEVANISH the PKE (wand slot) is now %s in the picture (mirror-only answer %d, eye %d) | goggle button byte %d, goggle blend %.2f, player flags %08x | asked %ld times with the PKE in hand, hidden %ld (frame %d)", v ? "HIDDEN" : "shown", (int)v, (int)(g_be.eye & 1), btn, (double)blend, fl, s_n, s_hid, (int)g_ctl.worldFrames); }
    }
  }
  return v;
}
static GBVR_NOINLINE uint8_t hk_mirror_only_core(void* gb, void* ret, int* siteOut) {
  if (g_inMainRender && gb && gb != g_selfActor && engine_scene_arms(0)) {   // 1.7.199 SCENEOTHER: is the flashlight / walkie-talkie another object asking this question (not the player)?
    static volatile LONG s_o; if (s_o < 12) { const LONG n = InterlockedIncrement(&s_o); if (n <= 12) log_line("SCENEOTHER #%ld t=%.2fs an object that is not the player asks the mirror-only question in the roof fight: object %p, game RVA 0x%x", (long)n, qpc_ms() / 1000.0, gb, (unsigned)((uintptr_t)ret - g_game.base)); }
  }
  if (g_inMainRender && gb && gb == g_selfActor && g_lastEyeApplied && g_ctl.firstPerson) {
    uintptr_t r = (uintptr_t)ret - g_game.base;
    int idx = r == layout::kRvaMirrorOnlyRetBody ? kSiteBody : r == layout::kRvaMirrorOnlyRetPack ? kSitePack
            : r == layout::kRvaMirrorOnlyRetHose ? kSiteHose : r == layout::kRvaMirrorOnlyRetBody2 ? kSiteBody2
            : r == layout::kRvaMirrorOnlyRetWand ? kSiteWand : r == layout::kRvaMirrorOnlyRetBody2b ? kSiteBody2b : -1;
    if (siteOut) *siteOut = idx;   // 1.7.27
    {   // 1.7.197 SCENEGEAR: what the game asks about in the roof fight / while dying and what is hidden (the flashlight and the walkie-talkie still showed in 1.7.196: this says which draw they come through)
      const int sc = engine_scene_arms((uintptr_t)gb) ? 1 : 0, dn = (!sc && engine_player_downed()) ? 1 : 0;
      static volatile LONG s_ask[2][kSiteCount + 1], s_hid[2][kSiteCount + 1]; static volatile LONG64 s_q; static volatile LONG s_logs;
      if (sc || dn) {
        const int k = idx >= 0 ? idx : kSiteCount;
        InterlockedIncrement(&s_ask[sc ? 0 : 1][k]);
        const int hide = (idx == kSitePack || idx == kSiteHose || idx == kSiteBody2 || idx == kSiteBody2b) ? 1 : 0;
        if (hide) InterlockedIncrement(&s_hid[sc ? 0 : 1][k]);
        const int64_t nq = qpc_now(); const int64_t q0 = s_q;
        if (!q0) s_q = nq;
        else if ((double)(nq - q0) / (double)qpc_freq() >= 10.0 && s_logs < 20 && InterlockedCompareExchange64(&s_q, nq, q0) == q0) {
          InterlockedIncrement(&s_logs);
          log_line("SCENEGEAR 10 s (roof fight / dying) asked | roof: body %ld pack %ld hose %ld body2 %ld wand %ld body2b %ld other %ld | dying: body %ld pack %ld hose %ld body2 %ld wand %ld body2b %ld other %ld | hidden roof: pack %ld hose %ld body2 %ld body2b %ld | item in hand: PKE %d",
                   (long)s_ask[0][0], (long)s_ask[0][1], (long)s_ask[0][2], (long)s_ask[0][3], (long)s_ask[0][4], (long)s_ask[0][5], (long)s_ask[0][6],
                   (long)s_ask[1][0], (long)s_ask[1][1], (long)s_ask[1][2], (long)s_ask[1][3], (long)s_ask[1][4], (long)s_ask[1][5], (long)s_ask[1][6],
                   (long)s_hid[0][1], (long)s_hid[0][2], (long)s_hid[0][3], (long)s_hid[0][5], pke_item_held() ? 1 : 0);
        }
      }
    }
    if ((engine_scene_arms((uintptr_t)gb) || engine_player_downed()) && (idx == kSitePack || idx == kSiteHose || idx == kSiteBody2 || idx == kSiteBody2b)) return 1;   // 1.7.202: the roof fight shows arms, gun and the gun's hose only (the hose is still hidden while dying)   // 1.7.192: also the extra body pass (the flashlight and the walkie-talkie showed in the roof fight); 1.7.197: and while dying (no dead body)   // 1.7.192: also the extra body pass (the flashlight and the walkie-talkie showed in the roof fight)
    // 0.73: with the game's own models shown only the hose is hidden (idx == kSiteHose), and only while the probe's cord is drawn
    if (idx == kSiteBody || idx == kSitePack || idx == kSiteBody2 || idx == kSiteBody2b) InterlockedIncrement(&g_be.asked[g_be.eye & 1]);   // 0.98: the game asked about the player's own part in this eye
    if (g_pkeShowNow && idx >= 0 && (idx != kSiteHose || !cord_hides_hose()) && idx != kSiteWand && !gb_hide_body()) {   // 1.7.150: the hose too (it is the game's own hose now; with the PKE out the game's view hid it)   // 0.98: the PKE view's "mirror only" is not wanted for the avatar
      InterlockedIncrement(&g_bodySt.pkeShowAsked);
      const uint8_t gv = o_mirrorOnly(gb);
      if (gv) { InterlockedIncrement(&g_bodySt.pkeShown[idx]); InterlockedIncrement(&g_be.pkeShown[g_be.eye & 1]); return 0; }
      return gv;
    }
    const int hoseOnly = !gb_hide_body() && idx == kSiteHose && cord_hides_hose();
    if (idx >= 0 && ((gb_hide_body() && (idx != kSiteWand || g_ctl.hideWand)) || hoseOnly)) {
      InterlockedIncrement(&g_bodySt.hidden[idx]);
      // 2 = also no shadow (only when both readers are hooked; for the game 2 is the same as 1)
      return (g_ctl.hideShadow && g_shadowHooks == 1) ? 2 : 1;
    }
    if (idx < 0 && InterlockedIncrement(&g_bodySt.otherSites) <= 3)
      log_line("BODY note: the player's 'mirrors only' check was also asked from rva %llx (not one of the known parts; "
               "left to the game)", (unsigned long long)r);
  }
  uint8_t v = o_mirrorOnly(gb);
  if (v) InterlockedIncrement(&g_bodySt.gameTrue);
  return v;
}
static uint8_t __fastcall hk_mirror_only(void* gb) { return hk_mirror_only_impl(gb, GBVR_RETURN_ADDRESS()); }

// Draw context of a draw callback: is the view a mirror view?
static inline int draw_ctx_mirror(const uint8_t* drawCtx) {
  const uint8_t* view = *(const uint8_t* const*)(drawCtx + layout::kDrawCtxView);
  return view && *(const uint64_t*)(view + layout::kViewMirror) != 0;
}

// 0.30: the draw-time rule for body, pack, hose and wand. Only the probe's own
// mark (2) is handled; 0 and 1 (every other frame, and the game's own PKE view)
// go to the game's function unchanged. Runs on the render job threads.
static uint8_t __fastcall hk_draw_predicate(void* actor, uint8_t flag, void* drawCtx) {
  int vdType = 0;
  if (drawCtx) {   // 1.7.30 VIEWDRAW: count what kind of view asks, per eye
    const int ey = (int)(g_be.eye & 1);
    if (actor && actor == g_be.actor) {
      const uint8_t* dcv = (const uint8_t*)drawCtx;
      const uint8_t* vw = *(const uint8_t* const*)(dcv + layout::kDrawCtxView);
      int pass = *(const int*)(dcv + layout::kDrawCtxPass);
      int ty = vw ? *(const int*)(vw + layout::kViewType) : 0;
      const int mir = vw && *(const uint64_t*)(vw + layout::kViewMirror) != 0;
      if (ty < 0 || ty > 7) ty = 7;
      if (pass < 0 || pass > 15) pass = 15;
      vdType = ty;
      InterlockedIncrement(&g_vd.n[ey][mir ? 1 : (pass == (int)layout::kPassShadow ? 2 : 0)][ty][pass]);
    } else InterlockedIncrement(&g_vd.others[ey]);
  }
  const int selfPart = actor && actor == g_be.actor && drawCtx && !draw_ctx_mirror((const uint8_t*)drawCtx) &&
                       *(const int*)((const uint8_t*)drawCtx + layout::kDrawCtxPass) != (int)layout::kPassShadow;   // 0.98: the player's own part in the MAIN picture
  if (flag == 2 && drawCtx) {
    const uint8_t* dc = (const uint8_t*)drawCtx;
    if (draw_ctx_mirror(dc)) { InterlockedIncrement(&g_bodySt.mirrorKept); return 1; }
    if (selfPart) InterlockedIncrement(&g_be.markHidden[g_be.eye & 1]);
    if (*(const int*)(dc + layout::kDrawCtxPass) == (int)layout::kPassShadow) InterlockedIncrement(&g_bodySt.shadowSkipped);
    else InterlockedIncrement(&g_bodySt.mainSkipped);
    return 0;
  }
  uint8_t gv = o_drawPredicate(actor, flag, drawCtx);
  if (selfPart && drawCtx) {   // 1.7.27: the right eye draws what the left eye drew
    const uint8_t* dc2 = (const uint8_t*)drawCtx;
    const uintptr_t item = (uintptr_t)*(const uint8_t* const*)(dc2 + layout::kDrawCtxItem);
    gv = (uint8_t)pair_same_answer(1, (item << 3) ^ (uintptr_t)(*(const int*)(dc2 + layout::kDrawCtxPass) + 1) ^ 0x5 ^ ((uintptr_t)(vdType + 1) << 58), (int)gv, (int)flag);
  }
  if (selfPart) InterlockedIncrement(gv ? &g_be.drawn[g_be.eye & 1] : &g_be.refused[g_be.eye & 1]);
  if (drawCtx) {   // 0.76: count the game's own answer (does it refuse to draw a part of the player in the main picture?)
    const int shadow = *(const int*)((const uint8_t*)drawCtx + layout::kDrawCtxPass) == (int)layout::kPassShadow;
    if (shadow) InterlockedIncrement(gv ? &g_bodySt.predShadowDrawn : &g_bodySt.predShadowRefused);
    else InterlockedIncrement(gv ? &g_bodySt.predMainDrawn : &g_bodySt.predMainRefused);
  }
  return gv;
}

// 0.30: the extra body pass writes the same rule inline in its draw callback;
// with the mark it is skipped exactly the way the callback skips by itself
// (return before drawing), except in mirror views.
static void __fastcall hk_body2_callback(void* drawCtx) {
  if (drawCtx) {
    const uint8_t* dc = (const uint8_t*)drawCtx;
    const uint8_t* item = *(const uint8_t* const*)(dc + layout::kDrawCtxItem);
    const uint8_t* block = item ? *(const uint8_t* const*)(item + layout::kItemDrawBlock) : nullptr;
    if (block && block[layout::kBody2BlockFlag] == 2 && !draw_ctx_mirror(dc)) {
      if (*(const int*)(dc + layout::kDrawCtxPass) == (int)layout::kPassShadow) InterlockedIncrement(&g_bodySt.body2ShadowSkipped);
      else InterlockedIncrement(&g_bodySt.body2Skipped);
      return;
    }
  }
  o_body2Callback(drawCtx);
}

static int bytes_match(uint32_t r, const uint8_t* b, int n) {
  const uint8_t* p = (const uint8_t*)rva(r);
  for (int i = 0; i < n; ++i) if (p[i] != b[i]) return 0;
  return 1;
}

// 0.30: the two readers of the stored answer that decide shadow drawing. Both
// or neither: with only one, part of the shadow would stay.
static void install_shadow_hooks() {
  // the four callbacks really call the rule (e8 rel32 -> 0xEEC70) with the byte in edx
  int calls = 1;
  for (uint32_t c : layout::kRvaDrawPredicateCalls) {
    const uint8_t* p = (const uint8_t*)rva(c);
    if (p[0] != 0xe8 || (uintptr_t)(p + 5 + *(const int32_t*)(p + 1)) != rva(layout::kRvaDrawPredicate)) calls = 0;
  }
  int pred = bytes_match(layout::kRvaDrawPredicate, layout::kBytesDrawPredicate, 16);
  int cb = bytes_match(layout::kRvaBody2DrawCallback, layout::kBytesBody2DrawCallback, 16);
  if (!calls || !pred || !cb) {
    g_shadowHooks = -1;
    log_line("BODY shadow hiding not available (callers=%d rule=%d extraCallback=%d): the hidden body keeps its shadow",
             calls, pred, cb);
    return;
  }
  void* t1 = (void*)rva(layout::kRvaDrawPredicate);
  void* t2 = (void*)rva(layout::kRvaBody2DrawCallback);
  MH_STATUS s1 = MH_CreateHook(t1, (void*)hk_draw_predicate, (void**)&o_drawPredicate);
  MH_STATUS s2 = s1 == MH_OK ? MH_CreateHook(t2, (void*)hk_body2_callback, (void**)&o_body2Callback) : s1;
  if (s1 == MH_OK && s2 == MH_OK) {
    s1 = MH_EnableHook(t1);
    s2 = s1 == MH_OK ? MH_EnableHook(t2) : s1;
  }
  if (s1 == MH_OK && s2 == MH_OK) {
    g_shadowHooks = 1;
  } else {
    MH_DisableHook(t1); MH_DisableHook(t2);
    g_shadowHooks = -2;
  }
  log_line("HOOK draw-rule status=%d target=%p; HOOK extra-body-callback status=%d target=%p (own shadow: %s)", (int)s1, t1,
           (int)s2, t2, g_shadowHooks == 1 ? "can be hidden" : "stays");
}

// ---- 1.7.30 mirrors that follow the headset (layout.h "1.7.30 mirrors") ------------------------------------------------------------------------------------------
// "The mirrors in the hotel don't reflect correctly" (1.7.29 report). The mirror-view builder (0x427210) reads the CAMERA OBJECT's own eye (cam+0x08) and Euler angles (cam+0x14, turned into a basis by 0x3DD40),
// but the probe only replaces the eye and basis that Prepare hands on to the engine, so the mirrors were built from the flat-screen camera while the picture is drawn from the headset. Now, during the one call of
// the builder that belongs to a headset-modified prepare of the same camera on the same thread: the camera's eye is swapped for the headset eye (restored right after) and the result of the Euler->basis call
// inside the builder is replaced by the headset basis. Nothing else sees the swap (single render thread, restored before the builder returns). Option "Mirrors follow your head" (mirror_vr).
typedef int(__fastcall* PFN_BuildMirrors)(void* list, void* ctx);
typedef void*(__fastcall* PFN_EulerToBasis)(float* out, const float* euler);
static PFN_BuildMirrors o_buildMirrors;
static PFN_EulerToBasis o_eulerToBasis;
static int g_mirrorHooks;                 // 1 installed, 0 not yet, <0 why not
static volatile LONG g_mirrorTid;         // the thread that is inside a swapped builder call
static float g_mirrorBasis[9];
static struct {
  volatile LONG calls, swapped, basisReplaced, unpaired, notReadable, off, viewsBuilt[2], viewsBuiltAll, swappedEye[2], unpairedEye[2], zeroViews;
  volatile LONG lastEyeDx1000, lastEyeDz1000, lastTurnDegX10, maxEyeMoveX1000, maxTurnDegX10;   // how far the headset eye / view differ from the camera's own (feet, degrees)
  volatile LONG logged;
} g_mir;

static int __fastcall hk_build_mirrors(void* list, void* ctx) {
  InterlockedIncrement(&g_mir.calls);
  const int eyeIx = (int)(g_be.eye & 1);
  void* cam = (ctx && memory_readable(ctx, 8)) ? *(void* volatile*)ctx : nullptr;
  const DWORD tid = GetCurrentThreadId();
  if (!g_ctl.mirrorVr) { InterlockedIncrement(&g_mir.off); return o_buildMirrors(list, ctx); }
  if (!(cam && g_lastTid == tid && g_lastCamera == cam && g_lastModified && g_lastEyeApplied)) {
    InterlockedIncrement(&g_mir.unpaired); InterlockedIncrement(&g_mir.unpairedEye[eyeIx]);
    return o_buildMirrors(list, ctx);
  }
  float* camEye = (float*)((uint8_t*)cam + layout::kCamEyeOffset);
  if (!memory_readable(camEye, 12) || !memory_readable((uint8_t*)cam + 0x14, 12)) { InterlockedIncrement(&g_mir.notReadable); return o_buildMirrors(list, ctx); }
  const float save[3] = {camEye[0], camEye[1], camEye[2]};
  // how different are the two? (diagnostics: eye shift in 1/1000 ft, and the angle between the camera's own forward and the headset's)
  {
    const double dx = (double)g_lastEye[0] - (double)save[0], dy = (double)g_lastEye[1] - (double)save[1], dz = (double)g_lastEye[2] - (double)save[2];
    const LONG mv = (LONG)(vm::dsqrt(dx * dx + dy * dy + dz * dz) * 1000.0);
    InterlockedExchange(&g_mir.lastEyeDx1000, (LONG)(dx * 1000.0)); InterlockedExchange(&g_mir.lastEyeDz1000, (LONG)(dz * 1000.0));
    if (mv > g_mir.maxEyeMoveX1000) InterlockedExchange(&g_mir.maxEyeMoveX1000, mv);
  }
  for (int i = 0; i < 9; ++i) g_mirrorBasis[i] = g_lastOut[i];
  camEye[0] = g_lastEye[0]; camEye[1] = g_lastEye[1]; camEye[2] = g_lastEye[2];
  InterlockedExchange(&g_mirrorTid, (LONG)tid);
  InterlockedIncrement(&g_mir.swapped); InterlockedIncrement(&g_mir.swappedEye[eyeIx]);
  const int views = o_buildMirrors(list, ctx);
  InterlockedExchange(&g_mirrorTid, 0);
  camEye[0] = save[0]; camEye[1] = save[1]; camEye[2] = save[2];
  InterlockedIncrement(&g_mir.viewsBuiltAll);
  if (views > 0) InterlockedExchangeAdd(&g_mir.viewsBuilt[eyeIx], views); else InterlockedIncrement(&g_mir.zeroViews);
  return views;
}

static GBVR_NOINLINE void* hk_euler_to_basis_impl(float* out, const float* euler, void* ret) {
  void* r = o_eulerToBasis(out, euler);
  if (g_mirrorTid && (uintptr_t)ret == rva(layout::kRvaBuildMirrorsEulerRet) && g_mirrorTid == (LONG)GetCurrentThreadId() && out) {
    // the camera's own forward before the swap, for the log
    const double a = (double)out[2] * (double)g_mirrorBasis[2] + (double)out[5] * (double)g_mirrorBasis[5] + (double)out[8] * (double)g_mirrorBasis[8];
    const double c = a > 1.0 ? 1.0 : (a < -1.0 ? -1.0 : a);
    const double ang = vm::datan2(vm::dsqrt(1.0 - c * c), c) * 57.29578;
    const LONG t10 = (LONG)(ang * 10.0);
    if (t10 > g_mir.maxTurnDegX10) InterlockedExchange(&g_mir.maxTurnDegX10, t10);
    InterlockedExchange(&g_mir.lastTurnDegX10, t10);
    for (int i = 0; i < 9; ++i) out[i] = g_mirrorBasis[i];
    InterlockedIncrement(&g_mir.basisReplaced);
  }
  return r;
}
static void* __fastcall hk_euler_to_basis(float* out, const float* euler) { return hk_euler_to_basis_impl(out, euler, GBVR_RETURN_ADDRESS()); }

static void install_mirror_hooks() {
  const uint8_t* callSite = (const uint8_t*)rva(layout::kRvaBuildMirrorsRet - 5);
  int caller = callSite[0] == 0xe8 && (uintptr_t)(callSite + 5 + *(const int32_t*)(callSite + 1)) == rva(layout::kRvaBuildMirrors);
  const uint8_t* eulerSite = (const uint8_t*)rva(layout::kRvaBuildMirrorsEulerRet - 5);
  int eulerCall = eulerSite[0] == 0xe8 && (uintptr_t)(eulerSite + 5 + *(const int32_t*)(eulerSite + 1)) == rva(layout::kRvaEulerToBasis);
  int fnA = bytes_match(layout::kRvaBuildMirrors, layout::kBytesBuildMirrors, 16);
  int fnB = bytes_match(layout::kRvaEulerToBasis, layout::kBytesEulerToBasis, 16);
  if (!caller || !eulerCall || !fnA || !fnB) {
    g_mirrorHooks = -1;
    log_line("MIRROR hooks not available (caller=%d eulerCall=%d builder=%d euler=%d): the mirrors stay the game's own", caller, eulerCall, fnA, fnB);
    return;
  }
  void* t1 = (void*)rva(layout::kRvaBuildMirrors);
  void* t2 = (void*)rva(layout::kRvaEulerToBasis);
  MH_STATUS s1 = MH_CreateHook(t1, (void*)hk_build_mirrors, (void**)&o_buildMirrors);
  MH_STATUS s2 = s1 == MH_OK ? MH_CreateHook(t2, (void*)hk_euler_to_basis, (void**)&o_eulerToBasis) : s1;
  if (s1 == MH_OK && s2 == MH_OK) { s1 = MH_EnableHook(t1); s2 = s1 == MH_OK ? MH_EnableHook(t2) : s1; }
  if (s1 == MH_OK && s2 == MH_OK) g_mirrorHooks = 1;
  else { MH_DisableHook(t1); MH_DisableHook(t2); g_mirrorHooks = -2; }
  log_line("HOOK mirror-builder status=%d target=%p; HOOK euler-to-basis status=%d target=%p (mirrors follow the headset: %s, setting %d)", (int)s1, t1, (int)s2, t2, g_mirrorHooks == 1 ? "available" : "NOT available", (int)g_ctl.mirrorVr);
}

static void mirror_report(LONG frame) {
  if (g_mirrorHooks == 0) return;
  log_line("MIRROR frame=%d setting=%d hooks=%d | builder calls=%d swapped=%d (left/right %d/%d) basisReplaced=%d notFromHeadsetFrame=%d (left/right %d/%d) setting-off=%d unreadable=%d | mirror views built left/right=%d/%d, calls with none=%d | the headset eye differed from the camera's own by up to %d.%03d ft (now dx %d dz %d thousandths of a foot), the view direction by up to %d.%d deg (now %d.%d)",
           (int)frame, (int)g_ctl.mirrorVr, g_mirrorHooks, (int)g_mir.calls, (int)g_mir.swapped, (int)g_mir.swappedEye[0], (int)g_mir.swappedEye[1], (int)g_mir.basisReplaced, (int)g_mir.unpaired, (int)g_mir.unpairedEye[0], (int)g_mir.unpairedEye[1],
           (int)g_mir.off, (int)g_mir.notReadable, (int)g_mir.viewsBuilt[0], (int)g_mir.viewsBuilt[1], (int)g_mir.zeroViews,
           (int)(g_mir.maxEyeMoveX1000 / 1000), (int)(g_mir.maxEyeMoveX1000 % 1000), (int)g_mir.lastEyeDx1000, (int)g_mir.lastEyeDz1000,
           (int)(g_mir.maxTurnDegX10 / 10), (int)(g_mir.maxTurnDegX10 % 10), (int)(g_mir.lastTurnDegX10 / 10), (int)(g_mir.lastTurnDegX10 % 10));
}

// Installed separately: if anything does not match, only this feature is off.
static void install_body_hooks() {
  static const uint8_t kVcall[6] = {0xff, 0x90, 0xc0, 0x08, 0x00, 0x00};  // call [rax+0x8c0]
  static const uint8_t kVcallRdx[6] = {0xff, 0x92, 0xc0, 0x08, 0x00, 0x00};  // call [rdx+0x8c0]
  int sites = bytes_match(layout::kRvaMirrorOnlyRetBody - 6, kVcall, 6) && bytes_match(layout::kRvaMirrorOnlyRetPack - 6, kVcall, 6) &&
              bytes_match(layout::kRvaMirrorOnlyRetHose - 6, kVcall, 6) && bytes_match(layout::kRvaMirrorOnlyRetWand - 6, kVcall, 6) &&
              bytes_match(layout::kRvaMirrorOnlyRetBody2 - 6, kVcallRdx, 6) &&
              bytes_match(layout::kRvaMirrorOnlyRetBody2b - 6, kVcallRdx, 6);
  int slot = *(const uintptr_t*)rva(layout::kRvaMirrorOnlySlot) == rva(layout::kRvaMirrorOnly);
  int fn = bytes_match(layout::kRvaMirrorOnly, layout::kBytesMirrorOnly, 16);
  int cr = bytes_match(layout::kRvaCameraRender, layout::kBytesCameraRender, 16);
  if (!sites || !slot || !fn || !cr) {
    g_bodyHooks = -1;
    log_line("BODY hiding not available (callSites=%d vtableSlot=%d check=%d cameraRender=%d): the own body stays visible",
             sites, slot, fn, cr);
    return;
  }
  // The shadow readers first: until the check itself is hooked nothing carries the mark.
  install_shadow_hooks();
  void* t1 = (void*)rva(layout::kRvaCameraRender);
  void* t2 = (void*)rva(layout::kRvaMirrorOnly);
  MH_STATUS s1 = MH_CreateHook(t1, (void*)hk_camera_render, (void**)&o_cameraRender);
  MH_STATUS s2 = s1 == MH_OK ? MH_CreateHook(t2, (void*)hk_mirror_only, (void**)&o_mirrorOnly) : s1;
  if (s1 == MH_OK && s2 == MH_OK) {
    s1 = MH_EnableHook(t1);
    s2 = MH_EnableHook(t2);
  }
  if (s1 == MH_OK && s2 == MH_OK) {
    g_bodyHooks = 1;
  } else {
    MH_DisableHook(t1); MH_DisableHook(t2);
    g_bodyHooks = -2;
  }
  log_line("HOOK camera-render status=%d target=%p; HOOK mirrors-only status=%d target=%p (own body: %s)", (int)s1, t1,
           (int)s2, t2, g_bodyHooks == 1 ? "can be hidden" : "NOT available");
}

static void body_report(LONG frame) {
  log_line("BODYPKE frame=%d setting=%d pkeOutFrames=%d questionsInThoseFrames=%d shownDespitePkeView body=%d pack=%d body2=%d body2b=%d (0 = the game's PKE view was not hiding anything the probe could un-hide)",
           (int)frame, (int)g_ctl.pkeShowBody, (int)g_bodySt.pkeShowFrames, (int)g_bodySt.pkeShowAsked, (int)g_bodySt.pkeShown[kSiteBody], (int)g_bodySt.pkeShown[kSitePack],
           (int)g_bodySt.pkeShown[kSiteBody2], (int)g_bodySt.pkeShown[kSiteBody2b]);
  log_line("BODYEYE frame=%d the player's own parts per eye (left/right): asked(prepare)=%d/%d drawn(game said yes)=%d/%d refused(game said no)=%d/%d hiddenByProbeMark=%d/%d shownDespitePkeView=%d/%d",
           (int)frame, (int)g_be.asked[0], (int)g_be.asked[1], (int)g_be.drawn[0], (int)g_be.drawn[1], (int)g_be.refused[0], (int)g_be.refused[1],
           (int)g_be.markHidden[0], (int)g_be.markHidden[1], (int)g_be.pkeShown[0], (int)g_be.pkeShown[1]);
  log_line("BODYDRAW the game's own answer for the player's parts (flag 0/1): main picture drawn=%d refused=%d, shadow drawn=%d refused=%d (refused = the game itself skips the part)",
           (int)g_bodySt.predMainDrawn, (int)g_bodySt.predMainRefused, (int)g_bodySt.predShadowDrawn, (int)g_bodySt.predShadowRefused);
  log_line("BODY frame=%d realModels=%d hidden=%d wand=%s shadow=%s hooks=%d shadowHooks=%d mainRenders=%d hiddenFrames=%d hiddenItems "
           "body=%d pack=%d hose=%d body2=%d body2b=%d wand=%d otherCallSites=%d notPlayerClass=%d noFollowTarget=%d "
           "gameSaidMirrorOnly=%d drawSkipped main=%d shadow=%d mirrorKept=%d extraBodySkipped main=%d shadow=%d",
           (int)frame, (int)g_ctl.realModels, gb_hide_body(), g_ctl.realModels ? "game wand shown" : g_ctl.hideWand ? "hidden" : "shown",
           g_ctl.hideShadow && g_shadowHooks == 1 ? "hidden" : g_ctl.hideShadow ? "kept (not available)" : "kept",
           g_bodyHooks, g_shadowHooks, (int)g_bodySt.renders, (int)g_bodySt.renderFp, (int)g_bodySt.hidden[kSiteBody],
           (int)g_bodySt.hidden[kSitePack], (int)g_bodySt.hidden[kSiteHose], (int)g_bodySt.hidden[kSiteBody2],
           (int)g_bodySt.hidden[kSiteBody2b], (int)g_bodySt.hidden[kSiteWand], (int)g_bodySt.otherSites,
           (int)g_bodySt.wrongClass, (int)g_bodyMv.noActor, (int)g_bodySt.gameTrue, (int)g_bodySt.mainSkipped,
           (int)g_bodySt.shadowSkipped, (int)g_bodySt.mirrorKept, (int)g_bodySt.body2Skipped,
           (int)g_bodySt.body2ShadowSkipped);
}

// ---- Head aim (0.32, layout.h "Aim direction") -------------------------------------
// The game keeps the direction the player shoots in as a unit vector in the
// actor (iAimDir). Its own player-aim code works it out every frame from the
// mouse-driven angles and stores it through one small function. In the
// headset the picture follows the head, so the aiming circle and the stream
// must follow the head too. While the headset view is on, the vector the game
// hands to that function for the PLAYER actor is replaced by the forward
// direction of the very view that was just drawn (level game yaw x head
// rotation: the mouse still turns the body, the head adds to it). Everything
// else stays the game's: its own calculation still runs, lock-on targets
// still take over, hits and damage are decided by the game from this vector,
// and when the feature is off, stale or the view is not the player's the
// game's vector goes through untouched (it overwrites ours on the next frame).
// Which actor is "the player": the follow target of the camera that produced
// the headset view, accepted only if it is a CGhostbuster (same class check as
// the body hiding). Nothing is written into the game except through the
// game's own setter.
typedef void(__fastcall* PFN_AimSet)(float* field, const float* v);
static PFN_AimSet o_aimSet;
static int g_aimHook;   // 1 installed, 0 not yet, <0 why not
static struct {
  volatile LONG seq;         // odd while being written
  volatile uintptr_t actor;  // the player actor the last headset view followed
  volatile float dir[3];     // forward vector of that view (game world axes)
  volatile float adir[3];    // 0.68: the same turned a little toward the ghost the beam nearly hits (aim assist); equals dir when off
  volatile int64_t qpc;
  volatile float tip[3];     // 0.34: wand tip in game world (feet); valid when hasTip
  volatile LONG hasTip;
  volatile float grip[3];    // 0.51: the controller's grip point in game world (feet); valid when hasGrip
  volatile LONG hasGrip;
  volatile float wup[3];     // 0.58: the wand's up direction in game world (unit); valid when hasWup (the gun rolls with the wrist)
  volatile LONG hasWup;
  volatile float lpos[3], lfwd[3], lup[3];   // 0.57: the left controller in game world (feet / unit vectors); valid when hasLeft
  volatile LONG hasLeft;
  volatile float fpm;        // 0.57: feet per metre of that view
  volatile float eye[3], gaze[3]; // headset reticle ray, distinct from the offset hand ray
  volatile float view9[9];   // 1.7.167: the head's turn in game world (engine axes) for that view
} g_headAim;
static struct { volatile int64_t q; float pos[3]; } g_tl;   // 1.7.37: a trap throw by hand is pending: where the hand was (game feet)
void engine_trap_launch_request() {
  if (!g_headAim.hasLeft || !aim::is_fresh(qpc_now(), g_headAim.qpc, qpc_freq(), 250)) return;
  for (int i = 0; i < 3; ++i) g_tl.pos[i] = g_headAim.lpos[i];
  g_tl.q = qpc_now();
}
int engine_trap_idle() { const int st = fight_trap_state(g_headAim.actor); return st == 1 || st < 0; }   // 1.7.177: 1 = the trap is on the belt (or the state is unknown)
int engine_trap_deploy_now() {
  if (!g_ctl.trapNoAnim) return 0;
  if (g_headAim.hasLeft && aim::is_fresh(qpc_now(), g_headAim.qpc, qpc_freq(), 1000)) {   // 1.7.176: 1 s (was 0.25 s): the hip throw is a moment when the aim can be stale
    const float lp[3] = {g_headAim.lpos[0], g_headAim.lpos[1], g_headAim.lpos[2]};
    return fight_trap_deploy_request(g_headAim.actor, lp);
  }
  return fight_trap_deploy_request(g_headAim.actor, nullptr);
}
void engine_trap_button_launch() {
  // 1.7.174 double check of 1.7.173: the trap button also calls a trap that is already out back / opens it. Moving THAT trap to the hand and letting it fly on
  // would carry a deployed trap away. Only a trap that is idle (not out) is started from the hand.
  static LONG s_ok, s_skip;
  const int st = fight_trap_state(g_headAim.actor);
  if (st != 1) { if (InterlockedIncrement(&s_skip) <= 8) log_line("TRAP button with the trap state %d (not idle): left to the game, nothing is moved to the hand", st); return; }
  engine_trap_launch_request();
  if (InterlockedIncrement(&s_ok) <= 8) log_line("TRAP button with the trap idle: it leaves from your off hand (trap_no_anim=1)");
}
static void trap_carry_step() {
  { const int64_t nowQ = qpc_now(); const int pending = g_ctl.trapFromHand && g_tl.q && nowQ - g_tl.q < qpc_freq() * 14 / 10;   // 1.7.166: 0.7 -> 1.4 s (the game throws about 0.5 s late, then 0.35 s of pull)
    float ad[3] = {g_headAim.dir[0], g_headAim.dir[1], g_headAim.dir[2]};
    fight_trap_launch(head_aim_actor(), pending ? g_tl.pos : nullptr, ad); if (!pending) g_tl.q = 0; }
  const int held = controllers_trap_held();
  const float* lp = nullptr; float lpb[3];
  float lf[3] = {0, 0, 1}, lu[3] = {0, 1, 0};
  if (held && g_headAim.hasLeft && aim::is_fresh(qpc_now(), g_headAim.qpc, qpc_freq(), 250)) { for (int i = 0; i < 3; ++i) { lpb[i] = g_headAim.lpos[i]; lf[i] = g_headAim.lfwd[i]; lu[i] = g_headAim.lup[i]; } lp = lpb; }
  fight_trap_carry(head_aim_actor(), held, lp, lp ? lf : nullptr, lp ? lu : nullptr);
}
static uintptr_t head_aim_actor() { return g_headAim.actor; }
static struct {
  volatile LONG published, noActor, calls, playerCalls, overridden, stale, firstLogged;
  volatile float lastGame[3], lastHead[3];
  volatile LONG lastDegX100, worstDegX100;
} g_aimSt;

static struct { volatile float v[3]; volatile int64_t qpc; } g_gameAim;   // 0.41: the game's own aim, last value it stored


// 0.48: what is in the game folder (archives, configs, saves) - to learn where models, levels and settings live.
static void log_gamedir_level(const wchar_t* dir, const char* prefix, int depth, int* budget) {
  wchar_t pat[MAX_PATH + 8];
  lstrcpynW(pat, dir, MAX_PATH);
  lstrcatW(pat, L"*");
  WIN32_FIND_DATAW fd;
  HANDLE h = FindFirstFileW(pat, &fd);
  if (h == INVALID_HANDLE_VALUE) return;
  do {
    if (fd.cFileName[0] == L'.' && (!fd.cFileName[1] || (fd.cFileName[1] == L'.' && !fd.cFileName[2]))) continue;
    if (*budget <= 0) break;
    char name[200];
    WideCharToMultiByte(CP_ACP, 0, fd.cFileName, -1, name, sizeof(name), nullptr, nullptr);
    name[sizeof(name) - 1] = 0;
    const int isDir = (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
    --*budget;
    if (isDir) log_line("GAMEDIR %s%s\\", prefix, name);
    else log_line("GAMEDIR %s%s %u bytes", prefix, name, (unsigned)fd.nFileSizeLow);
    if (isDir && depth < 1) {
      wchar_t sub[MAX_PATH + 8];
      lstrcpynW(sub, dir, MAX_PATH); lstrcatW(sub, fd.cFileName); lstrcatW(sub, L"\\");
      char pre[220]; wsprintfA(pre, "%s%s\\", prefix, name);
      int sb = 60;
      log_gamedir_level(sub, pre, depth + 1, &sb);
      *budget -= 0;
    }
  } while (FindNextFileW(h, &fd));
  FindClose(h);
}
static void log_gamedir() {
  int budget = 300;
  log_line("GAMEDIR listing of %ls (two levels, names and sizes)", g_selfDir);
  log_gamedir_level(g_selfDir, "", 0, &budget);
}
void actor_watch(uintptr_t actor);   // 0.48 data collection (defined with the binding code)

// ---- 0.68 aim assist -----------------------------------------------------------------------------------------------------------
// The game's health ring (draw 0x24D810, see hud.cpp) is placed on the ghost the game has targeted: this+0x1A8..0x1B0 is that ghost's world
// position (the draw subtracts the camera position and projects it); while nothing is targeted the field holds a constant (0x23CA1A8) and the
// ring sits at the screen centre. hud.cpp's ring hook hands every ring object to aim_ring_seen(); head_aim_publish() then turns the beam a
// little toward that position while it is inside a narrow cone and the trigger is down (assistmath.h).
static struct {
  volatile float pos[3]; volatile int64_t qpc; volatile uintptr_t self;
  volatile LONG calls, setCalls, unsetCalls, bad, moves, lastSetSeq;
  volatile float unset[3];
} g_ring;
static struct { long samples, stillSamples, jumps, targetChanges; int jumpLogged, stillLogged; double stillSecs, stillRun, longestStill, lastStillLog, maxSpeed, speedSum; } g_gw;
void aim_ring_seen(const void* ring) {
  InterlockedIncrement(&g_ring.calls);
  const uint8_t* b = (const uint8_t*)ring;
  const float* p = (const float*)(b + 0x1A8);
  if (!b || !memory_readable(p, 12)) return;
  const float* un = (const float*)rva(0x23CA1A8);
  if (memory_readable(un, 12)) for (int i = 0; i < 3; ++i) g_ring.unset[i] = un[i];
  if (!vm::is_finite_f(p[0]) || !vm::is_finite_f(p[1]) || !vm::is_finite_f(p[2])) { InterlockedIncrement(&g_ring.bad); return; }
  if (p[0] == g_ring.unset[0] && p[1] == g_ring.unset[1] && p[2] == g_ring.unset[2]) { InterlockedIncrement(&g_ring.unsetCalls); g_ring.qpc = 0; return; }
  if (p[0] > 3.0e5f || p[0] < -3.0e5f || p[1] > 3.0e5f || p[1] < -3.0e5f || p[2] > 3.0e5f || p[2] < -3.0e5f) { InterlockedIncrement(&g_ring.bad); return; }
  {   // 0.73 GHOSTWATCH data: how the targeted ghost moves (the ring sits on the ghost the game targeted). A ghost that stays put for seconds while it is
      // near and targeted is the "stuck in a wall / floor" case; its position is logged so I can see where.
    const int64_t nowq = qpc_now();
    if ((uintptr_t)ring == g_ring.self && g_ring.qpc && nowq > g_ring.qpc) {
      const double dt = (double)(nowq - g_ring.qpc) / (double)qpc_freq();
      if (dt > 0.02 && dt < 0.7) {
        const double dx = p[0] - g_ring.pos[0], dy = p[1] - g_ring.pos[1], dz = p[2] - g_ring.pos[2];
        const double d = vm::dsqrt(dx * dx + dy * dy + dz * dz);
        const double sp = d / dt;
        ++g_gw.samples;
        if (sp < 0.15) { g_gw.stillSecs += dt; g_gw.stillRun += dt; ++g_gw.stillSamples; if (g_gw.stillRun > g_gw.longestStill) g_gw.longestStill = g_gw.stillRun; }
        else g_gw.stillRun = 0;
        if (sp > g_gw.maxSpeed) g_gw.maxSpeed = sp;
        g_gw.speedSum += sp;
        if (d > 5.0) { ++g_gw.jumps; if (g_gw.jumpLogged < 12) { ++g_gw.jumpLogged; log_line("GHOSTWATCH jump: the targeted ghost moved %.1f ft in %.0f ms (%.1f,%.1f,%.1f -> %.1f,%.1f,%.1f)", d, dt * 1000.0, (double)g_ring.pos[0], (double)g_ring.pos[1], (double)g_ring.pos[2], (double)p[0], (double)p[1], (double)p[2]); } }
        if (g_gw.stillRun > 6.0 && g_gw.stillLogged < 12 && g_gw.stillRun - g_gw.lastStillLog > 6.0) {
          g_gw.lastStillLog = g_gw.stillRun;
          ++g_gw.stillLogged;
          log_line("GHOSTWATCH still: the targeted ghost has not moved for %.0f s at %.1f,%.1f,%.1f ft (ring object %p)", g_gw.stillRun, (double)p[0], (double)p[1], (double)p[2], ring);
        }
        if (g_gw.stillRun == 0) g_gw.lastStillLog = 0;
      }
    } else { g_gw.stillRun = 0; g_gw.lastStillLog = 0; ++g_gw.targetChanges; }
  }
  {   // 0.79 data: the whole ring object (and what its pointers lead to), so a later version can draw the game's own ring on every ghost with the right health
    static volatile LONG s_dumps;
    const LONG n = InterlockedIncrement(&g_ring.setCalls);
    if ((n == 3 || n == 400 || n == 4000) && s_dumps < 3 && memory_readable(b, 0x240)) {
      InterlockedIncrement(&s_dumps);
      for (int off = 0; off < 0x240; off += 0x20) {
        const uint64_t* q = (const uint64_t*)(b + off);
        log_line("RINGRAW #%ld +0x%03x: %016llx %016llx %016llx %016llx", (long)s_dumps, off, (unsigned long long)q[0], (unsigned long long)q[1], (unsigned long long)q[2], (unsigned long long)q[3]);
      }
      for (int off = 0; off < 0x240; off += 8) {   // pointers inside: the first 0x60 bytes of what they point to
        const uintptr_t v = *(const uintptr_t*)(b + off);
        if (v > 0x10000 && v < 0x00007FFFFFFF0000ull && !(v & 7) && memory_readable((const void*)v, 0x60) && s_dumps == 1) {
          const uint64_t* q = (const uint64_t*)v;
          log_line("RINGPTR +0x%03x -> %p: %016llx %016llx %016llx %016llx %016llx %016llx", off, (void*)v, (unsigned long long)q[0], (unsigned long long)q[1], (unsigned long long)q[2], (unsigned long long)q[3], (unsigned long long)q[4], (unsigned long long)q[5]);
        }
      }
    }
    InterlockedDecrement(&g_ring.setCalls);
  }
  for (int i = 0; i < 3; ++i) g_ring.pos[i] = p[i];
  g_ring.self = (uintptr_t)ring;
  g_ring.qpc = qpc_now();
  InterlockedIncrement(&g_ring.setCalls);
}
static assist::State g_assistSt, g_assistPkeSt;
static struct { volatile LONG blocked, passed, unknown; int logged; } g_ghostGate;   // 1.7 ghost-only aim assist counters
static struct { volatile LONG ticks, active, maxTurnX100; } g_pkeAssistN;   // 0.94
static struct {
  LONG ticks, fireTicks, candTicks, activeTicks, maxTurnX100, lockStarts, posLogged;
  int wasActive;
  double lastAng, lastDist, lastTurn, lastCone;
  float lastPos[3];
} g_assistLog;
static void assist_report(LONG frame) {
  log_line("PKEASSIST frame=%d cone=%ddeg strength=%d%% ticksWithPke=%ld pulling=%ld maxTurn=%.2fdeg", (int)frame, (int)g_ctl.pkeAssistDeg, (int)g_ctl.pkeAssistPct, g_pkeAssistN.ticks, g_pkeAssistN.active, g_pkeAssistN.maxTurnX100 / 100.0);
  { long ca = 0, cg = 0, cn = 0, cu = 0; const int cnow = fight_enemy_stats(&ca, &cg, &cn, &cu);
    log_line("AIMGHOST frame=%d ghost_only=%d | the pull toward the game's lock ring was skipped %ld times (nothing alive there: a table, a chair...), allowed %ld times, unknown %ld times | enemy list asks=%ld ghost=%ld notGhost=%ld unknown=%ld, enemies in the last scan=%d",
             (int)frame, (int)g_ctl.aimGhostOnly, (long)g_ghostGate.blocked, (long)g_ghostGate.passed, (long)g_ghostGate.unknown, ca, cg, cn, cu, cnow); }
  log_line("GHOSTWATCH frame=%d targetedGhostSamples=%ld meanSpeed=%.2fft/s fastest=%.1fft/s stillSamples=%ld stillSecs=%.0f longestStill=%.0fs jumps(>5ft)=%ld targetChanges=%ld",
           (int)frame, g_gw.samples, g_gw.samples ? g_gw.speedSum / (double)g_gw.samples : 0.0, g_gw.maxSpeed, g_gw.stillSamples, g_gw.stillSecs, g_gw.longestStill, g_gw.jumps, g_gw.targetChanges);
  log_line("AIMASSIST frame=%d on=%d strength=%d%% cone=%ddeg ticks=%d firing=%d withTarget=%d pulling=%d lockStarts=%d maxTurn=%.2fdeg lastTarget=%.1f,%.1f,%.1f dist=%.1fft angle=%.2fdeg cone=%.2f lastTurn=%.2fdeg | "
           "gameRing: draws=%d targetSet=%d targetUnset=%d bad=%d unsetConst=%g,%g,%g",
           (int)frame, (int)(g_ctl.aimAssistPct > 0 && g_ctl.headAim == 2), (int)g_ctl.aimAssistPct, (int)g_ctl.aimAssistDeg, (int)g_assistLog.ticks, (int)g_assistLog.fireTicks, (int)g_assistLog.candTicks,
           (int)g_assistLog.activeTicks, (int)g_assistLog.lockStarts, g_assistLog.maxTurnX100 / 100.0, (double)g_assistLog.lastPos[0], (double)g_assistLog.lastPos[1], (double)g_assistLog.lastPos[2],
           g_assistLog.lastDist, g_assistLog.lastAng, g_assistLog.lastCone, g_assistLog.lastTurn, (int)g_ring.calls, (int)g_ring.setCalls, (int)g_ring.unsetCalls, (int)g_ring.bad,
           (double)g_ring.unset[0], (double)g_ring.unset[1], (double)g_ring.unset[2]);
}
static int pke_easy_target(float* out3, int maxAgeMs);   // 1.4 (below): the target the game's PKE has locked, when seen in the last maxAgeMs
// 1.7.31 pair_hands: the hand poses read for the first eye of a pair, and how far the hands moved by the time the second eye asked (the measure of what each eye reading its own did)
static struct PairHands {
  HandsRaw hr; int got; int64_t q; double hc[3];
  volatile LONG reused, own, noPair, sameSample;
  long n, over5, over15, nMoving, nStill; double sumMm[2], maxMm[2], sumLMm, maxLMm; int64_t prevQ; double prevHc[3];
} g_pairHands;
static void pairhands_measure(const HandsRaw& fresh, int fg, const ArmStereo& st) {
  (void)st;
  if (!fg || !g_pairHands.got) return;
  if (fresh.sampleQ == g_pairHands.hr.sampleQ) { ++g_pairHands.sameSample; return; }
  // moving = the head centre moved more than 1.5 ft/s between two pairs (the player is walking)
  int moving = 0;
  const int64_t nq = qpc_now();
  if (g_pairHands.prevQ) {
    const double dt = (double)(nq - g_pairHands.prevQ) / (double)qpc_freq();
    if (dt > 0.0 && dt < 0.25) {
      const double dx = g_pairHands.hc[0] - g_pairHands.prevHc[0], dz = g_pairHands.hc[2] - g_pairHands.prevHc[2];
      moving = (dx * dx + dz * dz) > (1.5 * dt) * (1.5 * dt) ? 1 : 0;
    }
  }
  g_pairHands.prevQ = nq; for (int i = 0; i < 3; ++i) g_pairHands.prevHc[i] = g_pairHands.hc[i];
  double mm = 0.0, mmL = 0.0;
  if (fresh.validR && g_pairHands.hr.validR) {
    const double dx = (double)fresh.poseR[3] - g_pairHands.hr.poseR[3], dy = (double)fresh.poseR[7] - g_pairHands.hr.poseR[7], dz = (double)fresh.poseR[11] - g_pairHands.hr.poseR[11];
    mm = vm::dsqrt(dx * dx + dy * dy + dz * dz) * 1000.0;
  }
  if (fresh.validL && g_pairHands.hr.validL) {
    const double dx = (double)fresh.poseL[3] - g_pairHands.hr.poseL[3], dy = (double)fresh.poseL[7] - g_pairHands.hr.poseL[7], dz = (double)fresh.poseL[11] - g_pairHands.hr.poseL[11];
    mmL = vm::dsqrt(dx * dx + dy * dy + dz * dz) * 1000.0;
  }
  if (mm > 500.0 || mmL > 500.0) return;   // a jump of half a metre is tracking coming back, not motion
  ++g_pairHands.n; g_pairHands.sumMm[moving] += mm; if (mm > g_pairHands.maxMm[moving]) g_pairHands.maxMm[moving] = mm;
  g_pairHands.sumLMm += mmL; if (mmL > g_pairHands.maxLMm) g_pairHands.maxLMm = mmL;
  if (mm > 5.0) ++g_pairHands.over5; if (mm > 15.0) ++g_pairHands.over15;
  if (moving) ++g_pairHands.nMoving; else ++g_pairHands.nStill;
}
static void pairhands_report(LONG frame) {
  log_line("PAIRHANDS frame=%d pair_hands=%d | second eye used the first eye's hands %ld times, read its own %ld times, not in a pair %ld; no independent second-eye controller sample %ld times (distance unavailable) | how far the RIGHT controller moved between the two eyes of a pair (what each eye reading its own hand would show): standing mean %.1f max %.0f mm (%ld pairs), walking mean %.1f max %.0f mm (%ld pairs), over 5 mm %ld, over 15 mm %ld | left controller mean %.1f max %.0f mm",
           (int)frame, (int)g_ctl.pairHands, (long)g_pairHands.reused, (long)g_pairHands.own, (long)g_pairHands.noPair, (long)g_pairHands.sameSample,
           g_pairHands.nStill ? g_pairHands.sumMm[0] / (double)g_pairHands.nStill : 0.0, g_pairHands.maxMm[0], g_pairHands.nStill,
           g_pairHands.nMoving ? g_pairHands.sumMm[1] / (double)g_pairHands.nMoving : 0.0, g_pairHands.maxMm[1], g_pairHands.nMoving,
           g_pairHands.over5, g_pairHands.over15, g_pairHands.n ? g_pairHands.sumLMm / (double)g_pairHands.n : 0.0, g_pairHands.maxLMm);
}
static void starttl_sample(uintptr_t actor, const ArmStereo& st);   // 1.7.31 (defined after the wand state, below)
static void head_aim_publish(void* cam, const ArmStereo& st) {
  const float* view = st.view;
  const float* level = st.level;
  if (g_aimHook != 1) return;
  uintptr_t actor = 0;
  const uint8_t* b = (const uint8_t*)cam;
  if (memory_readable(b + layout::kCamFollowTarget, 8)) actor = *(const uintptr_t*)(b + layout::kCamFollowTarget);
  if (!actor || !memory_readable((const void*)actor, 8) || *(const uintptr_t*)actor != rva(layout::kRvaGhostbusterVtable)) {
    InterlockedIncrement(&g_aimSt.noActor);
    return;
  }
  // Sample and block the player's fall at the verified camera path. Body IK
  // may be disabled during a scripted or forced fall, so its update is too
  // narrow a place to observe the event.
  if (knock_comfort_on(actor)) knock_guard_actor(actor);
  knockdown_update((void*)actor);
  actor_watch(actor);
  starttl_sample(actor, st);
  float d[3];
  // 0.33: aim source 2 = the controllers (right hand, or the line between both hands); the head while none is tracked
  float handLevel[9];
  for (int i = 0; i < 9; ++i) handLevel[i] = level[i];
  // The scene's rendered picture is pitched toward Stay Puft. Pitch the
  // controller's world aiming basis by the same amount as the tracked hands
  // and visible gun, so its muzzle and beam follow the pictured blaster.
  // This changes neither actor physics nor the game's movement frame.
  if (!st.spec && engine_scene_arms(actor) && g_sceneStation.have)
    sceneview::aim_down(handLevel, g_sceneStation.facingYaw, g_sceneStation.pitchDown);
  if (!(g_ctl.headAim == 2 && controllers_hand_aim(handLevel, d)) && !aim::forward_from_basis(view, d)) return;
  // 0.34: the wand tip of the drawn wand, in game world axes (the stream starts there)
  // 0.51: the wand pose is the weighted one (controllers.cpp); the grip point is published for the game's own wand model
  float tip[3] = {0, 0, 0}, grip[3] = {0, 0, 0};
  float lpos[3] = {0, 0, 0}, lfwd[3] = {0, 0, 1}, lup[3] = {0, 1, 0};
  float wup[3] = {0, 1, 0};
  int hasTip = 0, hasGrip = 0, hasLeft = 0, hasWup = 0;
  float trigR = 0.0f;
  if (g_ctl.headAim == 2 && (g_ctl.handModel || g_ctl.realModels)) {
    HandsRaw hr;
    hand::Xform x;
    float two[12];
    int have = 0;
    const float* wp = nullptr;
    double pitch = g_ctl.handPitchDeci / 10.0;
    int gotHands;
    {   // 1.7.31 pair_hands: the second eye of a pair uses the hand poses read for the first eye, so the gun, the PKE and the arms are in the same place in both pictures (each eye used to read its own, ~14 ms later)
      const int role = st.pairRole;
      const int64_t nowH = qpc_now();
      if (role == 2 && g_pairHands.q && (double)(nowH - g_pairHands.q) < 0.1 * (double)qpc_freq()) {
        HandsRaw fresh;
        const int fg = controllers_raw(&fresh);   // read anyway: it measures how far the hands moved between the two eyes
        pairhands_measure(fresh, fg, st);
        if (g_ctl.pairHands) { hr = g_pairHands.hr; gotHands = g_pairHands.got; InterlockedIncrement(&g_pairHands.reused); }
        else { hr = fresh; gotHands = fg; InterlockedIncrement(&g_pairHands.own); }
      } else {
        gotHands = controllers_raw(&hr);
        if (role == 1) { g_pairHands.hr = hr; g_pairHands.got = gotHands; g_pairHands.q = nowH; g_pairHands.hc[0] = st.headCenter[0]; g_pairHands.hc[1] = st.headCenter[1]; g_pairHands.hc[2] = st.headCenter[2]; }
        else InterlockedIncrement(&g_pairHands.noPair);
      }
    }
    if (gotHands) { trigR = hr.trigR; }
    if (gotHands && hr.validL && g_ctl.armIk == 1) {   // 0.57: the left controller in game world, for the left arm
      hand::Xform xl;
      if (hand::model_to_eye(st.pose34, hr.poseL, nullptr, 0.0, &xl)) {
        const float o3[3] = {0, 0, 0}, f3[3] = {0, 0, -1}, u3[3] = {0, 1, 0};
        float po[3], pf[3], pu[3];
        hand::apply(xl, o3, po); hand::apply(xl, f3, pf); hand::apply(xl, u3, pu);
        for (int r = 0; r < 3; ++r) {
          lpos[r] = (float)(st.headCenter[r] + st.feetPerMetre * ((double)view[r * 3] * po[0] + (double)view[r * 3 + 1] * po[1] + (double)view[r * 3 + 2] * po[2]));
          lfwd[r] = (float)((double)view[r * 3] * (pf[0] - po[0]) + (double)view[r * 3 + 1] * (pf[1] - po[1]) + (double)view[r * 3 + 2] * (pf[2] - po[2]));
          lup[r] = (float)((double)view[r * 3] * (pu[0] - po[0]) + (double)view[r * 3 + 1] * (pu[1] - po[1]) + (double)view[r * 3 + 2] * (pu[2] - po[2]));
        }
        hasLeft = vm::is_finite_f(lpos[0]) && vm::is_finite_f(lpos[1]) && vm::is_finite_f(lpos[2]) && vm::is_finite_f(lfwd[0]) && vm::is_finite_f(lfwd[1]) &&
                  vm::is_finite_f(lfwd[2]) && vm::is_finite_f(lup[0]) && vm::is_finite_f(lup[1]) && vm::is_finite_f(lup[2]);
      }
    }
    if (gotHands && hr.validR) {
      if (hr.wandValid) { wp = hr.wandPose; if (hr.wandTwo) pitch = 0.0; }
      else if (g_ctl.twoHandLine && hr.validL && hr.gripL && hand::two_hand_pose_ref(hr.poseR, hr.poseL, 0.12, (double)g_ctl.dpadAwayCm / 100.0, (double)g_ctl.twoHandPitchDeci / 10.0, (double)g_ctl.twoHandRefCm / 100.0, two)) { wp = two; pitch = 0.0; }
      else wp = hr.poseR;
      have = hand::model_to_eye(st.pose34, wp, nullptr, pitch, &x);
    }
    if (have) {
      float p[3], e[3] = {hand::kTipX, hand::kTipY, hand::kTipZ}, g0[3] = {0, 0, 0}, pg[3];
      hand::apply(x, e, p);   // head-centre space, engine axes, metres
      hand::apply(x, g0, pg);
      for (int r = 0; r < 3; ++r) {
        tip[r] = (float)(st.headCenter[r] + st.feetPerMetre * ((double)view[r * 3] * p[0] + (double)view[r * 3 + 1] * p[1] +
                                                               (double)view[r * 3 + 2] * p[2]));
        grip[r] = (float)(st.headCenter[r] + st.feetPerMetre * ((double)view[r * 3] * pg[0] + (double)view[r * 3 + 1] * pg[1] +
                                                                (double)view[r * 3 + 2] * pg[2]));
      }
      {   // 0.58 the wand's up direction (the grip's up) in game world
        const float u3[3] = {0, 1, 0};
        float pu[3];
        hand::apply(x, u3, pu);
        for (int r = 0; r < 3; ++r)
          wup[r] = (float)((double)view[r * 3] * (pu[0] - pg[0]) + (double)view[r * 3 + 1] * (pu[1] - pg[1]) + (double)view[r * 3 + 2] * (pu[2] - pg[2]));
        hasWup = vm::is_finite_f(wup[0]) && vm::is_finite_f(wup[1]) && vm::is_finite_f(wup[2]);
      }
      // wand_back_cm: slide the wand toward the player (+) / away (-) along its barrel
      double back = (double)g_ctl.wandBackCm * 0.01 * st.feetPerMetre;
      if (back != 0.0) for (int r = 0; r < 3; ++r) { tip[r] -= (float)(d[r] * back); grip[r] -= (float)(d[r] * back); }
      hasTip = vm::is_finite_f(tip[0]) && vm::is_finite_f(tip[1]) && vm::is_finite_f(tip[2]);
      hasGrip = vm::is_finite_f(grip[0]) && vm::is_finite_f(grip[1]) && vm::is_finite_f(grip[2]);
      {   // 1.7.206 GUNVIEW (data only): where the drawn gun sits in the head's own frame, and which way the barrel points against the head
        static int64_t s_gvQ; static LONG s_gvN; static double s_gvMinR = 1e9, s_gvMaxR = -1e9, s_gvMinY = 1e9, s_gvMaxY = -1e9;
        double dh[3];
        for (int i = 0; i < 3; ++i) dh[i] = (double)view[0 + i] * d[0] + (double)view[3 + i] * d[1] + (double)view[6 + i] * d[2];
        const double rCm = pg[0] * 100.0, uCm = pg[1] * 100.0, fCm = pg[2] * 100.0;
        const double sideDeg = vm::datan2(pg[0], pg[2]) * 57.29577951308232;
        const double yawDeg = vm::datan2(dh[0], dh[2]) * 57.29577951308232;
        if (vm::is_finite_f((float)yawDeg) && vm::is_finite_f((float)sideDeg)) { if (rCm < s_gvMinR) s_gvMinR = rCm; if (rCm > s_gvMaxR) s_gvMaxR = rCm; if (yawDeg < s_gvMinY) s_gvMinY = yawDeg; if (yawDeg > s_gvMaxY) s_gvMaxY = yawDeg; }
        const int64_t gq = qpc_now();
        if (!s_gvQ || (double)(gq - s_gvQ) > 2.0 * (double)qpc_freq()) {
          s_gvQ = gq;
          if (InterlockedIncrement(&s_gvN) <= 400)
            log_line("GUNVIEW two-hand line %d | grip from the eye: right %.1f up %.1f fwd %.1f cm (%.1f deg %s of straight ahead) | barrel yaw against the head %.1f deg (%s) | last 2 s: grip right %.1f..%.1f cm, barrel yaw %.1f..%.1f deg | world %d%%, view_model %d%%",
                     wp == two ? 1 : 0, rCm, uCm, fCm, sideDeg < 0 ? -sideDeg : sideDeg, sideDeg < 0 ? "LEFT" : "right", yawDeg, yawDeg < 0 ? "LEFT" : "right", s_gvMinR, s_gvMaxR, s_gvMinY, s_gvMaxY, (int)g_ctl.worldPct, (int)g_ctl.viewModelPct);
          s_gvMinR = 1e9; s_gvMaxR = -1e9; s_gvMinY = 1e9; s_gvMaxY = -1e9;
        }
      }
    }
  }
  float dA[3] = {d[0], d[1], d[2]};
  {   // 0.68 aim assist (see assistmath.h): only while the trigger is down (+ a short tail so the pull lets go smoothly)
    static int64_t s_q, s_fireQ;
    const int64_t nowq = qpc_now();
    double dtA = s_q ? (double)(nowq - s_q) / (double)qpc_freq() : 0.011;
    s_q = nowq;
    if (!(dtA > 0.0005)) dtA = 0.0005; if (dtA > 0.1) dtA = 0.1;
    const int firing = trigR > 0.5f;
    if (firing) s_fireQ = nowq;
    const int tail = s_fireQ && (double)(nowq - s_fireQ) < 0.25 * (double)qpc_freq();
    const int enabled = g_ctl.aimAssistPct > 0 && g_ctl.headAim == 2;
    const int ringFresh = g_ring.qpc && aim::is_fresh(nowq, g_ring.qpc, qpc_freq(), 350);   // 0.69: 350 ms (the game draws its ring on only ~1 frame in 9)
    double o3[3] = {hasTip ? tip[0] : st.headCenter[0], hasTip ? tip[1] : st.headCenter[1], hasTip ? tip[2] : st.headCenter[2]};
    double d3[3] = {d[0], d[1], d[2]}, t3[3] = {g_ring.pos[0], g_ring.pos[1], g_ring.pos[2]}, a3[3];
    // 1.7: the beam is only pulled toward a GHOST. The game's lock ring also sits on tables, chairs and other things it can grab; a world point with no living enemy at it is skipped.
    int ghostOk = 1;
    if (g_ctl.aimGhostOnly && enabled && (firing || tail) && ringFresh) {
      const float rp[3] = {g_ring.pos[0], g_ring.pos[1], g_ring.pos[2]};
      const int isGhost = fight_enemy_near(rp, 1.5);
      if (isGhost == 0) { ghostOk = 0; InterlockedIncrement(&g_ghostGate.blocked); }
      else if (isGhost > 0) InterlockedIncrement(&g_ghostGate.passed);
      else InterlockedIncrement(&g_ghostGate.unknown);
      if (isGhost == 0 && g_ghostGate.logged < 25 && (g_ghostGate.blocked % 40) == 1) { ++g_ghostGate.logged; log_line("AIMGHOST the game's lock ring is at %.1f,%.1f,%.1f ft but no ghost is there (a table, a chair or another thing it can grab): the beam is NOT pulled toward it", (double)rp[0], (double)rp[1], (double)rp[2]); }
    }
    const int useTarget = enabled && (firing || tail) && ringFresh && ghostOk;
    // 0.94 scan help: with the PKE in hand the nearest scannable PKE source that is nearly in line gets the pull (things on the floor, in odd places), no trigger needed
    assist::State* ast = &g_assistSt;
    double coneUse = (double)g_ctl.aimAssistDeg, strUse = enabled ? (double)g_ctl.aimAssistPct / 100.0 : 0.0, sizeUse = 1.0;
    const double* tgtUse = useTarget ? t3 : nullptr;
    double ps3[3] = {0, 0, 0};
    int pkeHeldNow = 0;
    if (g_ctl.pkeAssistDeg > 0 && g_ctl.pkeAssistPct > 0 && g_ctl.headAim == 2 && pke_item_held()) {
      pkeHeldNow = 1;
      float src[16][3]; int64_t sq = 0;
      const int ns = fight_pke_sources(src, 16, &sq);
      double bestAng = 1e9;
      const double po[3] = {hasGrip ? grip[0] : o3[0], hasGrip ? grip[1] : o3[1], hasGrip ? grip[2] : o3[2]};
      for (int k = 0; k < ns; ++k) {
        const double sp[3] = {src[k][0], src[k][1], src[k][2]};
        double ang = 0, dist = 0, uu[3];
        if (assist::angle_to(po, d3, sp, 1.0, 150.0, &ang, &dist, uu) && ang < bestAng) { bestAng = ang; ps3[0] = sp[0]; ps3[1] = sp[1]; ps3[2] = sp[2]; }
      }
      // 1.4: the target the game itself locked (the ghost in front of the PKE), not only the "PKE source" actors: it is what the game will scan
      float gtp[3];
      if (pke_easy_target(gtp, 250)) {
        const double sp[3] = {gtp[0], gtp[1], gtp[2]};
        double ang = 0, dist = 0, uu[3];
        if (assist::angle_to(po, d3, sp, 1.0, 150.0, &ang, &dist, uu) && ang < bestAng) { bestAng = ang; ps3[0] = sp[0]; ps3[1] = sp[1]; ps3[2] = sp[2]; }
      }
      static LONG s_pkeAsLog;
      if (bestAng < 1e8) { o3[0] = po[0]; o3[1] = po[1]; o3[2] = po[2]; tgtUse = ps3; if (s_pkeAsLog < 30 && bestAng < (double)g_ctl.pkeAssistDeg + 20.0 && (s_pkeAsLog++ % 1) == 0) log_line("PKEASSIST a PKE source at %.1f,%.1f,%.1f ft is %.1f deg off where the PKE points (cone %d deg, %d sources near)", ps3[0], ps3[1], ps3[2], bestAng, (int)g_ctl.pkeAssistDeg, ns); }
      else tgtUse = nullptr;
      ast = &g_assistPkeSt; coneUse = (double)g_ctl.pkeAssistDeg; strUse = (double)g_ctl.pkeAssistPct / 100.0 * 1.5; sizeUse = 1.2;
    }
    assist::Result r = assist::step(ast, o3, d3, tgtUse, dtA, coneUse, strUse, sizeUse, a3);
    if (pkeHeldNow) { if (r.active) { InterlockedIncrement(&g_pkeAssistN.active); const LONG tx = (LONG)(r.turnedDeg * 100.0); if (tx > g_pkeAssistN.maxTurnX100) g_pkeAssistN.maxTurnX100 = tx; } InterlockedIncrement(&g_pkeAssistN.ticks); }
    ++g_assistLog.ticks;
    if (firing) ++g_assistLog.fireTicks;
    if (ringFresh && enabled) {   // data: where the game's target ring is compared with the beam, while firing (first 40 + every 100th)
      ++g_assistLog.candTicks;
      double ang = 0, dist = 0, u[3];
      if ((firing || tail) && assist::angle_to(o3, d3, t3, 0.0, 1.0e9, &ang, &dist, u)) {
        g_assistLog.lastAng = ang; g_assistLog.lastDist = dist; g_assistLog.lastCone = r.coneDeg;
        for (int i = 0; i < 3; ++i) g_assistLog.lastPos[i] = (float)t3[i];
        if (g_assistLog.posLogged < 40 || (g_assistLog.candTicks % 100) == 0) {
          ++g_assistLog.posLogged;
          log_line("AIMASSIST target ring at %.1f,%.1f,%.1f ft: %.1f ft from the wand tip, %.2f deg from the beam, firing=%d, pull %.2f deg (cone %.1f, ring object %p)",
                   t3[0], t3[1], t3[2], dist, ang, firing, r.turnedDeg, r.coneDeg, (void*)g_ring.self);
        }
      }
    }
    if (r.active) {
      for (int i = 0; i < 3; ++i) dA[i] = (float)a3[i];
      ++g_assistLog.activeTicks;
      g_assistLog.lastTurn = r.turnedDeg;
      const LONG tx = (LONG)(r.turnedDeg * 100.0);
      if (tx > g_assistLog.maxTurnX100) g_assistLog.maxTurnX100 = tx;
      if (!g_assistLog.wasActive) { ++g_assistLog.lockStarts; if (g_assistLog.lockStarts <= 12) log_line("AIMASSIST pulling: target %.2f deg off at %.1f ft, beam turned %.2f deg so far (strength %d%%)", r.angDeg, r.distFt, r.turnedDeg, (int)g_ctl.aimAssistPct); }
    }
    g_assistLog.wasActive = r.active;
  }
  InterlockedIncrement(&g_headAim.seq);
  g_headAim.actor = actor;
  g_headAim.dir[0] = d[0]; g_headAim.dir[1] = d[1]; g_headAim.dir[2] = d[2];
  g_headAim.adir[0] = dA[0]; g_headAim.adir[1] = dA[1]; g_headAim.adir[2] = dA[2];
  g_headAim.tip[0] = tip[0]; g_headAim.tip[1] = tip[1]; g_headAim.tip[2] = tip[2];
  g_headAim.hasTip = hasTip;
  g_headAim.grip[0] = grip[0]; g_headAim.grip[1] = grip[1]; g_headAim.grip[2] = grip[2];
  g_headAim.hasGrip = hasGrip;
  for (int i = 0; i < 3; ++i) g_headAim.wup[i] = wup[i];
  g_headAim.hasWup = hasWup;
  for (int i = 0; i < 3; ++i) { g_headAim.lpos[i] = lpos[i]; g_headAim.lfwd[i] = lfwd[i]; g_headAim.lup[i] = lup[i]; }
  g_headAim.hasLeft = hasLeft;
  g_headAim.fpm = (float)st.feetPerMetre;
  for (int i = 0; i < 3; ++i) { g_headAim.eye[i] = st.headCenter[i]; g_headAim.gaze[i] = (float)view[i * 3 + 2]; }
  for (int i = 0; i < 9; ++i) g_headAim.view9[i] = view[i];   // 1.7.167
  g_headAim.qpc = qpc_now();
  InterlockedIncrement(&g_headAim.seq);
  InterlockedIncrement(&g_aimSt.published);
}

static void __fastcall hk_aim_set(float* field, const float* v) {
  stage_g(ST_G_AIM);
  InterlockedIncrement(&g_aimSt.calls);
  if (g_ctl.headAim && g_ctl.stereoActive && field && v) {
    uintptr_t actor = 0;
    float d[3] = {0, 0, 0}, ad[3] = {0, 0, 0};
    int64_t q = 0;
    int ok = 0;
    for (int tries = 0; tries < 3 && !ok; ++tries) {
      LONG s0 = g_headAim.seq;
      if (s0 & 1) continue;
      actor = g_headAim.actor;
      d[0] = g_headAim.dir[0]; d[1] = g_headAim.dir[1]; d[2] = g_headAim.dir[2];
      ad[0] = g_headAim.adir[0]; ad[1] = g_headAim.adir[1]; ad[2] = g_headAim.adir[2];
      q = g_headAim.qpc;
      ok = g_headAim.seq == s0;
    }
    if (ok && actor && (uintptr_t)field == actor + layout::kAimDirOffset) {
      InterlockedIncrement(&g_aimSt.playerCalls);
      if (aim::is_fresh(qpc_now(), q, qpc_freq(), 250)) {
        float game[3] = {v[0], v[1], v[2]};
        if (vm::is_finite_f(game[0]) && vm::is_finite_f(game[1]) && vm::is_finite_f(game[2])) { g_gameAim.v[0] = game[0]; g_gameAim.v[1] = game[1]; g_gameAim.v[2] = game[2]; g_gameAim.qpc = qpc_now(); }
        if (vm::is_finite_f(game[0]) && vm::is_finite_f(game[1]) && vm::is_finite_f(game[2])) {
          double deg = aim::angle_deg(game, d);
          LONG x100 = (LONG)(deg * 100.0);
          g_aimSt.lastDegX100 = x100;
          if (x100 > g_aimSt.worstDegX100) g_aimSt.worstDegX100 = x100;
          for (int i = 0; i < 3; ++i) { g_aimSt.lastGame[i] = game[i]; g_aimSt.lastHead[i] = d[i]; }
        }
        if (InterlockedIncrement(&g_aimSt.overridden) == 1)
          log_line("HEADAIM first override: the game's aim (%.3f,%.3f,%.3f) replaced by the head direction (%.3f,%.3f,%.3f) "
                   "(player actor %p)", (double)v[0], (double)v[1], (double)v[2], (double)d[0], (double)d[1], (double)d[2],
                   (void*)actor);
        o_aimSet(field, (vm::is_finite_f(ad[0]) && vm::is_finite_f(ad[1]) && vm::is_finite_f(ad[2])) ? ad : d);   // 0.68: with aim assist
        return;
      }
      InterlockedIncrement(&g_aimSt.stale);
    }
  }
  o_aimSet(field, v);
}

// 0.34: the stream starts at the "tip" attachment of the player's model. For the
// player (and only while the controllers drive the aim) the translation of the
// returned world matrix is replaced by the tip of the drawn wand; the rotation
// and everything else stay the game's.
typedef void*(__fastcall* PFN_AttachMatrix)(void* actor, float* out, const char* name);
static PFN_AttachMatrix o_attach;
static int g_tipHook;   // 1 installed, 0 not yet, <0 why not
static struct { volatile LONG calls, tipCalls, overridden, stale, gameTip; volatile float lastOld[3], lastNew[3]; volatile LONG lastDistX100; } g_tipSt;


// 0.45: the stream is built in the frame of the "tip" matrix (layout.h kRvaVecToAngles): the hit point is turned into
// that frame, its angles are measured from the frame's +Z axis = ROW 2 of the matrix (the game's own matrix-to-angles
// function, its orthonormaliser and its angles-to-vector function all use row 2 as forward), angles beyond 30 degrees
// fade out and beyond 60 degrees become zero, which leaves the stream pointing straight along row 2. So the controller
// aim has to be written into row 2. (0.41 learnt a row from the idle pose and rewrote row 0, which left row 2 sideways:
// the stream flew to the right and never reached a ghost.) The other two rows are turned with it, lengths and
// handedness kept. A hook on the angle function only watches (STREAMANG): how far the game still had to turn the stream.
static struct {
  volatile LONG applied, failed;
  volatile LONG streamCalls, within5, within30, within60, beyond60;
  volatile LONG lastHeadX10, lastPitchX10, worstX10;
  volatile float lastLocal[3];
} g_tipRot;
// 0.69 straight beam: the stream update asks for the "tip" matrix (call site kRvaTipCallers[3]) and a little later measures the angle between
// the tip's forward axis and the line to the hit point; the game bends the stream by that angle (fading out between 30 and 60 degrees). The
// hit point comes from a ray along the aim direction that starts at the head, not at the gun, so near ghosts the bend was several degrees to
// either side ("the gun shoots off to the left and right"). For the player's stream those two angles are set to zero: the stream leaves along
// the barrel. (Which stream is the player's: the tip fetched by that call site was the player's actor, on this thread.)
static struct { volatile LONG tipFetches, tipPlayer, calls, straightened, bentOver2, bentOver5, bentOver10; volatile LONG sumAbsX100, maxAbsX100, lastHX10, lastPX10; } g_beam;
static volatile LONGLONG g_streamSeenQ;   // 0.79: when the player's own stream was last updated (the game really fires)
static volatile LONG g_streamTipTid;   // thread that last fetched the PLAYER's tip for the stream update (0 = the last fetch was another actor's)
static void tip_rotate(float* m, const float* dir) {
  double d[3] = {dir[0], dir[1], dir[2]};
  double dl = vm::dsqrt(tipmath::dot3(d, d));
  if (!(dl > 0.5) || !(dl < 2.0)) { InterlockedIncrement(&g_tipRot.failed); return; }
  for (int j = 0; j < 3; ++j) d[j] /= dl;
  if (tipmath::rewrite_row(m, 2, 1.0, d)) InterlockedIncrement(&g_tipRot.applied);
  else InterlockedIncrement(&g_tipRot.failed);
}

// 0.79: 1 while the game really fires the player's stream (it updated within ms milliseconds). No stream = the game refuses (cutscene, no-fire zone): no buzz.
int engine_stream_recent(int ms) { const LONGLONG q = g_streamSeenQ; return q && qpc_now() - q < (LONGLONG)ms * qpc_freq() / 1000; }
typedef float*(__fastcall* PFN_VecToAngles)(float* out, const float* v);
static PFN_VecToAngles o_vecAngles;
static int g_angHook;   // 1 installed, 0 not yet, <0 why not
static GBVR_NOINLINE float* __fastcall hk_vec_angles(float* out, const float* v) {
  void* ret = GBVR_RETURN_ADDRESS();
  float* r = o_vecAngles(out, v);
  if ((uintptr_t)ret == rva(layout::kRvaStreamAnglesReturn) && out && v && r) {
    InterlockedIncrement(&g_tipRot.streamCalls);
    double hd = 57.29577951308232 * (double)out[1], pd = 57.29577951308232 * (double)out[0];
    if (g_streamTipTid && g_streamTipTid == (LONG)GetCurrentThreadId() && hd == hd && pd == pd) {   // 0.69: the player's own stream
      InterlockedIncrement(&g_beam.calls);
      g_streamSeenQ = qpc_now();
      const double ah = hd < 0 ? -hd : hd, ap = pd < 0 ? -pd : pd, w = ah > ap ? ah : ap;
      const LONG wx = (LONG)(w * 100.0);
      InterlockedExchangeAdd(&g_beam.sumAbsX100, wx > 100000 ? 100000 : wx);
      if (wx > g_beam.maxAbsX100) g_beam.maxAbsX100 = wx;
      if (w > 2.0) InterlockedIncrement(&g_beam.bentOver2);
      if (w > 5.0) InterlockedIncrement(&g_beam.bentOver5);
      if (w > 10.0) InterlockedIncrement(&g_beam.bentOver10);
      g_beam.lastHX10 = (LONG)(hd * 10.0); g_beam.lastPX10 = (LONG)(pd * 10.0);
      const int stationBeam = engine_scene_arms(0) && g_sceneStation.have && g_ctl.stationBeamFree;   // 1.7.169
      if (stationBeam) { InterlockedIncrement(&g_stAim.beamFree); const LONG wx2 = (LONG)(w * 10.0); InterlockedExchangeAdd(&g_stAim.bendSumX10, wx2 > 100000 ? 100000 : wx2); InterlockedIncrement(&g_stAim.bendN); if (wx2 > g_stAim.bendMaxX10) g_stAim.bendMaxX10 = wx2; }
      if (!stationBeam && g_ctl.beamStraight && g_ctl.headAim == 2 && g_ctl.stereoActive) { out[0] = 0.0f; out[1] = 0.0f; InterlockedIncrement(&g_beam.straightened); hd = pd = 0.0; }
    }
    if (hd == hd && pd == pd) {   // not NaN
      double ah = hd < 0 ? -hd : hd, ap = pd < 0 ? -pd : pd, w = ah > ap ? ah : ap;
      if (w < 5.0) InterlockedIncrement(&g_tipRot.within5);
      else if (w < 30.0) InterlockedIncrement(&g_tipRot.within30);
      else if (w < 60.0) InterlockedIncrement(&g_tipRot.within60);
      else InterlockedIncrement(&g_tipRot.beyond60);
      g_tipRot.lastHeadX10 = (LONG)(hd * 10.0); g_tipRot.lastPitchX10 = (LONG)(pd * 10.0);
      if ((LONG)(w * 10.0) > g_tipRot.worstX10) g_tipRot.worstX10 = (LONG)(w * 10.0);
      g_tipRot.lastLocal[0] = v[0]; g_tipRot.lastLocal[1] = v[1]; g_tipRot.lastLocal[2] = v[2];
    }
  }
  return r;
}

static void install_angles_watch() {
  if (!bytes_match(layout::kRvaVecToAngles, layout::kBytesVecToAngles, 16)) {
    g_angHook = -1;
    log_line("STREAMANG not available (bytes differ): the stream direction is not measured, the fix itself does not need it");
    return;
  }
  void* t = (void*)rva(layout::kRvaVecToAngles);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_vec_angles, (void**)&o_vecAngles);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_angHook = s == MH_OK ? 1 : -2;
  log_line("HOOK stream-angles watch status=%d target=%p (%s)", (int)s, t, g_angHook == 1 ? "available" : "NOT available");
}

// ---- 0.51 the game's own wand model at the controller ----------------------------------------------------------
// The wand is a separate model instance drawn with the world matrix W at actor+0x24718 (layout.h). To put it into the
// hand: rotate the whole instance about the grip so the barrel (the "tip" attachment's forward, row 2) points along the
// controller's aim, and move the grip point (W's translation) to the controller. In row-vector form, with R the rotation:
//     W'rot = Wrot * R^T,   W'trans = hand        and the tip ends at  hand + R * (tip - W.t).
// The same numbers move the stream's start (hk_attach_matrix), so wand model and stream agree.
static struct {
  volatile LONG calls, applied, noAim, stale, noTip, bad, farSkip, holstered, hookCalls, holsterBack;
  volatile LONG lastTurnX10, maxTurnX10, lastGripTipX100, lastShiftX100, firstLogged;
  volatile LONG lastRollX10, maxRollX10, rolled;   // 0.58
  volatile LONG gateOff, notMine, pkeOut, gateOffLast, lastAppliedAt;   // 1.0: why pushes were NOT turned into hand moves (settings/stereo gate, another buster's wand, PKE out)
  volatile LONG glued, lastGlueX100, maxGlueX100, tipGlued;   // 0.66: gun kept in the avatar's hand when the arm fell short (ft x100)
  volatile LONG handFit, tipFit;   // 0.93: gun (and the beam's start) slid so the handle is in the hand
  volatile LONG rigidDevMaxX100, rigidDevMeanX100, rigidHeld, rigidUsedX100, rigidTipHeld;   // 1.6: the game's hand-to-gun offset against the rigid one (cm x100), polls without a fresh value, the slide used last
  volatile LONG fitMenu;   // 1.7: frames the menu's gun fit was applied
  volatile LONG sized, tipSized;   // 0.77: gun drawn bigger (view_model_pct) / stream start moved with it
  volatile LONG gapHidden;         // 1.7.66: calls where the gun was not drawn because there was no hand for it yet
  volatile float lastTip0[3], lastW[3];
} g_wandSt;
static int g_wandHook;   // 1 installed, 0 not yet, <0 why not
static volatile float g_gunRigidLast[3]; static volatile int64_t g_gunRigidAt;   // 1.6: the gun's rigid hand slide last used (ft), and when
static volatile float g_gunFitOff[3]; static volatile int64_t g_gunFitAt;   // 1.7: the menu's gun fit (forward / up, feet in game space) last applied to the drawn gun, and when: the muzzle takes the same
// 1.7.2: where the gun was finally put this frame (game feet, after the slide and the fit) and which way it points: the HOLDCHECK line measures it against the drawn wrist
static volatile float g_gunPlaced[3], g_gunPlacedDir[3]; static volatile int64_t g_gunPlacedAt;
static volatile float g_gunPlacedGrip[3], g_gunPlacedUp[3];   // 1.7.104: the controller point and up the gun was placed from (the left hand's foregrip is measured from the same moment)
// 1.7.58: the drawn wand is placed by preserving the GAME'S complete hand->wand relation.
// One full relation is locked per equipped item; it survives view-model rebuilds and holster/draw gaps.
static struct ExactWandGrip {
  handprop::GripLock lock[9];                         // exact GAME prop -> GAME hand, one per item
  handprop::HandFollower handFollow[9];              // final rendered hand -> tracked controller, never prop -> controller
  uintptr_t handFollowActor[9];
  uintptr_t lockActor[9];                         // preserve through viewmodel/holster gaps, reset only for a genuinely new player actor
  volatile LONG seq;
  uintptr_t actor; float gameM[16], finalM[16]; int64_t q; int have;
  volatile LONG used, fallback, tipMapped, tipFallback;
} g_exactWand;
// 1.7.143: the gun's / PKE's hand <-> controller relation easing back to the drawn hand (handprop.h drift_step)
static handprop::HandDrift g_gunDrift[9], g_pkeDrift;
static void prop_drift_log(const char* what, int slot, const handprop::HandDrift& d) {   // once per new easing (40 lines at most)
  static long s_seen[10]; static LONG s_logs;
  const int k = (slot >= 0 && slot < 9) ? slot : 9;
  if (d.relocks == s_seen[k]) return;
  s_seen[k] = d.relocks;
  if (InterlockedIncrement(&s_logs) <= 40)
    log_line("PROPDRIFT t=%.2fs %s %d: the drawn hand was %.1f cm from where the controller held the %s (largest so far %.1f cm); the hold eases back into the hand (%ld times in all)",
             qpc_ms() / 1000.0, what, slot, d.lastCm, what, d.maxCm, d.relocks);
}
static void gun_drift_log(int slot, const handprop::HandDrift& d) { prop_drift_log("gun", slot, d); }

// 1.7.66: spawn / view-model switch.
// (a) the first seconds after the gun's hold is locked, the lock is compared with what the game shows; a steady and clearly different hold (the spawn pose is not the
//     weapon's real hold) is taken again.  (b) while there is no hand for the gun (spawn, weapon switch) the gun is not drawn at the game's own spot (the floor, as the
//     1.7.65 video showed for 0.8 s at spawn); it shows the moment the hand is ready.  Both write GUNGRIP / GUNGAP lines with the time, so a video can be lined up with the log.
// 1.7.68: the hand on the gun follows the game's own hold as the game shows it now (like at spawn), instead of a hold frozen ~0.1 s after the weapon is equipped.
// The 1.7.65 video: at spawn (item not known yet, the game's current hold was used) the glove wrapped the handle; after PKE -> gun the hold was frozen during the draw
// animation and the hand sat at the bottom of the grip / floated under the gun.  A one-frame glitch is ignored; a lasting change is followed after 8 samples.
static volatile LONG g_gunFarHolds, g_gunNoHoldHidden;
static double g_gunHoldStep[2], g_gunHoldStepMax[2]; static long g_gunHoldStepN[2], g_gunHoldEased;   // 1.7.71: the game's hold change per update (cm), [0] standing [1] walking
static handprop::Live g_gunLive[9]; static uintptr_t g_gunLiveActor[9]; static LONG g_gunLiveLogs; static int64_t g_gunLiveQ[9]; static int g_gunLiveSlot = -2;
static struct GunHeal { uintptr_t actor; int64_t lockQ; int run, haveFresh, heals; float fresh[16]; } g_gunHeal[9];
static struct GunGapSt { int64_t startQ; long frames, hidden, episodes, logs; int kind; double maxMs; } g_gunGap;
static LONG g_vmSwitchLogs; static int g_vmLastSlot = -2;
// 1.7.98 the game's own draw animation shown on the hand (drawanimmath.h): one window for the gun (opens at every weapon switch), one for the PKE (opens when the meter comes out)
static drawanim::Window g_drawWin, g_pkeWin;
static struct { double off[3]; double offStartS; int offOn; double lastPos[3]; int lastHave; } g_da;   // the last drawn spot of the animated gun, and the offset that fades out when the normal hold takes over
static LONG g_daLogs; static double g_daLogS; static double g_hmUntilS;   // g_hmUntilS: HANDMOVE (the game's own hand) is logged until then
static const char* da_why(int closedBy) { return closedBy == 1 ? "the game's relation arrived at the hold" : closedBy == 2 ? "the time ran out" : closedBy == 3 ? "another item came" : "never needed"; }
static void da_log_shown(const char* what, int slot, const drawanim::Window& w, double nowS, double lenFt, int haveHold, double distFt) {
  if (g_daLogs >= 60 || nowS - g_daLogS < 0.07) return;
  g_daLogS = nowS; ++g_daLogs;
  log_line("DRAWANIM t=%.2fs item %d +%d ms: the game's %s is %.1f cm from the hand%s | the game's own fingers, total bend in degrees: index %d, middle %d, ring %d, pinkie %d",
           nowS, slot, (int)((nowS - w.startS) * 1000.0), what, lenFt * 30.48, haveHold ? "" : " (no resting hold yet)", arms_right_finger_base_x10(1) / 10, arms_right_finger_base_x10(2) / 10, arms_right_finger_base_x10(3) / 10, arms_right_finger_base_x10(4) / 10);
  (void)distFt;
}
static void da_log_end(const char* what, int slot, drawanim::Window& w) {
  if (w.open || w.endLogged || !w.closedBy) return;
  w.endLogged = 1;
  if (g_daLogs >= 80) return;
  ++g_daLogs;
  log_line("DRAWANIM end t=%.2fs item %d: the game's %s was drawn from its own animation on %ld of %ld looks over %d ms, farthest %.1f cm from the hand; closed because %s",
           w.endS, slot, what, w.shown, w.frames, (int)((w.endS - w.startS) * 1000.0), w.maxLenFt * 30.48, da_why(w.closedBy));
}
// 1.7.99: 1 = the game's gun was placed at the controller within the last maxAgeS seconds (so a life bar drawn at the controller sits on the gun, not on an empty hand)
int engine_gun_placed(double maxAgeS) { if (g_wandHook != 1 || g_ctl.gamePlace || !g_ctl.realModels) return 1; /* the probe does not place the gun: nothing to compare with */ const int64_t q = g_gunPlacedAt; return q && (double)(qpc_now() - q) / (double)qpc_freq() < maxAgeS; }
static void gun_grip_heal(int slot, uintptr_t actor, const float* wand, const float* gameHand) {
  if (slot < 0 || slot >= 9) return;
  handprop::GripLock& lk = g_exactWand.lock[slot];
  GunHeal& h = g_gunHeal[slot];
  if (h.actor != actor) { h.actor = actor; h.lockQ = 0; h.run = 0; h.haveFresh = 0; h.heals = 0; }
  const int64_t now = qpc_now(); const double fq = (double)qpc_freq();
  if (!lk.locked) { h.lockQ = 0; h.run = 0; h.haveFresh = 0; return; }
  if (!h.lockQ) {
    h.lockQ = now; h.run = 0; h.haveFresh = 0;
    const double len = vm::dsqrt((double)lk.rel[12]*lk.rel[12] + (double)lk.rel[13]*lk.rel[13] + (double)lk.rel[14]*lk.rel[14]) * 30.48;
    static LONG s_lockLogs;
    if (InterlockedIncrement(&s_lockLogs) <= 30) log_line("GUNGRIP lock taken t=%.2fs item %d: game's hand-to-gun relation %.1f cm long (it is compared with the game's hold for 10 s)", qpc_ms() / 1000.0, slot, len);
  }
  if (!g_ctl.gunGripHeal) return;   // 1.7.67: off (the gun hand is left exactly as in 1.7.65); the lock is still logged
  if (h.heals >= 3 || (double)(now - h.lockQ) / fq > 10.0) return;
  float fr[16];
  if (!handprop::relative(wand, gameHand, fr)) return;
  const double dp = handprop::rel_pos_delta(fr, lk.rel), da = handprop::rel_axis_delta(fr, lk.rel);
  const int differs = dp > 0.13 || da > 0.0055;   // about 4 cm or 6 degrees
  const int steady = h.haveFresh && handprop::rel_pos_delta(fr, h.fresh) <= 0.05 && handprop::rel_axis_delta(fr, h.fresh) <= 0.00137046525;
  for (int i = 0; i < 16; ++i) h.fresh[i] = fr[i];
  h.haveFresh = 1;
  if (differs && steady) {
    if (++h.run >= 40) {
      ++h.heals;
      log_line("GUNGRIP re-captured t=%.2fs item %d: the locked hold differed from what the game shows by %.1f cm / axis error %.4f for 40 steady samples, %.1f s after the lock; taken again (%d of 3)",
               qpc_ms() / 1000.0, slot, dp * 30.48, da, (double)(now - h.lockQ) / fq, h.heals);
      handprop::reset(&lk); h.lockQ = 0; h.run = 0; h.haveFresh = 0;
    }
  } else h.run = 0;
}
static volatile LONG g_adCalls, g_adPaired, g_adRight, g_adNoRight, g_adSolved;   // 1.7.77: arm_drive passes: all / replayed from the first eye's targets / with a right-hand target / without / right arm really solved
static long g_gapSnap[12], g_gapAd[5];
// returns 1 when the gun must not be drawn this call. exactGrip: 1 = hand pair ok, 3 = hand rebuilt from the controller (the arms are not drawn), 0 = no hand at all
static int gun_gap_step(int exactGrip) {
  const int64_t now = qpc_now(); const double fq = (double)qpc_freq();
  static int64_t s_lastCallQ;
  if (g_gunGap.startQ && s_lastCallQ && (double)(now - s_lastCallQ) / fq > 0.5) g_gunGap.startQ = 0;   // the gun was not asked for in between (PKE out, holstered, menu): that gap is over
  s_lastCallQ = now;
  if (exactGrip == 1) {
    if (g_gunGap.startQ) {
      const double ms = (double)(now - g_gunGap.startQ) * 1000.0 / fq;
      if (ms > g_gunGap.maxMs) g_gunGap.maxMs = ms;
      if (ms >= 60.0 && g_gunGap.logs < 40) { ++g_gunGap.logs; { long now12[12]; arms_fail_snapshot(now12); log_line("GUNGAP ended t=%.2fs: the gun had no arms/hand for %.0f ms (%ld calls, %ld not drawn, %s) | in that time: arm passes %ld (replayed %ld, with a right-hand target %ld, without %ld, right arm solved %ld) | arm code: calls %ld, right hand moved %ld, ik failed %ld, not finite %ld, no target %ld, bad space %ld, bad length %ld, no model %ld, bad bones %ld, bad layout %ld, skipped (unchanged) %ld, clamped %ld", qpc_ms() / 1000.0, ms, g_gunGap.frames, g_gunGap.hidden, g_gunGap.kind == 3 ? "hand rebuilt from the controller" : "no hand at all",
        (long)g_adCalls - g_gapAd[0], (long)g_adPaired - g_gapAd[1], (long)g_adRight - g_gapAd[2], (long)g_adNoRight - g_gapAd[3], (long)g_adSolved - g_gapAd[4], now12[0] - g_gapSnap[0], now12[1] - g_gapSnap[1], now12[2] - g_gapSnap[2], now12[3] - g_gapSnap[3], now12[4] - g_gapSnap[4], now12[5] - g_gapSnap[5], now12[6] - g_gapSnap[6], now12[7] - g_gapSnap[7], now12[8] - g_gapSnap[8], now12[9] - g_gapSnap[9], now12[10] - g_gapSnap[10], now12[11] - g_gapSnap[11]); } }
      g_gunGap.startQ = 0;
    }
    return 0;
  }
  if (!g_gunGap.startQ) { g_gunGap.startQ = now; g_gunGap.frames = 0; g_gunGap.hidden = 0; g_gunGap.kind = exactGrip; ++g_gunGap.episodes; arms_fail_snapshot(g_gapSnap); g_gapAd[0] = g_adCalls; g_gapAd[1] = g_adPaired; g_gapAd[2] = g_adRight; g_gapAd[3] = g_adNoRight; g_gapAd[4] = g_adSolved; }
  else if (exactGrip == 0) g_gunGap.kind = 0;
  ++g_gunGap.frames;
  const double ms = (double)(now - g_gunGap.startQ) * 1000.0 / fq;
  int hide = 0;
  if (g_ctl.hideGunGap && g_ctl.armIk) hide = (exactGrip == 0) ? (ms < 1500.0) : (ms > 350.0 && ms < 2500.0);
  if (hide) ++g_gunGap.hidden;
  return hide;
}
static int exact_wand_read(uintptr_t actor, float gameM[16], float finalM[16]) {
  for (int tries = 0; tries < 4; ++tries) {
    const LONG s0 = g_exactWand.seq;
    if (s0 & 1) continue;
    const int have = g_exactWand.have;
    const uintptr_t ac = g_exactWand.actor;
    const int64_t q = g_exactWand.q;
    for (int i = 0; i < 16; ++i) { gameM[i] = g_exactWand.gameM[i]; finalM[i] = g_exactWand.finalM[i]; }
    if (g_exactWand.seq != s0) continue;
    if (!have || ac != actor || !q || (double)(qpc_now() - q) / (double)qpc_freq() > 0.20) return 0;
    return handprop::finite16(gameM) && handprop::finite16(finalM);
  }
  return 0;
}
static void holdcheck_line(const char* why, const char* what, const float* org, const float* aim, double slideFt, int fitFwd);
static void holdcheck_timeline(int what, const float* org, const float* aim, double slideFt, int fitFwd);   // what: 0 gun, 1 PKE; logs at fixed seconds after the weapon came into the hand

static volatile LONG g_aimHeldReads;   // 1.7.25: reads answered from the last good aim (see wand_aim_read)
static volatile LONG g_aimLongHolds;   // 1.7.170: the last aim kept up to 1 s, moved with the player
static int wand_aim_read(uintptr_t* actor, float* dir, float* grip, int64_t* q, float* up = nullptr) {
  // 1.7.25: "gun and PKE disappear while walking sometimes": 1832 of 133552 gun placements and 3476 of 7622 PKE placements found no aim (the camera thread was writing it, or the grip was unknown
  // for a moment) and fell back to the game's own spot. The last good aim is kept and used for up to 0.15 s, so a short gap no longer drops the gun.
  static struct { uintptr_t actor; float dir[3], grip[3], up[3]; int64_t q; int ok; int posOk; float apos[3]; double lag; } last;
  int staleHas = 0;   // 1.7.172: the aim is there but 0.15 .. 1 s old
  for (int tries = 0; tries < 3; ++tries) {
    LONG s0 = g_headAim.seq;
    if (s0 & 1) continue;
    uintptr_t ac = g_headAim.actor;
    float d3[3], g3[3], u3[3];
    for (int i = 0; i < 3; ++i) { d3[i] = g_headAim.dir[i]; g3[i] = g_headAim.grip[i]; }
    const int64_t qq = g_headAim.qpc;
    const int has = g_headAim.hasGrip;
    const int hu = g_headAim.hasWup;
    for (int i = 0; i < 3; ++i) u3[i] = hu ? g_headAim.wup[i] : 0.0f;
    if (g_headAim.seq != s0) continue;
    if (has) {
      // 1.7.172 recheck: the player's position is remembered once per NEW sample (it was re-read on every call, so a stale sample was never moved with the player)
      if (qq != last.q || ac != last.actor || !last.ok) {
        last.posOk = 0;
        if (ac && memory_readable((const void*)(ac + layout::kActorPos), 12)) { const float* ap = (const float*)(ac + layout::kActorPos); last.posOk = vm::is_finite_f(ap[0]) && vm::is_finite_f(ap[1]) && vm::is_finite_f(ap[2]); if (last.posOk) { for (int i = 0; i < 3; ++i) last.apos[i] = ap[i]; last.lag = eye_lag_ft(); } }
      }
      for (int i = 0; i < 3; ++i) { last.dir[i] = d3[i]; last.grip[i] = g3[i]; last.up[i] = u3[i]; }
      last.actor = ac; last.q = qq; last.ok = 1;
      const double age = (double)(qpc_now() - qq) / (double)qpc_freq();
      if (!(age > 0.15 && age < 1.0)) {   // fresh (or far too old: the callers' own freshness checks deal with that, as before)
        *actor = ac; *q = qq;
        for (int i = 0; i < 3; ++i) { dir[i] = d3[i]; grip[i] = g3[i]; if (up) up[i] = u3[i]; }
        return 1;
      }
      // 0.15 .. 1 s old (1.7.172: the aim was still there but no longer refreshed - the callers dropped the gun at the game's spot after 250 ms): the long hold below
      staleHas = 1;
    }
    break;
  }
  const double lastAge = last.ok ? (double)(qpc_now() - last.q) / (double)qpc_freq() : 99.0;
  if (last.ok && last.actor && lastAge < 0.15) {
    *actor = last.actor; *q = last.q;
    for (int i = 0; i < 3; ++i) { dir[i] = last.dir[i]; grip[i] = last.grip[i]; if (up) up[i] = last.up[i]; }
    InterlockedIncrement(&g_aimHeldReads);
    return 1;
  }
  // 1.7.170 "watch how bad the floating gets": a longer gap (up to 1 s: weapon wheel, item switch, a tracking blink) dropped the gun / PKE at the game's own spot,
  // floating in the air. The last aim is now kept for up to 1 s, MOVED WITH THE PLAYER (the actor's position), and handed out as fresh.
  if (last.ok && last.actor && lastAge < 1.0) {
    float mv[3] = {0, 0, 0}; int mvOk = 0;
    if (last.posOk && memory_readable((const void*)(last.actor + layout::kActorPos), 12)) {
      const float* ap = (const float*)(last.actor + layout::kActorPos);
      for (int i = 0; i < 3; ++i) mv[i] = ap[i] - last.apos[i];
      mv[1] += (float)(eye_lag_ft() - last.lag);   // 1.7.186: the sample was made at the EYE's height (eased), not the feet's: it moves with the eye, so a step does not fling the held gun / PKE up or down
      if (vm::dabs(eye_lag_ft() - last.lag) > 0.05) InterlockedIncrement(&g_stepAimMoved);
      mvOk = vm::is_finite_f(mv[0]) && vm::is_finite_f(mv[1]) && vm::is_finite_f(mv[2]) && mv[0] * mv[0] + mv[1] * mv[1] + mv[2] * mv[2] < 100.0f;   // under 10 ft moved (more = a cut / teleport: no hold)
    }
    if (mvOk) {
      *actor = last.actor; *q = qpc_now();
      for (int i = 0; i < 3; ++i) { dir[i] = last.dir[i]; grip[i] = last.grip[i] + mv[i]; if (up) up[i] = last.up[i]; }
      InterlockedIncrement(&g_aimLongHolds);
      return 1;
    }
  }
  if (staleHas) {   // the stale aim could not be moved with the player (a cut, the position unreadable): handed out with its real age, as before 1.7.170 (the callers' freshness checks decide)
    *actor = last.actor; *q = last.q;
    for (int i = 0; i < 3; ++i) { dir[i] = last.dir[i]; grip[i] = last.grip[i]; if (up) up[i] = last.up[i]; }
    return 1;
  }
  return 0;
}

// 0.58: what wand::solve gets besides the barrel direction: the controller's up (zero = not known) and the roll fix
static inline const float* wand_up_arg(const float* up) { return (up[0] * up[0] + up[1] * up[1] + up[2] * up[2]) > 0.25f ? up : nullptr; }
static inline double wand_roll_rad() { return (double)g_ctl.wandRollDeg * vm::kPi / 180.0; }

// ---- 1.7.10 the stream's hit point on the barrel line ---------------------------------------------------------------------
// The 1.7.9 video: the stream left the muzzle sideways (about 90 degrees from the barrel, always the same way) while the gun pointed where the hand pointed. The log said why it cannot
// have been the stream's own direction: the game's hit point was 75 degrees off the barrel on average (BEAMSTRAIGHT "bend the game wanted"), and 0.69 only zeroed the two angles the
// game derives from it, not the hit point itself (which also sets the stream's length, its impact glow and what it hits). Without a lock-on target the game takes the hit point from one
// of two reads (layout.h): the virtual +0x168 of the "view" object (the camera's crosshair ray: it follows the frozen game camera, not the gun) or muzzle + aim getter * length.
// Both reads, made by the PLAYER's stream update only, now give a point on the barrel line (muzzle + the gun's aim * the game's own distance).
static struct {
  volatile LONG getHooked, viewHooked;
  volatile LONG getAll, getStream, getHit, getOver, getNoRef;
  volatile LONG viewCalls, viewStream, viewOver, viewBad, viewNoRef;
  volatile LONG getOver10, getOver45, viewOver10, viewOver45;
  volatile LONG getSumX100, getMaxX100, viewSumX100, viewMaxX100;
  volatile LONG lastGetX100, lastViewX100, lastViewLenX100, tipStale, installTries;
  volatile LONG viewRva, viewVtRva;
} g_sfix;
static struct { volatile LONG n, sumX100, maxX100, over10, over30, over60, lastX100, logged; } g_gp;   // 1.7.13: the game's barrel against the controller's aim
static volatile float g_sfixTip[3], g_sfixDir[3];   // the stream's muzzle and aim of the player's latest stream update (set by hk_attach_matrix, read by the two hooks below)
static volatile LONGLONG g_sfixQ;
static int sfix_ref(float* tip, float* dir) {
  const LONGLONG q = g_sfixQ;
  if (!q || !aim::is_fresh(qpc_now(), q, qpc_freq(), 120)) { InterlockedIncrement(&g_sfix.tipStale); return 0; }
  for (int i = 0; i < 3; ++i) { tip[i] = g_sfixTip[i]; dir[i] = g_sfixDir[i]; }
  const double l = vm::dsqrt((double)dir[0] * dir[0] + (double)dir[1] * dir[1] + (double)dir[2] * dir[2]);
  if (!(l > 0.5) || !(l < 2.0)) return 0;
  for (int i = 0; i < 3; ++i) { dir[i] = (float)(dir[i] / l); if (!vm::is_finite_f(dir[i]) || !vm::is_finite_f(tip[i])) return 0; }
  return 1;
}
// ---- 1.7.21 the game's aim read follows the gun at EVERY read (aim_live) ------------------------------------------------------------------------
// The 1.7.20 log (HEADAIM): the game writes its aim store (player+0xB584) 11368 times but only 3210 of those writes are the player's (the rest are other actors), and the probe replaced the
// player's store only when the game wrote it. In between, the getter handed out an OLD hand direction: the game's own aim read in the player's stream update was 39.8 degrees off the
// barrel on average (STREAMAIM, "put on the barrel 0"). That stale aim is what the capture / slam code (processWrangling calls the getter twice) and the lock choice measure the ghost against,
// so the capture stream "always missed". Now every read of the PLAYER's aim returns the live hand aim (the same vector the store gets).
static struct { volatile LONG on, calls, replaced, stale, notPlayer, over10, over45, sumX100, maxX100; struct { volatile LONG rva, n, over10, sumX100; } by[24]; volatile LONG byFull; } g_alive;
static int live_aim(const void* actor, float* v) {
  if (!g_ctl.aimLive || g_ctl.headAim != 2 || !g_ctl.stereoActive || !actor) return 0;
  uintptr_t a = 0; float d[3] = {0, 0, 0}, ad[3] = {0, 0, 0}; int64_t q = 0; int ok = 0;
  for (int tries = 0; tries < 3 && !ok; ++tries) {
    LONG s0 = g_headAim.seq;
    if (s0 & 1) continue;
    a = g_headAim.actor;
    for (int i = 0; i < 3; ++i) { d[i] = g_headAim.dir[i]; ad[i] = g_headAim.adir[i]; }
    q = g_headAim.qpc;
    ok = g_headAim.seq == s0;
  }
  if (!ok || !a) return 0;
  if ((uintptr_t)actor != a) { InterlockedIncrement(&g_alive.notPlayer); return 0; }
  if (!aim::is_fresh(qpc_now(), q, qpc_freq(), 250)) { InterlockedIncrement(&g_alive.stale); return 0; }
  const float* use = (vm::is_finite_f(ad[0]) && vm::is_finite_f(ad[1]) && vm::is_finite_f(ad[2])) ? ad : d;
  if (!vm::is_finite_f(use[0]) || !vm::is_finite_f(use[1]) || !vm::is_finite_f(use[2])) return 0;
  v[0] = use[0]; v[1] = use[1]; v[2] = use[2];
  return 1;
}
typedef void*(__fastcall* PFN_AimGetter)(void* actor, float* out);
static PFN_AimGetter o_aimGetter;
static GBVR_NOINLINE void* __fastcall hk_aim_getter(void* actor, float* out) {
  void* ret = GBVR_RETURN_ADDRESS();
  void* r = o_aimGetter(actor, out);
  InterlockedIncrement(&g_sfix.getAll);
  const uintptr_t rr = (uintptr_t)ret - g_game.base;
  const int hitRead = rr == layout::kRvaStreamHitAimRet;
  if ((hitRead || rr == layout::kRvaAimStreamRead + 5) && out && g_streamTipTid && g_streamTipTid == (LONG)GetCurrentThreadId() && memory_readable(out, 12)) {
    InterlockedIncrement(&g_sfix.getStream);
    if (hitRead) InterlockedIncrement(&g_sfix.getHit);
    float tip[3], dir[3];
    if (sfix_ref(tip, dir) && vm::is_finite_f(out[0]) && vm::is_finite_f(out[1]) && vm::is_finite_f(out[2])) {
      const double deg = aim::angle_deg(out, dir);
      const LONG x100 = (LONG)(deg * 100.0);
      g_sfix.lastGetX100 = x100;
      InterlockedExchangeAdd(&g_sfix.getSumX100, x100 > 100000 ? 100000 : x100);
      if (x100 > g_sfix.getMaxX100) g_sfix.getMaxX100 = x100;
      if (deg > 10.0) InterlockedIncrement(&g_sfix.getOver10);
      if (deg > 45.0) InterlockedIncrement(&g_sfix.getOver45);
      if (hitRead && g_ctl.streamAimGun && g_ctl.headAim == 2 && g_ctl.stereoActive) {
        out[0] = dir[0]; out[1] = dir[1]; out[2] = dir[2];
        InterlockedIncrement(&g_sfix.getOver);
      }
    } else InterlockedIncrement(&g_sfix.getNoRef);
  }
  {   // 1.7.21 aim_live: every read of the player's aim gets the live hand aim (the stream's hit read above already has the barrel line)
    InterlockedIncrement(&g_alive.calls);
    if (!hitRead && out && memory_readable(out, 12)) {
      float v[3];
      if (live_aim(actor, v)) {
        double deg = 0.0;
        if (vm::is_finite_f(out[0]) && vm::is_finite_f(out[1]) && vm::is_finite_f(out[2])) deg = aim::angle_deg(out, v);
        const LONG x100 = (LONG)(deg * 100.0);
        InterlockedIncrement(&g_alive.replaced);
        InterlockedExchangeAdd(&g_alive.sumX100, x100 > 100000 ? 100000 : x100);
        if (x100 > g_alive.maxX100) g_alive.maxX100 = x100;
        if (deg > 10.0) InterlockedIncrement(&g_alive.over10);
        if (deg > 45.0) InterlockedIncrement(&g_alive.over45);
        int k = -1;
        for (int i = 0; i < 24; ++i) { if (g_alive.by[i].rva == (LONG)rr) { k = i; break; } if (!g_alive.by[i].rva) { if (InterlockedCompareExchange(&g_alive.by[i].rva, (LONG)rr, 0) == 0 || g_alive.by[i].rva == (LONG)rr) { k = i; break; } } }
        if (k >= 0) { InterlockedIncrement(&g_alive.by[k].n); if (deg > 10.0) InterlockedIncrement(&g_alive.by[k].over10); InterlockedExchangeAdd(&g_alive.by[k].sumX100, x100 > 100000 ? 100000 : x100); }
        else InterlockedIncrement(&g_alive.byFull);
        out[0] = v[0]; out[1] = v[1]; out[2] = v[2];
      }
    }
  }
  return r;
}
typedef float*(__fastcall* PFN_ViewHit)(void* self, float* tmp);
static PFN_ViewHit o_viewHit;
static float g_sfixHitBuf[4];
static GBVR_NOINLINE float* __fastcall hk_view_hit(void* self, float* tmp) {
  void* ret = GBVR_RETURN_ADDRESS();
  float* r = o_viewHit(self, tmp);
  InterlockedIncrement(&g_sfix.viewCalls);
  if ((uintptr_t)ret == rva(layout::kRvaStreamViewHitRet) && r && g_streamTipTid && g_streamTipTid == (LONG)GetCurrentThreadId()) {
    InterlockedIncrement(&g_sfix.viewStream);
    if (g_ctl.lockGhostOnly && g_headAim.actor && !pke_item_held()) fight_lock_guard((uintptr_t)g_headAim.actor);   // 1.7.19: once more right where the stream decides what its crosshair hit is
    float tip[3], dir[3];
    if (!memory_readable(r, 12) || !vm::is_finite_f(r[0]) || !vm::is_finite_f(r[1]) || !vm::is_finite_f(r[2])) { InterlockedIncrement(&g_sfix.viewBad); return r; }
    if (!sfix_ref(tip, dir)) { InterlockedIncrement(&g_sfix.viewNoRef); return r; }
    const double dx = (double)r[0] - tip[0], dy = (double)r[1] - tip[1], dz = (double)r[2] - tip[2];
    const double len = vm::dsqrt(dx * dx + dy * dy + dz * dz);
    if (!(len > 0.05) || !(len < 5000.0)) { InterlockedIncrement(&g_sfix.viewBad); return r; }
    const float to[3] = {(float)(dx / len), (float)(dy / len), (float)(dz / len)};
    const double deg = aim::angle_deg(to, dir);
    const LONG x100 = (LONG)(deg * 100.0);
    g_sfix.lastViewX100 = x100; g_sfix.lastViewLenX100 = (LONG)(len * 100.0);
    InterlockedExchangeAdd(&g_sfix.viewSumX100, x100 > 100000 ? 100000 : x100);
    if (x100 > g_sfix.viewMaxX100) g_sfix.viewMaxX100 = x100;
    if (deg > 10.0) InterlockedIncrement(&g_sfix.viewOver10);
    if (deg > 45.0) InterlockedIncrement(&g_sfix.viewOver45);
    if (g_ctl.streamAimGun && g_ctl.headAim == 2 && g_ctl.stereoActive) {
      const double use = len < 1.0 ? 1.0 : (len > 200.0 ? 200.0 : len);
      for (int i = 0; i < 3; ++i) g_sfixHitBuf[i] = (float)(tip[i] + (double)dir[i] * use);
      g_sfixHitBuf[3] = 0.0f;
      InterlockedIncrement(&g_sfix.viewOver);
      return g_sfixHitBuf;
    }
  }
  return r;
}
static void install_stream_aim_hook() {
  if (!bytes_match(layout::kRvaAimGetter, layout::kBytesAimGetter, 16)) { g_sfix.getHooked = -1; log_line("STREAMAIM the game's aim getter differs from the expected bytes: its reads in the stream update stay as they are"); return; }
  const uint8_t* p = (const uint8_t*)rva(layout::kRvaStreamHitAimCall);
  if (p[0] != 0xe8 || (uintptr_t)(p + 5 + *(const int32_t*)(p + 1)) != rva(layout::kRvaAimGetter) || (uintptr_t)(p + 5) != rva(layout::kRvaStreamHitAimRet)) { g_sfix.getHooked = -2; log_line("STREAMAIM the stream update's aim read is not where it was expected: stays as it is"); return; }
  void* t = (void*)rva(layout::kRvaAimGetter);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_aim_getter, (void**)&o_aimGetter);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_sfix.getHooked = s == MH_OK ? 1 : -3;
  log_line("HOOK aim-getter %x status=%d (1.7.10: the stream's aim read follows the gun)", layout::kRvaAimGetter, (int)s);
}
// the "view" object's virtual function is found at run time (the object hangs off the player), the first time the player's stream update asks for the tip
static void sfix_try_view_hook(uintptr_t actor) {
  if (g_sfix.viewHooked != 0 || g_sfix.installTries > 2000) return;
  ++g_sfix.installTries;
  const uint8_t* ab = (const uint8_t*)actor;
  if (!memory_readable(ab + layout::kOffStreamView, 8)) return;
  const uintptr_t obj = *(const uintptr_t*)(ab + layout::kOffStreamView);
  if (!obj || !memory_readable((const void*)obj, 8)) return;
  const uintptr_t vt = *(const uintptr_t*)obj;
  if (!vt || !memory_readable((const void*)(vt + layout::kOffViewHitSlot), 8)) return;
  const uintptr_t fn = *(const uintptr_t*)(vt + layout::kOffViewHitSlot);
  if (fn < g_game.base || fn >= g_game.base + g_game.sizeOfImage) { g_sfix.viewHooked = -1; log_line("STREAMAIM the view object's hit function %p is outside the game: not hooked", (void*)fn); return; }
  const uint8_t* cs = (const uint8_t*)rva(layout::kRvaStreamViewHitCall);
  if (!(cs[0] == 0xff && cs[1] == 0x90 && *(const int32_t*)(cs + 2) == (int32_t)layout::kOffViewHitSlot && (uintptr_t)(cs + 6) == rva(layout::kRvaStreamViewHitRet))) {
    g_sfix.viewHooked = -2; log_line("STREAMAIM the stream update's call of the view object's hit function is not where it was expected: stays as it is"); return;
  }
  MH_STATUS s = MH_CreateHook((void*)fn, (void*)hk_view_hit, (void**)&o_viewHit);
  if (s == MH_OK) s = MH_EnableHook((void*)fn);
  g_sfix.viewHooked = s == MH_OK ? 1 : -3;
  g_sfix.viewRva = (LONG)(fn - g_game.base); g_sfix.viewVtRva = (LONG)(vt - g_game.base);
  log_line("HOOK view-hit-point fn=ghost.exe+%x (virtual +%x of the object at actor+%x, vtable ghost.exe+%x) status=%d (1.7.10: the stream's crosshair hit point follows the gun)",
           (unsigned)g_sfix.viewRva, (unsigned)layout::kOffViewHitSlot, (unsigned)layout::kOffStreamView, (unsigned)g_sfix.viewVtRva, (int)s);
}
static void sfix_report(LONG frame) {
  log_line("GAMEPLACE frame=%d on=%d | the game's own barrel vs where your controller points (stream updates sampled %d): mean %.1f deg, max %.1f, over 10 deg %d, over 30 deg %d, over 60 deg %d, last %.1f | tip matrices taken from the game %d (1.7.13: the game places the gun and the PKE; no wand move, no tip override, no arm target, no finger curl)",
           (int)frame, (int)g_ctl.gamePlace, (int)g_gp.n, g_gp.n ? (double)g_gp.sumX100 / 100.0 / (double)g_gp.n : 0.0, (double)g_gp.maxX100 / 100.0, (int)g_gp.over10, (int)g_gp.over30, (int)g_gp.over60, (double)g_gp.lastX100 / 100.0, (int)g_tipSt.gameTip);
  const LONG gs = g_sfix.getStream, vs = g_sfix.viewStream;
  log_line("STREAMAIM frame=%d on=%d aimGetterHook=%d viewHook=%d (fn ghost.exe+%x) | the game's own aim read in the player's stream update: %d reads (%d for the hit point), mean %.1f deg off the barrel, max %.1f, over 10 deg %d, over 45 deg %d, put on the barrel %d, no reference %d | "
           "the game's crosshair hit point: %d calls (%d from the player's stream update), mean %.1f deg off the barrel, max %.1f, over 10 deg %d, over 45 deg %d, put on the barrel %d, bad %d, no reference %d | last: aim read %.1f deg, hit point %.1f deg at %.1f ft | tip reference stale %d",
           (int)frame, (int)g_ctl.streamAimGun, (int)g_sfix.getHooked, (int)g_sfix.viewHooked, (unsigned)g_sfix.viewRva, (int)gs, (int)g_sfix.getHit,
           gs ? (double)g_sfix.getSumX100 / 100.0 / (double)gs : 0.0, (double)g_sfix.getMaxX100 / 100.0, (int)g_sfix.getOver10, (int)g_sfix.getOver45, (int)g_sfix.getOver, (int)g_sfix.getNoRef,
           (int)g_sfix.viewCalls, (int)vs, vs ? (double)g_sfix.viewSumX100 / 100.0 / (double)vs : 0.0, (double)g_sfix.viewMaxX100 / 100.0, (int)g_sfix.viewOver10, (int)g_sfix.viewOver45, (int)g_sfix.viewOver, (int)g_sfix.viewBad, (int)g_sfix.viewNoRef,
           (double)g_sfix.lastGetX100 / 100.0, (double)g_sfix.lastViewX100 / 100.0, (double)g_sfix.lastViewLenX100 / 100.0, (int)g_sfix.tipStale);
  {   // 1.7.21 aim_live: how far the game's stored aim was from the live hand aim at each read, and which code reads it
    log_line("AIMLIVE frame=%d on=%d | reads of the aim getter %d | player's reads given the live hand aim %d (the stored aim was %.1f deg off on average, max %.1f; over 10 deg %d, over 45 deg %d), other actors %d, hand aim too old %d, caller table full %d",
             (int)frame, (int)g_ctl.aimLive, (int)g_alive.calls, (int)g_alive.replaced, g_alive.replaced ? (double)g_alive.sumX100 / 100.0 / (double)g_alive.replaced : 0.0, (double)g_alive.maxX100 / 100.0,
             (int)g_alive.over10, (int)g_alive.over45, (int)g_alive.notPlayer, (int)g_alive.stale, (int)g_alive.byFull);
    char cb[900]; int cl = 0; cb[0] = 0;
    for (int i = 0; i < 24 && g_alive.by[i].rva && cl < 800; ++i)
      cl += log_fmt(cb + cl, (int)sizeof(cb) - cl, " [%x: %d reads, mean %.0f deg, >10deg %d]", (unsigned)g_alive.by[i].rva, (int)g_alive.by[i].n, g_alive.by[i].n ? (double)g_alive.by[i].sumX100 / 100.0 / (double)g_alive.by[i].n : 0.0, (int)g_alive.by[i].over10);
    log_line("AIMLIVE callers (return address in the game, reads):%s", cl ? cb : " none yet");
  }
}


static int exact_wand_read(uintptr_t actor, float gameM[16], float finalM[16]);
// ---- 1.7.72 the slime blower, read from ghost.exe (layout.h kRvaTetherFire) -------------------------------------------------------------------------------------------
// 1.7.71 changed nothing: the slime gun does not ask the player for attachments at all. It is its own entity (CGadgetTether). Its fire logic takes the stream's start from its
// own attachment "slime" (entity attach 0x2C1E40) - where the game holds the gun, beside you - and its end from the game's view (camera + its angles: where your HEAD looks).
// Now, only while the player's slime blower fires (0xAB320):
//   - the "slime" attachment is carried from the game's gun to the gun in your hand (the same exact move as the gun model and the proton tip),
//   - the game view pointer (player+0xB550) is hidden, so the game takes the other path it has: start + the player's aim (the live hand aim, AIMLIVE) times the range,
//     the same way the proton stream is handled since 1.7.27. It is put back right after.
typedef void(__fastcall* PFN_TetherFire)(void* self);   // rcx only (0xAADFF: mov rcx,rbx; call)
static PFN_TetherFire o_tetherFire;
static volatile uintptr_t g_slimeTether;   // the player's tether (seen in its fire logic); its "slime" attachment is always carried while you own it
static struct { volatile LONG hooked, calls, mine, hudHidden, hudBack, hudChanged, carried, noPair, offGun, selfHits, stateLogs; int64_t logQ; volatile LONG logs; double lastCm; int lastMode; uintptr_t lastHit, lastE1, lastE2; float lastStart[3]; } g_tf;
// ---- 1.7.75 "the slime tether breaks on impact": the tether ENTITY is placed at the gun in your hand -------------------------------------------------------------
// 1.7.72-1.7.74 moved only its "slime" attachment reads. The entity itself (and so the rope's gun end, its physics, sounds, anything that reads the entity) stayed
// at the game's gun spot beside you, 30-140 cm from the gun you see, so the two ends of the same rope disagreed and it snapped. Now the game's own placement of the
// tether (SetTransform from the player update, 0xD5C97) is carried from the game's gun to the gun in your hand before it is stored; every read then agrees, and the
// attachment reads are left alone (they already come out at the hand).
typedef void*(__fastcall* PFN_SetXform)(void* self, const float* pos, const float* rot);
static PFN_SetXform o_setXform;
static struct { volatile LONG hooked, moved, noPair, offGun; int64_t q; double lastCm; } g_tx;
static int exact_wand_read(uintptr_t actor, float gameM[16], float finalM[16]);
static void* __fastcall hk_set_xform(void* self, const float* pos, const float* rot) {
  if ((uintptr_t)GBVR_RETURN_ADDRESS() != rva(layout::kRvaTetherPlaceRet) || !g_ctl.slimeMuzzle || !g_ctl.stereoActive || !pos || !rot) return o_setXform(self, pos, rot);
  const uintptr_t owner = g_headAim.actor;
  if (!owner || !memory_readable((const void*)(owner + layout::kOffPlayerTether), 8) || *(const uintptr_t*)(owner + layout::kOffPlayerTether) != (uintptr_t)self) return o_setXform(self, pos, rot);
  { int st8[8], cur = -1; if (!fight_items(st8, &cur) || cur != 7) return o_setXform(self, pos, rot); }   // only while the slime blower is the item in your hand
  float gp[16], fp[16], M[16], out[16];
  if (!exact_wand_read(owner, gp, fp)) { InterlockedIncrement(&g_tx.noPair); return o_setXform(self, pos, rot); }
  {   const float* W = (const float*)(owner + layout::kOffWandWorld);
      if (memory_readable(W, 64) && handprop::finite16(W)) for (int i = 0; i < 16; ++i) gp[i] = W[i]; }
  handprop::ident(M);
  for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) M[j * 4 + i] = rot[3 * i + j];   // the entity layout s[3*i+j] = M[j*4+i]
  for (int i = 0; i < 3; ++i) M[12 + i] = pos[i];
  if (!handprop::finite16(M) || handprop::rel_pos_delta(M, gp) > 6.0 || !handprop::map_part(M, gp, fp, out)) { InterlockedIncrement(&g_tx.offGun); return o_setXform(self, pos, rot); }
  float P[3], R[9];
  for (int i = 0; i < 3; ++i) P[i] = out[12 + i];
  for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) R[3 * i + j] = out[j * 4 + i];
  g_tx.lastCm = handprop::rel_pos_delta(M, out) * 30.48;
  g_tx.q = qpc_now(); InterlockedIncrement(&g_tx.moved);
  return o_setXform(self, P, R);
}
static void install_set_xform_hook() {
  if (!bytes_match(layout::kRvaSetTransform, layout::kBytesSetTransform, 16)) { g_tx.hooked = -1; log_line("SLIMEFIX the tether placement is not available: SetTransform bytes differ"); return; }
  void* t = (void*)rva(layout::kRvaSetTransform);
  MH_STATUS st = MH_CreateHook(t, (void*)hk_set_xform, (void**)&o_setXform);
  if (st == MH_OK) st = MH_EnableHook(t);
  g_tx.hooked = st == MH_OK ? 1 : -2;
  log_line("HOOK slime blower placement %x status=%d (1.7.75: the whole slime blower, rope end included, sits at the gun in your hand)", layout::kRvaSetTransform, (int)st);
}
static int tether_carry(void* self, float* out) {
  if (g_tx.q && (double)(qpc_now() - g_tx.q) / (double)qpc_freq() < 0.25) return 0;   // 1.7.75: the entity is already at the hand: its attachments are too
  const uintptr_t owner = memory_readable((const uint8_t*)self + layout::kOffTetherOwner, 8) ? *(const uintptr_t*)((const uint8_t*)self + layout::kOffTetherOwner) : 0;
  if (!owner || owner != g_headAim.actor || !g_ctl.slimeMuzzle || !g_ctl.stereoActive || !memory_readable(out, 64) || !handprop::finite16(out)) return 0;
  float gp[16], fp[16], mapped[16];
  if (!exact_wand_read(owner, gp, fp)) { InterlockedIncrement(&g_tf.noPair); return 0; }
  {   // the game's gun as it is NOW (the player update just placed it); the hand gun from the last frame
    const float* W = (const float*)(owner + layout::kOffWandWorld);
    if (memory_readable(W, 64) && handprop::finite16(W)) for (int i = 0; i < 16; ++i) gp[i] = W[i];
  }
  if (handprop::rel_pos_delta(out, gp) > 6.0) { InterlockedIncrement(&g_tf.offGun); return 0; }   // not on the game's gun: left alone
  if (!handprop::map_part(out, gp, fp, mapped)) return 0;
  g_tf.lastCm = handprop::rel_pos_delta(out, mapped) * 30.48;
  for (int i = 0; i < 16; ++i) out[i] = mapped[i];
  for (int i = 0; i < 3; ++i) g_tf.lastStart[i] = mapped[12 + i];
  InterlockedIncrement(&g_tf.carried);
  return 1;
}
static void __fastcall hk_tether_fire(void* self) {
  InterlockedIncrement(&g_tf.calls);
  const uintptr_t owner = self && memory_readable((const uint8_t*)self + layout::kOffTetherOwner, 8) ? *(const uintptr_t*)((const uint8_t*)self + layout::kOffTetherOwner) : 0;
  if (!g_ctl.slimeMuzzle || !g_ctl.stereoActive || !owner || owner != g_headAim.actor) { o_tetherFire(self); return; }
  InterlockedIncrement(&g_tf.mine);
  uintptr_t* hud = (uintptr_t*)(owner + layout::kOffPlayerHud); uintptr_t saved = 0;
  if (memory_readable(hud, 8)) { saved = *hud; if (saved) { *hud = 0; InterlockedIncrement(&g_tf.hudHidden); } }
  g_slimeTether = (uintptr_t)self;   // kept: every "slime" attachment of this tether is carried (fire logic, stream emitter, its draw), not only inside the fire logic
  o_tetherFire(self);
  if (saved) { if (*hud == 0) { *hud = saved; InterlockedIncrement(&g_tf.hudBack); } else InterlockedIncrement(&g_tf.hudChanged); }
  {   // 1.7.74 data: what the slime tether did this update (mode, what its ray hit, its two end points) - logged when it changes
    const uint8_t* T = (const uint8_t*)self;
    if (memory_readable(T + 0x4B8, 4) && memory_readable(T + 0x500, 0xB0)) {
      const int mode = *(const int*)(T + 0x4B8);
      const uintptr_t hit = *(const uintptr_t*)(T + 0x500), e1 = *(const uintptr_t*)(T + 0x598), e2 = *(const uintptr_t*)(T + 0x5A0);
      const float* hp = (const float*)(T + 0x520);
      if (hit == owner) InterlockedIncrement(&g_tf.selfHits);
      if ((mode != g_tf.lastMode || e1 != g_tf.lastE1 || e2 != g_tf.lastE2) && InterlockedIncrement(&g_tf.stateLogs) <= 80) {
        uintptr_t vt = hit && memory_readable((const void*)hit, 8) ? *(const uintptr_t*)hit : 0;
        log_line("SLIMETETHER t=%.2fs mode %d | ray hit %p (class vtable +%x%s) at %.1f,%.1f,%.1f ft | end points %p %p | left trigger presses %ld, two-hand flips %ld",
                 qpc_ms() / 1000.0, mode, (void*)hit, vt ? (unsigned)(vt - g_game.base) : 0u, hit == owner ? " = YOU: the ray hit your own body" : "", (double)hp[0], (double)hp[1], (double)hp[2], (void*)e1, (void*)e2,
                 g_slimeLtEdges, g_twoFlips);
      }
      g_tf.lastMode = mode; g_tf.lastHit = hit; g_tf.lastE1 = e1; g_tf.lastE2 = e2;
    }
  }
  const int64_t q = qpc_now();
  if ((!g_tf.logQ || (double)(q - g_tf.logQ) / (double)qpc_freq() >= 15.0) && InterlockedIncrement(&g_tf.logs) <= 60) {
    if (g_tf.logQ) log_line("SLIMEFIX t=%.1fs on=%d hook=%d | slime blower updates %ld (yours %ld) | its \"slime\" start carried to the gun in your hand %ld times (last move %.0f cm), no hand-gun pose %ld, not on the gun %ld | game view hidden %ld, put back %ld, changed meanwhile %ld | its ray hit your own body %ld times | 1.7.75 placement: hook %d, moved to the hand %ld (last %.0f cm), no hand-gun pose %ld, not on the gun %ld",
                        qpc_ms() / 1000.0, (int)g_ctl.slimeMuzzle, (int)g_tf.hooked, (long)g_tf.calls, (long)g_tf.mine, (long)g_tf.carried, g_tf.lastCm, (long)g_tf.noPair, (long)g_tf.offGun, (long)g_tf.hudHidden, (long)g_tf.hudBack, (long)g_tf.hudChanged, (long)g_tf.selfHits, (int)g_tx.hooked, (long)g_tx.moved, g_tx.lastCm, (long)g_tx.noPair, (long)g_tx.offGun);
    g_tf.logQ = q;
  }
}
static void install_tether_hook() {
  if (!bytes_match(layout::kRvaTetherFire, layout::kBytesTetherFire, 16)) { g_tf.hooked = -1; log_line("SLIMEFIX not available: the slime blower's bytes differ in this game build"); return; }
  void* t = (void*)rva(layout::kRvaTetherFire);
  MH_STATUS st = MH_CreateHook(t, (void*)hk_tether_fire, (void**)&o_tetherFire);
  if (st == MH_OK) st = MH_EnableHook(t);
  g_tf.hooked = st == MH_OK ? 1 : -2;
  log_line("HOOK slime blower %x status=%d (1.7.72: the slime starts at the gun in your hand and goes where it points)", layout::kRvaTetherFire, (int)st);
}
// ---- 1.7.76 the slime rope: ONE rope step per squeeze --------------------------------------------------------------------------------------------------------------
// ghost.exe (layout.h kRvaTetherRopeStep): the player update calls AAF40(tether, 0) every frame the alt-fire flag is set.  Each call puts the ray's hit into a free one of the rope
// manager's two anchor slots; a hit on an entity that already holds a slot lets the old rope go and stores the hit again.  The left trigger keeps the flag set for several frames
// (and the game's own 0.25 s latch), so ONE squeeze filled BOTH slots with the same thing: a rope from the bridge to the bridge, complete at once, never pulling anything.
// Now: the first step of a squeeze that really anchors something is the only one let through; the rest of that squeeze returns "nothing happened" (0.0, what the game's own
// no-attach path returns).  A squeeze that has not anchored anything yet (nothing in the sights) keeps trying.  A hit on the entity that already holds the first anchor is skipped.
typedef float(__fastcall* PFN_RopeStep)(void* self, unsigned char reset);
static PFN_RopeStep o_ropeStep;
static struct { volatile LONG hooked, calls, passed, gated, sameSkip, anchored, completed, squeezes, logs; int64_t lastCall; long edgeUsed; int done; int slotsBefore; } g_rope;
static int rope_slots(const uint8_t* T, uintptr_t ent[2], int occ[2], uintptr_t* mgrOut) {
  ent[0] = ent[1] = 0; occ[0] = occ[1] = 0; if (mgrOut) *mgrOut = 0;
  if (!memory_readable(T + layout::kOffTetherRopeMgr, 8)) return 0;
  const uintptr_t mgr = *(const uintptr_t*)(T + layout::kOffTetherRopeMgr);
  if (mgrOut) *mgrOut = mgr;
  if (!mgr || !memory_readable((const void*)(mgr + layout::kOffRopeSlots), layout::kRopeSlotStride * 2)) return 0;
  for (int i = 0; i < 2; ++i) {
    const uint8_t* S = (const uint8_t*)(mgr + layout::kOffRopeSlots + (size_t)i * layout::kRopeSlotStride);
    ent[i] = *(const uintptr_t*)S;
    const float* p = (const float*)(S + 8);
    occ[i] = ent[i] != 0 || p[0] != 0.0f || p[1] != 0.0f || p[2] != 0.0f;
  }
  return 1;
}
static float __fastcall hk_rope_step(void* self, unsigned char reset) {
  const uint8_t* T = (const uint8_t*)self;
  const uintptr_t owner = self && memory_readable(T + layout::kOffTetherOwner, 8) ? *(const uintptr_t*)(T + layout::kOffTetherOwner) : 0;
  if (reset || !owner || owner != g_headAim.actor || !g_ctl.slimeRopeFix || !g_ctl.stereoActive || !memory_readable(T + layout::kOffTetherHitEntity, 0x20)) return o_ropeStep(self, reset);
  InterlockedIncrement(&g_rope.calls);
  const int64_t now = qpc_now();
  const double gap = g_rope.lastCall ? (double)(now - g_rope.lastCall) / (double)qpc_freq() : 99.0;
  g_rope.lastCall = now;
  const long edges = g_slimeLtEdges;
  const int newSqueeze = gap > 0.12 || edges != g_rope.edgeUsed;
  if (newSqueeze) { g_rope.edgeUsed = edges; g_rope.done = 0; InterlockedIncrement(&g_rope.squeezes); }
  uintptr_t ent0[2], mgr0; int occ0[2];
  rope_slots(T, ent0, occ0, &mgr0);
  const uintptr_t hit = *(const uintptr_t*)(T + layout::kOffTetherHitEntity);
  const int mode = memory_readable(T + layout::kOffTetherMode, 4) ? *(const int*)(T + layout::kOffTetherMode) : -1;
  const char* why = "passed";
  if (g_rope.done && !newSqueeze) { InterlockedIncrement(&g_rope.gated); return 0.0f; }
  if (hit && ((ent0[0] && ent0[0] == hit) || (ent0[1] && ent0[1] == hit))) {   // the same thing twice would be a rope from it to itself
    g_rope.done = 1; InterlockedIncrement(&g_rope.sameSkip); why = "SKIPPED (the sights are on the thing that already holds an anchor)";
    if (InterlockedIncrement(&g_rope.logs) <= 120) log_line("SLIMEROPE t=%.2fs squeeze #%ld %s | mode %d | hit %p | anchors before %p%s %p%s", qpc_ms() / 1000.0, (long)g_rope.squeezes, why, mode, (void*)hit, (void*)ent0[0], occ0[0] ? "" : "(free)", (void*)ent0[1], occ0[1] ? "" : "(free)");
    return 0.0f;
  }
  const float r = o_ropeStep(self, reset);
  InterlockedIncrement(&g_rope.passed);
  uintptr_t ent1[2], mgr1; int occ1[2];
  rope_slots(T, ent1, occ1, &mgr1);
  const int before = occ0[0] + occ0[1], after = occ1[0] + occ1[1];
  const int completed = mgr0 && !mgr1;   // both anchors set: the game let the manager go and the tether went to its next mode
  if (completed) { InterlockedIncrement(&g_rope.completed); g_rope.done = 1; why = "ROPE COMPLETE (both anchors set, manager let go)"; }
  else if (after > before) { InterlockedIncrement(&g_rope.anchored); g_rope.done = 1; why = "ANCHOR SET"; }
  else why = "no anchor (nothing hit yet)";
  const int worth = completed || after > before || newSqueeze;
  if (worth && InterlockedIncrement(&g_rope.logs) <= 120) {
    uintptr_t vt = hit && memory_readable((const void*)hit, 8) ? *(const uintptr_t*)hit : 0;
    const float* hp = (const float*)(T + 0x520);
    log_line("SLIMEROPE t=%.2fs squeeze #%ld %s | gap %.0f ms | mode %d -> %d | hit %p (class +%x) | anchors before %p %p after %p %p | manager %p -> %p | step returned %.2f",
             qpc_ms() / 1000.0, (long)g_rope.squeezes, why, gap * 1000.0, mode, memory_readable(T + layout::kOffTetherMode, 4) ? *(const int*)(T + layout::kOffTetherMode) : -1, (void*)hit, vt ? (unsigned)(vt - g_game.base) : 0u,
             (void*)ent0[0], (void*)ent0[1], (void*)ent1[0], (void*)ent1[1], (void*)mgr0, (void*)mgr1, (double)r);
    (void)hp;
  }
  return r;
}
static void install_rope_hook() {
  if (!bytes_match(layout::kRvaTetherRopeStep, layout::kBytesTetherRopeStep, 16)) { g_rope.hooked = -1; log_line("SLIMEROPE not available: the rope step's bytes differ in this game build"); return; }
  void* t = (void*)rva(layout::kRvaTetherRopeStep);
  MH_STATUS st = MH_CreateHook(t, (void*)hk_rope_step, (void**)&o_ropeStep);
  if (st == MH_OK) st = MH_EnableHook(t);
  g_rope.hooked = st == MH_OK ? 1 : -2;
  log_line("HOOK slime rope %x status=%d (1.7.76: one rope step per squeeze, so the two anchors are two different squeezes)", layout::kRvaTetherRopeStep, (int)st);
}
static struct { char name[32]; LONG count; float pos[3]; } g_attach[32];
static int g_attachN;

static double acos_c(double c) { if (c > 1.0) c = 1.0; if (c < -1.0) c = -1.0; return vm::datan2(vm::dsqrt(1.0 - c * c), c); }
// 1.7.169 "on the Stay Puft rooftop the gun does not shoot straight": the 1.7.165 video shows the stream leaving the muzzle sideways along a forced start
// direction, then kinking toward Stay Puft. On the rooftop station the stream is no longer forced along the controller's aim (station_beam_free=1): it leaves
// toward where the game sends it. STATIONAIM measures what the old forcing would have done: the angle between the drawn gun's barrel, the aim the mod
// had, and the game's own stream direction; and how often the muzzle came from the drawn gun.
static void station_aim_note(const float* gameTip, const float* dir, int exactTip) {
  InterlockedIncrement(&g_stAim.n); if (exactTip) InterlockedIncrement(&g_stAim.exact);
  double dl = vm::dsqrt((double)dir[0] * dir[0] + (double)dir[1] * dir[1] + (double)dir[2] * dir[2]);
  if (dl > 1e-6) {
    // the game's own stream direction: the game tip's row 2 (its barrel line)
    double g[3] = {gameTip[8], gameTip[9], gameTip[10]}; double gl = vm::dsqrt(g[0] * g[0] + g[1] * g[1] + g[2] * g[2]);
    if (gl > 1e-6) { const double c = (g[0] * dir[0] + g[1] * dir[1] + g[2] * dir[2]) / (gl * dl); const double a = acos_c(c) * 57.29577951308232;
      g_stAim.sumGameAim += a; ++g_stAim.ng; if (a > g_stAim.maxGameAim) g_stAim.maxGameAim = a; }
    float gm[16], fm[16];
    if (exactTip && exact_wand_read(g_exactWand.actor, gm, fm)) {   // the drawn barrel = the game's barrel carried by the game->drawn gun turn
      double v[3];
      for (int c2 = 0; c2 < 3; ++c2) {   // direction g in the game prop's frame, then out through the drawn prop's frame (rows are axes)
        double loc[3]; for (int k = 0; k < 3; ++k) { const double ax = vm::dsqrt((double)gm[k * 4] * gm[k * 4] + (double)gm[k * 4 + 1] * gm[k * 4 + 1] + (double)gm[k * 4 + 2] * gm[k * 4 + 2]); loc[k] = ax > 1e-6 ? (g[0] * gm[k * 4] + g[1] * gm[k * 4 + 1] + g[2] * gm[k * 4 + 2]) / (ax * ax) : 0.0; }
        v[c2] = loc[0] * fm[0 * 4 + c2] + loc[1] * fm[1 * 4 + c2] + loc[2] * fm[2 * 4 + c2];
      }
      const double vl = vm::dsqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
      if (vl > 1e-6) { const double c = (v[0] * dir[0] + v[1] * dir[1] + v[2] * dir[2]) / (vl * dl); const double a = acos_c(c) * 57.29577951308232;
        g_stAim.sumBarrelAim += a; ++g_stAim.nb; if (a > g_stAim.maxBarrelAim) g_stAim.maxBarrelAim = a; }
    }
  }
  const int64_t nq = qpc_now();
  if ((!g_stAim.q || (double)(nq - g_stAim.q) / (double)qpc_freq() >= 5.0) && g_stAim.logs < 40) { g_stAim.q = nq; ++g_stAim.logs;
    log_line("STATIONAIM rooftop: muzzle from the drawn gun %ld of %ld | drawn barrel vs the mod's aim: avg %.1f deg, most %.1f | the game's stream vs the mod's aim: avg %.1f deg, most %.1f | stream left free %ld times, its bend avg %.1f deg, most %.1f (station_beam_free=%d)",
             (long)g_stAim.exact, (long)g_stAim.n, g_stAim.nb ? g_stAim.sumBarrelAim / g_stAim.nb : 0.0, g_stAim.maxBarrelAim, g_stAim.ng ? g_stAim.sumGameAim / g_stAim.ng : 0.0, g_stAim.maxGameAim,
             (long)g_stAim.beamFree, g_stAim.bendN ? 0.1 * g_stAim.bendSumX10 / g_stAim.bendN : 0.0, 0.1 * g_stAim.bendMaxX10, (int)g_ctl.stationBeamFree); }
}

// 1.7.167 the drawn gun's muzzle (the game's gun, held by the game's hand) in the head's own space (engine axes: x right, y up, z forward; metres),
// so the health tube can sit on the gun the player sees instead of on the controller. Render thread writes, render thread reads (seqlock anyway).
// 1.7.188 THE TUBE FLOATED OFF THE GUN IN THE 22:42 VIDEO (about 8 cm while the gun was swung up fast): the muzzle was stored relative to the head AT THE TIME the game placed it, and the tube was then
// built from the controller of the picture it was first seen in; the game places the gun a tick before the picture, so a moving hand made that difference. Now the muzzle is stored where it is in the
// GAME'S WORLD and turned into the head's space of the picture being drawn (the same camera the game draws the gun with): the tube's muzzle point is exactly the drawn gun's muzzle point.
static struct { volatile LONG seq; float w[3]; int64_t q; volatile LONG pubs; } g_muz;
static void gun_muzzle_publish(const float* w) {
  if (!vm::is_finite_f(w[0]) || !vm::is_finite_f(w[1]) || !vm::is_finite_f(w[2])) return;
  InterlockedIncrement(&g_muz.seq);
  for (int i = 0; i < 3; ++i) g_muz.w[i] = w[i];
  g_muz.q = qpc_now();
  InterlockedIncrement(&g_muz.seq);
  InterlockedIncrement(&g_muz.pubs);
}
int engine_gun_muzzle(float* h, long* sampleNo) {
  float hc[3], v[9], fpm = 0.0f; int ok = 0;
  for (int tries = 0; tries < 3 && !ok; ++tries) {
    const LONG s0 = g_headAim.seq; if (s0 & 1) continue;
    for (int i = 0; i < 3; ++i) hc[i] = g_headAim.eye[i];
    for (int i = 0; i < 9; ++i) v[i] = g_headAim.view9[i];
    fpm = g_headAim.fpm;
    ok = g_headAim.seq == s0;
  }
  if (!ok || !(fpm > 0.5f)) return 0;
  for (int tries = 0; tries < 3; ++tries) {
    const LONG s0 = g_muz.seq; if (s0 & 1) continue;
    float w[3] = {g_muz.w[0], g_muz.w[1], g_muz.w[2]}; const int64_t q = g_muz.q; const LONG pubs = g_muz.pubs;
    if (g_muz.seq != s0) continue;
    if (!q || (double)(qpc_now() - q) / (double)qpc_freq() > 0.15) return 0;
    const double d[3] = {(double)w[0] - hc[0], (double)w[1] - hc[1], (double)w[2] - hc[2]};
    float t[3];
    for (int k = 0; k < 3; ++k) t[k] = (float)(((double)v[0 * 3 + k] * d[0] + (double)v[1 * 3 + k] * d[1] + (double)v[2 * 3 + k] * d[2]) / fpm);
    if (!(t[0] * t[0] + t[1] * t[1] + t[2] * t[2] < 4.0f)) return 0;   // more than 2 m from the head: not a gun in hand
    {   // 1.7.191: a muzzle that moves in the WORLD (the player walks or the hand swings) has a stale sample: no learning then (the kept gap holds), so the tube cannot swim while walking
      static gunshift::StillGate s_gate; static LONG s_p0 = -1; static int s_gateInit;
      if (!s_gateInit) { s_gate.reset(); s_gateInit = 1; }
      if (pubs != s_p0) { s_p0 = pubs; const double wd[3] = {(double)w[0], (double)w[1], (double)w[2]}; s_gate.step(wd, (double)q / (double)qpc_freq(), 0.25 * (double)fpm); }
      if (!s_gate.still) return 0;
    }
    for (int i = 0; i < 3; ++i) h[i] = t[i];
    if (sampleNo) *sampleNo = (long)pubs;   // which sample this is (a new number = a new game update)
    return 1;
  }
  return 0;
}

// 1.7.211 "tube floats": the tube's WHOLE frame from the game's own sample of the drawn gun (muzzle, barrel direction, up of one tick), in the head space of the game's camera: no controller read, no learned gap, no gate.
// r (row-major, columns = tube-model right / up / back) and t (head space, metres, engine axes) like hand::Xform before the eye offset is taken off.
int engine_gun_frame(float* r, float* t, double* ageMs) {
  float hc[3], v[9], fpm = 0.0f; int ok = 0;
  for (int tries = 0; tries < 3 && !ok; ++tries) {
    const LONG s0 = g_headAim.seq; if (s0 & 1) continue;
    for (int i = 0; i < 3; ++i) hc[i] = g_headAim.eye[i];
    for (int i = 0; i < 9; ++i) v[i] = g_headAim.view9[i];
    fpm = g_headAim.fpm; ok = g_headAim.seq == s0;
  }
  if (!ok || !(fpm > 0.5f)) return 0;
  float w[3] = {0, 0, 0}; int64_t q = 0; int ok2 = 0;
  for (int tries = 0; tries < 3 && !ok2; ++tries) {
    const LONG s0 = g_muz.seq; if (s0 & 1) continue;
    for (int i = 0; i < 3; ++i) w[i] = g_muz.w[i]; q = g_muz.q; ok2 = g_muz.seq == s0;
  }
  const int64_t now = qpc_now(), pq = g_gunPlacedAt; const double f = (double)qpc_freq();
  if (!ok2 || !q || !pq || (double)(now - q) / f > 0.15 || (double)(now - pq) / f > 0.15) return 0;
  const double d[3] = {(double)w[0] - hc[0], (double)w[1] - hc[1], (double)w[2] - hc[2]};
  const float dirW[3] = {g_gunPlacedDir[0], g_gunPlacedDir[1], g_gunPlacedDir[2]}, upW[3] = {g_gunPlacedUp[0], g_gunPlacedUp[1], g_gunPlacedUp[2]};
  float m[3], fw[3], up[3];
  for (int k = 0; k < 3; ++k) {
    m[k] = (float)(((double)v[k] * d[0] + (double)v[3 + k] * d[1] + (double)v[6 + k] * d[2]) / fpm);
    fw[k] = v[k] * dirW[0] + v[3 + k] * dirW[1] + v[6 + k] * dirW[2];
    up[k] = v[k] * upW[0] + v[3 + k] * upW[1] + v[6 + k] * upW[2];
  }
  const double fl = vm::dsqrt((double)fw[0] * fw[0] + (double)fw[1] * fw[1] + (double)fw[2] * fw[2]);
  if (!(fl > 0.5) || !(m[0] * m[0] + m[1] * m[1] + m[2] * m[2] < 4.0f)) return 0;
  for (int k = 0; k < 3; ++k) fw[k] = (float)(fw[k] / fl);
  float rt[3] = {up[1] * fw[2] - up[2] * fw[1], up[2] * fw[0] - up[0] * fw[2], up[0] * fw[1] - up[1] * fw[0]};   // up x forward = right (x right, y up, z forward)
  const double rl = vm::dsqrt((double)rt[0] * rt[0] + (double)rt[1] * rt[1] + (double)rt[2] * rt[2]);
  if (!(rl > 0.2)) return 0;
  for (int k = 0; k < 3; ++k) rt[k] = (float)(rt[k] / rl);
  const float u2[3] = {fw[1] * rt[2] - fw[2] * rt[1], fw[2] * rt[0] - fw[0] * rt[2], fw[0] * rt[1] - fw[1] * rt[0]};
  for (int k = 0; k < 3; ++k) { r[k * 3] = rt[k]; r[k * 3 + 1] = u2[k]; r[k * 3 + 2] = -fw[k]; t[k] = m[k] - hand::kTipY * u2[k] + hand::kTipZ * fw[k]; }   // origin = muzzle - R*kTip (kTip = (0,.02,-.488) in the model frame, model z = back)
  if (ageMs) *ageMs = (double)(now - q) * 1000.0 / f;
  return 1;
}

static GBVR_NOINLINE void* __fastcall hk_attach_matrix(void* actor, float* out, const char* name) {
  void* retAddr = GBVR_RETURN_ADDRESS();
  stage_g(ST_G_TIP);
  void* r = o_attach(actor, out, name);
  int streamMine = 0;   // 1.7.10: this fetch is the player's own stream update
  if ((uintptr_t)retAddr == rva(layout::kRvaTipCallers[3]) + 5) {   // 0.69: the stream update's own request for the tip (see g_beam)
    InterlockedIncrement(&g_beam.tipFetches);
    const int mine = g_headAim.actor && (uintptr_t)actor == g_headAim.actor;
    if (mine) { InterlockedIncrement(&g_beam.tipPlayer); streamMine = 1; sfix_try_view_hook((uintptr_t)actor); }
    if (mine && !pke_item_held()) fight_lock_guard((uintptr_t)actor);   // 1.7.2: the game's lock on a table / chair / prop is let go before the stream looks at it (the PKE keeps its own lock)
    g_streamTipTid = mine ? (LONG)GetCurrentThreadId() : 0;
  }
  InterlockedIncrement(&g_tipSt.calls);
  if (name && memory_readable_any(name, 2)) {   // 0.51 census: which attachment names the game asks for (model parts / bones), how often, last world position
    int slot = -1;
    for (int i = 0; i < g_attachN; ++i) { const char* a = g_attach[i].name; const char* b = name; while (*a && *a == *b) { ++a; ++b; } if (*a == *b) { slot = i; break; } }
    if (slot < 0 && g_attachN < 32) {
      slot = g_attachN++;
      int k = 0;
      for (; k < 31 && name[k] && memory_readable_any(name + k, 1); ++k) g_attach[slot].name[k] = name[k];
      g_attach[slot].name[k] = 0;
      g_attach[slot].count = 0;
      log_line("ATTACH new name \"%s\" asked for by the game (actor %p%s)", g_attach[slot].name, actor, (uintptr_t)actor == g_headAim.actor ? " = player" : "");
    }
    if (slot >= 0) {
      g_attach[slot].count++;
      if (out && memory_readable(out, 64)) for (int i = 0; i < 3; ++i) g_attach[slot].pos[i] = out[12 + i];
    }
  }
  if (out && name && name[0] == 'h' && name[1] == 'o' && name[2] == 's' && name[3] == 'e' && name[4] == 0 && (uintptr_t)actor != g_headAim.actor && memory_readable(out, 64))
    fight_hose_raw(out + 12, (uintptr_t)actor);   // 0.76: where the game itself puts the hose's gun end (the cord is drawn to it)
  if (g_ctl.gamePlace && streamMine && out && memory_readable(out, 64) && vm::is_finite_f(out[8]) && vm::is_finite_f(out[9]) && vm::is_finite_f(out[10]) && vm::is_finite_f(out[12]) && vm::is_finite_f(out[13]) && vm::is_finite_f(out[14])) {
    // 1.7.13: the game places the gun; the muzzle and the barrel line are the game's own (tip matrix row 2), and the hit point is put on THAT line (hk_aim_getter / hk_view_hit)
    for (int i = 0; i < 3; ++i) { g_sfixTip[i] = out[12 + i]; g_sfixDir[i] = out[8 + i]; }
    g_sfixQ = qpc_now();
    InterlockedIncrement(&g_tipSt.gameTip);
    {   // data: how far the game's own barrel is from where the controller points (does the game's animation follow the aim we give it?)
      float ad[3] = {0, 0, 0}; int okA = 0; int64_t qa = 0;
      for (int tries = 0; tries < 3 && !okA; ++tries) {
        LONG s0 = g_headAim.seq; if (s0 & 1) continue;
        ad[0] = g_headAim.adir[0]; ad[1] = g_headAim.adir[1]; ad[2] = g_headAim.adir[2]; qa = g_headAim.qpc;
        okA = g_headAim.seq == s0 && g_headAim.hasTip;
      }
      if (okA && aim::is_fresh(qpc_now(), qa, qpc_freq(), 250)) {
        const double deg = aim::angle_deg(out + 8, ad);
        const LONG x100 = (LONG)(deg * 100.0);
        InterlockedIncrement(&g_gp.n); InterlockedExchangeAdd(&g_gp.sumX100, x100 > 100000 ? 100000 : x100);
        if (x100 > g_gp.maxX100) g_gp.maxX100 = x100;
        if (deg > 10.0) InterlockedIncrement(&g_gp.over10);
        if (deg > 30.0) InterlockedIncrement(&g_gp.over30);
        if (deg > 60.0) InterlockedIncrement(&g_gp.over60);
        g_gp.lastX100 = x100;
        if (g_gp.n % 600 == 1 && g_gp.logged < 40) { ++g_gp.logged; log_line("GAMEPLACE sample #%d: the game's own barrel is %.1f deg from where your controller points (muzzle %.2f,%.2f,%.2f ft)", (int)g_gp.n, deg, (double)out[12], (double)out[13], (double)out[14]); }
      }
    }
  }
  if (g_ctl.gamePlace) return r;   // 1.7.13: the game decides where the gun and its tip are
  if (!g_ctl.headAim || g_ctl.headAim != 2 || !g_ctl.stereoActive || !(g_ctl.handModel || g_ctl.realModels) || !out || !name) return r;
  if (name[0] != 't' || name[1] != 'i' || name[2] != 'p' || name[3] != 0) return r;
  InterlockedIncrement(&g_tipSt.tipCalls);
  uintptr_t pa = 0;
  float tip[3] = {0, 0, 0}, dir[3] = {0, 0, 1};
  int64_t q = 0;
  int ok = 0;
  for (int tries = 0; tries < 3 && !ok; ++tries) {
    LONG s0 = g_headAim.seq;
    if (s0 & 1) continue;
    pa = g_headAim.actor;
    tip[0] = g_headAim.tip[0]; tip[1] = g_headAim.tip[1]; tip[2] = g_headAim.tip[2];
    dir[0] = g_headAim.adir[0]; dir[1] = g_headAim.adir[1]; dir[2] = g_headAim.adir[2];   // 0.68: the assisted direction (= dir when the assist is off)
    q = g_headAim.qpc;
    ok = g_headAim.seq == s0 && g_headAim.hasTip;
  }
  if (!ok || !pa || (uintptr_t)actor != pa) return r;
  if (!aim::is_fresh(qpc_now(), q, qpc_freq(), 250)) { InterlockedIncrement(&g_tipSt.stale); return r; }
  if (!vm::is_finite_f(out[12]) || !vm::is_finite_f(out[13]) || !vm::is_finite_f(out[14])) return r;
  int exactTip = 0;
  {
    float gameProp[16], finalProp[16], mapped[16];
    if (exact_wand_read((uintptr_t)actor, gameProp, finalProp) && handprop::map_part(out, gameProp, finalProp, mapped)) {
      tip[0]=mapped[12]; tip[1]=mapped[13]; tip[2]=mapped[14];
      exactTip=1; InterlockedIncrement(&g_exactWand.tipMapped);
    } else InterlockedIncrement(&g_exactWand.tipFallback);
  }
  // With the exact hand lock enabled, never invent a muzzle from the controller
  // when the exact game-hand mapping is temporarily unavailable. The game tip
  // is safer for that frame and cannot pull the beam away from the visible gun.
  if (!exactTip && g_ctl.handLock) return r;
  if (!exactTip && g_ctl.armIk && g_ctl.realModels && g_ctl.wandToHand && g_wandHook == 1) {   // legacy fallback only when hand_lock is explicitly off
    uintptr_t pa2 = 0; float dir2[3], grip2[3], up2[3]; int64_t q2 = 0;
    const float* W = (const float*)((const uint8_t*)actor + layout::kOffWandWorld);
    wand::Solve ws;
    if (wand_aim_read(&pa2, dir2, grip2, &q2, up2) && pa2 == (uintptr_t)actor && memory_readable(W, 64) && wand::solve(W, out, grip2, dir2, &ws, wand_up_arg(up2), wand_roll_rad())) {
      tip[0] = ws.tip[0]; tip[1] = ws.tip[1]; tip[2] = ws.tip[2];
      const LONG vp = g_ctl.viewModelPct;   // 0.77: the drawn gun is bigger about its grip, so the beam starts at its bigger muzzle
      if (vp >= 80 && vp <= 200 && vp != 100) {
        const float k = (float)vp * 0.01f;
        for (int i = 0; i < 3; ++i) tip[i] = grip2[i] + k * (tip[i] - grip2[i]);
        InterlockedIncrement(&g_wandSt.tipSized);
      }
    }
  }
  if (!exactTip && g_ctl.gripAtHand && g_ctl.armIk && g_ctl.realModels && g_ctl.wandToHand && g_wandHook == 1) {   // legacy fallback: the gun slid to fit the hand
    float gs[3];
    if (g_ctl.gunRigid && g_gunRigidAt && (double)(qpc_now() - g_gunRigidAt) / (double)qpc_freq() < 0.12) {   // 1.6: the muzzle takes the same rigid slide the drawn gun got
      for (int i = 0; i < 3; ++i) tip[i] += g_gunRigidLast[i];
      InterlockedIncrement(&g_wandSt.tipFit);
    } else if (arms_grip_shift(gs)) { for (int i = 0; i < 3; ++i) tip[i] += gs[i]; InterlockedIncrement(&g_wandSt.tipFit); }
    if ((g_ctl.gunFwdCm || g_ctl.gunUpCm) && g_gunFitAt && (double)(qpc_now() - g_gunFitAt) / (double)qpc_freq() < 0.12) for (int i = 0; i < 3; ++i) tip[i] += g_gunFitOff[i];   // 1.7: the menu's gun fit moves the muzzle with the drawn gun
  }
  if (!exactTip && g_ctl.gunGlue && g_ctl.armIk && g_ctl.realModels && g_ctl.wandToHand && g_wandHook == 1) {   // legacy fallback only
    float ms[3];
    if (arms_gun_miss(ms)) { for (int i = 0; i < 3; ++i) tip[i] -= ms[i]; InterlockedIncrement(&g_wandSt.tipGlued); }
  }
  double dx = tip[0] - out[12], dy = tip[1] - out[13], dz = tip[2] - out[14];
  g_tipSt.lastDistX100 = (LONG)(vm::dsqrt(dx * dx + dy * dy + dz * dz) * 100.0);
  for (int i = 0; i < 3; ++i) { g_tipSt.lastOld[i] = out[12 + i]; g_tipSt.lastNew[i] = tip[i]; }
  if (InterlockedIncrement(&g_tipSt.overridden) == 1)
    log_line("TIP first override: the game's wand tip (%.2f,%.2f,%.2f) replaced by the controller's wand tip (%.2f,%.2f,%.2f) (feet)",
             (double)out[12], (double)out[13], (double)out[14], (double)tip[0], (double)tip[1], (double)tip[2]);
  const int station = engine_scene_arms((uintptr_t)actor) && g_sceneStation.have;   // 1.7.169
  if (station) station_aim_note(out, dir, exactTip);
  out[12] = tip[0]; out[13] = tip[1]; out[14] = tip[2];
  if (!(station && g_ctl.stationBeamFree)) tip_rotate(out, dir);   // 1.7.169: on the rooftop the stream leaves toward where the game sends it (no kink)
  if (exactTip) gun_muzzle_publish(tip);   // 1.7.167: where the drawn gun's muzzle is, for the health tube
  if (streamMine) {   // 1.7.10: the stream's muzzle and aim of this update, for the two hit-point reads that follow in the same stream update
    for (int i = 0; i < 3; ++i) { g_sfixTip[i] = out[12 + i]; g_sfixDir[i] = dir[i]; }
    g_sfixQ = qpc_now();
  }
  return r;
}


// ---- 0.59 guard for a game helper that crashed while a level loaded -----------------------------------------------
// 0.58 log: ghost.exe+0x2D668A "mov rax,[rcx]" with rcx = 0x00FFFFFF00FFFFFF (colour bytes where an object pointer should be),
// in flat mode, before the headset was even on. The helper is bool Get(obj, key): it calls the object's first virtual function.
// The guard checks the pointer chain first; a broken object gives "false" (as if the key were absent) instead of a crash.
typedef unsigned char(__fastcall* PFN_PropGet)(void* obj, void* key);
static PFN_PropGet o_propGet;
static int g_propHook;
static struct { volatile LONG calls, saved, logged; } g_propSt;
static int prop_ptr_ok(const void* p, size_t n) {
  const uintptr_t v = (uintptr_t)p;
  if (v < 0x10000 || v >= 0x00007FFFFFFF0000ull || (v & 7)) return 0;   // not a user-mode address (the crash had 0x00FFFFFF00FFFFFF)
  static uintptr_t s_page;   // last page already verified: most calls repeat the same objects
  if ((v >> 12) == s_page && ((v + n - 1) >> 12) == s_page) return 1;
  if (!memory_readable_any(p, n)) return 0;
  if (((v + n - 1) >> 12) == (v >> 12)) s_page = v >> 12;
  return 1;
}
static unsigned char __fastcall hk_prop_get(void* obj, void* key) {
  InterlockedIncrement(&g_propSt.calls);
  if (obj) {
    int ok = prop_ptr_ok(obj, 8);
    const void* vt = nullptr; const void* fn = nullptr;
    if (ok) { vt = *(void* const*)obj; ok = prop_ptr_ok(vt, 8); }
    if (ok) { fn = *(void* const*)vt; ok = fn && (uintptr_t)fn >= 0x10000 && (uintptr_t)fn < 0x00007FFFFFFF0000ull && memory_readable_any(fn, 1); }
    if (!ok) {
      InterlockedIncrement(&g_propSt.saved);
      if (InterlockedIncrement(&g_propSt.logged) <= 8)
        log_line("PROPGUARD broken object caught: obj=%p key=%p first qword=%p (the game's helper at +0x2d6670 returns false instead of crashing); caller +0x%x",
                 obj, key, (uintptr_t)obj >= 0x10000 && (uintptr_t)obj < 0x00007FFFFFFF0000ull && memory_readable_any(obj, 8) ? *(void* const*)obj : nullptr,
                 (unsigned)((uintptr_t)GBVR_RETURN_ADDRESS() - g_game.base));
      return 0;
    }
  }
  return o_propGet(obj, key);
}
// ---- 1.7.24 slam helper -----------------------------------------------------------------------------------------------------------------------
// The game slams from inside the player update (0xD8596): capture beam in mode 4 (player+0x24D80 -> +0x170), the fire bits of the action mask set, and then TryEnterSlam (0xDE390): meter (player+0x24A40) >= 0.25
// -> EnterSlam sets the flag at player+0x24A48. The 1.7.22 log: four slam presses with the meter at 0.7 to 1.0 and a ghost under the ring, and the game never started a slam, so one of the earlier conditions
// (most likely the beam mode) was not met and the log could not say which. This block (a) watches the beam mode, the flag and the meter every player update, counts how often the game itself reaches TryEnterSlam
// and whether it works (SLAMGAME), and (b) when the left-trigger sequence has run its press and the game has still not started the slam while a ghost is held and the meter is up, calls the game's own TryEnterSlam
// from the same place in the update (right before the capture step), once per sequence (setting slam_assist, on by default).
typedef void(__fastcall* PFN_TrySlam)(void* player);
static PFN_TrySlam o_trySlam;
static struct {
  volatile LONG hooked, req, done;
  volatile LONG64 reqQpc;
  long frames, mode4, gameCalls, gameCallsWin, gameEntered, gameEnteredWin, helperCalls, helperEntered, winFrames, skipFlag, skipMeter, skipHeld, skipOff, reqs;
  long modeAll[8], modeWin[8], modeAtCall[8];
  int logged, stLogged; double lastStateAge; int lastReq;
} g_sa;
void slam_assist_request(long long qpc) { g_sa.reqQpc = (LONG64)qpc;   /* an aligned 64-bit store is atomic on x64 */ InterlockedExchange(&g_sa.done, 0); InterlockedExchange(&g_sa.req, 1); ++g_sa.reqs; }
static int sa_read(uintptr_t player, int* mode, int* sub, int* flag, float* meter, float* limit) {
  *mode = *sub = -1; *flag = 0; *meter = 0.f; *limit = 0.f;
  if (!player || !memory_readable((const void*)(player + layout::kOffSlamMeter), 16)) return 0;
  *meter = *(const float*)(player + layout::kOffSlamMeter);
  *flag = *(const unsigned char*)(player + layout::kOffSlamFlag);
  const float* lp = (const float*)rva(layout::kRvaSlamLimit);
  *limit = memory_readable(lp, 4) ? *lp : 0.f;
  if (memory_readable((const void*)(player + layout::kOffBeamPtr), 8)) {
    const uintptr_t b = *(const uintptr_t*)(player + layout::kOffBeamPtr);
    if (b && memory_readable((const void*)(b + layout::kOffBeamMode), 8)) { *mode = *(const int*)(b + layout::kOffBeamMode); *sub = *(const int*)(b + layout::kOffBeamSub); }
  }
  return 1;
}
static double sa_age() { const LONG64 q = g_sa.reqQpc; return g_sa.req && q ? (double)(qpc_now() - q) / (double)qpc_freq() : 999.0; }
static void __fastcall hk_try_slam(void* pv) {
  const uintptr_t p = (uintptr_t)pv;
  const int mine = g_headAim.actor && p == g_headAim.actor;
  int m0 = -1, s0 = -1, f0 = 0, ok0 = 0; float g0 = 0.f, l0 = 0.f;
  if (mine) ok0 = sa_read(p, &m0, &s0, &f0, &g0, &l0);
  o_trySlam(pv);
  if (!mine) return;
  const double age = sa_age();
  const int win = age < 1.6;
  ++g_sa.gameCalls; if (win) ++g_sa.gameCallsWin;
  if (m0 >= 0 && m0 < 8) ++g_sa.modeAtCall[m0];
  int m1, s1, f1; float g1, l1;
  if (ok0 && sa_read(p, &m1, &s1, &f1, &g1, &l1) && !f0 && f1) {
    ++g_sa.gameEntered; if (win) ++g_sa.gameEnteredWin;
    if (g_sa.logged < 40) { ++g_sa.logged; log_line("SLAMENTER the GAME started the slam itself: beam mode %d/%d, meter %.2f -> %.2f of %.2f, %.2f s after the slam sequence began", m0, s0, (double)g0, (double)g1, (double)l0, age); }
  }
}
// called from the capture step hook (the player's own call), once per update
static void sa_step(uintptr_t player) {
  int mode, sub, flag; float meter, limit;
  if (!sa_read(player, &mode, &sub, &flag, &meter, &limit)) return;
  ++g_sa.frames; if (mode >= 0 && mode < 8) ++g_sa.modeAll[mode]; if (mode == 4) ++g_sa.mode4;
  if (!g_sa.req) return;
  const double age = sa_age();
  if (age > 1.6) { InterlockedExchange(&g_sa.req, 0); InterlockedExchange(&g_reportNow, 1); return; }
  ++g_sa.winFrames; if (mode >= 0 && mode < 8) ++g_sa.modeWin[mode];
  const int held = fight_wrangled();
  if (g_sa.lastReq != (int)g_sa.reqs) { g_sa.lastReq = (int)g_sa.reqs; g_sa.lastStateAge = -1.0; }
  if (g_sa.stLogged < 120 && age - g_sa.lastStateAge >= 0.08) {
    g_sa.lastStateAge = age; ++g_sa.stLogged;
    log_line("SLAMSTATE #%d t=%.2f s: capture beam mode %d (sub %d; 4 = the capture stream is on), slam flag %d, meter %.2f of %.2f, ghost under the ring %d", (int)g_sa.reqs, age, mode, sub, flag, (double)meter, (double)limit, held);
  }
  if (!g_ctl.slamAssist) { if (!g_sa.done) { g_sa.done = 1; ++g_sa.skipOff; } return; }
  if (g_sa.done) return;
  if (flag) { g_sa.done = 1; ++g_sa.skipFlag; if (g_sa.logged < 40) { ++g_sa.logged; log_line("SLAMASSIST not needed: the slam is already running (beam mode %d/%d, meter %.2f)", mode, sub, (double)meter); } return; }
  if (!(limit > 0.f) || !(meter >= limit)) { g_sa.done = 1; ++g_sa.skipMeter; if (g_sa.logged < 40) { ++g_sa.logged; log_line("SLAMASSIST skipped: the meter is %.2f, the game needs %.2f", (double)meter, (double)limit); } return; }
  if (held <= 0 || mode != 4) {   // 1.7.25: keep trying for 0.6 s (the stream may be a few frames away from holding the ghost)
    if (age < 0.6) return;
    g_sa.done = 1; ++g_sa.skipHeld; if (g_sa.logged < 40) { ++g_sa.logged; log_line("SLAMASSIST skipped after 0.6 s: no ghost under the ring or the capture stream is not on (beam mode %d/%d, ring %d)", mode, sub, held); } return;
  }
  g_sa.done = 1;
  ++g_sa.helperCalls;
  o_trySlam((void*)player);
  int m1, s1, f1; float g1, l1;
  const int ok = sa_read(player, &m1, &s1, &f1, &g1, &l1);
  if (ok && f1) ++g_sa.helperEntered;
  if (g_sa.logged < 40) { ++g_sa.logged; log_line("SLAMASSIST the probe asked the game to start the slam (beam mode %d/%d, %.2f s into the sequence): slam flag %d -> %d, meter %.2f -> %.2f of %.2f -> %s", mode, sub, age, flag, ok ? f1 : -1, (double)meter, (double)(ok ? g1 : -1.f), (double)limit, ok && f1 ? "the game accepted it" : "the game did not start a slam"); }
}
static void install_slam_helper() {
  if (!bytes_match(layout::kRvaTrySlam, layout::kBytesTrySlam, 16)) { g_sa.hooked = -1; log_line("SLAMHELPER not available: the slam entry's bytes differ in this game build"); return; }
  void* t = (void*)rva(layout::kRvaTrySlam);
  MH_STATUS st = MH_CreateHook(t, (void*)hk_try_slam, (void**)&o_trySlam);
  if (st == MH_OK) st = MH_EnableHook(t);
  g_sa.hooked = st == MH_OK ? 1 : -2;
  log_line("HOOK slam helper status=%d target=%p (1.7.24: counts the game's own slam-entry calls; the probe can call it too when slam_assist=1, now %d)", (int)st, t, (int)g_ctl.slamAssist);
}
static void slam_helper_report(LONG frame) {
  log_line("SLAMGAME frame=%d hook=%d slam_assist=%d | player updates seen %ld, capture beam in mode 4 for %ld of them (modes 0/1/2/3/4: %ld/%ld/%ld/%ld/%ld) | the game reached its slam entry %ld times (%ld inside a slam sequence's 1.6 s, with the beam in mode 4/2/0 at the call: %ld/%ld/%ld) and started the slam %ld times (%ld inside a sequence) | the probe's help: sequences %ld, asked the game %ld times, accepted %ld, skipped: already running %ld, meter low %ld, no ghost %ld, switched off %ld | during sequences: %ld updates, beam modes 0/2/3/4: %ld/%ld/%ld/%ld",
           (int)frame, (int)g_sa.hooked, (int)g_ctl.slamAssist, g_sa.frames, g_sa.mode4, g_sa.modeAll[0], g_sa.modeAll[1], g_sa.modeAll[2], g_sa.modeAll[3], g_sa.modeAll[4], g_sa.gameCalls, g_sa.gameCallsWin, g_sa.modeAtCall[4], g_sa.modeAtCall[2], g_sa.modeAtCall[0], g_sa.gameEntered, g_sa.gameEnteredWin,
           g_sa.reqs, g_sa.helperCalls, g_sa.helperEntered, g_sa.skipFlag, g_sa.skipMeter, g_sa.skipHeld, g_sa.skipOff, g_sa.winFrames, g_sa.modeWin[0], g_sa.modeWin[2], g_sa.modeWin[3], g_sa.modeWin[4]);
}
// ---- 1.7.19 the capture stream only wrangles ghosts ----------------------------------------------------------------------------------------------
// The game's own lock-on accepts props (the class filter at 0xAB320 lists CPhysicsObject, CGlass, CAniModel, CBoneSimActor ...). The 1.7.2 guard let go of such a lock at the stream's tip request; the wrangle step
// (processWrangling) is a separate function that runs once a frame, so the same guard runs right before it as well. Only the player's own call is touched (AI ghostbusters are left alone).
typedef void(__fastcall* PFN_Wrangle)(void* self, float dt);
static PFN_Wrangle o_wrangle;
static struct { volatile LONG hooked; long calls, mine, cleared, capForced, capReleased; int logged; } g_wrg;
static uintptr_t g_capOwner;
static int g_capInjected;
static void capture_hold_bridge(uintptr_t player) {
  if (!player || !memory_readable((const void*)(player + 0xC7A8), sizeof(uint32_t))) return;
  if (g_capOwner != player) { g_capOwner = player; g_capInjected = 0; }
  volatile uint32_t* mask = (volatile uint32_t*)(player + 0xC7A8);
  const bool want = g_ctl.padEnabled && g_ctl.stereoActive &&
                    !stereo_in_flat_mode() && !pke_item_held() && bindings_capture_down();
  const capbridge::Result next = capbridge::step(*mask, want, g_capInjected != 0);
  if (next.added || next.removed) *mask = next.mask;
  g_capInjected = next.owned;
  if (next.added) ++g_wrg.capForced;
  if (next.removed) ++g_wrg.capReleased;
}
static GBVR_NOINLINE void __fastcall hk_wrangle(void* self, float dt) {
  InterlockedIncrement((volatile LONG*)&g_wrg.calls);
  if (g_headAim.actor && (uintptr_t)self == g_headAim.actor) capture_hold_bridge((uintptr_t)self);
  if (g_headAim.actor && (uintptr_t)self == g_headAim.actor) sa_step((uintptr_t)self);   // 1.7.24: slam state log + the slam helper (same place in the update where the game itself would start the slam)
  if (g_ctl.lockGhostOnly && g_headAim.actor && (uintptr_t)self == g_headAim.actor && !pke_item_held()) {
    InterlockedIncrement((volatile LONG*)&g_wrg.mine);
    const int n = fight_lock_guard((uintptr_t)self);
    if (n) { InterlockedExchangeAdd((volatile LONG*)&g_wrg.cleared, n); if (g_wrg.logged < 12) { ++g_wrg.logged; log_line("WRANGLEGUARD a lock on something that is not a ghost was let go right before the capture step (%d lock%s)", n, n == 1 ? "" : "s"); } }
  }
  o_wrangle(self, dt);
}
// ---- 1.7.27 the HUD pointer is only hidden while the proton stream update runs ----------------------------------------------------------------------------------------------------------------------
// player+0xB550 is the game's HUD (CGameView): HUD::Init (0x1FDBA3) stores itself there and the player's destructor deletes it. The 1.7.2 "lock only ghosts" guard took it for a lock-on target and set it to 0
// at the first stream request of every session ("LOCKGUARD ... stream lock sits on a CGameView ... let go" in every log since). With the HUD pointer 0 the stream update ends the stream along the barrel (the paths the
// probe puts on the barrel line), which is what the VR aim relies on, so that part stays: the pointer is 0 only for the duration of the stream update (0xE6360) and is put back right after. Everything else in the
// game (the PKE goggles, prompts, the tutorial hints that tell the story to go on) sees its HUD again.
typedef void(__fastcall* PFN_StreamUpdate)(void* self, float dt);
static PFN_StreamUpdate o_streamUpdate;
static struct { volatile LONG hooked; long calls, mine, hidden, restored, changed, noHud; } g_su;
static GBVR_NOINLINE void __fastcall hk_stream_update(void* self, float dt) {
  InterlockedIncrement((volatile LONG*)&g_su.calls);
  if (g_headAim.actor && (uintptr_t)self == g_headAim.actor) capture_hold_bridge((uintptr_t)self);
  uintptr_t* slot = nullptr; uintptr_t saved = 0;
  if (g_ctl.lockGhostOnly && g_headAim.actor && (uintptr_t)self == g_headAim.actor) {
    InterlockedIncrement((volatile LONG*)&g_su.mine);
    uintptr_t* sl = (uintptr_t*)((uintptr_t)self + layout::kOffPlayerHud);
    if (memory_readable(sl, 8)) {
      saved = *sl;
      if (saved) { slot = sl; *sl = 0; InterlockedIncrement((volatile LONG*)&g_su.hidden); } else InterlockedIncrement((volatile LONG*)&g_su.noHud);
    }
  }
  o_streamUpdate(self, dt);
  if (slot && saved) {
    if (*slot == 0) { *slot = saved; InterlockedIncrement((volatile LONG*)&g_su.restored); }
    else InterlockedIncrement((volatile LONG*)&g_su.changed);   // the game put something there meanwhile: left as it is
  }
}
static void install_stream_update_hook() {
  if (!bytes_match(layout::kRvaStreamUpdate, layout::kBytesStreamUpdate, 16)) { g_su.hooked = -1; log_line("STREAMHUD not available: the proton stream update's bytes differ in this game build (the HUD pointer is left alone, the beam may follow the game's own aim point)"); return; }
  void* t = (void*)rva(layout::kRvaStreamUpdate);
  MH_STATUS st = MH_CreateHook(t, (void*)hk_stream_update, (void**)&o_streamUpdate);
  if (st == MH_OK) st = MH_EnableHook(t);
  g_su.hooked = st == MH_OK ? 1 : -2;
  log_line("HOOK stream-update HUD guard status=%d target=%p (1.7.27: the HUD pointer player+0xB550 is hidden only while the proton stream runs, then put back)", (int)st, t);
}
static void install_wrangle_guard() {
  if (!bytes_match(layout::kRvaWrangle, layout::kBytesWrangle, 16)) { g_wrg.hooked = -1; log_line("WRANGLEGUARD not available: the capture step's bytes differ in this game build"); return; }
  void* t = (void*)rva(layout::kRvaWrangle);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_wrangle, (void**)&o_wrangle);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_wrg.hooked = s == MH_OK ? 1 : -2;
  log_line("HOOK capture-step guard status=%d target=%p (1.7.19: a lock on a prop is let go before the capture step runs)", (int)s, t);
}
static void streamhud_report(LONG frame) {
  log_line("STREAMHUD frame=%d hook=%d | stream updates %ld, the player's own %ld: HUD pointer hidden for the call %ld times and put back %ld times, changed by the game meanwhile %ld, no HUD at all %ld (1.7.27: before, the HUD pointer was wiped for good)",
           (int)frame, (int)g_su.hooked, g_su.calls, g_su.mine, g_su.hidden, g_su.restored, g_su.changed, g_su.noHud);
}
static void wrangle_report(LONG frame) {
  log_line("WRANGLEGUARD frame=%d hook=%d lock_ghost_only=%d | capture steps %ld, the player's own %ld, locks let go before them %ld", (int)frame, (int)g_wrg.hooked, (int)g_ctl.lockGhostOnly, g_wrg.calls, g_wrg.mine, g_wrg.cleared);
  log_line("CAPTUREBRIDGE frame=%d capture button held: fallback applied %ld times, released %ld times, active=%d (preserves the game's own slam path)", (int)frame, g_wrg.capForced, g_wrg.capReleased, g_capInjected);
}
static void install_prop_guard() {
  if (!bytes_match(layout::kRvaPropGet, layout::kBytesPropGet, 16)) { g_propHook = -1; log_line("PROPGUARD not available: the helper's bytes differ in this game build"); return; }
  void* t = (void*)rva(layout::kRvaPropGet);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_prop_get, (void**)&o_propGet);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_propHook = s == MH_OK ? 1 : -2;
  log_line("HOOK prop-get guard status=%d target=%p", (int)s, t);
}

static void install_tip_hook() {
  int fn = bytes_match(layout::kRvaAttachMatrix, layout::kBytesAttachMatrix, 16);
  int calls = 1;
  for (uint32_t c : layout::kRvaTipCallers) {
    const uint8_t* p = (const uint8_t*)rva(c);
    if (p[0] != 0xe8 || (uintptr_t)(p + 5 + *(const int32_t*)(p + 1)) != rva(layout::kRvaAttachMatrix)) calls = 0;
  }
  const uint8_t* str = (const uint8_t*)rva(layout::kRvaTipString);
  int tipStr = str[0] == 't' && str[1] == 'i' && str[2] == 'p' && str[3] == 0;
  if (!fn || !calls || !tipStr) {
    g_tipHook = -1;
    log_line("TIP not available (bytes=%d callSites=%d string=%d): the stream keeps starting at the game's wand", fn, calls, tipStr);
    return;
  }
  void* t = (void*)rva(layout::kRvaAttachMatrix);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_attach_matrix, (void**)&o_attach);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_tipHook = s == MH_OK ? 1 : -2;
  log_line("HOOK attach-matrix status=%d target=%p (wand tip: %s)", (int)s, t, g_tipHook == 1 ? "available" : "NOT available");
}


// 0.51: the render pass multiplies the wand instance's world matrix with the view matrix (kRvaWandPushCall). For the
// player's wand the world matrix is replaced by one that puts the wand in the controller hand (see wand_solve).
typedef float*(__fastcall* PFN_MatMul)(const float* a, float* out, const float* b);
static PFN_MatMul o_matMul;
// 0.57: the arms. Targets in game world: the right (gun) hand takes the wand's rigid motion (the same turn about the grip that
// moves the wand model to the controller, see the wand hook below), the left hand goes to the left controller.
struct BodyExtra { int on; float lean[3]; float view[9]; double yaw; float eye[3]; int eyeOk; float fade; };
// 0.97 "the gun falls out of the hand" detector: the gun is out (not holstered, not the PKE) but the avatar's right hand has no target this pass, so the hand stays in the animation while the gun is at the controller.
static struct { volatile LONG total, bursts, logged, shots; volatile LONG reason[6]; int64_t lastQ; } g_gunLost;
static void gunhand_lost(int reason) {
  if (!g_ctl.probeData) return;
  InterlockedIncrement(&g_gunLost.total);
  if (reason >= 0 && reason < 6) InterlockedIncrement(&g_gunLost.reason[reason]);
  const int64_t nq = qpc_now();
  const int newBurst = !g_gunLost.lastQ || (double)(nq - g_gunLost.lastQ) / (double)qpc_freq() > 0.5;   // a burst = passes less than half a second apart
  g_gunLost.lastQ = nq;
  if (!newBurst) return;
  InterlockedIncrement(&g_gunLost.bursts);
  if (InterlockedIncrement(&g_gunLost.logged) <= 30)
    log_line("GUNLOST #%ld the gun is out but the avatar's right hand has no target: %s (passes so far %ld)", g_gunLost.bursts,
             reason == 3 ? "the controller aim is not fresh" : reason == 4 ? "the game's wand matrix cannot be read" : reason == 5 ? "no wand solution (the hand would be more than 12 ft from the gun)" : "unknown", g_gunLost.total);
  if ((reason == 4 || reason == 5) && g_gunLost.shots < 2) { InterlockedIncrement(&g_gunLost.shots); shot_request(); }
}
static int g_pkeHook;   // 0.94 PKE hooks: 1 installed, 0 not yet, <0 why not
// 1.7.18 RIGEVENT: how far the right wrist falls short of the controller, kept per kind of moment, so the next log shows exactly in which situation the rig slips
// (the 1.7.16 log had the numbers for the whole run only: three clusters of 1.7-8.4 ft that I could tie to the menu and the lowered height only by their line numbers).
enum { kRigNormal = 0, kRigMenu, kRigPke, kRigFire, kRigForced, kRigKinds };
static struct { volatile LONG n, over10cm, over30cm, over100cm, maxCm; volatile LONGLONG sumCm; } g_rigEv[kRigKinds];
static const char* const kRigEvName[kRigKinds] = {"normal play", "menu open", "PKE in hand", "trigger/bumper held (firing, capture)", "the game is moving you (forced)"};
static void rig_event_sample() {
  if (!g_ctl.probeData) return;
  float m[3];
  if (!arms_gun_miss(m)) return;
  int b = kRigNormal;
  if (vrmenu_is_open()) b = kRigMenu;
  else if (g_forced.forced) b = kRigForced;
  else if (pke_item_held()) b = kRigPke;
  else { pad::State ps; if (controllers_pad_state(&ps) && ((ps.buttons & 0x0100) || ps.rt > 40 || ps.lt > 40)) b = kRigFire; }
  const double ft = vm::dsqrt((double)m[0] * m[0] + (double)m[1] * m[1] + (double)m[2] * m[2]);
  const LONG cm = (LONG)(ft * 30.48);
  InterlockedIncrement(&g_rigEv[b].n);
  InterlockedAdd64(&g_rigEv[b].sumCm, cm);
  if (cm > 10) InterlockedIncrement(&g_rigEv[b].over10cm);
  if (cm > 30) InterlockedIncrement(&g_rigEv[b].over30cm);
  if (cm > 100) InterlockedIncrement(&g_rigEv[b].over100cm);
  if (cm > g_rigEv[b].maxCm) g_rigEv[b].maxCm = cm;
}
static void cine_report(LONG frame) {
  log_line("CUTHOLD frame=%d wait=%d ms cut_fade=%d | holds %ld, cutscene shots kept on the 2D screen %ld (longest %.2f s), full waits %ld, ended by the stick %ld, no wait after the pause menu / lost tracking %ld, no wait after a short 2D blip %ld | jumps in 3D shown through black %ld (jumps seen %d)",
           (int)frame, (int)g_ctl.cutHoldMs, (int)g_ctl.cutFade, g_cutHold.holds, g_cutHold.shortShots, g_cutHold.longestShort, g_cutHold.fullWaits, g_cutHold.byInput, g_cutHold.byMenu, g_cutHold.byQuick, g_cutFades, g_forced.jumpsAll);
  log_line("CINESUM frame=%d cine_guard=%d | engaged %d times (by a long forced move %d, by a jump %d), %.1f s in all, longest %.1f s, blend now %.2f | camera frames %ld, with the game in charge %ld | the probe left alone: body %ld, pack %ld, hose %ld, gun %ld; eased (mixed) %ld; arm passes skipped %ld | forced-move detector: %d events, %d jumps, longest speed %.1f ft/s (1.7.26: no cutscene flag is known in the game, so this follows the game moving the character by force)",
           (int)frame, (int)g_ctl.cineGuard, g_cine.events, g_cine.byMove, g_cine.byJump, g_cine.activeTotal, g_cine.longest, cine_blend(), g_cineSt.frames, g_cineSt.frames1,
           g_cineSt.bodyPass, g_cineSt.packPass, g_cineSt.hosePass, g_cineSt.wandPass, g_cineSt.mixed, g_cineSt.armSkips, g_forced.events, g_forced.teleports, g_forced.maxSpeed);
}
static void rig_event_report(LONG frame) {
  char buf[900]; int o = 0;
  for (int i = 0; i < kRigKinds; ++i) {
    const LONG n = g_rigEv[i].n;
    o += wsprintfA(buf + o, "%s[%s: %ld passes, mean %ld cm, worst %ld cm, over 10 cm %ld, over 30 cm %ld, over 1 m %ld]", i ? " " : "", kRigEvName[i], (long)n, n ? (long)(g_rigEv[i].sumCm / n) : 0L, (long)g_rigEv[i].maxCm,
                   (long)g_rigEv[i].over10cm, (long)g_rigEv[i].over30cm, (long)g_rigEv[i].over100cm);
    if (o > 760) break;
  }
  log_line("RIGEVENT frame=%d how far the right wrist stays from your controller, by kind of moment: %s", (int)frame, buf);
}

static GBVR_NOINLINE int pke_place(uint8_t* self, int site);
static int pke_hold_locked_settled();
static int pke_hold_locked();   // 1.7.76: the PKE grip has been taken from a steady hold
static int pke_align_vectors(double* vh, double* ph);   // 1.7.104: the PKE's long axis and centre in the hand's own axes, from the locked hold
static struct { volatile LONG frozenPasses, freePasses, animFingers; int64_t logQ; volatile LONG logs; } g_pctl;   // 1.7.76 PKECTL counters
// 1.7.76: the controller frame the LAST right-arm solve was made for (and when); the PKE is placed through the hand of that solve, so every other placement (the game's update, its
// collect) first moves the hand the way the controller has moved since (the hand is tied to it), instead of using a hand that is one frame old (the "dragged" meter)
static struct { float m[16]; int64_t q, aimQ; } g_solveTrk, g_solveTrkPend;
static int64_t g_pkAimQ;   // the controller sample time of the placement in progress (pke_place -> pke_place_locked)
struct AdvStats { volatile LONG advanced, sameSample, tooOld, noFrame; double lastCm, maxCm, sumCm, sumAgeMs, maxAgeMs; };
static AdvStats g_pAdv, g_gAdv;   // PKE placements / gun placements
static struct { volatile LONG used, notLocked, over3cm; double sumCm, maxCm, lastCm, maxAx; } g_gCtl;   // 1.7.78: gun placed on the controller through the locked hand relation
// 1.7.77: the hand of the last right-arm solve, moved on the way the controller has moved since that solve (the hand is tied to the controller). 1 = hand changed.
// The 1.7.76 PKE log: on average 6 cm of controller movement between the solve and the placement, so the gun (placed from the same hand) trailed by as much (more in fast moves).
static int hand_advance(float* hand, const float* grip, const float* dir, const float* up, int64_t aimQ, AdvStats& st) {
  if (!g_solveTrk.q) return 0;
  const double age = (double)(qpc_now() - g_solveTrk.q) / (double)qpc_freq();
  if (age > 0.15) { InterlockedIncrement(&st.tooOld); return 0; }
  if (aimQ && aimQ == g_solveTrk.aimQ) { InterlockedIncrement(&st.sameSample); return 0; }
  float nowT[16], relT[16], adv[16];
  if (!(handprop::tracked_frame(grip, dir, up, nowT) && handprop::rel_pos_delta(nowT, g_solveTrk.m) < 3.0 && handprop::relative(hand, g_solveTrk.m, relT) && handprop::place(relT, nowT, adv))) { InterlockedIncrement(&st.noFrame); return 0; }
  const double cm = handprop::rel_pos_delta(adv, hand) * 30.48;
  st.lastCm = cm; st.sumCm += cm; if (cm > st.maxCm) st.maxCm = cm;
  st.sumAgeMs += age * 1000.0; if (age * 1000.0 > st.maxAgeMs) st.maxAgeMs = age * 1000.0;
  for (int i = 0; i < 16; ++i) hand[i] = adv[i];
  InterlockedIncrement(&st.advanced);
  return 1;
}

// 1.7.104 LEFTHAND data: how steady the left hand's place along the barrel is while it supports the gun (standing 0 / walking 1). "old" = measured from the gun's last placement (what 1.7.103 did),
// "new" = measured from the same moment as the controllers (steady foregrip), "kept" = after the small smoothing that is applied on top.
static struct {
  long n[2]; double stepOld[2], stepNew[2], stepKept[2], maxOld[2], maxNew[2], maxKept[2], diffSum[2], diffMax[2];
  double prevOld, prevNew, prevKept; int havePrev; long offPasses;
} g_fg;
// 1.7.105 GRAB data: the fore grab (the left hand taking hold of the gun): how often it took hold / let go, why, how long it held, where on the gun, and what the gun was (item, length) each time
static struct {
  long grabs, releasesFar, releasesGrip, modelResets, slides, heldPasses, passes, busyPasses, nearPasses, nearHist[8]; double fracSum; long fracN; double lastFrac, lastL; int lastItem; int64_t onQ; double heldS, longestS;
} g_grab;
// Proximity contact already attaches the visible hand without a grip button.
// Publish that contact for two-hand steadiness on every controller. Expire it if
// rendering/IK stops; the controller poll never holds a stale contact forever.
alignas(8) static volatile LONG64 g_foreSupportQ;
int engine_offhand_support() {
  const int64_t q = InterlockedCompareExchange64(&g_foreSupportQ, 0, 0);
  return q > 0 && aim::is_fresh(qpc_now(), q, qpc_freq(), 120);
}
static GBVR_NOINLINE void arm_drive(uintptr_t actor, const float* W2, const float* origBody, const BodyExtra* bx) {
  g_solveTrkPend.aimQ = 0;   // 1.7.77
  InterlockedIncrement(&g_adCalls);
  ArmTargets t;
  int wandRead = 0;   // 0.90: the game's wand matrix was copied into t.wandM (0.85 tested wandM[15] != 0, but that column is not a valid number in the game's matrices: the PKE never went to the hand)
  char* z = (char*)&t;
  for (size_t i = 0; i < sizeof(t); ++i) z[i] = 0;
  const int64_t now = qpc_now();
  t.mirrorArms = (controllers_left_applied() && g_ctl.leftHandDraw) ? 1 : 0;   // 1.7.174: left-handed: each arm is DRAWN at the other controller (armcore.h display_arm); left_hand_draw=0 = the 1.7.169 look (the right arm reaches across)
  ArmStereo draw;
  if (draw_stereo(&draw) && g_ctl.pairHands) { t.stereoPair = draw.pairQ; t.stereoRole = draw.pairRole; }
  static struct { int64_t pair; uintptr_t actor; ArmTargets t; } targetPair;
  if (t.stereoPair && targetPair.pair == t.stereoPair && targetPair.actor == actor) {
    InterlockedIncrement(&g_adPaired);
    ArmTargets paired = targetPair.t;
    paired.stereoRole = t.stereoRole;
    arms_apply(actor, W2, &paired);
    return;
  }
  int noGunEquipped = 0;
  { int st8[8], cur8 = -1; const int fresh8 = fight_items(st8, &cur8); t.itemId = cur8; noGunEquipped = (fresh8 && cur8 == 0) ? 1 : 0; }   // 1.7.119: the same "nothing equipped" the gun gate uses
  int gr = 0;   // 0.97: why the gun hand had no target (1 probe hooks off, 2 gun holstered, 3 hand aim stale, 4 wand matrix unreadable, 5 no solution); 0 = it has one
  if (g_ctl.gamePlace) gr = 6;   // 1.7.13: the game's own animation holds the gun: no right-hand target
  else if (!(g_ctl.realModels && g_ctl.wandToHand && g_wandHook == 1 && g_tipHook == 1)) gr = 1;
  else if (noGunEquipped) {
    gr = 7;
    static LONG s_noGunLogs;
    if (InterlockedIncrement(&s_noGunLogs) <= 3) {   // data for a report: what the game's wand matrix holds while nothing is equipped
      const float* Wm = (const float*)((const uint8_t*)actor + layout::kOffWandWorld);
      float m[4] = {0, 0, 0, 0};
      if (memory_readable(Wm, 64)) { m[0] = Wm[0]; m[1] = Wm[5]; m[2] = Wm[10]; m[3] = Wm[12]; }
      log_line("ARMNOGUN #%ld nothing is equipped (no pack / wand): the right hand follows the controller alone; the game's wand matrix holds diag %.2f/%.2f/%.2f x %.1f (a stale one is what broke the arm)", (long)s_noGunLogs, m[0], m[1], m[2], m[3]);
    }
  }
  else {   // 1.7.25: also while the gun is holstered: the right arm keeps following the right controller (it used to stay in the animation: 'it makes the right arm not work')
    uintptr_t pa = 0; float dir[3], grip[3], wup[3]; int64_t q = 0;
    if (!(wand_aim_read(&pa, dir, grip, &q, wup) && pa == actor && aim::is_fresh(now, q, qpc_freq(), 250))) gr = 3;
    else {
      const float* Wm = (const float*)((const uint8_t*)actor + layout::kOffWandWorld);
      int fin = memory_readable(Wm, 64);
      for (int i = 0; fin && i < 16; ++i) if (!vm::is_finite_f(Wm[i])) fin = 0;
      if (!fin) gr = 4;
      if (fin) {
        for (int i = 0; i < 16; ++i) t.wandM[i] = Wm[i];   // 0.85
        wandRead = 1;
        float tipm[16];
        o_attach((void*)actor, tipm, "tip");
        wand::Solve ws;
        if (wand::solve(Wm, tipm, grip, dir, &ws, wand_up_arg(wup), wand_roll_rad()) &&
            (ws.shiftFt <= 12.0f || (engine_scene_arms(actor) && g_sceneStation.have && sceneview::nearby_rig(grip, Wm + 12, g_sceneStation.delta)))) {
          t.rightOn = 1;
          for (int i = 0; i < 9; ++i) t.wandR[i] = ws.R[i];
          for (int i = 0; i < 3; ++i) { t.wandP0[i] = Wm[12 + i]; t.grip[i] = grip[i]; }
          t.gunLenFt = (double)ws.gripToTipFt * (g_ctl.viewModelPct >= 80 && g_ctl.viewModelPct <= 200 ? 0.01 * (double)g_ctl.viewModelPct : 1.0);   // 0.81
          {   // 0.79: the controller's own pointing direction and up (game world), for a hand that is not on the animation's grip
            double d3[3] = {dir[0], dir[1], dir[2]}, u3[3] = {wup[0], wup[1], wup[2]};
            if (arm::unit(d3, d3) && arm::unit(u3, u3)) { t.rdirOk = 1; for (int i = 0; i < 3; ++i) { t.rdir[i] = d3[i]; t.rup[i] = u3[i]; } }
          }
          if (handprop::tracked_frame(grip, dir, wup, g_solveTrkPend.m)) g_solveTrkPend.aimQ = q;   // 1.7.77: the controller frame this solve is made for (the gun is placed through its hand)
        } else gr = 5;
      }
    }
  }
  // 0.97: the game's PKE is in the hand and was moved to the controller: the avatar's right hand holds it there. (0.96: no right-arm target while the PKE was out - the arm stayed in the animation.)
  const int pkeGameOn = (!g_ctl.gamePlace && g_ctl.pkeGame && g_pkeHook == 1 && pke_item_held()) ? 1 : 0;
  if (pkeGameOn) {
    if (memory_readable((const void*)(actor + layout::kOffPlayerPke), 8))
      pke_place(*(uint8_t* const*)(actor + layout::kOffPlayerPke), 3);
    // 1.7.62: hand drives PKE, never PKE drives hand.  Throw away any wand
    // animation target while the meter is out; the bootstrap below puts the
    // actual rendered GAME hand on the tracked controller first.
    t.rightOn = 0;
  }
  else if (gr >= 3 && gr != 6 && gr != 7) gunhand_lost(gr);   // the gun is drawn at the controller but the avatar's hand has nothing to hold it with: that is "the gun falls out of the hand"
  // Bootstrap/maintain the VR GAME hand before exact gun/PKE placement needs it.
  // PKE is allowed even though the blaster is holstered: the hand must keep moving.
  if (!t.rightOn && !g_ctl.gamePlace && (pkeGameOn || gr == 7 || (!controllers_holstered() && gr >= 3))) {
    uintptr_t pa = 0; float dir[3], grip[3], up[3]; int64_t q = 0;
    if (wand_aim_read(&pa, dir, grip, &q, up) && pa == actor && aim::is_fresh(now, q, qpc_freq(), 120)) {
      t.rightOn = 1; t.rdirOk = 1; t.gunLenFt = 0.0;
      t.wandR[0] = t.wandR[4] = t.wandR[8] = 1.0;
      for (int i = 0; i < 3; ++i) { t.grip[i] = grip[i]; t.wandP0[i] = grip[i]; t.rdir[i] = dir[i]; t.rup[i] = up[i]; }
      if (handprop::tracked_frame(grip, dir, up, g_solveTrkPend.m)) g_solveTrkPend.aimQ = q; else g_solveTrkPend.aimQ = 0;   // 1.7.76/1.7.77
    }
  }
  if (pkeGameOn && g_ctl.pkeCtlRigid && t.rightOn && t.rdirOk && pke_hold_locked_settled()) { t.handFreeze = 1; InterlockedIncrement(&g_pctl.frozenPasses); }   // 1.7.76
  t.gunLiveOpen = 0.01 * (double)g_ctl.gunFingerOpenPct;
  t.pkeCentre = g_ctl.pkeCentre ? 1 : 0;   // 1.7.158
  t.pkePitchDeg = g_ctl.pkeAlignPitch ? (double)g_ctl.pkePitchDeg : 1.0e9;
  t.pkeTurnMaxDeg = (double)g_ctl.pkeTurnMaxDeg;
  t.pkeEaseS = 0.001 * (double)g_ctl.pkeEaseMs;
  if (t.handFreeze && g_ctl.pkeAlign) { double vh[3], ph[3]; if (pke_align_vectors(vh, ph)) { t.pkeAlign = 1; for (int i = 0; i < 3; ++i) { t.pkeVh[i] = vh[i]; t.pkePh[i] = ph[i]; } } }   // 1.7.104
  else if (pkeGameOn) InterlockedIncrement(&g_pctl.freePasses);
  float fpm = 1.0f;
  if (g_ctl.armIk == 1 && !g_ctl.gamePlace) {   // 1.7.13: with the game placing the gun the left hand is the game's too
    for (int tries = 0; tries < 3; ++tries) {
      LONG s0 = g_headAim.seq;
      if (s0 & 1) continue;
      uintptr_t pa = g_headAim.actor;
      int has = g_headAim.hasLeft;
      float lp[3], lf[3], lu[3];
      for (int i = 0; i < 3; ++i) { lp[i] = g_headAim.lpos[i]; lf[i] = g_headAim.lfwd[i]; lu[i] = g_headAim.lup[i]; }
      fpm = g_headAim.fpm;
      int64_t q = g_headAim.qpc;
      if (g_headAim.seq != s0) continue;
      if (has && pa == actor && aim::is_fresh(now, q, qpc_freq(), 250)) {
        double f[3] = {lf[0], lf[1], lf[2]}, u[3] = {lu[0], lu[1], lu[2]};
        if (arm::unit(f, f) && arm::unit(u, u)) {
          t.leftOn = 1;
          for (int i = 0; i < 3; ++i) { t.lpos[i] = lp[i]; t.lfwd[i] = f[i]; t.lup[i] = u[i]; }
          {   // 1.7.211 TRAPROLL: holding the ghost trap the off-hand glove is turned to the player's right about the handle line (the controller's up; eased in/out). The trap itself keeps the raw controller pose (it reads g_headAim, not this).
            static double s_trapRoll; static int64_t s_trapRollQ; static int s_trN;
            const int64_t qr = qpc_now();
            double dtr = s_trapRollQ ? (double)(qr - s_trapRollQ) / (double)qpc_freq() : 0.0;
            if (dtr < 0.0) dtr = 0.0; if (dtr > 0.1) dtr = 0.1;
            s_trapRollQ = qr;
            const double tgtR = controllers_trap_held() ? 30.0 : 0.0;
            s_trapRoll += (tgtR - s_trapRoll) * (dtr > 0.0 ? dtr / (0.12 + dtr) : 0.0);
            if (s_trapRoll < 0.05) s_trapRoll = 0.0;
            if (s_trapRoll > 0.0) {
              const double sd[3] = {f[1] * u[2] - f[2] * u[1], f[2] * u[0] - f[0] * u[2], f[0] * u[1] - f[1] * u[0]};   // numerically the player's LEFT (game world is left-handed)
              double sR, cR; vm::dsincos(s_trapRoll * vm::kPi / 180.0, &sR, &cR);
              for (int i = 0; i < 3; ++i) t.lfwd[i] = f[i] * cR - sd[i] * sR;   // 1.7.212: turned about the controller's UP line (= the handle line, the trap hangs along it), so the fist stays ON the handle; FLIP the '-' to '+' if the glove turns to the left
              if (s_trN < 30 && (s_trN++ % 60) == 0) log_line("TRAPROLL off-hand glove turned %.1f deg to the right about the handle line while the trap is held (up %.2f,%.2f,%.2f | pointing %.2f,%.2f,%.2f -> %.2f,%.2f,%.2f)", s_trapRoll, u[0], u[1], u[2], f[0], f[1], f[2], t.lfwd[0], t.lfwd[1], t.lfwd[2]);
            }
          }
        }
      }
      break;
    }
  }
  if (!(fpm > 0.1f && fpm < 100.0f)) fpm = 3.28084f;
  t.wristBackFt = 0.01 * (double)g_ctl.armWristCm * fpm;
  t.wristDownFt = 0.02 * fpm;
  // 1.7.58: no guessed wrist setback for a held prop.  The final right-hand bone itself is the anchor;
  // the gun/PKE takes the exact hand-to-prop relationship from the game's untouched pose.
  t.gunWristBackFt = 0.0;
  t.gunWristDownFt = 0.0;
  if (g_gunPlacedAt && (double)(qpc_now() - g_gunPlacedAt) / (double)qpc_freq() < 0.1) { t.gunPosOk = 1; for (int i = 0; i < 3; ++i) t.gunPos[i] = (double)g_gunPlaced[i]; }   // 1.7.7: where the gun really is, for the left hand's foregrip
  double gunOld[3] = {t.gunPos[0], t.gunPos[1], t.gunPos[2]}; const int gunOldOk = t.gunPosOk;   // 1.7.104
  if (g_ctl.foreSteady && t.rightOn && t.rdirOk) {   // 1.7.104 STEADY FOREGRIP: the gun's own place comes from the last placement, the left hand from the newest controller sample: walking or sprinting moves the world between the two (several cm per frame), so the hand slid back and forth along the barrel. The gun's place is now rebuilt from the controller of THIS sample and the gun's fixed offset to it (averaged over time).
    static foregrip::Offsets s_go; static int64_t s_goQ;
    const int64_t pq = g_gunPlacedAt;
    if (!pq || (double)(now - pq) / (double)qpc_freq() > 0.5) s_go.have = 0;
    else if (pq != s_goQ) {
      s_goQ = pq;
      const double gr[3] = {g_gunPlacedGrip[0], g_gunPlacedGrip[1], g_gunPlacedGrip[2]}, di[3] = {g_gunPlacedDir[0], g_gunPlacedDir[1], g_gunPlacedDir[2]}, up[3] = {g_gunPlacedUp[0], g_gunPlacedUp[1], g_gunPlacedUp[2]}, gn[3] = {g_gunPlaced[0], g_gunPlaced[1], g_gunPlaced[2]};
      foregrip::learn(&s_go, gr, di, up, gn, 0.12);
    }
    double gp[3];
    if (foregrip::place(&s_go, t.grip, t.rdir, t.rup, gp)) { for (int i = 0; i < 3; ++i) t.gunPos[i] = gp[i]; t.gunPosOk = 1; }
  }
  t.foreSteady = g_ctl.foreSteady ? 0.6 : 0.0;
  t.rightEmpty = (g_ctl.emptyFingers && (controllers_holstered() || !engine_gun_placed(0.25))) ? 1 : 0;   // 1.7.104: nothing in the right hand: its fingers follow the controller
  t.elbowDown = 0.01 * (double)g_ctl.armElbowDown;
  t.stretchMax = g_ctl.armStretchPct > 100 ? 0.01 * (double)g_ctl.armStretchPct : 1.0;
  t.armLenBase = g_ctl.armReachPct > 100 ? 0.01 * (double)g_ctl.armReachPct : 1.0;   // 1.7.69: elbow room
  t.handClean = g_ctl.handClean ? 1 : 0;   // 1.7.70
  t.forearmTwist = 0.01 * (double)g_ctl.forearmTwistPct;   // 0.77
  if (bx && bx->on && g_ctl.fullBody) {
    t.bodyOn = 1;
    for (int i = 0; i < 3; ++i) t.headDelta[i] = bx->lean[i];
    for (int i = 0; i < 9; ++i) t.hmdBasis[i] = bx->view[i];
    t.bodyYaw = bx->yaw;
    t.leanMaxDeg = (double)g_ctl.bodyLeanDeg; t.headMaxDeg = (double)g_ctl.bodyHeadDeg;
    t.bendFrac = 0.01 * (double)g_ctl.bodyBendPct; t.bendMaxDeg = (double)g_ctl.bodyBendMaxDeg;
    t.dropMaxFt = 0.01 * (double)g_ctl.bodyDropCm * 3.28084;
    t.crouchOn = (g_ctl.bodyCrouch != 0 && !g_ctl.seated) ? 1 : 0;   // 1.7.19: sitting down is not a crouch
    // 0.68
    if (g_ctl.bodyEyeAlign && bx->eyeOk) { t.eyeOn = 1; for (int i = 0; i < 3; ++i) t.eyeTarget[i] = bx->eye[i]; }
    t.fade = bx->fade;
    t.eyeSampleBlock = (g_forced.forced || cine_blend() >= 0.01 || controllers_move_mag() >= 150 || controllers_fire_hold_active()) ? 1 : 0;   // 1.7.181
    t.shiftCapFt = 0.01 * (double)g_ctl.eyeShiftCapCm * 3.28084;
    { const double lg = vm::dabs(eye_lag_ft()); if (lg > 0.02 && lg < 1.5) { t.shiftCapFt += lg; InterlockedIncrement(&g_stepCapRaised); } }   // 1.7.186: while the eye is eased away from the feet the body may follow it that much further (the arms no longer stretch to the hands on a step)
    t.slideCapFt = 0.45;
    {   // 1.7.29 calm walking: once per game frame the time since the previous one; the torso pass steps its filter once per frame
      static int64_t s_calmFrame = -1; static int64_t s_calmQ; static double s_calmDt;
      const int64_t wf = t.stereoPair ? t.stereoPair : (int64_t)g_ctl.worldFrames;
      if (wf != s_calmFrame) { s_calmFrame = wf; s_calmDt = s_calmQ ? (double)(now - s_calmQ) / (double)qpc_freq() : 0.0; s_calmQ = now; }
      t.calmTauS = 0.001 * (double)g_ctl.bodyCalmMs; t.calmDtS = s_calmDt; t.calmSeq = wf;
    }
    t.crouchDeadFt = 0.01 * (double)g_ctl.crouchDeadCm * 3.28084;
    t.shoulderPullDeg = (double)g_ctl.shoulderPullDeg;
    t.shoulderSlideFt = 0.01 * (double)g_ctl.shoulderSlideCm * (double)fpm;   // 0.74
  }
  // 0.75: the game's own (unmoved) body matrix. The hand's place in the game's pose is measured through it, so it is in the same
  // world as the wand and the controller grip (0.74 measured the hand in the moved, scaled body, 25 cm from the wand: that was the loose gun).
  if (origBody) { t.origOn = 1; for (int i = 0; i < 16; ++i) t.origBody[i] = origBody[i]; }
  if (bx && bx->on && g_ctl.fullBody) {
    t.viewDownFt = -0.01 * (double)g_ctl.bodyHeightCm * (double)fpm;   // 0.75: the view is higher = the body's eyes target lower
    t.bodyOutFt = 0.01 * (double)g_ctl.bodyOutCm * (double)fpm;
    t.downBackFt = 0.01 * ((double)g_ctl.bodyDownBackCm + (engine_scene_arms(actor) && g_sceneStation.have ? (double)g_ctl.stationBackCm : 0.0)) * (double)fpm;   // 1.7.168; 1.7.169: more on the rooftop (the view looks 86 deg down there: the shoulders filled the bottom of the view)   // 0.75: the whole avatar stands further out in front
  }
  t.fpm = (double)fpm; t.rigOn = (g_ctl.rigView != 0 || (g_ctl.armsOnly && g_ctl.armsStraps)) ? 1 : 0;   // 0.74
  const int sceneArms = engine_scene_arms(actor) || engine_player_downed();   // 1.7.197: a dying player is drawn like the roof fight: floating arms, no body
  t.armsOnly = (g_ctl.armsOnly && g_ctl.armIk == 1) || sceneArms ? 1 : 0;
  t.hidePke = ((!g_ctl.gamePlace && g_ctl.pkeOwn && pke_item_held()) || g_ctl.hideBeltPke) ? 1 : 0;   // 1.7.64: hide_belt_pke squashes the belt copy (cloth_pke, cloth_pke1) of the PKE   // 0.93: the game's PKE bones (cloth_pke) are squashed, the probe draws its own
  t.gripAtHand = g_ctl.gripAtHand ? 1 : 0;   // 0.93
  t.gripMagnet = g_ctl.leftGripPct > 0 ? 0.01 * (double)g_ctl.leftGripPct : 0.0;
  static float s_underW;   // 1.7.19: eases in and out so the hand glides onto the barrel instead of jumping
  int leftOnGun = 0;
  int dbgNear = 0; double dbgPerpCm = -1.0, dbgDistCm = -1.0;   // 1.7.200: values for the SCENELEFT log line only
  {
    HandsRaw hu;
    // 1.7.114 FORE NEAR (fore_near_cm): a free left hand that comes within that many cm of the barrel takes hold of it by itself (no grip squeeze needed), and lets go again when it leaves (1.4 x the distance). 0 = off.
    // 1.7.116: the rule is foregrabmath.h near_step() (unit-tested: units, hysteresis at the reach and at both ends of the barrel). NEARHAND logs where a free hand hangs.
    static int s_nearOn; int nearLock = 0, nearHave = 0; double nearAlong = 0.0, nearPerp = 0.0;
    if (g_ctl.foreNearCm > 0 && t.leftOn && t.rightOn && t.rdirOk && t.gunPosOk && t.gunLenFt > 0.2) {
      foregrab::hand_vs_barrel(t.lpos, t.gunPos, t.rdir, &nearAlong, &nearPerp); nearHave = 1;
      s_nearOn = foregrab::near_step(s_nearOn, nearAlong, nearPerp, t.gunLenFt, foregrab::cm_to_ft((double)g_ctl.foreNearCm, (double)fpm));   // 1.7.197: in the roof fight the free hand snaps from farther (32 cm), the floating arms hang away from the gun
      nearLock = s_nearOn; dbgNear = s_nearOn; dbgPerpCm = foregrab::ft_to_cm(nearPerp, (double)fpm);
    } else s_nearOn = 0;
    const int gunOk = g_ctl.leftUnder && !g_ctl.gamePlace && t.rightOn && controllers_raw(&hu) && hu.validL && hu.validR && !hu.trapHeld && !pke_item_held() && !controllers_holstered() && engine_gun_placed(0.25);   // 1.7.103: only with the gun really drawn at the right hand
    leftOnGun = gunOk && (hand::support_requested(hu.gripL, nearLock, g_ctl.twoHandLine));   // 1.7.200: in the roof fight the free hand also latches to the gun by nearness alone (nearLock already has its own in/out margin, so it cannot flicker)
    if (gunOk && nearHave && !hu.gripL) {   // a FREE hand with the gun drawn: how far from the barrel it hangs while it is along the gun (NEARHAND, 30 s), and the passes the near rule alone put it on the gun
      if (foregrab::in_zone(nearAlong, t.gunLenFt, s_nearOn)) ++g_grab.nearHist[foregrab::near_bucket(foregrab::ft_to_cm(nearPerp, (double)fpm))];
      if (nearLock) ++g_grab.nearPasses;
    }   // 1.7.103: only with the gun really drawn at the right hand (a squeezed left grip with the gun on the back, no weapon or the PKE out used to bend the left hand onto a gun that is not there)
    static int64_t s_underQ; const int64_t nq = qpc_now();
    double dtu = s_underQ ? (double)(nq - s_underQ) / (double)qpc_freq() : 0.0; if (dtu < 0.0) dtu = 0.0; if (dtu > 0.1) dtu = 0.1; s_underQ = nq;
    const double tau = leftOnGun ? 0.10 : 0.16;
    const double ku = dtu > 0.0 ? dtu / (tau + dtu) : 0.0;
    s_underW = (float)(s_underW + ((leftOnGun ? 1.0f : 0.0f) - s_underW) * ku);
    if (s_underW < 0.002f) s_underW = 0.0f;
    const double kfp = (double)fpm / 3.28084;   // 1.7.110: real distances (cm) become game feet through the world size, not a fixed 30.48
    t.underW = (double)s_underW; t.underFt = (double)g_ctl.leftUnderCm * 0.01 * (double)fpm;
    {   // 1.7.105 FORE GRAB: squeeze the left grip with the hand near the barrel and the hand takes hold of the gun and stays on it (see foregrabmath.h); it follows the gun as the gun changes
      const int64_t nowg = qpc_now(); static foregrab::State s_gs; static double s_gDelta, s_gW; static int s_gItem = -2; static double s_gL; static int64_t s_gQ; static int s_gOnPrev, s_gHeldPrev;
      double dtg = s_gQ ? (double)(nowg - s_gQ) / (double)qpc_freq() : 0.0; if (dtg < 0.0) dtg = 0.0; if (dtg > 0.1) dtg = 0.1; s_gQ = nowg;
      static double s_busy;   // 1.7.110 how much the world moves under the two hands: the left stick (walking) or your own right-stick turn; fast up, slow down. Turning rotates the world between the left hand's and the gun's samples (like walking moved it) and shook the supporting hand.
      {
        int um = 0, bl = 0; controllers_turn_info(&um, &bl);
        const double wk = controllers_move_mag() / 700.0, tn = bl ? 0.0 : um / 400.0;
        double tgt = wk > tn ? wk : tn; if (tgt > 1.0) tgt = 1.0;
        const double kb = tgt > s_busy ? dtg / (0.05 + dtg) : dtg / (0.40 + dtg);
        s_busy += (tgt - s_busy) * kb;
        if (s_busy < 0.002) s_busy = 0.0;
      }
      const int can = g_ctl.foreGrab && leftOnGun && t.leftOn && t.rightOn && t.rdirOk && t.gunPosOk && t.gunLenFt > 0.2;
      ++g_grab.passes;
      if (can) {
        int st8[8] = {0}, cur = -1; fight_items(st8, &cur);
        const double L = t.gunLenFt;
        if (s_gs.have && ((cur >= 0 && s_gItem >= 0 && cur != s_gItem) || vm::dabs(L - s_gL) > 0.12 * s_gL)) {   // another weapon or another model of it (an upgrade): the old grip point means nothing on it, take hold again
          ++g_grab.modelResets;
          if (g_grab.modelResets <= 40) log_line("GRAB the gun changed (item %d -> %d, length %.2f -> %.2f ft): the old grip point is dropped, the next squeeze takes hold on the new gun", s_gItem, cur, s_gL, L);
          s_gs.have = 0; s_gs.on = 0;
          // The next firing style has its own native offhand pose. Start its
          // blend from the free hand rather than applying the old style at full
          // weight for the first frame of the switch.
          s_gW = 0.0; s_gDelta = 0.0; s_gOnPrev = 0;
        }
        s_gItem = cur; s_gL = L; g_grab.lastItem = cur; g_grab.lastL = L;
        foregrab::Params gpar = foregrab::defaults(); gpar.deadFt *= kfp * (1.0 + 1.8 * s_busy); gpar.grabFt *= kfp; gpar.releaseFt *= kfp;   // 1.7.200: a wider reach for the floating arms of the roof fight   // 1.7.110: the dead zone and the reach follow the world size
        foregrab::Out o = foregrab::step(&s_gs, 1, t.lpos, t.gunPos, t.rdir, t.rup, L, t.underFt, gpar);
        dbgDistCm = o.dist * 30.48;
        if (o.on && !s_gOnPrev) {
          ++g_grab.grabs; g_grab.onQ = nowg; g_grab.lastFrac = o.along / L; g_grab.fracSum += o.along / L; ++g_grab.fracN;
          haptics_add(0, hap::kSrcMark, 0.30f, 35);   // a small tick in the left hand: you have hold of it
          if (g_grab.grabs <= 40) log_line("GRAB took hold: %.0f%% of the way along the gun (%.1f cm from its origin, gun %.1f cm long, item %d), real hand %.1f cm from the grip point", 100.0 * o.along / L, o.along * 30.48, L * 30.48, cur, o.dist * 30.48);
        } else if (!o.on && s_gOnPrev) {
          ++g_grab.releasesFar; const double hs = g_grab.onQ ? (double)(nowg - g_grab.onQ) / (double)qpc_freq() : 0.0; g_grab.heldS += hs; if (hs > g_grab.longestS) g_grab.longestS = hs;
          if (g_grab.releasesFar <= 40) log_line("GRAB let go: the real hand is %.1f cm from the grip point (held %.1f s)", o.dist * 30.48, hs);
        }
        if (o.on) { const double d = o.along - o.alongReal; if (vm::dabs(d - s_gDelta) > 0.02 && vm::dabs(o.along - g_grab.lastFrac * L) > 0.05) ++g_grab.slides; if (s_gW < 0.02) s_gDelta = d; else s_gDelta += (d - s_gDelta) * (dtg / (0.03 + 0.22 * s_busy + dtg)); ++g_grab.heldPasses; if (s_busy > 0.3) ++g_grab.busyPasses; }
        else s_gDelta -= s_gDelta * (dtg / (0.12 + dtg));
        s_gOnPrev = o.on;
        const double tw = o.on ? 1.0 : 0.0, kw = dtg / ((o.on ? 0.10 : 0.15) + dtg);
        s_gW += (tw - s_gW) * kw;
      } else {
        if (s_gOnPrev) { ++g_grab.releasesGrip; const double hs = g_grab.onQ ? (double)(nowg - g_grab.onQ) / (double)qpc_freq() : 0.0; g_grab.heldS += hs; if (hs > g_grab.longestS) g_grab.longestS = hs; if (g_grab.releasesGrip <= 40) log_line("GRAB let go: grip released or the gun is not drawn (held %.1f s)", hs); }
        s_gs.have = 0; s_gs.on = 0; s_gOnPrev = 0;
        s_gDelta -= s_gDelta * (dtg / (0.12 + dtg));
        s_gW += (0.0 - s_gW) * (dtg / (0.15 + dtg));
      }
      if (s_gW < 0.002) s_gW = 0.0;
      if (vm::dabs(s_gDelta) < 1e-5) s_gDelta = 0.0;
      if (g_ctl.foreGrab && t.rdirOk && s_gDelta != 0.0) for (int i = 0; i < 3; ++i) t.lpos[i] += s_gDelta * t.rdir[i];
      t.grabOn = s_gOnPrev; t.grabW = g_ctl.foreGrab ? s_gW : 0.0;
      InterlockedExchange64(&g_foreSupportQ, t.grabOn && gunOk ? nowg : 0);
      {   // 1.7.110: the real hand's sideways place against the barrel line, smoothed (more while walking / turning): the wrapped hand goes round the barrel by it
        static double s_lx, s_ly; static int s_lHave;
        if (t.grabW > 0.01 && t.rdirOk && t.gunPosOk) {
          double rel[3], rt3[3]; for (int i = 0; i < 3; ++i) rel[i] = t.lpos[i] - t.gunPos[i];
          arm::cross(t.rdir, t.rup, rt3);
          const double lx = arm::dot(rel, rt3), ly = arm::dot(rel, t.rup);
          if (!s_lHave) { s_lx = lx; s_ly = ly; s_lHave = 1; }
          else { const double kk = dtg / (0.05 + 0.25 * s_busy + dtg); s_lx += (lx - s_lx) * kk; s_ly += (ly - s_ly) * kk; }
          t.grabLatOk = 1; t.grabLatX = s_lx; t.grabLatY = s_ly;
        } else s_lHave = 0;
      }
      t.grabOrbitDeg = (double)g_ctl.grabOrbitDeg; t.grabOrbitFollow = 0.01 * (double)g_ctl.grabOrbitFollowPct; t.grabWrap = g_ctl.grabWrap ? t.grabW : 0.0;   /* 1.7.210: the roof fight grips the barrel like normal play (the hand sits round the barrel at the right distance) */ t.grabWrapDeg = (double)g_ctl.grabWrapDeg; t.trigPullDeg = (double)g_ctl.trigFingerDeg;   // 1.7.109
    }
    {   // 1.7.104 the left hand's slide along the barrel: measured against the steady gun place, then a small smoothing (a thumb pushing the stick moves the real hand a little). The data of both ways of measuring is logged (LEFTHAND).
      static double s_af; static int s_afHave; static int64_t s_afQ;
      if (g_ctl.foreSteady && !g_ctl.foreGrab && s_underW > 0.3f && t.leftOn && t.rightOn && t.rdirOk && t.gunPosOk) {
        const int walk = controllers_move_mag() > 300 ? 1 : 0;
        double rel[3], relOld[3];
        for (int i = 0; i < 3; ++i) { rel[i] = t.lpos[i] - t.gunPos[i]; relOld[i] = t.lpos[i] - gunOld[i]; }
        const double along = arm::dot(rel, t.rdir), alongOld = gunOldOk ? arm::dot(relOld, t.rdir) : along;
        const double dtA = s_afQ ? (double)(now - s_afQ) / (double)qpc_freq() : 0.0;
        if (!s_afHave || dtA > 0.3 || dtA < 0.0) s_af = along;
        else { const double tau = walk ? 0.10 : 0.05; const double k = dtA / (tau + dtA); s_af += (along - s_af) * k; }
        s_afHave = 1; s_afQ = now;
        const double dAl = s_af - along;
        for (int i = 0; i < 3; ++i) t.lpos[i] += dAl * t.rdir[i];
        const double cm = 30.48;
        if (g_fg.havePrev) {
          const double a = vm::dabs(alongOld - g_fg.prevOld) * cm, b = vm::dabs(along - g_fg.prevNew) * cm, c = vm::dabs(s_af - g_fg.prevKept) * cm, dd = vm::dabs(alongOld - along) * cm;
          g_fg.stepOld[walk] += a; g_fg.stepNew[walk] += b; g_fg.stepKept[walk] += c; g_fg.diffSum[walk] += dd; ++g_fg.n[walk];
          if (a > g_fg.maxOld[walk]) g_fg.maxOld[walk] = a;
          if (b > g_fg.maxNew[walk]) g_fg.maxNew[walk] = b;
          if (c > g_fg.maxKept[walk]) g_fg.maxKept[walk] = c;
          if (dd > g_fg.diffMax[walk]) g_fg.diffMax[walk] = dd;
        }
        g_fg.prevOld = alongOld; g_fg.prevNew = along; g_fg.prevKept = s_af; g_fg.havePrev = 1;
      } else { s_afHave = 0; g_fg.havePrev = 0; if (leftOnGun) ++g_fg.offPasses; }
    }
  }   // 0.81: the left hand is drawn to the gun's foregrip
  if (pke_mode() && !sceneArms) {   // keep the scripted view's body out of sight even if the PKE is held
    t.armsOnly = 1; t.headOnly = 1;   // 0.82: the arms still follow your hands (the PKE is part of the hand), only the head is hidden
    InterlockedIncrement(&g_pke.armSkips);
  } else {   // 0.81 solid body: the gun hand and the left hand stay out of the torso
    double dl[3];
    if (t.rightOn) { const float g3[3] = {(float)t.grip[0], (float)t.grip[1], (float)t.grip[2]}; if (solid_delta(g3, dl)) for (int i = 0; i < 3; ++i) t.grip[i] += dl[i]; }
    if (t.leftOn) { const float l3[3] = {(float)t.lpos[0], (float)t.lpos[1], (float)t.lpos[2]}; if (solid_delta(l3, dl)) for (int i = 0; i < 3; ++i) t.lpos[i] += dl[i]; }
  }
  {   // 0.84 fingers: the trigger bends the index finger, the grip curls the others (eased, so they do not snap); the PKE bones follow the hand while the PKE is out
    HandsRaw hr;
    static float s_curl[2][5];
    static int64_t s_curlQ;

    if (g_ctl.fingers && g_ctl.armIk == 1 && !g_ctl.gamePlace && controllers_raw(&hr)) {
      const int64_t nq = qpc_now();
      double dt = s_curlQ ? (double)(nq - s_curlQ) / (double)qpc_freq() : 0.0;
      if (dt < 0.0) dt = 0.0;
      if (dt > 0.1) dt = 0.1;
      s_curlQ = nq;
      const int vh[2] = {hr.validR, hr.validL}, gr[2] = {hr.gripR, hr.gripL};
      const float tr[2] = {hr.trigR, hr.trigL};
      const int trapFist = (hr.trapHeld || controllers_trap_held()) ? 1 : 0;   // 1.7.209: the off hand holds the ghost trap: it makes a fist round the handle
      float leftWrap = 0.0f;   // 1.7.24: how far the left hand is on the gun (0..1), also decides how much the left thumb keeps the game's pose
      for (int h = 0; h < 2; ++h) {
        if (!vh[h]) { t.curl[h][0] = t.curl[h][1] = t.curl[h][2] = t.curl[h][3] = t.curl[h][4] = -1.0; continue; }
        // 1.7.17: an open hand is RELAXED (fingers a little curled, thumb a little in), not ruler-straight: the 1.7.16 pictures showed the left hand as a stiff open claw
        const float tg0 = tr[h] > 1.0f ? 1.0f : (tr[h] < 0.0f ? 0.0f : tr[h]);
        const float rest = (float)g_ctl.fingerRestPct * 0.01f;
        // 1.7.19: the 1.7.18 picture showed the left hand as a fist with ONE straight finger (index followed only the trigger). Now: a held grip curls every finger (index never below about half),
        // nothing closes past 0.92 (a tight fist looked like a claw), an open hand is a soft gradient (index least bent, pinkie most), and the left hand on the gun wraps around the barrel.
        // 1.7.23: the left hand's fingers blend smoothly between the relaxed / grip pose and the wrapped-on-the-gun pose by how far onto the gun the hand is (s_underW 0..1, eased).
        // 1.7.22 switched at s_underW = 0.3, so a hand drifting near the barrel flicked its fingers open and shut ("left hand fingers are weird").
        float want[5];
        if (g_ctl.fingerAnalog) {   // 1.7.111 ANALOG FINGERS: the grip squeeze closes the middle / ring / pinkie smoothly, a thumb off its buttons points up, a finger off the trigger points; the old two poses (open / fist) were all there was
          static int s_anaSeen[2], s_thumbSeen[2], s_trigSeen[2];
          const float gaRaw[2] = {hr.gripAnaR, hr.gripAnaL};
          const int thT = h == 0 ? hr.thumbTR : hr.thumbTL, trT = h == 0 ? hr.trigTR : hr.trigTL;
          if (gaRaw[h] > 0.3f) s_anaSeen[h] = 1;
          if (thT) s_thumbSeen[h] = 1;
          if (trT) s_trigSeen[h] = 1;
          float g = s_anaSeen[h] ? gaRaw[h] : (gr[h] ? 1.0f : 0.0f);
          if (gr[h] && g < 0.85f) g = 0.85f;
          g = g < 0.0f ? 0.0f : (g > 1.0f ? 1.0f : g);
          const float idxOpen = tg0 > rest * 0.85f ? tg0 : rest * 0.85f;
          const int pointing = s_trigSeen[h] && !trT && tg0 < 0.05f;
          const float idxClosed = pointing ? 0.12f : (tg0 > 0.52f ? (tg0 > 0.92f ? 0.92f : tg0) : 0.52f);
          const float thOpen = s_thumbSeen[h] ? (thT ? 0.50f : 0.18f) : 0.22f, thClosed = s_thumbSeen[h] ? (thT ? 0.62f : 0.06f) : 0.60f;
          want[0] = thOpen + (thClosed - thOpen) * g;
          want[1] = idxOpen + (idxClosed - idxOpen) * g;
          want[2] = rest * 1.05f + (0.88f - rest * 1.05f) * g;
          want[3] = rest * 1.30f + (0.90f - rest * 1.30f) * g;
          want[4] = rest * 1.55f + (0.92f - rest * 1.55f) * g;
          g_fa.g[h] = (int)(g * 100.0f); g_fa.th[h] = thT; g_fa.tr[h] = trT; g_fa.pt[h] = pointing; ++g_fa.passes[h]; if (pointing) ++g_fa.pointPasses[h];
          g_fa.anaSeen[h] = s_anaSeen[h]; g_fa.thumbSeen[h] = s_thumbSeen[h]; g_fa.trigSeen[h] = s_trigSeen[h];
        } else
        if (gr[h]) { want[0] = 0.60f; want[1] = tg0 > 0.52f ? (tg0 > 0.92f ? 0.92f : tg0) : 0.52f; want[2] = 0.88f; want[3] = 0.90f; want[4] = 0.92f; }
        else { want[0] = 0.22f; want[1] = tg0 > rest * 0.85f ? tg0 : rest * 0.85f; want[2] = rest * 1.05f; want[3] = rest * 1.30f; want[4] = rest * 1.55f; }
        float wrapAmt = 0.0f;
        if (h == 1) {
          const float uw = sceneArms ? (s_underW < (float)t.grabW ? s_underW : (float)t.grabW) : s_underW;   // 1.7.200: in the roof fight the fist only shows once the hand really has hold of the barrel (a squeezed grip far away used to curl the fingers with no grab)
          float x = (uw - 0.10f) / 0.60f; if (x < 0.0f) x = 0.0f; if (x > 1.0f) x = 1.0f;
          wrapAmt = x * x * (3.0f - 2.0f * x);   /* 1.7.210: with a real hold the fingers go round the barrel like normal play */ //   // 1.7.200: "grab the offhand on the roof without it curling": in the roof fight the left fingers only follow your own grip and trigger, on or off the gun
          leftWrap = wrapAmt;
          const float wrapPose[5] = {0.55f, tg0 > 0.82f ? tg0 : 0.82f, 0.90f, 0.92f, 0.92f};
          const float wpW = sceneArms ? wrapAmt * (1.0f - (float)(t.grabWrap > 1.0 ? 1.0 : t.grabWrap)) : wrapAmt;   // 1.7.211 roof: the fist pose fades out as the barrel pose takes over (no extra closing after take-hold)
          for (int f = 0; f < 5; ++f) want[f] += (wrapPose[f] - want[f]) * wpW;
          {   // 1.7.109: taking hold WRAPPED round the barrel the fingers close to a barrel-sized grip (about 0.65), not a fist: the game's own left pose is a closed fist and buried the fingertips in the palm
            static const float barrelPose[5] = {0.40f, 0.70f, 0.74f, 0.76f, 0.72f};   // 1.7.221: a little tighter round the barrel (was 0.30 / 0.62 / 0.66 / 0.68 / 0.64: the report said it did not look like a real grip); the video decides if it is still too loose or now buried
            const float ww = (float)t.grabWrap;
            for (int f = 0; f < 5; ++f) want[f] += (barrelPose[f] - want[f]) * ww;
          }
          const int onGun = wrapAmt > 0.5f;
          static int s_prevOnGun;
          ++g_lf.passes; if (onGun) ++g_lf.onGunPasses;
          if (onGun != s_prevOnGun) { ++g_lf.switches; s_prevOnGun = onGun; }
          if (wrapAmt > 0.02f && wrapAmt < 0.98f) ++g_lf.blendPasses;
          if (wrapAmt <= 0.02f) ++g_lf.freePasses;   // 1.7.24: the hand is off the gun
          g_lf.lastWrapX100 = (int)(wrapAmt * 100.0f); g_lf.lastGripL = gr[h]; g_lf.lastTrigX100 = (int)(tg0 * 100.0f);
        }
        if (h == 1 && trapFist) {   // 1.7.175: the hand that holds the trap closes round its handle (it stayed open and relaxed); a handle grip, not a full fist
          static const float trapPose[5] = {1.00f, 0.78f, 0.82f, 0.85f, 0.86f};   // 1.7.211: thumb wrapped, fingers staggered round a thick handle (0.92 was tighter than the game's own fist and read as a claw)
          for (int f = 0; f < 5; ++f) want[f] = trapPose[f];
        }
        for (int f = 0; f < 5; ++f) {
          const float cur = s_curl[h][f];
          // closing is quick, opening a little slower. 1.7.148: a real grab rolls in from the index to the little finger (and lets go the other way round), so each finger
          // takes a few ms more / less: thumb and index lead the close, the little finger trails by about 25 ms; when letting go the little finger opens first.
          static const double kCloseTau[5] = {0.040, 0.040, 0.050, 0.058, 0.066}, kOpenTau[5] = {0.095, 0.092, 0.084, 0.076, 0.068};
          const double tau = want[f] > cur ? kCloseTau[f] : kOpenTau[f];
          const double k = dt > 0.0 ? dt / (tau + dt) : 0.0;
          s_curl[h][f] = (float)(cur + (want[f] - cur) * k);
          t.curl[h][f] = (double)s_curl[h][f];
        }
      }
      if (pkeGameOn && g_ctl.pkeFingersAnim) { for (int f = 0; f < 5; ++f) t.curl[0][f] = -1.0; InterlockedIncrement(&g_pctl.animFingers); }   // 1.7.76: the right hand keeps the game's own fingers around the meter's handle (they used to follow your grip button, so the handle floated out of the fist)
      {   // 1.7.103 the game's own finger pose for the supporting hand: on the gun (by how far the hand is on it) and while the PKE is out
        double keepL = 0.0;
        static double s_pkeKeep;
        if (g_ctl.gameFingers) {
          keepL = (double)leftWrap;
          // 1.7.104: with the PKE out the free left hand rests in the game's own pose, but as soon as you squeeze grip or trigger the fingers follow you (1.7.103 froze them: "left middle finger always down")
          const double inp = vh[1] ? (gr[1] ? 1.0 : (double)(tr[1] > 1.0f ? 1.0f : (tr[1] < 0.0f ? 0.0f : tr[1]))) : 0.0;
          const double tgt = pkeGameOn ? 1.0 - inp : 0.0;
          const double k2 = dt > 0.0 ? dt / (0.12 + dt) : 0.0;
          s_pkeKeep += (tgt - s_pkeKeep) * k2;
          if (s_pkeKeep < 0.0005) s_pkeKeep = 0.0;
          if (s_pkeKeep > keepL) keepL = s_pkeKeep;
        } else s_pkeKeep = 0.0;
        if (sceneArms) keepL = 0.0;   // 1.7.199: in the roof fight / while dying the game's left hand is curled round the flashlight or radio it holds in the animation: the hand follows your own fingers instead
        keepL *= 1.0 - (t.grabWrap > 1.0 ? 1.0 : t.grabWrap);   // 1.7.109: wrapping the barrel, the engine's own barrel grip pose is used
        if (trapFist) keepL = 0.0;   // 1.7.209: holding the trap the game open left pose is never blended in
        t.leftFingerKeep = keepL;
        if (sceneArms) {   // 1.7.200 SCENELEFT: the free left hand in the roof fight, about once a second, 60 lines at most
          static int s_slN; static int64_t s_slQ;
          const int64_t qn = qpc_now();
          if (s_slN < 60 && (s_slQ == 0 || (double)(qn - s_slQ) >= (double)qpc_freq())) {
            s_slQ = qn; ++s_slN;
            log_line("SCENELEFT t=%.1f grip=%d near=%d leftOnGun=%d perpCm=%.1f distGripPtCm=%.1f grabW=%.2f underW=%.2f wrap=%.2f keepL=%.2f curl L idx/mid/ring/pink=%.2f/%.2f/%.2f/%.2f | wrist bend last %.1f deg, passes %ld, limited %ld, hand-only %ld (limit 55) | hand orbit moved %.1f deg to cut the bend %.1f -> %.1f deg (%ld of %ld passes)",
              (double)qn / (double)qpc_freq(), gr[1] ? 1 : 0, dbgNear, leftOnGun, dbgPerpCm, dbgDistCm, (double)t.grabW, (double)s_underW, (double)leftWrap, keepL, (double)s_curl[1][1], (double)s_curl[1][2], (double)s_curl[1][3], (double)s_curl[1][4], arms_bend_last_x10() / 10.0, arms_bend_n(), arms_bend_clamped(), arms_bend_fallback(), arms_orbit_shift_x10() / 10.0, arms_orbit_bend0_x10() / 10.0, arms_orbit_bend_x10() / 10.0, arms_orbit_moved(), arms_orbit_n());
          }
        }
      }
      t.leftThumbKeep = g_ctl.leftThumbAnim && !sceneArms ? (double)leftWrap * (1.0 - (t.grabWrap > 1.0 ? 1.0 : t.grabWrap)) : 0.0;
      if (t.leftFingerKeep > t.leftThumbKeep) t.leftThumbKeep = t.leftFingerKeep;   // 1.7.103: the thumb follows the same rule   // 1.7.24: the thumb keeps the game's pose on the gun and relaxes with the other fingers off it (1.7.23 kept it everywhere, so a free hand held the thumb the way the animation holds the foregrip)
      if (trapFist) t.leftThumbKeep = 0.0;   // 1.7.209: the thumb wraps the handle too
      g_lf.lastThumbX100 = (int)(s_curl[1][0] * 100.0f); g_lf.lastIdxX100 = (int)(s_curl[1][1] * 100.0f); g_lf.lastPinkX100 = (int)(s_curl[1][4] * 100.0f);
      t.gunWrap = g_ctl.gunWrapPct > 0 ? 0.01 * (double)(g_ctl.gunWrapPct > 100 ? 100 : g_ctl.gunWrapPct) : 0.0;
      if (controllers_holstered()) t.gunWrap = 0.0;
      {   // 1.7.98 HAND ON / OFF THE GUN: 1.7.97 made the fingers close and open on a timer of its own (v9). That is gone: the fingers are the game's own animation. What is logged here is the time of
          // each on / off together with the game's own finger bend then, so a video can be matched to the log; the look of taking hold comes from the game's draw animation (DRAWANIM).
        static int s_wrapDir = 0; static int s_wrapLogs;
        const int dir = t.gunWrap > 0.5 ? 1 : 0;
        if (dir != s_wrapDir) { s_wrapDir = dir; if (s_wrapLogs++ < 30) log_line("HANDANIM t=%.2fs: the gun hand is %s the gun (%s) | the game's own finger bend, total degrees: right index %d, middle %d, ring %d, pinkie %d | left index %d, middle %d, ring %d, pinkie %d", qpc_ms() / 1000.0, dir ? "on" : "off", dir ? "drawn" : "holstered or not the item in hand", arms_right_finger_base_x10(1) / 10, arms_right_finger_base_x10(2) / 10, arms_right_finger_base_x10(3) / 10, arms_right_finger_base_x10(4) / 10, arms_left_finger_base_x10(1) / 10, arms_left_finger_base_x10(2) / 10, arms_left_finger_base_x10(3) / 10, arms_left_finger_base_x10(4) / 10); }
      }   // 1.7.25: nothing in the right hand while the gun is on the back: the fingers follow the grip button   // 1.7: the weapon hand keeps its grip fingers wrapped
      t.fingersOn = 1;
    }
    const int pkeHeld = (!g_ctl.gamePlace && g_ctl.pkeAttach && !g_ctl.pkeLikeGun && !pkeGameOn && pke_item_held()) ? 1 : 0;   // 0.91: pke_like_gun puts the PKE on the controller the way the gun is placed (0.97: not when the game's own PKE is moved)
    t.pkeAttach = (pkeHeld && g_ctl.pkeBones) ? 1 : 0;
    t.pkeWand = (pkeHeld && wandRead) ? 1 : 0;   // 0.85: the game's wand matrix was read above (0.90: tested with a flag)
    { static LONG s_pd; const LONG k = InterlockedIncrement(&s_pd); if (pkeHeld && (k % 600 == 1)) log_line("PKEDBG pkeHeld=%d wandRead=%d pkeWand=%d pkeBones=%d rightOn=%d (the PKE is the item in hand)", pkeHeld, wandRead, (int)t.pkeWand, (int)g_ctl.pkeBones, (int)t.rightOn); }
  }
  if (t.armsOnly && !sceneArms && !pke_mode() && g_ctl.armsShoulders && g_ctl.bodyWhole) {
    // Full-body visibility never changes with headset pitch. Hide neck/head only.
    t.headOnly = 1;
    static LONG s_whole; if (InterlockedIncrement(&s_whole) == 1) log_line("BODYWHOLE full body stays visible at every look angle; only neck/head hidden");
  }
  if (t.armsOnly && !sceneArms && engine_glove_mode()) { t.noArms = 1; InterlockedIncrement(&g_glove.frames); }
  if (sceneArms) {
    t.fade = 1.0; t.floatingArms = 1;
    t.stretchMax = 1.0; t.shoulderPullDeg = 0.0; t.armLenBase = 1.0;
    t.shoulderSlideFt = 0.15 * t.fpm;
    if (g_sceneStation.have) for (int i = 0; i < 3; ++i) {
      const float shift = g_sceneStation.delta[i];
      t.sceneShift[i] = shift;
      if (t.rightOn) t.wandP0[i] += shift;
    }
    if (bx && bx->eyeOk) {
      t.eyeOn = 1; t.bodyYaw = bx->yaw;
      for (int i = 0; i < 3; ++i) t.eyeTarget[i] = bx->eye[i];
    }
  }
  t.keepShoulders = sceneArms ? 0 : (g_ctl.armsShoulders ? 1 : 0);
  t.nativeSupport = !sceneArms && !pke_mode() && g_ctl.foreGrab && g_ctl.grabWrap;
  // 1.7.226 "remove the hand animation for weapon change and any other hand-on-gun animation": the upper-body hold (made for the reload) also covers the 1.2 s after the weapon changes
  // (the game's draw / switch animation moves its hand) and the alternate fire (the left trigger, the dart's kick). The pose from just before is kept; the hand stays on the controller.
  static int s_swItem = -1; static double s_swUntil; int switchHold = 0;
  {
    const double nowS = qpc_ms() / 1000.0;
    if (t.itemId != s_swItem) { if (s_swItem >= 0 && (t.itemId == 1 || t.itemId == 2 || t.itemId == 3 || t.itemId == 7)) s_swUntil = nowS + 1.2; s_swItem = t.itemId; }
    switchHold = g_ctl.gunHandNoAnim && nowS < s_swUntil;
  }
  const int altHold = g_ctl.gunHandNoAnim && controllers_alt_fire_active();
  t.switchHold = switchHold;
  t.reloadHold = !sceneArms && !pke_mode() && g_ctl.handLock &&
    (t.itemId == 1 || t.itemId == 2 || t.itemId == 3 || t.itemId == 7) && (controllers_reload_active() || controllers_trap_anim_active() || controllers_fire_hold_active() || switchHold || altHold);   // 1.7.173: also while the game's trap throw plays
  { static LONG s_shLog; static int s_shWas; const int on = (switchHold || altHold) && t.reloadHold; if (on && !s_shWas && InterlockedIncrement(&s_shLog) <= 40) log_line("HANDANIM 1.7.226 the game's hand-on-gun animation is held off (%s), item %d", switchHold ? "weapon change" : "alternate fire", t.itemId); s_shWas = on; }
  { static LONG s_trapHoldPasses, s_thLog; if (t.reloadHold && controllers_trap_anim_active() && InterlockedIncrement(&s_trapHoldPasses) % 400 == 1 && InterlockedIncrement(&s_thLog) <= 12) log_line("TRAP throw animation kept off the upper body (trap_no_anim=1): %ld arm passes so far", (long)s_trapHoldPasses); }
  t.elbowOut = 0.5;                                              // 0.72
  if (!t.rightOn) InterlockedIncrement(&g_adNoRight);
  if (t.rightOn || t.leftOn || t.bodyOn) {
    crumb("arm_drive:apply", t.rightOn + 2 * t.leftOn + 4 * t.bodyOn);
    const int adSolved = arms_apply(actor, W2, &t);
    if (t.rightOn) { InterlockedIncrement(&g_adRight); if (adSolved) InterlockedIncrement(&g_adSolved); }
    if (t.rightOn && g_solveTrkPend.aimQ) { for (int i = 0; i < 16; ++i) g_solveTrk.m[i] = g_solveTrkPend.m[i]; g_solveTrk.aimQ = g_solveTrkPend.aimQ; g_solveTrk.q = qpc_now(); }   // 1.7.76
    if (t.stereoPair && t.stereoRole == 1) {
      targetPair.t = t; targetPair.actor = actor; targetPair.pair = t.stereoPair;
    }
    // The arm pass now owns a fresh grip calibration for this PKE, not the last gun pose.
    if (pkeGameOn && memory_readable((const void*)(actor + layout::kOffPlayerPke), 8))
      pke_place(*(uint8_t* const*)(actor + layout::kOffPlayerPke), 4);
    crumb("arm_drive:done", 0); if (t.rightOn) rig_event_sample();
  }
}

// 0.73 data: where the game's pack (1) and hose (2) sit relative to the eye, in the headset's own axes (feet: right, up, forward), next to the game's wand.
// The physics cord uses fixed anchors (a hand's width behind and below the head); these lines show where the game itself puts its pack and hose, so the anchors can be tuned.
static GBVR_NOINLINE void body_down_log(const float* W2, const void* bxv);
static GBVR_NOINLINE void body_rel_log(uintptr_t actor, const float* W2, const void* bxv, int which) {
  if (which == 1) body_down_log(W2, bxv);   // 1.7.166
  static volatile LONG cnt[3], total;
  const LONG c = InterlockedIncrement(&cnt[which]);
  if (!(c <= 5 || (c % 1200) == 0) || total >= 60) return;
  const BodyExtra* bx = (const BodyExtra*)bxv;
  if (!bx->eyeOk) return;
  const float* Wm = (const float*)((const uint8_t*)actor + layout::kOffWandWorld);
  if (!memory_readable(Wm, 64)) return;
  double p[3], wi[3], h[3], w[3];
  for (int r = 0; r < 3; ++r) { p[r] = (double)W2[12 + r] - bx->eye[r]; wi[r] = (double)Wm[12 + r] - bx->eye[r]; }
  for (int k = 0; k < 3; ++k) {
    double a = 0, bq = 0;
    for (int r = 0; r < 3; ++r) { a += (double)bx->view[r * 3 + k] * p[r]; bq += (double)bx->view[r * 3 + k] * wi[r]; }
    h[k] = a; w[k] = bq;   // h: the part; w: the game's wand (both in head axes)
  }
  InterlockedIncrement(&total);
  log_line("BODYREL %s relative to the eye (right,up,forward ft): %.2f,%.2f,%.2f | the game's wand there: %.2f,%.2f,%.2f | part minus wand: %.2f,%.2f,%.2f (call %d)",
           which == 1 ? "pack" : "hose", h[0], h[1], h[2], w[0], w[1], w[2], h[0] - w[0], h[1] - w[1], h[2] - w[2], (int)c);
}

// 1.7.166 "when I look down another overlapping body appears": while you look steeply down, where the game's pack is from your eye in level axes
// (forward along your look's heading, right, up; feet) and how far the body's heading is from yours. A normal body puts the pack behind you
// (forward about -0.6 .. -1.0 ft); a pack in front of you, or a big heading gap, is the body standing where you see it. Every 2 s while down, 40 lines.
static GBVR_NOINLINE void body_down_log(const float* W2, const void* bxv) {
  const BodyExtra* bx = (const BodyExtra*)bxv;
  if (!bx || !bx->eyeOk) return;
  const double fx = bx->view[0 * 3 + 2], fy = bx->view[1 * 3 + 2], fz = bx->view[2 * 3 + 2];
  const double pitch = vm::datan2(fy, vm::dsqrt(fx * fx + fz * fz)) * 57.29577951308232;
  static int64_t s_q; static LONG s_n;
  const int64_t nq = qpc_now();
  if (pitch > -40.0 || s_n >= 40 || (s_q && (double)(nq - s_q) / (double)qpc_freq() < 2.0)) return;
  double hl = vm::dsqrt(fx * fx + fz * fz); if (!(hl > 1e-6)) return;
  const double hx = fx / hl, hz = fz / hl;   // your heading (level)
  const double d[3] = {(double)W2[12] - bx->eye[0], (double)W2[13] - bx->eye[1], (double)W2[14] - bx->eye[2]};
  const double fwd = d[0] * hx + d[2] * hz, right = d[0] * hz - d[2] * hx, up = d[1];
  const double headYaw = vm::datan2(hx, hz) * 57.29577951308232;
  double gap = bx->yaw * 57.29577951308232 - headYaw; while (gap > 180.0) gap -= 360.0; while (gap < -180.0) gap += 360.0;
  s_q = nq; ++s_n;
  log_line("BODYDOWN looking %.0f deg down: the pack is %.2f ft forward, %.2f ft right, %.2f ft up from your eye (level axes; behind you is about -0.6..-1.0 forward) | body heading minus yours %.0f deg | eye-match fade %.2f | body_down_back_cm %d",
           -pitch, fwd, right, up, gap, (double)bx->fade, (int)g_ctl.bodyDownBackCm);
}

// 0.52: body base (which = 0), extras / pack (1) and hose (2): the same placement as the camera says the real body has.
static float g_packPoseW[16]; static int64_t g_packPoseQ;   // 1.7.25
static struct { uintptr_t actor; float gameM[16], drawM[16]; int64_t q; } g_hoseGun;   // 1.7.148: the gun as the game has it and as it is drawn (wand push, same render)
static volatile int64_t g_hoseOkQ;   // 1.7.148: when the game's own hose was last bent to the drawn gun
static volatile LONG g_hoseShown, g_hoseHidden;
int64_t engine_hose_ok_q() { return g_hoseOkQ; }
// 1.7.149: every place the mod draws the player's gun somewhere other than the game's spot tells the hose where (the hose push comes later in the same render)
static inline void hose_gun_note(uintptr_t actor, const float* gameM, const float* drawM) {
  for (int i = 0; i < 16; ++i) { g_hoseGun.gameM[i] = gameM[i]; g_hoseGun.drawM[i] = drawM[i]; }
  g_hoseGun.actor = actor; g_hoseGun.q = qpc_now();
}
// 1.7.148 / 1.7.150: the game's OWN hose follows the drawn gun (hosemath.h): its gun end moves with the gun, its pack end stays on the pack. hoseDraw = the matrix the
// hose is drawn with this time (the game's own when the body follow did not change it). Tried once per hose push, whatever body_push decided.
static volatile LONG g_hoseTried;
static void hose_bend_try(uintptr_t actor, const float* hoseGame, const float* hoseDraw) {
  InterlockedExchange(&g_hoseTried, 1);
  if (g_ctl.hoseOff) return;
  if (!actor || g_hoseGun.actor != actor || !g_hoseGun.q || (double)(qpc_now() - g_hoseGun.q) / (double)qpc_freq() >= 0.05) {   // 1.7.182: no fresh gun this render (gun stowed, PKE swap): hold the last bent pose a moment
    static LONG s_stale, s_sl; const LONG n = InterlockedIncrement(&s_stale);
    const int held = arms_hose_hold(1);
    if (n <= 8 && InterlockedIncrement(&s_sl) <= 8) log_line("HOSEFLICK t=%.2fs no fresh gun draw for the hose (%ld times): %s", qpc_ms() / 1000.0, (long)n, held ? "the last bent pose is held (up to 0.15 s)" : "the game's own pose is shown");
    return;
  }
  const long okBefore = arms_hose_stat(1);
  if (arms_hose_follow(actor, hoseGame, hoseDraw, g_hoseGun.gameM, g_hoseGun.drawM)) {
    if (arms_hose_stat(1) == okBefore) { static LONG s_hl2; if (InterlockedIncrement(&s_hl2) <= 8) log_line("HOSEFLICK t=%.2fs the hose could not be bent this render (the hose end is not at the game's gun, or the maths refused): the last bent pose is held (up to 0.15 s)", qpc_ms() / 1000.0); }
    g_hoseOkQ = qpc_now();
    static LONG s_hl; if (InterlockedIncrement(&s_hl) == 1) log_line("HOSE the game's own hose is bent to the gun in your hand (its gun end follows the gun, the pack end stays on the pack)");
  } else {
    static LONG s_hf; if (InterlockedIncrement(&s_hf) <= 3) log_line("HOSE not bent this time (calls %ld, bent %ld, layout not the expected one %ld, hose end not at the game's gun %ld, maths refused %ld): the game's own pose is kept meanwhile",
      arms_hose_stat(0), arms_hose_stat(1), arms_hose_stat(2), arms_hose_stat(3), arms_hose_stat(4));
  }
}
static GBVR_NOINLINE float* body_push(const float* a, float* out, const float* b, int which) {
  ProfScope psBody(PF_BODYPUSH);
  crumb("bodypush", which);
  if (!g_ctl.bodyFollow || !g_ctl.realModels || !g_ctl.stereoActive) return o_matMul(a, out, b);
  uintptr_t actor = 0; float feet[3], d[3]; double phi = 0, s = 1.0; int64_t q = 0; int ok = 0;
  BodyExtra bx; bx.on = 0; bx.fade = 1.0f;
  for (int tries = 0; tries < 3 && !ok; ++tries) {
    LONG s0 = g_body.seq;
    if (s0 & 1) continue;
    actor = g_body.actor; q = g_body.qpc; phi = g_body.phi; s = g_body.s;
    for (int i = 0; i < 3; ++i) bx.lean[i] = g_body.lean[i];
    for (int i = 0; i < 9; ++i) bx.view[i] = g_body.view[i];
    bx.yaw = g_body.yaw; bx.on = 1;
    for (int i = 0; i < 3; ++i) bx.eye[i] = g_body.eye[i];
    bx.eyeOk = g_body.eyeOk;
    bx.fade = g_body.fade;
    for (int i = 0; i < 3; ++i) { feet[i] = g_body.feet[i]; d[i] = g_body.d[i]; }
    ok = g_body.seq == s0 && g_body.valid;
  }
  if (!ok || !actor) return o_matMul(a, out, b);
  if (!aim::is_fresh(qpc_now(), q, qpc_freq(), 250)) { InterlockedIncrement(&g_bodyMv.stale); return o_matMul(a, out, b); }
  if (!memory_readable(a, 64)) return o_matMul(a, out, b);
  const uint8_t* act = (const uint8_t*)actor;
  int mine = 0;
  if (which == 1) mine = (uintptr_t)a == actor + layout::kOffExtrasWorld;
  else if (which == 2) mine = (uintptr_t)a == actor + layout::kOffHoseWorld;
  else {   // the body base is a matrix on the render function's stack: it is the player's when its position is the actor's
    const float* pos = (const float*)(act + layout::kActorPos);
    // (the game thread may have moved the actor a little since the render function read it: 0.6 ft is still "this actor")
    mine = memory_readable(pos, 12) && vm::is_finite_f(a[12]) && vm::is_finite_f(a[14]) &&
           a[12] - pos[0] < 0.6f && pos[0] - a[12] < 0.6f && a[13] - pos[1] < 0.6f && pos[1] - a[13] < 0.6f && a[14] - pos[2] < 0.6f && pos[2] - a[14] < 0.6f;
  }
  {   // pivot = where the actor is NOW (the snapshot is from the camera step)
    const float* lp = (const float*)(act + layout::kActorPos);
    if (mine && memory_readable(lp, 12) && vm::is_finite_f(lp[0]) && vm::is_finite_f(lp[1]) && vm::is_finite_f(lp[2])) { feet[0] = lp[0]; feet[1] = lp[1]; feet[2] = lp[2]; }
  }
  if (!mine) { InterlockedIncrement(&g_bodyMv.notPlayer[which]); return o_matMul(a, out, b); }
  for (int i = 0; i < 16; ++i) if (!vm::is_finite_f(a[i])) { InterlockedIncrement(&g_bodyMv.bad); return o_matMul(a, out, b); }
  const double cb = engine_scene_arms(actor) ? 0.0 : cine_blend();
  if (cb >= 0.999) {   // 1.7.26: the game is in charge of the character (cutscene): its own placement, nothing of the probe's
    InterlockedIncrement(which == 0 ? &g_cineSt.bodyPass : which == 1 ? &g_cineSt.packPass : &g_cineSt.hosePass);
    return o_matMul(a, out, b);
  }
  body::Xf x;
  const int stationRig = engine_scene_arms(actor) && g_sceneStation.have;
  // Rotate only the rendered player model to the scene view heading.
  x.set_blend(s, phi + (stationRig ? g_sceneStation.yawDelta : 0.0), feet, d, cb);
  float W2[16];
  x.matrix(a, W2);
  if (stationRig) for (int i = 0; i < 3; ++i) W2[12 + i] += g_sceneStation.delta[i];
  if (cb > 0.001) InterlockedIncrement(&g_cineSt.mixed);   // rigid easing in or out, including the arms/pack's basis
  if (InterlockedIncrement(&g_bodyMv.applied[which]) == 1)
    log_line("BODY first move of %s: world position %.2f,%.2f,%.2f -> %.2f,%.2f,%.2f feet (torso turned %.1f degrees, scale %.3f, offset %.2f,%.2f feet)",
             which == 0 ? "the body" : which == 1 ? "the pack and extras" : "the hose", (double)a[12], (double)a[13], (double)a[14], (double)W2[12], (double)W2[13],
             (double)W2[14], phi * 57.29578, s, (double)d[0], (double)d[2]);
  {
    static struct { int64_t pair; uintptr_t actor; float W[16]; BodyExtra bx; } bodyPair[3];
    ArmStereo draw;
    if (which >= 0 && which < 3 && g_ctl.pairHands && draw_stereo(&draw) && draw.pairQ) {
      auto& cache = bodyPair[which];
      if (cache.pair == draw.pairQ && cache.actor == actor) {
        for (int i = 0; i < 16; ++i) W2[i] = cache.W[i];
        bx = cache.bx;
      } else if (draw.pairRole == 1) {
        for (int i = 0; i < 16; ++i) cache.W[i] = W2[i];
        cache.bx = bx; cache.actor = actor; cache.pair = draw.pairQ;
      }
    }
  }
  if (which == 0 && (g_ctl.armIk || g_ctl.fullBody)) { if (cb > 0.5) InterlockedIncrement(&g_cineSt.armSkips); else arm_drive(actor, W2, a, &bx); }   // 1.7.26: not while the game animates the character
  if (which == 1 && g_ctl.fullBody && g_ctl.packFollow) {   // 0.68: the pack drops and leans with the torso (the body pass of this same render just did it)
    bpack::Motion pm;
    if (arms_torso_motion(&pm)) {
      if (bpack::apply(pm, W2, 1)) {
        InterlockedIncrement(&g_bodyMv.packMoved);
        const LONG dd = (LONG)(-pm.drop * 100.0);
        if (dd > g_bodyMv.packDropMaxX100) g_bodyMv.packDropMaxX100 = dd;
      }
    } else InterlockedIncrement(&g_bodyMv.packNoMotion);
  }
  if (which == 1) { for (int i = 0; i < 16; ++i) g_packPoseW[i] = W2[i]; g_packPoseQ = qpc_now(); }   // 1.7.25: where the pack is drawn, for the holstered gun
  if (which >= 1) body_rel_log(actor, W2, &bx, which);
  if (which >= 1 && (g_ctl.rigView || (g_ctl.armsOnly && g_ctl.armsStraps)) && bx.eyeOk) {   // 0.74 rig view: where the game's pack / hose matrices are, relative to the eye
    double v9[9], e3[3];
    for (int i = 0; i < 9; ++i) v9[i] = bx.view[i];
    for (int i = 0; i < 3; ++i) e3[i] = bx.eye[i];
    arms_rig_part(which, W2, v9, e3);
  }
  if (which == 1 && (g_ctl.armIk || g_ctl.fullBody)) arms_verify(actor);
  if (which == 2) hose_bend_try(actor, a, W2);   // 1.7.148 / 1.7.150
  return o_matMul(W2, out, b);
}

static const char* const kWpnName[8] = {"none", "proton gun", "meson collider", "boson dart", "ghost trap", "PKE meter", "flashlight", "slime blower"};
static struct { long frames, tipSum, tipMin, tipMax, switchesTo; } g_wpn[8];
static int g_wpnLast = -1, g_wpnLogged;
static void weapons_report(LONG frame) {
  log_line("LEFTFINGERS frame=%d thumb_keeps_the_game_pose=%d | passes %ld, on the gun (wrap > 50%%) %ld, blended between relaxed and wrapped %ld, switches between on/off the gun %ld (1.7.23: the fingers blend smoothly with the hand's distance to the gun; 1.7.22 flicked at one distance)",
           (int)frame, (int)g_ctl.leftThumbAnim, g_lf.passes, g_lf.onGunPasses, g_lf.blendPasses, g_lf.switches);
  log_line("LEFTFREE frame=%d left hand OFF the gun (wrap < 2%%) in %ld of %ld passes | last pass: wrap %d%%, grip %d, trigger %d%%, eased curl thumb %d%% index %d%% pinkie %d%% (1.7.24: off the gun the thumb now relaxes with the fingers instead of holding the animation's foregrip pose)",
           (int)frame, g_lf.freePasses, g_lf.passes, g_lf.lastWrapX100, g_lf.lastGripL, g_lf.lastTrigX100, g_lf.lastThumbX100, g_lf.lastIdxX100, g_lf.lastPinkX100);
  for (int i = 0; i < 8; ++i) if (g_wpn[i].frames)
    log_line("WEAPONS frame=%d item %d %s: %ld gun placements in hand, barrel (grip to muzzle) mean %d.%02d ft (smallest %d.%02d, largest %d.%02d), brought out %ld times", (int)frame, i, kWpnName[i], g_wpn[i].frames,
             (int)(g_wpn[i].tipSum / g_wpn[i].frames / 100), (int)(g_wpn[i].tipSum / g_wpn[i].frames % 100), (int)(g_wpn[i].tipMin / 100), (int)(g_wpn[i].tipMin % 100), (int)(g_wpn[i].tipMax / 100), (int)(g_wpn[i].tipMax % 100), g_wpn[i].switchesTo);
}
// 1.7.31 GEARSHAKE / GEARTRACE: where the gun / PKE is drawn, seen from the eye being drawn (the view basis and eye position of this frame), per eye, per way of holding it, standing or walking.
// The shake is the second difference of that place over three frames of the same eye (what you see as a tremble); the trace is a run of consecutive frames, so a left/right pattern shows.
static struct GearShake {
  struct Acc { long n; double sum, max; } a[2][3][2];      // [eye][what: 0 gun one hand, 1 gun two hands, 2 PKE][moving]
  double hist[2][3][3]; int histN[2]; int64_t lastQ[2]; int lastWhat[2];
  double prevHc[2][3]; int64_t prevHcQ[2]; int moving[2];
  // between the eyes of one pair: the same gear seen from the head centre, left minus right
  double pairP[3]; int pairWhat; int64_t pairQ; long interN; double interSum, interMax;
  struct Tr { int eye, what, moving; double dtMs, p[3]; } tr[96]; int trN, trDone, trLogged;
} g_gs;
static void gear_note(int what, const float* worldPos) {
  if (!g_ctl.probeData) return;
  ArmStereo st;
  if (!worldPos || !draw_stereo(&st)) return;
  const int ey = (int)(st.eye & 1);
  const double fpm = st.feetPerMetre > 0.1f ? (double)st.feetPerMetre : 3.28084;
  // the place in the head-centre frame and in the eye frame (metres): V^T (world - centre) / fpm
  double dc[3], de[3], pc[3], pe[3];
  for (int r = 0; r < 3; ++r) { dc[r] = (double)worldPos[r] - st.headCenter[r]; de[r] = (double)worldPos[r] - st.eyeWorld[r]; }
  for (int c = 0; c < 3; ++c) {
    pc[c] = ((double)st.view[0 * 3 + c] * dc[0] + (double)st.view[1 * 3 + c] * dc[1] + (double)st.view[2 * 3 + c] * dc[2]) / fpm;
    pe[c] = ((double)st.view[0 * 3 + c] * de[0] + (double)st.view[1 * 3 + c] * de[1] + (double)st.view[2 * 3 + c] * de[2]) / fpm;
  }
  if (!vm::is_finite_f((float)pe[0]) || !vm::is_finite_f((float)pe[1]) || !vm::is_finite_f((float)pe[2])) return;
  const int64_t nq = qpc_now();
  // walking = the head centre moved more than 1.5 ft/s since the previous frame of this eye
  if (g_gs.prevHcQ[ey]) {
    const double dt = (double)(nq - g_gs.prevHcQ[ey]) / (double)qpc_freq();
    if (dt > 0.0 && dt < 0.25) { const double dx = st.headCenter[0] - g_gs.prevHc[ey][0], dz = st.headCenter[2] - g_gs.prevHc[ey][2]; g_gs.moving[ey] = (dx * dx + dz * dz) > (1.5 * dt) * (1.5 * dt) ? 1 : 0; }
    else g_gs.moving[ey] = 0;
  }
  if (st.pairRole != 2 || ey == 1) { for (int i = 0; i < 3; ++i) g_gs.prevHc[ey][i] = st.headCenter[i]; g_gs.prevHcQ[ey] = nq; }
  const int mv = g_gs.moving[ey];
  const double dtMs = g_gs.lastQ[ey] ? (double)(nq - g_gs.lastQ[ey]) * 1000.0 / (double)qpc_freq() : 0.0;
  if (what != g_gs.lastWhat[ey] || dtMs > 250.0 || !g_gs.lastQ[ey]) g_gs.histN[ey] = 0;
  g_gs.lastWhat[ey] = what; g_gs.lastQ[ey] = nq;
  for (int k = 0; k < 2; ++k) for (int i = 0; i < 3; ++i) g_gs.hist[ey][k][i] = g_gs.hist[ey][k + 1][i];
  for (int i = 0; i < 3; ++i) g_gs.hist[ey][2][i] = pe[i];
  if (g_gs.histN[ey] < 3) ++g_gs.histN[ey];
  if (g_gs.histN[ey] >= 3) {
    double sd = 0.0;
    for (int i = 0; i < 3; ++i) { const double v = g_gs.hist[ey][0][i] - 2.0 * g_gs.hist[ey][1][i] + g_gs.hist[ey][2][i]; sd += v * v; }
    sd = vm::dsqrt(sd) * 1000.0;   // mm
    if (sd < 300.0) { GearShake::Acc& A = g_gs.a[ey][what][mv]; ++A.n; A.sum += sd; if (sd > A.max) A.max = sd; }
  }
  // the two eyes of a pair, seen from the head centre
  if (st.pairRole == 1 || st.pairRole == 0) { for (int i = 0; i < 3; ++i) g_gs.pairP[i] = pc[i]; g_gs.pairWhat = what; g_gs.pairQ = nq; }
  else if (st.pairRole == 2 && g_gs.pairQ && g_gs.pairWhat == what && (double)(nq - g_gs.pairQ) < 0.1 * (double)qpc_freq()) {
    const double dx = pc[0] - g_gs.pairP[0], dy = pc[1] - g_gs.pairP[1], dz = pc[2] - g_gs.pairP[2];
    const double mm = vm::dsqrt(dx * dx + dy * dy + dz * dz) * 1000.0;
    if (mm < 300.0) { ++g_gs.interN; g_gs.interSum += mm; if (mm > g_gs.interMax) g_gs.interMax = mm; }
  }
  // the trace: 96 consecutive frames while walking with the gun in two hands or the PKE out, twice per session
  if (!g_gs.trDone && g_gs.trLogged < 2 && what >= 1 && mv) {
    if (g_gs.trN < 96) { GearShake::Tr& t = g_gs.tr[g_gs.trN++]; t.eye = ey; t.what = what; t.moving = mv; t.dtMs = dtMs; for (int i = 0; i < 3; ++i) t.p[i] = pe[i]; }
    if (g_gs.trN >= 96) {
      char line[1700]; int len = 0;
      for (int i = 0; i < g_gs.trN && len < 1600; ++i) {
        const GearShake::Tr& t = g_gs.tr[i];
        len += log_fmt(line + len, (int)sizeof(line) - len, "%s%c %.0fms %.0f,%.0f,%.0f", i ? " | " : "", t.eye ? 'R' : 'L', t.dtMs, t.p[0] * 1000.0, t.p[1] * 1000.0, t.p[2] * 1000.0);
      }
      line[len < (int)sizeof(line) ? len : (int)sizeof(line) - 1] = 0;
      ++g_gs.trLogged; g_gs.trN = 0;
      log_line("GEARTRACE #%d (%s, walking): 96 frames in a row, each: eye (L/R), time since the previous frame, gear place seen from that eye (right,up,forward in mm). Look for a left/right pattern: %s", g_gs.trLogged, what == 2 ? "PKE" : "gun in two hands", line);
      if (g_gs.trLogged >= 2) g_gs.trDone = 1;
    }
  } else if (g_gs.trN > 0 && !mv) g_gs.trN = 0;   // the run is broken: start again
}
static void gearshake_report(LONG frame) {
  static const char* const nm[3] = {"gun in one hand", "gun in two hands", "PKE"};
  char buf[1500]; int len = 0;
  for (int w = 0; w < 3; ++w) for (int m = 0; m < 2; ++m) {
    const GearShake::Acc& L = g_gs.a[0][w][m]; const GearShake::Acc& R = g_gs.a[1][w][m];
    if (!L.n && !R.n) continue;
    len += log_fmt(buf + len, (int)sizeof(buf) - len, "%s%s %s: left eye mean %.1f max %.0f mm (%ld), right eye mean %.1f max %.0f mm (%ld)", len ? " | " : "", nm[w], m ? "WALKING" : "standing",
                   L.n ? L.sum / (double)L.n : 0.0, L.max, L.n, R.n ? R.sum / (double)R.n : 0.0, R.max, R.n);
  }
  buf[len < (int)sizeof(buf) ? len : (int)sizeof(buf) - 1] = 0;
  log_line("GEARSHAKE frame=%d the gun / PKE seen from each eye, second difference over three frames of the same eye (a tremble; mean/max mm): %s | between the two eyes of a pair, the gear differs by mean %.1f max %.0f mm (%ld pairs; 0 = both eyes see it in the same place)",
           (int)frame, len ? buf : "(no gun or PKE placed yet)", g_gs.interN ? g_gs.interSum / (double)g_gs.interN : 0.0, g_gs.interMax, g_gs.interN);
}

// ---- 1.7.71 the PKE is moved where it is drawn (pkedrawmath.h) --------------------------------------------------------------------------------
// Published by pke_place_locked (game thread) after every placement: the game's own pose of the meter and the in-hand pose. Read by the matrix
// product hook (render thread): a world matrix that IS the game's pose of the meter is replaced by the in-hand pose, the same way the gun is.
static struct {
  volatile LONG seq; int have; int64_t q;
  float gameM[16], handM[16];
  pkedraw::Census census;
  volatile LONG swaps, parts, stale, checks;
  int64_t logQ; volatile LONG logs; int heldLast;
} g_pkDraw;
static void pke_draw_publish(const float* gameM, const float* handM) {
  InterlockedIncrement(&g_pkDraw.seq);
  for (int i = 0; i < 16; ++i) { g_pkDraw.gameM[i] = gameM[i]; g_pkDraw.handM[i] = handM[i]; }
  g_pkDraw.q = qpc_now(); g_pkDraw.have = 1;
  InterlockedIncrement(&g_pkDraw.seq);
}
static int pke_draw_read(float* gameM, float* handM) {
  for (int tries = 0; tries < 4; ++tries) {
    const LONG s0 = g_pkDraw.seq; if (s0 & 1) continue;
    if (!g_pkDraw.have) return 0;
    const int64_t q = g_pkDraw.q;
    for (int i = 0; i < 16; ++i) { gameM[i] = g_pkDraw.gameM[i]; handM[i] = g_pkDraw.handM[i]; }
    if (g_pkDraw.seq != s0) continue;
    return q && (double)(qpc_now() - q) / (double)qpc_freq() < 0.15;
  }
  return 0;
}
// returns 1 and the matrix to draw with when `a` (going into the product from return address rr) is the meter or one of its parts
static int pke_draw_swap(const float* a, uintptr_t rr, float* outM) {
  if (!g_ctl.pkeDrawSwap || !g_pkDraw.have) return 0;
  if (!vm::is_finite_f(a[12]) || !vm::is_finite_f(a[13]) || !vm::is_finite_f(a[14])) return 0;
  {   // cheap first look (no copy): most matrices are nowhere near the meter
    const double x = (double)a[12] - g_pkDraw.gameM[12], y = (double)a[13] - g_pkDraw.gameM[13], z = (double)a[14] - g_pkDraw.gameM[14];
    if (x * x + y * y + z * z > 9.0) return 0;
  }
  float gm[16], hm[16];
  if (!pke_draw_read(gm, hm)) { InterlockedIncrement(&g_pkDraw.stale); return 0; }
  if (!handprop::finite16(a)) return 0;
  const double d = handprop::rel_pos_delta(a, gm);
  if (d > 2.5) return 0;   // nowhere near the meter: by far the most calls end here
  InterlockedIncrement(&g_pkDraw.checks);
  pkedraw::Site* st = pkedraw::site(g_pkDraw.census, rr);
  if (st) { ++st->nearN; if (d < st->minFt) st->minFt = d; }
  if (pkedraw::is_game_pose(a, gm, 0.13, 0.004)) {   // the meter itself, at the game's pose (4 cm, about 5 degrees)
    if (st) ++st->exact;
    for (int i = 0; i < 16; ++i) outM[i] = hm[i];
    InterlockedIncrement(&g_pkDraw.swaps);
    if (st && st->exact == pkedraw::kLearn) log_line("PKEDRAW the PKE is drawn from ghost.exe+%x (the game's own pose seen there %ld times): it is now drawn in your hand from that call", (unsigned)rr, st->exact);
    return 1;
  }
  if (pkedraw::learned(st) && pkedraw::carry(a, gm, hm, outM)) {   // a part of the meter, from the same call: carried along
    ++st->parts; InterlockedIncrement(&g_pkDraw.parts);
    return 1;
  }
  return 0;
}
static void pke_draw_report() {   // every ~30 s while it matters (quiet log): which call draws the PKE, how often it was moved
  const int64_t q = qpc_now();
  if (g_pkDraw.logQ && (double)(q - g_pkDraw.logQ) / (double)qpc_freq() < 30.0) return;
  if (!g_pkDraw.have || InterlockedIncrement(&g_pkDraw.logs) > 60) return;
  g_pkDraw.logQ = q;
  char buf[900]; int len = 0; buf[0] = 0;
  for (int i = 0; i < g_pkDraw.census.n && len < 820; ++i) {
    const pkedraw::Site& c = g_pkDraw.census.s[i];
    len += log_fmt(buf + len, (int)sizeof(buf) - len, " [+%x: game pose %ld, parts %ld, near %ld, closest %.2f ft]", (unsigned)c.rva, c.exact, c.parts, c.nearN, c.minFt);
  }
  log_line("PKEDRAW t=%.1fs on=%d | drawn in the hand %ld times, parts carried %ld, checks near the meter %ld, pose too old %ld | callers near the meter (%d, table full %ld):%s%s",
           qpc_ms() / 1000.0, (int)g_ctl.pkeDrawSwap, (long)g_pkDraw.swaps, (long)g_pkDraw.parts, (long)g_pkDraw.checks, (long)g_pkDraw.stale, g_pkDraw.census.n, g_pkDraw.census.full, len ? buf : " none",
           g_pkDraw.swaps ? "" : " | NOTE: nothing drawn matched the game's PKE pose: the meter is drawn some other way (the callers above say where to look next)");
}
// ---- 1.7.72 the PKE is moved where the game PUSHES it (read from ghost.exe, layout.h kRvaMatPush) --------------------------------------------------------------------
// The 1.7.71 log: no matrix product ever carried the meter (the draw does not use 0x17210). The collect pushes the meter's entity pose (+0x54/+0xF4) and its second pose
// (+0x4B8/+0x4C4) with 0x41360(ctx, pos, rot). Those two pushes of the player's meter are handed the in-hand pose instead, at the moment they happen; nothing else is touched.
// The PKEPUSH line also says whether the fields already held the in-hand pose when they were pushed (if they did and the meter still floats, it is drawn some other way).
typedef void*(__fastcall* PFN_MatPush)(void* ctx, const float* pos, const float* rot);
static PFN_MatPush o_matPush;
static volatile uintptr_t g_pkPushSelf;   // the player's meter while it is in the hand (set by pke_place), 0 otherwise
static struct { volatile LONG hooked; volatile LONG ent, pose, entOurs, entGame, poseOurs, posePrev, stale; double sumCm; long nCm; double maxCm; int64_t logQ; volatile LONG logs; } g_pp;
static void* __fastcall hk_mat_push(void* ctx, const float* pos, const float* rot) {
  const uintptr_t self = g_pkPushSelf;
  if (!self || !g_ctl.pkeDrawSwap) return o_matPush(ctx, pos, rot);
  const int ent = (uintptr_t)pos == self + layout::kActorPos && (uintptr_t)rot == self + layout::kOffEntityRot;
  const int pose = !ent && (uintptr_t)pos == self + layout::kOffPkePos && (uintptr_t)rot == self + layout::kOffPkeRot;
  if (!ent && !pose) return o_matPush(ctx, pos, rot);
  float gm[16], hm[16];
  if (!pke_draw_read(gm, hm)) { InterlockedIncrement(&g_pp.stale); return o_matPush(ctx, pos, rot); }
  float P[3], R[9];
  for (int i = 0; i < 3; ++i) P[i] = hm[12 + i];
  for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) R[3 * i + j] = hm[j * 4 + i];   // the entity layout: s[3*i+j] = M[j*4+i]
  {   // data: were the fields already the in-hand pose?
    const double dx = (double)pos[0] - P[0], dy = (double)pos[1] - P[1], dz = (double)pos[2] - P[2];
    const double cm = vm::dsqrt(dx * dx + dy * dy + dz * dz) * 30.48;
    if (ent) { InterlockedIncrement(&g_pp.ent); if (cm < 1.0) InterlockedIncrement(&g_pp.entOurs); else { InterlockedIncrement(&g_pp.entGame); g_pp.sumCm += cm; ++g_pp.nCm; if (cm > g_pp.maxCm) g_pp.maxCm = cm; } }
    else { InterlockedIncrement(&g_pp.pose); if (cm < 1.0) InterlockedIncrement(&g_pp.poseOurs); }
  }
  return o_matPush(ctx, P, R);
}
static void pke_push_report(int force = 0) {
  const int64_t q = qpc_now();
  if (!g_pp.ent && !g_pp.pose && !g_pp.stale) return;   // nothing pushed yet (1.7.71 logged too early)
  if (!force && g_pp.logQ && (double)(q - g_pp.logQ) / (double)qpc_freq() < 10.0) return;
  if (!force && !g_pp.logQ) { g_pp.logQ = q; return; }   // the first line comes 10 s after the first push
  if (InterlockedIncrement(&g_pp.logs) > 80) return;
  g_pp.logQ = q;
  log_line("PKEPUSH t=%.1fs hook=%d on=%d | the meter's entity pushed %ld times (it already held the in-hand pose %ld, held the game's pose %ld: mean %.0f cm, max %.0f cm away), second pose pushed %ld (%ld already in hand) | all given the in-hand pose; pose too old %ld",
           qpc_ms() / 1000.0, (int)g_pp.hooked, (int)g_ctl.pkeDrawSwap, (long)g_pp.ent, (long)g_pp.entOurs, (long)g_pp.entGame, g_pp.nCm ? g_pp.sumCm / g_pp.nCm : 0.0, g_pp.maxCm, (long)g_pp.pose, (long)g_pp.poseOurs, (long)g_pp.stale);
}
static void install_mat_push_hook() {
  if (!bytes_match(layout::kRvaMatPush, layout::kBytesMatPush, 16)) { g_pp.hooked = -1; log_line("PKEPUSH not available: the matrix push bytes differ in this game build"); return; }
  void* t = (void*)rva(layout::kRvaMatPush);
  MH_STATUS st = MH_CreateHook(t, (void*)hk_mat_push, (void**)&o_matPush);
  if (st == MH_OK) st = MH_EnableHook(t);
  g_pp.hooked = st == MH_OK ? 1 : -2;
  log_line("HOOK matrix push %x status=%d (1.7.72: the PKE is drawn in your hand at the moment the game pushes it)", layout::kRvaMatPush, (int)st);
}
// 1.7.100 GUNGONE: the gun hook is the one place that puts the gun in your hand. When it stops doing that for a moment (the gun vanishes or jumps to the game's own spot) the log
// says which of its exits was taken and for how long: 1 the controller aim sample was older than 250 ms, 2 no hand for the gun (hidden on purpose), 3 no hold yet (hidden on purpose),
// 4 no exact hand relation (the game's own spot), 5 the game's wand matrix or the aim could not be read. The expected gaps (holstered, PKE out, a cut-scene) are not counted.
static struct { int64_t okQ, firstQ; int why; LONG logs; LONG count[6]; } g_gm;
static void gun_miss(int why) {
  if (!g_gm.okQ || why < 1 || why > 5) return;
  ++g_gm.count[why];
  if (!g_gm.why) { g_gm.why = why; g_gm.firstQ = qpc_now(); }
}
static void gun_expected_gap() { g_gm.why = 0; g_gm.okQ = 0; }
static void gun_ok_note(int item) {
  const int64_t nq = qpc_now();
  if (g_gm.why && g_gm.okQ) {
    const double gap = (double)(nq - g_gm.okQ) / (double)qpc_freq();
    if (gap > 0.25 && InterlockedIncrement(&g_gm.logs) <= 30) {
      static const char* const kW[6] = {"", "the controller aim sample was older than 250 ms (tracking hiccup)", "no hand for the gun (hidden on purpose)", "no hold yet for this weapon (hidden on purpose)", "no exact hand relation: the gun stayed at the game's own spot", "the game's wand matrix or the aim could not be read"};
      HandsRaw hh; const int got = controllers_raw(&hh);
      log_line("GUNGONE t=%.2fs the gun was not at your hand for %d ms (the first cause: %s; item %d; two hands %d, controllers tracked %d/%d); times each exit was taken meanwhile: stale %ld, no hand %ld, no hold %ld, no relation %ld, unreadable %ld",
               (double)qpc_ms() / 1000.0, (int)(gap * 1000.0), kW[g_gm.why], item, got ? hh.wandTwo : -1, got ? hh.validL : -1, got ? hh.validR : -1, (long)g_gm.count[1], (long)g_gm.count[2], (long)g_gm.count[3], (long)g_gm.count[4], (long)g_gm.count[5]);
    }
  }
  g_gm.why = 0; g_gm.okQ = nq;
  for (int k = 1; k <= 5; ++k) g_gm.count[k] = 0;
}
// 1.7.156 GUNOUT: EVERY way the gun can end up somewhere other than your hand, with how long and why. (The 1.7.154 report had 9.5 s without a single gun
// placement and nothing in the log to say why: the "expected" exits below were never written down.)
static struct { int64_t placedQ, callQ; LONG n[12]; LONG logs; } g_go;
static inline void gun_exit(int k) { if (k > 0 && k < 12) ++g_go.n[k]; g_go.callQ = qpc_now(); }
static void gun_placed_note(int item) {
  const int64_t nq = qpc_now();
  if (g_go.placedQ) {
    const double gap = (double)(nq - g_go.placedQ) / (double)qpc_freq();
    long sum = 0; for (int k = 1; k < 12; ++k) sum += g_go.n[k];
    if (gap > 0.30 && g_go.logs < 80) {
      ++g_go.logs;
      HandsRaw hh; const int got = controllers_raw(&hh);
      log_line("GUNOUT t=%.2fs the gun was not placed in your hand for %d ms (item %d now). What the gun draw did meanwhile: game-in-charge guard %ld, placing switched off / no 3D %ld, no controller aim %ld, PKE out (gun stowed) %ld, "
               "aim older than 250 ms %ld, holstered %ld, bad game matrix %ld, hidden: no hand %ld, hidden: no hold yet %ld, left at the game's own spot %ld%s | trigger %d%%, two hands %d, stick %d%%",
               qpc_ms() / 1000.0, (int)(gap * 1000.0), item, g_go.n[1], g_go.n[2], g_go.n[3], g_go.n[4], g_go.n[5], g_go.n[6], g_go.n[7], g_go.n[8], g_go.n[9], g_go.n[10],
               sum == 0 ? " | NONE of these: the game did not draw your gun at all in that time" : "", got ? (int)(hh.trigR * 100.0f) : -1, got ? hh.wandTwo : -1, controllers_move_mag() / 10);
    }
  }
  g_go.placedQ = nq; g_go.callQ = nq;
  for (int k = 1; k < 12; ++k) g_go.n[k] = 0;
}
// 1.7.200 SCENEPROPS (variant A, safe): the roof fight's flashlight / walkie-talkie may be sub-meshes of the body model (visibility byte is read at collect time).
// Logs every sub-mesh name (3 times per model at most, only in the roof fight) and hides only names that look like a prop; restores the game's own byte when the scene ends.
static struct { uint8_t forced[200]; uint8_t was[200]; uintptr_t model; LONG logs; } g_sp;
static int prop_mesh_name(const char* s) {
  // 1.7.200 "make sure to remove the flashlight and walkie-talkie mesh in the roof fight": a wider list of words, and never a piece that looks like an arm, hand, glove or sleeve
  static const char* const k[] = {"flash", "torch", "radio", "walkie", "talk", "comm", "pda", "light", "lamp", "mic", "phone", "gadget", "device", "equip", "gear", "belt", "holster", "clip", "handheld", "prop", "item", "tool", "antenna", "battery", "calc"};
  static const char* const keep[] = {"arm", "hand", "glove", "sleeve", "finger", "wrist", "elbow", "shoulder", "clav", "thumb", "palm"};
  char b[0x3c]; int i = 0; for (; i < 0x3b && s[i]; ++i) b[i] = (char)(s[i] | 32); b[i] = 0;
  for (const char* w : keep) if (strstr(b, w)) return 0;
  for (const char* w : k) if (strstr(b, w)) return 1;
  return 0;
}
// 1.7.202 "just arms, the gun and the hose, that's it": in the roof fight every body sub-mesh is hidden except arm / hand / glove / sleeve pieces and torso-like cloth (which can hold the sleeves; the bone squash already hides it). Unknown names are hidden.
static int roof_keep_mesh(const char* s) {
  static const char* const k[] = {"arm", "hand", "glove", "sleeve", "finger", "wrist", "elbow", "shoulder", "clav", "thumb", "palm", "coat", "jacket", "torso", "body", "chest", "shirt", "uniform", "suit", "top", "jump", "cloth"};
  char b[0x3c]; int i = 0; for (; i < 0x3b && s[i]; ++i) b[i] = (char)(s[i] | 32); b[i] = 0;
  for (const char* w : k) if (strstr(b, w)) return 1;
  return 0;
}
static void scene_submesh_props(uintptr_t actor) {
  if (!actor || !memory_readable((const void*)(actor + 0x430 + 0x2088), 8)) return;
  uint8_t* model = (uint8_t*)(actor + 0x430);
  const uint8_t* def = *(const uint8_t**)(model + 0x2088);
  const int on = engine_scene_arms(actor);
  if (!def || !memory_readable(def + 0x12F8, 4)) return;
  const int n = *(const int*)(def + 0x12F8);
  if (n <= 0 || n > 200 || !memory_readable(def + 0x12FC, (size_t)n * 0x3c) || !memory_readable(model + 0x2094, 200) || !memory_readable(model + 0x2174, 1)) return;
  if (g_sp.model != (uintptr_t)model) { memset(&g_sp, 0, sizeof g_sp); g_sp.model = (uintptr_t)model; }   // a new model (level change): forget
  if (on && g_sp.logs < 3) {
    ++g_sp.logs; int vis = 0; for (int i = 0; i < n; ++i) vis += model[0x2094 + i] ? 1 : 0;
    log_line("SUBMESH #%ld t=%.2fs body model %p has %d sub-meshes, %d visible (roof fight)", (long)g_sp.logs, qpc_ms() / 1000.0, (void*)model, n, vis);
    for (int i = 0; i < n; ++i) log_line("SUBMESH %d/%d \"%.59s\" visible=%d prop_match=%d keep_as_arm_or_torso=%d", i, n, (const char*)(def + 0x12FC + i * 0x3c), (int)model[0x2094 + i], prop_mesh_name((const char*)(def + 0x12FC + i * 0x3c)), roof_keep_mesh((const char*)(def + 0x12FC + i * 0x3c)));
  }
  int keptVisible = 0; for (int i = 0; i < n; ++i) if (roof_keep_mesh((const char*)(def + 0x12FC + i * 0x3c)) && (model[0x2094 + i] || g_sp.forced[i])) ++keptVisible;
  for (int i = 0; i < n; ++i) {
    uint8_t& v = model[0x2094 + i];
    if (on) {
      const char* nm = (const char*)(def + 0x12FC + i * 0x3c);
      // hide: a prop-looking name, or (only when some arm / torso piece exists to keep) any name that is not an arm / torso piece
      if (v && (prop_mesh_name(nm) || (keptVisible > 0 && !roof_keep_mesh(nm)))) {
        if (!g_sp.forced[i]) { g_sp.forced[i] = 1; g_sp.was[i] = v; log_line("SCENEPROPS t=%.2fs hiding sub-mesh %d \"%.59s\" (roof fight)", qpc_ms() / 1000.0, i, (const char*)(def + 0x12FC + i * 0x3c)); }
        v = 0; model[0x2174] = 1;
      }
    } else if (g_sp.forced[i]) {
      if (!v) { v = g_sp.was[i]; model[0x2174] = 1; }
      g_sp.forced[i] = 0; log_line("SCENEPROPS t=%.2fs scene over, sub-mesh %d given back to the game", qpc_ms() / 1000.0, i);
    }
  }
}
// 1.7.200 SCENEKIDS: diagnostics only, what is attached to the player in the roof fight (nothing is hidden here)
static void scene_kids_log(uintptr_t actor) {
  static LONG s_n; static int64_t s_q;
  if (!actor || s_n >= 6 || !engine_scene_arms(actor) || qpc_now() - s_q < 2 * qpc_freq()) return;
  if (!memory_readable((const void*)(actor + 0x1E8), 8) || !memory_readable((const void*)(actor + 0x54), 12) || !memory_readable((const void*)(actor + layout::kOffPlayerPke), 0x10) || !memory_readable((const void*)(actor + 0x24D80), 0x20)) return;
  s_q = qpc_now(); ++s_n;
  uintptr_t c = *(const uintptr_t*)(actor + 0x1E8);
  for (int k = 0; c && k < 24 && memory_readable((const void*)c, 0x200); ++k, c = *(const uintptr_t*)(c + 0x1F0)) {
    const uintptr_t vt = *(const uintptr_t*)c; const float* p = (const float*)(c + 0x54);
    const int mine = (c == *(const uintptr_t*)(actor + 0x24D80) || c == *(const uintptr_t*)(actor + 0x24D88) || c == *(const uintptr_t*)(actor + layout::kOffPlayerPke) || c == *(const uintptr_t*)(actor + layout::kOffPlayerTether)) ? 1 : 0;
    log_line("SCENEKIDS #%ld child %d %p vtable rva 0x%x flags4C %08x pos %.1f,%.1f,%.1f ft (player %.1f,%.1f,%.1f) own_entity=%d", (long)s_n, k, (void*)c, (unsigned)(vt - g_game.base), (unsigned)*(const uint32_t*)(c + 0x4C),
             (double)p[0], (double)p[1], (double)p[2], (double)*(const float*)(actor + 0x54), (double)*(const float*)(actor + 0x58), (double)*(const float*)(actor + 0x5C), mine);
  }
}
static GBVR_NOINLINE float* hk_mat_mul_impl(const float* a, float* out, const float* b, void* ret) {
  const uintptr_t rr = (uintptr_t)ret - g_game.base;
  if (rr == layout::kRvaBodyPushRet) { scene_submesh_props((uintptr_t)g_selfActor); scene_kids_log((uintptr_t)g_selfActor); return body_push(a, out, b, 0); }
  if (rr == layout::kRvaExtrasPushRet) return body_push(a, out, b, 1);
  if (rr == layout::kRvaHosePushRet) {
    InterlockedExchange(&g_hoseTried, 0);
    float* r = body_push(a, out, b, 2);
    // 1.7.150: body_push left the hose where the game has it (body follow off, stale, cutscene...): the hose still follows a gun the mod drew this render
    if (!g_hoseTried && g_hoseGun.actor && (uintptr_t)a == g_hoseGun.actor + layout::kOffHoseWorld && memory_readable(a, 64)) hose_bend_try(g_hoseGun.actor, a, a);
    return r;
  }
  if ((uintptr_t)ret != rva(layout::kRvaWandPushRet)) {
    return o_matMul(a, out, b);
  }
  InterlockedIncrement(&g_wandSt.hookCalls);
  if (g_ctl.gamePlace) { InterlockedIncrement(&g_wandSt.gateOff); g_wandSt.gateOffLast = 16; gun_exit(2); return o_matMul(a, out, b); }   // 1.7.13: the game places the gun (and the PKE in the wand slot)
  if (!engine_scene_arms(0) && cine_blend() > 0.5) { InterlockedIncrement(&g_cineSt.wandPass); gun_expected_gap(); gun_exit(1); return o_matMul(a, out, b); }
  if (!g_ctl.realModels || !g_ctl.wandToHand || !g_ctl.stereoActive || g_tipHook != 1) { InterlockedIncrement(&g_wandSt.gateOff); gun_exit(2); g_wandSt.gateOffLast = (g_ctl.realModels ? 1 : 0) | (g_ctl.wandToHand ? 2 : 0) | (g_ctl.stereoActive ? 4 : 0) | (g_tipHook == 1 ? 8 : 0); return o_matMul(a, out, b); }
  uintptr_t actor = 0; float dir[3], grip[3], wup[3]; int64_t q = 0;
  if (!wand_aim_read(&actor, dir, grip, &q, wup) || !actor) { InterlockedIncrement(&g_wandSt.noAim); gun_miss(5); gun_exit(3); return o_matMul(a, out, b); }
  if ((uintptr_t)a != actor + layout::kOffWandWorld) { InterlockedIncrement(&g_wandSt.notMine); return o_matMul(a, out, b); }   // not the player's wand (another ghostbuster)
  InterlockedIncrement(&g_wandSt.calls);
  crumb("wand:in", 0);
  if ((g_ctl.pkeOwn || g_ctl.pkeGame) && pke_item_held()) {   // 0.93/0.94: the PKE is out: the game's wand-slot model (the stowed gun) is not drawn, the real PKE object is moved to the hand (see pke_place)
    float Z[16];
    for (int i = 0; i < 16; ++i) Z[i] = a[i];
    for (int r = 0; r < 3; ++r) for (int c2 = 0; c2 < 3; ++c2) Z[r * 4 + c2] *= 1e-4f;
    if (InterlockedIncrement(&g_pke.gunHidden) == 1) log_line("PKE the game's wand-slot model (the stowed gun) is hidden while the PKE is out; the game's own PKE object is moved to your right controller");
    InterlockedIncrement(&g_wandSt.pkeOut); gun_expected_gap(); gun_exit(4);
    return o_matMul(Z, out, b);
  }
  if (pke_mode()) InterlockedIncrement(&g_pke.wandSkips);   // 0.82: counted only; the wand matrix (the PKE) still goes to the controller like the gun
  if (!aim::is_fresh(qpc_now(), q, qpc_freq(), 250)) { InterlockedIncrement(&g_wandSt.stale); gun_miss(1); gun_exit(5); return o_matMul(a, out, b); }
  if (controllers_holstered()) {
    InterlockedIncrement(&g_wandSt.holstered); gun_expected_gap(); gun_exit(6);
    // 1.7.25: "when the gun is holstered ... it places the gun on the side instead of on the back": the gun is drawn at the pack (where the game draws the pack on the moved body)
    if (g_packPoseQ && aim::is_fresh(qpc_now(), g_packPoseQ, qpc_freq(), 250) && g_ctl.holsterOnBack) {
      float H[16]; int fin = 1;
      for (int i = 0; i < 16; ++i) { H[i] = a[i]; if (!vm::is_finite_f(a[i])) fin = 0; }
      for (int i = 0; i < 3; ++i) if (!vm::is_finite_f(g_packPoseW[12 + i])) fin = 0;
      if (fin) {
        H[12] = g_packPoseW[12]; H[13] = g_packPoseW[13] + 0.35f; H[14] = g_packPoseW[14];   // the pack's spot, a little higher (feet)
        // 1.7.99 "when the gun is holstered it goes through the chest": only the PLACE was the pack's, the TURN stayed the game's (barrel pointing forward, through the body).
        // The whole gun is now turned about its grip so the barrel points UP and a little BACK (along the pack), away from the chest and the view.
        float tipH[16] = {}; static LONG s_hpLogs; int posed = 0; float dirH[3] = {0, 1, 0};
        o_attach((void*)actor, tipH, "tip");
        {
          int tf = 1; for (int i = 8; i < 11; ++i) if (!vm::is_finite_f(tipH[i])) tf = 0;
          double fx = tipH[8], fz = tipH[10], fl = vm::dsqrt(fx * fx + fz * fz);
          {   // 1.7.101: the way the BODY faces (the stowed gun's own barrel can point sideways: the 1.7.100 log had it at 0.95/0.29/-0.14)
            float by = 0; int bok = 0;
            for (int tries = 0; tries < 3 && !bok; ++tries) { const LONG s0 = g_body.seq; if (s0 & 1) continue; by = (float)g_body.yaw; bok = g_body.seq == s0 && g_body.valid && vm::is_finite_f(by); }
            if (bok) { double sy, cy; vm::dsincos((double)by, &sy, &cy); fx = sy; fz = cy; fl = 1.0; tf = 1; }
          }
          if (tf && fl > 0.2) {   // the way the body faces, flattened
            dirH[0] = (float)(-fx / fl * 0.34); dirH[1] = 0.94f; dirH[2] = (float)(-fz / fl * 0.34);
            wand::Solve hs = {};
            const float gH[3] = {H[12], H[13], H[14]};
            if (wand::solve(a, tipH, gH, dirH, &hs, nullptr, 0.0)) {
              float Hp[16]; wand::apply_world(a, hs, gH, Hp);
              int ok = 1; for (int i = 0; i < 16; ++i) if (!vm::is_finite_f(Hp[i])) ok = 0;
              if (ok) { for (int i = 0; i < 16; ++i) H[i] = Hp[i]; posed = 1; }
              if (InterlockedIncrement(&s_hpLogs) <= 6) {
                const float* ap = (const float*)(actor + layout::kActorPos);
                const int rd = memory_readable(ap, 12);
                log_line("HOLSTERPOSE the holstered gun grip is %.1f/%.1f/%.1f cm (world x/y/z) from the actor feet, turned %.0f degrees so the barrel points up and back (%.2f/%.2f/%.2f); the game's own barrel pointed %.2f/%.2f/%.2f; turned gun used %d",
                  rd ? (H[12] - (double)ap[0]) * 30.48 : 0.0, rd ? (H[13] - (double)ap[1]) * 30.48 : 0.0, rd ? (H[14] - (double)ap[2]) * 30.48 : 0.0, (double)hs.turnDeg, (double)dirH[0], (double)dirH[1], (double)dirH[2], (double)tipH[8], (double)tipH[9], (double)tipH[10], posed);
              }
            }
          }
        }
        InterlockedIncrement(&g_wandSt.holsterBack);
        if (!pke_item_held()) hose_gun_note(actor, a, H);   // 1.7.149: the hose follows the holstered gun too
        return o_matMul(H, out, b);
      }
    }
    return o_matMul(a, out, b);
  }
  for (int i = 0; i < 16; ++i) if (!vm::is_finite_f(a[i])) { InterlockedIncrement(&g_wandSt.bad); gun_exit(7); return o_matMul(a, out, b); }
  if (g_ctl.pkeAttach && !g_ctl.pkeLikeGun && pke_item_held()) {   // 0.85: the PKE is the wand-slot model: it goes to the hand the way the game holds it (the armcore worked that out)
    float pw[16];
    if (arms_pke_wand(pw)) {
      if (InterlockedIncrement(&g_pke.gunHidden) == 1) log_line("PKE the wand-slot model (the PKE meter) is placed in your hand from the game's own hold pose");
      return o_matMul(pw, out, b);
    }
  }
  float tipm[16];
  o_attach((void*)actor, tipm, "tip");
  wand::Solve ws = {};
  const int wandSolved = wand::solve(a, tipm, grip, dir, &ws, wand_up_arg(wup), wand_roll_rad());
  if (!wandSolved) {
    const double dx=(double)tipm[12]-a[12], dy=(double)tipm[13]-a[13], dz=(double)tipm[14]-a[14];
    ws.gripToTipFt = (float)vm::dsqrt(dx*dx+dy*dy+dz*dz);
  }

  // 1.7.62: the GAME HAND is authoritative.  First preserve the complete
  // game prop->game hand relationship.  If the rig/view-model disappears for
  // a few frames, reconstruct the HAND from its last exact relationship to the
  // tracked controller, then apply the game prop->hand relationship to it.
  // The prop is never attached directly to a synthetic controller frame.
  float W2[16];
  int exactGrip = 0;
  int exactSlot = -1;
  int gunNoHold = 0;
  {
    int states[8], item = -1;
    fight_items(states, &item);
    if (item >= 0 && item < 8) exactSlot = item;
    if (exactSlot != g_vmLastSlot) {   // 1.7.66: the equipped item changed (weapon switch / spawn / back from the PKE): when, and whether the hand was there
      if (InterlockedIncrement(&g_vmSwitchLogs) <= 60) log_line("VMSWITCH t=%.2fs equipped item %d -> %d (the gun is drawn from the hand that was locked for that item, if any: %s)", qpc_ms() / 1000.0, g_vmLastSlot, exactSlot, (exactSlot >= 0 && g_exactWand.lock[exactSlot].locked) ? "locked" : "not locked yet");
      if (drawanim::is_gun_item(exactSlot)) g_hmUntilS = qpc_ms() / 1000.0 + 1.5;   // 1.7.99: the probe of the game's own hand runs whatever the setting
      if (g_ctl.drawAnim && drawanim::is_gun_item(exactSlot)) {
        const double ds = qpc_ms() / 1000.0;
        drawanim::begin(&g_drawWin, exactSlot, ds); g_da.offOn = 0; g_da.lastHave = 0;
        if (g_daLogs < 80) { ++g_daLogs; log_line("DRAWANIM t=%.2fs: item %d -> %d: the game's own draw animation is shown on your hand for up to %.1f s (view only: the aim, the trigger and the resting hold are not changed)", ds, g_vmLastSlot, exactSlot, drawanim::kWindowS); }
      }
      g_vmLastSlot = exactSlot;
    }
    float gameHand[16], finalHand[16];
    if (g_ctl.armIk && arms_game_hand_pair(actor, gameHand, finalHand)) {
      if (qpc_ms() / 1000.0 < g_hmUntilS) {   // 1.7.99 HANDMOVE: does the GAME move its own right hand (reach back, bring the gun up) when a weapon is drawn? Logged against the body, ~70 ms apart, for the draw window
        static double s_hmS; static float s_hmP[3]; static int s_hmHave; static LONG s_hmLogs;
        const float* ap = (const float*)(actor + layout::kActorPos);
        const double hs = qpc_ms() / 1000.0;
        if (memory_readable(ap, 12) && s_hmLogs < 90 && hs - s_hmS >= 0.07) {
          const double rx = ((double)gameHand[12] - ap[0]) * 30.48, ry = ((double)gameHand[13] - ap[1]) * 30.48, rz = ((double)gameHand[14] - ap[2]) * 30.48;
          const double mv = s_hmHave ? vm::dsqrt((rx - s_hmP[0]) * (rx - s_hmP[0]) + (ry - s_hmP[1]) * (ry - s_hmP[1]) + (rz - s_hmP[2]) * (rz - s_hmP[2])) : 0.0;
          s_hmP[0] = (float)rx; s_hmP[1] = (float)ry; s_hmP[2] = (float)rz; s_hmHave = 1; s_hmS = hs; ++s_hmLogs;
          log_line("HANDMOVE t=%.2fs item %d +%d ms: the GAME's own right hand is %.1f/%.1f/%.1f cm (side/up/front) from the body feet, moved %.1f cm since the last look", hs, exactSlot, (int)((hs - (g_hmUntilS - 1.5)) * 1000.0), rx, ry, rz, mv);
        }
      }
      if (g_ctl.gunFreshHand) {   // 1.7.77: the gun follows the hand as it is NOW (the controller's move since the last arm solve), not the hand of a frame or more ago
        ArmStereo ds; const int pr = g_ctl.pairHands && draw_stereo(&ds) && ds.pairQ;
        static int64_t s_gPair; static float s_gHand[16]; static int s_gHave; static volatile LONG s_gReuse;
        if (pr && ds.pairRole == 2 && s_gHave && s_gPair == ds.pairQ) { for (int i = 0; i < 16; ++i) finalHand[i] = s_gHand[i]; InterlockedIncrement(&s_gReuse); }   // the second eye gets exactly the first eye's gun
        else {
          hand_advance(finalHand, grip, dir, wup, q, g_gAdv);
          if (g_ctl.gunCtlFollow && exactSlot >= 0) {   // 1.7.78: once the hand<->controller relation of this weapon is locked, the gun sits on the CONTROLLER through it, whatever the arm solve made of the hand (it trailed 5-50 cm in fast moves and on stairs)
            handprop::HandFollower& hf = g_exactWand.handFollow[exactSlot];
            float trk[16], carried[16];
            if (hf.locked && g_exactWand.handFollowActor[exactSlot] == actor && handprop::tracked_frame(grip, dir, wup, trk)) {   // 1.7.143: the locked relation follows the drawn hand back (handprop drift_step)
              if (!controllers_reload_active() && handprop::drift_step(&hf, &g_gunDrift[exactSlot], finalHand, trk)) gun_drift_log(exactSlot, g_gunDrift[exactSlot]);
            }
            if (hf.locked && g_exactWand.handFollowActor[exactSlot] == actor && handprop::tracked_frame(grip, dir, wup, trk) && handprop::follow_hand(&hf, trk, carried)) {
              const double dcm = handprop::rel_pos_delta(finalHand, carried) * 30.48, dax = handprop::rel_axis_delta(finalHand, carried);
              InterlockedIncrement(&g_gCtl.used); g_gCtl.sumCm += dcm; if (dcm > g_gCtl.maxCm) g_gCtl.maxCm = dcm; g_gCtl.lastCm = dcm; if (dax > g_gCtl.maxAx) g_gCtl.maxAx = dax;
              if (dcm > 3.0) InterlockedIncrement(&g_gCtl.over3cm);
              if (dcm > 6.0) {   // 1.7.93: the drawn hand is clearly away from the gun for a moment; the first few such moments, once a second at most, with what else was going on (the 1.7.89 log only had totals)
                static LONG s_slipLogs; static int64_t s_slipQ; const int64_t nqs = qpc_now();
                if (s_slipLogs < 16 && (!s_slipQ || (double)(nqs - s_slipQ) / (double)qpc_freq() >= 1.0)) {
                  s_slipQ = nqs; ++s_slipLogs;
                  HandsRaw hs; const int gotS = controllers_raw(&hs);
                  log_line("GUNSLIP t=%.2fs item %d: the drawn hand is %.1f cm (axes off %.4f) from where the controller puts the gun | arm lengthened to %d%% | two hands %d, trigger %d%%, walking stick %d%%, the hand was moved on %.1f cm since the arm solve",
                           qpc_ms() / 1000.0, exactSlot, dcm, dax, arms_right_stretch_x100(), gotS ? hs.wandTwo : -1, gotS ? (int)(hs.trigR * 100.0f) : -1, controllers_move_mag() / 10, g_gAdv.lastCm);
                }
              }
              for (int i = 0; i < 16; ++i) finalHand[i] = carried[i];
            } else InterlockedIncrement(&g_gCtl.notLocked);
          }
          if (pr && ds.pairRole == 1) { for (int i = 0; i < 16; ++i) s_gHand[i] = finalHand[i]; s_gPair = ds.pairQ; s_gHave = 1; }
        }
      }
      {   // 1.7.100 a new model / skeleton: no hold of the old model is carried over
        static LONG s_gunGen;
        if (s_gunGen != g_modelGen) {
          s_gunGen = g_modelGen;
          for (int i = 0; i < 9; ++i) { handprop::reset(&g_exactWand.lock[i]); handprop::reset(&g_exactWand.handFollow[i]); g_exactWand.lockActor[i] = 0; g_exactWand.handFollowActor[i] = 0; }
          drawanim::reset(&g_drawWin); g_da.offOn = 0; g_da.lastHave = 0;
          // 1.7.175: everything else that remembers the OLD hand / model (the log line below always said "all"): the hand-move base frame, the exact-wand sample, the live holds, the drift trackers
          g_solveTrk.q = 0; g_solveTrk.aimQ = 0; g_solveTrkPend.q = 0; g_solveTrkPend.aimQ = 0; g_exactWand.have = 0;
          for (int i = 0; i < 9; ++i) { handprop::reset(&g_gunLive[i]); g_gunLiveActor[i] = 0; handprop::reset(&g_gunDrift[i]); }
          log_line("MODELCHANGE the gun holds of all weapons were dropped (they are taken again from the new model's hand)");
        }
      }
      if (exactSlot >= 0) {
        // A holster, beam/viewmodel rebuild or streamed model keeps the same player's grip.
        // A genuinely new player actor must never inherit a relation from an old skeleton/model.
        if (g_exactWand.lockActor[exactSlot] && g_exactWand.lockActor[exactSlot] != actor) {
          handprop::reset(&g_exactWand.lock[exactSlot]);
          handprop::reset(&g_exactWand.handFollow[exactSlot]);
          g_exactWand.handFollowActor[exactSlot] = 0;
        }
        if (g_ctl.gunLiveGrip) {
          {   // 1.7.69: every equip / weapon switch / unholster starts from the game's hold of that moment (the same rule each time, no old hold carried over)
            const int64_t nq = qpc_now();
            // 1.7.70: the hold is kept per weapon (only holds with the gun really in the hand are ever stored, see below), so a switch or unholster starts from that
            // weapon's own hold at once; only a different player character starts empty
            if (g_gunLiveActor[exactSlot] != actor) { handprop::reset(&g_gunLive[exactSlot]); g_gunLiveActor[exactSlot] = actor; }
            g_gunLiveQ[exactSlot] = nq; g_gunLiveSlot = exactSlot;
          }
          float fr[16];
          const long jb = g_gunLive[exactSlot].jumps;
          if (handprop::relative(a, gameHand, fr)) {
            // 1.7.70: the 1.7.69 log: right after a switch the game's "hold" was 70.8 cm (the draw animation: the gun is still on its way from the back) and the
            // first-sample rule took it, so the gun floated sideways beside the hand for a moment. A hold farther than 25 cm from the hand is not a hold: not used.
            const double flen = vm::dsqrt((double)fr[12] * fr[12] + (double)fr[13] * fr[13] + (double)fr[14] * fr[14]);
            if (flen <= 0.82) handprop::live_update(&g_gunLive[exactSlot], fr, 0.25, 0.04, 8);
            else InterlockedIncrement(&g_gunFarHolds);
          }
          handprop::Live& gl = g_gunLive[exactSlot];
          if (!gl.have) gunNoHold = 1;   // the very first draw of this weapon, still in the draw animation: not drawn at the animation's spot
          // 1.7.71 "the hand shakes when two-handing and walking": the game's own hold sways a little with its walk animation and the gun followed every
          // frame, so the gun (and the left hand on its barrel) trembled. Small changes of the hold are now eased (gun_hold_smooth_ms); a real change
          // of hold (a jump) or a new draw still snaps at once.
          const float* relUse = gl.rel;
          if (gl.have) {
            static float s_sm[9][16]; static int s_smHave[9]; static long s_smJumps[9]; static int64_t s_smQ[9]; static float s_prevRaw[9][16];
            { static LONG s_smGen; if (s_smGen != g_modelGen) { s_smGen = g_modelGen; for (int i = 0; i < 9; ++i) { s_smHave[i] = 0; s_smQ[i] = 0; } } }   // 1.7.181: no easing from the old hand
            const int64_t nq = qpc_now();
            const double dt = s_smQ[exactSlot] ? (double)(nq - s_smQ[exactSlot]) / (double)qpc_freq() : 1.0;
            if (s_smHave[exactSlot] && dt < 0.3) {   // data: how much the game's hold moves per update, standing vs walking
              const double st = handprop::rel_pos_delta(gl.rel, s_prevRaw[exactSlot]) * 30.48;
              const int walking = controllers_move_mag() > 300;
              g_gunHoldStep[walking] += st; ++g_gunHoldStepN[walking]; if (st > g_gunHoldStepMax[walking]) g_gunHoldStepMax[walking] = st;
            }
            for (int i = 0; i < 16; ++i) s_prevRaw[exactSlot][i] = gl.rel[i];
            const double tau = (double)g_ctl.gunHoldSmoothMs / 1000.0;
            if (tau <= 0.001 || !s_smHave[exactSlot] || gl.jumps != s_smJumps[exactSlot] || dt > 0.3) {
              for (int i = 0; i < 16; ++i) s_sm[exactSlot][i] = gl.rel[i];
              s_smHave[exactSlot] = 1; s_smJumps[exactSlot] = gl.jumps;
            } else if (dt > 0.0) {
              const float k = (float)(dt / (tau + dt));
              for (int i = 0; i < 16; ++i) s_sm[exactSlot][i] += (gl.rel[i] - s_sm[exactSlot][i]) * k;
              ++g_gunHoldEased;
            }
            s_smQ[exactSlot] = nq;
            relUse = s_sm[exactSlot];
          }
          exactGrip = gl.have && handprop::place(relUse, finalHand, W2);
          if (exactGrip) {   // the model-gap path below reads the lock
            handprop::GripLock& lk = g_exactWand.lock[exactSlot];
            for (int i = 0; i < 16; ++i) lk.rel[i] = gl.rel[i];
            lk.havePrev = 1; lk.locked = 1;
          }
          if ((gl.accepted == 1 || gl.jumps != jb) && InterlockedIncrement(&g_gunLiveLogs) <= 40)
            log_line("GUNGRIP live t=%.2fs item %d: %s; game's hand-to-gun relation %.1f cm long", qpc_ms() / 1000.0, exactSlot, gl.jumps != jb ? "the game's hold changed and stayed changed: followed" : "first hold taken from the game now",
                     vm::dsqrt((double)gl.rel[12]*gl.rel[12] + (double)gl.rel[13]*gl.rel[13] + (double)gl.rel[14]*gl.rel[14]) * 30.48);
        } else {
          handprop::GripLock& fl = g_exactWand.lock[exactSlot];
          const long farBefore = fl.tooFar;
          exactGrip = handprop::step(&fl, a, gameHand, finalHand, W2);
          // 1.7.93: a gun that is not within reach of the hand (still on the back at a cut-scene start: 40 and 78 cm in the 1.7.80 / 1.7.90 logs) is no hold; nothing is locked from it
          static long s_farRun[9]; static LONG s_farLogs;
          if (fl.tooFar != farBefore) {
            if (++s_farRun[exactSlot] == 1 && InterlockedIncrement(&s_farLogs) <= 20)
              log_line("GUNGRIP far t=%.2fs item %d: the game's gun is %.1f cm from its hand (a hold is under %.0f cm): not locked as the grip; the game's own spot is used until the gun is in the hand", qpc_ms() / 1000.0, exactSlot, fl.lastFarFt * 30.48, handprop::kMaxHoldFt * 30.48);
          } else if (exactGrip && s_farRun[exactSlot]) {
            if (InterlockedIncrement(&s_farLogs) <= 20)
              log_line("GUNGRIP in hand t=%.2fs item %d: after %ld far samples the gun came to the hand (%.1f cm); the grip is taken from the game's hold now", qpc_ms() / 1000.0, exactSlot, s_farRun[exactSlot], handprop::rel_len_ft(fl.rel) * 30.48);
            s_farRun[exactSlot] = 0;
          }
          {   // 1.7.98 THE GAME'S OWN DRAW ANIMATION, on your hand: for the first moment after a switch the gun is placed through the relation the game shows NOW (it travels in from the back,
              // the game's own fingers close on it) instead of appearing in the hand. View only: the stored hold (fl), the aim, the trigger and the beam direction are not touched.
            const double nowS = qpc_ms() / 1000.0;
            int animShown = 0;
            if (g_ctl.drawAnim && g_drawWin.open) {
              float fr[16], Wa[16];
              if (handprop::relative(a, gameHand, fr)) {
                const int haveHold = fl.locked;
                const double lenFt = handprop::rel_len_ft(fr), distFt = haveHold ? handprop::rel_pos_delta(fr, fl.rel) : 0.0;
                if (drawanim::step(&g_drawWin, exactSlot, nowS, lenFt, haveHold, distFt, handprop::kMaxHoldFt) && handprop::place(fr, finalHand, Wa)) {
                  for (int i = 0; i < 16; ++i) W2[i] = Wa[i];
                  exactGrip = 1; animShown = 1;
                  for (int i = 0; i < 3; ++i) g_da.lastPos[i] = Wa[12 + i];
                  g_da.lastHave = 1; g_da.offOn = 0;
                  da_log_shown("gun", exactSlot, g_drawWin, nowS, lenFt, haveHold, distFt);
                }
              }
              da_log_end("gun", exactSlot, g_drawWin);
            }
            if (!animShown && exactGrip) {   // the normal hold again: the last animated spot against it fades out in about 80 ms, so nothing pops
              if (g_da.lastHave) {
                for (int i = 0; i < 3; ++i) g_da.off[i] = g_da.lastPos[i] - (double)W2[12 + i];
                const double offLen = vm::dsqrt(g_da.off[0] * g_da.off[0] + g_da.off[1] * g_da.off[1] + g_da.off[2] * g_da.off[2]);
                g_da.lastHave = 0; g_da.offStartS = nowS; g_da.offOn = offLen > 0.005 && offLen < 3.3;
              }
              if (g_da.offOn) {
                const double k = drawanim::fade(nowS - g_da.offStartS);
                if (k <= 0.0) g_da.offOn = 0; else for (int i = 0; i < 3; ++i) W2[12 + i] += (float)(g_da.off[i] * k);
              }
            }
          }
        }
        if (exactGrip) gun_grip_heal(exactSlot, actor, a, gameHand);
        if (exactGrip) {
          g_exactWand.lockActor[exactSlot] = actor;
          float tracked[16];
          if (g_exactWand.handFollowActor[exactSlot] && g_exactWand.handFollowActor[exactSlot] != actor)
            handprop::reset(&g_exactWand.handFollow[exactSlot]);
          if (handprop::tracked_frame(grip, dir, wup, tracked) &&
              handprop::capture_hand(&g_exactWand.handFollow[exactSlot], finalHand, tracked))
            g_exactWand.handFollowActor[exactSlot] = actor;
          static LONG s_exactGunLog[9];
          if (InterlockedIncrement(&s_exactGunLog[exactSlot]) == 1)
            log_line("HANDGRIP gun item %d captured from GAME hand (viewmodel/holster changes keep this grip; no cm/controller prop offset)", exactSlot);
        }
      } else {
        // Unknown item for a frame: use only the game's CURRENT exact relation.
        // Never store it in a shared slot a different weapon could inherit.
        float rel[16]; exactGrip = handprop::relative(a, gameHand, rel) && handprop::place(rel, finalHand, W2);
      }
      if (exactGrip) InterlockedIncrement(&g_exactWand.used);
      if (exactGrip == 1 && exactSlot >= 0) {   // 1.7.155 FIREGUN: "the gun floats out of the hand when fired". Trigger up against trigger down, measured where the gun is drawn:
        // the gun's grip against the drawn hand, the drawn hand against the controller, and how far the GAME's own hold is from the locked one right now
        // (the game's fire animation moving the gun in its hand, or its hand under the gun).
        static struct { double sumGH, sumHC, sumGame, maxGH, maxHC, maxGame; long n; } s_f[2];
        static int64_t s_fq; static LONG s_fLogs;
        HandsRaw fh; const int gotF = controllers_raw(&fh);
        const int down = gotF && fh.trigR > 0.6f;
        float rw[16], fresh[16];
        const double gh = handprop::relative(W2, finalHand, rw) ? handprop::rel_len_ft(rw) * 30.48 : -1.0;
        const double hx = (double)finalHand[12] - grip[0], hy = (double)finalHand[13] - grip[1], hz = (double)finalHand[14] - grip[2];
        const double hc = vm::dsqrt(hx * hx + hy * hy + hz * hz) * 30.48;
        const double gm = (g_exactWand.lock[exactSlot].locked && handprop::relative(a, gameHand, fresh)) ? handprop::rel_pos_delta(fresh, g_exactWand.lock[exactSlot].rel) * 30.48 : -1.0;
        if (gotF && gh >= 0.0 && gm >= 0.0 && gh < 500.0 && hc < 500.0 && gm < 500.0) {
          s_f[down].sumGH += gh; s_f[down].sumHC += hc; s_f[down].sumGame += gm; ++s_f[down].n;
          if (gh > s_f[down].maxGH) s_f[down].maxGH = gh; if (hc > s_f[down].maxHC) s_f[down].maxHC = hc; if (gm > s_f[down].maxGame) s_f[down].maxGame = gm;
        }
        const int64_t fq = qpc_now();
        if (!s_fq) s_fq = fq;
        if ((double)(fq - s_fq) / (double)qpc_freq() >= 10.0 && s_f[1].n >= 30 && s_fLogs < 60) {
          ++s_fLogs; s_fq = fq;
          const double u = s_f[0].n ? (double)s_f[0].n : 1.0, d = (double)s_f[1].n;
          log_line("FIREGUN t=%.1fs item %d | trigger UP (%ld draws): gun grip to drawn hand %.1f cm (most %.1f), drawn hand to controller %.1f cm (most %.1f), game's own hold away from the locked hold %.1f cm (most %.1f) | "
                   "trigger DOWN (%ld draws): gun to hand %.1f cm (most %.1f), hand to controller %.1f cm (most %.1f), game's hold away %.1f cm (most %.1f) | two hands %d | the gun is locked in the drawn hand when the first figure is the same up and down",
                   qpc_ms() / 1000.0, exactSlot, s_f[0].n, s_f[0].sumGH / u, s_f[0].maxGH, s_f[0].sumHC / u, s_f[0].maxHC, s_f[0].sumGame / u, s_f[0].maxGame,
                   s_f[1].n, s_f[1].sumGH / d, s_f[1].maxGH, s_f[1].sumHC / d, s_f[1].maxHC, s_f[1].sumGame / d, s_f[1].maxGame, gotF ? fh.wandTwo : -1);
          for (int k = 0; k < 2; ++k) { s_f[k].sumGH = s_f[k].sumHC = s_f[k].sumGame = s_f[k].maxGH = s_f[k].maxHC = s_f[k].maxGame = 0; s_f[k].n = 0; }
        }
      }
      if (exactGrip == 1) {   // 1.7.67 data only: does the drawn hand change size while the gun is held? (the 1.7.66 PKE log showed it growing from 1.02 to 1.38 and up to 1.9 on one axis)
        static int64_t s_ghQ; static LONG s_ghN;
        const int64_t nq = qpc_now();
        if ((!s_ghQ || (double)(nq - s_ghQ) / (double)qpc_freq() >= 1.0) && s_ghN < 300) {
          s_ghQ = nq; ++s_ghN;
          const double gx = (double)finalHand[12] - grip[0], gy = (double)finalHand[13] - grip[1], gz = (double)finalHand[14] - grip[2];
          HandsRaw hh; const int gotH = controllers_raw(&hh);
          log_line("GUNHAND t=%.2fs item %d | drawn hand axes %.2f/%.2f/%.2f (longest/shortest %.2f, arm lengthened to %d%%, game's hand %.2f) | gun drawn at %.2f x its game size | drawn hand to controller grip %.1f cm | two hands %d, stick %d%% | game's hold moves per update: standing mean %.2f max %.2f cm, walking mean %.2f max %.2f cm, eased %ld (gun_hold_smooth_ms %d) | hand moved on with the controller %ld times (mean %.1f cm, last %.1f, most %.1f; solve age mean %.0f ms, most %.0f; same sample %ld, too old %ld, no frame %ld) | gun on the controller through the locked relation %ld times (the arm solve's hand was %.1f cm away on average, %.1f now, %.1f at most, over 3 cm %ld; relation not locked %ld)",
                   qpc_ms() / 1000.0, exactSlot, handprop::row_len(finalHand, 0), handprop::row_len(finalHand, 1), handprop::row_len(finalHand, 2), handprop::row_ratio(finalHand),
                   arms_right_stretch_x100(), handprop::mean_scale(gameHand), handprop::mean_scale(W2), vm::dsqrt(gx * gx + gy * gy + gz * gz) * 30.48,
                   gotH ? hh.wandTwo : -1, controllers_move_mag() / 10,
                   g_gunHoldStepN[0] ? g_gunHoldStep[0] / g_gunHoldStepN[0] : 0.0, g_gunHoldStepMax[0], g_gunHoldStepN[1] ? g_gunHoldStep[1] / g_gunHoldStepN[1] : 0.0, g_gunHoldStepMax[1], g_gunHoldEased, (int)g_ctl.gunHoldSmoothMs,
                   (long)g_gAdv.advanced, g_gAdv.advanced ? g_gAdv.sumCm / (double)g_gAdv.advanced : 0.0, g_gAdv.lastCm, g_gAdv.maxCm, g_gAdv.advanced ? g_gAdv.sumAgeMs / (double)g_gAdv.advanced : 0.0, g_gAdv.maxAgeMs, (long)g_gAdv.sameSample, (long)g_gAdv.tooOld, (long)g_gAdv.noFrame,
                   (long)g_gCtl.used, g_gCtl.used ? g_gCtl.sumCm / (double)g_gCtl.used : 0.0, g_gCtl.lastCm, g_gCtl.maxCm, (long)g_gCtl.over3cm, (long)g_gCtl.notLocked);
          g_gunHoldStepMax[0] = g_gunHoldStepMax[1] = 0.0;
        }
      }
    }
  }

  if (!exactGrip && exactSlot >= 0 && g_exactWand.lock[exactSlot].havePrev &&
      g_exactWand.handFollow[exactSlot].have && g_exactWand.handFollowActor[exactSlot] == actor) {
    float tracked[16], carriedHand[16];
    if (handprop::tracked_frame(grip, dir, wup, tracked) &&
        handprop::follow_hand(&g_exactWand.handFollow[exactSlot], tracked, carriedHand) &&
        handprop::place(g_exactWand.lock[exactSlot].rel, carriedHand, W2)) {
      exactGrip = 3; // hand-first continuity through a model/rig streaming gap
      const LONG fb = InterlockedIncrement(&g_exactWand.fallback);
      if (fb <= 6) log_line("HANDGRIP gun item %d model gap: reconstructed GAME hand first, then reapplied its locked grip", exactSlot);
    }
  }
  {   // 1.7.66: no hand for the gun (spawn, weapon switch): do not draw it at the game's own spot
    const int hideGun = gun_gap_step(exactGrip == 1 ? 1 : (exactGrip == 3 ? 3 : 0));
    if (hideGun) {
      float Zg[16];
      for (int i = 0; i < 16; ++i) Zg[i] = a[i];
      for (int r = 0; r < 3; ++r) for (int c2 = 0; c2 < 3; ++c2) Zg[r * 4 + c2] *= 1e-4f;
      InterlockedIncrement(&g_wandSt.gapHidden); gun_miss(2); gun_exit(8);
      return o_matMul(Zg, out, b);
    }
  }
  if (!exactGrip && gunNoHold) {   // 1.7.70
    float Zg[16];
    for (int i = 0; i < 16; ++i) Zg[i] = a[i];
    for (int r = 0; r < 3; ++r) for (int c2 = 0; c2 < 3; ++c2) Zg[r * 4 + c2] *= 1e-4f;
    InterlockedIncrement(&g_gunNoHoldHidden); gun_miss(3); gun_exit(9);
    return o_matMul(Zg, out, b);
  }
  if (!exactGrip) {
    // No exact GAME hand relationship exists yet. Leave the game's model where
    // the game put it for this frame. arm_drive bootstraps the right hand from
    // the controller, so the exact pair becomes available without inventing a grip.
    InterlockedIncrement(&g_exactWand.fallback); gun_miss(4); gun_exit(10);
    return o_matMul(a, out, b);
  }

  // Exact placement supersedes every legacy translation/fit path.
  g_gunRigidLast[0]=g_gunRigidLast[1]=g_gunRigidLast[2]=0.0f; g_gunRigidAt=0;
  g_gunFitOff[0]=g_gunFitOff[1]=g_gunFitOff[2]=0.0f; g_gunFitAt=0;
  if (!pke_item_held()) hose_gun_note(actor, a, W2);   // 1.7.149: the gun in your hand (never the PKE: the hose does not go to it) (before the view-model size, so the hose keeps its own thickness)
  {   // 0.77 view model size: the gun is drawn bigger about its grip (the model's origin is at the grip, so its position stays; the axis rows grow)
    const LONG vp = g_ctl.viewModelPct;
    if (vp >= 80 && vp <= 200 && vp != 100) {
      const float k = (float)vp * 0.01f;
      for (int r = 0; r < 3; ++r) for (int cc = 0; cc < 3; ++cc) W2[r * 4 + cc] *= k;
      if (InterlockedIncrement(&g_wandSt.sized) == 1) log_line("WAND size: the drawn gun is %d%% of the game's size (view_model_pct); the beam starts at its muzzle", (int)vp);
    }
  }
  if (exactGrip == 1 || exactGrip == 3) {
    // Publish the exact game-prop -> final-prop pair for the tip/beam hook.  The
    // sequence makes the cross-hook snapshot atomic enough for a render thread.
    InterlockedIncrement(&g_exactWand.seq);
    g_exactWand.actor = actor;
    for (int i = 0; i < 16; ++i) { g_exactWand.gameM[i] = a[i]; g_exactWand.finalM[i] = W2[i]; }
    g_exactWand.q = qpc_now(); g_exactWand.have = 1;
    InterlockedIncrement(&g_exactWand.seq);
  }
  {   // 1.7.2 the final spot of the gun, kept for the HOLDCHECK line, and the numbers at fixed seconds after it came into the hand ("good at the start, off after 2 seconds")
    for (int i = 0; i < 3; ++i) { g_gunPlaced[i] = W2[12 + i]; g_gunPlacedDir[i] = dir[i]; g_gunPlacedGrip[i] = grip[i]; g_gunPlacedUp[i] = wup[i]; }
    g_gunPlacedAt = qpc_now();
    const double sl = vm::dsqrt((double)g_gunRigidLast[0] * g_gunRigidLast[0] + (double)g_gunRigidLast[1] * g_gunRigidLast[1] + (double)g_gunRigidLast[2] * g_gunRigidLast[2]);
    holdcheck_timeline(0, W2 + 12, dir, sl, (int)g_ctl.gunFwdCm);
  }
  {   // 1.7.31: seen from this eye (see gear_note)
    HandsRaw hg; const int gotG = controllers_raw(&hg);
    gear_note(gotG && hg.wandTwo ? 1 : 0, W2 + 12);
  }
  InterlockedIncrement(&g_wandSt.applied);
  g_wandSt.lastAppliedAt = (LONG)(GetTickCount() / 1000);
  fight_hose_posed(a, W2);   // 0.76
  g_wandSt.lastTurnX10 = (LONG)(ws.turnDeg * 10.0f);
  if (g_wandSt.lastTurnX10 > g_wandSt.maxTurnX10) g_wandSt.maxTurnX10 = g_wandSt.lastTurnX10;
  g_wandSt.lastGripTipX100 = (LONG)(ws.gripToTipFt * 100.0f);
  {   // 1.7.19 per weapon: how long each item was in hand and how long its barrel is (the left hand's place under the barrel and the muzzle depend on it)
    int st8[8], cur8 = -1; const int fresh8 = fight_items(st8, &cur8);
    const int it = fresh8 && cur8 >= 0 && cur8 < 8 ? cur8 : 0;
    const LONG gt = g_wandSt.lastGripTipX100;
    ++g_wpn[it].frames; g_wpn[it].tipSum += gt; if (!g_wpn[it].tipMin || gt < g_wpn[it].tipMin) g_wpn[it].tipMin = gt; if (gt > g_wpn[it].tipMax) g_wpn[it].tipMax = gt;
    if (it != g_wpnLast) { ++g_wpn[it].switchesTo; if (g_wpnLogged < 24) { ++g_wpnLogged; log_line("WEAPON in hand now: item %d (%s), the barrel from the grip to the muzzle is %d.%02d ft", it, kWpnName[it], (int)(gt / 100), (int)(gt % 100)); } g_wpnLast = it; }
  }
  g_wandSt.lastRollX10 = (LONG)(ws.rollDeg * 10.0f); if (ws.rolled) InterlockedIncrement(&g_wandSt.rolled);
  { const LONG ar = g_wandSt.lastRollX10 < 0 ? -g_wandSt.lastRollX10 : g_wandSt.lastRollX10; if (ar > g_wandSt.maxRollX10) g_wandSt.maxRollX10 = ar; }
  g_wandSt.lastShiftX100 = (LONG)(ws.shiftFt * 100.0f);
  for (int i = 0; i < 3; ++i) { g_wandSt.lastTip0[i] = tipm[12 + i]; g_wandSt.lastW[i] = a[12 + i]; }
  if (InterlockedIncrement(&g_wandSt.firstLogged) == 1)
    log_line("WAND first move: the game's wand model (matrix at actor+0x%x, grip %.2f,%.2f,%.2f feet, tip %.2f,%.2f,%.2f, %.2f ft grip-to-tip) "
             "turned %.1f degrees and moved %.2f ft to the controller", (unsigned)layout::kOffWandWorld, (double)a[12], (double)a[13], (double)a[14],
             (double)tipm[12], (double)tipm[13], (double)tipm[14], (double)ws.gripToTipFt, (double)ws.turnDeg, (double)ws.shiftFt);
  gun_ok_note(exactSlot);
  gun_placed_note(exactSlot);
  return o_matMul(W2, out, b);
}
static float* __fastcall hk_mat_mul(const float* a, float* out, const float* b) { return hk_mat_mul_impl(a, out, b, GBVR_RETURN_ADDRESS()); }

static void install_wand_hook() {
  int fn = bytes_match(layout::kRvaMatMul, layout::kBytesMatMul, 16);
  const uint8_t* p = (const uint8_t*)rva(layout::kRvaWandPushCall);
  int call = p[0] == 0xe8 && (uintptr_t)(p + 5 + *(const int32_t*)(p + 1)) == rva(layout::kRvaMatMul) && (uintptr_t)(p + 5) == rva(layout::kRvaWandPushRet);
  {  // 0.52: the three other world-matrix products of the player's render function; if one differs the body just is not moved
    const uint32_t calls[3] = {layout::kRvaBodyPushCall, layout::kRvaExtrasPushCall, layout::kRvaHosePushCall};
    const uint32_t rets[3] = {layout::kRvaBodyPushRet, layout::kRvaExtrasPushRet, layout::kRvaHosePushRet};
    int okc = 1;
    for (int i = 0; i < 3; ++i) {
      const uint8_t* q = (const uint8_t*)rva(calls[i]);
      if (q[0] != 0xe8 || (uintptr_t)(q + 5 + *(const int32_t*)(q + 1)) != rva(layout::kRvaMatMul) || calls[i] + 5 != rets[i]) okc = 0;
    }
    if (!okc) {
      InterlockedExchange(&g_ctl.bodyFollow, 0);
      log_line("BODY follow not available: the body / extras / hose matrix call sites differ in this game build (body_follow switched off)");
    }
  }
  if (!fn || !call || g_tipHook != 1) {
    g_wandHook = -1;
    log_line("WAND model move not available (matrix product bytes=%d call site=%d tipHook=%d): the game's wand stays where the game animates it", fn, call, g_tipHook);
    return;
  }
  void* t = (void*)rva(layout::kRvaMatMul);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_mat_mul, (void**)&o_matMul);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_wandHook = s == MH_OK ? 1 : -2;
  log_line("HOOK wand-matrix status=%d target=%p (the game's wand model moves to the controller: %s)", (int)s, t, g_wandHook == 1 ? "available" : "NOT available");
}


// ===== 0.94 the game's OWN PKE meter in the hand ===========================================================================
// The PKE the player holds is a separate object (CPKEMeter, layout.h). 0.94-0.96 rewrote only its second "pose" (+0x4B8). The 0.96 log proved that this was NOT what the screen shows:
// the game draws the meter with its ENTITY matrix (position +0x54, rotation +0xF4: collect -> 0x110570 -> 0x1402C2800 pushes exactly those), which stayed where the game's animation puts it
// ("moved 2.62 ft" once, then 0.00 forever, because only the second pose was moved). The same entity position is the centre of the scan range and where its sounds / sparks start.
// 0.97: right before the meter is drawn (collect) and before it updates / scans (update), the entity matrix AND the pose are set to the controller:
//   - the front is the model's own front: local +Y (its "tip" attachment is at 0, 1.07, 0.03 in the model's axes - read from the game every run, +Y is only the default),
//   - the up is the axis that points up in the game's level hold, set to the controller's up (pkemath.h look),
//   - the position is the controller's grip point (slid into the visible hand the way the gun is).
// The game writes the entity again every frame from its animation, so nothing is put back; the probe only remembers which values are its own to tell the game's placement apart.
typedef void*(__fastcall* PFN_PkeCollect)(void* self, void* ctx);
typedef void(__fastcall* PFN_PkeUpdate)(void* self, float dt);
typedef unsigned char(__fastcall* PFN_EntityAttachWorld)(void* self, const char* name, float* out);
static PFN_PkeCollect o_pkeCollect;
static PFN_PkeUpdate o_pkeUpdate;
static PFN_EntityAttachWorld o_entAttach;
int engine_boss_mouth(uintptr_t boss, float* mouth) {
  if (g_pkeHook != 1 || !o_entAttach || !boss || !memory_readable((const void*)boss, 0x60) ||
      *(const uintptr_t*)boss != rva(0x7A0678)) return 0;
  float m[16] = {}; for (int i = 0; i < 4; ++i) m[5 * i] = 1.0f;
  // The boss itself requests "mouth" through this same verified function
  // at 0x16A7BF, 0x16BAd6 and 0x16C20C.
  if (!o_entAttach((void*)boss, "mouth", m)) return 0;
  const float* root = (const float*)(boss + layout::kActorPos);
  double d2 = 0;
  for (int i = 0; i < 3; ++i) {
    if (!vm::is_finite_f(m[12 + i]) || !vm::is_finite_f(root[i])) return 0;
    const double d = (double)m[12 + i] - root[i]; d2 += d * d;
    mouth[i] = m[12 + i];
  }
  return d2 > 1.0 && d2 < 500.0 * 500.0;
}
static volatile LONG g_pkLock;
static struct {
  volatile LONG collects, updates, placed, notHeld, noAim, notPlayer, bad, disabled, tipFixed, tipSeen, rollFixed, swung, busy;
  volatile LONG minMovedX100, maxMovedX100;   // how far (ft x100) the game's own position was from the controller when it was moved
  uintptr_t self;      // the player's PKE object last placed
  int64_t placedQ;     // when
  float newM[16];      // the placed pose as a 4x4 (rows = axes, row 3 = position)
  int axis, sign;      // front axis / sign
  int haveAxis;
  float lastDot[3], lastSwing, lastRoll, lastGame[3], lastNew[3], lastEnt[3], lastUpDots[3];
  // 0.97
  volatile LONG entMoved, entNoRead, entGameSeen, entOursSeen, upFoundLogged, upLocked, tentative, tipOnEntity;
  pke::Frame frame;    // the model's front / up axes
  int frameInit, frontFromTip;
  float tipLocal[3]; volatile LONG tipLocalN;   // the tip attachment in the model's own axes (feet)
  float wPos[3], wRot[9]; int64_t wQ;           // what was last written into the entity (to tell "ours" from "the game's")
  int gameValid; double gameP[3], gameU[3][3], gameL[3]; int64_t gameQ;   // the game's own placement of the meter (its animation), last seen
  // 1.7.63: hand -> PKE is the only live direction. Keep just the last aim
  // direction for HOLDCHECK diagnostics; the old PKE -> arm feedback state is gone.
  float lastDir[3];
  // the game's own scan (what the PKE's update did)
  volatile LONG scanOn, scanStarts, scanTargetsSeen, scanLogged, scanFrames;
  uintptr_t lastTarget;
  int64_t heldSinceQ, lastSeenQ, srcLogQ; volatile LONG shots;   // diagnostic pictures taken while the meter is in hand
  pke::ShiftState shift; volatile LONG shiftFresh, shiftHeld, shiftNone; LONG shiftMaxX100; double shiftSumCm; LONG shiftN;   // 0.98: the held hand slide
  pke::GripLock gripLock;
  handprop::GripLock exactGrip; volatile LONG exactUsed, exactFallback, onDrawnHand;   // exact GAME PKE -> GAME hand relation
  handprop::HandFollower handFollow;                                     // final rendered hand -> tracked controller; prop never follows controller directly
  uintptr_t exactActor;                                                  // holster/redraw keeps grip; a new player actor gets its own game-hand calibration
  // 1.7.64 grip self-check: the relation the game shows now (fresh game PKE pose against the fresh game hand) against the locked one
  float lastFresh[16]; int haveFresh, healRun; volatile LONG healChecks, rebinds, rebindsDraw; double lastDeltaCm, lastDeltaAx, maxDeltaCm, relLenCm;
  int64_t gripLogQ; volatile LONG gripLogs, pairMiss, pairOk; float lastPkeToHandCm, lastPkeToCtlCm, lastGamePkeToHandCm; int lastOurs;
  int64_t drawPair; uintptr_t drawSelf; float drawM[16];
  // 1.7.66: follow the game's own live hold (see handprop::Live)
  handprop::Live live; double lastScaleGame, lastScaleFinal; volatile LONG liveLogged;
  // 1.7.67: the drawn hand as it is (axis lengths), the clean copy used, the hand's speed (the grip is only adjusted while it is steady), and the eased grip
  double handRef; int handRefHave; long handClean, handSpike, handRigidFail, calmN, busyN;
  float rawRows[3]; double rawRatio; int rawStretch100;
  double hsPos[3], hsT, handSpeed; int hsKnown;
  float relUse[16]; int relUseHave; double relUseT;
  pke::RigidShift rigid;   // 1.6: the same, kept in the PKE's own axes
  uintptr_t parent; volatile LONG parentLogged;   // what the player has at +0x24E80 (the game draws the meter relative to it when it is not null)
} g_pk;

struct PkLock {
  int got;
  PkLock() { got = 0; for (int i = 0; i < 256; ++i) { if (InterlockedCompareExchange(&g_pkLock, 1, 0) == 0) { got = 1; return; } if (i > 32) YieldProcessor(); } }
  ~PkLock() { if (got) InterlockedExchange(&g_pkLock, 0); }
};

static int pke_finite(const float* f, int n) { for (int i = 0; i < n; ++i) if (!vm::is_finite_f(f[i])) return 0; return 1; }

// the front axis from the game's own tip attachment (in the model's axes), once it has been seen
static void pke_learn_front() {
  if (g_pk.tipLocalN <= 0 || g_pk.frontFromTip) return;
  int best = 0;
  for (int j = 1; j < 3; ++j) if (vm::dabs(g_pk.tipLocal[j]) > vm::dabs(g_pk.tipLocal[best])) best = j;
  double second = 0.0;
  for (int j = 0; j < 3; ++j) if (j != best && vm::dabs(g_pk.tipLocal[j]) > second) second = vm::dabs(g_pk.tipLocal[j]);
  if (!(vm::dabs(g_pk.tipLocal[best]) > 0.3 && vm::dabs(g_pk.tipLocal[best]) > 2.0 * second)) return;
  const int sgn = g_pk.tipLocal[best] < 0 ? -1 : 1;
  g_pk.frontFromTip = 1;
  if (best != g_pk.frame.front || sgn != g_pk.frame.fsign) { g_pk.frame.front = best; g_pk.frame.fsign = sgn; g_pk.frame.have = 0; g_pk.frame.up = -1; }
  log_line("PKEGAME front axis of the game's PKE read from its tip attachment: local axis %d%s (tip %.2f,%.2f,%.2f ft in the model's own axes)", best, sgn < 0 ? " reversed" : "", (double)g_pk.tipLocal[0], (double)g_pk.tipLocal[1], (double)g_pk.tipLocal[2]);
}

// 1.7.70: the 1.7.69 video showed the PKE drawn 40-60 cm in front of / above the fist, exactly where the game's own scan animation holds it, while the log said the
// written pose was 13 cm from the hand. The fields the probe wrote (+0x54/+0xF4 and +0x4B8/+0x4C4) are not what the model is drawn with; the game's own setter
// (0x141E60, this + 4x4: the same call the player's update uses every frame) is. The pose is now handed to the game through that setter.
typedef void (__fastcall* PFN_PkeSetMatrix)(void* self, const float* m4x4);
static PFN_PkeSetMatrix g_pkeSet; static int g_pkeSetState;   // 0 = not checked, 1 = ok, -1 = bytes differ
static volatile LONG g_pkeSetCalls, g_pkeSetSkips;
// ---- 1.7.74 the PKE's real hold: R_PKE ------------------------------------------------------------------------------------------------------------------------------
// ghost.exe: the player's update writes TWO poses of the meter every frame. The ENTITY (what the 1.7.62-1.7.73 grip read as "the game's PKE") is the player's position plus a
// fixed offset turned by the aim (0x2C3AB0): it is not in the hand at all, so its distance to the game's hand swings with the aim and the animation (the 1.7.73 log: 8.5-17.3 cm;
// that is the "pulled" PKE). The other one, set through 0x141E60 from 0xD6542, is the animation's R_PKE attachment times the player: the meter as the hand holds it.
// The grip is now taken from R_PKE against the game's hand. It is only taken while that pose really is in the hand (within 25 cm) and steady for 6 samples, then kept
// for the session (it is the animation's own prop-in-hand offset, so it does not change); walking, aiming, the draw animation and the belt cannot pull it.
typedef void (__fastcall* PFN_PkeSetM)(void* self, const float* m4x4);
static PFN_PkeSetM o_pkeSetM;
static struct { volatile LONG seq; float m[16]; int64_t q; uintptr_t self; volatile LONG caps, hooked; } g_rpke;
static struct { float rel[16], prev[16]; int havePrev, stable, locked; LONG lastCaps; int64_t lockQ; uintptr_t actor; long samples, outOfHand, unsteady, locks, used, waits; double relLenCm; int64_t logQ, lastSampleQ; volatile LONG logs;
               float keep[16]; int keepHave; uintptr_t keepActor; LONG keepGen; long reused; int64_t outQ; int reuseLock, tiedLogged; int tier; double devCm, devDeg; } g_pkh;   // 1.7.182: keep = the last locked hold, used at once on the next pull-out
static void __fastcall hk_pke_setm(void* self, const float* m) {
  const uintptr_t ret = (uintptr_t)GBVR_RETURN_ADDRESS();
  o_pkeSetM(self, m);
  if (ret == rva(0xD6547) && m) {   // the player's update (0xD6542 call): the animation's hold, not ours
    InterlockedIncrement(&g_rpke.seq);
    for (int i = 0; i < 16; ++i) g_rpke.m[i] = m[i];
    g_rpke.m[3] = g_rpke.m[7] = g_rpke.m[11] = 0.0f; g_rpke.m[15] = 1.0f;
    g_rpke.q = qpc_now(); g_rpke.self = (uintptr_t)self;
    InterlockedIncrement(&g_rpke.seq);
    InterlockedIncrement(&g_rpke.caps);
  }
}
static int pke_rpke_read(uintptr_t self, float* out) {
  for (int tries = 0; tries < 4; ++tries) {
    const LONG s0 = g_rpke.seq; if (s0 & 1) continue;
    const int64_t q = g_rpke.q; const uintptr_t sf = g_rpke.self;
    for (int i = 0; i < 16; ++i) out[i] = g_rpke.m[i];
    if (g_rpke.seq != s0) continue;
    return q && sf == self && (double)(qpc_now() - q) / (double)qpc_freq() < 0.12 && handprop::finite16(out);
  }
  return 0;
}
static void install_pke_setm_hook() {
  if (!bytes_match(layout::kRvaPkeSetMatrix, layout::kBytesPkeSetMatrix, 16)) { g_rpke.hooked = -1; log_line("PKEHOLD not available: the PKE setter's bytes differ"); return; }
  void* t = (void*)rva(layout::kRvaPkeSetMatrix);
  MH_STATUS st = MH_CreateHook(t, (void*)hk_pke_setm, (void**)&o_pkeSetM);
  if (st == MH_OK) st = MH_EnableHook(t);
  g_rpke.hooked = st == MH_OK ? 1 : -2;
  log_line("HOOK PKE hold %x status=%d (1.7.74: the PKE grip comes from the animation's R_PKE hold, not from the pose fixed in front of the view)", layout::kRvaPkeSetMatrix, (int)st);
}
// one step: 1 = rel holds the grip to use (locked, or a good fresh one before the lock)
static int pke_hold_step(uintptr_t self, uintptr_t actor, const float* gameHand, float* relOut) {
  const int64_t nowQ = qpc_now();
  // A new draw or level transition must not inherit the previous R_PKE grip.
  if (g_pkh.actor != actor || (g_pkh.lastSampleQ && nowQ - g_pkh.lastSampleQ > qpc_freq() * 2)) {   // 1.7.181: 2 s (was 0.5 s): a short pause or hitch no longer throws the lock and the hand turn away
    g_pkh.havePrev = g_pkh.stable = g_pkh.locked = 0;
    g_pkh.actor = actor;
    g_pkh.lastSampleQ = 0; g_pkh.outQ = nowQ; g_pkh.reuseLock = 0; g_pkh.tiedLogged = 0; g_pkh.devCm = 0.0; g_pkh.devDeg = 0.0; g_pkh.tier = 0;
    // 1.7.182 THE PKE PULLED IN MANY DIRECTIONS: every pull-out started the grip from nothing and waited for 12 steady game updates (the log: 6 s, 403 unsteady samples, the hand
    // not tied to the controller on half of all passes, the game's hand turn up to 95 deg off). The game's hold is the same every time (8.6 cm both times in the log), so the last
    // locked hold of this player and model is used at once; it is only dropped with a new model, a new player or a hand switch.
    if (g_pkh.keepHave && g_pkh.keepActor == actor && g_pkh.keepGen == g_modelGen && pke_finite(g_pkh.keep, 16)) {
      for (int i = 0; i < 16; ++i) g_pkh.rel[i] = g_pkh.keep[i];
      g_pkh.locked = 1; g_pkh.lockQ = nowQ; ++g_pkh.reused; g_pkh.reuseLock = 1;
      static LONG s_reuseLog; if (InterlockedIncrement(&s_reuseLog) <= 12) log_line("PKEHOLD t=%.2fs the PKE comes out again: the grip of the last pull-out is used at once (no waiting, no re-learning; reused %ld times)", qpc_ms() / 1000.0, g_pkh.reused);
    } else g_pkh.keepHave = 0;
    arms_frz_reset();   // 1.7.175: the hand turn K was captured once per session; a new draw captures it again
    handprop::reset(&g_pk.exactGrip);
    handprop::reset(&g_pk.handFollow);
    g_pk.exactActor = 0;
  }
  float R[16], fr[16];
  int fresh = 0, animShow = 0;
  if (pke_rpke_read(self, R) && handprop::relative(R, gameHand, fr)) {
    g_pkh.lastSampleQ = nowQ;
    ++g_pkh.samples;
    const double len = vm::dsqrt((double)fr[12] * fr[12] + (double)fr[13] * fr[13] + (double)fr[14] * fr[14]);
    g_pkh.relLenCm = len * 30.48;
    if (g_ctl.drawAnim) {   // 1.7.98 THE GAME'S OWN DRAW ANIMATION of the meter: while it is still coming out of the belt the meter is placed through the relation the game shows now (view only)
      static double s_lastSampleS;
      const double nowS = qpc_ms() / 1000.0;
      if (s_lastSampleS == 0.0 || nowS - s_lastSampleS > 0.5) {   // the meter was away for half a second: a new pull-out
        drawanim::begin(&g_pkeWin, 5, nowS);
        if (g_daLogs < 80) { ++g_daLogs; log_line("DRAWANIM t=%.2fs: the PKE comes out: the game's own draw animation of the meter is shown on your hand for up to %.1f s (view only: the scan, the trigger and the resting hold are not changed)", nowS, drawanim::kWindowS); }
      }
      s_lastSampleS = nowS;
      const int haveHold = g_pkh.locked;
      const double distFt = haveHold ? handprop::rel_pos_delta(fr, g_pkh.rel) : 0.0;
      if (drawanim::step(&g_pkeWin, 5, nowS, len, haveHold, distFt, 0.82)) { animShow = 1; da_log_shown("PKE meter", 5, g_pkeWin, nowS, len, haveHold, distFt); }
      da_log_end("PKE meter", 5, g_pkeWin);
    }
    if (len > 0.6) { ++g_pkh.outOfHand; g_pkh.stable = 0; g_pkh.havePrev = 0; }   // 1.7.175: gate 0.6 ft (was 0.82): still coming out of the belt / going back: not a hold
    else {
      fresh = 1;
      if (!g_pkh.locked) {
        // 1.7.175: steadiness is measured from an ANCHOR (the first sample), not sample to sample: the meter sliding into the hand passed the old test and was locked
        // mid-draw, so every draw got a different grip. Now 20 samples (~0.25 s) must stay within 1.5 mm and 1 degree of the anchor.
        // 1.7.181: a sample counts only when the game really sent a NEW R_PKE (this runs 4-6 times a frame; 20 calls were only 3-5 game updates, so the grip could lock in the tail of the draw animation)
        const LONG capsNow = g_rpke.caps;
        const int newSample = capsNow != g_pkh.lastCaps;
        g_pkh.lastCaps = capsNow;
        if (newSample || !g_pkh.havePrev) {
          // 1.7.225 "the PKE gets pulled around when it first comes out": the grip waited for 12 new game updates within 1.5 mm / 1 degree of each other, and in the 1.7.224 report that
          // took 6.8 s (the game's hold keeps moving while the hand moves), the whole time the meter followed the game's own hand. The draw animation is over after about 0.7 s, so
          // the steadiness limit now loosens with time: 1.5 mm / 1 deg to 0.7 s, then 5 mm / 3 deg, from 1.5 s 12 mm / 6 deg, from 3 s 25 mm / 10 deg.
          const double eS = g_pkh.outQ ? (double)(nowQ - g_pkh.outQ) / (double)qpc_freq() : 0.0;
          double tolP = 0.005, tolA = 0.000152; int tier = 0;
          if (eS > 3.0) { tolP = 0.082; tolA = 0.0152; tier = 3; } else if (eS > 1.5) { tolP = 0.039; tolA = 0.0055; tier = 2; } else if (eS > 0.7) { tolP = 0.016; tolA = 0.0014; tier = 1; }
          if (g_pkh.havePrev) { const double dpc = 30.48 * handprop::rel_pos_delta(fr, g_pkh.prev); const double dac = handprop::rel_axis_delta(fr, g_pkh.prev); if (dpc > g_pkh.devCm && dpc < 20.0) g_pkh.devCm = dpc; if (dac > 0.0) { const double dd = 57.29577951308232 * vm::dsqrt(2.0 * dac); if (dd > g_pkh.devDeg && dd < 60.0) g_pkh.devDeg = dd; } }
          g_pkh.tier = tier;
          if (g_pkh.havePrev && handprop::rel_pos_delta(fr, g_pkh.prev) <= tolP && handprop::rel_axis_delta(fr, g_pkh.prev) <= tolA) ++g_pkh.stable;
          else { if (g_pkh.havePrev) ++g_pkh.unsteady; g_pkh.stable = 0; for (int i = 0; i < 16; ++i) g_pkh.prev[i] = fr[i]; }
          g_pkh.havePrev = 1;
        }
        if (g_pkh.stable >= 12 && len > 0.2 && !g_pkeWin.open) {
          for (int i = 0; i < 16; ++i) g_pkh.rel[i] = fr[i];
          g_pkh.locked = 1; g_pkh.lockQ = qpc_now(); ++g_pkh.locks;
          for (int i = 0; i < 16; ++i) g_pkh.keep[i] = fr[i];
          g_pkh.keepHave = 1; g_pkh.keepActor = actor; g_pkh.keepGen = g_modelGen;
          log_line("PKEHOLD t=%.2fs grip taken from the game's R_PKE hold: %.1f cm from the hand (steady for 12 new game updates, limit tier %d of 3 [0 = 1.5 mm / 1 deg, 1 = 5 mm / 3 deg, 2 = 12 mm / 6 deg, 3 = 25 mm / 10 deg], %.2f s after the pull-out; the hold moved up to %.1f cm / %.1f deg between updates while waiting); kept from now on", qpc_ms() / 1000.0, g_pkh.relLenCm, g_pkh.tier, g_pkh.outQ ? (double)(qpc_now() - g_pkh.outQ) / (double)qpc_freq() : 0.0, g_pkh.devCm, g_pkh.devDeg);
        }
      }
    }
  }
  if (animShow) { for (int i = 0; i < 16; ++i) relOut[i] = fr[i]; ++g_pkh.used; return 1; }   // 1.7.98: the game's own animation of the meter (the lock below is not changed)
  if (g_pkh.locked) { for (int i = 0; i < 16; ++i) relOut[i] = g_pkh.rel[i]; ++g_pkh.used; return 1; }
  if (fresh) { for (int i = 0; i < 16; ++i) relOut[i] = fr[i]; ++g_pkh.used; return 1; }   // before the lock: the game's hold of this moment (only when it is in the hand)
  ++g_pkh.waits;
  return 0;
}
static void pke_hold_report() {
  const int64_t q = qpc_now();
  if (g_pkh.logQ && (double)(q - g_pkh.logQ) / (double)qpc_freq() < 10.0) return;
  if (InterlockedIncrement(&g_pkh.logs) > 80) return;
  g_pkh.logQ = q;
  log_line("PKEHOLD t=%.1fs on=%d hook=%d | R_PKE poses seen %ld, hold samples %ld (not in the hand %ld, unsteady %ld), locked=%d (%ld times), last relation %.1f cm, used %ld, waited %ld",
           qpc_ms() / 1000.0, (int)g_ctl.pkeHoldRpke, (int)g_rpke.hooked, (long)g_rpke.caps, g_pkh.samples, g_pkh.outOfHand, g_pkh.unsteady, g_pkh.locked, g_pkh.locks, g_pkh.relLenCm, g_pkh.used, g_pkh.waits);
  {   // 1.7.76: is the hand tied to the controller, and how far the animation's own hand turn would have been from it
    long cap = 0, app = 0; int last = 0, mx = 0, mean = 0;
    arms_frz_stats(&cap, &app, &last, &mx, &mean);
    log_line("PKECTL t=%.1fs pke_ctl_rigid=%d pke_fingers_anim=%d | hand tied to the controller on %ld passes (relation captured %ld times), not tied (waiting for the steady hold) %ld | the animation's own hand turn would have been off your controller by %.1f deg on average, %.1f now, %.1f at most | the game's own fingers kept on %ld passes | PKE pose setter %s, %ld calls | the hand of the last solve moved on with the controller %ld times (mean %.1f cm, last %.1f, most %.1f; same sample %ld, solve too old %ld, no frame %ld)",
             qpc_ms() / 1000.0, (int)g_ctl.pkeCtlRigid, (int)g_ctl.pkeFingersAnim, app, cap, (long)g_pctl.freePasses, mean / 10.0, last / 10.0, mx / 10.0, (long)g_pctl.animFingers, g_pkeSetState == 1 ? "through the game" : "not available", (long)g_pkeSetCalls,
             (long)g_pAdv.advanced, g_pAdv.advanced ? g_pAdv.sumCm / (double)g_pAdv.advanced : 0.0, g_pAdv.lastCm, g_pAdv.maxCm, (long)g_pAdv.sameSample, (long)g_pAdv.tooOld, (long)g_pAdv.noFrame);
  }
}
static int pke_hold_locked() { return g_pkh.locked; }
// 1.7.176: the hand turn K is saved from the hand as it is NOW; at the first lock the arm is still settling (log: turned 76 deg, 13 cm off to the side = the tangled start), so it waits 0.5 s after the lock
// 1.7.203 "the PKE is dragged in one direction when first pulled out, then goes away": the hand was tied to the controller only 0.5 s AFTER the hold was locked (about 0.9 s after the pull-out in the 1.7.198 log:
// PKEHOLD locked 0.43 s after the pull-out, PROPDRIFT 0.6 s later), and the game's draw animation moved the hand meanwhile. A hold reused from the last pull-out is tied after 0.05 s, a freshly learned one after 0.25 s.
static int pke_hold_locked_settled() {
  if (!(g_pkh.locked && g_pkh.lockQ)) return 0;
  const double need = g_pkh.reuseLock ? 0.05 : 0.25;
  const int ok = (double)(qpc_now() - g_pkh.lockQ) / (double)qpc_freq() > need;
  if (ok && !g_pkh.tiedLogged && g_pkh.outQ) { g_pkh.tiedLogged = 1; static LONG s_tl; if (InterlockedIncrement(&s_tl) <= 12) log_line("PKEDRAG t=%.2fs the hand is tied to the controller %.2f s after the PKE came out (hold %s, locked %.2f s after the pull-out)", qpc_ms() / 1000.0, (double)(qpc_now() - g_pkh.outQ) / (double)qpc_freq(), g_pkh.reuseLock ? "reused from the last pull-out" : "learned this time", (double)(g_pkh.lockQ - g_pkh.outQ) / (double)qpc_freq()); }
  return ok;
}
// 1.7.104: the PKE's long (front) axis and centre in the hand's own axes, from the locked R_PKE hold (rel = PKE x inverse(hand), row vectors: rows = the PKE's axes in the hand's axes)
static int pke_align_vectors(double* vh, double* ph) {
  if (!g_pkh.locked || !pke_finite(g_pkh.rel, 16)) return 0;
  const int fa = g_pk.frame.front >= 0 && g_pk.frame.front <= 2 ? g_pk.frame.front : 1;
  const double sg = g_pk.frame.fsign < 0 ? -1.0 : 1.0;
  double v[3] = {g_pkh.rel[fa * 4] * sg, g_pkh.rel[fa * 4 + 1] * sg, g_pkh.rel[fa * 4 + 2] * sg};
  const double n = vm::dsqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
  if (!(n > 0.2)) return 0;
  for (int i = 0; i < 3; ++i) vh[i] = v[i] / n;
  const double sc = g_pk.handRefHave && g_pk.handRef > 0.5 && g_pk.handRef < 2.0 ? g_pk.handRef : 1.0;
  for (int i = 0; i < 3; ++i) ph[i] = (double)g_pkh.rel[12 + i] * sc;
  return 1;
}
static void pke_game_set(uint8_t* self, const float* M) {
  if (!g_ctl.pkeSetMatrix) { InterlockedIncrement(&g_pkeSetSkips); return; }
  if (!g_pkeSetState) {
    if (g_rpke.hooked == 1 && o_pkeSetM) { g_pkeSet = (PFN_PkeSetMatrix)o_pkeSetM; g_pkeSetState = 1; }   // 1.7.76: 1.7.74 hooked the setter, so its first bytes are no longer the original ones: call the original through the hook's trampoline
    else if (bytes_match(layout::kRvaPkeSetMatrix, layout::kBytesPkeSetMatrix, 16)) { g_pkeSet = (PFN_PkeSetMatrix)rva(layout::kRvaPkeSetMatrix); g_pkeSetState = 1; }
    else g_pkeSetState = -1;
    log_line("PKESET the game's PKE pose setter %s: the PKE in your hand is %s", g_pkeSetState == 1 ? "found" : "NOT found (bytes differ)", g_pkeSetState == 1 ? "handed to the game through it (the drawn model takes the pose)" : "only written into its fields");
  }
  if (g_pkeSetState != 1) return;
  float m[16];
  for (int i = 0; i < 16; ++i) m[i] = M[i];
  m[3] = m[7] = m[11] = 0.0f; m[15] = 1.0f;
  for (int i = 0; i < 16; ++i) if (!vm::is_finite_f(m[i])) return;
  g_pkeSet(self, m);
  InterlockedIncrement(&g_pkeSetCalls);
}

// 1.7.170 "watch how bad the floating gets": when the exact hand pair is not ready (goggles, a fresh draw) the PKE was left at the game's own spot,
// up to 1.7 m away from the hand. Now the last in-hand pose is kept RELATIVE TO THE CONTROLLER (position and turn), so it stays in the hand.
static struct { pkerel::Rel rel; int ok; int64_t q; LONG holds, logs, stored, refused; } g_pkRel;   // 1.7.172: the math is in pkerelmath.h (tested); a bad pose no longer wipes the last good hold
static void pke_rel_store(const float* M, const float* gripf, const float* dirf, const float* wupf) {
  if (pkerel::store(g_pkRel.rel, M, gripf, dirf, wupf)) { g_pkRel.ok = 1; g_pkRel.q = qpc_now(); InterlockedIncrement(&g_pkRel.stored); }
  else InterlockedIncrement(&g_pkRel.refused);
}
static int pke_rel_pose(const float* gripf, const float* dirf, const float* wupf, float* M) { return g_pkRel.ok && pkerel::pose(g_pkRel.rel, gripf, dirf, wupf, M); }
static void pke_write_pose(uint8_t* self, const float* M);
static GBVR_NOINLINE int pke_place_locked(uint8_t* self, int site, uintptr_t actor, const float* dirf, const float* gripf, const float* wupf) {
  if (!memory_readable(self, layout::kSizePkeMeter)) { InterlockedIncrement(&g_pk.bad); return 0; }
  if (g_pk.self && g_pk.self != (uintptr_t)self) {
    g_pk.gameValid = 0; g_pk.wQ = 0; g_pk.frameInit = 0; g_pk.frontFromTip = 0;
    g_pk.tipLocalN = 0; g_pk.drawPair = 0;
    // A new PKE entity is normal after holster/draw.  Preserve the learned
    // GAME hand<->PKE grip and hand follower; only entity-local caches reset.
    pke::rigid_reset(&g_pk.rigid); pke::shift_reset(&g_pk.shift);
  }
  if (!g_pk.frameInit) { g_pk.frame.front = 1; g_pk.frame.fsign = 1; g_pk.frame.up = -1; g_pk.frame.usign = 1; g_pk.frame.have = 0; g_pk.frame.prevOk = 0; g_pk.frameInit = 1; }
  pke_learn_front();
  float* posF = (float*)(self + layout::kOffPkePos);
  float* rotF = (float*)(self + layout::kOffPkeRot);
  float* entP = (float*)(self + layout::kActorPos);
  float* entR = (float*)(self + layout::kOffEntityRot);
  const int entOk = g_ctl.pkeEntity && memory_readable(entP, 12) && memory_readable(entR, 36) && pke_finite(entP, 3) && pke_finite(entR, 9);
  if (!entOk && g_ctl.pkeEntity) InterlockedIncrement(&g_pk.entNoRead);
  // 1. the game's own placement: the entity matrix (what the screen shows), or the second pose when the entity cannot be used. If what is there is what this code wrote last (the game did not
  //    place it again yet), the game's placement seen before is used.
  const float* mP = entOk ? entP : posF;
  const float* mR = entOk ? entR : rotF;
  int ours = g_pk.wQ != 0;
  for (int i = 0; ours && i < 3; ++i) if (mP[i] != g_pk.wPos[i]) ours = 0;
  for (int i = 0; ours && i < 9; ++i) if (mR[i] != g_pk.wRot[i]) ours = 0;
  if (!ours) {
    double L[3], u[3][3];
    for (int j = 0; j < 3; ++j) {
      const double v[3] = {mR[j], mR[3 + j], mR[6 + j]};
      L[j] = pke::len(v);
      if (!vm::is_finite_f((float)L[j]) || !(L[j] > 1e-4)) { InterlockedIncrement(&g_pk.bad); return 0; }
      for (int i = 0; i < 3; ++i) u[j][i] = v[i] / L[j];
    }
    for (int i = 0; i < 3; ++i) if (!vm::is_finite_f(mP[i])) { InterlockedIncrement(&g_pk.bad); return 0; }
    for (int i = 0; i < 3; ++i) { g_pk.gameP[i] = mP[i]; g_pk.gameL[i] = L[i]; for (int k = 0; k < 3; ++k) g_pk.gameU[i][k] = u[i][k]; }
    g_pk.gameValid = 1; g_pk.gameQ = qpc_now();
    InterlockedIncrement(&g_pk.entGameSeen);
  } else InterlockedIncrement(&g_pk.entOursSeen);
  if (!g_pk.gameValid) { InterlockedIncrement(&g_pk.bad); return 0; }
  double u[3][3], u0[3][3];
  for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) { u[j][i] = g_pk.gameU[j][i]; u0[j][i] = g_pk.gameU[j][i]; }
  double L[3] = {g_pk.gameL[0], g_pk.gameL[1], g_pk.gameL[2]};
  const double P0[3] = {g_pk.gameP[0], g_pk.gameP[1], g_pk.gameP[2]};
  double dir[3] = {dirf[0], dirf[1], dirf[2]};
  if (!pke::unit(dir)) { InterlockedIncrement(&g_pk.bad); return 0; }
  // 1.7.62: the GAME HAND is authoritative for the PKE too.  Capture the
  // game's complete PKE->hand relationship, then apply it to the VR-rendered
  // hand.  During a rig/view-model gap reconstruct the HAND from the tracked
  // controller first; never attach the PKE directly to a controller frame and
  // never hold a stale world-space PKE matrix.
  int exactPke = 0;
  float exactPkeM[16] = {}, exactFinalHand[16] = {};
  int pkePairOk = 0; float pkeDrawnHand[16];   // 1.7.147: the drawn hand of this placement, for the lock-to-hand path below
  {
    float gameM[16] = {}, gameHand[16], finalHand[16];
    for (int j=0;j<3;++j) for (int i=0;i<3;++i) gameM[j*4+i]=(float)(u0[j][i]*L[j]);
    for (int i=0;i<3;++i) gameM[12+i]=(float)P0[i]; gameM[15]=1.0f;
    {   // 1.7.100 a new model / skeleton: the PKE hold of the old model is dropped
      static LONG s_pkeGen;
      if (s_pkeGen != g_modelGen) { s_pkeGen = g_modelGen; handprop::reset(&g_pk.exactGrip); handprop::reset(&g_pk.handFollow); handprop::reset(&g_pk.live); g_pk.exactActor = 0; g_pk.haveFresh = 0; g_pk.healRun = 0; g_pkRel.ok = 0; handprop::reset(&g_pkeDrift); arms_frz_reset(); }   // 1.7.181: the PKE drift tracker too. 1.7.175: the controller-relative PKE hold and the hand turn of the old hand are dropped too
    }
    if (g_pk.exactActor && g_pk.exactActor != actor) {
      handprop::reset(&g_pk.exactGrip);
      handprop::reset(&g_pk.handFollow);
      g_pk.exactActor = 0;
    }
    const int pairOk = g_ctl.armIk && arms_game_hand_pair(actor, gameHand, finalHand);
    if (pairOk) InterlockedIncrement(&g_pk.pairOk); else InterlockedIncrement(&g_pk.pairMiss);
    g_pk.lastOurs = ours;
    if (pairOk) {   // 1.7.67: what the drawn hand looks like now, then a clean copy of it for the PKE
      for (int r = 0; r < 3; ++r) g_pk.rawRows[r] = (float)handprop::row_len(finalHand, r);
      g_pk.rawRatio = handprop::row_ratio(finalHand);
      g_pk.lastScaleGame = handprop::mean_scale(gameHand); g_pk.lastScaleFinal = handprop::mean_scale(finalHand);
      g_pk.rawStretch100 = arms_right_stretch_x100();
      if (g_ctl.pkeRigidHand) {
        const double ms = g_pk.lastScaleFinal;
        const int clean = g_pk.rawRatio > 0.0 && g_pk.rawRatio < 1.06 && ms >= 0.9 && ms <= 1.12;
        if (clean) { g_pk.handRef = ms; g_pk.handRefHave = 1; ++g_pk.handClean; } else ++g_pk.handSpike;   // a stretched moment keeps the size of the last clean one
        float rig[16];
        if (handprop::rigid_frame(finalHand, g_pk.handRefHave ? g_pk.handRef : 1.0, rig)) { for (int i = 0; i < 16; ++i) finalHand[i] = rig[i]; }
        else ++g_pk.handRigidFail;
      }
    }
    if (pairOk && g_ctl.pkeCtlRigid) hand_advance(finalHand, gripf, dirf, wupf, g_pkAimQ, g_pAdv);   // 1.7.76/1.7.77: the hand of the last solve moved on with the controller
    if (pairOk) { pkePairOk = 1; for (int i = 0; i < 16; ++i) pkeDrawnHand[i] = finalHand[i]; }
    if (pairOk) { const double dx = (double)gameM[12]-gameHand[12], dy = (double)gameM[13]-gameHand[13], dz = (double)gameM[14]-gameHand[14]; g_pk.lastGamePkeToHandCm = (float)(vm::dsqrt(dx*dx+dy*dy+dz*dz) * 30.48); }
    float holdRel[16];
    if (pairOk && g_ctl.pkeHoldRpke && pke_hold_step((uintptr_t)self, actor, gameHand, holdRel) && handprop::place(holdRel, finalHand, exactPkeM)) {   // 1.7.74
      for (int i = 0; i < 16; ++i) g_pk.exactGrip.rel[i] = holdRel[i];   // the model-gap path below reads these
      g_pk.exactGrip.havePrev = 1; g_pk.exactGrip.locked = 1; ++g_pk.exactGrip.captures;
      g_pk.exactActor = actor;
      g_pk.relLenCm = g_pkh.relLenCm;
      float tracked[16];
      if (handprop::tracked_frame(gripf, dirf, wupf, tracked)) { handprop::capture_hand(&g_pk.handFollow, finalHand, tracked); if (handprop::drift_step(&g_pk.handFollow, &g_pkeDrift, finalHand, tracked)) prop_drift_log("PKE", 9, g_pkeDrift); }
      for (int i = 0; i < 16; ++i) exactFinalHand[i] = finalHand[i];
      exactPke = 1; InterlockedIncrement(&g_pk.exactUsed);
      pke_hold_report();
    } else if (pairOk && g_ctl.pkeHoldRpke) {
      // no hold yet (R_PKE not in the hand yet): the model-gap path below keeps the last grip on the tracked hand
    } else if (pairOk && g_ctl.pkeLiveGrip) {
      // 1.7.66: the relation the game shows NOW is followed (no early freeze).  The 1.7.65 log showed the freeze taken while the meter was still coming out of the belt
      // (15 cm from the hand while the game's own hold was 8 cm), then kept for seconds.  A big jump is only believed after 8 steady samples (view-model glitches are ignored).
      // 1.7.67: the relation is only adjusted while the hand is steady (the 1.7.66 log: while the hand moved fast the game's meter and hand were sampled a moment apart and the
      // "relation" swung between 6.5 and 17.7 cm), and the meter eases to a new relation instead of jumping.
      const int64_t nowL = qpc_now();
      const double nowS = (double)nowL / (double)qpc_freq();
      if (!g_pk.lastSeenQ || (double)(nowL - g_pk.lastSeenQ) / (double)qpc_freq() > 0.5) {   // a new pull-out (1.7.69: away 0.5 s, like the gun): nothing is carried over from an earlier draw
        if (g_pk.live.have || g_pk.exactGrip.havePrev) InterlockedIncrement(&g_pk.rebindsDraw);
        handprop::reset(&g_pk.live); handprop::reset(&g_pk.exactGrip); handprop::reset(&g_pk.handFollow);
        g_pk.relUseHave = 0; g_pk.hsT = 0.0; g_pk.hsKnown = 0; g_pk.handSpeed = 0.0;
        log_line("PKEGRIP new pull-out t=%.2fs: the hand grip starts from what the game shows now", qpc_ms() / 1000.0);
      }
      {   // how fast the game's hand moves: from the game hand matrix of one arm pass to the next
        const double dx = (double)gameHand[12] - g_pk.hsPos[0], dy = (double)gameHand[13] - g_pk.hsPos[1], dz = (double)gameHand[14] - g_pk.hsPos[2];
        const double moved = vm::dsqrt(dx * dx + dy * dy + dz * dz);
        if (!g_pk.hsT) { for (int i = 0; i < 3; ++i) g_pk.hsPos[i] = gameHand[12 + i]; g_pk.hsT = nowS; }
        else if (moved > 1e-5) {
          const double dt = nowS - g_pk.hsT;
          if (dt > 0.003) {
            if (dt < 0.3) { const double v = moved / dt; g_pk.handSpeed = g_pk.hsKnown ? 0.6 * g_pk.handSpeed + 0.4 * v : v; g_pk.hsKnown = 1; }
            else g_pk.hsKnown = 0;
            for (int i = 0; i < 3; ++i) g_pk.hsPos[i] = gameHand[12 + i]; g_pk.hsT = nowS;
          }
        } else if (nowS - g_pk.hsT > 0.05) { g_pk.handSpeed = 0.0; g_pk.hsKnown = 1; }   // the same hand matrix for 50 ms with a fresh pair: the hand is still
      }
      const int calm = !g_ctl.pkeSteadyOnly || (g_pk.hsKnown && g_pk.handSpeed < 0.8);   // 1.7.69: the gun's rule (every fresh sample) unless pke_steady_only 1 (then only under about 24 cm/s)
      float fr[16];
      if (!ours && handprop::relative(gameM, gameHand, fr)) {
        InterlockedIncrement(&g_pk.healChecks);
        g_pk.relLenCm = (double)vm::dsqrt((double)fr[12]*fr[12] + (double)fr[13]*fr[13] + (double)fr[14]*fr[14]) * 30.48;
        if (g_pk.relLenCm > 30.0 && g_pk.live.have) ++g_pk.busyN;   // 1.7.70: not a hold (the meter is still on its way to the hand / away from it)
        else if (!g_pk.live.have || calm) {
          ++g_pk.calmN;
          float prevRel[16]; for (int i = 0; i < 16; ++i) prevRel[i] = g_pk.live.rel[i];
          const int had = g_pk.live.have;
          const long jumpsBefore = g_pk.live.jumps;
          handprop::live_update(&g_pk.live, fr, 0.25, 0.04, 8);
          if (had) {
            g_pk.lastDeltaCm = handprop::rel_pos_delta(g_pk.live.rel, prevRel) * 30.48; g_pk.lastDeltaAx = handprop::rel_axis_delta(g_pk.live.rel, prevRel);
            if (g_pk.lastDeltaCm > g_pk.maxDeltaCm) g_pk.maxDeltaCm = g_pk.lastDeltaCm;
          }
          if (g_pk.live.jumps != jumpsBefore && InterlockedIncrement(&g_pk.rebinds) <= 24)
            log_line("PKEGRIP jump t=%.2fs: the game's hand-to-meter relation changed by %.1f cm and stayed there for 8 samples (relation length now %.1f cm): followed", qpc_ms() / 1000.0, g_pk.live.lastJumpFt * 30.48, g_pk.relLenCm);
        } else ++g_pk.busyN;
      }
      if (g_pk.live.have) {   // ease to the relation in use (about 27 cm/s at most), so a new relation slides in instead of popping
        if (!g_pk.relUseHave || !g_ctl.pkeSteadyOnly) { for (int i = 0; i < 16; ++i) g_pk.relUse[i] = g_pk.live.rel[i]; g_pk.relUseHave = 1; g_pk.relUseT = nowS; }   // 1.7.69: no easing with the gun's rule
        else {
          double dt = nowS - g_pk.relUseT; if (dt < 0.0) dt = 0.0; if (dt > 0.1) dt = 0.1;
          g_pk.relUseT = nowS;
          const float limT = (float)(0.9 * dt), limR = (float)(1.2 * dt);
          for (int i = 0; i < 16; ++i) {
            const float lim = (i >= 12 && i <= 14) ? limT : limR;
            float d = g_pk.live.rel[i] - g_pk.relUse[i];
            if (d > lim) d = lim; else if (d < -lim) d = -lim;
            g_pk.relUse[i] += d;
          }
        }
      }
      if (g_pk.live.have && g_pk.relUseHave && handprop::place(g_pk.relUse, finalHand, exactPkeM)) {
        for (int i = 0; i < 16; ++i) g_pk.exactGrip.rel[i] = g_pk.relUse[i];   // the model-gap path below reads these
        g_pk.exactGrip.havePrev = 1; g_pk.exactGrip.locked = 1; ++g_pk.exactGrip.captures;
        g_pk.exactActor = actor;
        float tracked[16];
        if (handprop::tracked_frame(gripf, dirf, wupf, tracked))
          { handprop::capture_hand(&g_pk.handFollow, finalHand, tracked); if (handprop::drift_step(&g_pk.handFollow, &g_pkeDrift, finalHand, tracked)) prop_drift_log("PKE", 9, g_pkeDrift); }
        for (int i=0;i<16;++i) exactFinalHand[i]=finalHand[i];
        exactPke=1; InterlockedIncrement(&g_pk.exactUsed);
        static LONG s_exactPkeLog;
        if (InterlockedIncrement(&s_exactPkeLog) == 1)
          log_line("HANDGRIP PKE follows the game's own hand-to-meter relation every frame, the same rule as the gun, through a clean hand (pke_rigid_hand %d, pke_steady_only %d)", (int)g_ctl.pkeRigidHand, (int)g_ctl.pkeSteadyOnly);
      }
    } else {   // pke_live_grip 0: the 1.7.65 frozen grip
    // 1.7.64: a new pull-out (the meter was away for 2 s) starts from a clean grip, so a relation captured in an earlier draw / stowed pose cannot stay
    if (pairOk && g_ctl.pkeGripHeal && g_pk.exactGrip.havePrev &&
        (!g_pk.lastSeenQ || (double)(qpc_now() - g_pk.lastSeenQ) / (double)qpc_freq() > 2.0)) {
      handprop::reset(&g_pk.exactGrip); handprop::reset(&g_pk.handFollow); g_pk.haveFresh = 0; g_pk.healRun = 0;
      InterlockedIncrement(&g_pk.rebindsDraw);
    }
    // 1.7.64: while the game's own PKE pose is fresh (not the one we wrote) and the hand pair is fresh, the relation the game shows is compared with the locked one.
    // A steady, clearly different relation (more than 9 cm or 10 degrees for 20 fresh samples) means the lock was taken in a wrong pose: it is taken again.
    if (pairOk && g_ctl.pkeGripHeal && !ours) {
      float fr[16];
      if (handprop::relative(gameM, gameHand, fr)) {
        InterlockedIncrement(&g_pk.healChecks);
        g_pk.relLenCm = (double)vm::dsqrt((double)fr[12]*fr[12] + (double)fr[13]*fr[13] + (double)fr[14]*fr[14]) * 30.48;
        if (g_pk.exactGrip.locked) {
          const double dp = handprop::rel_pos_delta(fr, g_pk.exactGrip.rel), da = handprop::rel_axis_delta(fr, g_pk.exactGrip.rel);
          g_pk.lastDeltaCm = dp * 30.48; g_pk.lastDeltaAx = da; if (g_pk.lastDeltaCm > g_pk.maxDeltaCm) g_pk.maxDeltaCm = g_pk.lastDeltaCm;
          const int differs = dp > 0.295 || da > 0.0152;
          const int steady = g_pk.haveFresh && handprop::rel_pos_delta(fr, g_pk.lastFresh) <= 0.05 && handprop::rel_axis_delta(fr, g_pk.lastFresh) <= 0.00137046525;
          if (differs && steady) {
            if (++g_pk.healRun >= 20) {
              InterlockedIncrement(&g_pk.rebinds);
              if (g_pk.rebinds <= 12) log_line("PKEGRIP re-captured: the locked PKE-in-hand relation differed from what the game shows by %.1f cm / axis error %.4f for 20 steady samples (relation length now %.1f cm); the grip is taken again from the game's pose", g_pk.lastDeltaCm, da, g_pk.relLenCm);
              handprop::reset(&g_pk.exactGrip); handprop::reset(&g_pk.handFollow); g_pk.healRun = 0; g_pk.haveFresh = 0;
            }
          } else g_pk.healRun = 0;
        }
        for (int i = 0; i < 16; ++i) g_pk.lastFresh[i] = fr[i];
        g_pk.haveFresh = 1;
      }
    }
    const long pkeFarBefore = g_pk.exactGrip.tooFar;
    const int pkeStepped = pairOk ? handprop::step(&g_pk.exactGrip, gameM, gameHand, finalHand, exactPkeM) : 0;
    if (g_pk.exactGrip.tooFar != pkeFarBefore) {   // 1.7.93: the meter is not within reach of the hand (still in the belt / on its way out): not locked, the game's own spot is used meanwhile
      static LONG s_pkeFarLogs;
      if (InterlockedIncrement(&s_pkeFarLogs) <= 12)
        log_line("PKEGRIP far t=%.2fs: the game's meter is %.1f cm from its hand (a hold is under %.0f cm): not locked as the grip yet", qpc_ms() / 1000.0, g_pk.exactGrip.lastFarFt * 30.48, handprop::kMaxHoldFt * 30.48);
    }
    if (pkeStepped) {
      g_pk.exactActor = actor;
      float tracked[16];
      if (handprop::tracked_frame(gripf, dirf, wupf, tracked))
        { handprop::capture_hand(&g_pk.handFollow, finalHand, tracked); if (handprop::drift_step(&g_pk.handFollow, &g_pkeDrift, finalHand, tracked)) prop_drift_log("PKE", 9, g_pkeDrift); }
      for (int i=0;i<16;++i) exactFinalHand[i]=finalHand[i];
      exactPke=1; InterlockedIncrement(&g_pk.exactUsed);
      static LONG s_exactPkeLog;
      if (InterlockedIncrement(&s_exactPkeLog) == 1)
        log_line("HANDGRIP PKE captured from GAME hand (holster/redraw keeps this grip; no direct controller prop placement)");
    }
    }
  }

  // 1.7.147 LOCK TO THE HAND: the meter's own hold (R_PKE) is not there this frame but the drawn hand is: the locked grip goes on the DRAWN hand, never on a hand rebuilt
  // from the controller (Keith's 1.7.139 log: 15579 of 22816 placements were rebuilt from the controller through a relation taken once; that is the PKE "above the hand").
  if (!exactPke && g_pk.exactGrip.havePrev && g_pk.exactGrip.locked && pkePairOk && handprop::place(g_pk.exactGrip.rel, pkeDrawnHand, exactPkeM)) {
    for (int i = 0; i < 16; ++i) exactFinalHand[i] = pkeDrawnHand[i];
    exactPke = 1;
    const LONG n = InterlockedIncrement(&g_pk.onDrawnHand);
    if (n == 1) log_line("HANDGRIP PKE locked to the DRAWN hand while its own hold is missing (1.7.147; it was rebuilt from the controller before)");
  }
  if (!exactPke && g_pk.exactGrip.havePrev && g_pk.handFollow.have) {
    float tracked[16], carriedHand[16];
    if (handprop::tracked_frame(gripf, dirf, wupf, tracked) &&
        handprop::follow_hand(&g_pk.handFollow, tracked, carriedHand) &&
        handprop::place(g_pk.exactGrip.rel, carriedHand, exactPkeM)) {
      for (int i=0;i<16;++i) exactFinalHand[i]=carriedHand[i];
      exactPke=3;
      const LONG fb = InterlockedIncrement(&g_pk.exactFallback);
      if (fb <= 6) log_line("HANDGRIP PKE model gap: reconstructed GAME hand first, then reapplied its locked grip");
    }
  }

  if (!exactPke) {
    // Bootstrap frame: leave the game's PKE untouched. arm_drive now moves the
    // right GAME hand from the controller even while the PKE is out, so the
    // exact pair appears on the next arm pass without any guessed PKE pose.
    InterlockedIncrement(&g_pk.exactFallback);
    {   // 1.7.170: keep the PKE in the hand with the last relation to the controller instead of leaving it at the game's spot
      float M[16];
      if (pke_rel_pose(gripf, dirf, wupf, M)) {
        pke_write_pose(self, M);
        for (int i = 0; i < 16; ++i) g_pk.newM[i] = M[i];
        g_pk.self = (uintptr_t)self; g_pk.placedQ = qpc_now(); g_pk.lastSeenQ = g_pk.placedQ;
        // "ours" detection (1.7.172: exact, as the main path does it): what the fields hold AFTER the game's setter ran - not our own copy of M, which
        // the setter may have changed in the last bits. Otherwise our pose would be taken for the game's own on the next call.
        { const float* rp = entOk ? entP : posF; const float* rr = entOk ? entR : rotF;
          for (int i = 0; i < 3; ++i) g_pk.wPos[i] = rp[i];
          for (int i = 0; i < 9; ++i) g_pk.wRot[i] = rr[i]; }
        g_pk.wQ = g_pk.placedQ;
        gear_note(2, g_pk.newM + 12);
        InterlockedIncrement(&g_pkRel.holds);
        if (InterlockedIncrement(&g_pkRel.logs) <= 5) log_line("PKEREL the game's hand pair is not ready: the PKE is kept in your hand with its last hold on the controller (%.1f cm from the grip) instead of the game's own spot (kept %ld times)",
          30.48 * vm::dsqrt((double)g_pkRel.rel.pos[0] * g_pkRel.rel.pos[0] + (double)g_pkRel.rel.pos[1] * g_pkRel.rel.pos[1] + (double)g_pkRel.rel.pos[2] * g_pkRel.rel.pos[2]), (long)g_pkRel.holds);
        return 1;
      }
    }
    static LONG noPairLogged;
    if (InterlockedIncrement(&noPairLogged) <= 6)
      log_line("PKE exact game-hand pair not ready: leaving game placement untouched while the VR hand bootstraps");
    return 0;
  }

  // Decode the exact matrix into the axes/scales the existing safe writeback
  // path expects. No legacy PKE look/fit/shift math participates.
  for (int j=0;j<3;++j) {
    const double v[3]={exactPkeM[j*4+0],exactPkeM[j*4+1],exactPkeM[j*4+2]};
    L[j]=pke::len(v);
    if (!(L[j] > 1e-4) || !vm::is_finite_f((float)L[j])) { InterlockedIncrement(&g_pk.bad); return 0; }
    for (int i=0;i<3;++i) u[j][i]=v[i]/L[j];
  }

  // 2. Legacy fallback only: front onto the controller's direction, up onto
  // the controller's up (roll), optional tilt (pkemath.h look).
  pke::LookInfo li = {};
  double upCtl[3] = {0,1,0};
  if (!exactPke) {
    const float* wu = wand_up_arg(wupf);
    const double wv[3] = {wu ? wu[0] : 0.0, wu ? wu[1] : 0.0, wu ? wu[2] : 0.0};
    if (!pke::look(u, dir, wu ? wv : nullptr, wand_roll_rad(), (double)g_ctl.pkeTiltDeg * vm::kPi / 180.0, &g_pk.frame, &li, upCtl)) { InterlockedIncrement(&g_pk.bad); return 0; }
    if (!g_pk.frame.have && !li.upFound) {   // the game's hold did not show a clear up axis: after a while the best guess is kept so the meter does not flip between two
      if (InterlockedIncrement(&g_pk.tentative) > 40) { g_pk.frame.have = 1; if (InterlockedIncrement(&g_pk.upLocked) == 1) log_line("PKEGAME no clear up axis in the game's hold (how much each local axis points up: %.2f %.2f %.2f): keeping local axis %d%s as the up", li.dotsUp[0], li.dotsUp[1], li.dotsUp[2], g_pk.frame.up, g_pk.frame.usign < 0 ? " reversed" : ""); }
    }
    g_pk.axis = g_pk.frame.front; g_pk.sign = g_pk.frame.fsign; g_pk.haveAxis = g_pk.frame.have;
    if (li.upFound && InterlockedIncrement(&g_pk.upFoundLogged) == 1)
      log_line("PKEGAME model axes: front = local axis %d%s, up = local axis %d%s (how much each local axis points up in the game's own hold: %.2f %.2f %.2f; how much each points along the controller: %.2f %.2f %.2f)",
               g_pk.frame.front, g_pk.frame.fsign < 0 ? " reversed" : "", g_pk.frame.up, g_pk.frame.usign < 0 ? " reversed" : "", li.dotsUp[0], li.dotsUp[1], li.dotsUp[2], li.dotsDir[0], li.dotsDir[1], li.dotsDir[2]);
    for (int j = 0; j < 3; ++j) { g_pk.lastDot[j] = (float)li.dotsDir[j]; g_pk.lastUpDots[j] = (float)li.dotsUp[j]; }
    g_pk.lastRoll = (float)li.rollDeg;
    if (li.swingDeg > 0.5) InterlockedIncrement(&g_pk.swung);
    if (li.rolled) InterlockedIncrement(&g_pk.rollFixed);
  } else {
    // Keep diagnostics/arm orientation tied to the real controller while the
    // PKE model itself is entirely determined by the game-hand transform.
    const float* wu=wand_up_arg(wupf);
    upCtl[0]=wu?wu[0]:0.0; upCtl[1]=wu?wu[1]:1.0; upCtl[2]=wu?wu[2]:0.0;
    const double d=upCtl[0]*dir[0]+upCtl[1]*dir[1]+upCtl[2]*dir[2];
    for(int i=0;i<3;++i) upCtl[i]-=d*dir[i];
    if (!pke::unit(upCtl)) { upCtl[0]=0; upCtl[1]=1; upCtl[2]=0; }
  }
  const double swingDeg = exactPke ? 0.0 : li.swingDeg;
  // 3. position: the controller's grip point (kept out of the torso like the gun), then slid so the handle is in the visible hand, plus the fit offsets
  const double fpm = (g_headAim.fpm > 0.1f && g_headAim.fpm < 100.0f) ? (double)g_headAim.fpm : 3.28084;
  float gp[3] = {exactPke ? exactFinalHand[12] : gripf[0], exactPke ? exactFinalHand[13] : gripf[1], exactPke ? exactFinalHand[14] : gripf[2]};
  if (!exactPke) {
    double dl[3];
    if (solid_delta(gp, dl)) { gp[0] += (float)dl[0]; gp[1] += (float)dl[1]; gp[2] += (float)dl[2]; }
  }
  const float gpBase[3] = {gp[0], gp[1], gp[2]};   // the controller's point: the avatar's wrist goes here (arm_drive)
  double handShiftFt = 0.0;
  if (!exactPke && g_ctl.gripAtHand && g_ctl.armIk) {
    float gs[3];
    const int gotShift = arms_grip_shift(gs);
    const double mm = gotShift ? vm::dsqrt((double)gs[0] * gs[0] + (double)gs[1] * gs[1] + (double)gs[2] * gs[2]) : 0.0;
    if (g_ctl.pkeRigid || g_ctl.handLock) {   // 1.6: the PKE stays rigid with the hand: the slide is kept in the PKE's own axes, followed slowly, used in full (see pke::rigid_step)
      const double nowS = (double)qpc_now() / (double)qpc_freq();
      if (!g_pk.lastSeenQ || (double)(qpc_now() - g_pk.lastSeenQ) / (double)qpc_freq() > 2.0) {
        if (!g_ctl.handLock) pke::rigid_reset(&g_pk.rigid);
        // hand_lock deliberately survives holster/re-equip gaps: do not re-learn from a different animation pose.
      }
      const int ok = gotShift && mm > 0.001 && mm < 1.0;
      const double fr[3] = {(double)gs[0], (double)gs[1], (double)gs[2]};
      double sh[3];
      if (g_ctl.handLock) {
        double lockAx[3][3] = {{dir[0],dir[1],dir[2]}, {upCtl[0],upCtl[1],upCtl[2]}, {0,0,0}};
        int lockOk = pke::unit(lockAx[0]);
        if (lockOk) { const double d=pke::dot(lockAx[1],lockAx[0]); for(int i=0;i<3;++i) lockAx[1][i]-=d*lockAx[0][i]; lockOk=pke::unit(lockAx[1]); }
        if (lockOk) { pke::cross(lockAx[0],lockAx[1],lockAx[2]); lockOk=pke::unit(lockAx[2]); }
        if (lockOk) pke::grip_step(&g_pk.gripLock, (ok && site == 4) ? fr : nullptr, lockAx, (double)g_ctl.pkeShiftPct / 100.0, sh);
        else sh[0] = sh[1] = sh[2] = 0.0;
      } else pke::rigid_step(&g_pk.rigid, ok ? fr : nullptr, u, nowS, (double)g_ctl.pkeShiftPct / 100.0, 0.5, 0.08, 0.6, sh);
      for (int i = 0; i < 3; ++i) gp[i] += (float)sh[i];
      if (ok && (!g_ctl.handLock || site == 4)) InterlockedIncrement(&g_pk.shiftFresh);
      else if (g_ctl.handLock ? g_pk.gripLock.have : g_pk.rigid.have) InterlockedIncrement(&g_pk.shiftHeld);
      else InterlockedIncrement(&g_pk.shiftNone);
      const double used = vm::dsqrt(sh[0] * sh[0] + sh[1] * sh[1] + sh[2] * sh[2]);
      handShiftFt = used;
      if ((LONG)(used * 100.0 * 30.48) > g_pk.shiftMaxX100) g_pk.shiftMaxX100 = (LONG)(used * 100.0 * 30.48);
      g_pk.shiftSumCm += used * 30.48; ++g_pk.shiftN;
    } else if (g_ctl.pkePairCache) {   // 0.98: a share of the slide, held through gaps, eased in time (the same place for draw, scan and both eyes)
      const double nowS = (double)qpc_now() / (double)qpc_freq();
      if (!g_pk.lastSeenQ || (double)(qpc_now() - g_pk.lastSeenQ) / (double)qpc_freq() > 2.0) pke::shift_reset(&g_pk.shift);
      const int ok = gotShift && mm > 0.001 && mm < 1.0;
      const double fr[3] = {(double)gs[0], (double)gs[1], (double)gs[2]};
      double sh[3];
      pke::shift_step(&g_pk.shift, ok ? fr : nullptr, nowS, (double)g_ctl.pkeShiftPct / 100.0, 0.5, 0.06, sh);
      for (int i = 0; i < 3; ++i) gp[i] += (float)sh[i];
      if (ok) InterlockedIncrement(&g_pk.shiftFresh); else if (g_pk.shift.have) InterlockedIncrement(&g_pk.shiftHeld); else InterlockedIncrement(&g_pk.shiftNone);
      const double used = vm::dsqrt(sh[0] * sh[0] + sh[1] * sh[1] + sh[2] * sh[2]);
      handShiftFt = used;
      if ((LONG)(used * 100.0 * 30.48) > g_pk.shiftMaxX100) g_pk.shiftMaxX100 = (LONG)(used * 100.0 * 30.48);
      g_pk.shiftSumCm += used * 30.48; ++g_pk.shiftN;
    } else if (gotShift && mm > 0.001 && mm < 1.0) { for (int i = 0; i < 3; ++i) gp[i] += gs[i]; handShiftFt = mm; }   // the 0.97 way
  }
  double np[3];
  for (int i = 0; i < 3; ++i) np[i] = exactPke ? (double)exactPkeM[12+i] : (double)gp[i] + dir[i] * 0.01 * (double)g_ctl.pkeFwdCm * fpm + upCtl[i] * 0.01 * (double)g_ctl.pkeUpCm * fpm;
  for (int i = 0; i < 3; ++i) if (!vm::is_finite_f((float)np[i])) { InterlockedIncrement(&g_pk.bad); return 0; }
  const double mv = vm::dsqrt((np[0] - P0[0]) * (np[0] - P0[0]) + (np[1] - P0[1]) * (np[1] - P0[1]) + (np[2] - P0[2]) * (np[2] - P0[2]));
  // 4. write it back: the second pose always, the entity (what is drawn and where it scans from) when it can be used
  float newR[9];
  if (exactPke) for (int j=0;j<3;++j) for (int i=0;i<3;++i) newR[3*i+j]=exactPkeM[j*4+i];
  else for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) newR[3 * i + j] = (float)(u[j][i] * L[j]);
  for (int i = 0; i < 9; ++i) rotF[i] = newR[i];
  for (int i = 0; i < 3; ++i) posF[i] = (float)np[i];
  const int64_t nowQ = qpc_now();
  if (entOk) {
    for (int i = 0; i < 3; ++i) { entP[i] = (float)np[i]; g_pk.wPos[i] = (float)np[i]; }
    for (int i = 0; i < 9; ++i) { entR[i] = newR[i]; g_pk.wRot[i] = newR[i]; }
    g_pk.wQ = nowQ;
    InterlockedIncrement(&g_pk.entMoved);
  } else {
    for (int i = 0; i < 3; ++i) g_pk.wPos[i] = (float)np[i];
    for (int i = 0; i < 9; ++i) g_pk.wRot[i] = newR[i];
    g_pk.wQ = nowQ;
  }
  for (int j = 0; j < 3; ++j) { for (int i = 0; i < 3; ++i) g_pk.newM[j * 4 + i] = exactPke ? exactPkeM[j*4+i] : (float)(u[j][i] * L[j]); g_pk.newM[j * 4 + 3] = 0.0f; }
  for (int i = 0; i < 3; ++i) g_pk.newM[12 + i] = (float)np[i];
  g_pk.newM[15] = 1.0f;
  pke_game_set(self, g_pk.newM);   // 1.7.70: through the game's own setter, so the drawn model takes it
  if (exactPke) pke_rel_store(g_pk.newM, gripf, dirf, wupf);   // 1.7.170: remember the hold on the controller (used when the hand pair is missing)
  if (exactPke) {   // 1.7.71: what the game itself shows (its own pose of the meter) and where it belongs, for the draw (pke_draw_swap)
    float gM[16] = {};
    for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) gM[j * 4 + i] = (float)(g_pk.gameU[j][i] * g_pk.gameL[j]);
    for (int i = 0; i < 3; ++i) gM[12 + i] = (float)g_pk.gameP[i];
    gM[15] = 1.0f;
    pke_draw_publish(gM, g_pk.newM);
    pke_push_report();
  }
  if (entOk) {   // the setter may have rewritten the entity fields from the 4x4: keep "ours" detection exact
    for (int i = 0; i < 3; ++i) g_pk.wPos[i] = entP[i];
    for (int i = 0; i < 9; ++i) g_pk.wRot[i] = entR[i];
  }
  g_pk.self = (uintptr_t)self;
  if (!g_pk.lastSeenQ || (double)(nowQ - g_pk.lastSeenQ) / (double)qpc_freq() > 2.0) { g_pk.heldSinceQ = nowQ; InterlockedExchange(&g_pk.shots, 0); }   // the meter came into the hand just now
  g_pk.lastSeenQ = nowQ;
  g_pk.placedQ = nowQ;
  {   // 1.7.2 the same numbers for the PKE at fixed seconds after it came into the hand
    const float dF[3] = {(float)dir[0], (float)dir[1], (float)dir[2]};
    holdcheck_timeline(1, g_pk.newM + 12, dF, handShiftFt, (int)g_ctl.pkeFwdCm);
  }
  gear_note(2, g_pk.newM + 12);   // 1.7.31
  {   // 1.7.64 PKEGRIP: about once a second while the meter is in the hand, how it sits (cheap; a few hundred lines at most per session)
    if ((!g_pk.gripLogQ || (double)(nowQ - g_pk.gripLogQ) / (double)qpc_freq() >= 1.0) && g_pk.gripLogs < 400) {
      g_pk.gripLogQ = nowQ; InterlockedIncrement(&g_pk.gripLogs);
      const double hx = exactPke ? (double)np[0] - exactFinalHand[12] : 0.0, hy = exactPke ? (double)np[1] - exactFinalHand[13] : 0.0, hz = exactPke ? (double)np[2] - exactFinalHand[14] : 0.0;
      const double cx = (double)np[0] - gripf[0], cy = (double)np[1] - gripf[1], cz = (double)np[2] - gripf[2];
      g_pk.lastPkeToHandCm = (float)(vm::dsqrt(hx*hx+hy*hy+hz*hz) * 30.48); g_pk.lastPkeToCtlCm = (float)(vm::dsqrt(cx*cx+cy*cy+cz*cz) * 30.48);
      log_line("PKEGRIP #%ld site=%d mode=%s (exact 1 = game hand now, 3 = hand rebuilt from the controller) | PKE to the drawn hand %.1f cm, to the controller grip %.1f cm, game's own PKE to the game hand %.1f cm | grip: locked=%d stable=%d captures=%ld resets=%ld relation length %.1f cm | game pose fresh=%d | self-check: samples %ld, last difference %.1f cm / %.4f, biggest %.1f cm, re-captured %ld (new pull-outs %ld) | hand pair ok/missing %ld/%ld",
               (long)g_pk.gripLogs, site, exactPke == 1 ? "exact" : exactPke == 3 ? "rebuilt" : "none", (double)g_pk.lastPkeToHandCm, (double)g_pk.lastPkeToCtlCm, (double)g_pk.lastGamePkeToHandCm,
               g_pk.exactGrip.locked, g_pk.exactGrip.stable, g_pk.exactGrip.captures, g_pk.exactGrip.resets, g_pk.relLenCm, ours ? 0 : 1,
               (long)g_pk.healChecks, g_pk.lastDeltaCm, g_pk.lastDeltaAx, g_pk.maxDeltaCm, (long)g_pk.rebinds, (long)g_pk.rebindsDraw, (long)g_pk.pairOk, (long)g_pk.pairMiss);
      if (g_ctl.pkeLiveGrip) {   // 1.7.66: what the live grip is doing, the hand scale (is the drawn hand bigger than the game's?) and how far the drawn hand is from the controller
        const double fx = exactPke ? (double)exactFinalHand[12] - gripf[0] : 0.0, fy = exactPke ? (double)exactFinalHand[13] - gripf[1] : 0.0, fz = exactPke ? (double)exactFinalHand[14] - gripf[2] : 0.0;
        log_line("PKEGRIP live #%ld t=%.2fs | relation in use: accepted %ld, held back %ld, jumps %ld (last %.1f cm, biggest per-sample step %.1f cm); updated while steady %ld, kept while moving %ld | hand speed %.2f ft/s%s | drawn hand axes %.2f/%.2f/%.2f (longest/shortest %.2f, arm lengthened to %d%%, game's hand %.2f) -> PKE uses %s %.2f; stretched moments %ld of %ld | drawn hand to controller grip %.1f cm | PKE scale rows %.2f/%.2f/%.2f",
                 (long)g_pk.gripLogs, qpc_ms() / 1000.0, g_pk.live.accepted, g_pk.live.held, g_pk.live.jumps, g_pk.live.lastJumpFt * 30.48, g_pk.live.maxStepFt * 30.48,
                 g_pk.calmN, g_pk.busyN, g_pk.handSpeed, g_pk.hsKnown ? "" : " (not known)",
                 (double)g_pk.rawRows[0], (double)g_pk.rawRows[1], (double)g_pk.rawRows[2], g_pk.rawRatio, g_pk.rawStretch100, g_pk.lastScaleGame,
                 g_ctl.pkeRigidHand ? "a clean hand of size" : "the hand as drawn, size", g_ctl.pkeRigidHand ? (g_pk.handRefHave ? g_pk.handRef : 1.0) : g_pk.lastScaleFinal,
                 g_pk.handSpike, g_pk.handSpike + g_pk.handClean, vm::dsqrt(fx*fx+fy*fy+fz*fz) * 30.48, L[0], L[1], L[2]);
      }
    }
  }
  const LONG n = InterlockedIncrement(&g_pk.placed);
  g_pk.lastSwing = (float)swingDeg;
  for (int i = 0; i < 3; ++i) { g_pk.lastGame[i] = (float)P0[i]; g_pk.lastNew[i] = (float)np[i]; g_pk.lastEnt[i] = entOk ? entP[i] : 0.0f; }
  { const LONG m100 = (LONG)(mv * 100.0); if (m100 > g_pk.maxMovedX100) g_pk.maxMovedX100 = m100; if (n == 1 || m100 < g_pk.minMovedX100) g_pk.minMovedX100 = m100; }
  for (int i = 0; i < 3; ++i) g_pk.lastDir[i] = (float)dir[i];
  if (n <= 6 || (n % 900) == 0) {
    log_line("PKEGAME #%ld (%s): the game's PKE was placed at %.1f,%.1f,%.1f ft by its animation (%s%s; second pose %.1f,%.1f,%.1f before), moved %.2f ft to the controller grip %.1f,%.1f,%.1f; front turned %.1f deg onto the controller direction, roll %.1f deg, front/up axis %d/%d, axis dots with the controller %.2f %.2f %.2f, scale %.2f/%.2f/%.2f, tilt %d, fit %d/%d cm",
             n, site == 1 ? "draw" : site == 2 ? "scan" : site == 3 ? "arm" : "post-arm", P0[0], P0[1], P0[2], entOk ? "entity matrix" : "second pose only", ours ? ", already ours from the last call" : "", (double)g_pk.lastEnt[0], (double)g_pk.lastEnt[1], (double)g_pk.lastEnt[2], mv, np[0], np[1], np[2], swingDeg, (double)g_pk.lastRoll,
             g_pk.frame.front, g_pk.frame.up, li.dotsDir[0], li.dotsDir[1], li.dotsDir[2], L[0], L[1], L[2], (int)g_ctl.pkeTiltDeg, (int)g_ctl.pkeFwdCm, (int)g_ctl.pkeUpCm);
  }
  if (InterlockedIncrement(&g_pk.parentLogged) == 1) {
    uintptr_t par = 0;
    if (memory_readable((const void*)(actor + 0x24E80), 8)) par = *(const uintptr_t*)(actor + 0x24E80);
    g_pk.parent = par ? par : 1;
    log_line("PKEGAME the player's object at +0x24E80 is %s (null = the game draws the meter with its own entity matrix, as assumed)", par ? "NOT null: the meter may be drawn relative to it, so the entity move may be off" : "null");
  }
  return 1;
}

static GBVR_NOINLINE int pke_place_inner(uint8_t* self, int site) {
  if (!g_ctl.pkeGame || !g_ctl.stereoActive || g_ctl.gamePlace) { InterlockedIncrement(&g_pk.disabled); return 0; }   // 1.7.13: gamePlace = the game's own PKE hold
  uintptr_t actor = 0; float dirf[3], gripf[3], wupf[3]; int64_t q = 0;
  if (!wand_aim_read(&actor, dirf, gripf, &q, wupf) || !actor) { InterlockedIncrement(&g_pk.noAim); return 0; }
  if (!aim::is_fresh(qpc_now(), q, qpc_freq(), 250)) { InterlockedIncrement(&g_pk.noAim); return 0; }   // (the holster state does not matter: the PKE is in the hand)
  g_pkAimQ = q;
  if (!memory_readable((const void*)(actor + layout::kOffPlayerPke), 8) || *(const uintptr_t*)(actor + layout::kOffPlayerPke) != (uintptr_t)self) { InterlockedIncrement(&g_pk.notPlayer); return 0; }
  {   // 1.7.64: when the meter comes into the hand and when it goes away (the video of 1.7.63 showed the belt copy, so the log must say whether the meter was out at all)
    static int s_wasHeld; static LONG s_heldLogs;
    const int heldNow = pke_item_held() ? 1 : 0;
    if (heldNow != s_wasHeld) {
      s_wasHeld = heldNow;
      if (!heldNow) pke_push_report(1);   // 1.7.72: what the draw pushes did while it was out
      if (InterlockedIncrement(&s_heldLogs) <= 80)
        log_line("PKEHELD the PKE is now %s the hand | placed %ld, exact %ld, rebuilt-from-controller %ld, on the drawn hand without its hold %ld (1.7.147), hand pair ok/missing %ld/%ld, grip locked=%d, belt copy hidden=%d", heldNow ? "IN" : "OUT of", (long)g_pk.placed, (long)g_pk.exactUsed, (long)g_pk.exactFallback, (long)g_pk.onDrawnHand, (long)g_pk.pairOk, (long)g_pk.pairMiss, g_pk.exactGrip.locked, (int)g_ctl.hideBeltPke);
    }
  }
  if (!pke_item_held()) { InterlockedIncrement(&g_pk.notHeld); g_pkPushSelf = 0; return 0; }
  g_pkPushSelf = (uintptr_t)self;   // 1.7.72: the draw pushes of this meter get the in-hand pose (hk_mat_push)
  PkLock lk;
  if (!lk.got) { InterlockedIncrement(&g_pk.busy); return 0; }
  ArmStereo draw;
  const int paired = g_ctl.pairHands && draw_stereo(&draw) && draw.pairQ;
  if (paired && draw.pairRole == 2 && g_pk.drawPair == draw.pairQ && g_pk.drawSelf == (uintptr_t)self &&
      memory_readable(self, layout::kSizePkeMeter)) {
    for (int i = 0; i < 3; ++i) {
      ((float*)(self + layout::kOffPkePos))[i] = g_pk.drawM[12 + i];
      if (g_ctl.pkeEntity) ((float*)(self + layout::kActorPos))[i] = g_pk.drawM[12 + i];
      for (int j = 0; j < 3; ++j) {
        const float value = g_pk.drawM[j * 4 + i];
        ((float*)(self + layout::kOffPkeRot))[3 * i + j] = value;
        if (g_ctl.pkeEntity) ((float*)(self + layout::kOffEntityRot))[3 * i + j] = value;
      }
    }
    pke_game_set(self, g_pk.drawM);   // 1.7.70
    gear_note(2, g_pk.drawM + 12);
    return 1;
  }
  const int placed = pke_place_locked(self, site, actor, dirf, gripf, wupf);
  if (placed && paired && draw.pairRole == 1) {
    for (int i = 0; i < 16; ++i) g_pk.drawM[i] = g_pk.newM[i];
    g_pk.drawSelf = (uintptr_t)self; g_pk.drawPair = draw.pairQ;
  }
  return placed;
}

// 1.7.103 PKEGONE: "the PKE disappears sometimes when turning". The meter is placed through pke_place_inner; when that gives up for a moment (a stale aim sample, the placement lock busy) the game's own
// placement stands for that call - the meter jumps to the animation's spot or is not drawn. Two things are done here: (1) such a short miss keeps the LAST in-hand pose for up to 150 ms (only on those
// two exits, never when the PKE is not the item in hand); (2) every gap longer than 250 ms is logged with the first cause and the time, so a video can be matched to it.
static struct { int64_t gapQ, okQ, drawQ; int cause; LONG causes[8], gaps, holds, noDrawGaps; LONG logs; double longestMs; } g_pg;
static const char* const kPgName[8] = {"none", "PKE not enabled / game places it", "aim sample too old or missing", "not the player's meter", "placement lock busy", "the game did not draw the meter", "pose unreadable", "other"};
static void pke_write_pose(uint8_t* self, const float* M) {
  if (!memory_readable(self, layout::kSizePkeMeter)) return;
  for (int i = 0; i < 3; ++i) {
    ((float*)(self + layout::kOffPkePos))[i] = M[12 + i];
    if (g_ctl.pkeEntity) ((float*)(self + layout::kActorPos))[i] = M[12 + i];
    for (int j = 0; j < 3; ++j) {
      const float value = M[j * 4 + i];
      ((float*)(self + layout::kOffPkeRot))[3 * i + j] = value;
      if (g_ctl.pkeEntity) ((float*)(self + layout::kOffEntityRot))[3 * i + j] = value;
    }
  }
  pke_game_set(self, M);
}
static GBVR_NOINLINE int pke_place(uint8_t* self, int site) {
  const LONG dis0 = g_pk.disabled, aim0 = g_pk.noAim, np0 = g_pk.notPlayer, busy0 = g_pk.busy, nh0 = g_pk.notHeld;
  int r = pke_place_inner(self, site);
  const int64_t now = qpc_now();
  const double fq = (double)qpc_freq();
  if (g_pk.notHeld != nh0) { g_pg.gapQ = 0; g_pg.cause = 0; g_pg.drawQ = 0; return r; }   // not the item in hand: nothing to keep or log
  if (site == 1 || site == 6) g_pg.drawQ = now;
  int cause = 0;
  if (!r) cause = g_pk.disabled != dis0 ? 1 : g_pk.noAim != aim0 ? 2 : g_pk.notPlayer != np0 ? 3 : g_pk.busy != busy0 ? 4 : 7;
  if (!r && (cause == 2 || cause == 4) && g_pg.okQ && (double)(now - g_pg.okQ) / fq < 0.15 && g_pk.placedQ) {   // (1) a short miss: the last in-hand pose stays for this call
    pke_write_pose(self, g_pk.newM);
    InterlockedIncrement(&g_pg.holds);
    r = 1;
  }
  const int drawStale = g_pg.drawQ && (double)(now - g_pg.drawQ) / fq > 0.25 && site != 1 && site != 6;   // other calls keep coming but the game stopped drawing the meter
  if (r && !drawStale) {
    g_pg.okQ = now;
    if (g_pg.gapQ) {
      const double ms = (double)(now - g_pg.gapQ) * 1000.0 / fq;
      if (ms > 250.0) {
        InterlockedIncrement(&g_pg.gaps);
        if (ms > g_pg.longestMs) g_pg.longestMs = ms;
        if (InterlockedIncrement(&g_pg.logs) <= 30)
          log_line("PKEGONE t=%.2fs the PKE was not at your hand for %.0f ms (first cause: %s; causes so far: aim %ld, lock busy %ld, not drawn %ld, other %ld; kept the last pose %ld times)", qpc_ms() / 1000.0, ms, kPgName[g_pg.cause], (long)g_pg.causes[2], (long)g_pg.causes[4], (long)g_pg.causes[5], (long)g_pg.causes[7], (long)g_pg.holds);
      }
      g_pg.gapQ = 0; g_pg.cause = 0;
    }
  } else {
    if (drawStale && r) cause = 5;
    if (cause) {
      InterlockedIncrement(&g_pg.causes[cause]);
      if (!g_pg.gapQ) { g_pg.gapQ = now; g_pg.cause = cause; }
    }
  }
  return r;
}

// 1.7.63: PKE no longer publishes a reverse PKE->arm target. The rendered hand is authoritative.
// the game's own PKE scan state (what its update just did): scan on / off, the target it holds, and how far that is from the meter
static void pke_scan_note(uint8_t* self) {
  InterlockedIncrement(&g_pk.scanFrames);
  if (!memory_readable(self + 0x4E8, 0x70)) return;
  const int scanning = *(const int*)(self + 0x53C) != 0;
  const int idx = *(const int*)(self + 0x520);
  uintptr_t tgt = *(const uintptr_t*)(self + 0x4E8);   // first (and only) slot: the target the meter is locked on (0 = none)
  if (scanning != g_pk.scanOn) {
    g_pk.scanOn = scanning;
    if (scanning) InterlockedIncrement(&g_pk.scanStarts);
    if (InterlockedIncrement(&g_pk.scanLogged) <= 40) {
      float tp[3] = {0, 0, 0}; double dist = -1.0;
      if (tgt && memory_readable((const void*)(tgt + 0x54), 12)) {
        for (int i = 0; i < 3; ++i) tp[i] = *(const float*)(tgt + 0x54 + 4 * i);
        dist = vm::dsqrt((double)(tp[0] - g_pk.newM[12]) * (tp[0] - g_pk.newM[12]) + (double)(tp[1] - g_pk.newM[13]) * (tp[1] - g_pk.newM[13]) + (double)(tp[2] - g_pk.newM[14]) * (tp[2] - g_pk.newM[14]));
      }
      char raw[300]; int rl = 0;
      for (int i = 0; i < 28 && rl < 280; ++i) rl += wsprintfA(raw + rl, "%s%08x", i ? " " : "", (unsigned)*(const uint32_t*)(self + 0x4E8 + 4 * i));
      raw[rl] = 0;
      log_line("PKESCAN the PKE is now %s (1.4: this is the item state at +0x53C, NOT the scan; the real scan is logged as PKEEASY): target %p%s at %.1f,%.1f,%.1f ft, %.1f ft from the meter, slot index %d, progress %.2f/%.2f [state dwords from +0x4E8: %s]", scanning ? "equipped" : "put away", (void*)tgt, tgt ? "" : " (none in range)",
               (double)tp[0], (double)tp[1], (double)tp[2], dist, idx, (double)*(const float*)(self + 0x54C), (double)*(const float*)(self + 0x548), raw);
    }
  }
  if (tgt && tgt != g_pk.lastTarget) { InterlockedIncrement(&g_pk.scanTargetsSeen); g_pk.lastTarget = tgt; }
}

// every few seconds while the meter is in the hand: how far the nearest scannable source is from the meter (the scan range is measured from the meter, not from you)
static void pke_src_note() {
  const int64_t now = qpc_now();
  if (g_pk.srcLogQ && (double)(now - g_pk.srcLogQ) / (double)qpc_freq() < 5.0) return;
  g_pk.srcLogQ = now;
  float src[16][3]; int64_t sq = 0;
  const int ns = fight_pke_sources(src, 16, &sq);
  double best = 1e9;
  for (int k = 0; k < ns; ++k) {
    const double d = vm::dsqrt((double)(src[k][0] - g_pk.newM[12]) * (src[k][0] - g_pk.newM[12]) + (double)(src[k][1] - g_pk.newM[13]) * (src[k][1] - g_pk.newM[13]) + (double)(src[k][2] - g_pk.newM[14]) * (src[k][2] - g_pk.newM[14]));
    if (d < best) best = d;
  }
  static LONG s_n;
  if (InterlockedIncrement(&s_n) <= 40) {
    if (ns > 0) log_line("PKESCAN %d scannable source(s) within 120 ft of you; the nearest is %.1f ft from the meter (the scan finds things inside its range around the meter)", ns, best);
    else log_line("PKESCAN no scannable source within 120 ft of you: there is nothing for the meter to find here (walk toward one; the log lists the ones the game has under PKESRC)");
  }
}

static void pke_auto_picture() {   // 0.97: a picture 3 s and 12 s after the meter came into the hand, so the next report shows where the meter really is
  if (!g_ctl.probeData) return;
  if (!g_pk.heldSinceQ) return;
  const double age = (double)(qpc_now() - g_pk.heldSinceQ) / (double)qpc_freq();
  if ((g_pk.shots == 0 && age > 3.0) || (g_pk.shots == 1 && age > 12.0)) {
    InterlockedIncrement(&g_pk.shots);
    log_line("PKEGAME picture requested %.1f s after the PKE came into your hand (the diagnostic picture of both eyes is saved in the game folder)", age);
    shot_request();
  }
}

// ===== 1.4 the forgiving PKE scan ==========================================================================================================================================
// What the 1.3 log showed: the PKE was in the hand and pointing, but never scanned. The game's own rules (layout.h, pkeeasymath.h): the target must be within 15 ft (ground distance) AND within
// 18 degrees of where the PKE points AND the line must be clear AND the cooldown over AND the trigger held. The log had ghosts 37-65 ft away, so none of it could ever be true.
// 1.4 keeps the game's own scan (its bar, its sounds, its result) and only widens the two limits, through the game's own numbers:
//   - the cone: the game's global threshold (cos 18 deg) is lowered to cos(pke_cone_deg). The game's enumeration, its scan check and its strength all read that same number.
//   - the range: scan_ok (0x1456A0) is asked twice when the first answer is "no" and the only problem is the range: the record's range is raised to pke_easy_ft for this frame.
//   - the trigger: with pke_auto the meter's input byte (+0x538) is set by the probe while the PKE points at something scannable, so the scan starts by itself.
typedef unsigned char(__fastcall* PFN_PkeScanOk)(void* self);
static PFN_PkeScanOk o_pkeScanOk;
static struct {
  volatile LONG updates, withTarget, inWindow, autoInput, scanOkCalls, scanOkSaved, thrWrites, thrBad, visBlocked, cooldownBlocked, tgtChanges, haptic, rawInput, outsideGame;
  volatile LONG scanStarts, scanEnds, scanFinished, scanCancelled, ticks;
  float *thr, thrOrig; int thrState;           // the game's cone threshold: 0 not looked at yet, 1 ready, -1 not usable
  int prevScanning; int64_t scanStartQ, tgtSinceQ, lastTickQ; uintptr_t lastTgt; int prevInWindow;
  double minDistFt, minAngDeg; double sumBarMax; float lastBar, maxBar;
  float tgtPos[3]; int64_t tgtQ; double lastDistFt, lastAngDeg;   // the game's own locked target, for the aim help
  volatile LONG logged, logCap;
  uint8_t gogOrig[6]; int gogState, gogPatched; volatile LONG gogApplied, gogRestored;   // the goggle frame patch
  // 1.6 the real scan: the pings (0x1460D0) and their rate (0x145F20), why scan_ok says no, what the targets are
  volatile LONG pings, pingsCancel, pingsAdded, pingsNothing, scansDone, pingLogged, rateCalls, rateRaised, rateLevel[4], ownerBusy, ownerState[8], whyLogged;
  volatile LONG why[pkeasy::kWhyCount], whyHeld[pkeasy::kWhyCount];
  int64_t lastPingQ; float lastRateGame, lastRateUsed; int inputPre, whyStable, whyCand, whyCandN;
  struct Type { uintptr_t vt; volatile LONG seen, scannable, blocked, scanned, pings, done; } types[12];
  volatile LONG typesN;
} g_pe;

static pkeasy::Cfg pke_easy_cfg() {
  pkeasy::Cfg c;
  c.easy = g_ctl.pkeEasy != 0; c.autoScan = 0; /* 1.7.18: the PKE never scans by itself, whatever pke_auto says */ c.rangeFt = (double)g_ctl.pkeEasyFt; c.coneDeg = (double)g_ctl.pkeConeDeg;
  return c;
}

// 1.7.83: how far the nearest scannable thing is from the meter (feet), 1e9 when unknown. Used to widen the cone at close range (pkeeasymath.h close_cone_deg).
static double pke_nearest_source_ft() {
  if (!g_pk.placedQ || !aim::is_fresh(qpc_now(), g_pk.placedQ, qpc_freq(), 250)) return 1.0e9;
  float src[16][3]; int64_t sq = 0;
  const int ns = fight_pke_sources(src, 16, &sq);
  double best = 1.0e9;
  for (int k = 0; k < ns; ++k) {
    const double dx = (double)src[k][0] - g_pk.newM[12], dy = (double)src[k][1] - g_pk.newM[13], dz = (double)src[k][2] - g_pk.newM[14];
    const double d = vm::dsqrt(dx * dx + dy * dy + dz * dz);
    if (d == d && d < best) best = d;
  }
  return best;
}
static struct { double lastDeg; int on; volatile LONG frames, starts, logged; double minFt, maxDeg; } g_pc;   // 1.7.83 PKECLOSE: the close-range cone

// the game's cone threshold, kept at the setting (every update: cheap, and it follows the menu); 1.7.83: wider while a scannable thing is close to the meter
static void pke_easy_threshold() {
  if (g_pe.thrState < 0) return;
  if (g_pe.thrState == 0) {
    float* t = (float*)rva(layout::kRvaPkeAlignMin);
    if (!memory_readable(t, 4)) { g_pe.thrState = -1; InterlockedIncrement(&g_pe.thrBad); log_line("PKEEASY the game's cone value is not readable: the cone stays the game's own 18 degrees"); return; }
    const float v = *t;
    if (!(v > 0.5f && v < 0.99f)) {
      g_pe.thrState = -1; InterlockedIncrement(&g_pe.thrBad);
      log_line("PKEEASY the game's cone value is %.4f, not the expected cos 18 deg = 0.9511: left alone (the range and auto-start still work)", (double)v);
      return;
    }
    DWORD old = 0;
    VirtualProtect(t, 4, PAGE_READWRITE, &old);
    g_pe.thr = t; g_pe.thrOrig = v; g_pe.thrState = 1;
    log_line("PKEEASY the game's own scan cone: cos = %.4f (= %.1f degrees off the PKE's line), range 15 ft; 1.4 setting: easy=%d range %d ft cone %d deg auto=%d",
             (double)v, pkeasy::align_deg((double)v), (int)g_ctl.pkeEasy, (int)g_ctl.pkeEasyFt, (int)g_ctl.pkeConeDeg, (int)g_ctl.pkeAuto);
  }
  const pkeasy::Cfg c = pke_easy_cfg();
  const double nearFt = (c.easy && g_ctl.pkeCloseHelp) ? pke_nearest_source_ft() : 1.0e9;
  const double coneDeg = pkeasy::effective_cone_deg(c, nearFt, (int)g_ctl.pkeCloseHelp);
  const double settingDeg = pkeasy::game_cone_deg(c);
  const int wide = c.easy && coneDeg > settingDeg + 0.05;
  if (wide) {
    InterlockedIncrement(&g_pc.frames);
    if (nearFt < g_pc.minFt || g_pc.minFt == 0.0) g_pc.minFt = nearFt;
    if (coneDeg > g_pc.maxDeg) g_pc.maxDeg = coneDeg;
  }
  if (wide != g_pc.on) {
    g_pc.on = wide;
    if (wide) InterlockedIncrement(&g_pc.starts);
    if (InterlockedIncrement(&g_pc.logged) <= 40) log_line("PKECLOSE the scan cone is %s: nearest scannable thing %.1f ft from the meter, cone %.1f deg (setting %.0f deg, game's own 18); a hand-held meter sits beside the line to what you look at, so close things need a wider cone", wide ? "WIDER now" : "back to the setting", nearFt < 1.0e6 ? nearFt : -1.0, coneDeg, settingDeg);
  }
  g_pc.lastDeg = coneDeg;
  const float want = c.easy ? (float)pkeasy::cone_cos(coneDeg) : g_pe.thrOrig;
  if (*g_pe.thr != want) {
    *g_pe.thr = want;
    const LONG n = InterlockedIncrement(&g_pe.thrWrites);
    if (n <= 8 && !wide) log_line("PKEEASY the scan cone is now cos %.4f (%.1f degrees; the game's own was %.1f)", (double)want, pkeasy::align_deg((double)want), pkeasy::align_deg((double)g_pe.thrOrig));
  }
}

struct PkeRec {
  uintptr_t tgt; float near2, far2, dist2, align, strength, cooldown, timer, bar; int vis, idx, state; unsigned char input, scanning;
};
static int pke_read_rec(const uint8_t* self, PkeRec* o) {
  if (!self || !memory_readable(self + layout::kOffPkeRecords, 0x690 - layout::kOffPkeRecords)) return 0;
  o->tgt = *(const uintptr_t*)(self + layout::kOffPkeRecords);
  o->near2 = *(const float*)(self + 0x4F0); o->far2 = *(const float*)(self + 0x4F4); o->dist2 = *(const float*)(self + 0x4F8);
  o->vis = *(const int*)(self + 0x4FC); o->align = *(const float*)(self + 0x500); o->strength = *(const float*)(self + 0x504);
  o->idx = *(const int*)(self + layout::kOffPkeSlot); o->state = *(const int*)(self + layout::kOffPkeState);
  o->input = *(const unsigned char*)(self + layout::kOffPkeInput); o->cooldown = *(const float*)(self + layout::kOffPkeCooldown);
  o->timer = *(const float*)(self + layout::kOffPkeScanTimer); o->scanning = *(const unsigned char*)(self + layout::kOffPkeScanning); o->bar = *(const float*)(self + layout::kOffPkeScanBar);
  return vm::is_finite_f(o->dist2) && vm::is_finite_f(o->align) && vm::is_finite_f(o->near2);
}
static void pke_rec_to(const PkeRec& r, pkeasy::Rec* o) {
  o->hasTarget = r.tgt != 0 && r.idx == 0; o->visible = r.vis != 0; o->dist2 = (double)r.dist2; o->align = (double)r.align; o->cooldown = (double)r.cooldown; o->equipped = r.state != 0;
}

// scan_ok: the game's answer first; when it says no and ONLY the range is what stops it, the range is widened for this frame and asked again
static void pke_tracked_alignment(uint8_t* self) {
  if (g_ctl.pkeEasy && g_ctl.headAim == 2 && g_ctl.stereoActive && self && (uintptr_t)self == g_pk.self &&
      g_pk.placedQ && aim::is_fresh(qpc_now(), g_pk.placedQ, qpc_freq(), 250) && pke_item_held()) {
    PkeRec target;
    uintptr_t actor = 0; int64_t q = 0; float dir[3], grip[3], position[3], alignment;
    if (pke_read_rec(self, &target) && target.tgt &&
        memory_readable((const void*)(target.tgt + layout::kActorPos), 12) &&
        wand_aim_read(&actor, dir, grip, &q) && actor &&
        aim::is_fresh(qpc_now(), q, qpc_freq(), 120)) {
      for (int i = 0; i < 3; ++i) position[i] = *(const float*)(target.tgt + layout::kActorPos + 4 * i);
      if (pkeasy::controller_alignment(grip, dir, position, &alignment)) {
        for (int attempt = 0; attempt < 3; ++attempt) {
          const LONG seq = g_headAim.seq;
          if (seq & 1) continue;
          float eye[3], gaze[3], gazeCos;
          for (int i = 0; i < 3; ++i) { eye[i] = g_headAim.eye[i]; gaze[i] = g_headAim.gaze[i]; }
          if (seq != g_headAim.seq) continue;
          double dist2 = 0; for (int i = 0; i < 3; ++i) dist2 += ((double)position[i] - eye[i]) * ((double)position[i] - eye[i]);
          if (pkeasy::controller_alignment(eye, gaze, position, &gazeCos))
            alignment = pkeasy::close_alignment(alignment, gazeCos, vm::dsqrt(dist2), g_ctl.pkeCloseHelp);
          break;
        }
        alignment = pkeasy::assisted_alignment(target.align, alignment);
        *(float*)(self + 0x500) = alignment;
        static int logs;
        if (logs < 12 && vm::dabs((double)target.align - alignment) > 0.1) {
          ++logs;
          log_line("PKESCAN tracked angle: native %.1f deg -> controller %.1f deg for locked target %p (visibility, cooldown and target-state checks remain the game's)",
            pkeasy::align_deg(target.align), pkeasy::align_deg(alignment), (void*)target.tgt);
        }
      }
    }
  }
}

static unsigned char __fastcall hk_pke_scan_ok(void* selfv) {
  InterlockedIncrement(&g_pe.scanOkCalls);
  uint8_t* self = (uint8_t*)selfv;
  pke_tracked_alignment(self);
  const unsigned char r = o_pkeScanOk(selfv);
  if (r || !g_ctl.pkeEasy || !self || (uintptr_t)self != g_pk.self || !g_pk.placedQ || !aim::is_fresh(qpc_now(), g_pk.placedQ, qpc_freq(), 250)) return r;
  PkeRec rec;
  if (!pke_read_rec(self, &rec) || rec.idx != 0 || !rec.tgt) return r;
  const double R = pkeasy::game_range_ft(pke_easy_cfg());
  if (!((double)rec.dist2 <= R * R) || !((double)rec.near2 < R * R)) return r;
  *(float*)(self + 0x4F0) = (float)(R * R);   // stays until the game refills its record (once per update); the meter's own range checks then agree
  const unsigned char r2 = o_pkeScanOk(selfv);
  if (r2) InterlockedIncrement(&g_pe.scanOkSaved);
  else *(float*)(self + 0x4F0) = rec.near2;    // the range was not the problem: put it back
  return r2;
}

// ---- 1.6 the target's own virtual getters (the same ones scan_ok and the ping call) ----------------------------------------------------------------------------------------------
static int pke_vcall_ok(uintptr_t tgt, uint32_t off, uintptr_t* fn, uintptr_t* vtOut) {
  if (!tgt || !memory_readable((const void*)tgt, 8)) return 0;
  const uintptr_t lo = rva(0), hi = lo + layout::kExpectedSizeOfImage;
  const uintptr_t vt = *(const uintptr_t*)tgt;
  if (vt < lo || vt >= hi || !memory_readable((const void*)(vt + off), 8)) return 0;
  const uintptr_t f = *(const uintptr_t*)(vt + off);
  if (f < lo || f >= hi) return 0;
  *fn = f; if (vtOut) *vtOut = vt;
  return 1;
}
static int pke_tgt_bool(uintptr_t tgt, uint32_t off, int* out) {
  uintptr_t f; if (!pke_vcall_ok(tgt, off, &f, 0)) return 0;
  *out = ((unsigned char(__fastcall*)(void*))f)((void*)tgt) != 0;
  return 1;
}
static int pke_tgt_float(uintptr_t tgt, uint32_t off, float* out) {
  uintptr_t f; if (!pke_vcall_ok(tgt, off, &f, 0)) return 0;
  *out = ((float(__fastcall*)(void*))f)((void*)tgt);
  return vm::is_finite_f(*out);
}
// 1.7.13: for the PKE proximity buzz (damage.cpp): is this source already scanned? (1 yes, 0 no, -1 unknown)
int engine_pke_source_scanned(uintptr_t actor) {
  int scanned = 0, scannable = 1;
  if (!actor) return -1;
  uintptr_t f; if (!pke_vcall_ok(actor, layout::kVtTargetScanned, &f, 0)) return -1;
  if (!pke_tgt_bool(actor, layout::kVtTargetScanned, &scanned)) return -1;
  if (pke_tgt_bool(actor, layout::kVtTargetScannable, &scannable) && !scannable) return 1;   // not scannable any more = nothing to find there
  return scanned ? 1 : 0;
}
// 1.7.29: the game's own scannable / scanned answers for one actor, and what kind of thing it is (for the logs and the aim help)
int engine_pke_target_state(uintptr_t actor, int* scannable, int* scanned) {
  int a = 1, b = 0;
  if (!actor) return 0;
  const int okA = pke_tgt_bool(actor, layout::kVtTargetScannable, &a);
  const int okB = pke_tgt_bool(actor, layout::kVtTargetScanned, &b);
  if (scannable) *scannable = okA ? a : -1;
  if (scanned) *scanned = okB ? b : -1;
  if (okA && !a && scannable) *scannable = 0;
  return okA && okB;
}
const char* engine_pke_class_name(uintptr_t actor) {
  if (!actor || !memory_readable((const void*)actor, 8)) return "nothing";
  const uintptr_t vt = *(const uintptr_t*)actor;
  if (vt == rva(layout::kRvaPkeSourceVtable)) return "PKE source";
  if (vt == rva(layout::kRvaTrinketVtable)) return "collectible";
  if (vt == rva(layout::kRvaSlimerVtable)) return "Slimer";
  return "other";
}
static uintptr_t pke_tgt_type(uintptr_t tgt) {   // the target's vtable (its class), as an offset in the game
  uintptr_t f, vt = 0; if (!pke_vcall_ok(tgt, layout::kVtTargetScannable, &f, &vt)) return 0;
  return vt - rva(0);
}
static int pke_type_slot(uintptr_t vt) {
  for (LONG i = 0; i < g_pe.typesN && i < 12; ++i) if (g_pe.types[i].vt == vt) return (int)i;
  if (g_pe.typesN >= 12) return -1;
  const LONG n = InterlockedIncrement(&g_pe.typesN) - 1;
  if (n >= 12) return -1;
  g_pe.types[n].vt = vt;
  return (int)n;
}

typedef void(__fastcall* PFN_PkePing)(void* self, unsigned char dl);
typedef float(__fastcall* PFN_PkeRate)(void* self);
static PFN_PkePing o_pkePing;
static PFN_PkeRate o_pkeRate;

static void pke_easy_log_ev(const char* what, const PkeRec& r, const uint8_t* self, double distFt, double angDeg);

// the rate of one ping: the game gives 0 when the meter is not lined up well enough, and the ping still uses up the 2 s cooldown; 1.6 puts a floor under it
static float __fastcall hk_pke_rate(void* selfv) {
  const float r = o_pkeRate(selfv);
  InterlockedIncrement(&g_pe.rateCalls);
  const int lv = pkeasy::rate_level((double)r);
  InterlockedIncrement(&g_pe.rateLevel[lv + 1]);
  g_pe.lastRateGame = r;
  float use = r;
  if (g_ctl.pkeScanHelp && (uintptr_t)selfv == g_pk.self) {
    use = (float)pkeasy::ping_rate((double)r, 1);
    if (use != r) InterlockedIncrement(&g_pe.rateRaised);
  }
  g_pe.lastRateUsed = use;
  return use;
}

// the ping itself: what it did to the target's progress, so the log shows whether a scan really happens
static void __fastcall hk_pke_ping(void* selfv, unsigned char dl) {
  uint8_t* self = (uint8_t*)selfv;
  uintptr_t tgt = 0; float p0 = -1.0f, p1 = -1.0f; int s0 = -1, s1 = -1; uintptr_t type = 0;
  if (self && memory_readable(self + layout::kOffPkeRecords, 0x690 - layout::kOffPkeRecords) && *(const int*)(self + layout::kOffPkeSlot) == 0) {
    tgt = *(const uintptr_t*)(self + layout::kOffPkeRecords);
    if (tgt) { type = pke_tgt_type(tgt); pke_tgt_float(tgt, layout::kVtTargetProgress, &p0); pke_tgt_bool(tgt, layout::kVtTargetScanned, &s0); }
  }
  double pgDistFt = -1.0, pgAngDeg = -1.0; int pgVis = -1;   // 1.7.18: how well the meter was aimed at the moment of the ping (the game's own record)
  {
    PkeRec pr0;
    if (self && pke_read_rec(self, &pr0) && pr0.idx == 0 && pr0.tgt) { pgDistFt = vm::dsqrt((double)pr0.dist2 > 0.0 ? (double)pr0.dist2 : 0.0); pgAngDeg = pkeasy::align_deg((double)pr0.align); pgVis = pr0.vis != 0; }
  }
  o_pkePing(selfv, dl);
  if (tgt) { pke_tgt_float(tgt, layout::kVtTargetProgress, &p1); pke_tgt_bool(tgt, layout::kVtTargetScanned, &s1); }
  const int64_t now = qpc_now();
  if (!dl) { InterlockedIncrement(&g_pe.pingsCancel); return; }
  const LONG n = InterlockedIncrement(&g_pe.pings);
  g_pe.lastPingQ = now;
  int added = 0, done = 0;
  if (p0 >= 0.0f && p1 >= 0.0f) { if (p1 > p0 + 1e-4f) { added = 1; InterlockedIncrement(&g_pe.pingsAdded); } else InterlockedIncrement(&g_pe.pingsNothing); }
  if ((s0 == 0 && s1 == 1) || (p0 >= 0.0f && p0 < 0.999f && p1 >= 0.999f)) { done = 1; InterlockedIncrement(&g_pe.scansDone); }
  if (type) { const int k = pke_type_slot(type); if (k >= 0) { InterlockedIncrement(&g_pe.types[k].pings); if (done) InterlockedIncrement(&g_pe.types[k].done); } }
  if (done) haptics_add(1, hap::kSrcScan, 0.95f, 220);
  else haptics_add(1, hap::kSrcScan, 0.55f, 90);
  if (g_ctl.probeData && (n <= 3 || (done && g_pe.scansDone <= 2))) { log_line("PKEPING a picture of both eyes is saved with the ping (ping %ld)", (long)n); shot_request(); }
  if (n <= 120 || done) {
    float tp[3] = {0, 0, 0};
    if (tgt && memory_readable((const void*)(tgt + layout::kActorPos), 12)) for (int i = 0; i < 3; ++i) tp[i] = *(const float*)(tgt + layout::kActorPos + 4 * i);
    const float cd = self ? *(const float*)(self + layout::kOffPkeCooldown) : 0.0f;
    const float S = self ? *(const float*)(self + layout::kOffPkeSignal) : 0.0f;
    const int ownerState = (self && *(const uintptr_t*)(self + layout::kOffPkeOwner) && memory_readable((const void*)(*(const uintptr_t*)(self + layout::kOffPkeOwner) + layout::kOffPlayerState), 4)) ? *(const int*)(*(const uintptr_t*)(self + layout::kOffPkeOwner) + layout::kOffPlayerState) : -1;
    log_line("PKEACC ping #%ld %s: aimed %.1f deg off the meter's line, %.1f ft away (ground), clear line %d | scan cone now %d deg, reach %d ft | scans begun by the probe without a trigger squeeze: %ld (always 0: auto-scan is locked off)",
             (long)n, done ? "SCAN FINISHED" : (added ? "progress added" : "nothing added"), pgAngDeg, pgDistFt, pgVis, (int)pkeasy::game_cone_deg(pke_easy_cfg()), (int)pkeasy::game_range_ft(pke_easy_cfg()), (long)g_pe.autoInput);
    log_line("PKEPING #%ld %s: target %p (class %x) at %.1f,%.1f,%.1f ft: progress %.2f -> %.2f, scanned %d -> %d | rate the game gave %.2f (level %d), used %.2f | sideways offset S %.1f | cooldown now %.2f s | player state %d | %s",
             (long)n, done ? "SCAN FINISHED" : (added ? "progress added" : "NOTHING ADDED"), (void*)tgt, (unsigned)type, (double)tp[0], (double)tp[1], (double)tp[2], (double)p0, (double)p1, s0, s1,
             (double)g_pe.lastRateGame, pkeasy::rate_level((double)g_pe.lastRateGame), (double)g_pe.lastRateUsed, (double)((S > -1.0e6f && S < 1.0e6f) ? S : -1.0f), (double)cd, ownerState,   // 1.7.14: a never-set value (1e30) is shown as -1
             g_ctl.pkeScanHelp ? "scan help on" : "scan help off");
  }
}

static void pke_easy_log_ev(const char* what, const PkeRec& r, const uint8_t* self, double distFt, double angDeg) {
  if (g_pe.logged >= 160) return;
  InterlockedIncrement(&g_pe.logged);
  float tp[3] = {0, 0, 0};
  if (r.tgt && memory_readable((const void*)(r.tgt + layout::kActorPos), 12)) for (int i = 0; i < 3; ++i) tp[i] = *(const float*)(r.tgt + layout::kActorPos + 4 * i);
  log_line("PKEEASY %s: target %p at %.1f,%.1f,%.1f ft, ground distance %.1f ft (game limit 15, now %d), %.1f deg off the PKE's line (game limit 18, now %d), line clear=%d, cooldown %.2f s, "
           "scanning=%d bar %.2f timer %.2f, input byte %d, equipped=%d, record range %.0f ft squared, PKE at %.1f,%.1f,%.1f",
           what, (void*)r.tgt, (double)tp[0], (double)tp[1], (double)tp[2], distFt, (int)pkeasy::game_range_ft(pke_easy_cfg()), angDeg, (int)pkeasy::game_cone_deg(pke_easy_cfg()),
           r.vis, (double)r.cooldown, (int)r.scanning, (double)r.bar, (double)r.timer, (int)r.input, r.state, (double)r.near2,
           self ? (double)*(const float*)(self + 0x54) : 0.0, self ? (double)*(const float*)(self + 0x58) : 0.0, self ? (double)*(const float*)(self + 0x5C) : 0.0);
}

static volatile LONG g_padNow, g_padLatch;   // 1.7: declared here (the PKE scan reads the trigger); written by bindings_pad further down
static struct { volatile LONG manualInput, manualFrames, manualFresh; int64_t lastQ; int logged; } g_manScan;   // 1.7: the right trigger pressed with the PKE out
// before the game's update: the cone, and the scan input when the PKE points at something scannable
static void pke_easy_pre(uint8_t* self) {
  pke_easy_threshold();
  InterlockedIncrement(&g_pe.updates);
  const pkeasy::Cfg c = pke_easy_cfg();
  PkeRec rec;
  g_pe.inputPre = 0;
  if (!pke_read_rec(self, &rec)) return;
  if (rec.input) InterlockedIncrement(&g_pe.rawInput);
  g_pe.inputPre = rec.input != 0;
  if (g_ctl.pkeTrigScan && rec.state != 0 && (((LONG)g_padNow >> 5) & 1)) {   // 1.7: the player pressed the scan button (the right trigger) with the PKE out: the probe sets the game's scan input itself (the game's own path set it only 7 times in the 1.6 log)
    InterlockedIncrement(&g_manScan.manualFrames);
    if (!rec.input) { *(unsigned char*)(self + layout::kOffPkeInput) = 1; InterlockedIncrement(&g_manScan.manualInput); }
    const int64_t nq = qpc_now();
    if (!g_manScan.lastQ || (double)(nq - g_manScan.lastQ) / (double)qpc_freq() > 0.6) {   // a new press
      InterlockedIncrement(&g_manScan.manualFresh);
      {   // 1.7.12: a cue for every squeeze: nothing locked = a buzz, already scanned = a soft tick (the game gives no feedback for either)
        int scannedAlready = 0, scannableNow = 1;
        if (rec.tgt) { pke_tgt_bool(rec.tgt, layout::kVtTargetScanned, &scannedAlready); pke_tgt_bool(rec.tgt, layout::kVtTargetScannable, &scannableNow); }
        if (!rec.tgt) haptics_add(1, hap::kSrcScan, 0.50f, 120);
        else if (scannedAlready) haptics_add(1, hap::kSrcScan, 0.22f, 50);
        else if (!scannableNow) haptics_add(1, hap::kSrcScan, 0.30f, 90);   // 1.7.29: a source the game has not switched on yet: a short dull tick, not the "scanning" feel
        static int s_cue; if (s_cue < 60) { ++s_cue; log_line("PKECUE squeeze #%d: %s (cooldown %.2f s)", s_cue, !rec.tgt ? "nothing locked: buzz (point the meter at a PKE source or ghost closer than the scan reach)" : (scannedAlready ? "this one is already scanned: soft tick" : (!scannableNow ? "this one is not active yet (the game will not scan it): dull tick" : "scanning")), (double)rec.cooldown); }
      }
      if (g_manScan.logged < 60) {
        ++g_manScan.logged;
        int sa = -1, sd = -1; if (rec.tgt) engine_pke_target_state(rec.tgt, &sa, &sd);
        log_line("PKESCAN trigger pressed with the PKE out: target %p, cooldown %.2f s, %s | 1.7.29 the locked thing is: %s, scannable now %d, already scanned %d, %.1f ft away (ground), %.0f deg off the meter's line (the scan needs it within %d deg and %d ft)",
                 (void*)rec.tgt, (double)rec.cooldown, rec.tgt ? "a target is locked" : "no target locked yet", rec.tgt ? engine_pke_class_name(rec.tgt) : "nothing", sa, sd,
                 rec.tgt ? vm::dsqrt((double)rec.dist2 > 0.0 ? (double)rec.dist2 : 0.0) : 0.0, rec.tgt ? pkeasy::align_deg((double)rec.align) : 0.0,
                 (int)pkeasy::game_cone_deg(pke_easy_cfg()), (int)pkeasy::game_range_ft(pke_easy_cfg()));
      }
    }
    g_manScan.lastQ = nq;
    g_pe.inputPre = 1;
  }
  if (!c.easy || !c.autoScan) return;
  pkeasy::Rec pr; pke_rec_to(rec, &pr);
  const int running = g_pe.lastPingQ && (double)(qpc_now() - g_pe.lastPingQ) / (double)qpc_freq() < 2.2;   // 1.6: a ping in the last 2.2 s = a scan is running (the old +0x67C flag is never set by the game)
  if (pkeasy::want_input(pr, c, running) && !rec.input) { *(unsigned char*)(self + layout::kOffPkeInput) = 1; InterlockedIncrement(&g_pe.autoInput); }
  g_pe.inputPre = (rec.input != 0) || *(const unsigned char*)(self + layout::kOffPkeInput) != 0;
}

// after the game's update: what the game's scan did, the feedback in the hand, the target for the aim help, the log
static void pke_easy_post(uint8_t* self, float dt) {
  pke_tracked_alignment(self); // enumeration has refilled the record; the later scan-action update must see the tracked angle
  PkeRec rec;
  if (!pke_read_rec(self, &rec)) return;
  const pkeasy::Cfg c = pke_easy_cfg();
  const int64_t now = qpc_now();
  const double freq = (double)qpc_freq();
  pkeasy::Rec pr; pke_rec_to(rec, &pr);
  const int has = pr.hasTarget;
  const int inW = pkeasy::in_window(pr, c);
  double distFt = 0.0, angDeg = 0.0;
  if (has) {
    distFt = vm::dsqrt((double)rec.dist2 > 0.0 ? (double)rec.dist2 : 0.0);
    angDeg = pkeasy::align_deg((double)rec.align);
    InterlockedIncrement(&g_pe.withTarget);
    if (inW) InterlockedIncrement(&g_pe.inWindow);
    if (!rec.vis) InterlockedIncrement(&g_pe.visBlocked);
    if (rec.cooldown > 0.0f) InterlockedIncrement(&g_pe.cooldownBlocked);
    if (!g_pe.minDistFt || distFt < g_pe.minDistFt) g_pe.minDistFt = distFt;
    if (!g_pe.minAngDeg || angDeg < g_pe.minAngDeg) g_pe.minAngDeg = angDeg;
    g_pe.lastDistFt = distFt; g_pe.lastAngDeg = angDeg;
    if (memory_readable((const void*)(rec.tgt + layout::kActorPos), 12)) {
      for (int i = 0; i < 3; ++i) g_pe.tgtPos[i] = *(const float*)(rec.tgt + layout::kActorPos + 4 * i);
      g_pe.tgtQ = now;
    }
  }
  if (rec.tgt != g_pe.lastTgt) {
    if (g_pe.lastTgt) pke_easy_log_ev(rec.tgt ? "target changed" : "target lost", rec, self, distFt, angDeg);
    else if (rec.tgt) pke_easy_log_ev("target locked", rec, self, distFt, angDeg);
    if (rec.tgt) g_pe.tgtSinceQ = now;
    g_pe.lastTgt = rec.tgt;
    InterlockedIncrement(&g_pe.tgtChanges);
  }
  // 1.6 why the game would (not) scan this frame, and what the target is (the old "scan started" flag at +0x67C is never set by the game: that detector was blind)
  {
    const uint8_t* owner = (const uint8_t*)*(const uintptr_t*)(self + layout::kOffPkeOwner);
    int ownerState = 0;
    if (owner && memory_readable(owner + layout::kOffPlayerState, 4)) ownerState = *(const int*)(owner + layout::kOffPlayerState);
    const int equipped = rec.state != 0;
    if (equipped) { InterlockedIncrement(&g_pe.ownerState[ownerState < 0 ? 0 : (ownerState > 7 ? 7 : ownerState)]); if (ownerState != 0) InterlockedIncrement(&g_pe.ownerBusy); }
    const int hasT = rec.tgt != 0 && rec.idx == 0;
    int scannable = 1, blocked = 0, scanned = 0; uintptr_t type = 0; float prog = -1.0f;
    if (hasT) {
      int a = 0, b = 0, d = 0;
      if (pke_tgt_bool(rec.tgt, layout::kVtTargetScannable, &a)) scannable = a;
      if (pke_tgt_bool(rec.tgt, layout::kVtTargetBlocked, &b)) blocked = b;
      if (pke_tgt_bool(rec.tgt, layout::kVtTargetScanned, &d)) scanned = d;
      pke_tgt_float(rec.tgt, layout::kVtTargetProgress, &prog);
      type = pke_tgt_type(rec.tgt);
    }
    const double R = pkeasy::game_range_ft(c);
    pkeasy::WhyIn w;
    w.equipped = equipped; w.ownerState = ownerState; w.hasTarget = hasT; w.cooldown = (double)rec.cooldown; w.scannable = scannable; w.blocked = blocked; w.visible = rec.vis != 0;
    w.dist2 = (double)rec.dist2; w.range2 = c.easy ? (R * R > (double)rec.near2 ? R * R : (double)rec.near2) : (double)rec.near2;
    w.align = (double)rec.align; w.coneCos = pkeasy::cone_cos(pkeasy::game_cone_deg(c));
    const int why = equipped ? pkeasy::why_not(w) : pkeasy::kWhyNotEquipped;
    if (equipped && (hasT || ownerState != 0)) { InterlockedIncrement(&g_pe.why[why]); if (g_pe.inputPre) InterlockedIncrement(&g_pe.whyHeld[why]); }
    if (hasT && type) {
      const int k = pke_type_slot(type);
      if (k >= 0) { InterlockedIncrement(&g_pe.types[k].seen); if (scannable) InterlockedIncrement(&g_pe.types[k].scannable); if (blocked) InterlockedIncrement(&g_pe.types[k].blocked); if (scanned) InterlockedIncrement(&g_pe.types[k].scanned); }
    }
    // a line whenever the reason has been the same for 6 updates and differs from the last stable one (the first 150)
    const int cand = equipped ? (hasT || ownerState != 0 ? why : -1) : -2;
    if (cand == g_pe.whyCand) { if (g_pe.whyCandN < 1000) ++g_pe.whyCandN; } else { g_pe.whyCand = cand; g_pe.whyCandN = 1; }
    if (g_pe.whyCandN == 6 && cand != g_pe.whyStable) {
      g_pe.whyStable = cand;
      if (cand >= 0 && InterlockedIncrement(&g_pe.whyLogged) <= 150)
        log_line("PKEWHY now: %s | target %p class %x scannable=%d blocked=%d already scanned=%d progress %.2f | %.1f ft (range in force %.0f), %.1f deg off the line (cone in force %.0f), line clear=%d, cooldown %.2f s | button held=%d | player state %d",
                 pkeasy::why_name(cand), (void*)rec.tgt, (unsigned)type, scannable, blocked, scanned, (double)prog, distFt, vm::dsqrt(w.range2), angDeg, pkeasy::game_cone_deg(c), rec.vis, (double)rec.cooldown, g_pe.inputPre, ownerState);
    }
  }
  // the scan is "running" for the rumble while the last ping is less than 2 s old (the cooldown)
  const int scanning = g_pe.lastPingQ && (double)(now - g_pe.lastPingQ) / freq < 2.0 && has;
  g_pe.prevScanning = scanning;
  // feedback: a faint tick when a ghost comes into the window, a rumble that grows with the scan bar
  if (inW && !g_pe.prevInWindow) haptics_add(1, hap::kSrcScan, 0.30f, 35);
  g_pe.prevInWindow = inW;
  const double rum = pkeasy::scan_rumble(scanning, (double)rec.bar, inW);
  if (rum > 0.0) { haptics_add(1, hap::kSrcScan, (float)rum, 70); InterlockedIncrement(&g_pe.haptic); }
  g_pe.lastBar = rec.bar;
  // a short line every 3 s while a target is locked, so the log shows what the scan was doing (first 40)
  if (has && (!g_pe.lastTickQ || (double)(now - g_pe.lastTickQ) / freq >= 3.0)) {
    g_pe.lastTickQ = now;
    if (InterlockedIncrement(&g_pe.ticks) <= 40) pke_easy_log_ev("locked", rec, self, distFt, angDeg);
  }
  (void)dt;
}

// the goggle frame: "mov eax,[rdi+0x448]" before the second full-screen quad of the overlay draw becomes "xor eax,eax; nop" (the quad is skipped)
void engine_goggle_apply() {
  if (g_pe.gogState < 0) return;
  uint8_t* p = (uint8_t*)rva(layout::kRvaGoggleStateRead);
  if (g_pe.gogState == 0) {
    if (!bytes_match(layout::kRvaGoggleStateRead, layout::kBytesGoggleStateRead, 16)) { g_pe.gogState = -1; log_line("GOGGLES the game's overlay code differs from the expected bytes: the green frame stays as the game draws it"); return; }
    for (int i = 0; i < 6; ++i) g_pe.gogOrig[i] = p[i];
    g_pe.gogState = 1;
  }
  const int hide = g_ctl.pkeFrame ? 0 : 1;
  if (hide == g_pe.gogPatched) return;
  DWORD old = 0;
  if (!VirtualProtect(p, 6, PAGE_EXECUTE_READWRITE, &old)) { g_pe.gogState = -1; log_line("GOGGLES the game's code could not be made writable (%lu): the green frame stays", (unsigned long)GetLastError()); return; }
  if (hide) { p[0] = 0x31; p[1] = 0xC0; p[2] = 0x90; p[3] = 0x90; p[4] = 0x90; p[5] = 0x90; }
  else for (int i = 0; i < 6; ++i) p[i] = g_pe.gogOrig[i];
  FlushInstructionCache(GetCurrentProcess(), p, 6);
  VirtualProtect(p, 6, old, &old);
  g_pe.gogPatched = hide;
  if (hide) InterlockedIncrement(&g_pe.gogApplied); else InterlockedIncrement(&g_pe.gogRestored);
  log_line("GOGGLES the game's green PKE goggle frame is now %s (a 6-byte change at game address %x, made on the render thread between two overlay draws)", hide ? "HIDDEN" : "shown as the game draws it", layout::kRvaGoggleStateRead);
}

static int pke_easy_target(float* out3, int maxAgeMs) {
  if (!g_pe.tgtQ || !aim::is_fresh(qpc_now(), g_pe.tgtQ, qpc_freq(), maxAgeMs)) return 0;
  for (int i = 0; i < 3; ++i) out3[i] = g_pe.tgtPos[i];
  return 1;
}

static void pke_easy_report(LONG frame) {
  log_line("PKECLOSE frame=%d help=%d | the wider close-range cone was in force for %ld updates in %ld stretches; closest scannable thing seen %.1f ft from the meter, widest cone %.1f deg, cone now %.1f deg (setting %d deg)",
           (int)frame, (int)g_ctl.pkeCloseHelp, (long)g_pc.frames, (long)g_pc.starts, g_pc.minFt, g_pc.maxDeg, g_pc.lastDeg, (int)g_ctl.pkeConeDeg);
  log_line("PKEEASY frame=%d easy=%d auto=%d help=%d range=%dft cone=%ddeg | game cone value %s (own %.4f) writes=%ld | updates=%ld withTarget=%ld inWindow=%ld (a ghost locked inside the widened limits) lineBlocked=%ld cooldownBlocked=%ld | "
           "scan_ok calls=%ld saved by the wider range=%ld | the game's own input byte seen set=%ld, set by the probe (auto)=%ld | closest ghost seen %.1f ft, best aim %.1f deg off | "
           "last: %.1f ft, %.1f deg | rumble ticks=%ld | goggle frame %s (state %d, hidden %ld times, restored %ld)",
           (int)frame, (int)g_ctl.pkeEasy, (int)g_ctl.pkeAuto, (int)g_ctl.pkeScanHelp, (int)g_ctl.pkeEasyFt, (int)g_ctl.pkeConeDeg, g_pe.thrState > 0 ? "found" : (g_pe.thrState < 0 ? "NOT usable" : "not looked at yet"), g_pe.thrState > 0 ? (double)*g_pe.thr : 0.0, g_pe.thrWrites,
           g_pe.updates, g_pe.withTarget, g_pe.inWindow, g_pe.visBlocked, g_pe.cooldownBlocked, g_pe.scanOkCalls, g_pe.scanOkSaved, g_pe.rawInput, g_pe.autoInput,
           g_pe.minDistFt, g_pe.minAngDeg, g_pe.lastDistFt, g_pe.lastAngDeg, g_pe.haptic,
           g_pe.gogPatched ? "HIDDEN" : "shown", g_pe.gogState, g_pe.gogApplied, g_pe.gogRestored);
  // 1.6 the real scan
  log_line("PKESCAN frame=%d trigger_scan=%d auto_scan=%d | the right trigger was pressed with the PKE out %ld times (%ld updates held, the probe set the game's scan input %ld times) | what the game said while the button was held: %s", (int)frame, (int)g_ctl.pkeTrigScan, (int)g_ctl.pkeAuto, (long)g_manScan.manualFresh, (long)g_manScan.manualFrames, (long)g_manScan.manualInput, "see PKEWHY (second line)");
  log_line("PKEPING frame=%d scan help=%d | pings=%ld (cancel calls %ld) | pings that ADDED progress=%ld, pings that added NOTHING=%ld | scans FINISHED=%ld | rate asked %ld times: the game's level none(0)=%ld quarter=%ld half=%ld full=%ld, raised by the floor=%ld (one ping per 2 s while the button is held and the game says yes)",
           (int)frame, (int)g_ctl.pkeScanHelp, g_pe.pings, g_pe.pingsCancel, g_pe.pingsAdded, g_pe.pingsNothing, g_pe.scansDone, g_pe.rateCalls, g_pe.rateLevel[0], g_pe.rateLevel[3], g_pe.rateLevel[2], g_pe.rateLevel[1], g_pe.rateRaised);
  {
    char a[640], b[640]; int la = 0, lb = 0;
    for (int i = 0; i < pkeasy::kWhyCount; ++i) {
      la += wsprintfA(a + la, "%s%s=%ld", i ? ", " : "", pkeasy::why_name(i), (long)g_pe.why[i]);
      lb += wsprintfA(b + lb, "%s%s=%ld", i ? ", " : "", pkeasy::why_name(i), (long)g_pe.whyHeld[i]);
    }
    log_line("PKEWHY frame=%d updates by the first reason the game would say no (only updates with a target, or a busy player): %s", (int)frame, a);
    log_line("PKEWHY frame=%d the same, only while the scan button was held (or auto-held): %s", (int)frame, b);
    log_line("PKEOWNER frame=%d player state while the PKE was out (0 = free; the PKE does nothing otherwise): 0=%ld 1=%ld 2=%ld 3=%ld 4=%ld 5=%ld 6=%ld 7+=%ld, busy updates=%ld", (int)frame,
             g_pe.ownerState[0], g_pe.ownerState[1], g_pe.ownerState[2], g_pe.ownerState[3], g_pe.ownerState[4], g_pe.ownerState[5], g_pe.ownerState[6], g_pe.ownerState[7], g_pe.ownerBusy);
  }
  for (LONG i = 0; i < g_pe.typesN && i < 12; ++i)
    log_line("PKETYPE frame=%d class %x: locked on it %ld updates, scannable in %ld, blocked in %ld, already scanned in %ld, pings %ld, scans finished %ld", (int)frame, (unsigned)g_pe.types[i].vt, g_pe.types[i].seen, g_pe.types[i].scannable, g_pe.types[i].blocked, g_pe.types[i].scanned, g_pe.types[i].pings, g_pe.types[i].done);
}

static void* __fastcall hk_pke_collect(void* self, void* ctx) {
  InterlockedIncrement(&g_pk.collects);
  crumb("pke:collect", 0);
  if (self) pke_place((uint8_t*)self, 1);
  void* r = o_pkeCollect(self, ctx);
  // The game may rebuild/update the meter inside collect. Reapply the exact
  // hand pose AFTER it too so draw/holster transitions cannot win the frame.
  if (self) pke_place((uint8_t*)self, 6);
  return r;
}
static void __fastcall hk_pke_update(void* self, float dt) {
  InterlockedIncrement(&g_pk.updates);
  crumb("pke:update", 0);
  const int placedPre = self ? pke_place((uint8_t*)self, 2) : 0;
  if (placedPre) pke_easy_pre((uint8_t*)self);
  o_pkeUpdate(self, dt);
  // Critical 1.7.62 order: the original update can overwrite the entity pose.
  // Reapply after it, otherwise the PKE can look frozen or jump back to animation.
  const int placedPost = self ? pke_place((uint8_t*)self, 5) : 0;
  if (placedPre || placedPost) { pke_scan_note((uint8_t*)self); pke_src_note(); pke_auto_picture(); pke_easy_post((uint8_t*)self, dt); }
}
// The scan ray starts at the PKE's "tip": the entity attach getter multiplies the model's local attachment with the entity matrix. With the entity moved to the controller (0.97) the tip is right as it comes;
// when it is asked while the entity still holds the game's own placement (between the player's update and the meter's), the attachment is carried over to the placed pose instead:
// tip = (attachment x entity^-1) x placed pose. Either way the tip in the model's own axes is noted (it tells which axis is the model's front).
static int tether_carry(void* self, float* out);   // 1.7.72
static unsigned char __fastcall hk_entity_attach(void* self, const char* name, float* out) {
  const unsigned char r = o_entAttach(self, name, out);
  if (r && out && g_slimeTether && (uintptr_t)self == g_slimeTether) { tether_carry(self, out); return r; }   // 1.7.72: the slime blower's "slime" attachment
  if (!r || !out || !name || (uintptr_t)self != g_pk.self || !g_pk.placedQ) return r;
  if (!memory_readable_any(name, 4) || name[0] != 't' || name[1] != 'i' || name[2] != 'p' || name[3] != 0) return r;
  if (!aim::is_fresh(qpc_now(), g_pk.placedQ, qpc_freq(), 120) || !memory_readable(out, 64) || !memory_readable((const uint8_t*)self + layout::kOffEntityRot, 36)) return r;
  InterlockedIncrement(&g_pk.tipSeen);
  const float* e = (const float*)((const uint8_t*)self + layout::kOffEntityRot);
  const float* ep = (const float*)((const uint8_t*)self + layout::kActorPos);
  double E[9], P3[9], Pp[3] = {g_pk.newM[12], g_pk.newM[13], g_pk.newM[14]}, Ep[3] = {ep[0], ep[1], ep[2]};
  for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) { E[j * 3 + i] = e[3 * i + j]; P3[j * 3 + i] = g_pk.newM[j * 4 + i]; }
  // inverse of the entity's 3x3 (rows are axes)
  const double det = E[0] * (E[4] * E[8] - E[5] * E[7]) - E[1] * (E[3] * E[8] - E[5] * E[6]) + E[2] * (E[3] * E[7] - E[4] * E[6]);
  if (!(vm::dabs(det) > 1e-8)) return r;
  const double id = 1.0 / det;
  const double Ei[9] = {(E[4] * E[8] - E[5] * E[7]) * id, (E[2] * E[7] - E[1] * E[8]) * id, (E[1] * E[5] - E[2] * E[4]) * id,
                        (E[5] * E[6] - E[3] * E[8]) * id, (E[0] * E[8] - E[2] * E[6]) * id, (E[2] * E[3] - E[0] * E[5]) * id,
                        (E[3] * E[7] - E[4] * E[6]) * id, (E[1] * E[6] - E[0] * E[7]) * id, (E[0] * E[4] - E[1] * E[3]) * id};
  // local attachment: A = out x E^-1  (3x3 part), translation Al = (out.pos - E.pos) x E^-1
  double A[9], Al[3], d[3] = {out[12] - Ep[0], out[13] - Ep[1], out[14] - Ep[2]};
  for (int r3 = 0; r3 < 3; ++r3) for (int c3 = 0; c3 < 3; ++c3) A[r3 * 3 + c3] = out[r3 * 4] * Ei[c3] + out[r3 * 4 + 1] * Ei[3 + c3] + out[r3 * 4 + 2] * Ei[6 + c3];
  for (int c3 = 0; c3 < 3; ++c3) Al[c3] = d[0] * Ei[c3] + d[1] * Ei[3 + c3] + d[2] * Ei[6 + c3];
  if (vm::is_finite_f((float)Al[0]) && vm::is_finite_f((float)Al[1]) && vm::is_finite_f((float)Al[2])) {
    for (int i = 0; i < 3; ++i) g_pk.tipLocal[i] = (float)Al[i];
    InterlockedIncrement(&g_pk.tipLocalN);
  }
  if (g_ctl.pkeEntity && ep[0] == g_pk.wPos[0] && ep[1] == g_pk.wPos[1] && ep[2] == g_pk.wPos[2]) {   // the entity IS the placed pose: the game's tip is already right
    const LONG n0 = InterlockedIncrement(&g_pk.tipOnEntity);
    if (n0 <= 4 || (n0 % 900) == 0) log_line("PKETIP #%ld (entity at the controller) the PKE's tip (the scan ray's start) is at %.1f,%.1f,%.1f ft, the meter at %.1f,%.1f,%.1f; the tip in the model's own axes: %.2f,%.2f,%.2f ft (the front is the axis with the biggest number)",
                                             n0, (double)out[12], (double)out[13], (double)out[14], Pp[0], Pp[1], Pp[2], Al[0], Al[1], Al[2]);
    return r;
  }
  float res[16];
  for (int i = 0; i < 16; ++i) res[i] = out[i];
  for (int r3 = 0; r3 < 3; ++r3) for (int c3 = 0; c3 < 3; ++c3) res[r3 * 4 + c3] = (float)(A[r3 * 3] * P3[c3] + A[r3 * 3 + 1] * P3[3 + c3] + A[r3 * 3 + 2] * P3[6 + c3]);
  for (int c3 = 0; c3 < 3; ++c3) res[12 + c3] = (float)(Al[0] * P3[c3] + Al[1] * P3[3 + c3] + Al[2] * P3[6 + c3] + Pp[c3]);
  for (int i = 0; i < 16; ++i) if (!vm::is_finite_f(res[i])) return r;
  const LONG n = InterlockedIncrement(&g_pk.tipFixed);
  if (n <= 6 || (n % 900) == 0) log_line("PKETIP #%ld the PKE's tip (the scan ray's start) was at %.1f,%.1f,%.1f ft, now %.1f,%.1f,%.1f (controller grip %.1f,%.1f,%.1f); the tip in the model's own axes: %.2f,%.2f,%.2f ft (the front is the axis with the biggest number); entity matrix position %.1f,%.1f,%.1f",
                                         n, (double)out[12], (double)out[13], (double)out[14], (double)res[12], (double)res[13], (double)res[14], Pp[0], Pp[1], Pp[2], Al[0], Al[1], Al[2], Ep[0], Ep[1], Ep[2]);
  for (int i = 0; i < 16; ++i) out[i] = res[i];
  return r;
}

static void install_pke_hooks() {
  const int a = bytes_match(layout::kRvaPkeCollect, layout::kBytesPkeCollect, 16);
  const int b = bytes_match(layout::kRvaPkeUpdate, layout::kBytesPkeUpdate, 16);
  const int c = bytes_match(layout::kRvaEntityAttachWorld, layout::kBytesEntityAttachWorld, 16);
  const int so = bytes_match(layout::kRvaPkeScanOk, layout::kBytesPkeScanOk, 16);   // 1.4
  const uint8_t* vt = (const uint8_t*)rva(layout::kRvaPkeMeterVtable);
  const int v = memory_readable(vt, 0xF0) && *(const uintptr_t*)(vt + 0x80) == rva(layout::kRvaPkeUpdate) && *(const uintptr_t*)(vt + 0xE8) == rva(layout::kRvaPkeCollect);
  if (!a || !b || !c || !v) {
    g_pkeHook = -1;
    log_line("PKEGAME not available (collect bytes=%d update bytes=%d attach bytes=%d vtable=%d): the game's PKE stays where the game animates it", a, b, c, v);
    return;
  }
  void* t0 = (void*)rva(layout::kRvaPkeCollect); void* t1 = (void*)rva(layout::kRvaPkeUpdate); void* t2 = (void*)rva(layout::kRvaEntityAttachWorld);
  MH_STATUS s0 = MH_CreateHook(t0, (void*)hk_pke_collect, (void**)&o_pkeCollect);
  MH_STATUS s1 = s0 == MH_OK ? MH_CreateHook(t1, (void*)hk_pke_update, (void**)&o_pkeUpdate) : s0;
  MH_STATUS s2 = s1 == MH_OK ? MH_CreateHook(t2, (void*)hk_entity_attach, (void**)&o_entAttach) : s1;
  if (s2 == MH_OK) s2 = MH_EnableHook(t0);
  if (s2 == MH_OK) s2 = MH_EnableHook(t1);
  if (s2 == MH_OK) s2 = MH_EnableHook(t2);
  if (s2 == MH_OK) {   // 1.4: scan_ok (a failure here only costs the wider range, the rest of the PKE work stays)
    void* t3 = (void*)rva(layout::kRvaPkeScanOk);
    MH_STATUS s3 = so ? MH_CreateHook(t3, (void*)hk_pke_scan_ok, (void**)&o_pkeScanOk) : MH_ERROR_NOT_CREATED;
    if (s3 == MH_OK) s3 = MH_EnableHook(t3);
    log_line("HOOK PKE scan_ok %x status=%d bytes=%d: %s", layout::kRvaPkeScanOk, (int)s3, so, s3 == MH_OK ? "the scan range can be widened (1.4 easy scan)" : "the game's own 15 ft range stays (the wider cone and the auto-start still work)");
    {   // 1.6: the scan ping and its rate (a failure here only costs the floor and the ping log)
      const int bp = bytes_match(layout::kRvaPkeScanPulse, layout::kBytesPkeScanPulse, 16), br = bytes_match(layout::kRvaPkeScanRate, layout::kBytesPkeScanRate, 16);
      void* t4 = (void*)rva(layout::kRvaPkeScanPulse); void* t5 = (void*)rva(layout::kRvaPkeScanRate);
      MH_STATUS s4 = bp ? MH_CreateHook(t4, (void*)hk_pke_ping, (void**)&o_pkePing) : MH_ERROR_NOT_CREATED;
      if (s4 == MH_OK) s4 = MH_EnableHook(t4);
      MH_STATUS s5 = br ? MH_CreateHook(t5, (void*)hk_pke_rate, (void**)&o_pkeRate) : MH_ERROR_NOT_CREATED;
      if (s5 == MH_OK) s5 = MH_EnableHook(t5);
      log_line("HOOK PKE scan ping %x status=%d bytes=%d / ping rate %x status=%d bytes=%d: %s", layout::kRvaPkeScanPulse, (int)s4, bp, layout::kRvaPkeScanRate, (int)s5, br,
               (s4 == MH_OK && s5 == MH_OK) ? "every ping is logged and never adds less than half a scan (1.6 scan help)" : "the ping log / rate floor are partly missing");
    }
  }
  g_pkeHook = s2 == MH_OK ? 1 : -2;
  log_line("HOOK PKE collect %x / update %x / attach %x status=%d: the game's own PKE meter %s (entity matrix move %s)", layout::kRvaPkeCollect, layout::kRvaPkeUpdate, layout::kRvaEntityAttachWorld, (int)s2, g_pkeHook == 1 ? "moves to your right controller while it is the item in hand" : "stays in the animation", g_ctl.pkeEntity ? "on" : "off");
}

static void pke_report(LONG frame) {
  pke_easy_report(frame);
  rig_event_report(frame);
  cine_report(frame);
  follow_report(frame);
  log_line("PKEGAME frame=%d on=%d entity=%d hooks=%d draws=%ld scans=%ld placed=%ld notHeld=%ld notPlayer=%ld noAim=%ld bad=%ld disabled=%ld busy=%ld swung=%ld rollFixed=%ld tipSeen=%ld tipFixed=%ld tipOnEntity=%ld entMoved=%ld gameSeen=%ld oursSeen=%ld entNoRead=%ld movedFt(min/max)=%.2f/%.2f front/up=%d%s/%d%s lastDots=%.2f,%.2f,%.2f lastSwing=%.1fdeg lastRoll=%.1fdeg gamePos=%.1f,%.1f,%.1f newPos=%.1f,%.1f,%.1f entityPos=%.1f,%.1f,%.1f",
           (int)frame, (int)g_ctl.pkeGame, (int)g_ctl.pkeEntity, g_pkeHook, g_pk.collects, g_pk.updates, g_pk.placed, g_pk.notHeld, g_pk.notPlayer, g_pk.noAim, g_pk.bad, g_pk.disabled, g_pk.busy, g_pk.swung, g_pk.rollFixed, g_pk.tipSeen, g_pk.tipFixed, g_pk.tipOnEntity,
           g_pk.entMoved, g_pk.entGameSeen, g_pk.entOursSeen, g_pk.entNoRead, 0.01 * (double)g_pk.minMovedX100, 0.01 * (double)g_pk.maxMovedX100, g_pk.frame.front, g_pk.frame.fsign < 0 ? "-" : "+", g_pk.frame.up, g_pk.frame.usign < 0 ? "-" : "+",
           (double)g_pk.lastDot[0], (double)g_pk.lastDot[1], (double)g_pk.lastDot[2], (double)g_pk.lastSwing, (double)g_pk.lastRoll,
           (double)g_pk.lastGame[0], (double)g_pk.lastGame[1], (double)g_pk.lastGame[2], (double)g_pk.lastNew[0], (double)g_pk.lastNew[1], (double)g_pk.lastNew[2], (double)g_pk.lastEnt[0], (double)g_pk.lastEnt[1], (double)g_pk.lastEnt[2]);
  log_line("PKESHIFT frame=%d pairCache=%d share=%d%% hand slide used: fresh calibration samples=%ld held=%ld none=%ld, mean %.1f cm, max %.1f cm",
           (int)frame, (int)g_ctl.pkePairCache, (int)g_ctl.pkeShiftPct, g_pk.shiftFresh, g_pk.shiftHeld, g_pk.shiftNone,
           g_pk.shiftN > 0 ? g_pk.shiftSumCm / (double)g_pk.shiftN : 0.0, 0.01 * (double)g_pk.shiftMaxX100);
  log_line("PKEHAND frame=%d exact/fallback=%ld/%ld scan(frames/starts/targetsSeen)=%ld/%ld/%ld shots=%ld (hand is authoritative; PKE follows the game hand relation)",
           (int)frame, g_pk.exactUsed, g_pk.exactFallback, g_pk.scanFrames, g_pk.scanStarts, g_pk.scanTargetsSeen, g_pk.shots);
}

// 1.6 the steadiness of the weapons in the hand: the game's hand-to-weapon offset against the steady (rigid) one the probe uses
static void rigid_report(LONG frame) {
  const double ft2cm = 30.48;
  const double pkeLockFt = vm::dsqrt(g_pk.gripLock.local[0] * g_pk.gripLock.local[0] + g_pk.gripLock.local[1] * g_pk.gripLock.local[1] + g_pk.gripLock.local[2] * g_pk.gripLock.local[2]);
  const double pkeRigidFt = vm::dsqrt(g_pk.rigid.loc[0] * g_pk.rigid.loc[0] + g_pk.rigid.loc[1] * g_pk.rigid.loc[1] + g_pk.rigid.loc[2] * g_pk.rigid.loc[2]);
  log_line("RIGID frame=%d gun_rigid=%d pke_rigid=%d | GUN: slide in use %.1f cm, the game's offset strayed from the steady one by %.1f cm on average and %.1f cm at most, polls without a fresh value=%ld | "
           "PKE: slide in use %.1f cm (grip calibrated=%d, fresh=%ld held=%ld none=%ld), rigid-mode offset variation %.1f/%.1f cm mean/max, share %d%% (the steady slide is kept in the weapon's own axes)",
           (int)frame, (int)g_ctl.gunRigid, (int)g_ctl.pkeRigid, 0.01 * (double)g_wandSt.rigidUsedX100, 0.01 * (double)g_wandSt.rigidDevMeanX100, 0.01 * (double)g_wandSt.rigidDevMaxX100, g_wandSt.rigidHeld,
           (g_ctl.handLock ? (g_pk.gripLock.have ? pkeLockFt : 0.0) : pkeRigidFt) * ft2cm * (double)g_ctl.pkeShiftPct / 100.0,
           g_pk.gripLock.have, g_pk.shiftFresh, g_pk.shiftHeld, g_pk.shiftNone,
           g_pk.rigid.n ? g_pk.rigid.devSum / (double)g_pk.rigid.n * ft2cm : 0.0, g_pk.rigid.devMax * ft2cm, (int)g_ctl.pkeShiftPct);
}
// 1.7.2 HOLDCHECK: how far the weapon's origin sits from the drawn right wrist and from the controller point, along the weapon's aim and across it (cm), next to the game's own
// hand-to-weapon offset, the slide in use and the fit. The handle should be in the fist: if the weapon floats, these numbers say by how much and in which direction.
static void holdcheck_line(const char* why, const char* what, const float* org, const float* aim, double slideFt, int fitFwd) {
  const double cm = 30.48;
  float wr[3], ms[3], ao[3];
  if (!org || !aim) { log_line("HOLDCHECK (%s) %s: nothing placed just now", why ? why : "?", what); return; }
  if (!arms_hold_numbers(wr, ms, ao)) { log_line("HOLDCHECK (%s) %s: the arm has no fresh numbers (no hand pass in the last moment)", why ? why : "?", what); return; }
  double u[3] = {aim[0], aim[1], aim[2]};
  const double ul = vm::dsqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]);
  if (!(ul > 1e-6)) return;
  for (int i = 0; i < 3; ++i) u[i] /= ul;
  double dh[3], dc[3];
  for (int i = 0; i < 3; ++i) { dh[i] = (double)org[i] - ((double)wr[i] - (double)ms[i]); dc[i] = (double)org[i] - (double)wr[i]; }
  const double th = vm::dsqrt(dh[0] * dh[0] + dh[1] * dh[1] + dh[2] * dh[2]), tc = vm::dsqrt(dc[0] * dc[0] + dc[1] * dc[1] + dc[2] * dc[2]);
  const double ah = dh[0] * u[0] + dh[1] * u[1] + dh[2] * u[2], ac = dc[0] * u[0] + dc[1] * u[1] + dc[2] * u[2];
  const double sh = th * th > ah * ah ? vm::dsqrt(th * th - ah * ah) : 0.0, sc = tc * tc > ac * ac ? vm::dsqrt(tc * tc - ac * ac) : 0.0;
  const double mm = vm::dsqrt((double)ms[0] * ms[0] + (double)ms[1] * ms[1] + (double)ms[2] * ms[2]);
  const double go = vm::dsqrt((double)ao[0] * ao[0] + (double)ao[1] * ao[1] + (double)ao[2] * ao[2]);
  log_line("HOLDCHECK (%s) %s: weapon origin is %.1f cm from the DRAWN wrist (%.1f cm along its aim, %.1f cm across) and %.1f cm from the CONTROLLER point (%.1f along, %.1f across); "
           "the game's own hand-to-weapon offset is %.1f cm, slide in use %.1f cm, wrist fell short of the controller by %.1f cm, fit forward/back %d cm. "
           "(By design the origin sits about the game's offset away from the wrist, so the handle is in the fist; a big gap between the two means the weapon floats.)",
           why ? why : "?", what, th * cm, ah * cm, sh * cm, tc * cm, ac * cm, sc * cm, go * cm, slideFt * cm, mm * cm, fitFwd);
}
// at fixed seconds after the weapon came into the hand (and again after it was away for 3 s): shows whether the spot is right at the start and what it does over the first 12 seconds
static void holdcheck_timeline(int what, const float* org, const float* aim, double slideFt, int fitFwd) {
  if (!g_ctl.probeData) return;
  static const double kAt[7] = {0.3, 1.0, 2.0, 3.0, 5.0, 8.0, 12.0};
  struct Tl { int64_t start, last; int next; };
  static Tl tl[2];
  Tl& t = tl[what ? 1 : 0];
  const int64_t now = qpc_now(); const double f = (double)qpc_freq();
  if (!t.last || (double)(now - t.last) / f > 3.0) { t.start = now; t.next = 0; }
  t.last = now;
  const double el = (double)(now - t.start) / f;
  if (t.next < 7 && el >= kAt[t.next]) {
    char w[40]; wsprintfA(w, "%s +%d.%d s after it came into the hand", what ? "PKE" : "gun", (int)kAt[t.next], (int)(kAt[t.next] * 10.0) % 10);
    holdcheck_line("timeline", w, org, aim, slideFt, fitFwd);
    ++t.next;
  }
}
// what the weapon in the hand looks like right now (F2 / periodic)
static void holdcheck_now(const char* why) {
  const int64_t now = qpc_now(); const double f = (double)qpc_freq();
  int any = 0;
  if (g_gunPlacedAt && (double)(now - g_gunPlacedAt) / f < 0.3) {
    float org[3] = {g_gunPlaced[0], g_gunPlaced[1], g_gunPlaced[2]}, dr[3] = {g_gunPlacedDir[0], g_gunPlacedDir[1], g_gunPlacedDir[2]};
    const double sl = vm::dsqrt((double)g_gunRigidLast[0] * g_gunRigidLast[0] + (double)g_gunRigidLast[1] * g_gunRigidLast[1] + (double)g_gunRigidLast[2] * g_gunRigidLast[2]);
    holdcheck_line(why, "gun", org, dr, sl, (int)g_ctl.gunFwdCm); any = 1;
  }
  if (pke_item_held() && g_pk.placedQ && (double)(now - g_pk.placedQ) / f < 0.3) {
    float org[3] = {g_pk.newM[12], g_pk.newM[13], g_pk.newM[14]}, dr[3] = {g_pk.lastDir[0], g_pk.lastDir[1], g_pk.lastDir[2]};
    const double sl = vm::dsqrt(g_pk.rigid.loc[0] * g_pk.rigid.loc[0] + g_pk.rigid.loc[1] * g_pk.rigid.loc[1] + g_pk.rigid.loc[2] * g_pk.rigid.loc[2]);
    holdcheck_line(why, "PKE", org, dr, sl, (int)g_ctl.pkeFwdCm); any = 1;
  }
  if (!any) log_line("HOLDCHECK (%s) no gun or PKE was placed in the last moment (holstered, or neither in hand)", why ? why : "?");
}
// 1.7.1: the hands at this moment: are the fingers closed around the weapon (animation -> drawn degrees), the controller buttons, the settings
// 1.7.3: where the PKE points (game world, unit direction) and where the controller point is (game feet): 1 = fresh. The collectible reveal uses it.
int engine_pke_aim(float dir[3], float grip[3]) {
  uintptr_t a = 0; int64_t q = 0;
  if (!wand_aim_read(&a, dir, grip, &q) || !a) return 0;
  return aim::is_fresh(qpc_now(), q, qpc_freq(), 250) ? 1 : 0;
}
static void float_hands_line(const char* why) {
    char fb[700];
    arms_finger_text(fb, (int)sizeof(fb));
    HandsRaw hr; const int haveHands = controllers_raw(&hr);
    log_line("FLOATHANDS (%s) fingers on the weapon: %s | gun_wrap_pct=%d, controller grip right/left=%d/%d, trigger right/left=%.2f/%.2f (%s), fit gun %d/%d cm, PKE %d/%d cm",
             why ? why : "?", fb, (int)g_ctl.gunWrapPct, haveHands ? hr.gripR : -1, haveHands ? hr.gripL : -1, haveHands ? (double)hr.trigR : -1.0, haveHands ? (double)hr.trigL : -1.0,
             haveHands ? "controllers read" : "controllers NOT read", (int)g_ctl.gunFwdCm, (int)g_ctl.gunUpCm, (int)g_ctl.pkeFwdCm, (int)g_ctl.pkeUpCm);
    holdcheck_now(why);
}
// the picture key (F2) also writes one line with the numbers of that moment: "the gun / PKE floats right now" then has data next to the picture
void engine_float_mark(const char* why) {
  const double ft2cm = 30.48;
  const int64_t now = qpc_now(); const double f = (double)qpc_freq();
  float_hands_line(why);
  log_line("FLOATMARK (%s) the numbers of this moment, next to the picture: GUN slide %.1f cm (%.1f,%.1f,%.1f ft), last used %.2f s ago, game offset strayed %.1f cm on average / %.1f cm at most | PKE slide held=%d (%.1f cm), strayed %.1f cm on average / %.1f cm at most, last placed %.2f s ago | PKE in hand=%d",
           why ? why : "?", 0.01 * (double)g_wandSt.rigidUsedX100, (double)g_gunRigidLast[0], (double)g_gunRigidLast[1], (double)g_gunRigidLast[2], g_gunRigidAt ? (double)(now - g_gunRigidAt) / f : -1.0,
           0.01 * (double)g_wandSt.rigidDevMeanX100, 0.01 * (double)g_wandSt.rigidDevMaxX100, g_pk.rigid.have,
           vm::dsqrt((double)g_pk.rigid.loc[0] * g_pk.rigid.loc[0] + (double)g_pk.rigid.loc[1] * g_pk.rigid.loc[1] + (double)g_pk.rigid.loc[2] * g_pk.rigid.loc[2]) * ft2cm,
           g_pk.rigid.n ? g_pk.rigid.devSum / (double)g_pk.rigid.n * ft2cm : 0.0, g_pk.rigid.devMax * ft2cm, g_pk.placedQ ? (double)(now - g_pk.placedQ) / f : -1.0, pke_item_held());
}

// 1.7.31 START TIMELINE: "the hands are perfect when I first start the game, then 2 seconds later they go bad". The reports are 2 s apart, too coarse to see what changes. For the first 12 s after the player
// appears (3 times at most, new level = new window) one line every 0.25 s: what the gun push did, how far the gun is from the game's spot, how far each controller is from the head, body-follow counters, the item in hand.
static struct StartTl { uintptr_t actor; int64_t t0, nextQ; int windows, lines; LONG p[8]; } g_startTl;
static void starttl_sample(uintptr_t actor, const ArmStereo& st) {
  if (st.pairRole == 2) return;
  const int64_t now = qpc_now(); const double f = (double)qpc_freq();
  if (actor != g_startTl.actor) {
    g_startTl.actor = actor;
    if (g_startTl.windows >= 3) { g_startTl.t0 = 0; return; }
    ++g_startTl.windows; g_startTl.t0 = now; g_startTl.nextQ = now; g_startTl.lines = 0;
    for (int k = 0; k < 8; ++k) g_startTl.p[k] = 0;
  }
  if (!g_startTl.t0 || now < g_startTl.nextQ) return;
  const double t = (double)(now - g_startTl.t0) / f;
  if (t > 12.0) { g_startTl.t0 = 0; return; }
  g_startTl.nextQ = now + (int64_t)(0.25 * f);
  int sti[8] = {0}, cur = -1; fight_items(sti, &cur);
  HandsRaw hr; const int got = controllers_raw(&hr);
  double dR = -1.0, dL = -1.0;
  if (got) {
    const double hx = st.pose34[3], hy = st.pose34[7], hz = st.pose34[11];
    if (hr.validR) { const double a = hr.poseR[3] - hx, b = hr.poseR[7] - hy, c = hr.poseR[11] - hz; dR = 100.0 * vm::dsqrt(a * a + b * b + c * c); }
    if (hr.validL) { const double a = hr.poseL[3] - hx, b = hr.poseL[7] - hy, c = hr.poseL[11] - hz; dL = 100.0 * vm::dsqrt(a * a + b * b + c * c); }
  }
  const LONG c8[8] = {g_wandSt.hookCalls, g_wandSt.applied, g_wandSt.noAim, g_wandSt.stale, g_wandSt.holstered, g_wandSt.handFit, g_wandSt.glued, g_bodyMv.applied[0]};
  log_line("STARTTL t=%.2fs #%d | per 0.25 s: pushes %d, applied %d, noAim %d, stale %d, holstered %d, handFit %d, glued %d, body moves %d | gun moved from the game's spot %d.%02d ft (grip to tip %d.%02d ft) | controller to head R/L %.0f/%.0f cm | item %d, PKE in hand %d, body offset %d.%02d,%d.%02d ft | armIk=%d pair=%d",
           t, ++g_startTl.lines, (int)(c8[0] - g_startTl.p[0]), (int)(c8[1] - g_startTl.p[1]), (int)(c8[2] - g_startTl.p[2]), (int)(c8[3] - g_startTl.p[3]), (int)(c8[4] - g_startTl.p[4]), (int)(c8[5] - g_startTl.p[5]), (int)(c8[6] - g_startTl.p[6]), (int)(c8[7] - g_startTl.p[7]),
           (int)(g_wandSt.lastShiftX100 / 100), (int)(g_wandSt.lastShiftX100 % 100), (int)(g_wandSt.lastGripTipX100 / 100), (int)(g_wandSt.lastGripTipX100 % 100), dR, dL, cur, pke_item_held(),
           (int)(g_bodyMv.lastDx100 / 100), (int)((g_bodyMv.lastDx100 < 0 ? -g_bodyMv.lastDx100 : g_bodyMv.lastDx100) % 100), (int)(g_bodyMv.lastDz100 / 100), (int)((g_bodyMv.lastDz100 < 0 ? -g_bodyMv.lastDz100 : g_bodyMv.lastDz100) % 100),
           (int)g_ctl.armIk, st.pairRole);
  for (int k = 0; k < 8; ++k) g_startTl.p[k] = c8[k];
}
// 1.7.30 GUNSPAWN: "the gun starts in the hand when I spawn in, then it floats away". One line per report for the first 90 reports (about 3 minutes from the start of the game), with what changed since the last line:
// how many gun pushes were applied / refused (and why), how far the gun was moved from where the game put it, whether the avatar's hand is on the gun, the item in hand, the holster.
static void gunspawn_report(LONG frame) {
  static int s_n;
  static LONG p[10];
  if (s_n >= 90 || !g_wandHook) return;
  ++s_n;
  int gsSt[8] = {0}, gsItemCur = -1;
  fight_items(gsSt, &gsItemCur);
  const LONG cur[10] = {g_wandSt.hookCalls, g_wandSt.calls, g_wandSt.applied, g_wandSt.notMine, g_wandSt.pkeOut, g_wandSt.noAim, g_wandSt.stale, g_wandSt.holstered, g_wandSt.handFit, g_wandSt.glued};
  log_line("GUNSPAWN #%d frame=%d | since the last line: pushes %d, mine %d, applied %d, other busters' wands %d, PKE out %d, no aim %d, stale %d, holstered %d, hand fit %d, glued %d | gun moved from the game's spot by %d.%02d ft now (grip to tip %d.%02d ft), game_place=%d glue=%d grip_at_hand=%d, item in hand %d",
           s_n, (int)frame, (int)(cur[0] - p[0]), (int)(cur[1] - p[1]), (int)(cur[2] - p[2]), (int)(cur[3] - p[3]), (int)(cur[4] - p[4]), (int)(cur[5] - p[5]), (int)(cur[6] - p[6]), (int)(cur[7] - p[7]), (int)(cur[8] - p[8]), (int)(cur[9] - p[9]),
           (int)(g_wandSt.lastShiftX100 / 100), (int)(g_wandSt.lastShiftX100 % 100), (int)(g_wandSt.lastGripTipX100 / 100), (int)(g_wandSt.lastGripTipX100 % 100), (int)g_ctl.gamePlace, (int)g_ctl.gunGlue, (int)g_ctl.gripAtHand, gsItemCur);
  for (int k = 0; k < 10; ++k) p[k] = cur[k];
}

static void wand_report(LONG frame) {
  rigid_report(frame);
  { static LONG s_fh; if ((InterlockedIncrement(&s_fh) % 10) == 1) float_hands_line("periodic"); }   // about every 15 seconds
  log_line("GUNLOST frame=%d bursts=%ld passes=%ld by reason (aim stale/wand unreadable/no solution)=%ld/%ld/%ld pictures=%ld (the gun was out but the avatar's right hand had no target: 0 is what it should be)", (int)frame, g_gunLost.bursts, g_gunLost.total, g_gunLost.reason[3], g_gunLost.reason[4], g_gunLost.reason[5], g_gunLost.shots);
  {   // 0.84: memory headroom while playing (the picture level guard used the value at start-up only)
    MEMORYSTATUSEX ms; ZeroMemory(&ms, sizeof(ms)); ms.dwLength = sizeof(ms);
    if (GlobalMemoryStatusEx(&ms)) log_line("MEM frame=%d commitFreeMB=%u of limit %u, ramFreeMB=%u", (int)frame, (unsigned)(ms.ullAvailPageFile >> 20), (unsigned)(ms.ullTotalPageFile >> 20), (unsigned)(ms.ullAvailPhys >> 20));
  }
  videoguard_report();
  log_line("GLOVES frame=%d on=%d setting=%d noArmsFrames=%d pkeItemHeld=%d (no body or arms: the probe draws plain gloves at the controllers; with the PKE the old arms come back)", (int)frame, engine_glove_mode(), (int)g_ctl.glovesOnly, (int)g_glove.frames, pke_item_held());
  log_line("PKEMODE frame=%d on=%d setting=%d switches=%d armOverridesSkipped=%d wandOverridesSkipped=%d (PKE in hand: body shown, head hidden, the game's animation holds the PKE)", (int)frame, g_pke.last, (int)g_ctl.pkeBody, (int)g_pke.switches, (int)g_pke.armSkips, (int)g_pke.wandSkips);
  log_line("PKEATTACH frame=%d setting=%d fingers=%d gunHiddenFrames=%d (the PKE meter is placed on the hand from the game's own hold pose: frames placed so far)", (int)frame, (int)g_ctl.pkeAttach, (int)g_ctl.fingers, (int)g_pke.gunHidden);
  log_line("SOLIDBODY frame=%d on=%d checks=%d pushedOut=%d biggestPushCm=%d (gun grip and hands kept out of the torso column)", (int)frame, (int)g_ctl.solidBody, (int)g_solid.calls, (int)g_solid.pushed, (int)(g_solid.maxX100 * 30.48 / 100.0));
  log_line("BODYFOLLOW frame=%d follow=%d scale=%d eyeNominal=%d.%02dft torsoDead=%ddeg lag=%dms updates=%d off=%d notFirstPerson=%d noActor=%d bad=%d stale=%d "
           "applied(body/extras/hose)=%d/%d/%d notPlayer=%d/%d/%d lastTorsoDeg=%d.%d maxTorsoDeg=%d.%d lastHeadYawDeg=%d.%d lastOffsetFt=%d.%02d,%d.%02d "
           "maxOffsetFt=%d.%02d bodyScale=%d.%03d calibrations=%d lastCalib=%dcm->%d%% playerHeight=%d%% eyeHeight=%d.%02dft world=%d%%",
           (int)frame, (int)g_ctl.bodyFollow, (int)g_ctl.bodyScale, (int)(g_ctl.bodyEyeCenti / 100), (int)(g_ctl.bodyEyeCenti % 100), (int)g_ctl.torsoDeadDeg, (int)g_ctl.torsoLagMs,
           (int)g_bodyMv.updates, (int)g_bodyMv.off, (int)g_bodyMv.notFp, (int)g_bodyMv.noActor, (int)g_bodyMv.bad, (int)g_bodyMv.stale,
           (int)g_bodyMv.applied[0], (int)g_bodyMv.applied[1], (int)g_bodyMv.applied[2], (int)g_bodyMv.notPlayer[0], (int)g_bodyMv.notPlayer[1], (int)g_bodyMv.notPlayer[2],
           (int)(g_bodyMv.lastPhiX10 / 10), (int)((g_bodyMv.lastPhiX10 < 0 ? -g_bodyMv.lastPhiX10 : g_bodyMv.lastPhiX10) % 10), (int)(g_bodyMv.maxPhiX10 / 10), (int)(g_bodyMv.maxPhiX10 % 10),
           (int)(g_bodyMv.lastHeadYawX10 / 10), (int)((g_bodyMv.lastHeadYawX10 < 0 ? -g_bodyMv.lastHeadYawX10 : g_bodyMv.lastHeadYawX10) % 10),
           (int)(g_bodyMv.lastDx100 / 100), (int)((g_bodyMv.lastDx100 < 0 ? -g_bodyMv.lastDx100 : g_bodyMv.lastDx100) % 100),
           (int)(g_bodyMv.lastDz100 / 100), (int)((g_bodyMv.lastDz100 < 0 ? -g_bodyMv.lastDz100 : g_bodyMv.lastDz100) % 100),
           (int)(g_bodyMv.maxOffX100 / 100), (int)(g_bodyMv.maxOffX100 % 100), (int)(g_bodyMv.lastScaleX1000 / 1000), (int)(g_bodyMv.lastScaleX1000 % 1000),
           (int)g_bodyMv.calibrations, (int)g_bodyMv.lastCalibCm, (int)g_bodyMv.lastCalibPct, (int)g_ctl.sizePct,
           (int)(g_ctl.eyeHeightCenti * g_ctl.sizePct / 10000), (int)((g_ctl.eyeHeightCenti * g_ctl.sizePct / 100) % 100), (int)g_ctl.worldPct);
  {
    char b[500]; int n = 0;
    for (int i = 0; i < g_attachN && n < 430; ++i)
      n += wsprintfA(b + n, " %s=%d@(%d,%d,%d)", g_attach[i].name, (int)g_attach[i].count, (int)g_attach[i].pos[0], (int)g_attach[i].pos[1], (int)g_attach[i].pos[2]);
    b[n] = 0;
    log_line("ATTACHNAMES %d names (calls, last world position in whole feet):%s", g_attachN, b);
  }
  log_line("PACKFOLLOW packFollow=%d moved=%d noTorsoMotion=%d biggestDropCm=%d", (int)g_ctl.packFollow, (int)g_bodyMv.packMoved, (int)g_bodyMv.packNoMotion, (int)g_bodyMv.packDropMaxX100);
  log_line("AIMHOLD gun/PKE placements that used the last good aim for a short gap instead of dropping back to the game's own spot: %ld (1.7.25; before: noAim %ld); 1.7.170 longer gaps (up to 1 s, moved with the player) %ld", (long)g_aimHeldReads, (long)g_wandSt.noAim, (long)g_aimLongHolds);
  log_line("HOLSTERBACK holster_on_back=%d | holstered gun draws %ld, of them placed at the pack %ld (1.7.25; the right arm now follows the controller while holstered)", (int)g_ctl.holsterOnBack, (long)g_wandSt.holstered, (long)g_wandSt.holsterBack);
  log_line("WAND frame=%d hook=%d realModels=%d wandToHand=%d backCm=%d pushes=%d applied=%d noAim=%d stale=%d noTip=%d bad=%d farSkip=%d holstered=%d "
           "rolled=%d lastRollDeg=%d.%d maxRollDeg=%d rollFixDeg=%d lastTurnDeg=%d.%d maxTurnDeg=%d.%d gripToTipFt=%d.%02d lastShiftFt=%d.%02d gameWandAt=%.2f,%.2f,%.2f gameTipAt=%.2f,%.2f,%.2f glue=%d gunGlued=%d tipGlued=%d lastGlueFt=%d.%02d maxGlueFt=%d.%02d handAtHand=%d handFit=%d tipFit=%d",
           (int)frame, g_wandHook, (int)g_ctl.realModels, (int)g_ctl.wandToHand, (int)g_ctl.wandBackCm, (int)g_wandSt.hookCalls, (int)g_wandSt.applied,
           (int)g_wandSt.noAim, (int)g_wandSt.stale, (int)g_wandSt.noTip, (int)g_wandSt.bad, (int)g_wandSt.farSkip, (int)g_wandSt.holstered,
           (int)g_wandSt.rolled, (int)(g_wandSt.lastRollX10 / 10), (int)((g_wandSt.lastRollX10 < 0 ? -g_wandSt.lastRollX10 : g_wandSt.lastRollX10) % 10), (int)(g_wandSt.maxRollX10 / 10), (int)g_ctl.wandRollDeg,
           (int)(g_wandSt.lastTurnX10 / 10), (int)(g_wandSt.lastTurnX10 % 10), (int)(g_wandSt.maxTurnX10 / 10), (int)(g_wandSt.maxTurnX10 % 10),
           (int)(g_wandSt.lastGripTipX100 / 100), (int)(g_wandSt.lastGripTipX100 % 100), (int)(g_wandSt.lastShiftX100 / 100), (int)(g_wandSt.lastShiftX100 % 100),
           (double)g_wandSt.lastW[0], (double)g_wandSt.lastW[1], (double)g_wandSt.lastW[2], (double)g_wandSt.lastTip0[0], (double)g_wandSt.lastTip0[1], (double)g_wandSt.lastTip0[2],
           (int)g_ctl.gunGlue, (int)g_wandSt.glued, (int)g_wandSt.tipGlued, (int)(g_wandSt.lastGlueX100 / 100), (int)(g_wandSt.lastGlueX100 % 100), (int)(g_wandSt.maxGlueX100 / 100), (int)(g_wandSt.maxGlueX100 % 100), (int)g_ctl.gripAtHand, (int)g_wandSt.handFit, (int)g_wandSt.tipFit);
  {   // 1.0: the 0.97 log had the gun stop being moved (applied frozen) while pushes went on; these say which gate it was
    const LONG nowS = (LONG)(GetTickCount() / 1000);
    log_line("WANDGATE pushes=%d player=%d applied=%d | not applied because: settingsOrStereoOff=%d (last bits realModels=%d wandToHand=%d stereo=%d tipHook=%d) otherBustersWand=%d pkeOut=%d noAim=%d stale=%d holstered=%d noTip=%d farSkip=%d | secondsSinceLastApplied=%d",
             (int)g_wandSt.hookCalls, (int)g_wandSt.calls, (int)g_wandSt.applied, (int)g_wandSt.gateOff, (int)(g_wandSt.gateOffLast & 1), (int)((g_wandSt.gateOffLast >> 1) & 1), (int)((g_wandSt.gateOffLast >> 2) & 1), (int)((g_wandSt.gateOffLast >> 3) & 1),
             (int)g_wandSt.notMine, (int)g_wandSt.pkeOut, (int)g_wandSt.noAim, (int)g_wandSt.stale, (int)g_wandSt.holstered, (int)g_wandSt.noTip, (int)g_wandSt.farSkip,
             g_wandSt.lastAppliedAt ? (int)(nowS - g_wandSt.lastAppliedAt) : -1);
  }
}

// ---- 0.35 input probe ------------------------------------------------------------
// Counts how often the game asks for each control (0..31) and how often the answer
// was "pressed", and samples the game's own pad array, so a log shows whether the
// right trigger (control 5) reaches the fire logic.
struct BtnProbe { volatile LONG asked[3][32]; volatile LONG yes[3][32]; };
static BtnProbe g_btn;
static int g_btnHook = 0;
typedef bool (*BtnFn)(void*, int);
static BtnFn o_btn[3];
static inline bool btn_common(int k, void* c, int i) {
  bool r = o_btn[k](c, i);
  if ((unsigned)i < 32) { InterlockedIncrement(&g_btn.asked[k][i]); if (r) InterlockedIncrement(&g_btn.yes[k][i]); }
  return r;
}
static bool hk_btn0(void* c, int i) { return btn_common(0, c, i); }
static bool hk_btn1(void* c, int i) { return btn_common(1, c, i); }
static bool hk_btn2(void* c, int i) { return btn_common(2, c, i); }

static void install_btn_probe() {
  const struct { uint32_t r; const uint8_t* b; void* hk; } t[3] = {
    {layout::kRvaBtnPressed, layout::kBytesBtnPressed, (void*)hk_btn0},
    {layout::kRvaBtnHeld2, layout::kBytesBtnHeld2, (void*)hk_btn1},
    {layout::kRvaBtnHeld, layout::kBytesBtnHeld, (void*)hk_btn2}};
  int ok = 1;
  for (int k = 0; k < 3; ++k) if (!bytes_match(t[k].r, t[k].b, 16)) ok = 0;
  if (!ok) { g_btnHook = -1; log_line("BTNPROBE not available (bytes differ)"); return; }
  for (int k = 0; k < 3; ++k) {
    void* tg = (void*)rva(t[k].r);
    MH_STATUS s = MH_CreateHook(tg, t[k].hk, (void**)&o_btn[k]);
    if (s == MH_OK) s = MH_EnableHook(tg);
    if (s != MH_OK) { g_btnHook = -2; log_line("BTNPROBE hook %d failed (%d)", k, (int)s); return; }
  }
  g_btnHook = 1;
  log_line("HOOK button-getters installed (input probe)");
}

static int readable_bytes(const void* p, size_t n) {
  MEMORY_BASIC_INFORMATION mbi;
  if (!VirtualQuery(p, &mbi, sizeof(mbi)) || mbi.State != MEM_COMMIT) return 0;
  if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return 0;
  return (const uint8_t*)p + n <= (const uint8_t*)mbi.BaseAddress + mbi.RegionSize;
}


// ---- 0.35 pad-memory watch ----------------------------------------------------------
// For a few seconds the two pages holding the game's pad 0 are guarded; every access to
// the control/edge/trigger area is logged with the address of the code that did it, so the
// log names the functions that read the right trigger. Single-steps once per access.
struct WatchRip { uint32_t rva; uint32_t reads, writes; uint32_t minOff, maxOff; };
static WatchRip g_wrip[96];
static volatile LONG g_wcount = 0, g_wArmed = 0, g_wHits = 0, g_wDropped = 0, g_wWindows = 0;
static DWORD g_wTids[16];
static uintptr_t g_wPage[2];
static DWORD g_wOld[2];
static uintptr_t g_wLo, g_wHi, g_wBase;
static void* g_wVeh = 0;
static int g_typeForced = 0, g_typeNow = -1;

static void watch_protect(int on) {
  for (int i = 0; i < 2; ++i) {
    DWORD old = 0;
    if (on) { if (VirtualProtect((void*)g_wPage[i], 4096, PAGE_READWRITE | PAGE_GUARD, &old)) g_wOld[i] = old & ~PAGE_GUARD; }
    else VirtualProtect((void*)g_wPage[i], 4096, g_wOld[i] ? g_wOld[i] : PAGE_READWRITE, &old);
  }
}
static int wslot(DWORD tid, int create) {
  for (int i = 0; i < 16; ++i) if (g_wTids[i] == tid) return i;
  if (!create) return -1;
  for (int i = 0; i < 16; ++i) if (InterlockedCompareExchange((volatile LONG*)&g_wTids[i], (LONG)tid, 0) == 0) return i;
  return -1;
}
static LONG CALLBACK watch_veh(EXCEPTION_POINTERS* ep) {
  DWORD code = ep->ExceptionRecord->ExceptionCode;
  if (code == STATUS_GUARD_PAGE_VIOLATION && g_wArmed) {
    uintptr_t addr = (uintptr_t)ep->ExceptionRecord->ExceptionInformation[1];
    if (addr < g_wPage[0] || addr >= g_wPage[1] + 4096) return EXCEPTION_CONTINUE_SEARCH;
    InterlockedIncrement(&g_wHits);
    if (addr >= g_wLo && addr < g_wHi) {
      uint32_t r = (uint32_t)(ep->ContextRecord->Rip - rva(0));
      uint32_t off = (uint32_t)(addr - g_wBase);
      int w = ep->ExceptionRecord->ExceptionInformation[0] ? 1 : 0, k = -1;
      LONG n = g_wcount;
      for (LONG i = 0; i < n && i < 96; ++i) if (g_wrip[i].rva == r) { k = (int)i; break; }
      if (k < 0 && n < 96) {
        LONG idx = InterlockedIncrement(&g_wcount) - 1;
        if (idx < 96) { g_wrip[idx].rva = r; g_wrip[idx].minOff = g_wrip[idx].maxOff = off; k = (int)idx; }
      }
      if (k >= 0) {
        if (w) g_wrip[k].writes++; else g_wrip[k].reads++;
        if (off < g_wrip[k].minOff) g_wrip[k].minOff = off;
        if (off > g_wrip[k].maxOff) g_wrip[k].maxOff = off;
      } else InterlockedIncrement(&g_wDropped);
    }
    int sl = wslot(GetCurrentThreadId(), 1);
    if (sl >= 0) ep->ContextRecord->EFlags |= 0x100;   // single-step, then guard again
    return EXCEPTION_CONTINUE_EXECUTION;
  }
  if (code == EXCEPTION_SINGLE_STEP) {
    int sl = wslot(GetCurrentThreadId(), 0);
    if (sl < 0) return EXCEPTION_CONTINUE_SEARCH;
    if (g_wArmed) {   // re-arm the guard of both pages
      DWORD old;
      for (int i = 0; i < 2; ++i) VirtualProtect((void*)g_wPage[i], 4096, PAGE_READWRITE | PAGE_GUARD, &old);
    }
    ep->ContextRecord->EFlags &= ~0x100u;
    return EXCEPTION_CONTINUE_EXECUTION;
  }
  return EXCEPTION_CONTINUE_SEARCH;
}

static void watch_tick(LONG frame) {
  static DWORD s_until = 0;
  static LONG s_lastWindowFrame = -100000;
  if (g_wArmed) {
    if ((LONG)(GetTickCount() - s_until) >= 0) {
      g_wArmed = 0; watch_protect(0);
      char line[1100]; int n = wsprintfA(line, "PADWATCH window=%d hits=%d dropped=%d readers:", (int)g_wWindows, (int)g_wHits, (int)g_wDropped);
      for (LONG i = 0; i < g_wcount && i < 96 && n < 980; ++i)
        n += wsprintfA(line + n, " %x[r%d w%d off%x-%x]", (unsigned)g_wrip[i].rva, (int)g_wrip[i].reads, (int)g_wrip[i].writes,
                       (unsigned)g_wrip[i].minOff, (unsigned)g_wrip[i].maxOff);
      log_line("%s", line);
    }
    return;
  }
  if (g_wWindows >= 0) return;   // 0.90: OFF. Each 3 s window made ~525000 exceptions (the pad pages are guarded and single-stepped); with the watcher attached that was the stutter. The data is already in the 0.35-0.88 logs.
  if (frame < 900 || frame - s_lastWindowFrame < 1100 || g_typeNow != 1) return;
  uintptr_t pad = (uintptr_t)rva(layout::kRvaPadArray);   // physical pad 0 (the merged pad at 0xDD36D8 stays zero in play)
  g_wBase = pad;
  g_wPage[0] = pad & ~(uintptr_t)4095;
  g_wPage[1] = g_wPage[0] + 4096;
  g_wLo = pad + 0x40; g_wHi = pad + 0x240;
  if (!g_wVeh) g_wVeh = AddVectoredExceptionHandler(1, watch_veh);
  g_wcount = 0; g_wHits = 0; g_wDropped = 0;
  for (int i = 0; i < 96; ++i) g_wrip[i] = WatchRip();
  s_lastWindowFrame = frame;
  g_wWindows++;
  s_until = GetTickCount() + 3000;
  g_wArmed = 1;
  watch_protect(1);
  log_line("PADWATCH window %d armed for 3 s on pad 0 at %p", (int)g_wWindows, (void*)g_wBase);
}


// 1.7.91 what the game itself believes about its four pad slots (read only). state: 0 no pad, 2 XInput pad, 12 DirectInput pad; di: its DirectInput device pointer (non zero = that slot is
// read through DirectInput and XInput is skipped for it).
void engine_pad_slots(long* state4, unsigned long long* di4) {
  for (int p = 0; p < 4; ++p) {
    state4[p] = -1; di4[p] = 0;
    const void* a = (const void*)(rva(layout::kRvaPadArray) + (size_t)p * layout::kPadStride);
    if (readable_bytes(a, 4)) state4[p] = *(const volatile int32_t*)a;
    const void* d = (const void*)(rva(layout::kRvaDiDevices) + (size_t)p * 8);
    if (readable_bytes(d, 8)) di4[p] = *(const volatile uint64_t*)d;
  }
}

void engine_pad_xflags(long* f4) {
  for (int p = 0; p < 4; ++p) {
    f4[p] = -1;
    const void* a = (const void*)(rva(layout::kRvaPadXFlags) + (size_t)p);
    if (readable_bytes(a, 1)) f4[p] = *(const volatile uint8_t*)a;
  }
}

// ---- 1.7.92 DirectInput takeover ----------------------------------------------------------
// See pad::di_takeover_should_arm. The decision is made on the render thread every few seconds (xinput_bridge_di_check); the work is done here on the game's MAIN thread, at
// the start of a main-loop simulation (the same thread that polls the pad a moment later in the same frame), so nothing reads the device while it is closed.
// What it does, slot by slot, for every DirectInput pad the game has open: log what the device is, close it the way the game's own shutdown does (Unacquire, Release, pointer 0,
// instance GUID cleared), and, if the slot was not an XInput pad, call the game's own "pad gone" function so the slot is empty. The game's next scan then asks XInput for the
// slot (the scan skips XInput only for a slot with a device), our import hook answers with the VR controllers, and the game's own detection makes it an XInput pad.
static volatile LONG g_diArm;
static long g_diRuns, g_diClosed;
void engine_di_takeover_arm() { InterlockedExchange(&g_diArm, 1); }
void engine_di_takeover_stats(long* runs, long* closed) { *runs = g_diRuns; *closed = g_diClosed; }

// what is this device? (IDirectInputDevice8::GetDeviceInfo, vtable index 15: guidProduct at +20 = product id << 16 | vendor id, then the names). Tries the wide structure, then the ANSI one.
static int di_describe(void* dev, char* out, int cap) {
  void** vt = *(void***)dev;
  typedef long(__stdcall * PFN_GetDeviceInfo)(void*, void*);
  PFN_GetDeviceInfo gi = (PFN_GetDeviceInfo)vt[15];
  static uint8_t buf[0x44C];
  memset(buf, 0, sizeof(buf));
  *(uint32_t*)buf = 0x44C;
  if (gi(dev, buf) == 0) {   // wide: instance name at +40, product name at +560 (260 wide characters each)
    char name[120] = {0};
    WideCharToMultiByte(CP_ACP, 0, (const wchar_t*)(buf + 560), -1, name, (int)sizeof(name) - 1, 0, 0);
    return wsprintfA(out, "'%s' vendor %04x product %04x type %08x", name, *(uint32_t*)(buf + 20) & 0xFFFF, *(uint32_t*)(buf + 20) >> 16, *(uint32_t*)(buf + 36));
  }
  memset(buf, 0, sizeof(buf));
  *(uint32_t*)buf = 0x244;
  if (gi(dev, buf) == 0) {   // ANSI: instance name at +40, product name at +300 (260 characters each)
    char name[120] = {0};
    lstrcpynA(name, (const char*)(buf + 300), (int)sizeof(name));
    return wsprintfA(out, "'%s' vendor %04x product %04x type %08x", name, *(uint32_t*)(buf + 20) & 0xFFFF, *(uint32_t*)(buf + 20) >> 16, *(uint32_t*)(buf + 36));
  }
  (void)cap;
  return wsprintfA(out, "(the device would not say what it is)");
}

static GBVR_NOINLINE void di_takeover_run() {
  if (!InterlockedExchange(&g_diArm, 0)) return;
  if (!bytes_match(layout::kRvaPadDisconnect, layout::kBytesPadDisconnect, 16)) {
    static int s_warned;
    if (!s_warned++) log_line("DITAKEOVER not done: the game's pad-clearing function is not the one this was made for");
    return;
  }
  uint8_t* devs = (uint8_t*)rva(layout::kRvaDiDevices);
  uint8_t* guids = (uint8_t*)rva(layout::kRvaDiGuids);
  const uint8_t* flags = (const uint8_t*)rva(layout::kRvaPadXFlags);
  if (!readable_bytes(devs, 32) || !readable_bytes(guids, 64) || !readable_bytes(flags, 4)) return;
  long st[4]; unsigned long long di[4];
  engine_pad_slots(st, di);
  ++g_diRuns;
  char info[1500]; int n = wsprintfA(info, "DITAKEOVER #%ld (game thread): the game had DirectInput pads open and was not reading XInput, so the VR controllers could not reach it. Slot states before %ld/%ld/%ld/%ld (0 none, 2 pad, 12 other).", g_diRuns, st[0], st[1], st[2], st[3]);
  for (int p = 0; p < 4; ++p) {
    void* dev = *(void* volatile*)(devs + 8 * p);
    if (!dev) continue;
    void** vt = readable_bytes(dev, 8) ? *(void***)dev : 0;
    if (!vt || !readable_bytes(vt, 8 * 20)) { if (n < 1100) n += wsprintfA(info + n, " | slot %d: left alone (not a usable device pointer)", p); continue; }
    char what[260];
    di_describe(dev, what, (int)sizeof(what));
    if (n < 1100) n += wsprintfA(info + n, " | slot %d closed: %s", p, what);   // each piece is at most about 250 characters: 4 slots always fit in 1500
    ((long(__stdcall*)(void*))vt[8])(dev);               // Unacquire
    *(void* volatile*)(devs + 8 * p) = 0;
    memset(guids + 16 * p, 0, 16);
    ((unsigned long(__stdcall*)(void*))vt[2])(dev);      // Release
    InterlockedIncrement((volatile LONG*)&g_diClosed);
    if (st[p] > 0 && !flags[p]) ((void(__fastcall*)(int))rva(layout::kRvaPadDisconnect))(p);   // the slot was made for that device: empty it so the next scan detects the VR pad
  }
  log_line("%s", info);
}
static void di_takeover_if_armed() { if (g_diArm) di_takeover_run(); }

// ---- 0.36 controller type -----------------------------------------------------------
// The game reads the pad during play only when its controller type is "gamepad". When the
// type is "mouse and keyboard" and the controllers are active, the game's own setter is
// called once (and logged), exactly as choosing it in Options > Controls would.
static void controller_type_tick() {
  static int s_bytesOK = -1;
  if (s_bytesOK < 0)
    s_bytesOK = bytes_match(layout::kRvaSetControllerType, layout::kBytesSetControllerType, 16) &&
                bytes_match(layout::kRvaGetControllerType, layout::kBytesGetControllerType, 16);
  if (!s_bytesOK || !g_ctl.padEnabled) return;
  const void* pp = (const void*)rva(layout::kRvaSettingsObjPtr);
  if (!readable_bytes(pp, 8)) return;
  uint8_t* obj = *(uint8_t* const*)pp;
  if (!obj || !readable_bytes(obj + layout::kOffControllerType, 4)) return;
  int type = *(volatile int32_t*)(obj + layout::kOffControllerType);
  g_typeNow = type;
  static int s_logged = -99;
  if (type != s_logged) { log_line("CONTROLTYPE game controller type = %d (0 mouse+keyboard, 1 gamepad)", type); s_logged = type; }
  static int s_dumped = -1;
  if (s_dumped != type && readable_bytes(obj + layout::kOffControllerType + 4, 50 * 24 + 0x20)) {   // control bindings of player 0, once per controller type
    s_dumped = type;
    char line[1500]; int n = wsprintfA(line, "BINDINGS(type=%d) a=Primary b=Secondary c=Trap d=Interact e=Jump f=Vent g=PKE h=CaptureStream i=HUD j=Sprint k=CPS l=ProtonEquip m=DMG n=PDS o=Start p=Select:", type);
    for (int i = 0; i < 50 && n < 1380; ++i) {
      const int32_t* e = (const int32_t*)(obj + layout::kOffControllerType + 4 + 24 * i);
      n += wsprintfA(line + n, " %d[%d,%d,%d,%d]", i, (int)e[0], (int)e[1], (int)e[2], (int)e[3]);
    }
    log_line("%s", line);
    log_line("BINDINGS pad slot of player 0 = %d (offset 0x496C0)", *(const int32_t*)(obj + 0x496C0));
  }
  // 1.7.86: the switch to "gamepad" is made on the game's own thread by gamepad_type_keep() (below), not here (this runs on the render thread in the full report)
}

// 1.7.86: the game reads the pad during play only while its controller type is "gamepad" (1). The type starts at "mouse and keyboard" (0) on a fresh
// install and the game's own setter refuses (and puts 0 back) while no pad slot is connected. Until 1.7.85 the mod tried at most 400 times in a whole
// session, two tries for every 90 ticks: a player whose controllers were asleep or whose game flipped back to 0 for a while could use up the tries
// and then never move again. Now: forever, one try per 1.2 s, only while the headset view is on, the controllers are tracked and a 3D picture is up
// (a flat menu needs mouse mode for the laser). Every try is counted and the first ones are logged (CONTROLTYPE) so a report shows what happened.
static long g_ctTries, g_ctOk, g_ctFail;
void engine_controller_type(int* type, long* tries, long* ok) {
  *type = g_typeNow; *tries = g_ctTries; *ok = g_ctOk;
}
// ---- 1.7.92 STUCK watch ---------------------------------------------------------------------------------------------------------------------
// A player reported "the character is stuck in place" in Times Square (Stay Puft throws debris, "Follow Ray across Times Square"). The video shows the character standing still for
// 15-25 s in front of a taxi / beside a truck while he fires, but walking normally elsewhere, and there was no log. This writes one line (at most 12 per run, 15 s apart) when ALL of
// these hold for 2.5 s: in play in the 3D view, the controllers make the move stick >= 50% and the character's position did not change by more than 0.6 ft. It records what could
// explain it (the game's controller type, whether the game reads the pad at all, the body velocity, forced-move / cutscene / knock-down state, the pad slots) so the next report says
// whether the character is blocked by the world (velocity set, position not changing) or the walking never reaches it (velocity 0). Nothing is changed.
static void stuck_watch() {
  static int64_t s_chk, s_since, s_lastLog; static float s_p0[3]; static int s_armed, s_logged;
  const int64_t now = qpc_now();
  if (s_chk && now - s_chk < qpc_freq() / 10) return;   // ten looks a second at most
  s_chk = now;
  if (!g_ctl.stereoActive || stereo_in_flat_mode() || vrmenu_is_open() || held_menu_active() || !controllers_active()) { s_armed = 0; return; }
  pad::State ps;
  if (!controllers_pad_peek(&ps)) { s_armed = 0; return; }
  const double stick = vm::dsqrt((double)ps.lx * ps.lx + (double)ps.ly * ps.ly) / 32767.0;
  const uintptr_t a = head_aim_actor();
  if (!a || !memory_readable((const void*)(a + layout::kActorPos), 12)) { s_armed = 0; return; }
  const float* p = (const float*)(a + layout::kActorPos);
  if (!sb_finite3(p) || stick < 0.5) { s_armed = 0; return; }
  if (!s_armed) { s_armed = 1; s_since = now; for (int i = 0; i < 3; ++i) s_p0[i] = p[i]; return; }
  const double dx = (double)p[0] - s_p0[0], dz = (double)p[2] - s_p0[2];
  if (vm::dsqrt(dx * dx + dz * dz) > 0.6) { s_since = now; for (int i = 0; i < 3; ++i) s_p0[i] = p[i]; return; }   // it moved: the window starts again
  const double secs = (double)(now - s_since) / (double)qpc_freq();
  if (secs < 2.5 || s_logged >= 12 || (s_lastLog && now - s_lastLog < 15 * qpc_freq())) return;
  s_lastLog = now; ++s_logged;
  float vel[3] = {0, 0, 0}; int haveVel = 0;
  const uintptr_t body = sb_body(a);
  if (body) { const float* v = (const float*)(body + layout::kBodyVel); if (sb_finite3(v)) { vel[0] = v[0]; vel[1] = v[1]; vel[2] = v[2]; haveVel = 1; } }
  long gs = 0, fk = 0, mg = 0; int hook = 0;
  xinput_bridge_counts(&gs, &fk, &mg, &hook);
  long st[4]; unsigned long long di[4]; long fl[4];
  engine_pad_slots(st, di); engine_pad_xflags(fl);
  const int knockFlag = memory_readable((const void*)(a + layout::kOffKnockFlag), 1) ? *((const uint8_t*)a + layout::kOffKnockFlag) : -1;
  log_line("STUCK #%d: the move stick has been pushed %.0f%% for %.1f s but the character moved only %.2f ft (position %.1f,%.1f,%.1f) | body velocity %s%.2f,%.2f,%.2f ft/s (0 = the walking never reaches the character; non-zero with no movement = the world blocks it) | "
           "the game's controller type %d (1 gamepad), game read XInput %ld times in total (flag per slot %ld/%ld/%ld/%ld, slot states %ld/%ld/%ld/%ld, DirectInput pads %llx/%llx/%llx/%llx) | forced move %d, cutscene guard %d, knock comfort %.2f, game fall flag %d, speed boost x%.2f | pad buttons 0x%04x",
           s_logged, stick * 100.0, secs, vm::dsqrt(dx * dx + dz * dz), (double)p[0], (double)p[1], (double)p[2], haveVel ? "" : "(not readable) ", (double)vel[0], (double)vel[1], (double)vel[2],
           g_typeNow, gs, fl[0], fl[1], fl[2], fl[3], st[0], st[1], st[2], st[3], di[0], di[1], di[2], di[3],
           g_forced.forced ? 1 : 0, g_cine.active ? 1 : 0, engine_knock_strength(), knockFlag, g_sb.s.k, (unsigned)ps.buttons);
  {   // 1.7.93: knock-backs the game sent this run, how many were replaced by the comfort window, the Stay Puft level, and the rescue
    const double agoS = g_kn.takenQ ? (double)(now - g_kn.takenQ) / (double)qpc_freq() : -1.0;
    const int boss = knock_boss_present(a);
    const int recent = g_kn.haveImpact && agoS >= 0.0 && agoS < 120.0 && !g_kn.off && !g_forced.forced && !g_cine.active;   // 1.7.191: also in the Stay Puft level (the soft knock-down is used there now)
    log_line("STUCK knock info: the game sent %ld knock-backs to the player, %ld replaced by the comfort window (the last one %.0f s ago, -1 = none), Stay Puft level now %d, comfort switched off by a rescue %d | %s",
             g_kn.playerCalls, g_kn.took, agoS, boss, (int)g_kn.off,
             recent ? "a knock-back was skipped within 2 minutes: it is played now (rescue)" : "no recent skipped knock-back: nothing replayed");
    if (recent && g_kn.rescues < 3) { InterlockedExchange(&g_kn.rescueReq, 1); ++g_kn.rescueAsked; }
  }
}
static void gamepad_type_keep() {
  static int64_t s_chk, s_try; static int s_bytesOK = -1; static int s_refused;
  const int64_t now = qpc_now();
  if (s_chk && now - s_chk < qpc_freq() / 5) return;   // looked at 5 times a second at most
  s_chk = now;
  if (!g_ctl.padEnabled || !g_ctl.stereoActive) return;
  if (s_bytesOK < 0)
    s_bytesOK = bytes_match(layout::kRvaSetControllerType, layout::kBytesSetControllerType, 16) &&
                bytes_match(layout::kRvaGetControllerType, layout::kBytesGetControllerType, 16);
  if (!s_bytesOK) return;
  const void* pp = (const void*)rva(layout::kRvaSettingsObjPtr);
  if (!readable_bytes(pp, 8)) return;
  uint8_t* obj = *(uint8_t* const*)pp;
  if (!obj || !readable_bytes(obj + layout::kOffControllerType, 4)) return;
  const int type = *(volatile int32_t*)(obj + layout::kOffControllerType);
  g_typeNow = type;
  if (type != 0) return;
  if (stereo_in_flat_mode() || !controllers_active()) return;   // a flat menu needs mouse mode; no controller = nothing to give the game
  // one try per 1.2 s; when the game keeps refusing (no pad connected for it) the gap grows to 5 s and then 15 s so a stuck case does not hammer the game's setter
  const int64_t gap = qpc_freq() * (s_refused < 10 ? 12 : s_refused < 40 ? 50 : 150) / 10;
  if (s_try && now - s_try < gap) return;
  s_try = now;
  typedef unsigned char (*SetFn)(void*, int, int);
  const unsigned char r = ((SetFn)rva(layout::kRvaSetControllerType))(obj, 0, 1);
  const int after = *(volatile int32_t*)(obj + layout::kOffControllerType);
  ++g_ctTries; g_typeForced = (int)g_ctTries; g_typeNow = after;
  if (after == 1) { ++g_ctOk; s_refused = 0; } else { ++g_ctFail; ++s_refused; }
  if (g_ctTries <= 12 || g_ctTries % 50 == 0)
    log_line("CONTROLTYPE try #%ld: the game's controller type was 0 (mouse+keyboard) with the controllers tracked in the 3D view; its setter said %d and the type is now %d (%s) | tries so far: %ld worked, %ld refused (the setter refuses while the game has no pad connected)",
             g_ctTries, (int)r, after, after == 1 ? "gamepad: the pad reaches the game" : "still mouse+keyboard: the pad does NOT reach the game", g_ctOk, g_ctFail);
}


// ---- 0.40 binding update hook -------------------------------------------------------
// The game turns pad/keyboard input into per-action states once per tick in 0x1FC240(block, dt)
// (block = the 50 bindings of one player, 0x18 bytes each; state at +0xC: 0 idle, 1 held, 2 just
// released; hold time at +0x10; analog at +0x14). Queries 0x1FC5C0 (held), 0x1FC5F0 (released) and
// 0x1FC620 (just pressed) read that state. The hook (a) logs which block runs and which actions
// the game asks about, (b) re-selects the gamepad type if the game dropped back to mouse+keyboard,
// (c) writes the state of Primary Action / Secondary Action itself while a VR trigger is held, so
// firing no longer depends on the pad path.
static volatile LONG g_trigLT = 0, g_trigRT = 0;
static volatile LONG g_trigOn[2];          // 0 Primary (right trigger), 1 Secondary (left trigger)
static volatile DWORD g_trigStart[2];
static int g_dirty[2];                      // 1 = we wrote "held" into the game's state, 2 = we wrote "released"
static DWORD g_dirtyAt[2];
static volatile LONG g_secLate;       // 1.7.223: pulls whose "just pressed" had to be delivered after the first 50 ms
static volatile LONG g_secDelivered;   // 1.7.223: 1 once the game has been told "just pressed" for this pull of the left trigger
void bindings_sample(int lt, int rt) {
  g_trigLT = lt; g_trigRT = rt;
  const int v[2] = {rt != 0, lt != 0};   // callers pass 0/1 (trigger above 60)
  for (int a = 0; a < 2; ++a) {
    if (v[a] && !g_trigOn[a]) { g_trigStart[a] = GetTickCount(); if (a == 1) InterlockedExchange(&g_secDelivered, 0); }
    g_trigOn[a] = v[a];
  }
}
static inline bool fire_active(int a) { return g_trigOn[a] && g_ctl.padEnabled; }
int engine_secondary_press(unsigned* ageMs, int* rtDown) {   // 1.7.223 (for the DARTTRACE log): 1 while the left trigger is held; how long, and whether the right trigger is held too
  if (ageMs) *ageMs = g_trigOn[1] ? (unsigned)(GetTickCount() - g_trigStart[1]) : 0;
  if (rtDown) *rtDown = g_trigOn[0] ? 1 : 0;
  return g_trigOn[1] ? 1 : 0;
}
long engine_secondary_late() { return g_secLate; }

// 0.46 pad buttons for the game's actions. The game's own path (XInputGetState -> 0x45FA90 -> edge flag -> binding update
// 0x1FC240) only accepts a press when the previous poll still saw the button up (0x1FB9E0 skips it when the "held last poll"
// flag is set). In VR the pad is polled more often than the binding update runs, so every press was eaten (log 0.45:
// only the two forced trigger actions ever answered "yes", Vent/Capture/Jump/Interact never). So the binding update
// below now writes the state of every pad-button action itself from the pad mask the controllers produce.
static LONG g_btnPress[50], g_btnFrames[50];
void bindings_pad(unsigned xbuttons, int lt, int rt) {
  const LONG m = (LONG)pad::game_button_mask(xbuttons, lt, rt);
  g_padNow = m;
  for (;;) {                                  // latch: a press shorter than one binding update is still seen once
    LONG old = g_padLatch;
    if (InterlockedCompareExchange(&g_padLatch, old | m, old) == old) break;
  }
}
int bindings_capture_down() {
  return controllers_active() && (((uint32_t)g_padNow & (1u << 6)) != 0);
}

// 0.48 data collection (log only, nothing is written into the game):
//  * snapshots of the player actor (0x2000 bytes) and of the objects it points to, while idle / firing / venting / idle again
//    / when the player marks a moment (MARK), and the dwords that changed (ACTORDIFF, OBJDIFF): offsets of pack heat,
//    vent / fire flags, target ...
//  * the object graph two levels below the actor (ACTORGRAPH: which field points to which game class), so the pack, wand,
//    stream, target and world list can be found without guessing
//  * TRACK: one line per second (actor position, aim, head offset, buttons) to replay the session
static const int kSnapBytes = 0x2000, kObjBytes = 0x400, kMaxObj = 32, kMaxNodes = 160, kSlots = 5;
struct GNode { uintptr_t p; uint32_t vt; int parent, off, depth; };
struct ObjSnap { uintptr_t p[kMaxObj]; uint32_t vt[kMaxObj]; int off[kMaxObj]; int n; uint32_t d[kMaxObj][kObjBytes / 4]; };
static uint32_t g_asnap[kSlots][kSnapBytes / 4];
static ObjSnap g_osnap[kSlots];
static GNode g_gnodes[kSlots][kMaxNodes];
static int g_gcount[kSlots];
static int g_ahave[kSlots];
static volatile LONG g_markReq, g_markCount;

static bool probe_is_obj(uintptr_t p, uint32_t* vtRva) {
  if (p < 0x10000 || p > 0x00007FFFFFFFFFFFull || (p & 7)) return false;
  const uintptr_t base = g_game.base, end = g_game.base + g_game.sizeOfImage;
  if (p >= base && p < end) return false;                      // a pointer into the exe itself is not a heap object
  if (!memory_readable((const void*)p, 0x40)) return false;
  const uintptr_t vt = *(const uintptr_t*)p;
  if (vt < base || vt >= end || (vt & 7)) return false;
  if (!memory_readable((const void*)vt, 8)) return false;
  const uintptr_t f = *(const uintptr_t*)vt;
  if (f < base || f >= end) return false;
  *vtRva = (uint32_t)(vt - base);
  return true;
}
static int probe_graph(uintptr_t root, GNode* out, int cap) {
  int n = 0;
  uint32_t vt = 0;
  probe_is_obj(root, &vt);
  out[n++] = GNode{root, vt, -1, 0, 0};
  for (int i = 0; i < n; ++i) {
    if (out[i].depth >= 2) continue;
    const int bytes = out[i].depth == 0 ? kSnapBytes : kObjBytes;
    if (!memory_readable((const void*)out[i].p, (size_t)bytes)) continue;
    const uintptr_t* q = (const uintptr_t*)out[i].p;
    for (int k = 0; k < bytes / 8 && n < cap; ++k) {
      uint32_t v2;
      if (!probe_is_obj(q[k], &v2)) continue;
      bool dup = false;
      for (int j = 0; j < n; ++j) if (out[j].p == q[k]) { dup = true; break; }
      if (!dup) out[n++] = GNode{q[k], v2, i, k * 8, out[i].depth + 1};
    }
  }
  return n;
}
static void probe_capture(int slot, uintptr_t actor) {
  memcpy(g_asnap[slot], (const void*)actor, kSnapBytes);
  g_gcount[slot] = probe_graph(actor, g_gnodes[slot], kMaxNodes);
  ObjSnap& o = g_osnap[slot];
  o.n = 0;
  for (int i = 1; i < g_gcount[slot] && o.n < kMaxObj; ++i) {
    const GNode& g = g_gnodes[slot][i];
    if (g.depth != 1 || !memory_readable((const void*)g.p, (size_t)kObjBytes)) continue;
    o.p[o.n] = g.p; o.vt[o.n] = g.vt; o.off[o.n] = g.off;
    memcpy(o.d[o.n], (const void*)g.p, kObjBytes);
    ++o.n;
  }
  g_ahave[slot] = 1;
}
static void probe_diff_words(const char* tag, const char* label, const uint32_t* a, const uint32_t* b, int words, const uint32_t* nA,
                             const uint32_t* nB, int maxShow, uintptr_t where) {
  char line[900]; int n = 0, shown = 0, total = 0;
  for (int i = 0; i < words; ++i) {
    if (a[i] == b[i]) continue;
    if (nA && nA[i] != nB[i]) continue;                         // also changes by itself while idle
    ++total;
    if (shown >= maxShow) continue;
    if (n == 0) n = wsprintfA(line, "%s %s:", tag, label);
    n += wsprintfA(line + n, " +%x:%x>%x", i * 4, (unsigned)a[i], (unsigned)b[i]);
    if (++shown % 8 == 0 || n > 780) { log_line("%s", line); n = 0; }
  }
  if (n) log_line("%s", line);
  if (total) log_line("%s %s total=%d shown=%d%s", tag, label, total, shown, where ? "" : "");
}
static void probe_diff_slots(const char* label, int sa, int sb, int noiseA, int noiseB) {
  probe_diff_words("ACTORDIFF", label, g_asnap[sa], g_asnap[sb], kSnapBytes / 4, noiseA >= 0 ? g_asnap[noiseA] : nullptr,
                   noiseA >= 0 ? g_asnap[noiseB] : nullptr, 160, 0);
  const ObjSnap& A = g_osnap[sa];
  const ObjSnap& B = g_osnap[sb];
  for (int i = 0; i < A.n; ++i) {
    int jb = -1, jn = -1, jm = -1;
    for (int j = 0; j < B.n; ++j) if (B.p[j] == A.p[i]) { jb = j; break; }
    if (jb < 0) continue;
    if (noiseA >= 0) {
      const ObjSnap& NA = g_osnap[noiseA]; const ObjSnap& NB = g_osnap[noiseB];
      for (int j = 0; j < NA.n; ++j) if (NA.p[j] == A.p[i]) { jn = j; break; }
      for (int j = 0; j < NB.n; ++j) if (NB.p[j] == A.p[i]) { jm = j; break; }
    }
    char tag[96];
    wsprintfA(tag, "%s(actor+0x%x obj=%p vt=+0x%x)", "OBJDIFF", A.off[i], (const void*)A.p[i], (unsigned)A.vt[i]);
    probe_diff_words(tag, label, A.d[i], B.d[jb], kObjBytes / 4, (jn >= 0 && jm >= 0) ? g_osnap[noiseA].d[jn] : nullptr,
                     (jn >= 0 && jm >= 0) ? g_osnap[noiseB].d[jm] : nullptr, 60, 0);
  }
}
static void probe_log_graph(const char* label, int slot, int vsSlot) {
  int shown = 0;
  for (int i = 0; i < g_gcount[slot]; ++i) {
    const GNode& g = g_gnodes[slot][i];
    if (vsSlot >= 0) { bool had = false; for (int j = 0; j < g_gcount[vsSlot]; ++j) if (g_gnodes[vsSlot][j].p == g.p) { had = true; break; } if (had) continue; }
    if (g.parent < 0) { log_line("ACTORGRAPH %s root=%p vt=+0x%x nodes=%d", label, (const void*)g.p, (unsigned)g.vt, g_gcount[slot]); continue; }
    log_line("ACTORGRAPH %s d%d parent=%d +0x%x -> %p vt=+0x%x", label, g.depth, g.parent, g.off, (const void*)g.p, (unsigned)g.vt);
    ++shown;
  }
  if (vsSlot >= 0) log_line("ACTORGRAPH %s new objects since idle: %d", label, shown);
}
void probe_mark(const char* who) {
  LONG n = InterlockedIncrement(&g_markCount);
  log_line("MARK %d by=%s frame=%d fire=%d pad=%08x (a snapshot of the player follows if the game is running)", (int)n, who, (int)g_ctl.worldFrames,
           (int)(g_trigOn[0] != 0), (unsigned)g_padNow);
  InterlockedExchange(&g_markReq, 1);
#if GBVR_HEADTRACK
  engine_float_mark(who);   // 1.6: every marker also writes the gun / PKE float numbers of that moment
  modscan_mark_note((int)n);   // 0.98
  shot_request();   // 0.64: a MARK also saves the picture of both eyes (the diagnostic JPEG in the game folder)
#endif
}
// 0.51: the world matrices of the player's model instances (and the tip), to see where each part really is
static void dump_models(uintptr_t actor, const char* why) {
  static int dumps;
  if (dumps >= 24 || !actor || !memory_readable((const void*)(actor + layout::kOffHoseWorld), 64)) return;
  ++dumps;
  static const struct { uint32_t off; const char* name; } k[3] = {{0x246d8, "pack-or-extra"}, {layout::kOffWandWorld, "wand"}, {layout::kOffHoseWorld, "hose"}};
  for (int i = 0; i < 3; ++i) {
    const float* m = (const float*)(actor + k[i].off);
    log_line("MODELMAT %s f=%d %s(+0x%x) rows: %.3f %.3f %.3f | %.3f %.3f %.3f | %.3f %.3f %.3f | pos %.3f %.3f %.3f", why, (int)g_ctl.worldFrames, k[i].name, (unsigned)k[i].off,
             (double)m[0], (double)m[1], (double)m[2], (double)m[4], (double)m[5], (double)m[6], (double)m[8], (double)m[9], (double)m[10], (double)m[12], (double)m[13], (double)m[14]);
  }
  {  // 0.52 the actor's own basis (what the body's base matrix is built from) and position, to see which way the body faces
    const float* r = (const float*)(actor + 0xF4);
    const float* p = (const float*)(actor + layout::kActorPos);
    log_line("ACTORBASIS %s f=%d cols: %.3f %.3f %.3f | %.3f %.3f %.3f | %.3f %.3f %.3f | pos %.3f %.3f %.3f", why, (int)g_ctl.worldFrames,
             (double)r[0], (double)r[1], (double)r[2], (double)r[3], (double)r[4], (double)r[5], (double)r[6], (double)r[7], (double)r[8],
             (double)p[0], (double)p[1], (double)p[2]);
  }
  if (g_tipHook == 1 && o_attach) {
    float t[16];
    o_attach((void*)actor, t, "tip");
    log_line("MODELMAT %s tip rows: %.3f %.3f %.3f | %.3f %.3f %.3f | %.3f %.3f %.3f | pos %.3f %.3f %.3f", why,
             (double)t[0], (double)t[1], (double)t[2], (double)t[4], (double)t[5], (double)t[6], (double)t[8], (double)t[9], (double)t[10], (double)t[12], (double)t[13], (double)t[14]);
  }
}

void actor_watch(uintptr_t actor) {
  if (!g_ctl.probeData) return;
  if (!actor || !memory_readable((const void*)actor, kSnapBytes)) return;
  {
    static LONG seenMarks; static int64_t firstSeen; static int first;
    const int64_t nowQ = qpc_now();
    if (!firstSeen) firstSeen = nowQ;
    if (!first && nowQ - firstSeen > 4 * qpc_freq()) { first = 1; dump_models(actor, "start"); }
    if (seenMarks != g_markCount) { seenMarks = g_markCount; dump_models(actor, "mark"); }
  }
  const int fire = g_trigOn[0] != 0, vent = (int)((g_padNow >> 7) & 1);
  // TRACK: one line per second
  static int64_t lastTrack; static int tracks;
  const int64_t now = qpc_now();
  if (tracks < 2400 && (!lastTrack || now - lastTrack >= qpc_freq())) {
    lastTrack = now; ++tracks;
    const float* f = (const float*)(const void*)(actor + layout::kActorPos);
    log_line("TRACK f=%d actor=%.2f,%.2f,%.2f aim=%.2f,%.2f,%.2f head=%.2f,%.2f,%.2f fire=%d vent=%d pad=%08x", (int)g_ctl.worldFrames,
             (double)f[0], (double)f[1], (double)f[2], (double)g_headAim.dir[0], (double)g_headAim.dir[1], (double)g_headAim.dir[2],
             (double)g_hm.last[0], (double)g_hm.last[1], (double)g_hm.last[2], fire, vent, (unsigned)g_padNow);
  }
  // SHOT: while firing, four lines a second about where the stream goes compared with where the wand points
  static int64_t lastShot; static int shots;
  if (fire && shots < 800 && now - lastShot >= qpc_freq() / 4) {
    lastShot = now; ++shots;
    HandsRaw hr; const int haveHands = controllers_raw(&hr);
    log_line("SHOT f=%d tip=%.2f,%.2f,%.2f aim=%.3f,%.3f,%.3f hit-in-tip-frame=%.3f,%.3f,%.3f heading=%.1f pitch=%.1f twoHand=%d hands=%d tipMoved=%.2fft overridden=%d",
             (int)g_ctl.worldFrames, (double)g_headAim.tip[0], (double)g_headAim.tip[1], (double)g_headAim.tip[2],
             (double)g_headAim.dir[0], (double)g_headAim.dir[1], (double)g_headAim.dir[2], (double)g_tipRot.lastLocal[0], (double)g_tipRot.lastLocal[1],
             (double)g_tipRot.lastLocal[2], (double)g_tipRot.lastHeadX10 / 10.0, (double)g_tipRot.lastPitchX10 / 10.0,
             haveHands && hr.validL && hr.gripL, haveHands, (double)g_tipSt.lastDistX100 / 100.0, (int)g_tipSt.overridden);
    // 0.52: does the game pull the stream towards the way the BODY faces? (aim yaw against the actor's facing, and the body-follow state)
    const float* rot = (const float*)(const void*)(actor + 0xF4);
    const double kDeg = 57.29577951308232;
    const double faceCol2 = vm::datan2((double)rot[6], (double)rot[8]) * kDeg;   // actor+0x10C, +0x114
    const double faceCol0 = vm::datan2((double)rot[0], (double)rot[2]) * kDeg;   // actor+0xF4, +0xFC
    const double aimYaw = vm::datan2((double)g_headAim.dir[0], (double)g_headAim.dir[2]) * kDeg;
    double d2 = aimYaw - faceCol2, d0 = aimYaw - faceCol0;
    while (d2 > 180) d2 -= 360; while (d2 < -180) d2 += 360; while (d0 > 180) d0 -= 360; while (d0 < -180) d0 += 360;
    log_line("SHOTFACE f=%d aimYaw=%.1f actorFacingCol2=%.1f (aim minus facing %.1f) actorFacingCol0=%.1f (%.1f) streamHeadingInTipFrame=%.1f torso=%.1f headYawRel=%.1f camYawDeg=%.1f",
             (int)g_ctl.worldFrames, aimYaw, faceCol2, d2, faceCol0, d0, (double)g_tipRot.lastHeadX10 / 10.0, (double)g_bodyMv.lastPhiX10 / 10.0,
             (double)g_bodyMv.lastHeadYawX10 / 10.0, g_armStereo.yaw * kDeg);
  }
  if (InterlockedExchange(&g_markReq, 0)) {
    probe_capture(4, actor);
    log_line("ACTORSNAP mark actor=%p bytes=%d objects=%d graph=%d", (const void*)actor, kSnapBytes, g_osnap[4].n, g_gcount[4]);
    if (g_ahave[0]) { probe_diff_slots("mark-vs-idle(raw)", 0, 4, -1, -1); probe_log_graph("mark", 4, 0); }
    else probe_log_graph("mark", 4, -1);
    return;
  }
  const int cond = vent ? 2 : fire ? 1 : 0;
  static int last = -1, held = 0;
  if (cond == last) ++held; else { last = cond; held = 0; }
  int slot = -1;
  if (cond == 1 && held == 200 && !g_ahave[1]) slot = 1;
  else if (cond == 2 && held == 100 && !g_ahave[2]) slot = 2;
  else if (cond == 0 && held == 400) { if (!g_ahave[0]) slot = 0; else if (!g_ahave[3] && g_ahave[1]) slot = 3; }
  if (slot < 0) return;
  static const char* nm[4] = {"idle", "firing", "venting", "idle-again"};
  probe_capture(slot, actor);
  const float* f = (const float*)(const void*)(actor + layout::kActorPos);
  log_line("ACTORSNAP %s actor=%p pos=%.2f,%.2f,%.2f bytes=%d objects=%d graph=%d", nm[slot], (const void*)actor, (double)f[0], (double)f[1],
           (double)f[2], kSnapBytes, g_osnap[slot].n, g_gcount[slot]);
  if (slot == 0) probe_log_graph("idle", 0, -1);
  if (slot == 1 || slot == 2) {
    probe_diff_slots(slot == 1 ? "firing-vs-idle(raw)" : "venting-vs-idle(raw)", 0, slot, -1, -1);
    probe_log_graph(nm[slot], slot, 0);
  }
  if (slot == 3) {
    probe_diff_slots("firing-vs-idle(no noise)", 0, 1, 0, 3);
    if (g_ahave[2]) probe_diff_slots("venting-vs-idle(no noise)", 0, 2, 0, 3);
  }
}
static LONG g_btnEvents;

typedef void (*BindUpdFn)(uint8_t*, float);
typedef bool (*BindQFn)(uint8_t*, int);
static BindUpdFn o_bindUpd;
static BindQFn o_bindQ[3];
static int g_bindHook = 0;
struct BindSeen { uintptr_t p; LONG calls, cached, slot, nat0, nat1; };
static BindSeen g_bs[4];
static LONG g_bqAsk[3][50], g_bqYes[3][50];
static LONG g_forcedFrames[2], g_forcedPress[2];
static LONG g_blockCalls;
static binding::Action g_vrAction[50];
static int g_vrActionKey[50];
static uint8_t* g_vrActionBlock;

static uint8_t* player0_block() {
  const void* pp = (const void*)rva(layout::kRvaSettingsObjPtr);
  if (!readable_bytes(pp, 8)) return 0;
  uint8_t* o = *(uint8_t* const*)pp;
  return o ? o + layout::kOffControllerType + 4 : 0;
}
static inline bool bq_common(int k, uint8_t* c, int i) {
  bool r = o_bindQ[k](c, i);
  uint8_t* s_p0 = player0_block();
  if (c != s_p0 || (unsigned)i >= 50) return r;
  // Capture (action 7, LB) must remain held while RT is firing. Native polling
  // can rebuild its buffer between updates, so answer from our own action history.
  if (i == 7 && c == g_vrActionBlock && g_vrActionKey[i] == 7 &&
      g_ctl.padEnabled && controllers_active() && !stereo_in_flat_mode()) {
    r = g_vrAction[i].query(k);
  }
  if (i < 2) {
    if (fire_active(i)) {                       // trigger held: the game sees the action as pressed
      uint8_t* e = c + 0x18 * i;
      DWORD age = GetTickCount() - g_trigStart[i];
      *(int32_t*)(e + 0xC) = 1; *(float*)(e + 0x14) = 1.0f; *(float*)(e + 0x10) = age < 50 ? 0.f : (float)age * 0.001f;
      g_dirty[i] = 1; g_dirtyAt[i] = GetTickCount();
      if (k == 0) r = true;                     // state == 1
      else if (k == 1) r = false;               // state == 2 (just released)
      else {                                    // state == 1 and hold time 0 (just pressed)
        r = age < 50;
        // 1.7.223: the Boson Dart (Secondary) launches on the game's "just pressed" answer; it was true for 50 ms only, and when the game's player update did not ask in that window (a long frame, the
        // stream busy) the dart made its sound and effect but never launched ("after each failed attempt it shoots"). Now a pull is guaranteed to be told "just pressed" at least ONCE (up to 400 ms
        // after the pull): pulls the game already saw in the first 50 ms behave exactly as before.
        if (i == 1) {
          if (r) InterlockedExchange(&g_secDelivered, 1);
          else if (!g_secDelivered && age < 400) { r = true; InterlockedExchange(&g_secDelivered, 1); ++g_secLate; }
        }
      }
    } else if (g_dirty[i] && GetTickCount() - g_dirtyAt[i] > 20) {
      uint8_t* e = c + 0x18 * i;                // trigger let go: finish the cycle 1 -> 2 -> 0 like the game does
      if (g_dirty[i] == 1) { *(int32_t*)(e + 0xC) = 2; *(float*)(e + 0x14) = 0.f; g_dirty[i] = 2; g_dirtyAt[i] = GetTickCount(); }
      else { *(int32_t*)(e + 0xC) = 0; *(float*)(e + 0x10) = 0.f; g_dirty[i] = 0; }
      r = o_bindQ[k](c, i);
    }
  }
  g_bqAsk[k][i]++; if (r) g_bqYes[k][i]++;
  return r;
}
long engine_secondary_asks(int k, long* yes) { if (yes) *yes = g_bqYes[k][1]; return g_bqAsk[k][1]; }   // 1.7.223
static bool hk_bq0(uint8_t* c, int i) { return bq_common(0, c, i); }
static bool hk_bq1(uint8_t* c, int i) { return bq_common(1, c, i); }
static bool hk_bq2(uint8_t* c, int i) { return bq_common(2, c, i); }

static BindQFn o_bindRel;
static LONG g_badBind, g_relCalls;
static bool hk_bind_release(uint8_t* c, int i) {
  ++g_relCalls;
  if ((unsigned)i < 50 && readable_bytes(c + 0x18 * i, 8)) {
    int32_t* e = (int32_t*)(c + 0x18 * i);
    if (e[0] == 3 && (uint32_t)e[1] >= 0x258) {   // would make the game end itself: use key 0 (unused) for this one call
      const int32_t keep = e[1];
      if (g_badBind < 20) log_line("BADBINDING block=%p index=%d kind=3 key=%d (>= 600): the game would have ended itself here (fast-fail 8); key 0 used for this call", (void*)c, i, (int)keep);
      ++g_badBind;
      e[1] = 0;
      const bool r = o_bindRel(c, i);
      e[1] = keep;
      return r;
    }
  }
  return o_bindRel(c, i);
}
static void dump_bind_table(const uint8_t* blk, const char* why) {
  if (!readable_bytes(blk, 50 * 24)) return;
  char line[1000]; int n = wsprintfA(line, "BINDTAB %s block=%p kind:code per action:", why, (const void*)blk);
  for (int c = 0; c < 50; ++c) {
    const uint8_t* e = blk + 0x18 * c;
    n += wsprintfA(line + n, " %d=%d:%d", c, (int)*(const int32_t*)e, (int)*(const int32_t*)(e + 4));
    if (n > 900) { log_line("%s", line); n = wsprintfA(line, "BINDTAB (cont.)"); }
  }
  log_line("%s", line);
}
static void hk_bind_update(uint8_t* blk, float dt) {
  stage_g(ST_G_BIND);
  uint8_t* p0 = player0_block();
  bool isP0 = blk && blk == p0;
  if (isP0) gamepad_type_keep();   // 1.7.86: shared with the game tick; no try limit (it was 400 per session), counted and logged
  // 0.46: actions bound to a pad button (kind 1, button 0..31, not the two trigger actions) get their state from our pad mask
  const bool mine = isP0 && g_ctl.padEnabled && controllers_active() && !stereo_in_flat_mode();
  if (mine && g_vrActionBlock != blk) {
    g_vrActionBlock = blk;
    for (int c = 0; c < 50; ++c) { g_vrAction[c] = binding::Action{}; g_vrActionKey[c] = 0; }
  } else if (!mine && isP0) {
    g_vrActionBlock = nullptr;
  }
  o_bindUpd(blk, dt);
  if (mine) {
    const uint32_t eff = (uint32_t)g_padNow | (uint32_t)InterlockedExchange(&g_padLatch, 0);
    for (int c = 2; c < 50; ++c) {
      uint8_t* e = blk + 0x18 * c;
      const int32_t kind = *(const int32_t*)e, idx = *(const int32_t*)(e + 4);
      if (kind != 1 || idx < 0 || idx > 31) { g_vrActionKey[c] = 0; continue; }
      static int8_t s_firstAct[32]; static bool s_firstInit;   // 1.4: several actions share a button (the Y button is actions 6, 25, 27 and 42); the log gets one line per button press, not four
      if (!s_firstInit) { for (int q = 0; q < 32; ++q) s_firstAct[q] = -1; s_firstInit = true; }
      if (s_firstAct[idx] < 0) s_firstAct[idx] = (int8_t)c;
      const bool logIt = s_firstAct[idx] == c;
      int32_t* st = (int32_t*)(e + 0xC); float* hold = (float*)(e + 0x10); float* an = (float*)(e + 0x14);
      const int key = idx + 1;
      if (g_vrActionKey[c] != key) { g_vrAction[c] = binding::Action{}; g_vrActionKey[c] = key; }
      binding::Action& action = g_vrAction[c];
      const int before = action.state;
      action.step(((eff >> idx) & 1) != 0, dt);
      *st = action.state; *hold = action.hold; *an = action.state == 1 ? 1.0f : 0.0f;
      if (action.state == 1) ++g_btnFrames[c];
      if (before != 1 && action.state == 1) ++g_btnPress[c];
      if (logIt && before != action.state && g_btnEvents < 1500) {
        ++g_btnEvents;
        log_line("BTNEVENT frame=%d action=%d button=%d state=%d held=%.3fs (private VR history)",
                 (int)g_ctl.worldFrames, c, idx, action.state, (double)action.hold);
      }
    }
  }
  for (int i = 0; i < 4; ++i) {
    if (g_bs[i].p == (uintptr_t)blk || !g_bs[i].p) {
      if (!g_bs[i].p) dump_bind_table(blk, "first update");
      g_bs[i].p = (uintptr_t)blk; g_bs[i].calls++;
      g_bs[i].cached = *(const int32_t*)(blk + 0x4cc); g_bs[i].slot = *(const int32_t*)(blk + 0x4bc);
      if (*(const int32_t*)(blk + 0xC)) g_bs[i].nat0++;
      if (*(const int32_t*)(blk + 0x18 + 0xC)) g_bs[i].nat1++;
      break;
    }
  }
  if (!isP0) return;
  ++g_blockCalls;
  for (int a = 0; a < 2; ++a) {                       // 0 Primary Action (RT), 1 Secondary Action (LT)
    uint8_t* e = blk + 0x18 * a;
    int32_t* st = (int32_t*)(e + 0xC);
    if (fire_active(a)) {
      DWORD age = GetTickCount() - g_trigStart[a];
      if (age < 50) ++g_forcedPress[a];
      *st = 1; *(float*)(e + 0x14) = 1.0f; *(float*)(e + 0x10) = age < 50 ? 0.f : (float)age * 0.001f;
      g_dirty[a] = 1; g_dirtyAt[a] = GetTickCount(); ++g_forcedFrames[a];
    } else if (g_dirty[a]) {
      if (g_dirty[a] == 1) { *st = 2; *(float*)(e + 0x14) = 0.f; g_dirty[a] = 2; }
      else { *st = 0; *(float*)(e + 0x10) = 0.f; g_dirty[a] = 0; }
      g_dirtyAt[a] = GetTickCount();
    }
  }
}
// 1.7.140: the game's achievement call with no Steam (game started outside Steam): skipped instead of crashing (layout.h kRvaStatsUnlock).
typedef bool (*StatsUnlockFn)(int);
static StatsUnlockFn o_statsUnlock;
static volatile LONG g_statsSkipped, g_statsPassed;
static bool hk_stats_unlock(int id) {
  void* const* mgr = (void* const*)rva(layout::kRvaStatsManager);
  if (!memory_readable(mgr, 8) || !*mgr) {
    const LONG n = InterlockedIncrement(&g_statsSkipped);
    if (n <= 5 || n % 50 == 0)
      log_line("STEAMSTATS achievement #%d skipped (%ld so far): the game has no Steam achievements (it was not started from Steam, SteamAPI_Init failed); the game would have crashed here. Start the game with Play in Steam to get achievements.", id, n);
    return false;
  }
  InterlockedIncrement(&g_statsPassed);
  return o_statsUnlock(id);
}
static void install_stats_guard() {
  if (!bytes_match(layout::kRvaStatsUnlock, layout::kBytesStatsUnlock, 16)) { log_line("STEAMSTATS guard not installed (bytes differ)"); return; }
  void* t = (void*)rva(layout::kRvaStatsUnlock);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_stats_unlock, (void**)&o_statsUnlock);
  if (s == MH_OK) s = MH_EnableHook(t);
  void* const* mgr = (void* const*)rva(layout::kRvaStatsManager);
  log_line("STEAMSTATS guard status=%d (0 = on); the game's Steam achievement manager is %s now", (int)s, memory_readable(mgr, 8) && *mgr ? "there" : "MISSING (no Steam: achievements are skipped instead of crashing the game)");
}
static void install_bind_hook() {
  if (!bytes_match(layout::kRvaBindUpdate, layout::kBytesBindUpdate, 16)) { g_bindHook = -1; log_line("BINDHOOK not available (bytes differ)"); return; }
  void* t = (void*)rva(layout::kRvaBindUpdate);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_bind_update, (void**)&o_bindUpd);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_bindHook = s == MH_OK ? 1 : -2;
  log_line("HOOK binding-update status=%d target=%p", (int)s, t);
  if (bytes_match(layout::kRvaBindRelease, layout::kBytesBindRelease, 16)) {
    void* tg = (void*)rva(layout::kRvaBindRelease);
    MH_STATUS r = MH_CreateHook(tg, (void*)hk_bind_release, (void**)&o_bindRel);
    if (r == MH_OK) r = MH_EnableHook(tg);
    log_line("HOOK binding-release status=%d (guards the game's own fast-fail 8)", (int)r);
  } else log_line("BINDHOOK release bytes differ");
  const uint32_t q[3] = {layout::kRvaBindQ0, layout::kRvaBindQ1, layout::kRvaBindQ2};
  const uint8_t* qb[3] = {layout::kBytesBindQ0, layout::kBytesBindQ1, layout::kBytesBindQ2};
  void* hk[3] = {(void*)hk_bq0, (void*)hk_bq1, (void*)hk_bq2};
  for (int k = 0; k < 3; ++k) {
    if (!bytes_match(q[k], qb[k], 16)) { log_line("BINDHOOK query %d bytes differ", k); continue; }
    void* tg = (void*)rva(q[k]);
    MH_STATUS r = MH_CreateHook(tg, hk[k], (void**)&o_bindQ[k]);
    if (r == MH_OK) r = MH_EnableHook(tg);
    log_line("HOOK binding-query %d status=%d", k, (int)r);
  }
}
static void bindings_report(LONG frame) {
  if (g_bindHook != 1) return;
  char line[900]; int n = wsprintfA(line, "BINDUPD frame=%d p0calls=%d typeFixes=%d forcedPress(RT,LT)=%d,%d forcedFrames=%d,%d trig(LT,RT)=%d,%d blocks:",
    (int)frame, (int)g_blockCalls, (int)g_ctOk, (int)g_forcedPress[0], (int)g_forcedPress[1], (int)g_forcedFrames[0], (int)g_forcedFrames[1], (int)g_trigLT, (int)g_trigRT);
  uint8_t* p0 = player0_block();
  for (int i = 0; i < 4 && g_bs[i].p; ++i)
    n += wsprintfA(line + n, " [%s calls=%d cachedType=%d padSlot=%d natState0=%d natState1=%d]", g_bs[i].p == (uintptr_t)p0 ? "player0" : "other",
                   (int)g_bs[i].calls, (int)g_bs[i].cached, (int)g_bs[i].slot, (int)g_bs[i].nat0, (int)g_bs[i].nat1);
  n += wsprintfA(line + n, " releaseCalls=%d badBindings=%d", (int)g_relCalls, (int)g_badBind);
  log_line("%s", line);
  static const char* nm[3] = {"held", "released", "justPressed"};
  for (int k = 0; k < 3; ++k) {
    char q[800]; int m = wsprintfA(q, "BINDQ %s (control ask/yes):", nm[k]);
    for (int i = 0; i < 50 && m < 740; ++i) if (g_bqAsk[k][i]) m += wsprintfA(q + m, " %d=%d/%d", i, (int)g_bqAsk[k][i], (int)g_bqYes[k][i]);
    log_line("%s", q);
  }
  char b[700]; int bn = wsprintfA(b, "BTNFORCE (action presses/frames written from the pad mask):");
  for (int i = 2; i < 50 && bn < 640; ++i) if (g_btnPress[i] || g_btnFrames[i]) bn += wsprintfA(b + bn, " %d=%d/%d", i, (int)g_btnPress[i], (int)g_btnFrames[i]);
  log_line("%s", b);
}

static void vpad_report(LONG frame) {
  if (!readable_bytes((void*)rva(layout::kRvaBtnArrayPtr), 8)) return;
  const uint8_t* v = *(const uint8_t* const*)rva(layout::kRvaBtnArrayPtr);
  if (!v || !readable_bytes(v, layout::kPadStride)) return;
  unsigned st = 0, ed = 0;
  for (int c = 0; c < 32; ++c) { if (*(const int32_t*)(v + 0x138 + 4 * c)) st |= 1u << c; if (*(const int32_t*)(v + 0xA4 + 4 * c)) ed |= 1u << c; }
  log_line("VPAD frame=%d at %p state=%d held=%08x edge=%08x axes=%d,%d,%d,%d lt=%d rt=%d", (int)frame, (const void*)v, *(const int32_t*)v, st, ed,
           (int)(*(const float*)(v + 0x44) * 100), (int)(*(const float*)(v + 0x48) * 100), (int)(*(const float*)(v + 0x4c) * 100),
           (int)(*(const float*)(v + 0x58) * 100), (int)(*(const float*)(v + 0x50) * 100), (int)(*(const float*)(v + 0x54) * 100));
}
static void headmove_report(LONG frame) {
  log_line("HEADMOVE frame=%d on=%d samples=%d clampedAxes=%d rangeM x=%.2f..%.2f y=%.2f..%.2f z=%.2f..%.2f", (int)frame, (int)g_ctl.headMove,
           (int)g_hm.n, (int)g_hm.clamped, (double)g_hm.mn[0], (double)g_hm.mx[0], (double)g_hm.mn[1], (double)g_hm.mx[1], (double)g_hm.mn[2], (double)g_hm.mx[2]);
}
static void btn_probe_report(LONG frame) {
  headmove_report(frame);
  controller_type_tick();
  bindings_report(frame);
  if (g_btnHook != 1) return;
  watch_tick(frame);
  char line[900]; int n = 0;
  n += wsprintfA(line + n, "BTNPROBE frame=%d", (int)frame);
  for (int c = 0; c < 32; ++c) {
    LONG a = g_btn.asked[0][c] + g_btn.asked[1][c] + g_btn.asked[2][c];
    if (!a) continue;
    n += wsprintfA(line + n, " c%d[ask=%d/%d/%d yes=%d/%d/%d]", c, (int)g_btn.asked[0][c], (int)g_btn.asked[1][c],
                   (int)g_btn.asked[2][c], (int)g_btn.yes[0][c], (int)g_btn.yes[1][c], (int)g_btn.yes[2][c]);
    if (n > 780) break;
  }
  log_line("%s", line);
  const uint8_t* base = (const uint8_t*)rva(layout::kRvaPadArray);
  const uint8_t* arrPtr = readable_bytes((void*)rva(layout::kRvaBtnArrayPtr), 8) ? *(const uint8_t* const*)rva(layout::kRvaBtnArrayPtr) : 0;
  int which = -1;
  for (int p = 0; p < 4; ++p) if (arrPtr == base + (size_t)p * layout::kPadStride) which = p;
  n = wsprintfA(line, "PADMEM frame=%d arrayPtrIsPad=%d", (int)frame, which);
  for (int p = 0; p < 2; ++p) {
    const uint8_t* q = base + (size_t)p * layout::kPadStride;
    if (!readable_bytes(q, layout::kPadStride)) continue;
    unsigned mask = 0;
    for (int c = 0; c < 32; ++c) if (*(const int32_t*)(q + 0x138 + 4 * c)) mask |= 1u << c;
    float lt = *(const float*)(q + 0x50), rt = *(const float*)(q + 0x54);
    n += wsprintfA(line + n, " pad%d[state=%d type=%d held=%08x lt=%d rt=%d]", p, *(const int32_t*)q, *(const int32_t*)(q + 4), mask,
                   (int)(lt * 100), (int)(rt * 100));
  }
  log_line("%s", line);
}

// Installed separately: if anything does not match, only this feature is off.
static void install_aim_hook() {
  int fn = bytes_match(layout::kRvaAimFieldSet, layout::kBytesAimFieldSet, 16);
  int calls = 1;
  for (uint32_t c : layout::kRvaAimWrapperCalls) {  // the 8 player-aim stores really go through the wrapper
    const uint8_t* p = (const uint8_t*)rva(c);
    if (p[0] != 0xe8 || (uintptr_t)(p + 5 + *(const int32_t*)(p + 1)) != rva(layout::kRvaAimWrapper)) calls = 0;
  }
  {  // the stream update reads the vector through the getter
    const uint8_t* p = (const uint8_t*)rva(layout::kRvaAimStreamRead);
    if (p[0] != 0xe8 || (uintptr_t)(p + 5 + *(const int32_t*)(p + 1)) != rva(layout::kRvaAimGetter)) calls = 0;
  }
  if (!fn || !calls) {
    g_aimHook = -1;
    log_line("HEADAIM not available (setter bytes=%d callSites=%d): the beam stays with the mouse", fn, calls);
    return;
  }
  void* t = (void*)rva(layout::kRvaAimFieldSet);
  MH_STATUS s = MH_CreateHook(t, (void*)hk_aim_set, (void**)&o_aimSet);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_aimHook = s == MH_OK ? 1 : -2;
  log_line("HOOK aim-direction-store status=%d target=%p (head aim: %s)", (int)s, t, g_aimHook == 1 ? "available" : "NOT available");
}

int head_aim_available() { return g_aimHook == 1; }

static void head_aim_report(LONG frame) {
  log_line("HEADAIM frame=%d on=%d hook=%d published=%d noPlayerActor=%d storeCalls=%d playerStores=%d replaced=%d stale=%d "
           "lastGameVsHeadDeg=%.2f worstDeg=%.2f lastGame=%.3f,%.3f,%.3f lastHead=%.3f,%.3f,%.3f",
           (int)frame, (int)g_ctl.headAim, g_aimHook, (int)g_aimSt.published, (int)g_aimSt.noActor, (int)g_aimSt.calls,
           (int)g_aimSt.playerCalls, (int)g_aimSt.overridden, (int)g_aimSt.stale, g_aimSt.lastDegX100 / 100.0,
           g_aimSt.worstDegX100 / 100.0, (double)g_aimSt.lastGame[0], (double)g_aimSt.lastGame[1], (double)g_aimSt.lastGame[2],
           (double)g_aimSt.lastHead[0], (double)g_aimSt.lastHead[1], (double)g_aimSt.lastHead[2]);
  log_line("TIP frame=%d hook=%d attachCalls=%d tipCalls=%d overridden=%d stale=%d lastMovedFeet=%.2f old=%.2f,%.2f,%.2f new=%.2f,%.2f,%.2f",
           (int)frame, g_tipHook, (int)g_tipSt.calls, (int)g_tipSt.tipCalls, (int)g_tipSt.overridden, (int)g_tipSt.stale,
           g_tipSt.lastDistX100 / 100.0, (double)g_tipSt.lastOld[0], (double)g_tipSt.lastOld[1], (double)g_tipSt.lastOld[2],
           (double)g_tipSt.lastNew[0], (double)g_tipSt.lastNew[1], (double)g_tipSt.lastNew[2]);
  log_line("TIPROT frame=%d row=2 applied=%d failed=%d", (int)frame, (int)g_tipRot.applied, (int)g_tipRot.failed);
  sfix_report(frame);
  log_line("BEAMSTRAIGHT frame=%d on=%d streamTipFetches=%d (player's %d) player stream updates=%d straightened=%d | the bend the game wanted (deg, worst of heading/pitch): mean %.2f max %.2f, over 2 deg %d, over 5 deg %d, over 10 deg %d, last heading %.1f pitch %.1f",
           (int)frame, (int)g_ctl.beamStraight, (int)g_beam.tipFetches, (int)g_beam.tipPlayer, (int)g_beam.calls, (int)g_beam.straightened,
           g_beam.calls ? (double)g_beam.sumAbsX100 / 100.0 / (double)g_beam.calls : 0.0, (double)g_beam.maxAbsX100 / 100.0, (int)g_beam.bentOver2, (int)g_beam.bentOver5, (int)g_beam.bentOver10,
           (double)g_beam.lastHX10 / 10.0, (double)g_beam.lastPX10 / 10.0);
  // STREAMANG: angles the game measured between the stream's aim and row 2 of the tip matrix (after TIPROT they should be ~0):
  // within5 = stream exactly on the aim, within30 = still on it, within60 = bent towards it, beyond60 = flies along row 2 only
  log_line("STREAMANG frame=%d hook=%d streamCalls=%d within5=%d within30=%d within60=%d beyond60=%d lastHeadingDeg=%.1f lastPitchDeg=%.1f "
           "worstDeg=%.1f lastLocal=%.3f,%.3f,%.3f", (int)frame, g_angHook, (int)g_tipRot.streamCalls, (int)g_tipRot.within5,
           (int)g_tipRot.within30, (int)g_tipRot.within60, (int)g_tipRot.beyond60, g_tipRot.lastHeadX10 / 10.0, g_tipRot.lastPitchX10 / 10.0,
           g_tipRot.worstX10 / 10.0, (double)g_tipRot.lastLocal[0], (double)g_tipRot.lastLocal[1], (double)g_tipRot.lastLocal[2]);
}
#endif

// ---- Install ----------------------------------------------------------------
static int install(const char* name, uint32_t r, void* detour, void** original) {
  void* target = (void*)rva(r);
  MH_STATUS s = MH_CreateHook(target, detour, original);
  if (s == MH_OK) s = MH_EnableHook(target);
  log_line("HOOK %s status=%d target=%p rva=%x", name, (int)s, target, r);
  return s == MH_OK;
}

int engine_install_hooks() {
  int ok = 1;
  ok &= install("camera-prepare", layout::kRvaCameraPrepare, (void*)hk_prepare, (void**)&o_prepare);
  ok &= install("basis", layout::kRvaBasisSetter, (void*)hk_basis, (void**)&o_basis);
  ok &= install("visibility-stage", layout::kRvaVisibilityStage, (void*)hk_visibility, (void**)&o_visibility);
  ok &= install("set-eye", layout::kRvaSetEye, (void*)hk_set_eye, (void**)&o_setEye);
  ok &= install("main-spatial", layout::kRvaMainSpatial, (void*)hk_main_spatial, (void**)&o_mainSpatial);
  ok &= install("set-near-far", layout::kRvaSetNearFar, (void*)hk_set_near_far, (void**)&o_setNearFar);
#if GBVR_HEADTRACK
  ok &= install("set-projection", layout::kRvaSetProjection, (void*)hk_set_projection, (void**)&o_setProjection);
  ok &= install("app-tick", layout::kRvaAppTick, (void*)hk_app_tick, (void**)&o_appTick);
  ok &= install("app-simulate", layout::kRvaAppSimulate, (void*)hk_app_simulate, (void**)&o_appSimulate);
#endif
  if (!ok) {
    MH_DisableHook(MH_ALL_HOOKS);
    log_line("ENGINE hook installation failed; all engine hooks disabled.");
  }
#if GBVR_HEADTRACK
  else {
    log_gamedir();   // 0.48
    install_body_hooks();
    install_mirror_hooks();   // 1.7.30
    install_aim_hook();
    install_prop_guard();   // 0.59
    install_wrangle_guard();   // 1.7.19
    install_stream_update_hook();   // 1.7.27
    install_slam_helper();     // 1.7.24
    install_tip_hook();   // 0.34
    install_wand_hook();  // 0.51
    install_pke_hooks();  // 0.94: the game's own PKE meter goes to the controller
    install_mat_push_hook();   // 1.7.72
    install_pke_setm_hook();   // 1.7.74
    install_tether_hook();     // 1.7.72
    install_rope_hook();       // 1.7.76
    install_set_xform_hook();  // 1.7.75
    arms_init();          // 0.57
    install_angles_watch();   // 0.45
    /* 1.7.25: the button-getter probe (a hook on every button query, only counters for the log) is no longer installed: BTNEVENT still logs what the game saw */
    install_bind_hook();  // 0.40
    install_stats_guard();   // 1.7.140
    install_boost_hook();  // 1.7.8: sprint = a plain speed boost
    install_knock_hook();  // 1.7.36: knock-down comfort
    install_goggles_hook();  // 1.7.9: the green PKE view while the PKE is in the hand
    install_stream_aim_hook();  // 1.7.10: the stream's aim read follows the gun (the view object's hit point is hooked at run time)
    damage_install();     // 0.76: +% beam damage on every enemy class
    xinput_bridge_install();   // 0.33
    hud_install();
  }
#endif
  return ok;
}

// Small, once-per-session-summary snapshot even when full diagnostics are off.
// It distinguishes a hook that did not run from a placement rejected for lack
// of an arm pair, without turning on the broad old diagnostic stream.
void engine_issue_report() {
#if GBVR_HEADTRACK
  log_line("PROPSTATUS wandPush=%ld placed=%ld exact=%ld fallback=%ld pkeDraw=%ld pkeUpdate=%ld pkePlaced=%ld pkeExact=%ld pkeFallback=%ld pkeNoAim=%ld pkeNotHeld=%ld pkeBad=%ld knockBack=%ld fallCalls=%ld fallBlocked=%ld bigHurt=%ld",
           g_wandSt.hookCalls, g_wandSt.applied, g_exactWand.used, g_exactWand.fallback,
           g_pk.collects, g_pk.updates, g_pk.placed, g_pk.exactUsed, g_pk.exactFallback,
           g_pk.noAim, g_pk.notHeld, g_pk.bad, g_kn.calls, g_kn.consumerCalls, g_kn.consumerIntercepts, g_knockEvents);
  damage_issue_report();   // 1.7.116: HEALTH30, the ring / bars / boss numbers (they were only in the developer's full-diagnostics log)
  {   // 1.7.64 always-on compact lines (a few numbers every 30 s): the PKE grip, the belt copy of the PKE, the player's health and the life bar on the gun
    float hf = -1.0f; const int hok = engine_player_health(&hf);
    log_line("HOSEFLICK 30 s summary: bend calls %ld, bent %ld, hose end not at the game's gun %ld, maths refused %ld, last bent pose held %ld (refused) + %ld (no fresh gun draw) times; the game's own pose is shown only after 0.15 s without a good bend",
             arms_hose_stat(0), arms_hose_stat(1), arms_hose_stat(3), arms_hose_stat(4), arms_hose_stat(5), arms_hose_stat(6));
    log_line("BODYHIDE 30 s summary: arms_only=%d arms_shoulders=%d body_whole=%d hide_belt_pke=%d | squash passes %ld, bones squashed in the last pass %ld, put back %ld, passes with no arms found %ld, bad point %ld | the Stay Puft scene's floating arms %ld (1.7.185: the legs, belt radio and trap showed in the 1.7.184 videos, this says whether the squash ran)",
             (int)g_ctl.armsOnly, (int)g_ctl.armsShoulders, (int)g_ctl.bodyWhole, (int)g_ctl.hideBeltPke, arms_collapse_stat(0), arms_collapse_stat(1), arms_collapse_stat(2), arms_collapse_stat(3), arms_collapse_stat(4), (long)g_sceneArms);
    log_line("STEPLAG 30 s summary (1.7.186, walking over an object / up steps): the eye is eased away from the actor's feet height; frames more than 0.3 ft apart %ld, most %.2f ft, now %.2f ft | held gun/PKE aims moved with the eased eye height %ld times | body eye-match cap raised for the lag in %ld arm passes (cap %d cm)",
             (long)g_stepLagFrames, (double)g_stepLagMaxMft * 0.001, eye_lag_ft(), (long)g_stepAimMoved, (long)g_stepCapRaised, (int)g_ctl.eyeShiftCapCm);
    log_line("BELTPKE hide_belt_pke=%d: arm passes that squashed the belt copy (cloth_pke) %ld | PKE grip heal=%d: self-check samples %ld, re-captured %ld, new pull-outs %ld, last difference %.1f cm, biggest %.1f cm, relation length %.1f cm, hand pair ok/missing %ld/%ld",
             (int)g_ctl.hideBeltPke, arms_pke_hide_passes(), (int)g_ctl.pkeGripHeal, (long)g_pk.healChecks, (long)g_pk.rebinds, (long)g_pk.rebindsDraw, g_pk.lastDeltaCm, g_pk.maxDeltaCm, g_pk.relLenCm, (long)g_pk.pairOk, (long)g_pk.pairMiss);
    log_line("GAMEFINGERS game_fingers=%d: the left hand fully kept the game's own finger pose in %d passes | the game's left finger bend now (total degrees): index %d, middle %d, ring %d, pinkie %d", (int)g_ctl.gameFingers, arms_left_finger_kept(), arms_left_finger_base_x10(1) / 10, arms_left_finger_base_x10(2) / 10, arms_left_finger_base_x10(3) / 10, arms_left_finger_base_x10(4) / 10);
    {   // 1.7.104 FINGERPOSE: per finger, per hand: the game's bend, the curl asked for, the bend drawn (total degrees), passes where that finger's pass stopped early
      static const char* const kN[5] = {"thumb", "index", "middle", "ring", "pinkie"};
      char lb[240], rb[240]; int ln = 0, rn = 0; lb[0] = rb[0] = 0;
      for (int f = 0; f < 5; ++f) {
        ln += log_fmt(lb + ln, sizeof(lb) - ln, "%s%s game %d ask %d drawn %d skip %ld", f ? " | " : "", kN[f], arms_left_finger_base_x10(f) / 10, arms_finger_tg_x10(1, f) / 10, arms_finger_final_x10(1, f) / 10, arms_finger_skips(1, f));
        rn += log_fmt(rb + rn, sizeof(rb) - rn, "%s%s game %d ask %d drawn %d skip %ld", f ? " | " : "", kN[f], arms_right_finger_base_x10(f) / 10, arms_finger_tg_x10(0, f) / 10, arms_finger_final_x10(0, f) / 10, arms_finger_skips(0, f));
      }
      log_line("FINGERPOSE (total degrees; ask = the curl asked for in %%, -100 = left to the game) LEFT: %s || RIGHT: %s || empty_fingers=%d, right-hand passes with the free-finger rules %ld", lb, rb, (int)g_ctl.emptyFingers, arms_finger_empty_passes());
    }
    {   // 1.7.104 LEFTHAND: how much the supporting hand slid along the barrel from one pass to the next (cm), standing / walking-or-sprinting. old = measured from the gun's last placement (1.7.103), new = from the same sample as the controllers, kept = what is drawn
      auto m = [](double sum, long n) { return n > 0 ? sum / (double)n : 0.0; };
      log_line("LEFTHAND fore_steady=%d (30 s window): standing %ld passes, mean step old %.2f / new %.2f / drawn %.2f cm, worst old %.1f / new %.1f / drawn %.1f cm, old-vs-new gap mean %.1f max %.1f cm | walking %ld passes, mean step old %.2f / new %.2f / drawn %.2f cm, worst old %.1f / new %.1f / drawn %.1f cm, old-vs-new gap mean %.1f max %.1f cm | hand not on the barrel %ld passes",
               (int)g_ctl.foreSteady, g_fg.n[0], m(g_fg.stepOld[0], g_fg.n[0]), m(g_fg.stepNew[0], g_fg.n[0]), m(g_fg.stepKept[0], g_fg.n[0]), g_fg.maxOld[0], g_fg.maxNew[0], g_fg.maxKept[0], m(g_fg.diffSum[0], g_fg.n[0]), g_fg.diffMax[0],
               g_fg.n[1], m(g_fg.stepOld[1], g_fg.n[1]), m(g_fg.stepNew[1], g_fg.n[1]), m(g_fg.stepKept[1], g_fg.n[1]), g_fg.maxOld[1], g_fg.maxNew[1], g_fg.maxKept[1], m(g_fg.diffSum[1], g_fg.n[1]), g_fg.diffMax[1], g_fg.offPasses);
      memset(&g_fg, 0, sizeof(g_fg));
    }
    {   // 1.7.105 GRAB (30 s window): the fore grab: times it took hold / let go (hand left the gun, grip released or gun put away), weapon or model changes that made it take hold again, passes holding, how far along the gun it took hold (% of the gun's length) and the gun it was holding
      log_line("GRAB fore_grab=%d (30 s window): took hold %ld, let go (hand pulled away) %ld, let go (grip/gun away) %ld, gun changed -> new hold %ld | holding %ld of %ld passes (%ld of them while walking or turning: the dead zone is wider and the slide smoother then, 1.7.110), longest hold %.1f s, total %.1f s | real slides along the barrel %ld | took hold on average %.0f%% along the gun (last %.0f%%) | last gun: item %d, %.1f cm long | pass counts in the arm solver while gripping %ld | 1.7.114 fore_near_cm=%d: passes the free hand was taken hold of by nearness %ld",
               (int)g_ctl.foreGrab, g_grab.grabs, g_grab.releasesFar, g_grab.releasesGrip, g_grab.modelResets, g_grab.heldPasses, g_grab.passes, g_grab.busyPasses, g_grab.longestS, g_grab.heldS, g_grab.slides,
               g_grab.fracN > 0 ? 100.0 * g_grab.fracSum / (double)g_grab.fracN : 0.0, 100.0 * g_grab.lastFrac, g_grab.lastItem, g_grab.lastL * 30.48, arms_grab_passes(), (int)g_ctl.foreNearCm, g_grab.nearPasses);
      {   // 1.7.116 NEARHAND: where a FREE left hand (no grip squeeze) hangs while the gun is drawn and the hand is along the barrel: passes per distance from the barrel line (cm). Tells whether the reach fits how you hold it.
        long tot = 0; for (int i = 0; i < 8; ++i) tot += g_grab.nearHist[i];
        log_line("NEARHAND fore_near_cm=%d (a free hand within this many cm of the barrel line takes hold of it by itself, lets go at 1.4 x; 0 = only with the grip squeezed) | free-hand passes along the barrel %ld, by distance from the barrel line: under 6 cm %ld, 6-10 %ld, 10-14 %ld, 14-18 %ld, 18-22 %ld, 22-28 %ld, 28-40 %ld, 40 and more %ld | passes held by this rule alone %ld",
                 (int)g_ctl.foreNearCm, tot, g_grab.nearHist[0], g_grab.nearHist[1], g_grab.nearHist[2], g_grab.nearHist[3], g_grab.nearHist[4], g_grab.nearHist[5], g_grab.nearHist[6], g_grab.nearHist[7], g_grab.nearPasses);
      }
      log_line("SIZES (1.7.110) world size %d%%, player height %d%%, game feet per metre %.3f (= %.3f x the standard), body drawn at %.3f x | hand distances follow it: under-barrel offset %d cm = %.3f ft, grab dead zone %.1f cm, reach %.0f / let go %.0f cm of real hand movement | walking/turning busy passes in the hold %ld",
               (int)g_ctl.worldPct, (int)g_ctl.sizePct, (double)g_headAim.fpm, (double)g_headAim.fpm / 3.28084, g_bodyMv.lastScaleX1000 * 0.001, (int)g_ctl.leftUnderCm, (double)g_ctl.leftUnderCm * 0.01 * (double)g_headAim.fpm,
               0.15 * 30.48, 1.00 * 30.48, 1.60 * 30.48, g_grab.busyPasses);
      log_line("FINGERANALOG finger_analog=%d | right: grip squeeze %d%% (analog axis seen %d), thumb touch %d (sensor seen %d), trigger touch %d (sensor seen %d), pointing %d, %ld passes (%ld pointing) | left: grip %d%% (analog %d), thumb touch %d (sensor %d), trigger touch %d (sensor %d), pointing %d, %ld passes (%ld pointing) | finger bend axis replaced by the knuckle line (right/left) %d/%d",  (int)g_ctl.fingerAnalog, g_fa.g[0], g_fa.anaSeen[0], g_fa.th[0], g_fa.thumbSeen[0], g_fa.tr[0], g_fa.trigSeen[0], g_fa.pt[0], g_fa.passes[0], g_fa.pointPasses[0], g_fa.g[1], g_fa.anaSeen[1], g_fa.th[1], g_fa.thumbSeen[1], g_fa.tr[1], g_fa.trigSeen[1], g_fa.pt[1], g_fa.passes[1], g_fa.pointPasses[1], arms_finger_axis_fixed(0), arms_finger_axis_fixed(1));
      log_line("HANDS111 grab_orbit_deg=%d grab_orbit_follow_pct=%d (where round the barrel the held hand sits; 110 = overhand from the top-left like the teaser) | two_hand_ref_cm=%d (tilt %.1f deg at that hand distance, follows the distance; 0 = fixed) | gun_finger_open_pct=%d (grip let go opens the gun hand's grip fingers; 0 = stay in the fist) | pke_align_pitch=%d pke_pitch_deg=%d | capture_tap=%d | health_style=%d ring_follow=%d | 1.7.113 two_hand_line=%d health_any=%d", (int)g_ctl.grabOrbitDeg, (int)g_ctl.grabOrbitFollowPct, (int)g_ctl.twoHandRefCm, 0.1 * (double)g_ctl.twoHandPitchDeci, (int)g_ctl.gunFingerOpenPct, (int)g_ctl.pkeAlignPitch, (int)g_ctl.pkePitchDeg, (int)g_ctl.captureTap, (int)g_ctl.healthStyle, (int)g_ctl.ringFollow, (int)g_ctl.twoHandLine, (int)g_ctl.healthAny);
      log_line("WRISTBEND (1.7.215) wrap-gripped left hand: %ld passes measured, wrist bend (hand pointing vs forearm) mean %.1f deg, max %.1f deg, limited in %ld passes, %ld of those by turning only the hand (limit 55 deg; the wrist moves so the palm stays on the barrel)", arms_bend_n(), arms_bend_mean_x10() / 10.0, arms_bend_max_x10() / 10.0, arms_bend_clamped(), arms_bend_fallback());
      log_line("GRABWRAP trigger_finger_deg=%d (gun hand index bend at a full pull, was 55) grab_wrap=%d grab_wrap_deg=%d: the held hand is wrapped round the barrel (palm on it, thumb to the muzzle, fingers round it) in %ld arm passes | fingers lean %.1f deg toward the muzzle, the hand sits %.1f deg round the barrel from underneath (+ = the left side) | wrap-grip finger pose is used while it holds (grab_wrap=0 brings back the 1.7.108 look)", (int)g_ctl.trigFingerDeg, (int)g_ctl.grabWrap, (int)g_ctl.grabWrapDeg, arms_wrap_passes(), arms_wrap_tilt_x10() / 10.0, arms_wrap_orbit_x10() / 10.0);
      { const int64_t keepOn = g_grab.onQ; const int keepItem = g_grab.lastItem; const double keepL = g_grab.lastL, keepFrac = g_grab.lastFrac; memset(&g_grab, 0, sizeof(g_grab)); g_grab.onQ = keepOn; g_grab.lastItem = keepItem; g_grab.lastL = keepL; g_grab.lastFrac = keepFrac; }
    }
    {   // 1.7.104 PKEALIGN: the meter's long side to the controller's centre plane (lean, degrees, + = left), how far the hand was turned, and the meter centre's sideways offset to the controller (cm, + = left)
      long pn = 0, pf = 0; double a[9] = {0};
      const int have = arms_align_info(&pn, &pf, a);
      log_line("PKEALIGN pke_align=%d: %s | passes %ld, could not align %ld | last pass: long side leaned %.1f deg -> %.1f deg (hand turned %.1f deg), long side %.1f deg above the controller's forward (pke_align_pitch=%d wants %.0f deg, now %.1f) | centre sideways %.1f -> %.1f cm (+ = left), forward %.1f cm, up %.1f cm (before the hand moved to put the centre on the controller; pke_centre=%d)",
               (int)g_ctl.pkeAlign, have ? "has run" : "not run yet (PKE not out, or hold not locked)", pn, pf, a[0], a[1], a[3], a[2], (int)g_ctl.pkeAlignPitch, (double)g_ctl.pkePitchDeg, a[8], a[4] * 30.48, a[5] * 30.48, a[6] * 30.48, a[7] * 30.48, (int)g_ctl.pkeCentre);
    }
    log_line("GUNBAR life bar on=%d player health read=%d value=%.0f%% | offsets forward/up/side = %d/%d/%d cm (side negative = left)", (int)g_ctl.gunHpBar, hok, hok ? (double)hf * 100.0 : -1.0, (int)g_ctl.gunHpFwdCm, (int)g_ctl.gunHpUpCm, (int)g_ctl.gunHpSideCm);
    log_line("GUNGAP summary t=%.0fs hide_gun_gap=%d gun_grip_heal=%d: %ld no-hand episodes, longest %.0f ms, %ld gun calls not drawn | gun grip re-captures per item %d/%d/%d/%d | PKE live grip=%d: relation followed %ld times, held back %ld, big jumps followed %ld; updated while steady %ld, kept while moving %ld | PKE clean hand=%d: stretched moments %ld of %ld, could not clean %ld | PKE pose through the game setter %ld (state %d) | gun: holds over 25 cm ignored %ld, first-draw calls not drawn %ld | hand bone cleaned R/L %ld/%ld",
             qpc_ms() / 1000.0, (int)g_ctl.hideGunGap, (int)g_ctl.gunGripHeal, g_gunGap.episodes, g_gunGap.maxMs, (long)g_wandSt.gapHidden, g_gunHeal[0].heals, g_gunHeal[1].heals, g_gunHeal[2].heals, g_gunHeal[3].heals,
             (int)g_ctl.pkeLiveGrip, g_pk.live.accepted, g_pk.live.held, g_pk.live.jumps, g_pk.calmN, g_pk.busyN, (int)g_ctl.pkeRigidHand, g_pk.handSpike, g_pk.handSpike + g_pk.handClean, g_pk.handRigidFail, (long)g_pkeSetCalls, g_pkeSetState, (long)g_gunFarHolds, (long)g_gunNoHoldHidden, arms_hand_cleaned(0), arms_hand_cleaned(1));
    {   // 1.7.172: the 1.7.170 float fixes, in the always-on log (their lines were only in the full-diagnostics log, so the 1.7.170 report could not show them)
      long mr = 0, ml = 0, mb = 0; const int mh = arms_mirror_info(&mr, &ml, &mb);
      log_line("AIMHOLD gun / PKE / arm placements that used the last good controller aim: short gaps (under 0.15 s) %ld, longer gaps (up to 1 s, moved with the player) %ld, no aim at all %ld | PKEREL: PKE kept in the hand by its last hold on the controller %ld times (hold known %d, taken %ld times, poses refused %ld)",
               (long)g_aimHeldReads, (long)g_aimLongHolds, (long)g_wandSt.noAim, (long)g_pkRel.holds, g_pkRel.ok, (long)g_pkRel.stored, (long)g_pkRel.refused);
      if (g_ctl.leftHanded || mr || mb) log_line("ARMSWAP left-handed=%d (1.7.174: the body's LEFT arm and hand are drawn holding the gun on your left controller, the right arm follows your right controller; the gun itself is placed as before): drawn right arm %ld / left arm %ld passes, not drawn (failed or no target) %ld%s", (int)g_ctl.leftHanded, mr, ml, mb, mh ? "" : " (arms not ready)");
    }
  }
#endif
}
// Called by the render thread every 180 presented frames.
void engine_periodic_report(LONG frame) {
#if GBVR_HEADTRACK
  static long lastBlocked = -1, lastSkipped = -1;
  if (frame == 180 || g_kn.consumerIntercepts != lastBlocked || g_kn.took != lastSkipped) {
    log_line("KNOCK frame=%d setting=%d hooks=%d/%d knockBack=%ld playerSkipped=%ld fallRequestsBlocked=%ld consumerCalls=%ld walkTicks=%ld active=%d strength=%.2f", (int)frame, (int)g_ctl.knockComfort, g_kn.hooked, g_kn.consumerHooked, g_kn.calls, g_kn.took, g_kn.consumerIntercepts, g_kn.consumerCalls, g_kn.walkTicks, (int)g_kn.active, engine_knock_strength());
    lastBlocked = g_kn.consumerIntercepts; lastSkipped = g_kn.took;
  }
#endif
  LONG mode = control_mode();
  log_line("ENGINECOUNTS frame=%d mode=%s centiDegrees=%d prepares=%d verified=%d otherCaller=%d basisCalls=%d "
           "basisMatched=%d modified=%d armedNoBasis=%d invalidBasis=%d applyVerify=%d/%d visibility=%d paired=%d "
           "pairedBasisMatch=%d pairedBasisDiffer=%d mathChecks=%d shaderModification=0",
           (int)frame, mode == MODE_HEAD ? "head" : mode == MODE_MANUAL ? "manual" : "off",
           mode == MODE_MANUAL ? (int)g_ctl.manualCentiDeg : 0, (int)g_st.prepareCalls, (int)g_st.verifiedPrepares,
           (int)g_st.otherCallerPrepares, (int)g_st.basisCalls, (int)g_st.basisMatched, (int)g_st.modifiedCalls,
           (int)g_st.armedWithoutBasis, (int)g_st.invalidBasis, (int)g_st.applyVerifyOK,
           (int)(g_st.applyVerifyOK + g_st.applyVerifyFail), (int)g_st.visibilityCalls, (int)g_st.visibilityPaired,
           (int)g_st.visibilityBasisMatch, (int)g_st.visibilityBasisDiffer, (int)g_st.mathChecks);
  log_line("FIRSTPERSONCOUNTS frame=%d on=%d height=%.2f forward=%.2f near=%.2f armed=%d applied=%d eyeVerify=%d/%d "
           "armedNoCall=%d spatialApplied=%d spatialVerify=%d/%d nearApplied=%d gateFails=%d suspendedFrames=%d",
           (int)frame, (int)g_ctl.firstPerson, g_ctl.eyeHeightCenti / 100.0, g_ctl.eyeForwardCenti / 100.0,
           g_ctl.nearCenti / 100.0, (int)g_st.eyeArmed, (int)g_st.eyeApplied, (int)g_st.eyeVerifyOK,
           (int)g_st.eyeApplied, (int)g_st.eyeArmedNoCall, (int)g_st.spatialApplied, (int)g_st.spatialVerifyOK,
           (int)g_st.spatialApplied, (int)g_st.nearApplied, (int)g_st.fpGateFails, (int)g_st.suspendedFrames);
  log_line("ENGINEMATH worstYawMathError=%.3g worstApplyError=%.3g samples=%d", g_worstMathError, g_worstApplyError,
           (int)g_samplesTaken);
#if GBVR_HEADTRACK
  if (g_ctl.firstPerson || g_ctl.stereoWanted) body_report(frame);
  mirror_report(frame);
  if (g_ctl.wallDiag && g_wall.total) log_line("WALLSUM frame=%d camera-distance frames watched=%d pulled in (below 75%% of what the spring wants)=%d (%.1f%%) episodes=%d pictures=%d lowest distance seen %.2f ft",
                                                  (int)frame, (int)g_wall.total, (int)g_wall.pulledFrames, 100.0 * (double)g_wall.pulledFrames / (double)g_wall.total, g_wall.events, g_wall.shots, (double)g_wall.minEver);
  if (g_ctl.stereoWanted && g_aimHook != 0) head_aim_report(frame);
  if (g_ctl.stereoWanted) { hud_report(); ring_assist_report(); }
  if (g_ctl.stereoWanted && xinput_bridge_available()) { controllers_report(frame); haptics_report(frame); wand_report(frame); gunspawn_report(frame); pke_report(frame); assist_report(frame); step_report(frame); arms_report(frame); damage_report(frame); btn_probe_report(frame); autopause_report(frame); vrmenu_report(frame); audio_report(frame); prof_report(frame); xinput_bridge_report(frame); handmodel_report(frame); }
#endif
  if (g_st.stereoArmed || g_ctl.stereoWanted)
    log_line("STEREOCOUNTS frame=%d armed=%d frames=%d left=%d right=%d incomplete=%d changedAfter=%d fovApplied=%d "
             "fovVerify=%d/%d yawAgree=%d yawDiffer=%d overlap=%d", (int)frame, (int)g_st.stereoArmed, (int)g_st.stereoFrames,
             (int)g_st.stereoEye[0], (int)g_st.stereoEye[1], (int)g_st.stereoIncomplete,
             (int)g_st.stereoPostVerifyFail, (int)g_st.fovApplied, (int)g_st.fovVerifyOK, (int)g_st.fovApplied,
             (int)g_st.stereoYawAgree, (int)g_st.stereoYawDiffer, (int)g_st.stereoOverlap);
#if GBVR_HEADTRACK
  if (g_ctl.chestCam || g_cc.frames || g_cc.noPair)
    log_line("CHESTCAM frame=%d setting=%d (needs the monitor view: %d) every=%d pairs, down %d cm, back %d cm, nearest %d cm | pictures prepared %ld, built %ld, asked but no pair state %ld, no gun aim (head direction used) %ld, pitch limited %ld | average yaw %.1f deg, pitch %.1f deg | the render side: see CHESTCAMPIC",
             (int)frame, (int)g_ctl.chestCam, (int)g_ctl.monitorView, (int)g_ctl.chestCamEvery, (int)g_ctl.chestCamDownCm, (int)g_ctl.chestCamBackCm, (int)g_ctl.chestCamNearCm,
             (long)g_st.stereoSpec, g_cc.frames, g_cc.noPair, g_cc.noAim, g_cc.pitchLimited,
             g_cc.frames ? g_cc.yawSum / (double)g_cc.frames * 180.0 / vm::kPi : 0.0, g_cc.frames ? g_cc.pitchSum / (double)g_cc.frames * 180.0 / vm::kPi : 0.0);
#endif
  if (g_st.stereoArmed || g_ctl.stereoWanted) {
    double stepFirst = g_st.stepSamples[0] ? g_st.stepSumMs[0] / g_st.stepSamples[0] : 0.0;
    double stepSecond = g_st.stepSamples[1] ? g_st.stepSumMs[1] / g_st.stepSamples[1] : 0.0;
    log_line("PAIRCOUNTS frame=%d pairMode=%d wide=%d firstEye=%d secondEyeReused=%d secondEyeNoState=%d wideApplied=%d "
             "ticks=%d ticksLifted=%d menuTicksLifted=%d menuFast=%d", (int)frame, (int)g_ctl.stereoPair, (int)g_ctl.stereoWide,
             (int)g_st.pairFirst, (int)g_st.pairReused, (int)g_st.pairNoState, (int)g_st.wideApplied, (int)g_st.tickCalls,
             (int)g_st.tickLifted, (int)g_st.menuTickLifted, (int)g_ctl.menuFast);
#if GBVR_HEADTRACK
    wrangle_report(frame);
    streamhud_report(frame);
    parity_report(frame); viewdraw_report(frame); pairhands_report(frame); gearshake_report(frame);
    sampler_report((long)frame);
    slam_helper_report(frame);
    weapons_report(frame);
    settings_profile_report(frame);
    log_line("PROPGUARD frame=%d hook=%d calls=%d caught=%d", (int)frame, g_propHook, (int)g_propSt.calls, (int)g_propSt.saved);
#endif
    log_line("TICKGAP frame=%d ticks=%d avgGapMs=%.2f maxGapMs=%.2f over50ms=%d capByteSetAtStart=%d pairTicksUncapped=%d menuFast=%d paused=%d frozen=%d menuOpen=%d", (int)frame,
             (int)g_st.tickGapN, g_st.tickGapN ? g_st.tickGapSumMs / g_st.tickGapN : 0.0, g_st.tickGapMaxMs, (int)g_st.tickGapOver50, (int)g_st.tickCapSet,
             (int)g_st.pairTickUncapped, (int)g_ctl.menuFast, g_appSeen && memory_readable((const uint8_t*)g_appSeen + layout::kAppPaused, 1) ? (int)*((const uint8_t*)g_appSeen + layout::kAppPaused) : -1,
#if GBVR_HEADTRACK
             engine_freeze_active(), vrmenu_is_open());
#else
             0, 0);
#endif
    g_st.tickGapSumMs = 0; g_st.tickGapMaxMs = 0; g_st.tickGapN = 0;
    // gameStepBefore...: the game's time step in force when that eye was prepared = how far the world had
    // moved since the previous eye. With "same moment" the second eye must show about 0.12 ms and
    // simulationsSkipped must follow shortTicks.
    log_line("SAMEMOMENT on=%d ticksAfterFirstEye=%d ticksAfterSecondEye=%d shortTicks=%d verified=%d skippedFeature=%d "
             "zeroStep=%d simulationsSkipped=%d keptForKeys=%d skipExpired=%d waitedForSecondEye=%d gameStepBeforeFirstEyeMs=%.3f gameStepBeforeSecondEyeMs=%.3f "
             "(samples %d/%d) lastShortTicks=%d lastNormalTicks=%d timeScale=%.3f maxFrameTicks=%d",
             (int)g_ctl.stereoSameMoment, (int)g_st.tickAfterFirst, (int)g_st.tickAfterSecond, (int)g_st.sameMoment,
             (int)g_st.sameMomentOK, (int)g_st.sameMomentSkipped, (int)g_st.sameMomentZero, (int)g_st.simSkipped,
             (int)g_st.simKeptForInput, (int)g_st.simSkipExpired, (int)g_st.drainBeforeSim, stepFirst, stepSecond, (int)g_st.stepSamples[0], (int)g_st.stepSamples[1],
             (int)g_st.shortTicksLast, (int)g_st.longTicksLast, (double)g_timeScaleSeen,
             g_game.hookBytesOK ? *(const volatile int32_t*)rva(layout::kRvaMaxFrameTicks) : 0);
    g_st.stepSumMs[0] = g_st.stepSumMs[1] = 0;
    InterlockedExchange(&g_st.stepSamples[0], 0);
    InterlockedExchange(&g_st.stepSamples[1], 0);
  }
}

DWORD engine_last_prepare_tid() { return g_lastTid; }

void engine_request_sample() { InterlockedExchange(&g_sampleRequest, 1); }
