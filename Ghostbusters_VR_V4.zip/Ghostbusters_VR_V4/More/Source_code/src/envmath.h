// 1.7.87 what the mod can tell about the player's PC setup, as plain facts and plain advice for the log (no Windows calls; tests/test_env.cpp).
#pragma once
#include <stdint.h>

namespace env {

// ---- graphics card ----------------------------------------------------------------------------------------------------------------
// SteamVR names the card the headset is attached to by its LUID (IVRSystem::GetOutputDevice). The game's own device must be on that card, otherwise
// the picture the game hands to SteamVR cannot be opened by it: the headset stays black. Seen on laptops with two cards (Windows "power saving" card
// for the game, the strong card for SteamVR) and on PCs where Windows' per-app graphics setting points the game at the wrong card.
enum { kGpuUnknown = 0, kGpuSame = 1, kGpuDifferent = 2 };

inline uint64_t luid_pack(uint32_t low, int32_t high) { return ((uint64_t)(uint32_t)high << 32) | low; }

inline int gpu_relation(uint64_t gameLuid, uint64_t vrLuid) {
  if (!gameLuid || !vrLuid) return kGpuUnknown;   // a LUID of 0 is "not answered"
  return gameLuid == vrLuid ? kGpuSame : kGpuDifferent;
}

inline const char* gpu_hint(int relation) {
  if (relation != kGpuDifferent) return "";
  return "The game is running on a different graphics card than the headset uses, so SteamVR cannot take the picture (black headset). "
         "Fix: Windows Settings > System > Display > Graphics > add ghost.exe (Browse to the game folder) > Options > High performance, then restart the game; "
         "on a laptop with two cards also set the same card for SteamVR (vrserver.exe / vrcompositor.exe) and for Virtual Desktop.";
}

// ---- Windows display scaling and window kind ----------------------------------------------------------------------------------------
inline int dpi_scale_pct(uint32_t dpi) { return dpi >= 48 ? (int)((dpi * 100u + 48u) / 96u) : 100; }

enum { kWinWindowed = 0, kWinBorderless = 1, kWinMaximized = 2 };
inline int window_kind(bool popupNoFrame, int winW, int winH, int monW, int monH) {
  const bool covers = monW > 0 && monH > 0 && winW >= monW && winH >= monH;
  if (!covers) return kWinWindowed;
  return popupNoFrame ? kWinBorderless : kWinMaximized;
}

// ---- Steam ---------------------------------------------------------------------------------------------------------------------
// Steam sets SteamAppId / SteamGameId for a game it starts. Without them the game was started by double-clicking ghost.exe: no Steam Input, no overlay.
inline const char* steam_note(int launchedBySteam, int overlayLoaded) {
  (void)overlayLoaded;
  if (launchedBySteam) return "";
  return "The game was not started from Steam (no SteamAppId). It still works, but Steam Input and the Steam overlay are missing and some "
         "checks cannot be made; start it with Play in Steam.";
}

}  // namespace env
