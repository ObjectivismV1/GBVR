// 0.23: make sure the game can always exit after the headset was used.
//
// Background: after the 0.21 tests (F4 = SteamVR scene session) a copy of
// ghost.exe stayed in the background when the game was closed, so the next
// install was refused ("the game is running") and the game would not start
// again. Runs that never started a SteamVR session exited normally.
//
// Once an OpenVR session has been requested in this run:
//  - ExitProcess is hooked. When the game exits, the render thread is told to
//    stop using OpenVR, the session is shut down in an orderly way (bounded
//    wait) and the process is then ended directly with the game's exit code.
//    At that point the game has finished its own shutdown work (it calls
//    ExitProcess last); only the DLL unload notifications are skipped, which
//    is where a hang would otherwise be possible.
//  - A small watchdog covers the case that the game never reaches ExitProcess:
//    if the game window has been destroyed and no frame was presented for 5
//    seconds, it does the same.
// Nothing here is installed in runs that never use F9 / F4.
#include "gbvr.h"
#include "MinHook.h"

#if GBVR_HEADTRACK

volatile LONG g_vrBusy;   // render thread is inside the probe's OpenVR section
volatile LONG g_vrStop;   // set at exit: the render thread must not start another OpenVR call

typedef VOID(WINAPI* PFN_ExitProcess)(UINT);
static PFN_ExitProcess o_exitProcess;
static volatile LONG g_armed, g_exitStarted;

static DWORD g_exitT0;
static void exit_note(const char* what) { log_line("EXIT +%u ms: %s", (unsigned)(GetTickCount() - g_exitT0), what); }

static DWORD WINAPI shutdown_thread(LPVOID) {
  // 0.42: the compositor must stop looking at our pictures before the process (and its textures) goes away
  vr_capi_clear_last_frame();
  vr_capi_overlay_hide();
  exit_note("overlay hidden, last frame cleared");
  Sleep(150);                       // let the compositor finish the frame it is showing
  vr_capi_shutdown();
  return 0;
}

static void vr_exit_cleanup(const char* why) {
  stage_r(ST_EXIT);
  settings_save_if_changed();  // 0.26: values changed by a key in the last seconds are not lost
  if (InterlockedExchange(&g_exitStarted, 1)) return;
  g_exitT0 = GetTickCount();
  safety_run_note("exiting");   // 0.44: a freeze from here on is a problem of closing, not of playing
  log_line("EXIT %s. session=\"%s\" renderThreadInVR=%d", why, vr_capi_status(), (int)g_vrBusy);
  menu_release();
  audio_shutdown();   // 0.69: the game's sound goes back to its volume at once
  InterlockedExchange(&g_vrStop, 1);
  for (int i = 0; i < 50 && g_vrBusy; ++i) Sleep(10);  // up to 0.5 s for the render thread to leave OpenVR
  if (g_vrBusy) {
    log_line("EXIT: the render thread is still inside a SteamVR call; skipping the orderly SteamVR shutdown.");
  } else {
    HANDLE t = CreateThread(nullptr, 0, shutdown_thread, nullptr, 0, nullptr);
    DWORD w = t ? WaitForSingleObject(t, 2000) : WAIT_FAILED;
    if (t) CloseHandle(t);
    log_line("EXIT: SteamVR session shutdown %s.", w == WAIT_OBJECT_0 ? "finished" : "did not finish within 2 s");
    exit_note("SteamVR shutdown step done");
  }
  // 0.42: give the graphics driver time to finish the frames already queued (about 3 frames at 30 FPS) before the
  // process, with its textures that the compositor shared, is removed; ending a process with GPU work in flight
  // is the usual cause of a screen that freezes for a few seconds.
  Sleep(250);
  exit_note("GPU grace period over");
  safety_run_end();   // 0.44: reached the end of an orderly close: the run marker goes
  log_flush();
}

// 1.7.9: who called ExitProcess (the 1.7.8 run ended by itself right after the pause-menu cycle; the caller says which part of the game asked to quit)
static void log_exit_caller() {
  typedef USHORT(WINAPI * PFN_Capture)(ULONG, ULONG, PVOID*, PULONG);
  HMODULE k = GetModuleHandleW(L"kernel32.dll");
  PFN_Capture cap = k ? (PFN_Capture)GetProcAddress(k, "RtlCaptureStackBackTrace") : nullptr;
  char ctx[340]; ctx[0] = 0;
  engine_exit_context(ctx, (int)sizeof(ctx));
  char b[520]; int n = 0; b[0] = 0;
  if (cap) {
    void* fr[14] = {};
    const USHORT got = cap(0, 14, fr, nullptr);
    const uintptr_t base = (uintptr_t)GetModuleHandleW(nullptr);
    for (int i = 0; i < got && n < 480; ++i) {
      const uintptr_t v = (uintptr_t)fr[i];
      if (v >= base && v < base + 0x4000000) n += wsprintfA(b + n, " ghost+%x", (unsigned)(v - base));
      else n += wsprintfA(b + n, " %p", fr[i]);
    }
  }
  b[n < (int)sizeof(b) ? n : (int)sizeof(b) - 1] = 0;
  log_line("EXITCALLER thread %lu, who called ExitProcess (innermost first, ghost+x = game address RVA):%s", (unsigned long)GetCurrentThreadId(), cap ? b : " (no stack trace here)");
  log_line("EXITSTATE %s", ctx);
}

static VOID WINAPI hk_ExitProcess(UINT code) {
  log_exit_caller();
  vr_exit_cleanup("game called ExitProcess");
  log_line("EXIT: ending the process now (exit code %u).", code);
  log_flush();
  TerminateProcess(GetCurrentProcess(), code);
  o_exitProcess(code);  // not reached
}

static DWORD WINAPI watchdog_thread(LPVOID) {
  LONG last = -1;
  int stale = 0;
  for (;;) {
    Sleep(500);
    if (g_exitStarted) return 0;
    LONG now = render_present_count();
    HWND w = g_ctl.gameHwnd;
    if (now != last || !w || IsWindow(w)) { last = now; stale = 0; continue; }
    if (++stale >= 10) break;  // window gone and no new frame for 5 s
  }
  vr_exit_cleanup("watchdog: the game window is gone and no frame was presented for 5 s");
  log_line("EXIT: ending the process so it does not stay in the background.");
  log_flush();
  TerminateProcess(GetCurrentProcess(), 0);
  return 0;
}

// 0.87: both crashes (0.85, 0.86) happened at the end of the first hotel cutscene, with the 0.85 file hook installed and in runs that never reached VR
// code, and neither run ever saw a single video open through it. That hook (every CreateFileW of the process) is gone. 0.84, which had no such hook,
// passed the same moment.
//
// Start-up videos: the optional hook below sits one level lower (ntdll NtCreateFile / NtOpenFile: every way of opening a file ends there). It is OFF
// unless skip_videos=1 in gbvr_settings.txt. When on, it logs the video files opened (VIDEOOPEN) and blocks every video except the in-game
// cutscenes (CS_*).
typedef LONG(NTAPI* PFN_NtCreateFile)(PHANDLE, ACCESS_MASK, void*, void*, void*, ULONG, ULONG, ULONG, ULONG, void*, ULONG);
typedef LONG(NTAPI* PFN_NtOpenFile)(PHANDLE, ACCESS_MASK, void*, void*, ULONG, ULONG);
static PFN_NtCreateFile o_ntCreateFile;
static PFN_NtOpenFile o_ntOpenFile;
static volatile LONG g_videoOpens, g_videoBlocked;
static DWORD g_videoT0;
struct NtUStr { USHORT Length, MaxLength; PWSTR Buffer; };
struct NtOA { ULONG Length; HANDLE Root; NtUStr* Name; ULONG Attr; void* SD; void* SQOS; };
static int wlower(wchar_t c) { return (c >= L'A' && c <= L'Z') ? c + 32 : c; }
static int ends_with(const wchar_t* s, size_t n, const wchar_t* ext) {
  size_t m = 0; while (ext[m]) ++m;
  if (n < m) return 0;
  for (size_t i = 0; i < m; ++i) if (wlower(s[n - m + i]) != ext[i]) return 0;
  return 1;
}
static int has_name(const wchar_t* s, size_t n, const wchar_t* pre) {   // the file name (after the last slash) starts with pre
  size_t b = n; while (b > 0 && s[b - 1] != L'\\' && s[b - 1] != L'/') --b;
  for (size_t i = 0; pre[i]; ++i) { if (b + i >= n || wlower(s[b + i]) != pre[i]) return 0; }
  return 1;
}
static int video_check(void* oa) {   // 1 = block this open
  const NtOA* a = (const NtOA*)oa;
  if (!a || !a->Name || !a->Name->Buffer) return 0;
  const size_t n = a->Name->Length / 2;
  const wchar_t* name = a->Name->Buffer;
  if (n < 5 || n > 520) return 0;
  if (!(ends_with(name, n, L".mp4") || ends_with(name, n, L".ogv") || ends_with(name, n, L".bik") || ends_with(name, n, L".webm") || ends_with(name, n, L".wmv") || ends_with(name, n, L".avi") || ends_with(name, n, L".mov"))) return 0;
  const int promo = !has_name(name, n, L"cs_");
  const LONG k = InterlockedIncrement(&g_videoOpens);
  crumb("video:open", (int)k);
  if (k <= 60) {
    wchar_t tmp[300]; size_t m = n < 299 ? n : 299; for (size_t i = 0; i < m; ++i) tmp[i] = name[i]; tmp[m] = 0;
    log_line("VIDEOOPEN #%d %ls at %lu ms after start%s", (int)k, tmp, (unsigned long)(GetTickCount() - g_videoT0), (promo && g_ctl.skipVideos) ? " -> BLOCKED (skip_videos)" : "");
  }
  if (promo && g_ctl.skipVideos) { InterlockedIncrement(&g_videoBlocked); return 1; }
  return 0;
}
static LONG NTAPI hk_NtCreateFile(PHANDLE h, ACCESS_MASK acc, void* oa, void* iosb, void* alloc, ULONG attr, ULONG share, ULONG disp, ULONG opts, void* ea, ULONG eal) {
  if (video_check(oa)) return (LONG)0xC0000034;   // STATUS_OBJECT_NAME_NOT_FOUND
  return o_ntCreateFile(h, acc, oa, iosb, alloc, attr, share, disp, opts, ea, eal);
}
static LONG NTAPI hk_NtOpenFile(PHANDLE h, ACCESS_MASK acc, void* oa, void* iosb, ULONG share, ULONG opts) {
  if (video_check(oa)) return (LONG)0xC0000034;
  return o_ntOpenFile(h, acc, oa, iosb, share, opts);
}
void videoguard_arm() {
  static volatile LONG once;
  if (InterlockedCompareExchange(&once, 1, 0) != 0) return;
  g_videoT0 = GetTickCount();
  if (!g_ctl.skipVideos) { log_line("VIDEOGUARD off (skip_videos=0): no file hook installed"); return; }
  HMODULE nt = GetModuleHandleW(L"ntdll.dll");
  void* t1 = nt ? (void*)GetProcAddress(nt, "NtCreateFile") : nullptr;
  void* t2 = nt ? (void*)GetProcAddress(nt, "NtOpenFile") : nullptr;
  MH_STATUS s1 = MH_ERROR_FUNCTION_NOT_FOUND, s2 = MH_ERROR_FUNCTION_NOT_FOUND;
  if (t1) { s1 = MH_CreateHook(t1, (void*)hk_NtCreateFile, (void**)&o_ntCreateFile); if (s1 == MH_OK) s1 = MH_EnableHook(t1); }
  if (t2) { s2 = MH_CreateHook(t2, (void*)hk_NtOpenFile, (void**)&o_ntOpenFile); if (s2 == MH_OK) s2 = MH_EnableHook(t2); }
  log_line("VIDEOGUARD on (ntdll NtCreateFile status=%d, NtOpenFile status=%d): every video the game opens is logged, all but CS_* cutscenes are blocked", (int)s1, (int)s2);
}
void videoguard_report() { log_line("VIDEOGUARD videosOpened=%d blocked=%d skip_videos=%d", (int)g_videoOpens, (int)g_videoBlocked, (int)g_ctl.skipVideos); }

// 0.87 EXIT SPY: whoever ends the process (the game itself, a fail-fast, the system) is written down first: the call, the exit code, the place in
// ghost.exe it came from and the last black-box steps. Hooks only the exit functions, which nothing calls during play.
typedef LONG(NTAPI* PFN_NtTerminateProcess)(HANDLE, LONG);
typedef VOID(NTAPI* PFN_RtlExitUserProcess)(LONG);
typedef VOID(WINAPI* PFN_RaiseFailFast)(void*, void*, ULONG);
static PFN_NtTerminateProcess o_ntTerm;
static PFN_RtlExitUserProcess o_rtlExit;
static PFN_RaiseFailFast o_failFast;
static volatile LONG g_spyN;
static void exit_spy_note(const char* api, LONG code, void* ret, HANDLE h) {
  if (InterlockedIncrement(&g_spyN) > 6) return;
  uintptr_t rr = (uintptr_t)ret;
  char where[160];
  if (rr > g_game.base && rr < g_game.base + g_game.sizeOfImage) log_fmt(where, sizeof(where), "ghost.exe+0x%llx", (unsigned long long)(rr - g_game.base));
  else {
    HMODULE hm = nullptr; char path[260]; path[0] = 0;
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)rr, &hm) && hm) GetModuleFileNameA(hm, path, sizeof(path));
    const char* nm = path; for (const char* c = path; *c; ++c) if (*c == '\\' || *c == '/') nm = c + 1;
    log_fmt(where, sizeof(where), "%s+0x%llx", nm, (unsigned long long)(rr - (uintptr_t)hm));
  }
  crumb("EXITSPY", (int)code);
  log_line("EXITSPY %s code=%ld(0x%08lx) handle=%p thread=%u from %s present=%d worldFrames=%d", api, (long)code, (unsigned long)code, (void*)h, (unsigned)GetCurrentThreadId(), where, (int)render_present_count(), (int)g_ctl.worldFrames);
  // code addresses on this thread's stack (game only)
  char buf[420]; int len = 0, found = 0;
  const uintptr_t* sp = (const uintptr_t*)__builtin_frame_address(0);
  for (int i = 0; i < 400 && found < 24; ++i) {
    { MEMORY_BASIC_INFORMATION mbi; if (VirtualQuery(sp + i, &mbi, sizeof(mbi)) != sizeof(mbi) || mbi.State != MEM_COMMIT || (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS))) break; }
    const uintptr_t v = sp[i];
    if (v > g_game.base && v < g_game.base + g_game.sizeOfImage) { len += log_fmt(buf + len, (int)sizeof(buf) - len, " +0x%llx", (unsigned long long)(v - g_game.base)); ++found; }
  }
  buf[len < (int)sizeof(buf) ? len : (int)sizeof(buf) - 1] = 0;
  log_line("EXITSPY ghost.exe return addresses on the stack:%s", buf);
  log_flush();
}
static LONG NTAPI hk_NtTerminateProcess(HANDLE h, LONG code) {
  if (h == (HANDLE)(intptr_t)-1 || h == GetCurrentProcess()) exit_spy_note("NtTerminateProcess(self)", code, __builtin_return_address(0), h);
  return o_ntTerm(h, code);
}
static VOID NTAPI hk_RtlExitUserProcess(LONG code) {
  exit_spy_note("RtlExitUserProcess", code, __builtin_return_address(0), nullptr);
  o_rtlExit(code);
}
static VOID WINAPI hk_RaiseFailFast(void* rec, void* ctx, ULONG flags) {
  exit_spy_note("RaiseFailFastException", 0, __builtin_return_address(0), nullptr);
  o_failFast(rec, ctx, flags);
}
void exit_spy_arm() {
  static volatile LONG once;
  if (InterlockedCompareExchange(&once, 1, 0) != 0) return;
  HMODULE nt = GetModuleHandleW(L"ntdll.dll"), kb = GetModuleHandleW(L"kernelbase.dll");
  void* t1 = nt ? (void*)GetProcAddress(nt, "NtTerminateProcess") : nullptr;
  void* t2 = nt ? (void*)GetProcAddress(nt, "RtlExitUserProcess") : nullptr;
  void* t3 = kb ? (void*)GetProcAddress(kb, "RaiseFailFastException") : nullptr;
  MH_STATUS s1 = MH_ERROR_FUNCTION_NOT_FOUND, s2 = s1, s3 = s1;
  if (t1) { s1 = MH_CreateHook(t1, (void*)hk_NtTerminateProcess, (void**)&o_ntTerm); if (s1 == MH_OK) s1 = MH_EnableHook(t1); }
  if (t2) { s2 = MH_CreateHook(t2, (void*)hk_RtlExitUserProcess, (void**)&o_rtlExit); if (s2 == MH_OK) s2 = MH_EnableHook(t2); }
  if (t3) { s3 = MH_CreateHook(t3, (void*)hk_RaiseFailFast, (void**)&o_failFast); if (s3 == MH_OK) s3 = MH_EnableHook(t3); }
  log_line("EXITSPY armed (NtTerminateProcess=%d RtlExitUserProcess=%d RaiseFailFastException=%d): whoever ends the game is written to the log first", (int)s1, (int)s2, (int)s3);
}

void exit_guard_arm() {
  if (InterlockedCompareExchange(&g_armed, 1, 0) != 0) return;
  HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
  void* target = k32 ? (void*)GetProcAddress(k32, "ExitProcess") : nullptr;
  MH_STATUS s = MH_ERROR_FUNCTION_NOT_FOUND;
  if (target) {
    s = MH_CreateHook(target, (void*)hk_ExitProcess, (void**)&o_exitProcess);
    if (s == MH_OK) s = MH_EnableHook(target);
  }
  HANDLE t = CreateThread(nullptr, 0, watchdog_thread, nullptr, 0, nullptr);
  log_line("EXITGUARD armed: ExitProcess hook status=%d watchdog=%d", (int)s, t != nullptr);
  if (t) CloseHandle(t);
}

#endif
