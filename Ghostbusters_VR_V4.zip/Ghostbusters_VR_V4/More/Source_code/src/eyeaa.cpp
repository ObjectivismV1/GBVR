// 1.7.153 "Smooth edges" (anti-aliasing) for the headset pictures. Off by default (eye_aa = 0, VR menu > View).
//
// The game draws each eye without usable edge smoothing at VR sizes, so thin lines and edges crawl. This pass runs on the finished eye picture, on the
// graphics card, right after the picture was copied for the headset:
//   eye picture (the copy the mod already owns) --[one full-screen draw: edge smoothing + a light sharpening]--> a second picture, which goes to the headset.
// The smoothing is the usual fast post-process kind (the approach of FXAA: where the brightness changes sharply, blend along the edge's direction);
// the sharpening afterwards gives back the fine detail that any such filter softens, limited to the brightness range of the neighbours (no halos).
// It is NOT DLSS / FSR 2: those need motion vectors and depth from inside the game's renderer, which a wrapper around Direct3D does not get.
//
// Safety, as in flatview.cpp: the game's own pictures and back buffer are never written; every piece of Direct3D state touched is saved and put back;
// shaders are compiled at first use with d3dcompiler_47.dll (part of Windows); if anything fails three times the option switches itself off and the
// headset gets the plain pictures exactly as before (log EYEAA). The PC window, the chest camera and screenshots keep using the plain pictures.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include <d3d11.h>
#include <d3dcompiler.h>

namespace {
const char* kShader =
  "Texture2D T : register(t0);\n"
  "SamplerState S : register(s0);\n"
  "struct VO { float4 pos : SV_Position; float2 uv : TEXCOORD0; };\n"
  "VO VSMain(uint id : SV_VertexID) {\n"
  "  VO o;\n"
  "  float2 p = float2((id << 1) & 2, id & 2);\n"
  "  o.uv = p;\n"
  "  o.pos = float4(p.x * 2.0 - 1.0, 1.0 - p.y * 2.0, 0.0, 1.0);\n"
  "  return o;\n"
  "}\n"
  "float luma(float3 c) {\n"
  "#if LIN\n"
  "  c = sqrt(saturate(c));\n"
  "#endif\n"
  "  return dot(c, float3(0.299, 0.587, 0.114));\n"
  "}\n"
  "float4 PSMain(VO i) : SV_Target {\n"
  "  float w, h;\n"
  "  T.GetDimensions(w, h);\n"
  "  float2 px = 1.0 / float2(w, h);\n"
  "  float4 cM4 = T.SampleLevel(S, i.uv, 0);\n"
  "  float3 cM = cM4.rgb;\n"
  "  float3 cNW = T.SampleLevel(S, i.uv + float2(-1.0, -1.0) * px, 0).rgb;\n"
  "  float3 cNE = T.SampleLevel(S, i.uv + float2( 1.0, -1.0) * px, 0).rgb;\n"
  "  float3 cSW = T.SampleLevel(S, i.uv + float2(-1.0,  1.0) * px, 0).rgb;\n"
  "  float3 cSE = T.SampleLevel(S, i.uv + float2( 1.0,  1.0) * px, 0).rgb;\n"
  "  float lM = luma(cM), lNW = luma(cNW), lNE = luma(cNE), lSW = luma(cSW), lSE = luma(cSE);\n"
  "  float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));\n"
  "  float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));\n"
  "  float3 o = cM;\n"
  "  if (lMax - lMin >= max(0.0312, lMax * 0.125)) {\n"
  "    float2 dir = float2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));\n"
  "    float reduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);\n"
  "    float inv = 1.0 / (min(abs(dir.x), abs(dir.y)) + reduce);\n"
  "    dir = clamp(dir * inv, -8.0, 8.0) * px;\n"
  "    float3 a = 0.5 * (T.SampleLevel(S, i.uv + dir * (1.0 / 3.0 - 0.5), 0).rgb + T.SampleLevel(S, i.uv + dir * (2.0 / 3.0 - 0.5), 0).rgb);\n"
  "    float3 b = a * 0.5 + 0.25 * (T.SampleLevel(S, i.uv - dir * 0.5, 0).rgb + T.SampleLevel(S, i.uv + dir * 0.5, 0).rgb);\n"
  "    float lB = luma(b);\n"
  "    o = (lB < lMin || lB > lMax) ? a : b;\n"
  "  } else {\n"
  "    float3 lo = min(cM, min(min(cNW, cNE), min(cSW, cSE)));\n"
  "    float3 hi = max(cM, max(max(cNW, cNE), max(cSW, cSE)));\n"
  "    float3 s = cM + (cM - 0.25 * (cNW + cNE + cSW + cSE)) * SHARP;\n"
  "    o = clamp(s, lo, hi);\n"
  "  }\n"
  "  return float4(o, cM4.a);\n"
  "}\n";

ID3D11Device* g_dev;                       // device the resources below belong to (no reference kept)
ID3D11VertexShader* g_vs;
ID3D11PixelShader* g_ps;
ID3D11SamplerState* g_smp;
ID3D11RasterizerState* g_rs;
ID3D11DepthStencilState* g_ds;
ID3D11BlendState* g_bs;
ID3D11Texture2D* g_out[2];
ID3D11RenderTargetView* g_rtv[2];
ID3D11ShaderResourceView* g_srv[2];
ID3D11Texture2D* g_srvOf[2];               // the source texture g_srv[e] was made for (compared only, no reference)
UINT g_w, g_h;
DXGI_FORMAT g_fmt;
int g_state;                               // 0 not tried, 1 ready, <0 failed (why)
int g_builtSharp = -1, g_builtLin = -1;
int g_failures, g_logged;
volatile LONG g_valid[2];                  // the filtered picture of this eye is the current one
struct { volatile LONG draws, offFrames, failed, rebuilt; double msSum; LONG msN; double msMax; } g_as;

template <class T> void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

void release_targets() {
  for (int e = 0; e < 2; ++e) { rel(g_rtv[e]); rel(g_srv[e]); rel(g_out[e]); g_srvOf[e] = nullptr; g_valid[e] = 0; }
  g_w = g_h = 0; g_fmt = DXGI_FORMAT_UNKNOWN;
}
void release_all() {
  rel(g_vs); rel(g_ps); rel(g_smp); rel(g_rs); rel(g_ds); rel(g_bs);
  release_targets();
  g_dev = nullptr; g_state = 0; g_builtSharp = g_builtLin = -1;
}

int create_resources(ID3D11Device* dev, int linear, int sharpPct) {
  HMODULE lib = LoadLibraryW(L"d3dcompiler_47.dll");
  if (!lib) return -1;
  pD3DCompile compile = (pD3DCompile)GetProcAddress(lib, "D3DCompile");
  if (!compile) return -2;
  char sharp[16];
  wsprintfA(sharp, "%d.%02d", sharpPct / 100, sharpPct % 100);
  const D3D_SHADER_MACRO defs[] = {{"LIN", linear ? "1" : "0"}, {"SHARP", sharp}, {nullptr, nullptr}};
  ID3DBlob *vsb = nullptr, *psb = nullptr, *err = nullptr;
  HRESULT h = compile(kShader, lstrlenA(kShader), "gbvr_eyeaa", defs, nullptr, "VSMain", "vs_4_0", 0, 0, &vsb, &err);
  if (FAILED(h) || !vsb) {
    if (err) { log_line("EYEAA vertex shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    return -3;
  }
  if (err) { err->Release(); err = nullptr; }
  h = compile(kShader, lstrlenA(kShader), "gbvr_eyeaa", defs, nullptr, "PSMain", "ps_4_0", 0, 0, &psb, &err);
  if (FAILED(h) || !psb) {
    if (err) { log_line("EYEAA pixel shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    vsb->Release();
    return -4;
  }
  if (err) { err->Release(); err = nullptr; }
  int rc = 0;
  if (FAILED(dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs))) rc = -5;
  else if (FAILED(dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps))) rc = -6;
  vsb->Release(); psb->Release();
  if (rc) return rc;
  D3D11_SAMPLER_DESC sd;
  ZeroMemory(&sd, sizeof(sd));
  sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
  sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
  sd.ComparisonFunc = D3D11_COMPARISON_NEVER; sd.MaxLOD = D3D11_FLOAT32_MAX;
  if (FAILED(dev->CreateSamplerState(&sd, &g_smp))) return -7;
  D3D11_RASTERIZER_DESC rd;
  ZeroMemory(&rd, sizeof(rd));
  rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
  if (FAILED(dev->CreateRasterizerState(&rd, &g_rs))) return -8;
  D3D11_DEPTH_STENCIL_DESC dd;
  ZeroMemory(&dd, sizeof(dd));
  dd.DepthEnable = FALSE; dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO; dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
  dd.StencilEnable = FALSE; dd.StencilReadMask = 0xff; dd.StencilWriteMask = 0xff;
  dd.FrontFace.StencilFailOp = dd.FrontFace.StencilDepthFailOp = dd.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
  dd.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
  dd.BackFace = dd.FrontFace;
  if (FAILED(dev->CreateDepthStencilState(&dd, &g_ds))) return -9;
  D3D11_BLEND_DESC bl;
  ZeroMemory(&bl, sizeof(bl));
  bl.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
  if (FAILED(dev->CreateBlendState(&bl, &g_bs))) return -10;
  return 1;
}

int ensure_targets(ID3D11Device* dev, const D3D11_TEXTURE2D_DESC& d) {
  if (g_out[0] && g_out[1] && g_rtv[0] && g_rtv[1] && d.Width == g_w && d.Height == g_h && d.Format == g_fmt) return 1;
  release_targets();
  D3D11_TEXTURE2D_DESC t;
  ZeroMemory(&t, sizeof(t));
  t.Width = d.Width; t.Height = d.Height; t.MipLevels = 1; t.ArraySize = 1; t.Format = d.Format;
  t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT; t.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
  for (int e = 0; e < 2; ++e) {
    HRESULT h = dev->CreateTexture2D(&t, nullptr, &g_out[e]);
    if (SUCCEEDED(h)) h = dev->CreateRenderTargetView(g_out[e], nullptr, &g_rtv[e]);
    if (FAILED(h)) { release_targets(); log_line("EYEAA picture %u x %u format=%d could not be made: %08x", d.Width, d.Height, (int)d.Format, (unsigned)h); return 0; }
  }
  g_w = d.Width; g_h = d.Height; g_fmt = d.Format;
  return 1;
}

struct Saved {
  ID3D11RenderTargetView* rtv[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT]; ID3D11DepthStencilView* dsv;
  D3D11_VIEWPORT vp[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE]; UINT nvp;
  ID3D11RasterizerState* rs; ID3D11BlendState* bs; float bf[4]; UINT mask; ID3D11DepthStencilState* ds; UINT sref;
  ID3D11InputLayout* il; D3D11_PRIMITIVE_TOPOLOGY topo;
  ID3D11VertexShader* vs; ID3D11PixelShader* ps; ID3D11GeometryShader* gs; ID3D11HullShader* hs; ID3D11DomainShader* dsh;
  ID3D11ShaderResourceView* srv; ID3D11SamplerState* smp;
};
void save(ID3D11DeviceContext* c, Saved* s) {
  ZeroMemory(s, sizeof(*s));
  c->OMGetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, s->rtv, &s->dsv);
  s->nvp = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
  c->RSGetViewports(&s->nvp, s->vp);
  c->RSGetState(&s->rs);
  c->OMGetBlendState(&s->bs, s->bf, &s->mask);
  c->OMGetDepthStencilState(&s->ds, &s->sref);
  c->IAGetInputLayout(&s->il);
  c->IAGetPrimitiveTopology(&s->topo);
  c->VSGetShader(&s->vs, nullptr, nullptr);
  c->PSGetShader(&s->ps, nullptr, nullptr);
  c->GSGetShader(&s->gs, nullptr, nullptr);
  c->HSGetShader(&s->hs, nullptr, nullptr);
  c->DSGetShader(&s->dsh, nullptr, nullptr);
  c->PSGetShaderResources(0, 1, &s->srv);
  c->PSGetSamplers(0, 1, &s->smp);
}
void restore(ID3D11DeviceContext* c, Saved* s) {
  c->OMSetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, s->rtv, s->dsv);
  c->RSSetViewports(s->nvp, s->vp);
  c->RSSetState(s->rs);
  c->OMSetBlendState(s->bs, s->bf, s->mask);
  c->OMSetDepthStencilState(s->ds, s->sref);
  c->IASetInputLayout(s->il);
  c->IASetPrimitiveTopology(s->topo);
  c->VSSetShader(s->vs, nullptr, 0);
  c->PSSetShader(s->ps, nullptr, 0);
  c->GSSetShader(s->gs, nullptr, 0);
  c->HSSetShader(s->hs, nullptr, 0);
  c->DSSetShader(s->dsh, nullptr, 0);
  c->PSSetShaderResources(0, 1, &s->srv);
  c->PSSetSamplers(0, 1, &s->smp);
  for (int i = 0; i < D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT; ++i) rel(s->rtv[i]);
  rel(s->dsv); rel(s->rs); rel(s->bs); rel(s->ds); rel(s->il);
  rel(s->vs); rel(s->ps); rel(s->gs); rel(s->hs); rel(s->dsh); rel(s->srv); rel(s->smp);
}

void fail(const char* why, int code) {
  InterlockedIncrement(&g_as.failed);
  ++g_failures;
  if (g_logged < 6) { ++g_logged; log_line("EYEAA problem: %s (%d), failure %d of 3", why, code, g_failures); }
  if (g_failures >= 3) {
    InterlockedExchange(&g_ctl.eyeAa, 0);
    log_line("EYEAA switched OFF after three problems: the headset gets the plain pictures as before");
    settings_changed();
  }
}
}  // namespace

void eyeaa_release() { release_all(); }

// Render thread, right after the eye picture `eyeTex` (owned by stereo.cpp, shader-readable) was copied. gammaSpace: the picture holds display-ready colours.
void eyeaa_apply(void* devp, void* ctxp, void* eyeTex, int eye, int gammaSpace) {
  if (eye < 0 || eye > 1) return;
  g_valid[eye] = 0;
  ID3D11Device* dev = (ID3D11Device*)devp;
  ID3D11DeviceContext* ctx = (ID3D11DeviceContext*)ctxp;
  ID3D11Texture2D* src = (ID3D11Texture2D*)eyeTex;
  if (!g_ctl.eyeAa) { if (g_out[0] || g_vs) release_all(); g_failures = 0; InterlockedIncrement(&g_as.offFrames); return; }   // 1.7.180: switching it on again starts the failure count again   // off: nothing is kept (no graphics memory used)
  if (!dev || !ctx || !src) return;
  if (dev != g_dev) { release_all(); g_dev = dev; }
  int sharp = (int)g_ctl.eyeAaSharpPct;
  if (sharp < 0) sharp = 0;
  if (sharp > 100) sharp = 100;
  const int lin = gammaSpace ? 0 : 1;
  if (g_state == 1 && (sharp != g_builtSharp || lin != g_builtLin)) { rel(g_vs); rel(g_ps); rel(g_smp); rel(g_rs); rel(g_ds); rel(g_bs); g_state = 0; InterlockedIncrement(&g_as.rebuilt); }
  D3D11_TEXTURE2D_DESC d;
  src->GetDesc(&d);
  if (g_state == 0) {
    g_state = create_resources(dev, lin, sharp);
    if (g_state < 0) {
      const int code = g_state;
      release_all();
      g_dev = dev;
      fail("shaders / states could not be created", code);
      return;
    }
    g_builtSharp = sharp; g_builtLin = lin;
    log_line("EYEAA ready: smooth edges on the headset pictures, %u x %u format=%d, colours %s, sharpening %d %%", d.Width, d.Height, (int)d.Format, lin ? "linear" : "display-ready", sharp);
  }
  if (g_state != 1) return;
  if (d.SampleDesc.Count != 1 || !(d.BindFlags & D3D11_BIND_SHADER_RESOURCE)) { fail("the eye picture cannot be read by a shader", (int)d.BindFlags); return; }
  if (!ensure_targets(dev, d)) { fail("the second picture could not be made (graphics memory?)", (int)d.Width); return; }
  if (!g_srv[eye] || g_srvOf[eye] != src) {
    rel(g_srv[eye]); g_srvOf[eye] = nullptr;
    if (FAILED(dev->CreateShaderResourceView(src, nullptr, &g_srv[eye])) || !g_srv[eye]) { fail("the eye picture's view could not be made", eye); return; }
    g_srvOf[eye] = src;
  }
  const int64_t t0 = qpc_now();
  Saved sv;
  save(ctx, &sv);
  ID3D11ShaderResourceView* none = nullptr;
  ctx->OMSetRenderTargets(1, &g_rtv[eye], nullptr);
  D3D11_VIEWPORT vp;
  vp.TopLeftX = 0; vp.TopLeftY = 0; vp.Width = (float)d.Width; vp.Height = (float)d.Height; vp.MinDepth = 0; vp.MaxDepth = 1;
  ctx->RSSetViewports(1, &vp);
  ctx->RSSetState(g_rs);
  ctx->OMSetBlendState(g_bs, nullptr, 0xffffffffu);
  ctx->OMSetDepthStencilState(g_ds, 0);
  ctx->IASetInputLayout(nullptr);
  ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  ctx->VSSetShader(g_vs, nullptr, 0);
  ctx->GSSetShader(nullptr, nullptr, 0);
  ctx->HSSetShader(nullptr, nullptr, 0);
  ctx->DSSetShader(nullptr, nullptr, 0);
  ctx->PSSetShader(g_ps, nullptr, 0);
  ctx->PSSetShaderResources(0, 1, &g_srv[eye]);
  ctx->PSSetSamplers(0, 1, &g_smp);
  ctx->Draw(3, 0);
  ctx->PSSetShaderResources(0, 1, &none);   // the eye picture is free again before anything else may want to write it
  restore(ctx, &sv);
  const double ms = (double)(qpc_now() - t0) * 1000.0 / (double)qpc_freq();
  g_as.msSum += ms; ++g_as.msN; if (ms > g_as.msMax) g_as.msMax = ms;
  InterlockedIncrement(&g_as.draws);
  g_valid[eye] = 1;
  g_failures = 0;   // 1.7.180: only problems in a row switch it off, not three hiccups over a whole session
}

// The picture to hand to the headset for this eye: the filtered one when it is current, otherwise the plain one.
void* eyeaa_tex(int eye, void* plain) {
  if (eye < 0 || eye > 1 || !g_ctl.eyeAa || !g_valid[0] || !g_valid[1] || !g_out[eye]) return plain;   // 1.7.180: both eyes filtered or neither
  return g_out[eye];
}

void eyeaa_report(LONG frame) {
  log_line("EYEAA frame=%d eye_aa=%d sharpen=%d%% state=%d (1 ready) pictures filtered %ld, frames with it off %ld, problems %ld, shader rebuilt %ld | CPU side of the pass avg %.3f ms (max %.3f; the graphics card's share is not in this number)",
           (int)frame, (int)g_ctl.eyeAa, (int)g_ctl.eyeAaSharpPct, g_state, (long)g_as.draws, (long)g_as.offFrames, (long)g_as.failed, (long)g_as.rebuilt, g_as.msN ? g_as.msSum / g_as.msN : 0.0, g_as.msMax);
  g_as.msSum = 0; g_as.msN = 0; g_as.msMax = 0;
}
#else
void eyeaa_release() {}
void eyeaa_apply(void*, void*, void*, int, int) {}
void* eyeaa_tex(int, void* plain) { return plain; }
void eyeaa_report(LONG) {}
#endif
