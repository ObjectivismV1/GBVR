// 0.76 fight maths: which damage is "the beam", the small health bars drawn inside the ghosts, and the slam swing.
// Pure functions (no game memory, no Direct3D) so tests/test_fight.cpp can check them.
#pragma once
#include <stdint.h>
#include "vmath.h"
#include "gunbarmath.h"   // 1.7.158: the liquid state and colours, shared with the life tube on the gun
#include "cordmath.h"   // cord::V (position, normal, colour; colour alpha > 0.5 = unlit / emissive)

namespace fight {

// ---- which damage is a beam -------------------------------------------------------------------------------------------------
// The game's SDamageInfo carries a damage type (offset +0x08) and an ammo type (+0x18). The enums (from the game's own script tables):
//   EDamageType: ... 0x6E Slime, 0x6F ProtonBeam, 0x70 Marshmallow, 0x71 Scare, 0x72 Wrangle, 0x73 WrangleSlam, 0x74 Grapple, 0x75 Freeze, 0x76 Silent, 0x77 None
//   EAmmoType:   0x09 BuckShot (meson collider), 0x0C SuperBeam, 0x0D ContainmentBeam, 0x0E CrossedBeam, 0x0F IceBeam, 0x10 BoltBeam, 0x11 Railgun, 0x12 RailgunLauncher (boson dart), 0x13..0x16 the four slimes
enum { kDmgSlime = 0x6E, kDmgProton = 0x6F, kDmgWrangle = 0x72, kDmgWrangleSlam = 0x73, kDmgFreeze = 0x75 };
inline bool is_beam(int type, int ammo) {
  switch (type) {
    case kDmgSlime: case kDmgProton: case kDmgWrangle: case kDmgWrangleSlam: case kDmgFreeze: return true;
    default: break;
  }
  // 1.7.19: the other weapons count too, so 115 % means the same for every gun: the meson collider (the shotgun item: BuckShot 0x09) and the boson dart (Railgun 0x11 / RailgunLauncher 0x12)
  return (ammo >= 0x0C && ammo <= 0x12) || ammo == 0x09 || (ammo >= 0x13 && ammo <= 0x16);
}
// 100 = unchanged. Anything that is not a plain non-negative number is returned as it is.
inline float boost(float v, int pct) {
  if (!(v == v) || v < 0.0f || v > 1.0e7f) return v;
  if (pct < 100) pct = 100;
  if (pct > 400) pct = 400;
  return v * (float)pct * 0.01f;
}
inline double health_frac(float cur, float mx) {
  if (!(cur == cur) || !(mx == mx) || mx < 0.5f || mx > 1.0e7f) return -1.0;
  double f = (double)cur / (double)mx;
  if (f < 0.0) f = 0.0;
  if (f > 1.0) f = 1.0;
  return f;
}

// A sequence of weak hits still confirms an active enemy. Heal resets the baseline.
inline bool health_drop(float current, float* baseline) {
  if (!baseline) return false;
  if (current > *baseline + 0.004f) *baseline = current;
  if (*baseline - current <= 0.004f) return false;
  *baseline = current;
  return true;
}

// ---- health bars ------------------------------------------------------------------------------------------------------------
// One bar per enemy. Position in the headset's axes from the head centre, metres (x right, y up, z forward).
struct Bar { float p[3]; float radius; float frac; unsigned flags; unsigned long long actor; };   // flags bit0: it lost health in the last few seconds; bit1 (1.7.103): the ghost the game's ring belongs to (looked at / locked); actor: which ghost

inline void rebase_bar(Bar& bar, const float* oldView, const float* oldHead, double oldFpm,
                       const float* view, const float* head, double fpm) {
  double world[3];
  for (int r = 0; r < 3; ++r) {
    world[r] = oldHead[r];
    for (int c = 0; c < 3; ++c) world[r] += oldView[r * 3 + c] * bar.p[c] * oldFpm;
  }
  for (int c = 0; c < 3; ++c) {
    double v = 0; for (int r = 0; r < 3; ++r) v += view[r * 3 + c] * (world[r] - head[r]);
    bar.p[c] = (float)(v / fpm);
  }
  bar.radius = (float)(bar.radius * oldFpm / fpm);
}
enum { kMaxBars = 24, kFlagRecent = 1, kFlagFocus = 2, kFlagBoss = 4 };   // 1.7.164: kFlagBoss = a boss's bar: its radius is a size for the view, not its body

struct Look {
  double sizePct;      // 100 = default
  int digitsFocus;     // 1.7.24: ignored, the percent number is gone (was: numbers for the ghost you look at and the ones just hit)
  double focusDeg;     // how close to the view centre a bar must be to count as "looked at"
  int liquid = 0;      // 1.7.158: 1 = a glass vial of glowing liquid (the gun's life tube, flat, facing you) instead of the bar / the ring
  const gunbar::Liquid* liq = nullptr;   // 1.7.158: per bar (same index as the bars), the level shown, the part just lost, the slosh; null = the plain health
  int ringStyle = 0;   // 1.7.103: 1 = a round health ring on the ghost the game's ring belongs to (kFlagFocus) and nothing on the others; 0 = the bars
};

// drawn size of a bar (width in metres) at a distance: roughly constant on screen, bounded in the world
inline double bar_width(double dist, double radiusM, double sizePct) {
  double w = dist * 0.050;
  const double minW = 0.20 + 0.10 * (radiusM > 1.0 ? (radiusM > 3.0 ? 2.0 : radiusM - 1.0) : 0.0) * 0.5;
  if (w < minW) w = minW;
  if (w > 1.30) w = 1.30;
  return w * sizePct * 0.01;
}

inline void colour_for(double f, float* c) {
  // 1.7.19: green (1.0) - lime (0.75) - yellow (0.5) - orange (0.27) - red (0): five stops, each stretch eased with a smoothstep so there is no visible corner at yellow; changes smoothly with health
  static const double at[5] = {0.0, 0.27, 0.5, 0.75, 1.0};
  static const float col[5][3] = {{0.95f, 0.10f, 0.08f}, {1.0f, 0.50f, 0.08f}, {1.0f, 0.86f, 0.10f}, {0.62f, 0.92f, 0.15f}, {0.18f, 0.95f, 0.25f}};
  if (!(f > 0.0)) f = 0.0;
  if (f > 1.0) f = 1.0;
  int i = 0;
  while (i < 3 && f > at[i + 1]) ++i;
  double t = (f - at[i]) / (at[i + 1] - at[i]);
  t = t * t * (3.0 - 2.0 * t);
  for (int k = 0; k < 3; ++k) c[k] = (float)((double)col[i][k] + ((double)col[i + 1][k] - (double)col[i][k]) * t);
}
// 1.7.19: the fraction a bar SHOWS eases toward the real health (about 0.2 s), so the fill and its colour slide instead of jumping with every hit. dt in seconds.
inline double ease_shown(double shown, double target, double dt) {
  if (!(shown >= 0.0)) return target;
  if (!(dt > 0.0)) return shown;
  if (dt > 0.25) dt = 0.25;
  const double k = dt / (0.20 + dt);
  return shown + (target - shown) * k;
}

struct Buf { cord::V* v; int n, cap; int over; };
inline void emit(Buf& b, const float* p, const float* col) {
  if (b.n >= b.cap) { b.over = 1; return; }
  cord::V& o = b.v[b.n++];
  o.p[0] = p[0]; o.p[1] = p[1]; o.p[2] = p[2];
  o.n[0] = 0; o.n[1] = 0; o.n[2] = -1;
  o.c[0] = col[0]; o.c[1] = col[1]; o.c[2] = col[2]; o.c[3] = 1.0f;   // alpha 1: unlit
}
// a flat rectangle facing the viewer (eye space: z is the distance), centre (cx,cy), size (w,h)
inline void rect(Buf& b, double cx, double cy, double z, double w, double h, const float* col) {
  const float x0 = (float)(cx - 0.5 * w), x1 = (float)(cx + 0.5 * w), y0 = (float)(cy - 0.5 * h), y1 = (float)(cy + 0.5 * h), zz = (float)z;
  const float A[3] = {x0, y0, zz}, B[3] = {x1, y0, zz}, C[3] = {x1, y1, zz}, D[3] = {x0, y1, zz};
  emit(b, A, col); emit(b, C, col); emit(b, B, col);
  emit(b, A, col); emit(b, D, col); emit(b, C, col);
}

// 3 x 5 pixel digits and a percent sign; row-major, 3 bits a row (bit 2 = left)
static const unsigned char kGlyph[11][5] = {
  {7, 5, 5, 5, 7}, {2, 6, 2, 2, 7}, {7, 1, 7, 4, 7}, {7, 1, 7, 1, 7}, {5, 5, 7, 1, 1},
  {7, 4, 7, 1, 7}, {7, 4, 7, 5, 7}, {7, 1, 1, 1, 1}, {7, 5, 7, 5, 7}, {7, 5, 7, 1, 7},
  {5, 1, 2, 4, 5}};   // 10 = percent
inline double glyph_width(double px) { return 3.0 * px; }
// the text "73%" (digits then a percent sign) centred at (cx,cy); px = size of one pixel. Dark outline first, then the bright digits.
inline void text(Buf& b, int value, double cx, double cy, double z, double px, const float* col) {
  int g[4], n = 0;
  if (value < 0) value = 0;
  if (value > 100) value = 100;
  if (value >= 100) { g[n++] = 1; g[n++] = 0; g[n++] = 0; }
  else if (value >= 10) { g[n++] = value / 10; g[n++] = value % 10; }
  else g[n++] = value;
  g[n++] = 10;
  const double gap = px, gw = 3.0 * px;
  const double total = n * gw + (n - 1) * gap;
  const float dark[3] = {0.0f, 0.0f, 0.0f};
  for (int pass = 0; pass < 2; ++pass) {   // pass 0: a thick dark shadow behind, pass 1: the glyphs
    for (int k = 0; k < n; ++k) {
      const double gx = cx - 0.5 * total + k * (gw + gap);
      for (int r = 0; r < 5; ++r)
        for (int c = 0; c < 3; ++c)
          if (kGlyph[g[k]][r] & (4 >> c)) {
            const double x = gx + (c + 0.5) * px, y = cy + (2.0 - r) * px;
            if (pass == 0) rect(b, x, y, z, px * 1.9, px * 1.9, dark);
            else rect(b, x, y, z, px, px, col);
          }
    }
  }
}

// ---- the round health ring (1.7.103) -------------------------------------------------------------------------------------
// A ring on the ghost the game's own ring would be on, at the same place the bar sits. angle 0 = 12 o'clock, clockwise. A sector of an annulus between rIn and rOut from a0 to a1 (radians).
inline void arc(Buf& b, double cx, double cy, double z, double rIn, double rOut, double a0, double a1, const float* col) {
  if (!(a1 > a0)) return;
  int segs = (int)((a1 - a0) / 0.08727 + 1.0);   // 1.7.163: about 5 degrees a piece (was 9: the ring's edge showed corners up close)
  if (segs < 1) segs = 1;
  if (segs > 72) segs = 72;
  const float zz = (float)z;
  for (int i = 0; i < segs; ++i) {
    const double t0 = a0 + (a1 - a0) * (double)i / (double)segs, t1 = a0 + (a1 - a0) * (double)(i + 1) / (double)segs;
    double s0, c0, s1, c1;
    vm::dsincos(t0, &s0, &c0); vm::dsincos(t1, &s1, &c1);
    const float A[3] = {(float)(cx + rIn * s0), (float)(cy + rIn * c0), zz};
    const float B[3] = {(float)(cx + rOut * s0), (float)(cy + rOut * c0), zz};
    const float C[3] = {(float)(cx + rOut * s1), (float)(cy + rOut * c1), zz};
    const float D[3] = {(float)(cx + rIn * s1), (float)(cy + rIn * c1), zz};
    emit(b, A, col); emit(b, B, col); emit(b, C, col);
    emit(b, A, col); emit(b, C, col); emit(b, D, col);
  }
}
// ring diameter (metres) at a distance: the bar's width rule, a little bigger
// 1.7.163 "fit tight": the ring and the vial lean halfway toward the ghost's own size (its bounds radius, metres), never under half or over 1.5 x the old
// size, so a small far ghost no longer wears a ring twice its size and a big near one is not under-ringed.
inline double fit_to_ghost(double base, double ghostSpan) {
  if (!(ghostSpan > 0.05) || !(ghostSpan < 200.0) || !(base > 0.0)) return base;
  double g = ghostSpan; if (g < base * 0.5) g = base * 0.5; if (g > base * 1.5) g = base * 1.5;
  return 0.5 * base + 0.5 * g;
}
inline double ring_diameter(double dist, double radiusM, double sizePct, int boss = 0) { const double base = bar_width(dist, radiusM, 100.0) * 2.4; return (boss ? base : fit_to_ghost(base, 2.1 * radiusM)) * sizePct * 0.01; }   // 1.7.164: a boss keeps its fixed size   // 1.7.164: a boss keeps its fixed size
inline void ring(Buf& b, double cx, double cy, double z, double dia, double f, const float* hc) {
  const float black[3] = {0.0f, 0.0f, 0.0f};
  const double R = 0.5 * dia, band = R * 0.16, rim = R * 0.035, glow = R * 0.025;   // 1.7.171: a thinner ring (was 0.26 / 0.05 / 0.035): it covered the ghost
  const double TWO_PI = 6.283185307179586;
  arc(b, cx, cy, z, R - band - rim - glow, R + rim + glow, 0.0, TWO_PI, hc);   // the hairline glow in the health colour
  arc(b, cx, cy, z, R - band - rim, R + rim, 0.0, TWO_PI, black);              // black frame
  arc(b, cx, cy, z, R - band, R, 0.0, TWO_PI, black);                          // black track
  if (f < 0.0) f = 0.0;
  if (f > 1.0) f = 1.0;
  if (f > 0.004) arc(b, cx, cy, z, R - band + rim * 0.6, R - rim * 0.6, 0.0, TWO_PI * f, hc);   // the health, clockwise from the top
}

// ---- 1.7.158 the ghost's health as a vial of liquid -------------------------------------------------------------------------
// "make sure this is for the ghost health bar as well". The gun's tube, drawn flat and facing you where the bar / ring sits: a black glass capsule with a
// hairline glow in the liquid's colour, the liquid filling it from the left (green, yellow, amber, red), darker at the bottom and bright on top, a moving
// surface at its end, a strip of light, three bubbles, and the part just lost flashing pale before it goes. Same state and colours as the gun (gunbarmath.h).
inline void diamond_px(Buf& b, double cx, double cy, double z, double h, const float* col) {
  const float zz = (float)z;
  const float T[3] = {(float)cx, (float)(cy + h), zz}, R[3] = {(float)(cx + h), (float)cy, zz}, B[3] = {(float)cx, (float)(cy - h), zz}, L[3] = {(float)(cx - h), (float)cy, zz};
  emit(b, T, col); emit(b, R, col); emit(b, B, col);
  emit(b, T, col); emit(b, B, col); emit(b, L, col);
}
inline void emit2(Buf& b, double x, double y, double z, const float* col, float k) {
  float c[3]; for (int i = 0; i < 3; ++i) { const float q = col[i] * k; c[i] = q < 0.0f ? 0.0f : q > 1.0f ? 1.0f : q; }
  const float p[3] = {(float)x, (float)y, (float)z}; emit(b, p, c);
}
// a four-cornered piece with its own brightness at the bottom and the top (x may differ per corner: the wavy end)
inline void quad_grad(Buf& b, double x0b, double x1b, double x0t, double x1t, double yb, double yt, double z, const float* col, float kb, float kt) {
  emit2(b, x0b, yb, z, col, kb); emit2(b, x1t, yt, z, col, kt); emit2(b, x1b, yb, z, col, kb);
  emit2(b, x0b, yb, z, col, kb); emit2(b, x0t, yt, z, col, kt); emit2(b, x1t, yt, z, col, kt);
}
// a capsule (a bar with round ends): centre, whole width, height
inline void capsule(Buf& b, double cx, double cy, double z, double w, double h, const float* col) {
  if (w < h) w = h;
  const double r = 0.5 * h, half = 0.5 * w - r;
  rect(b, cx, cy, z, 2.0 * half, h, col);
  for (int e = 0; e < 2; ++e) {   // two half discs of 8 slices (few vertices: up to 24 vials share one buffer)
    const double ox = e ? cx - half : cx + half, sg = e ? -1.0 : 1.0;
    for (int i = 0; i < 12; ++i) {   // 1.7.163: 12 slices (was 8): rounder ends
      double s0, c0, s1, c1; vm::dsincos(3.141592653589793 * i / 12.0, &s0, &c0); vm::dsincos(3.141592653589793 * (i + 1) / 12.0, &s1, &c1);
      const float zz = (float)z;
      const float O[3] = {(float)ox, (float)cy, zz}, A[3] = {(float)(ox + sg * r * s0), (float)(cy + r * c0), zz}, B[3] = {(float)(ox + sg * r * s1), (float)(cy + r * c1), zz};
      emit(b, O, col); emit(b, A, col); emit(b, B, col);
    }
  }
}
// the edge of the liquid's inside at height y (the glass is a capsule: narrower toward top and bottom at both ends)
inline double capsule_inset(double y, double cy, double r) { const double d = y - cy; const double q = r * r - d * d; return r - (q > 0.0 ? vm::dsqrt(q) : 0.0); }
// 1.7.160: the vial's width. Near ghosts as before (1.15 x the bar, 1.45 x on the ring's ghost); far away it keeps a smallest size in degrees of view
// (2.6 deg, 4.3 deg on the ring's ghost) so a far boss (Stay Puft from the roof, 60+ m) is not a thin line: the 1.30 m cap of bar_width made his vial 1.7 deg x 0.4 deg.
inline double vial_width(double dist, double radiusM, double sizePct, int ringGhost, int boss = 0) {
  const double base = bar_width(dist, radiusM, 100.0) * (ringGhost ? 1.45 : 1.15);
  double w = (boss ? base : fit_to_ghost(base, 1.7 * radiusM)) * sizePct * 0.01;   // 1.7.164: a boss's radius is not its body (bossring::ring_radius): no fitting   // 1.7.163: fitted to the ghost
  if (dist == dist && dist > 0.0 && sizePct == sizePct) {
    const double floorW = dist * (ringGhost ? 0.075 : 0.045) * sizePct * 0.01;
    if (w < floorW) w = floorW;
  }
  return w;
}
inline void vial(Buf& b, double cx, double cy, double z, double W, const gunbar::Liquid& s) {
  const double H = W * 0.24, rim = H * 0.13, glow = H * 0.06, inH = H - 2.0 * rim, inW = W - 2.0 * rim, r = 0.5 * inH;
  const double shown = gunbar::clamp01d(s.shown), lost = gunbar::clamp01d(s.lost < s.shown ? s.shown : s.lost);
  float lc[3]; gunbar::liquid_colour(shown, lc);
  const float black[3] = {0, 0, 0};
  float tint[3]; for (int i = 0; i < 3; ++i) tint[i] = 0.035f + 0.075f * lc[i];
  capsule(b, cx, cy, z, W + 2.0 * glow, H + 2.0 * glow, lc);     // the hairline glow
  capsule(b, cx, cy, z, W, H, black);                            // the black glass
  capsule(b, cx, cy, z, inW, inH, tint);                         // the empty inside, faintly the liquid's colour
  const double xl = cx - 0.5 * inW, yb = cy - 0.5 * inH;
  const float low = shown < 0.25 ? (float)(0.74 + 0.26 * gunbar::heart_pulse(s.beat)) : 1.0f;
  enum { kRows = 12 };   // 1.7.163: 12 rows (was 8): a smoother surface line
  // the liquid and the pale lost part, in rows so the round ends and the moving surface can be followed
  for (int pass = 0; pass < 2; ++pass) {
    const double level = pass == 0 ? lost : shown;
    if (pass == 0 && !(lost > shown + 1e-6)) continue;
    if (!(level > 0.0)) continue;
    float col[3]; for (int i = 0; i < 3; ++i) col[i] = pass == 0 ? lc[i] * 0.30f + 0.70f : lc[i];
    double xe[kRows + 1];
    for (int k = 0; k <= kRows; ++k) {
      const double y = yb + inH * (double)k / kRows;
      double a, c0, a2; { const double u = (double)k / kRows; vm::dsincos(3.6 * u + s.t * 4.2, &a, &c0); vm::dsincos(5.2 * u - s.t * 9.0, &a2, &c0); }   // 1.7.163: one gentle curve over the height (was a zig-zag)
      double x = xl + inW * level + (pass == 1 ? inH * (0.09 * a + 0.28 * s.slosh * a2) : 0.0);
      const double lo = xl + capsule_inset(y, cy, r), hi = xl + inW - capsule_inset(y, cy, r);
      if (x < lo) x = lo; if (x > hi) x = hi;
      xe[k] = x;
    }
    for (int k = 0; k < kRows; ++k) {
      const double y0 = yb + inH * (double)k / kRows, y1 = yb + inH * (double)(k + 1) / kRows;
      const double l0 = xl + capsule_inset(y0, cy, r), l1 = xl + capsule_inset(y1, cy, r);
      const float k0 = (pass == 0 ? 0.80f : (0.58f + 0.42f * (float)k / kRows) * low), k1 = (pass == 0 ? 0.92f : (0.58f + 0.42f * (float)(k + 1) / kRows) * low);
      if (xe[k] > l0 || xe[k + 1] > l1) quad_grad(b, l0, xe[k] > l0 ? xe[k] : l0, l1, xe[k + 1] > l1 ? xe[k + 1] : l1, y0, y1, z, col, k0, k1);
    }
  }
  const double fw = inW * shown;
  if (fw > inH * 1.2) {   // the strip of light and the bubbles, over the liquid only
    float hi[3]; for (int i = 0; i < 3; ++i) hi[i] = lc[i] * 0.40f + 0.60f;
    const double sx0 = xl + r * 0.9, sx1 = xl + fw - inH * 0.45;
    if (sx1 > sx0) quad_grad(b, sx0, sx1, sx0, sx1, cy + inH * 0.20, cy + inH * 0.31, z, hi, 0.70f * low, 0.95f * low);
    float bub[3]; for (int i = 0; i < 3; ++i) bub[i] = lc[i] * 0.35f + 0.65f;
    for (int q = 0; q < 3; ++q) {
      double u = 0.17 + 0.31 * q + s.t * (0.10 + 0.04 * q); u -= (double)(long)u;
      const double bx = xl + r + u * (fw - r - inH * 0.5), by = cy - inH * (0.22 - 0.13 * q), sz = inH * (0.055 + 0.02 * q);
      if (bx < xl + fw - inH * 0.3) diamond_px(b, bx, by, z, sz, bub);
    }
  }
}

// builds all bars into b (eye space). eyeX: this eye's offset from the head centre (metres). Returns the vertex count.
inline int build(const Bar* bars, int nBars, double eyeX, const Look& look, cord::V* out, int cap) {
  Buf b = {out, 0, cap, 0};
  // 1.7.24: "remove percent from the ghost health bar, and make the bars surrounding the color of the health neon black": the frame and the empty track are pure black,
  // with a hairline glow in the health colour just outside the frame (the neon); no number is drawn any more.
  const float rim[3] = {0.0f, 0.0f, 0.0f}, track[3] = {0.0f, 0.0f, 0.0f}, tick[3] = {0.0f, 0.0f, 0.0f};
  // far bars first, so the near ones are on top (the draw has no depth test)
  int order[kMaxBars];
  double dist[kMaxBars], ex[kMaxBars], ey[kMaxBars], ez[kMaxBars];
  int m = 0;
  for (int i = 0; i < nBars && m < kMaxBars; ++i) {
    const double x = (double)bars[i].p[0] - eyeX, y = (double)bars[i].p[1], z = (double)bars[i].p[2];
    if (look.ringStyle && !(bars[i].flags & kFlagFocus)) continue;   // 1.7.103: only the ghost the ring belongs to
    if (!(z > 0.35) || !(x == x) || !(y == y)) continue;
    if (vm::dabs(x) > 2.6 * z || vm::dabs(y) > 2.6 * z) continue;   // far outside the picture
    ex[m] = x; ey[m] = y; ez[m] = z; dist[m] = vm::dsqrt(x * x + y * y + z * z);
    order[m] = i;
    ++m;
  }
  for (int a = 1; a < m; ++a) {   // insertion sort, far to near
    int o = order[a]; double d = dist[a], x = ex[a], y = ey[a], z = ez[a];
    int k = a - 1;
    while (k >= 0 && dist[k] < d) { order[k + 1] = order[k]; dist[k + 1] = dist[k]; ex[k + 1] = ex[k]; ey[k + 1] = ey[k]; ez[k + 1] = ez[k]; --k; }
    order[k + 1] = o; dist[k + 1] = d; ex[k + 1] = x; ey[k + 1] = y; ez[k + 1] = z;
  }
  // which bar is "looked at": the one nearest the view centre
  int focus = -1; double best = look.focusDeg;
  for (int k = 0; k < m; ++k) {
    const double ang = vm::datan2(vm::dsqrt(ex[k] * ex[k] + ey[k] * ey[k]), ez[k]) * 57.29577951308232;
    if (ang < best) { best = ang; focus = k; }
  }
  // 1.7.165: too many at once for the buffer (24 ghosts at the biggest size): the FARTHEST ones are left out until the rest fit. Before, the whole build
  // failed and every ghost's health vanished in a crowded fight.
  int skipFar = 0;
again:
  for (int k = skipFar; k < m; ++k) {
    const Bar& bar = bars[order[k]];
    if (look.ringStyle) {   // 1.7.103; 1.7.170: the ring wins when its style is chosen (the vial hid it before)
      double fr = bar.frac;
      if (fr < 0.0) fr = 0.0;
      if (fr > 1.0) fr = 1.0;
      float hcR[3];
      colour_for(fr, hcR);
      ring(b, ex[k], ey[k], ez[k], ring_diameter(dist[k], (double)bar.radius, look.sizePct, (bar.flags & kFlagBoss) ? 1 : 0), fr, hcR);
      continue;
    }
    if (look.liquid) {   // 1.7.158: the vial (on the ring's ghost only when the ring style is on, as the ring was)
      gunbar::Liquid plain; plain.reset(); plain.have = 1; plain.shown = plain.lost = plain.target = gunbar::clamp01d((double)bar.frac);
      vial(b, ex[k], ey[k], ez[k], vial_width(dist[k], (double)bar.radius, look.sizePct, look.ringStyle, (bar.flags & kFlagBoss) ? 1 : 0), look.liq ? look.liq[order[k]] : plain);
      continue;
    }
    const double W = bar_width(dist[k], (double)bar.radius, look.sizePct), H = W * 0.20, rimT = H * 0.16, inset = H * 0.12;
    const double cx = ex[k], cy = ey[k], z = ez[k];
    double f = bar.frac;
    if (f < 0.0) f = 0.0;
    if (f > 1.0) f = 1.0;
    float hc[3];
    colour_for(f, hc);
    const double glowT = H * 0.07;
    rect(b, cx, cy, z, W + 2.0 * rimT + 2.0 * glowT, H + 2.0 * rimT + 2.0 * glowT, hc);   // 1.7.24: the neon hairline, in the health colour
    rect(b, cx, cy, z, W + 2.0 * rimT, H + 2.0 * rimT, rim);       // black frame
    rect(b, cx, cy, z, W, H, track);                               // black track
    const double fw = (W - 2.0 * inset) * f;
    if (fw > 1e-5)
      rect(b, cx - 0.5 * (W - 2.0 * inset) + 0.5 * fw, cy, z, fw, H - 2.0 * inset, hc);
    for (int q = 1; q <= 3; ++q)                                   // quarter marks (black, so they only show on the coloured part)
      rect(b, cx - 0.5 * (W - 2.0 * inset) + (W - 2.0 * inset) * 0.25 * q, cy, z, H * 0.07, H - 2.0 * inset, tick);
    (void)focus;   // 1.7.24: the percent number is gone (digitsFocus is ignored)
  }
  if (b.over && skipFar < m - 1) { ++skipFar; b.n = 0; b.over = 0; goto again; }
  return b.over ? -1 : b.n;
}

// ---- collectible markers (1.7.3) --------------------------------------------------------------------------------------------
// A small glowing diamond (with a thin light beam for collectibles) where the game keeps a collectible or a PKE scan target, drawn like the health bars
// (eye space, no depth test, far to near). The game's own glow for them does not come through in the headset.
struct Marker { float p[3]; int kind; float distFt; };   // p: headset axes from the head centre, metres. kind 0 = collectible (gold), 1 = PKE scan target (cyan)
enum { kMaxMarkers = 12 };
inline void diamond(Buf& b, double cx, double cy, double z, double hw, double hh, const float* col) {
  const float zz = (float)z;
  const float T[3] = {(float)cx, (float)(cy + hh), zz}, R[3] = {(float)(cx + hw), (float)cy, zz}, B[3] = {(float)cx, (float)(cy - hh), zz}, L[3] = {(float)(cx - hw), (float)cy, zz};
  emit(b, T, col); emit(b, R, col); emit(b, B, col);
  emit(b, T, col); emit(b, B, col); emit(b, L, col);
}
// a whole number (0..999) centred at (cx,cy); px = one glyph pixel. Dark outline first, then the bright digits.
inline void number(Buf& b, int value, double cx, double cy, double z, double px, const float* col) {
  int g[4], n = 0;
  if (value < 0) value = 0;
  if (value > 999) value = 999;
  if (value >= 100) { g[n++] = value / 100; g[n++] = (value / 10) % 10; g[n++] = value % 10; }
  else if (value >= 10) { g[n++] = value / 10; g[n++] = value % 10; }
  else g[n++] = value;
  const double gap = px, gw = 3.0 * px;
  const double total = n * gw + (n - 1) * gap;
  const float dark[3] = {0.0f, 0.0f, 0.0f};
  for (int pass = 0; pass < 2; ++pass)
    for (int k = 0; k < n; ++k) {
      const double gx = cx - 0.5 * total + k * (gw + gap);
      for (int r = 0; r < 5; ++r)
        for (int c = 0; c < 3; ++c)
          if (kGlyph[g[k]][r] & (4 >> c)) {
            const double x = gx + (c + 0.5) * px, y = cy + (2.0 - r) * px;
            if (pass == 0) rect(b, x, y, z, px * 1.9, px * 1.9, dark);
            else rect(b, x, y, z, px, px, col);
          }
    }
}
// width in metres of a marker at a distance: it grows with distance so it stays easy to see, but stays small up close
inline double marker_width(double dist, double sizePct) {
  double w = dist * 0.032;
  if (w < 0.07) w = 0.07;
  if (w > 0.55) w = 0.55;
  return w * sizePct * 0.01;
}
// phase: seconds (any origin) for the slow pulse. Returns the vertex count, -1 when the buffer was too small.
inline int build_markers(const Marker* mk, int nMk, double eyeX, double sizePct, double phase, cord::V* out, int cap) {
  Buf b = {out, 0, cap, 0};
  const float dark[3] = {0.02f, 0.02f, 0.03f}, white[3] = {1.0f, 1.0f, 0.88f};
  const float gold[3] = {1.0f, 0.80f, 0.12f}, cyan[3] = {0.20f, 0.85f, 1.0f};
  int order[kMaxMarkers];
  double dist[kMaxMarkers], ex[kMaxMarkers], ey[kMaxMarkers], ez[kMaxMarkers];
  int m = 0;
  for (int i = 0; i < nMk && m < kMaxMarkers; ++i) {
    const double x = (double)mk[i].p[0] - eyeX, y = (double)mk[i].p[1], z = (double)mk[i].p[2];
    if (!(z > 1.0) || !(x == x) || !(y == y)) continue;   // behind you or closer than a metre: not drawn (it must not block the pickup)
    if (vm::dabs(x) > 2.6 * z || vm::dabs(y) > 2.6 * z) continue;
    ex[m] = x; ey[m] = y; ez[m] = z; dist[m] = vm::dsqrt(x * x + y * y + z * z);
    order[m] = i;
    ++m;
  }
  for (int a = 1; a < m; ++a) {   // far to near
    int o = order[a]; double d = dist[a], x = ex[a], y = ey[a], z = ez[a];
    int k = a - 1;
    while (k >= 0 && dist[k] < d) { order[k + 1] = order[k]; dist[k + 1] = dist[k]; ex[k + 1] = ex[k]; ey[k + 1] = ey[k]; ez[k + 1] = ez[k]; --k; }
    order[k + 1] = o; dist[k + 1] = d; ex[k + 1] = x; ey[k + 1] = y; ez[k + 1] = z;
  }
  int focus = -1; double best = 14.0;   // the one nearest the view centre gets its distance in feet
  for (int k = 0; k < m; ++k) {
    const double ang = vm::datan2(vm::dsqrt(ex[k] * ex[k] + ey[k] * ey[k]), ez[k]) * 57.29577951308232;
    if (ang < best) { best = ang; focus = k; }
  }
  for (int k = 0; k < m; ++k) {
    const Marker& mr = mk[order[k]];
    const float* col = mr.kind == 1 ? cyan : gold;
    const double W = marker_width(dist[k], sizePct);
    double sn, cs; vm::dsincos(phase * 5.2 + (double)k, &sn, &cs);
    const double pulse = 1.0 + 0.10 * sn;
    const double hw = 0.5 * W * pulse, hh = 0.72 * W * pulse;
    const double cx = ex[k], cy = ey[k], z = ez[k];
    if (mr.kind == 0) {   // the thin light beam above a collectible
      const double bw = W * 0.14, bh = W * 2.8, by = cy + hh * 1.5 + 0.5 * bh;
      rect(b, cx, by, z, bw * 1.9, bh, dark);
      rect(b, cx, by, z, bw, bh, col);
    }
    diamond(b, cx, cy, z, hw * 1.45, hh * 1.45, dark);
    diamond(b, cx, cy, z, hw, hh, col);
    diamond(b, cx, cy, z, hw * 0.38, hh * 0.38, white);
    if (k == focus) number(b, (int)(mr.distFt + 0.5f), cx, cy - hh * 1.45 - W * 0.45, z, W * 0.11, col);
  }
  return b.over ? -1 : b.n;
}

// ---- the slam swing ----------------------------------------------------------------------------------------------------------
// The game slams a wrangled ghost when the capture stream is held and the fire trigger is pressed (and the slam meter is full).
// A down-swing of the gun hand does the trigger press for you. update() is called once per controller sample.
struct Swing {
  double last[3]; int have; double v[3];   // smoothed velocity of the hand, m/s (y up)
  double refractory;                       // seconds until another swing counts
  double pulse;                            // seconds the trigger stays pressed
  long swings;
  void reset() { have = 0; v[0] = v[1] = v[2] = 0; refractory = 0; pulse = 0; }
  // returns 1 while the fire trigger should be held down
  int update(double dt, const double* pos, int capture, double downSpeed, double minSpeed) {
    if (!(dt > 1e-4) || dt > 0.25) { have = 0; }
    if (have) {
      const double a = dt / (dt + 0.035);   // ~35 ms smoothing
      for (int i = 0; i < 3; ++i) v[i] += a * ((pos[i] - last[i]) / dt - v[i]);
    }
    for (int i = 0; i < 3; ++i) last[i] = pos[i];
    have = 1;
    if (refractory > 0) refractory -= dt;
    if (pulse > 0) pulse -= dt;
    if (!capture) { pulse = 0; return 0; }
    const double sp = vm::dsqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (refractory <= 0 && v[1] < -downSpeed && sp > minSpeed) {
      pulse = 0.22; refractory = 1.0; ++swings;
    }
    return pulse > 0 ? 1 : 0;
  }
};

}  // namespace fight
