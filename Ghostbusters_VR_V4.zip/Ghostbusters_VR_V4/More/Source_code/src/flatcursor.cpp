// 1.3 cursor on the 2D screen (menus, videos, loading) in the headset.
//
// While the game shows a menu (no 3D picture) its picture is on a flat screen in front of the player (stereo.cpp) and
// the controllers' laser acts as the mouse (menu.cpp). The ring drawn here sits exactly where SteamVR says the laser
// hits the screen: it is painted into the picture of the screen itself, at the same picture coordinates the click is
// sent to the game with. So the cursor cannot drift away from the click point, whatever the screen's size, distance or
// bend are. (The game's own pointer arrow, where it draws one, is under the ring's middle.)
//
// One small Direct3D pass into the screen's texture before it is handed to SteamVR: a triangle clipped to a square
// around the pointer, alpha-blended (the texture's alpha channel is not touched). All state that is changed is saved
// and put back. The shader is compiled at first use with d3dcompiler_47.dll; three failures switch the cursor off.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include <d3d11.h>
#include <d3dcompiler.h>

namespace {
const char* kShader =
  "cbuffer C : register(b0) { float4 A; };\n"                    // A = half size of the square in px, pressed, 0, 0
  "struct VO { float4 pos : SV_Position; float2 p : TEXCOORD0; float2 prm : TEXCOORD1; };\n"
  "VO VSMain(uint id : SV_VertexID) {\n"
  "  VO o;\n"
  "  float2 t = float2((id << 1) & 2, id & 2);\n"
  "  o.p = (t * 2.0 - 1.0) * A.x;\n"
  "  o.prm = float2(A.x / 64.0, A.y);\n"
  "  o.pos = float4(t.x * 2.0 - 1.0, 1.0 - t.y * 2.0, 0.0, 1.0);\n"
  "  return o;\n"
  "}\n"
  "float band(float r, float r0, float r1) { return min(saturate(r - r0 + 0.5), saturate(r1 - r + 0.5)); }\n"
  "float4 over(float4 d, float3 c, float a) {\n"
  "  float oa = a + d.a * (1.0 - a);\n"
  "  float3 oc = (c * a + d.rgb * d.a * (1.0 - a)) / max(oa, 0.00001);\n"
  "  return float4(oc, oa);\n"
  "}\n"
  "float4 PSMain(VO i) : SV_Target {\n"
  "  float r = length(i.p) / i.prm.x;\n"                    // the design is for a half size of 64 px
  "  float4 c = float4(0.0, 0.0, 0.0, 0.0);\n"
  "  c = over(c, float3(0.05, 0.05, 0.06), band(r, 34.0, 50.0) * 0.85);\n"    // dark outline of the ring
  "  c = over(c, float3(1.0, 1.0, 1.0), band(r, 37.5, 46.5));\n"             // white ring
  "  float dot_r = i.prm.y > 0.5 ? 13.0 : 10.0;\n"
  "  c = over(c, float3(0.05, 0.05, 0.06), band(r, 0.0, dot_r + 3.0) * 0.85);\n"   // dark outline of the dot
  "  float3 dc = i.prm.y > 0.5 ? float3(0.98, 0.78, 0.15) : float3(0.87, 0.24, 0.15);\n"
  "  c = over(c, dc, band(r, 0.0, dot_r));\n"                                 // red dot (yellow while the trigger is down)
  "  return c;\n"
  "}\n";

ID3D11Device* g_dev;
ID3D11VertexShader* g_vs;
ID3D11PixelShader* g_ps;
ID3D11RasterizerState* g_rs;
ID3D11DepthStencilState* g_ds;
ID3D11BlendState* g_bs;
ID3D11Buffer* g_cb;
int g_state, g_failures, g_logged;
struct { volatile LONG draws, failed; int lastX, lastY; } g_s;

template <class T> void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

void release_all() {
  rel(g_vs); rel(g_ps); rel(g_rs); rel(g_ds); rel(g_bs); rel(g_cb);
  g_dev = nullptr; g_state = 0;
}

int create_resources(ID3D11Device* dev) {
  HMODULE lib = LoadLibraryW(L"d3dcompiler_47.dll");
  if (!lib) return -1;
  pD3DCompile compile = (pD3DCompile)GetProcAddress(lib, "D3DCompile");
  if (!compile) return -2;
  ID3DBlob *vsb = nullptr, *psb = nullptr, *err = nullptr;
  HRESULT h = compile(kShader, lstrlenA(kShader), "gbvr_cursor", nullptr, nullptr, "VSMain", "vs_4_0", 0, 0, &vsb, &err);
  if (FAILED(h) || !vsb) {
    if (err) { log_line("FLATCURSOR vertex shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    return -3;
  }
  h = compile(kShader, lstrlenA(kShader), "gbvr_cursor", nullptr, nullptr, "PSMain", "ps_4_0", 0, 0, &psb, &err);
  if (FAILED(h) || !psb) {
    if (err) { log_line("FLATCURSOR pixel shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    vsb->Release();
    return -4;
  }
  int rc = 0;
  if (FAILED(dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs))) rc = -5;
  else if (FAILED(dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps))) rc = -6;
  vsb->Release(); psb->Release();
  if (rc) return rc;
  D3D11_RASTERIZER_DESC rd;
  ZeroMemory(&rd, sizeof(rd));
  rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
  if (FAILED(dev->CreateRasterizerState(&rd, &g_rs))) return -8;
  D3D11_DEPTH_STENCIL_DESC dd;
  ZeroMemory(&dd, sizeof(dd));
  dd.DepthEnable = FALSE; dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO; dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
  dd.StencilEnable = FALSE; dd.StencilReadMask = 0xff; dd.StencilWriteMask = 0xff;
  dd.FrontFace.StencilFailOp = dd.FrontFace.StencilDepthFailOp = dd.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
  dd.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
  dd.BackFace = dd.FrontFace;
  if (FAILED(dev->CreateDepthStencilState(&dd, &g_ds))) return -9;
  D3D11_BLEND_DESC bl;
  ZeroMemory(&bl, sizeof(bl));
  bl.RenderTarget[0].BlendEnable = TRUE;
  bl.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA; bl.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA; bl.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
  bl.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ZERO; bl.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE; bl.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
  bl.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_RED | D3D11_COLOR_WRITE_ENABLE_GREEN | D3D11_COLOR_WRITE_ENABLE_BLUE;   // the picture's alpha stays as it is
  if (FAILED(dev->CreateBlendState(&bl, &g_bs))) return -10;
  D3D11_BUFFER_DESC bd;
  ZeroMemory(&bd, sizeof(bd));
  bd.ByteWidth = 16; bd.Usage = D3D11_USAGE_DEFAULT; bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
  if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_cb))) return -11;
  return 1;
}

struct Saved {
  ID3D11RenderTargetView* rtv[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT]; ID3D11DepthStencilView* dsv;
  D3D11_VIEWPORT vp[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE]; UINT nvp;
  ID3D11RasterizerState* rs; ID3D11BlendState* bs; float bf[4]; UINT mask; ID3D11DepthStencilState* ds; UINT sref;
  ID3D11InputLayout* il; D3D11_PRIMITIVE_TOPOLOGY topo;
  ID3D11VertexShader* vs; ID3D11PixelShader* ps; ID3D11GeometryShader* gs; ID3D11HullShader* hs; ID3D11DomainShader* dsh;
  ID3D11Buffer* vcb;
};

void save(ID3D11DeviceContext* c, Saved* s) {
  ZeroMemory(s, sizeof(*s));
  c->OMGetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, s->rtv, &s->dsv);
  s->nvp = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
  c->RSGetViewports(&s->nvp, s->vp);
  c->RSGetState(&s->rs);
  c->OMGetBlendState(&s->bs, s->bf, &s->mask);
  c->OMGetDepthStencilState(&s->ds, &s->sref);
  c->IAGetInputLayout(&s->il);
  c->IAGetPrimitiveTopology(&s->topo);
  c->VSGetShader(&s->vs, nullptr, nullptr);
  c->PSGetShader(&s->ps, nullptr, nullptr);
  c->GSGetShader(&s->gs, nullptr, nullptr);
  c->HSGetShader(&s->hs, nullptr, nullptr);
  c->DSGetShader(&s->dsh, nullptr, nullptr);
  c->VSGetConstantBuffers(0, 1, &s->vcb);
}

void restore(ID3D11DeviceContext* c, Saved* s) {
  c->OMSetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, s->rtv, s->dsv);
  c->RSSetViewports(s->nvp, s->vp);
  c->RSSetState(s->rs);
  c->OMSetBlendState(s->bs, s->bf, s->mask);
  c->OMSetDepthStencilState(s->ds, s->sref);
  c->IASetInputLayout(s->il);
  c->IASetPrimitiveTopology(s->topo);
  c->VSSetShader(s->vs, nullptr, 0);
  c->PSSetShader(s->ps, nullptr, 0);
  c->GSSetShader(s->gs, nullptr, 0);
  c->HSSetShader(s->hs, nullptr, 0);
  c->DSSetShader(s->dsh, nullptr, 0);
  c->VSSetConstantBuffers(0, 1, &s->vcb);
  for (int i = 0; i < D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT; ++i) rel(s->rtv[i]);
  rel(s->dsv); rel(s->rs); rel(s->bs); rel(s->ds); rel(s->il);
  rel(s->vs); rel(s->ps); rel(s->gs); rel(s->hs); rel(s->dsh); rel(s->vcb);
}

void fail(const char* why, int code) {
  InterlockedIncrement(&g_s.failed);
  ++g_failures;
  if (g_logged < 6) { ++g_logged; log_line("FLATCURSOR problem: %s (%d), failure %d of 3", why, code, g_failures); }
  if (g_failures >= 3) {
    InterlockedExchange(&g_ctl.flatCursor, 0);
    log_line("FLATCURSOR switched OFF after three problems: the 2D screen has no ring cursor (the game's own pointer is still there)");
    settings_changed();
  }
}
}  // namespace

void flatcursor_release() { release_all(); }

// u, v: picture coordinates 0..1 (v from the top). sizePct: ring size. Returns 1 when the ring was drawn.
int flatcursor_draw(void* device, void* context, void* texture, unsigned w, unsigned h, float u, float v, int sizePct, int pressed) {
  ID3D11Device* dev = (ID3D11Device*)device;
  ID3D11DeviceContext* ctx = (ID3D11DeviceContext*)context;
  ID3D11Texture2D* tex = (ID3D11Texture2D*)texture;
  if (!dev || !ctx || !tex || w < 64 || h < 64) return 0;
  if (dev != g_dev) { release_all(); g_dev = dev; }
  if (g_state == 0) {
    g_state = create_resources(dev);
    if (g_state < 0) {
      int code = g_state;
      release_all();
      g_dev = dev;
      fail("shaders / states could not be created", code);
      return 0;
    }
    log_line("FLATCURSOR ready: picture %u x %u", w, h);
  }
  ID3D11RenderTargetView* rtv = nullptr;
  if (FAILED(dev->CreateRenderTargetView(tex, nullptr, &rtv)) || !rtv) { fail("render target view could not be made", 0); return 0; }
  if (sizePct < 40) sizePct = 40;
  if (sizePct > 250) sizePct = 250;
  const float half = 64.0f * (float)sizePct / 100.0f;
  const float cx = u * (float)(w - 1), cy = v * (float)(h - 1);
  float a[4] = {half, pressed ? 1.0f : 0.0f, 0.0f, 0.0f};
  ctx->UpdateSubresource(g_cb, 0, nullptr, a, 0, 0);
  Saved sv;
  save(ctx, &sv);
  ctx->OMSetRenderTargets(1, &rtv, nullptr);
  D3D11_VIEWPORT vp;
  vp.TopLeftX = cx - half; vp.TopLeftY = cy - half; vp.Width = half * 2.0f; vp.Height = half * 2.0f; vp.MinDepth = 0; vp.MaxDepth = 1;
  ctx->RSSetViewports(1, &vp);
  ctx->RSSetState(g_rs);
  const float bf[4] = {0, 0, 0, 0};
  ctx->OMSetBlendState(g_bs, bf, 0xffffffffu);
  ctx->OMSetDepthStencilState(g_ds, 0);
  ctx->IASetInputLayout(nullptr);
  ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  ctx->VSSetShader(g_vs, nullptr, 0);
  ctx->VSSetConstantBuffers(0, 1, &g_cb);
  ctx->GSSetShader(nullptr, nullptr, 0);
  ctx->HSSetShader(nullptr, nullptr, 0);
  ctx->DSSetShader(nullptr, nullptr, 0);
  ctx->PSSetShader(g_ps, nullptr, 0);
  ctx->Draw(3, 0);
  restore(ctx, &sv);
  rtv->Release();
  g_failures = 0;
  InterlockedIncrement(&g_s.draws);
  g_s.lastX = (int)cx; g_s.lastY = (int)cy;
  if (g_s.draws <= 3) log_line("FLATCURSOR drawn at picture pixel %d,%d (u %.3f v %.3f) ring half size %.0f px pressed=%d", (int)cx, (int)cy, (double)u, (double)v, (double)half, pressed);
  return 1;
}

void flatcursor_report(long frame) {
  log_line("FLATCURSOR frame=%d on=%d state=%d size=%d%% draws=%d failed=%d last=%d,%d", (int)frame, (int)g_ctl.flatCursor, g_state, (int)g_ctl.flatCursorPct,
           (int)g_s.draws, (int)g_s.failed, g_s.lastX, g_s.lastY);
}

#endif
