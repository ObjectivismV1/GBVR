// 0.95 the TV glow around the flat 2D screen (menus, cutscenes). Render thread, once per flat-screen frame.
// 1.1: the calm glow no longer re-sends its picture to SteamVR (that blinked): the soft halo goes up ONCE, white; only its colour (SetOverlayColor) and its fade change after that.
//
// The picture the game just drew is already copied into a texture for the screen overlay (stereo.cpp). Here a second copy is shrunk on the graphics card
// (the driver's own mip chain, a few hundred microseconds) down to a grid of about 15 x 8 cells, read back a frame later without waiting, turned into a soft,
// see-through halo picture (glowmath.h) and given to SteamVR as an overlay just behind the screen. Nothing of the game's pipeline state is touched: only copies
// and GenerateMips on textures owned by the probe. Where the card cannot do it (an unusual back-buffer format, no mip generation) the halo stays a soft
// constant blue-white instead, and the log says why.
#include "gbvr.h"
#include "glowmath.h"
#include "vr_pose.h"
#include <d3d11.h>
#include <string.h>

namespace {

static const int kBaseW = 160;       // halo picture width in pixels
static const int kMaxH = 192;        // ... and its tallest
static const int kMaxCells = 24;     // the card-side shrink stops when both sides are at most this many cells
static const double kReadEverySec = 0.09;    // a new reading of the picture at most this often
static const double kHaloEverySec = 0.066;   // the halo picture is refreshed at most this often (15 Hz)

struct Gpu {
  ID3D11Device* dev;
  ID3D11Texture2D* mip;               // the picture + its mip chain
  ID3D11ShaderResourceView* srv;
  ID3D11Texture2D* stage;             // one mip level, readable by the CPU
  UINT w, h;
  DXGI_FORMAT fmt;
  int kind, level, lw, lh;
} g_gpu;

int g_state;        // 0 not tried, 1 working, -1 not available (the halo is constant)
int g_pending;      // a copy to the staging texture is on its way
int64_t g_issueQ, g_haloQ;
glow::Grid g_grid;  // the latest reading
int g_haveGrid;
glow::Grid g_slow;  // 0.98: the readings averaged over several seconds (the calm glow)
int g_haveSlow;
int64_t g_slowQ;
static const double kSteadyTauSec = 5.0;   // 0.98: how slowly the calm glow follows the picture's colours
static const double kTintTauSec = 6.0, kTintMaxPerSec = 0.05;   // 1.1: the steady glow's colour: time constant, and at most this much of a colour channel per second
static const double kCornerTauSec = 0.55, kCornerMaxPerSec = 1.4;   // 1.7.161: quicker (a cutscene's shots change colour; 1.3 s / 0.45 lagged a whole shot behind)
static int g_freshGrid; static long g_snaps;   // 1.7.161: a reading of THIS flat screen has come in (the old screen's reading is never used for a new one)   // 1.7.151: the corner colours follow the picture in a second or two (still a drift, not a flash)
static const double kFadeInSecs = 1.6;                          // 1.1: the glow fades in this slowly when a flat screen appears
struct {
  int haveTex, texW, texH; double texPct, texAspect;   // the one halo picture that is up
  glow::Tint tint; int haveTint; int64_t tintQ, showQ;
  glow::Tint lastTarget;
  int corners;                         // 1.7.151: 1 = the four corner layers are up (0 = the single one)
  glow::Tint ctint[4], ctarget[4]; LONG cornerSessions, cornerFails; int cornerLogged;
  LONG uploads, tintCalls, tintFails, sessions; float maxStep; int logged;
} g_sd;
float g_cur[kBaseW * kMaxH * 4], g_tgt[kBaseW * kMaxH * 4];
int g_cornerFailRun;
int g_cornersOff;   // 1.7.151: SteamVR refused a corner layer: the single glow is used for the rest of the session
uint8_t g_bytes[kBaseW * kMaxH * 4];
int g_curW, g_curH, g_haveCur, g_shown, g_uploaded;
float g_lastXf[12];
double g_lastWidthM;
unsigned g_frameNo;
double g_lastPct = -1;
int g_lastSteady = -1;
struct {
  LONG frames, setups, setupFails, issued, reads, stuck, readFails, uploads, uploadFails, hidden;
  int lastErr, lastFmt;
  float lastMean[3];
  int lastBars[4];
  LONG readLogs;
  int64_t firstQ;
} g_st;

int fmt_kind(DXGI_FORMAT f) {
  switch (f) {
    case DXGI_FORMAT_R8G8B8A8_UNORM: case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: return glow::kRGBA8;
    case DXGI_FORMAT_B8G8R8A8_UNORM: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB:
    case DXGI_FORMAT_B8G8R8X8_UNORM: case DXGI_FORMAT_B8G8R8X8_UNORM_SRGB: return glow::kBGRA8;
    case DXGI_FORMAT_R10G10B10A2_UNORM: return glow::kRGB10A2;
    default: return -1;
  }
}

void gpu_release() {
  if (g_gpu.stage) g_gpu.stage->Release();
  if (g_gpu.srv) g_gpu.srv->Release();
  if (g_gpu.mip) g_gpu.mip->Release();
  if (g_gpu.dev) g_gpu.dev->Release();
  memset(&g_gpu, 0, sizeof(g_gpu));
  g_pending = 0;
}

int fail(const char* why, HRESULT hr) {
  g_state = -1;
  ++g_st.setupFails;
  g_st.lastErr = (int)hr;
  log_line("FLATGLOW the picture cannot be read back (%s, code %08x): the TV glow stays a soft constant light", why, (unsigned)hr);
  gpu_release();
  return 0;
}

int gpu_setup(ID3D11Device* dev, UINT w, UINT h, DXGI_FORMAT fmt) {
  gpu_release();
  ++g_st.setups;
  g_st.lastFmt = (int)fmt;
  const int kind = fmt_kind(fmt);
  if (kind < 0) return fail("back-buffer format not supported for the readback", (HRESULT)fmt);
  UINT sup = 0;
  HRESULT hr = dev->CheckFormatSupport(fmt, &sup);
  if (FAILED(hr) || !(sup & D3D11_FORMAT_SUPPORT_MIP_AUTOGEN)) return fail("the card cannot make mip levels for this format", hr);
  D3D11_TEXTURE2D_DESC d;
  ZeroMemory(&d, sizeof(d));
  d.Width = w; d.Height = h; d.MipLevels = 0; d.ArraySize = 1; d.Format = fmt;
  d.SampleDesc.Count = 1; d.Usage = D3D11_USAGE_DEFAULT;
  d.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
  d.MiscFlags = D3D11_RESOURCE_MISC_GENERATE_MIPS;
  ID3D11Texture2D* mip = nullptr;
  hr = dev->CreateTexture2D(&d, nullptr, &mip);
  if (FAILED(hr) || !mip) return fail("could not create the shrink texture", hr);
  D3D11_TEXTURE2D_DESC got;
  mip->GetDesc(&got);
  int level = 0;
  while ((((int)w >> level) > kMaxCells || ((int)h >> level) > kMaxCells) && level + 1 < (int)got.MipLevels) ++level;
  int lw = (int)w >> level, lh = (int)h >> level;
  if (lw < 1) lw = 1;
  if (lh < 1) lh = 1;
  if (lw > kMaxCells || lh > kMaxCells) { mip->Release(); return fail("the picture is too big to shrink to a small grid", (HRESULT)level); }
  ID3D11ShaderResourceView* srv = nullptr;
  hr = dev->CreateShaderResourceView(mip, nullptr, &srv);
  if (FAILED(hr) || !srv) { mip->Release(); return fail("could not create the view for the shrink", hr); }
  D3D11_TEXTURE2D_DESC s;
  ZeroMemory(&s, sizeof(s));
  s.Width = (UINT)lw; s.Height = (UINT)lh; s.MipLevels = 1; s.ArraySize = 1; s.Format = fmt;
  s.SampleDesc.Count = 1; s.Usage = D3D11_USAGE_STAGING; s.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
  ID3D11Texture2D* stage = nullptr;
  hr = dev->CreateTexture2D(&s, nullptr, &stage);
  if (FAILED(hr) || !stage) { srv->Release(); mip->Release(); return fail("could not create the readable texture", hr); }
  dev->AddRef();
  g_gpu.dev = dev; g_gpu.mip = mip; g_gpu.srv = srv; g_gpu.stage = stage;
  g_gpu.w = w; g_gpu.h = h; g_gpu.fmt = fmt; g_gpu.kind = kind; g_gpu.level = level; g_gpu.lw = lw; g_gpu.lh = lh;
  g_state = 1;
  log_line("FLATGLOW ready: picture %u x %u format %d shrunk to level %d = %d x %d cells (mip chain of %u levels), read back about every %d ms",
           w, h, (int)fmt, level, lw, lh, (unsigned)got.MipLevels, (int)(kReadEverySec * 1000.0));
  return 1;
}

void note_reading(const glow::Grid& g) {
  const glow::Insets in = glow::bars(g);
  float m[3];
  glow::mean_rgb(g, in, m);
  g_st.lastMean[0] = m[0]; g_st.lastMean[1] = m[1]; g_st.lastMean[2] = m[2];
  g_st.lastBars[0] = in.l; g_st.lastBars[1] = in.r; g_st.lastBars[2] = in.t; g_st.lastBars[3] = in.b;
  // the first 4 readings, then one in about 40 s: what the card read (colour of the picture, black bars skipped)
  if (g_st.readLogs < 4 || (g_st.reads % 400) == 0) {
    ++g_st.readLogs;
    log_line("FLATGLOW reading #%ld: %d x %d cells, mean colour %.2f,%.2f,%.2f, black bars skipped (left/right/top/bottom cells) %d/%d/%d/%d, corner cells %.2f,%.2f,%.2f | %.2f,%.2f,%.2f",
             g_st.reads, g.w, g.h, m[0], m[1], m[2], in.l, in.r, in.t, in.b,
             g.c[0], g.c[1], g.c[2], g.c[(g.w - 1) * 3], g.c[(g.w - 1) * 3 + 1], g.c[(g.w - 1) * 3 + 2]);
  }
}

}  // namespace

void flatglow_release() {
  gpu_release();
  g_state = 0;
  g_haveGrid = 0; g_haveSlow = 0; g_slowQ = 0;
  g_haveCur = 0;
  g_shown = 0; g_uploaded = 0;
  g_haloQ = g_issueQ = 0;
  g_sd.haveTex = 0; g_sd.haveTint = 0; g_sd.showQ = 0;
}

void flatglow_hide() {   // the 3D picture is back: the layer is hidden by vr_capi_overlay_hide(); the next flat screen starts its fade-in again
  if (g_shown) ++g_st.hidden;
  g_shown = 0; g_haveCur = 0; g_uploaded = 0; g_pending = 0;
  g_haveGrid = 0; g_freshGrid = 0;   // 1.7.161: the next flat screen (a menu after a cutscene) never starts in the last screen's colours
  g_haveSlow = 0; g_slowQ = 0;   // 0.98: the next flat screen starts its calm average from its own first reading
  g_sd.haveTex = 0; g_sd.haveTint = 0; g_sd.showQ = 0; g_lastSteady = -1;   // 1.1: the next flat screen sends its halo picture once more and fades in again
}

void flatglow_frame(void* devp, void* ctxp, void* flatp, unsigned w, unsigned h, int fmt, const float* xf, float screenWidthM, float aspect) {
  ID3D11Device* dev = (ID3D11Device*)devp;
  ID3D11DeviceContext* ctx = (ID3D11DeviceContext*)ctxp;
  ID3D11Texture2D* flat = (ID3D11Texture2D*)flatp;
  ++g_st.frames;
  const double pct = (double)g_ctl.flatGlowPct;
  if (pct <= 0.0) {   // off (menu): the layer is hidden and starts again from nothing when it is switched on
    if (g_shown) { for (int gi = 0; gi < 5; ++gi) vr_capi_glow_overlay_n(gi, nullptr, 0, 0, nullptr, 0, 0); g_shown = 0; g_haveCur = 0; g_uploaded = 0; ++g_st.hidden; g_sd.haveTex = 0; g_sd.haveTint = 0; g_sd.showQ = 0; }
    return;
  }
  if (!dev || !ctx || !flat || !xf || w == 0 || h == 0 || !(aspect > 0.1f) || !(screenWidthM > 0.1f)) return;
  const int64_t now = qpc_now();
  const double freq = (double)qpc_freq();
  if (!g_st.firstQ) g_st.firstQ = now;

  // ---- 1. the card side: shrink, read back (never waits) -------------------------------------------------
  if (g_state != -1 && (g_gpu.dev != dev || g_gpu.w != w || g_gpu.h != h || g_gpu.fmt != (DXGI_FORMAT)fmt)) gpu_setup(dev, w, h, (DXGI_FORMAT)fmt);
  else if (g_state == -1 && (g_gpu.fmt != (DXGI_FORMAT)fmt) && g_st.lastFmt != fmt) { g_state = 0; gpu_setup(dev, w, h, (DXGI_FORMAT)fmt); }   // another format: try again once
  if (g_state == 1 && g_gpu.stage) {
    if (g_pending) {
      D3D11_MAPPED_SUBRESOURCE ms;
      const HRESULT hr = ctx->Map(g_gpu.stage, 0, D3D11_MAP_READ, D3D11_MAP_FLAG_DO_NOT_WAIT, &ms);
      if (hr == S_OK) {
        glow::Grid g;
        if (glow::decode((const uint8_t*)ms.pData, ms.RowPitch, g_gpu.lw, g_gpu.lh, g_gpu.kind, &g)) {
          g_grid = g; g_haveGrid = 1; g_freshGrid = 1; ++g_st.reads; note_reading(g_grid);
          const double dtSlow = g_haveSlow && g_slowQ ? (double)(now - g_slowQ) / freq : 1.0;   // the very first reading counts fully
          if (!g_haveSlow) { g_slow = g; g_haveSlow = 1; } else glow::blend_toward(&g_slow, g, dtSlow, kSteadyTauSec);
          g_slowQ = now;
        }
        else ++g_st.readFails;
        ctx->Unmap(g_gpu.stage, 0);
        g_pending = 0;
      } else if (hr == DXGI_ERROR_WAS_STILL_DRAWING) {
        if ((double)(now - g_issueQ) / freq > 0.5) { g_pending = 0; ++g_st.stuck; }   // the card is behind: forget this one, ask again
      } else {
        ++g_st.readFails; g_st.lastErr = (int)hr; g_pending = 0;
        if (g_st.readFails <= 3) log_line("FLATGLOW reading the shrunk picture failed (code %08x)", (unsigned)hr);
        if (g_st.readFails >= 20 && g_st.reads == 0) { g_state = -1; log_line("FLATGLOW giving up on the readback: the TV glow stays a soft constant light"); }
      }
    }
    if (!g_pending && g_state == 1 && (double)(now - g_issueQ) / freq >= kReadEverySec) {
      ctx->CopySubresourceRegion(g_gpu.mip, 0, 0, 0, 0, flat, 0, nullptr);
      ctx->GenerateMips(g_gpu.srv);
      ctx->CopySubresourceRegion(g_gpu.stage, 0, 0, 0, 0, g_gpu.mip, (UINT)g_gpu.level, nullptr);
      g_pending = 1; g_issueQ = now; ++g_st.issued;
    }
  }

  // ---- 1.1 the steady glow: the halo picture once, then only a colour and a fade --------------------------------------------
  if (g_ctl.flatGlowSteady != 0) {
    glow::Look look = glow::steady_look(pct / 100.0, (double)aspect);
    int iw, ih;
    glow::image_size(look, kBaseW, &iw, &ih);
    if (ih > kMaxH) ih = kMaxH;
    const int corners = g_ctl.flatGlowCorners != 0 && !g_cornersOff;
    if (g_shown && corners != g_sd.corners) {   // switched: the other kind of layer goes, this one starts from its picture
      for (int gi = 0; gi < 5; ++gi) vr_capi_glow_overlay_n(gi, nullptr, 0, 0, nullptr, 0, 0);
      g_shown = 0; g_sd.haveTex = 0; g_sd.haveTint = 0;
    }
    g_sd.corners = corners;
    const int first = corners ? 1 : 0, count = corners ? 4 : 1;
    const int texNew = !g_sd.haveTex || iw != g_sd.texW || ih != g_sd.texH || pct != g_sd.texPct || (double)aspect != g_sd.texAspect;
    const int moved = memcmp(g_lastXf, xf, sizeof(g_lastXf)) != 0 || screenWidthM != (float)g_lastWidthM;
    if (texNew || moved || !g_shown) {
      if (texNew) {   // the see-through halo, white: the colour comes from the layer's tint
        glow::Grid white;
        glow::fill_grid(&white, 4, 3, 1.0f, 1.0f, 1.0f);
        glow::render_target(white, look, iw, ih, g_tgt);
      }
      double qw, qh;
      glow::quad_units(look, &qw, &qh);
      if (!g_shown && !g_sd.showQ) g_sd.showQ = now;
      int e = 0;
      for (int k = 0; k < count && e == 0; ++k) {
        const uint8_t* bytes = nullptr;
        if (texNew) {
          if (corners) { glow::corner_mask(g_tgt, iw, ih, k, g_cur); glow::to_bytes(g_cur, iw, ih, g_bytes, 0u); }
          else glow::to_bytes(g_tgt, iw, ih, g_bytes, 0u);   // a fixed dither: the picture never changes while it is up
          bytes = g_bytes;
        }
        if (!g_shown) vr_capi_glow_tint_n(first + k, glow::default_tint().r, glow::default_tint().g, glow::default_tint().b, 0.0f);   // a layer that exists already starts invisible: no one-frame pop
        e = vr_capi_glow_overlay_n(first + k, bytes, iw, ih, xf, (float)((double)screenWidthM * qw), 1);
      }
      if (e == 0) {
        if (texNew) { ++g_st.uploads; ++g_sd.uploads; g_sd.haveTex = 1; g_sd.texW = iw; g_sd.texH = ih; g_sd.texPct = pct; g_sd.texAspect = (double)aspect; g_curW = iw; g_curH = ih; }
        for (int i = 0; i < 12; ++i) g_lastXf[i] = xf[i];
        g_lastWidthM = screenWidthM; g_lastPct = pct; g_lastSteady = 1; g_uploaded = 1; g_shown = 1;
        if (g_sd.sessions == 0 || !g_sd.haveTint) { ++g_sd.sessions; if (corners) ++g_sd.cornerSessions; }
        if (corners) g_cornerFailRun = 0;
      } else {
        ++g_st.uploadFails; g_st.lastErr = e;
        if (g_st.uploadFails <= 4) log_line("FLATGLOW the glow layer could not be shown (SteamVR code %d)", e);
        if (corners) {   // the corner layers did not all come up: none of them stays, the single glow takes over from the next frame (the glow is never lost)
          for (int gi = 1; gi < 5; ++gi) vr_capi_glow_overlay_n(gi, nullptr, 0, 0, nullptr, 0, 0);
          ++g_sd.cornerFails; g_sd.haveTex = 0; g_sd.haveTint = 0; g_shown = 0;
          if (++g_cornerFailRun >= 3) { g_cornersOff = 1; log_line("GLOWCORNERS SteamVR refused a corner layer 3 times in a row (code %d): the single glow is used instead", e); }   // one bad frame is tried again
        }
        return;
      }
    }
    if (g_shown) {
      const float fade = glow::fade_in(g_sd.showQ ? (double)(now - g_sd.showQ) / freq : 0.0, kFadeInSecs);
      const double dt = g_sd.haveTint ? (double)(now - g_sd.tintQ) / freq : 0.0;
      if (corners) {
        const glow::Insets in = g_haveGrid ? glow::bars(g_grid) : glow::Insets{0, 0, 0, 0};
        for (int k = 0; k < 4; ++k) {
          glow::Tint target = glow::default_tint();
          if (g_haveGrid) { float m[3]; glow::corner_mean(g_grid, in, k, m); target = glow::corner_target(m); }
          else { static const float kBlack3[3] = {0.0f, 0.0f, 0.0f}; target = glow::corner_target(kBlack3); }   // 1.7.161: no reading yet: the faint neutral light, not blue
          if (!g_sd.haveTint) g_sd.ctint[k] = target;   // a new screen starts in its own colours (it fades in from nothing anyway)
          if (g_freshGrid == 1 && fade < 0.6f) { g_sd.ctint[k] = target; if (k == 3) { g_freshGrid = 2; ++g_snaps; } }   // 1.7.161: its first own reading: straight to its colours while the glow is still fading in
          const glow::Tint before = g_sd.ctint[k];
          glow::follow_tint(&g_sd.ctint[k], target, dt, kCornerTauSec, kCornerMaxPerSec);
          const float step = (float)(vm::dabs((double)(g_sd.ctint[k].r - before.r)) + vm::dabs((double)(g_sd.ctint[k].g - before.g)) + vm::dabs((double)(g_sd.ctint[k].b - before.b)));
          if (step > g_sd.maxStep) g_sd.maxStep = step;
          g_sd.ctarget[k] = target;
          if (vr_capi_glow_tint_n(1 + k, g_sd.ctint[k].r, g_sd.ctint[k].g, g_sd.ctint[k].b, fade) == 0) ++g_sd.tintCalls; else ++g_sd.tintFails;
        }
        g_sd.tint = g_sd.ctint[0]; g_sd.lastTarget = g_sd.ctarget[0];
        g_sd.haveTint = 1; g_sd.tintQ = now;
        if (g_sd.cornerLogged < 8 && (g_sd.tintCalls <= 4 || (g_sd.tintCalls % 1600) < 4)) {
          ++g_sd.cornerLogged;
          log_line("GLOWCORNERS on: the glow's four corners now (r,g,b) top-left %.2f,%.2f,%.2f top-right %.2f,%.2f,%.2f bottom-left %.2f,%.2f,%.2f bottom-right %.2f,%.2f,%.2f | picture read %d, fade %.2f, 4 halo pictures %dx%d sent %ld time(s), colour updates %ld (fails %ld)",
                   (double)g_sd.ctint[0].r, (double)g_sd.ctint[0].g, (double)g_sd.ctint[0].b, (double)g_sd.ctint[1].r, (double)g_sd.ctint[1].g, (double)g_sd.ctint[1].b, (double)g_sd.ctint[2].r, (double)g_sd.ctint[2].g, (double)g_sd.ctint[2].b,
                   (double)g_sd.ctint[3].r, (double)g_sd.ctint[3].g, (double)g_sd.ctint[3].b, g_haveGrid, (double)fade, iw, ih, (long)g_sd.uploads, (long)g_sd.tintCalls, (long)g_sd.tintFails);
        }
        return;
      }
      glow::Tint target = glow::default_tint();
      if (g_haveGrid) {
        float m[3];
        glow::mean_rgb(g_grid, glow::bars(g_grid), m);
        target = glow::ambient_target(m);
      }
      if (!g_sd.haveTint) { g_sd.tint = glow::default_tint(); g_sd.haveTint = 1; }
      g_sd.tintQ = now;
      const glow::Tint before = g_sd.tint;
      glow::follow_tint(&g_sd.tint, target, dt, kTintTauSec, kTintMaxPerSec);
      const float step = (float)(vm::dabs((double)(g_sd.tint.r - before.r)) + vm::dabs((double)(g_sd.tint.g - before.g)) + vm::dabs((double)(g_sd.tint.b - before.b)));
      if (step > g_sd.maxStep) g_sd.maxStep = step;
      g_sd.lastTarget = target;
      if (vr_capi_glow_tint(g_sd.tint.r, g_sd.tint.g, g_sd.tint.b, fade) == 0) ++g_sd.tintCalls; else ++g_sd.tintFails;
      if (g_sd.logged < 6 && (g_sd.tintCalls == 1 || (g_sd.tintCalls % 400) == 0)) {
        ++g_sd.logged;
        log_line("GLOWTINT steady glow: colour now %.2f,%.2f,%.2f (the picture asks for %.2f,%.2f,%.2f, default %.2f,%.2f,%.2f), fade %.2f, halo picture %dx%d sent %ld time(s), colour updates %ld",
                 (double)g_sd.tint.r, (double)g_sd.tint.g, (double)g_sd.tint.b, (double)target.r, (double)target.g, (double)target.b,
                 (double)glow::default_tint().r, (double)glow::default_tint().g, (double)glow::default_tint().b, (double)fade, iw, ih, (long)g_sd.uploads, (long)g_sd.tintCalls);
      }
    }
    return;
  }

  if (g_sd.corners) { for (int gi = 1; gi < 5; ++gi) vr_capi_glow_overlay_n(gi, nullptr, 0, 0, nullptr, 0, 0); g_sd.corners = 0; g_sd.haveTex = 0; g_shown = 0; g_uploaded = 0; g_haveCur = 0; }
  // ---- 2. the halo picture: at most 15 times a second -----------------------------------------------------
  const int changed = pct != g_lastPct || (g_ctl.flatGlowSteady != 0) != g_lastSteady || memcmp(g_lastXf, xf, sizeof(g_lastXf)) != 0 || screenWidthM != (float)g_lastWidthM;
  if (!changed && g_uploaded && (double)(now - g_haloQ) / freq < kHaloEverySec) return;
  g_haloQ = now;
  const int steady = g_ctl.flatGlowSteady != 0;
  glow::Look look = steady ? glow::steady_look(pct / 100.0, (double)aspect) : glow::default_look(pct / 100.0, (double)aspect);
  int iw, ih;
  glow::image_size(look, kBaseW, &iw, &ih);
  if (ih > kMaxH) ih = kMaxH;
  glow::Grid use;
  if (steady && g_haveSlow) use = g_slow;       // 0.98: the slow average (does not flash)
  else if (g_haveGrid) use = g_grid;
  else glow::fill_grid(&use, 4, 3, 0.30f, 0.36f, 0.50f);   // no reading (yet / at all): a calm blue-white
  glow::render_target(use, look, iw, ih, g_tgt);
  const int n = iw * ih * 4;
  if (!g_haveCur || g_curW != iw || g_curH != ih) {   // a new halo fades in: right colours at once, no alpha
    for (int i = 0; i < n; ++i) g_cur[i] = g_tgt[i];
    for (int i = 3; i < n; i += 4) g_cur[i] = 0.0f;
    g_curW = iw; g_curH = ih; g_haveCur = 1; g_uploaded = 0;
  }
  const float worst = steady ? glow::ease(g_cur, g_tgt, n, 0.10f, 0.012f) : glow::ease(g_cur, g_tgt, n, 0.18f, 0.10f);   // 0.98: calm = at most ~1 % of the range per step (15 steps a second)
  if (worst > 0.0015f || changed || !g_uploaded) {
    glow::to_bytes(g_cur, iw, ih, g_bytes, ++g_frameNo);
    double qw, qh;
    glow::quad_units(look, &qw, &qh);
    const int e = vr_capi_glow_overlay(g_bytes, iw, ih, xf, (float)((double)screenWidthM * qw), 1);
    if (e == 0) { ++g_st.uploads; g_uploaded = 1; g_shown = 1; for (int i = 0; i < 12; ++i) g_lastXf[i] = xf[i]; g_lastWidthM = screenWidthM; g_lastPct = pct; g_lastSteady = g_ctl.flatGlowSteady != 0; }
    else {
      ++g_st.uploadFails; g_st.lastErr = e;
      if (g_st.uploadFails <= 4) log_line("FLATGLOW the glow layer could not be shown (SteamVR code %d)", e);
    }
  }
}

void flatglow_report(LONG frame) {
  log_line("GLOWTINT frame=%d steady=%d colour=%.2f,%.2f,%.2f lastAsk=%.2f,%.2f,%.2f biggestStepPerFrame=%.4f haloPictureSends=%ld (1 per flat screen is right) colourUpdates=%ld colourFails=%ld flatScreenSessions=%ld fadeIn=%.1fs tau=%.0fs maxPerSec=%.2f",
           (int)frame, (int)g_ctl.flatGlowSteady, (double)g_sd.tint.r, (double)g_sd.tint.g, (double)g_sd.tint.b, (double)g_sd.lastTarget.r, (double)g_sd.lastTarget.g, (double)g_sd.lastTarget.b,
           (double)g_sd.maxStep, (long)g_sd.uploads, (long)g_sd.tintCalls, (long)g_sd.tintFails, (long)g_sd.sessions, kFadeInSecs, kTintTauSec, kTintMaxPerSec);
  log_line("GLOWCORNERS frame=%d new screens put straight in their own colours %ld, follow %.2f s | setting=%d in use=%d (given up=%d) flat screens with corners %ld, refusals %ld | corners now tl %.2f,%.2f,%.2f tr %.2f,%.2f,%.2f bl %.2f,%.2f,%.2f br %.2f,%.2f,%.2f",
           (int)frame, g_snaps, kCornerTauSec, (int)g_ctl.flatGlowCorners, g_sd.corners, g_cornersOff, (long)g_sd.cornerSessions, (long)g_sd.cornerFails, (double)g_sd.ctint[0].r, (double)g_sd.ctint[0].g, (double)g_sd.ctint[0].b, (double)g_sd.ctint[1].r, (double)g_sd.ctint[1].g, (double)g_sd.ctint[1].b,
           (double)g_sd.ctint[2].r, (double)g_sd.ctint[2].g, (double)g_sd.ctint[2].b, (double)g_sd.ctint[3].r, (double)g_sd.ctint[3].g, (double)g_sd.ctint[3].b);
  log_line("FLATGLOW frame=%d glow=%d%% steady=%d void=%d state=%d (1 reads the picture, -1 constant light) flatFrames=%ld setups=%ld setupFails=%ld readsIssued=%ld readsDone=%ld stuck=%ld readFails=%ld uploads=%ld uploadFails=%ld hidden=%ld lastErr=%08x format=%d lastMean=%.2f,%.2f,%.2f bars(l/r/t/b)=%d/%d/%d/%d haloPixels=%dx%d",
           (int)frame, (int)g_ctl.flatGlowPct, (int)g_ctl.flatGlowSteady, (int)g_ctl.flatVoid, g_state, g_st.frames, g_st.setups, g_st.setupFails, g_st.issued, g_st.reads, g_st.stuck, g_st.readFails,
           g_st.uploads, g_st.uploadFails, g_st.hidden, (unsigned)g_st.lastErr, g_st.lastFmt, g_st.lastMean[0], g_st.lastMean[1], g_st.lastMean[2],
           g_st.lastBars[0], g_st.lastBars[1], g_st.lastBars[2], g_st.lastBars[3], g_curW, g_curH);
}
