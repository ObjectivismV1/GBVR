// 0.45 flat view: the game's picture in its own shape when it is shown in the window (outside the headset).
//
// The bigger picture of picture level 3 is 3840 x 2880 (4:3). The window is 16:9, and Windows stretches the
// picture to fill it, so everything looks too wide (and the menus, which the game lays out for 16:9 inside the
// 4:3 picture, look stretched too). Right before the game's own Present this pass
//   1. copies the finished picture (the back buffer) into a texture of its own,
//   2. clears the back buffer to black, and
//   3. draws the copy back into the middle of the back buffer, squeezed sideways so that the stretch that
//      Windows then applies gives the picture exactly its own shape (black bars left and right).
// Nothing else of the game's Direct3D state is left changed (everything touched is saved and restored), no
// reference to the back buffer is kept between frames (a game resizing its swap chain is not blocked), and the
// shaders are compiled at first use with d3dcompiler_47.dll; if that is missing or anything fails three
// times the pass switches itself off and the picture is shown stretched as before (log FLATVIEW).
// While the headset view is active nothing is done (the window is not what the player looks at) - except (1.2) while the headset shows
// a flat 2D screen (menu, video): then the window gets the same correction, and in the 3D view monitorview.cpp draws the window.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include <d3d11.h>
#include <d3dcompiler.h>
#include "picturemath.h"

namespace {
const char* kShader =
  "Texture2D T : register(t0);\n"
  "SamplerState S : register(s0);\n"
  "struct VO { float4 pos : SV_Position; float2 uv : TEXCOORD0; };\n"
  "VO VSMain(uint id : SV_VertexID) {\n"
  "  VO o;\n"
  "  float2 p = float2((id << 1) & 2, id & 2);\n"
  "  o.uv = p;\n"
  "  o.pos = float4(p.x * 2.0 - 1.0, 1.0 - p.y * 2.0, 0.0, 1.0);\n"
  "  return o;\n"
  "}\n"
  "float4 PSMain(VO i) : SV_Target { return float4(T.SampleLevel(S, i.uv, 0).rgb, 1.0); }\n";

ID3D11Device* g_dev;                       // device the resources below belong to (no reference kept)
ID3D11VertexShader* g_vs;
ID3D11PixelShader* g_ps;
ID3D11SamplerState* g_smp;
ID3D11RasterizerState* g_rs;
ID3D11DepthStencilState* g_ds;
ID3D11BlendState* g_bs;
ID3D11Texture2D* g_copy;
ID3D11ShaderResourceView* g_srv;
UINT g_w, g_h;
DXGI_FORMAT g_fmt;
int g_state;                               // 0 not tried, 1 ready, <0 failed (why)
int g_failures;
struct { volatile LONG draws, notNeeded, skipped, failed; } g_fs;
struct { double x, y, w, h; UINT bw, bh; int cw, ch; } g_last;
volatile LONG g_active;                    // 1 while the last Present drew the corrected picture
volatile LONG g_activeHeadset;             // 1.3: ... while the headset shows the 2D screen (the window then shows the picture in its own shape too)
volatile int64_t g_activeQpc;
int g_logged;

template <class T> void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

void release_all() {
  rel(g_vs); rel(g_ps); rel(g_smp); rel(g_rs); rel(g_ds); rel(g_bs); rel(g_srv); rel(g_copy);
  g_dev = nullptr; g_w = g_h = 0; g_fmt = DXGI_FORMAT_UNKNOWN; g_state = 0;
}

int create_resources(ID3D11Device* dev) {
  HMODULE lib = LoadLibraryW(L"d3dcompiler_47.dll");
  if (!lib) return -1;
  pD3DCompile compile = (pD3DCompile)GetProcAddress(lib, "D3DCompile");
  if (!compile) return -2;
  ID3DBlob *vsb = nullptr, *psb = nullptr, *err = nullptr;
  HRESULT h = compile(kShader, lstrlenA(kShader), "gbvr_flatview", nullptr, nullptr, "VSMain", "vs_4_0", 0, 0, &vsb, &err);
  if (FAILED(h) || !vsb) {
    if (err) { log_line("FLATVIEW vertex shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    return -3;
  }
  h = compile(kShader, lstrlenA(kShader), "gbvr_flatview", nullptr, nullptr, "PSMain", "ps_4_0", 0, 0, &psb, &err);
  if (FAILED(h) || !psb) {
    if (err) { log_line("FLATVIEW pixel shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    vsb->Release();
    return -4;
  }
  int rc = 0;
  if (FAILED(dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs))) rc = -5;
  else if (FAILED(dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps))) rc = -6;
  vsb->Release(); psb->Release();
  if (rc) return rc;
  D3D11_SAMPLER_DESC sd;
  ZeroMemory(&sd, sizeof(sd));
  sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
  sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
  sd.ComparisonFunc = D3D11_COMPARISON_NEVER; sd.MaxLOD = D3D11_FLOAT32_MAX;
  if (FAILED(dev->CreateSamplerState(&sd, &g_smp))) return -7;
  D3D11_RASTERIZER_DESC rd;
  ZeroMemory(&rd, sizeof(rd));
  rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
  if (FAILED(dev->CreateRasterizerState(&rd, &g_rs))) return -8;
  D3D11_DEPTH_STENCIL_DESC dd;
  ZeroMemory(&dd, sizeof(dd));   // depth and stencil off (every enum field still holds a valid value)
  dd.DepthEnable = FALSE; dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO; dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
  dd.StencilEnable = FALSE; dd.StencilReadMask = 0xff; dd.StencilWriteMask = 0xff;
  dd.FrontFace.StencilFailOp = dd.FrontFace.StencilDepthFailOp = dd.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
  dd.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
  dd.BackFace = dd.FrontFace;
  if (FAILED(dev->CreateDepthStencilState(&dd, &g_ds))) return -9;
  D3D11_BLEND_DESC bl;
  ZeroMemory(&bl, sizeof(bl));
  bl.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
  if (FAILED(dev->CreateBlendState(&bl, &g_bs))) return -10;
  return 1;
}

int ensure_copy(ID3D11Device* dev, const D3D11_TEXTURE2D_DESC& d) {
  if (g_copy && g_srv && d.Width == g_w && d.Height == g_h && d.Format == g_fmt) return 1;
  rel(g_srv); rel(g_copy);
  D3D11_TEXTURE2D_DESC t;
  ZeroMemory(&t, sizeof(t));
  t.Width = d.Width; t.Height = d.Height; t.MipLevels = 1; t.ArraySize = 1; t.Format = d.Format;
  t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT; t.BindFlags = D3D11_BIND_SHADER_RESOURCE;
  HRESULT h = dev->CreateTexture2D(&t, nullptr, &g_copy);
  if (SUCCEEDED(h)) h = dev->CreateShaderResourceView(g_copy, nullptr, &g_srv);
  if (FAILED(h)) { rel(g_srv); rel(g_copy); log_line("FLATVIEW copy texture %u x %u format=%d failed: %08x", d.Width, d.Height, (int)d.Format, (unsigned)h); return 0; }
  g_w = d.Width; g_h = d.Height; g_fmt = d.Format;
  return 1;
}

struct Saved {
  ID3D11RenderTargetView* rtv[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT]; ID3D11DepthStencilView* dsv;
  D3D11_VIEWPORT vp[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE]; UINT nvp;
  ID3D11RasterizerState* rs; ID3D11BlendState* bs; float bf[4]; UINT mask; ID3D11DepthStencilState* ds; UINT sref;
  ID3D11InputLayout* il; D3D11_PRIMITIVE_TOPOLOGY topo;
  ID3D11VertexShader* vs; ID3D11PixelShader* ps; ID3D11GeometryShader* gs; ID3D11HullShader* hs; ID3D11DomainShader* dsh;
  ID3D11ShaderResourceView* srv; ID3D11SamplerState* smp;
};

void save(ID3D11DeviceContext* c, Saved* s) {
  ZeroMemory(s, sizeof(*s));
  c->OMGetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, s->rtv, &s->dsv);
  s->nvp = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
  c->RSGetViewports(&s->nvp, s->vp);
  c->RSGetState(&s->rs);
  c->OMGetBlendState(&s->bs, s->bf, &s->mask);
  c->OMGetDepthStencilState(&s->ds, &s->sref);
  c->IAGetInputLayout(&s->il);
  c->IAGetPrimitiveTopology(&s->topo);
  c->VSGetShader(&s->vs, nullptr, nullptr);
  c->PSGetShader(&s->ps, nullptr, nullptr);
  c->GSGetShader(&s->gs, nullptr, nullptr);
  c->HSGetShader(&s->hs, nullptr, nullptr);
  c->DSGetShader(&s->dsh, nullptr, nullptr);
  c->PSGetShaderResources(0, 1, &s->srv);
  c->PSGetSamplers(0, 1, &s->smp);
}

void restore(ID3D11DeviceContext* c, Saved* s) {
  c->OMSetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, s->rtv, s->dsv);
  c->RSSetViewports(s->nvp, s->vp);
  c->RSSetState(s->rs);
  c->OMSetBlendState(s->bs, s->bf, s->mask);
  c->OMSetDepthStencilState(s->ds, s->sref);
  c->IASetInputLayout(s->il);
  c->IASetPrimitiveTopology(s->topo);
  c->VSSetShader(s->vs, nullptr, 0);
  c->PSSetShader(s->ps, nullptr, 0);
  c->GSSetShader(s->gs, nullptr, 0);
  c->HSSetShader(s->hs, nullptr, 0);
  c->DSSetShader(s->dsh, nullptr, 0);
  c->PSSetShaderResources(0, 1, &s->srv);
  c->PSSetSamplers(0, 1, &s->smp);
  for (int i = 0; i < D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT; ++i) rel(s->rtv[i]);
  rel(s->dsv); rel(s->rs); rel(s->bs); rel(s->ds); rel(s->il);
  rel(s->vs); rel(s->ps); rel(s->gs); rel(s->hs); rel(s->dsh); rel(s->srv); rel(s->smp);
}

void fail(const char* why, int code) {
  InterlockedIncrement(&g_fs.failed);
  ++g_failures;
  if (g_logged < 6) { ++g_logged; log_line("FLATVIEW problem: %s (%d), failure %d of 3", why, code, g_failures); }
  if (g_failures >= 3) {
    InterlockedExchange(&g_ctl.flatView, 0);
    log_line("FLATVIEW switched OFF after three problems: the picture is shown stretched to the window as before");
    settings_changed();
  }
}
}  // namespace

int flatview_get_view(double* x, double* y, double* w, double* h) {
  if (!g_active || (g_ctl.stereoActive && !g_activeHeadset)) return 0;   // 1.3: while the headset shows the 2D screen the view is valid too (mouse and laser use it)
  if ((qpc_now() - g_activeQpc) * 1000 / qpc_freq() > 500) return 0;   // no Present for half a second: not current
  *x = g_last.x; *y = g_last.y; *w = g_last.w; *h = g_last.h;
  return 1;
}

void flatview_release() { release_all(); g_active = 0; }

int flatview_present(void* swapChain, int inHeadset) {
  IDXGISwapChain* sc = (IDXGISwapChain*)swapChain;
  g_active = 0; g_activeHeadset = 0;
  if (!g_ctl.flatView || (g_ctl.stereoActive && !inHeadset) || !sc || !g_ctl.gameHwnd) return 0;   // 1.2: inHeadset = a 2D screen (menu, video) is shown in the headset: the window still gets the picture in its own shape
  if (inHeadset && g_ctl.monitorMenuFill) {   // 1.7.28: the menu / video picture fills the PC window (Windows stretches the back buffer over it); no black bars, and the mouse maps the plain way
    static int s_logged;
    if (!s_logged) { s_logged = 1; log_line("FLATVIEW 1.7.28: monitor_menu_fill is on: the menu picture is stretched over the whole PC window (set monitor_menu_fill=0 for its own shape with black bars)"); }
    return 0;
  }
  RECT rc;
  if (!GetClientRect(g_ctl.gameHwnd, &rc) || rc.right < 64 || rc.bottom < 64) { InterlockedIncrement(&g_fs.skipped); return 0; }
  ID3D11Texture2D* bb = nullptr;
  if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb)) || !bb) { InterlockedIncrement(&g_fs.skipped); return 0; }
  D3D11_TEXTURE2D_DESC d;
  bb->GetDesc(&d);
  picture::View v;
  if (!picture::fit_view((int)d.Width, (int)d.Height, rc.right, rc.bottom, &v)) {
    InterlockedIncrement(&g_fs.notNeeded);
    bb->Release();
    return 0;
  }
  // multisampled back buffer, or one that cannot be a render target view of its own format: leave the picture alone
  if (d.SampleDesc.Count != 1 || d.Format == DXGI_FORMAT_UNKNOWN || !(d.BindFlags & D3D11_BIND_RENDER_TARGET)) {
    InterlockedIncrement(&g_fs.skipped);
    if (g_logged < 6) { ++g_logged; log_line("FLATVIEW not possible for this back buffer (samples=%u format=%d bind=%x): shown stretched", d.SampleDesc.Count, (int)d.Format, (unsigned)d.BindFlags); }
    bb->Release();
    return 0;
  }
  ID3D11Device* dev = nullptr;
  bb->GetDevice(&dev);
  if (!dev) { bb->Release(); return 0; }
  if (dev != g_dev) { release_all(); g_dev = dev; }   // another device (the game rebuilt it): start again
  int ok = 0;
  ID3D11DeviceContext* ctx = nullptr;
  ID3D11RenderTargetView* rtv = nullptr;
  if (g_state == 0) {
    g_state = create_resources(dev);
    if (g_state < 0) {
      int code = g_state;
      release_all();          // partly made objects go; the next frame tries again (three failures switch the feature off)
      g_dev = dev;
      fail("shaders / states could not be created", code);
    } else log_line("FLATVIEW ready: back buffer %u x %u format=%d, window %d x %d, picture shown %.0f x %.0f at %.0f,%.0f", d.Width, d.Height,
                  (int)d.Format, (int)rc.right, (int)rc.bottom, v.w, v.h, v.x, v.y);
  }
  if (g_state == 1) {
    dev->GetImmediateContext(&ctx);
    if (ctx && ensure_copy(dev, d) && SUCCEEDED(dev->CreateRenderTargetView(bb, nullptr, &rtv)) && rtv) {
      ctx->CopyResource(g_copy, bb);
      Saved sv;
      save(ctx, &sv);
      const float black[4] = {0, 0, 0, 1};
      ctx->OMSetRenderTargets(1, &rtv, nullptr);
      ctx->ClearRenderTargetView(rtv, black);
      D3D11_VIEWPORT vp;
      // client pixels -> back buffer pixels: Windows stretches the back buffer over the whole client area
      vp.TopLeftX = (float)(v.x * (double)d.Width / (double)rc.right);
      vp.TopLeftY = (float)(v.y * (double)d.Height / (double)rc.bottom);
      vp.Width = (float)(v.w * (double)d.Width / (double)rc.right);
      vp.Height = (float)(v.h * (double)d.Height / (double)rc.bottom);
      vp.MinDepth = 0; vp.MaxDepth = 1;
      ctx->RSSetViewports(1, &vp);
      ctx->RSSetState(g_rs);
      ctx->OMSetBlendState(g_bs, nullptr, 0xffffffffu);
      ctx->OMSetDepthStencilState(g_ds, 0);
      ctx->IASetInputLayout(nullptr);
      ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
      ctx->VSSetShader(g_vs, nullptr, 0);
      ctx->GSSetShader(nullptr, nullptr, 0);
      ctx->HSSetShader(nullptr, nullptr, 0);
      ctx->DSSetShader(nullptr, nullptr, 0);
      ctx->PSSetShader(g_ps, nullptr, 0);
      ctx->PSSetShaderResources(0, 1, &g_srv);
      ctx->PSSetSamplers(0, 1, &g_smp);
      ctx->Draw(3, 0);
      ID3D11ShaderResourceView* none = nullptr;
      ctx->PSSetShaderResources(0, 1, &none);   // the copy must not stay bound as an input
      restore(ctx, &sv);
      g_last.x = v.x; g_last.y = v.y; g_last.w = v.w; g_last.h = v.h; g_last.bw = d.Width; g_last.bh = d.Height;
      g_last.cw = rc.right; g_last.ch = rc.bottom;
      g_activeQpc = qpc_now();
      g_active = 1; g_activeHeadset = inHeadset ? 1 : 0;
      InterlockedIncrement(&g_fs.draws);
      g_failures = 0;
      ok = 1;
    } else {
      fail("copy texture or render target view could not be made", 0);
    }
  }
  if (rtv) rtv->Release();
  if (ctx) ctx->Release();
  dev->Release();
  bb->Release();
  return ok;
}

void flatview_report(LONG frame) {
  log_line("FLATVIEW frame=%d on=%d active=%d state=%d draws=%d notNeeded=%d skipped=%d failed=%d back=%ux%u window=%dx%d shown=%.0fx%.0f at %.0f,%.0f",
           (int)frame, (int)g_ctl.flatView, (int)g_active, g_state, (int)g_fs.draws, (int)g_fs.notNeeded, (int)g_fs.skipped, (int)g_fs.failed,
           g_last.bw, g_last.bh, g_last.cw, g_last.ch, g_last.w, g_last.h, g_last.x, g_last.y);
}

#endif
