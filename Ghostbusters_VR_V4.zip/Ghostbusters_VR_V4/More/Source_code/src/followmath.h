// 1.5 head-follow turning and snap turn (pure math, no Windows dependency; tested in tests/test_follow.cpp).
//
// Picture of the problem. The game's camera (its heading, "yaw") is turned by the right stick; the headset adds the real head rotation on top.
// The body, the walking direction and the game's own aim all follow the game's heading, not the head. To make the body follow the head:
//   1. e = the head's yaw measured from the game's heading (radians, + = turned right). It is what the headset tracks MINUS A (below).
//   2. When |e| gets bigger than startRad the right stick is pushed (by the probe, as if you did it) toward the head until |e| < stopRad.
//   3. The game's heading therefore changes by d on some frames. The picture must NOT turn twice (once by the game, once by the head), so every
//      such change is added to A (the yaw the game turned FOR you) and the headset rotation is turned back by A:  view = level(game yaw) * level(-A) * head.
//      Seen from the headset nothing moves; only the body, the walking direction and the game's aim are now where you look.
//   A snap turn is the same thing started by hand: A -= step (the picture jumps by one step at once), then the body catches up the same way.
// Which way a positive stick turns the game is not assumed: the first turns measure it (sign), and a turn that does not answer is given up (cool).
#pragma once
#include "vmath.h"

namespace follow {

static const double kPi = vm::kPi;
inline double wrap(double x) { while (x > kPi) x -= 2.0 * kPi; while (x < -kPi) x += 2.0 * kPi; return x; }
inline double rad(double deg) { return deg * kPi / 180.0; }
inline double deg(double r) { return r * 180.0 / kPi; }

struct Cfg {
  int enabled;        // the body follows the head (a snap turn works without it)
  double startRad;    // the head is this far from the body: the body starts to turn
  double stopRad;     // ... and stops when it is this close
  double maxStick;    // strongest push (0..1)
  double minStick;    // weakest push that still gets through the game's own stick dead zone
  double fullRad;     // beyond stopRad + fullRad the strongest push is used
  double tailSec;     // seconds after the last push in which a camera turn still counts as ours (the game's camera eases)
  double bigRad;      // one camera step bigger than this is a cut-scene / respawn, not our turn
  double calibRad;    // how far the camera has to move to know which way a positive push turns it
  double giveUpSec;   // no answer at all after this long: stop trying for a while
  double coolSec;     // ... this long
  // 1.7.5 polish
  int walkBoost;      // 1 = while the left stick is pushed (walking, sprinting) the body follows the head sooner and settles closer, so you go where you look
  double walkStartRad;// start angle while walking
  double walkStopRad; // stop angle while walking
  double upRate;      // how fast the push may grow (stick units per second): no sudden jerk when the turn starts
  double downRate;    // how fast it may shrink: the turn eases out instead of stopping dead
  // 1.7.6: the 1.7.5 report showed the game never answering the weak first pushes (47 snap turns, 0 degrees of real turning): never wait for a weak push to work
  double calibCap;    // strongest push while the stick's direction is not known yet (it used to be 0.55, which the game barely answers)
  double probeSec;    // after this long without the camera moving by probeRad, the next pushes use full strength
  double probeRad;
  double boostStick;  // the push used after a miss
  double dwellSec;    // 1.7.25: the head must stay past the start angle this long before the body starts to follow (a quick look back / sideways no longer drags the body)
};

inline Cfg make_cfg(int enabled, double startDeg, int walkBoost = 0) {
  Cfg c;
  c.enabled = enabled;
  c.startRad = rad(startDeg < 15.0 ? 15.0 : startDeg > 120.0 ? 120.0 : startDeg);
  c.stopRad = rad(7.0);
  if (c.stopRad > c.startRad * 0.6) c.stopRad = c.startRad * 0.6;
  c.maxStick = 1.0;
  c.minStick = 0.58;   // 1.7.6: the game's own look dead zone swallows weaker pushes (1.6 / 1.7.1 logs: 0.55 barely moves it, 0.7 turns about 25 degrees a second)
  c.fullRad = rad(55.0);
  c.tailSec = 0.6;
  c.bigRad = rad(45.0);
  c.calibRad = rad(1.0);
  c.giveUpSec = 1.3;
  c.coolSec = 5.0;
  c.walkBoost = walkBoost;
  // While actively walking, a 40-degree body lag makes forward feel diagonal.
  // The larger standing threshold still keeps brief glances from turning the body.
  c.walkStartRad = rad(10.0); if (c.walkStartRad > c.startRad) c.walkStartRad = c.startRad;
  c.walkStopRad = rad(5.0); if (c.walkStopRad > c.stopRad) c.walkStopRad = c.stopRad;
  c.upRate = 3.5;
  c.downRate = 7.0;
  c.calibCap = 0.85;
  c.probeSec = 0.4;
  c.probeRad = rad(0.4);
  c.boostStick = 1.0;
  c.dwellSec = 0.7;
  return c;
}

struct State {
  int active;          // pushing the stick now
  int forced;          // a snap asked for the body to catch up (works even with "follow" off)
  int sign;            // +1: a positive push raises the game's yaw (turns right), -1: the other way, 0: not known yet
  double calibSum, calibT;   // while the sign is unknown: how far the camera went with the push (+ = with it), for how long
  double respSum, respT;     // once known: the same, over the current run (a run that goes the wrong way flips the sign)
  double tail;         // seconds left in which camera turns still count as ours
  double dwell;        // 1.7.25: seconds the head has been past the start angle without the body following
  long dwellHolds;     // 1.7.25: steps where the body waited because of the dwell time
  double cool;         // seconds left of the pause after a push the game did not answer
  double lastU;        // the push sent last (stick axis, -1..1)
  double mSlew;        // 1.7.5: the push strength after the ramp (0..1)
  double learnedMin, stallSum, stallT;   // 1.7.6: the weakest push the game answered (starts at minStick, goes up when the camera stalls under a push)
  int boost;           // 1.7.6: the last tries did not move the game: push at full strength
  long noAnswerStreak; // 1.7.6: misses in a row (reset when the game turns again)
  long realigns, boosts, raises;
  long walkSteps, walkRuns;   // 1.7.5: steps / runs that used the walking limits
  // numbers for the log
  long steps, activeSteps, snaps, cuts, flips, noAnswer, runs, attributedSteps;
  long smooths;        // 1.7.81: frames of smooth turning (the mod's own, not the game's stick)
  double maxErr, attributed, maxPush;
};

inline void reset(State& s) { State z = {}; s = z; }

// One step per prepared frame. e = head yaw from the body (rad, + = right). allowed = the game is in a state where turning makes sense.
// userBusy = you push the right stick yourself (that always wins). Returns the push to add to the right stick axis (0 = none).
// moving = the left stick push (0..1): with walkBoost the start / stop angles shrink while you walk, so the body keeps pointing where you look.
inline double step(State& s, double e, double dt, const Cfg& c, int allowed, int userBusy, double moving = 0.0) {
  ++s.steps;
  if (!(dt > 0.0) || dt > 0.25) dt = 0.011;
  if (s.tail > 0.0) { s.tail -= dt; if (s.tail < 0.0) s.tail = 0.0; }
  if (s.cool > 0.0) { s.cool -= dt; if (s.cool < 0.0) s.cool = 0.0; }
  if (!(e == e)) { s.active = 0; s.lastU = 0.0; return 0.0; }
  const double a = e < 0 ? -e : e;
  if (a > s.maxErr) s.maxErr = a;
  if (userBusy) { s.active = 0; s.forced = 0; s.tail = 0.0; s.lastU = 0.0; return 0.0; }
  if (!allowed) { s.active = 0; s.forced = 0; s.lastU = 0.0; return 0.0; }
  double mv = (moving - 0.25) / 0.5; if (mv < 0.0) mv = 0.0; if (mv > 1.0) mv = 1.0;
  if (!c.walkBoost) mv = 0.0;
  const double startR = c.startRad + (c.walkStartRad - c.startRad) * mv;
  const double stopR = c.stopRad + (c.walkStopRad - c.stopRad) * mv;
  const int past = c.enabled && a > startR;
  if (past && !s.active) s.dwell += dt; else if (!past) s.dwell = 0.0;
  const double dwellNeed = c.dwellSec * (1.0 - mv);   // walking: no wait (go where you look)
  const int dwellOk = s.dwell >= dwellNeed;
  if (past && !dwellOk && !s.forced && !s.active) ++s.dwellHolds;
  const int want = (past && dwellOk) || (s.forced && a > stopR);
  if (!s.active) {
    if (want && s.cool <= 0.0) {
      s.active = 1; ++s.runs; s.mSlew = 0.0; if (mv > 0.5) ++s.walkRuns;
      s.respSum = 0.0; s.respT = 0.0;
      if (s.sign == 0) { s.calibSum = 0.0; s.calibT = 0.0; }
    }
  } else if (a < stopR || (!s.forced && !c.enabled)) {
    s.active = 0; s.forced = 0;
  }
  if (!s.active) { s.lastU = 0.0; return 0.0; }
  double t = (a - stopR) / c.fullRad; if (t < 0.0) t = 0.0; if (t > 1.0) t = 1.0;
  t = t * t * (3.0 - 2.0 * t);   // 1.7.5: smooth curve (gentle near the target, firm when far)
  double m = c.minStick + t * (c.maxStick - c.minStick);
  if (m < c.minStick) m = c.minStick;
  if (m > c.maxStick) m = c.maxStick;
  const double learned = s.learnedMin > c.minStick ? s.learnedMin : c.minStick;
  if (s.boost && m < c.boostStick) m = c.boostStick;                // 1.7.6: after a miss the next push is strong
  else if (s.sign == 0 && m > (c.calibCap > learned ? c.calibCap : learned)) m = (c.calibCap > learned ? c.calibCap : learned);   // before the direction is known: strong, but not the full stick
  if (m < learned) m = learned;
  const double floorM = s.boost ? c.boostStick : learned;
  if (s.mSlew < floorM) s.mSlew = floorM;   // a turn begins at the weakest push that works, then ramps
  if (m > s.mSlew) { s.mSlew += c.upRate * dt; if (s.mSlew > m) s.mSlew = m; }
  else { s.mSlew -= c.downRate * dt; if (s.mSlew < m) s.mSlew = m; }
  m = s.mSlew;
  if (mv > 0.5) ++s.walkSteps;
  const double dir = e > 0.0 ? 1.0 : -1.0;
  s.tail = c.tailSec;
  const double u = dir * m * (s.sign ? (double)s.sign : 1.0);
  s.lastU = u;
  ++s.activeSteps;
  if (m > s.maxPush) s.maxPush = m;
  return u;
}

// The game's heading changed by d (rad) since the previous prepared frame. Returns how much of it was OUR turn: the caller adds that to A.
inline double on_camera_delta(State& s, double d, double dt, const Cfg& c) {
  d = wrap(d);
  if (!(dt > 0.0) || dt > 0.25) dt = 0.011;
  const int ours = s.active || s.tail > 0.0;
  if (!ours) return 0.0;
  if ((d < 0 ? -d : d) > c.bigRad) { ++s.cuts; return 0.0; }
  if (s.active && s.lastU != 0.0) {
    const double along = d * (s.lastU > 0.0 ? 1.0 : -1.0);   // + = the camera went the way the push was sent
    if (s.sign == 0) {
      s.calibSum += along; s.calibT += dt;
      const double cs = s.calibSum < 0 ? -s.calibSum : s.calibSum;
      if (cs > c.calibRad) { s.sign = s.calibSum > 0 ? 1 : -1; if (s.sign < 0) ++s.flips; s.noAnswerStreak = 0; s.boost = 0; }
      else if (s.calibT > c.giveUpSec) { ++s.noAnswer; ++s.noAnswerStreak; s.boost = 1; ++s.boosts; s.active = 0; s.forced = 0; s.cool = c.coolSec; s.lastU = 0.0; s.calibSum = 0.0; s.calibT = 0.0; }
      else if (s.calibT > c.probeSec && cs < c.probeRad && !s.boost) { s.boost = 1; ++s.boosts; }   // nothing moved yet: full strength from now on
    } else {
      // the push went out already multiplied by sign, so "along" is relative to the real push: expected + when the sign is right
      s.respSum += along * (double)s.sign; s.respT += dt;
      if (s.respSum < -c.calibRad * 2.0) { s.sign = -s.sign; ++s.flips; s.respSum = 0.0; s.respT = 0.0; }
      else if (s.respT > c.giveUpSec * 2.0 && s.respSum < c.calibRad) { ++s.noAnswer; ++s.noAnswerStreak; s.boost = 1; ++s.boosts; s.active = 0; s.forced = 0; s.cool = c.coolSec; s.lastU = 0.0; s.respSum = 0.0; s.respT = 0.0; }
      else if (s.respT > c.probeSec && s.respSum < c.probeRad && !s.boost) { s.boost = 1; ++s.boosts; }
      else if (s.respSum > c.calibRad * 2.0) { s.noAnswerStreak = 0; if (s.respSum > c.calibRad * 4.0) { s.boost = 0; s.respSum = c.calibRad * 4.0; } }
    }
  }
  if (s.active && s.lastU != 0.0) {   // 1.7.6: a push the game does not turn under is too weak: raise the weakest push that is used (the game's look dead zone)
    s.stallSum += d < 0 ? -d : d; s.stallT += dt;
    if (s.stallT >= 0.5) {
      if (s.stallSum < rad(0.5)) { const double cur = s.learnedMin > c.minStick ? s.learnedMin : c.minStick; s.learnedMin = cur + 0.1 > c.maxStick ? c.maxStick : cur + 0.1; ++s.raises; }
      s.stallSum = 0.0; s.stallT = 0.0;
    }
  }
  s.attributed += d; ++s.attributedSteps;
  return d;
}

// The game turned (by your own stick or by a push that worked): it answers, so the misses in a row start from zero.
inline void note_answer(State& s) { s.noAnswerStreak = 0; }
// Two misses in a row: the game does not answer the pushes right now (a cut-scene, a locked camera, another input mode). The probe then stops faking turns:
// the picture goes back to the body and the real right stick turns the game itself.
inline int gave_up(const State& s) { return s.noAnswerStreak >= 2; }

// 1.7.8: WALK WHERE THE HEAD POINTS, whatever the game's camera does. The 1.7.5 and 1.7.7 reports showed the game's heading frozen for the whole session (the right stick, pushed by
// the probe or by you, turned nothing), so "the body follows the head" never happened and the left stick walked relative to a heading you were not looking along. The game walks the
// character relative to its own heading; the head is e (rad, + = right) away from it. Turning the left stick by e makes the game walk exactly along the head, whatever the heading is:
// stick forward -> (sin e, cos e), stick right -> (cos e, -sin e). The length never changes (a full push stays a full push, inside the unit circle).
inline void rotate_stick(double lx, double ly, double e, double* ox, double* oy) {
  double s, c; vm::dsincos(e, &s, &c);
  *ox = lx * c + ly * s;
  *oy = -lx * s + ly * c;
}

// A snap turn of stepDeg (+ = right). Returns the change for A (the picture turns by the step at once); the body then catches up on its own.
inline double snap(State& s, double stepDeg) {
  s.forced = 1; ++s.snaps;
  return -rad(stepDeg);
}

// 1.7.81 SMOOTH TURN. How many degrees to turn this frame (+ = right) while the right stick is held sideways. The mod turns the picture itself (the same way a snap does), so it works
// where the game's own stick turn does not answer. Dead zone 20 %, then a straight ramp to full speed; a push that is mostly up / down is not a turn; dps is limited to 30..360 deg/s;
// a long frame (a hitch) counts as 50 ms at most so the view never swings; a bad number turns nothing.
inline double smooth_deg(double x, double y, double dps, double dt) {
  if (!(x == x) || !(y == y) || !(dt > 0.0)) return 0.0;
  const double ax = x < 0 ? -x : x, ay = y < 0 ? -y : y;
  if (ax <= 0.20 || ax <= ay * 1.3) return 0.0;
  if (dt > 0.05) dt = 0.05;
  if (!(dps >= 30.0)) dps = 30.0;
  if (dps > 360.0) dps = 360.0;
  double f = (ax - 0.20) / 0.80; if (f > 1.0) f = 1.0;
  const double d = dps * f * dt;
  return x < 0 ? -d : d;
}
// One smooth step of deg (+ = right): the change for A, like snap() (the body catches up on its own), counted on its own.
inline double smooth(State& s, double deg) {
  s.forced = 1; ++s.smooths;
  return -rad(deg);
}

// Right stick flick detector for the snap turn: one step per flick, the stick has to come back to the middle before the next one.
struct Flick { int armed; long fired; };
inline int flick(Flick& f, double x, double y) {
  const double ax = x < 0 ? -x : x, ay = y < 0 ? -y : y;
  if (ax < 0.35 && ay < 0.5) { f.armed = 1; return 0; }
  if (f.armed && ax > 0.7 && ay < 0.65 && ax > ay * 1.3) { f.armed = 0; ++f.fired; return x > 0 ? 1 : -1; }
  return 0;
}

}  // namespace follow
