// 0.69 "the game moves the character, not the player": cutscenes walk the player's character about, ghosts knock it back, a level load
// puts it somewhere else. The avatar's animation then moves a lot against the camera (which hangs on the actor's position), and the
// body corrections that line the avatar's eyes up with the headset used to chase that motion: the body swung around. This watches the
// actor's position and the move stick: if the actor moves while the player is not pushing the stick it is a FORCED move, and the
// body corrections fade out quickly, then fade back in slowly once the actor stands (or the player takes over again).
// Pure math (game feet, seconds); unit-tested in tests/test_forced.cpp.
#pragma once

namespace forced {

struct Detector {
  int have;
  double last[3];
  double idleSec;       // how long the move stick has been (nearly) untouched
  double movingSec;     // how long the actor has been moving while the stick was untouched
  double stillSec;      // how long the actor has been (nearly) still
  double holdSec;       // after a forced move: stay "forced" this much longer
  double fade;          // 1 = the body corrections work fully, 0 = switched off
  int forced;           // the current state
  int events;           // how many times a forced move started
  int teleports;        // ... of which jumps
  double lastStep;      // 1.7.154: how far the actor moved in the last update, ft
  int jumpsAll;         // 1.7.151: every jump, also one that comes while the last is still being handled (teleports counts a run of them once)
  double speed;         // last horizontal speed of the actor, ft/s
  double forcedTotal;   // seconds spent forced
  double maxSpeed;      // fastest forced move seen, ft/s

  void reset() {
    have = 0; idleSec = movingSec = stillSec = holdSec = 0; fade = 1.0; forced = 0; events = teleports = jumpsAll = 0; lastStep = 0; speed = 0; forcedTotal = 0; maxSpeed = 0;
    last[0] = last[1] = last[2] = 0;
  }

  // pos: the actor's feet (game feet). stick: the move stick, 0..1 (pass 1.0 when it is not known: nothing is then ever called forced).
  // dt: seconds since the last call (the second eye of a pair comes with a tiny dt and is ignored). Returns the fade (0..1).
  double update(const double* pos, double stick, double dt) {
    if (!(dt > 0.0)) return fade;
    if (!have) { have = 1; for (int i = 0; i < 3; ++i) last[i] = pos[i]; return fade; }
    if (dt < 0.003) return fade;   // same game frame (second eye): no new information
    if (dt > 0.5) dt = 0.5;
    const double dx = pos[0] - last[0], dz = pos[2] - last[2];
    for (int i = 0; i < 3; ++i) last[i] = pos[i];
    double d2 = dx * dx + dz * dz, d = 0;
    if (d2 > 0) { d = d2; for (int i = 0; i < 20; ++i) d = 0.5 * (d + d2 / d); }   // sqrt without libm (Newton)
    speed = d / dt; lastStep = d;
    const double kStickIdle = 0.15, kMoveFtS = 1.5, kStillFtS = 0.5, kTeleportFt = 5.0, kIdleNeeded = 0.30, kMoveNeeded = 0.10, kStillNeeded = 0.25, kHold = 0.5;

    if (stick < kStickIdle) idleSec += dt; else idleSec = 0;
    if (speed < kStillFtS) stillSec += dt; else stillSec = 0;

    // 1.7.156: 5 ft in ONE normal frame is a jump (hundreds of ft/s). 5 ft covered during a long hitch while running or sprinting (25 ft/s x 0.25 s) is not:
    // it used to count, and a jump hands the gun and body to the game for two seconds.
    if (d > kTeleportFt && (speed > 60.0 || d > 15.0)) {   // the actor jumped (level load, cutscene cut, respawn): not a walk
      ++jumpsAll;
      if (!forced) { ++events; ++teleports; }
      forced = 1; holdSec = 1.0; movingSec = 0; stillSec = 0;
    } else if (idleSec >= kIdleNeeded && speed >= kMoveFtS) {
      movingSec += dt;
      if (movingSec >= kMoveNeeded && !forced) { forced = 1; ++events; }
    } else {
      if (!(speed >= kMoveFtS)) movingSec = 0;
    }
    if (forced) {
      forcedTotal += dt;
      if (speed > maxSpeed) maxSpeed = speed;
      holdSec = holdSec > kHold ? holdSec : kHold;
      // over: the actor stands still, or the player pushes the stick (he has the controls again)
      if (stillSec >= kStillNeeded || stick >= 0.3) { if (!(d > kTeleportFt)) { forced = 0; movingSec = 0; } }
    } else if (holdSec > 0) holdSec -= dt;
    const int off = forced || holdSec > 0;
    if (off) { fade -= dt / 0.12; if (fade < 0) fade = 0; }
    else { fade += dt / 0.9; if (fade > 1) fade = 1; }
    return fade;
  }
};

}  // namespace forced
