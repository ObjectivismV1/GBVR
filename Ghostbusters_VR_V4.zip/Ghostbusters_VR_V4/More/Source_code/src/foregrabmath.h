// 1.7.105 FORE GRAB. Pure math, no Windows dependency; unit-tested in tests/test_foregrab.cpp.
//
// The left hand used to be pulled softly toward the barrel and slid along it wherever the real hand went. It is now a GRAB: squeeze the left grip with the hand near the barrel and the
// hand is put on the gun at the spot where you grabbed it, and it STAYS there on the gun (the gun's own axes), whatever the real hand does within a small dead zone. Move the real hand
// along the barrel by more than the dead zone and the grip point slides with it (a hold that follows, but does not shake). Take the real hand far from the gun and the grab lets go.
// Everything is measured against the CURRENT gun (its place, its length, its axes) every pass, so it follows the gun as the model changes; a new weapon or a clearly different length
// drops the grab (the caller resets the state) and the next squeeze is a new grab.
#pragma once
#include "armmath.h"

namespace foregrab {

struct State { int have; int on; double along; };   // along = the grip point's distance from the gun's origin along the barrel (feet)

struct Params {
  double loFrac, hiFrac;     // the grip point stays between these fractions of the gun's length (0.25 .. 0.95)
  double deadFt;             // the real hand may move this far along the barrel before the grip point follows
  double grabFt, releaseFt;  // distance (hand to grip point) to take hold / to let go
};
inline Params defaults() { Params p; p.loFrac = 0.25; p.hiFrac = 0.95; p.deadFt = 0.15; p.grabFt = 1.00; p.releaseFt = 1.60; return p; }

struct Out { int on; double along, alongReal, dist; };

inline double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

// held: the left grip is squeezed with a gun really drawn. lpos: the left controller (hand), base: the gun's origin, dir / up: the gun's barrel direction and up (unit), L: the gun's length (feet),
// underFt: how far under the barrel line the hand sits.
inline Out step(State* s, int held, const double* lpos, const double* base, const double* dir, const double* up, double L, double underFt, const Params& p) {
  Out o; o.on = 0; o.along = 0.0; o.alongReal = 0.0; o.dist = 0.0;
  if (!held || !(L > 0.2)) { s->have = 0; s->on = 0; return o; }
  const double rel[3] = {lpos[0] - base[0], lpos[1] - base[1], lpos[2] - base[2]};
  const double real = arm::dot(rel, dir);
  const double lo = p.loFrac * L, hi = p.hiFrac * L;
  const double ac = clampd(real, lo, hi);
  o.alongReal = real;
  if (!s->have) { s->along = ac; s->have = 1; s->on = 0; }
  if (s->on) {
    // the dead zone: the grip point stays while the real hand is within deadFt of it, and is pushed along when the hand goes beyond
    const double d = ac - s->along;
    if (d > p.deadFt) s->along = ac - p.deadFt; else if (d < -p.deadFt) s->along = ac + p.deadFt;
    s->along = clampd(s->along, lo, hi);
  } else s->along = ac;   // not holding yet: the grip point is where the hand is, so taking hold does not jump
  double gp[3], dx[3];
  for (int i = 0; i < 3; ++i) { gp[i] = base[i] + dir[i] * s->along - up[i] * underFt; dx[i] = gp[i] - lpos[i]; }
  const double dist = arm::len(dx);
  if (!s->on && dist < p.grabFt) s->on = 1;
  else if (s->on && dist > p.releaseFt) s->on = 0;
  o.on = s->on; o.along = s->along; o.dist = dist;
  return o;
}

// 1.7.116 FORE NEAR (fore_near_cm): a FREE left hand (no grip squeeze) that comes near the barrel takes hold of it by itself and lets go when it leaves. The place of the hand is measured against the
// gun: along = how far along the barrel from the gun's origin, perp = its distance from the barrel line. All lengths in game feet (the world's size turns real cm into them: cm_to_ft).
// The decision has hysteresis so a hand at the edge does not flicker on and off: to take hold the hand must be inside the reach and between 0.15 L and 1.05 L along the barrel; once holding,
// it keeps hold out to 1.4 x the reach and 0.08 L .. 1.15 L.
inline int in_zone(double alongFt, double L, int prevOn) {
  const double lo = prevOn ? 0.08 : 0.15, hi = prevOn ? 1.15 : 1.05;
  return alongFt > lo * L && alongFt < hi * L;
}
inline int near_step(int prevOn, double alongFt, double perpFt, double L, double nearFt) {
  if (!(L > 0.2) || !(nearFt > 0.0)) return 0;
  return (in_zone(alongFt, L, prevOn) && perpFt < (prevOn ? 1.4 * nearFt : nearFt)) ? 1 : 0;
}
inline double cm_to_ft(double cm, double fpm) { return cm * 0.01 * fpm; }                       // fpm = game feet per real metre (3.28 at the standard world size)
inline double ft_to_cm(double ft, double fpm) { return fpm > 0.01 ? ft / fpm * 100.0 : 0.0; }
inline void hand_vs_barrel(const double* hand, const double* gunPos, const double* dir, double* along, double* perp) {
  const double rel[3] = {hand[0] - gunPos[0], hand[1] - gunPos[1], hand[2] - gunPos[2]};
  const double al = arm::dot(rel, dir);
  const double pv[3] = {rel[0] - al * dir[0], rel[1] - al * dir[1], rel[2] - al * dir[2]};
  *along = al; *perp = arm::len(pv);
}
// the log's picture of where a free hand hangs: 8 distance buckets from the barrel line (cm): <6, <10, <14, <18, <22, <28, <40, 40+
inline int near_bucket(double cm) {
  static const double kEdge[7] = {6.0, 10.0, 14.0, 18.0, 22.0, 28.0, 40.0};
  int i = 0; while (i < 7 && cm >= kEdge[i]) ++i;
  return i;
}

}  // namespace foregrab
