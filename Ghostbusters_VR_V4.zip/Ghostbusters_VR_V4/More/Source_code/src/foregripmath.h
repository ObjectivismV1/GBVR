// 1.7.104 STEADY FOREGRIP. Pure math, no Windows dependency; unit-tested in tests/test_foregrip.cpp.
//
// The gun's own place (where the game drew it) is known from the last gun placement; the left hand comes from the newest controller sample. While you walk or sprint the world moves several
// centimetres between the two, so the left hand's distance along the barrel jittered by that much (the 1.7.103 report: "off-hand shakes a lot when walking / sprinting").
// The gun sits on the right controller at a fixed offset (forward / up / side in the controller's own axes). That offset is learned from the placements (a slow average) and the gun's place
// is rebuilt from the controller of THE SAME sample as the left hand: gun = grip + offset in the controller's axes. Both then come from the same moment.
#pragma once
#include "armmath.h"

namespace foregrip {

struct Offsets { double o[3]; int have; };

// orthonormal controller axes: D forward, U up (made square to D), S = D x U
inline int frame(const double* dir, const double* up, double* D, double* U, double* S) {
  if (!arm::unit(dir, D) || !arm::unit(up, U)) return 0;
  const double k = arm::dot(U, D);
  for (int i = 0; i < 3; ++i) U[i] -= k * D[i];
  if (!arm::unit(U, U)) return 0;
  arm::cross(D, U, S);
  return 1;
}

// one placement: the controller (grip, dir, up) and where the gun was put (gun). alpha = how much of the new offset is taken (0..1); the first one is taken whole.
inline int learn(Offsets* s, const double* grip, const double* dir, const double* up, const double* gun, double alpha) {
  double D[3], U[3], S[3];
  if (!frame(dir, up, D, U, S)) return 0;
  const double v[3] = {gun[0] - grip[0], gun[1] - grip[1], gun[2] - grip[2]};
  const double c[3] = {arm::dot(v, D), arm::dot(v, U), arm::dot(v, S)};
  const double dv[3] = {c[0] - s->o[0], c[1] - s->o[1], c[2] - s->o[2]};
  if (!s->have || arm::len(dv) > 0.35) { for (int i = 0; i < 3; ++i) s->o[i] = c[i]; s->have = 1; }   // the first one, or another weapon (a jump of more than about 10 cm): taken whole
  else for (int i = 0; i < 3; ++i) s->o[i] += dv[i] * alpha;
  return 1;
}

// the gun's place for a controller sample
inline int place(const Offsets* s, const double* grip, const double* dir, const double* up, double* gun) {
  if (!s->have) return 0;
  double D[3], U[3], S[3];
  if (!frame(dir, up, D, U, S)) return 0;
  for (int i = 0; i < 3; ++i) gun[i] = grip[i] + s->o[0] * D[i] + s->o[1] * U[i] + s->o[2] * S[i];
  return 1;
}

}  // namespace foregrip
