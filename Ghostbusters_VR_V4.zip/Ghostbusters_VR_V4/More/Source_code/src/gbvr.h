// Ghostbusters VR probe - shared declarations.
#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <stdint.h>
#include <stdarg.h>
#include <intrin.h>

#include "version.h"
void crumb(const char* tag, int arg);   // 0.86 black box (declared early: armcore.h's steps are crumbs in every file; 1.7.14: until now only arms.cpp tried to turn them on, after gbvr.h had already included armcore.h with no-op crumbs)
#define ARMCORE_CRUMB(tag, arg) crumb(tag, (int)(arg))
#include "armcore.h"

#if defined(_MSC_VER) && !defined(__clang__)
#define GBVR_RETURN_ADDRESS() _ReturnAddress()
#define GBVR_NOINLINE __declspec(noinline)
#else
#define GBVR_RETURN_ADDRESS() __builtin_return_address(0)
#define GBVR_NOINLINE __attribute__((noinline))
#endif

// ---------------------------------------------------------------------------
// Module / process facts (filled once by gbvr_init).
struct GameModule {
  uintptr_t base;          // ghost.exe load address
  uint32_t  sizeOfImage;
  uint32_t  timeDateStamp;
  int       identityOK;    // timestamp + size match layout.h, OR (1.7.187) every code sample of sigtable.h is byte-identical (another store's build of the same code, e.g. Epic)
  int       altBuild;      // 1.7.187: identityOK came from the code samples, not from the PE header (the Epic Games Store build?)
  int       sampleMiss;    // 1.7.187: code samples that did not match (-1 = not checked)
  int       hookBytesOK;   // every hook site holds the expected bytes
};
extern GameModule g_game;
extern HMODULE g_selfModule;
extern wchar_t g_selfDir[MAX_PATH];  // folder of this DLL (= game folder)

inline uintptr_t rva(uint32_t r) { return g_game.base + r; }

// ---------------------------------------------------------------------------
// Log (log.cpp). One file per session in the game folder.
void log_open();
void log_line(const char* fmt, ...);
int  log_fmt(char* buf, int size, const char* fmt, ...);  // snprintf; returns chars written (<size)
void log_flush();
void log_flush_quiet();        // 0.44: flush through a second handle, so the thread writing the log is not held up (heartbeat thread)
const wchar_t* log_dir();      // folder the log file is in (game folder, or the Documents fallback)
double qpc_ms();               // milliseconds since log_open
int64_t qpc_now();
int64_t qpc_freq();

// 0.56 profile: where does the time of a frame go? Slots are filled with prof_add() (microseconds) and written by prof_report().
enum { PF_TICK, PF_SIM, PF_PRESENT, PF_CTRL, PF_MENU, PF_BODYPUSH, PF_HUD, PF_STEREOARM, PF_SUBMIT, PF_WAITPOSES, PF_ARMS, PF_COUNT };
void prof_add(int slot, int64_t t0Qpc);   // adds (now - t0) to the slot
void prof_report(LONG frame);

// ---------------------------------------------------------------------------
// Control state shared between the render thread (keys, focus, pose) and the
// camera thread (engine hooks). All access through Interlocked operations.
enum ControlMode : LONG { MODE_OFF = 0, MODE_MANUAL = 1, MODE_HEAD = 2 };

struct Control {
  volatile LONG mode;          // ControlMode
  volatile LONG manualCentiDeg;// +1000 = +10.00 degrees (F7), -1000 = F8
  volatile LONG captureDone;   // 1 after the capture window closes
  volatile LONG worldFrames;   // Presents that followed a verified prepare
  volatile LONG prepareSeen;   // set by camera thread each verified prepare
  volatile LONG pauseFlag;     // last pause-menu flag value seen
  volatile LONG captureStarted;// 1 after first F5/F7/F8/F9
  volatile LONG firstPerson;   // 0.19: F5 first-person eye test
  volatile LONG eyeHeightCenti;  // eye height above the followed actor, 1/100 game units (feet)
  volatile LONG eyeForwardCenti; // forward nudge along the camera heading
  volatile LONG nearCenti;       // 0.20: first-person near plane, 1/100 ft
  // ---- 0.21 stereo (F4) ----
  volatile LONG stereoWanted;    // F4: draw the game in 3D in the headset
  volatile LONG stereoActive;    // set by the render thread once the scene session and eye data are ready
  volatile LONG stereoNextEye;   // eye the next game frame is rendered for (owned by the render thread)
  volatile LONG swapEyes;        // Shift+F4: diagnostic, exchanges the two eye positions
  volatile LONG stereoStrengthPct; // Ctrl+F4 / Ctrl+Shift+F4: eye separation, percent of the real one (0..200)
  volatile LONG headMove;        // F3: head position (leaning) moves the eye
  volatile LONG recenterRequest; // F9: re-zero head yaw/position at the next valid pose
  // ---- 0.24 ----
  volatile LONG stereoPair;      // F8 (headset view): render both eyes back to back for every headset frame
  volatile LONG stereoPairPhase; // 0 = next frame starts a pair, 1 = next frame completes it (render thread)
  volatile LONG stereoWide;      // F7 (headset view): separate horizontal / vertical field of view (sharper)
  // ---- 0.25 ----
  volatile LONG sizePct;         // PgUp / PgDn (headset view): player height in percent (scales the eye height;
                                 // 0.25 also scaled eye separation and head movement with it - from 0.26 that is worldPct)
  // ---- 0.26 ----
  volatile LONG worldPct;        // Home / End (headset view): apparent size of the world in percent. Eye separation
                                 // and head movement are divided by it (smaller separation = bigger world).
  volatile LONG pictureLines;    // 1.7.117: 0 = the picture follows pictureLevel; 720..2880 = the game draws this many lines (monitor shape), set by the VR menu Resolution row
  volatile LONG pictureLevel;    // Insert: 1 = monitor resolution, 2..4 = the game draws a bigger picture (modes.cpp).
                                 // Used when the game lists its display modes, i.e. at the next start.
  // ---- 0.27 ----
  volatile LONG hudMode;         // 0.29 Ctrl+F1: 1 = the game's 2D overlay placed in front of the player for both eyes, 0 = as the game draws it
  volatile LONG hudSizePct;      // 0.29: overlay width, 100 = 60 degrees
  volatile LONG hudDistanceCm;   // 0.29: overlay distance (stereo depth), 250 = 2.5 m
  volatile LONG hideBody;        // F1: 0 = own body shown, 1 = hidden in first person (0.28/0.29 also had 2 = wand
                                 // too; from 0.30 the wand has its own switch and a saved 2 is read as 1)
  volatile LONG hideWand;        // 0.30 Shift+F1: 1 = the proton wand is hidden with the body (default), 0 = wand shown
  volatile LONG hideShadow;      // 0.30 settings file: 1 = the hidden body casts no shadow either (default)
  volatile LONG headAim;         // Shift+F2 aim source: 0 = the mouse, 1 = the head (0.32), 2 = the right hand / both hands (0.33, default;
                                 // falls back to the head while no controller is tracked)
  volatile LONG padEnabled;      // 0.33 Ctrl+F2: the Quest controllers act as the game's Xbox pad (default 1)
  volatile LONG twoHandFire;     // 0.33 settings: 1 = the triggers only fire while both grips are held (default 0)
  volatile LONG handPitchDeci;   // 0.33 Shift+Home / Shift+End: tilt of the pointing direction, 1/10 degree (default 0)
  volatile LONG stickDeadzonePct;// 0.33 settings: thumbstick dead zone (default 18)
  volatile LONG menuFlip;        // 0.42: 1 = the menu pointer's vertical direction is reversed (Ctrl+F12)
  volatile LONG menuFast;        // 0.43: 1 = menus / pause screen are not held to the game's 30 FPS cap in the headset
  volatile LONG autoQuality;     // 0.44: 1 = the tool may lower the picture level by itself when the PC cannot keep up / a start fails
  volatile LONG handPredictMs;   // 0.50: controller poses predicted this many ms ahead (less lag between hand, wand and stream)
  volatile LONG probeData;       // 0.49: 1 = snapshots of the player actor and its objects in the log (ACTORSNAP / ACTORDIFF / OBJDIFF / ACTORGRAPH)
  volatile LONG diagTiming;      // 0.44: 1 = ask the SteamVR compositor for its frame timings in the log (COMPOSITOR line)
  volatile LONG ventGesture;     // 0.45: 1 = squeezing a grip with a hand behind the shoulder (on the pack) vents the pack (default on)
  volatile LONG flatView;        // 0.45: 1 = in flat (non-headset) mode the 4:3 picture is shown in its right shape (black bars) instead of stretched
  volatile LONG flatVsyncOff;    // 0.45: 1 = flat mode does not wait for the monitor's refresh (no fixed 60 / 72 FPS ceiling)
  volatile LONG holster;         // 0.38: 1 = squeeze the right grip with the right hand at the hip to holster / draw the wand (default off)
  volatile LONG bodyFollow;      // 0.52: the game's body, pack and hose stand under the real head and turn after it (needs realModels)
  volatile LONG bodyScale;       // 0.52: the body is scaled to the camera's eye height
  volatile LONG bodyEyeCenti;    // 0.52: the body model's own eye height, 1/100 ft (550)
  volatile LONG torsoDeadDeg;    // 0.52: the torso turns only when the head looks further than this to the side
  volatile LONG torsoLagMs;      // 0.52: how slowly the torso follows
  volatile LONG calibrateRequest; // 0.52: 1 = measure the real height now (Ctrl+F9)
  volatile LONG menuFreeze;      // 0.54: the game world stands still while the in-VR menu is open
  volatile LONG ringMode;        // 0.54: the ghost's health ring: 0 as the game draws it, 1 hidden
  volatile LONG armIk;           // 0.57: the game's arms follow the real hands: 0 off, 1 both arms, 2 right (gun) arm only
  volatile LONG armWristCm;      // 0.57: how far behind the controller the wrist of a free hand is (cm)
  volatile LONG armElbowDown;    // 0.57: how strongly the elbow hangs down (percent)
  volatile LONG menuOnStart;     // 0.53: the in-VR menu opens by itself when the headset view starts
  volatile LONG fullBody;        // 0.61: head, spine, crouch and leg layer of the game's body (1 = on)
  volatile LONG bodyEyeAlign;    // 0.68: 1 = the avatar's eyes are lined up with the camera's eye (body base shift + head slide)
  volatile LONG eyeBackCm;       // 0.68: the camera sits this far in front of the avatar's eyes (cm), so the face is not in the picture
  volatile LONG eyeShiftCapCm;   // 0.69: the whole body may shift this far (cm, legs stay planted) to put the avatar's eyes exactly at the camera
  volatile LONG armsOnly;        // 0.71: 1 = only the avatar's arms are drawn (head, chest and legs squashed away)
  volatile LONG pkeBody;         // 0.81: 1 = while the PKE meter is in hand the body is shown and the game holds the PKE in both hands
  volatile LONG solidBody;       // 0.81: 1 = the gun and hands are pushed out of the avatar's torso
  volatile LONG aimLive;         // 1.7.21: 1 = every read of the player's aim (not only the game's writes) returns the live hand aim
  volatile LONG damageWatch;     // 1.7.21: 1 = hook the enemies' hurt function even at 100 % damage (passthrough, only for the hit log and the slam buzz); 0 = the game's damage code is not touched
  volatile LONG leftThumbAnim;  // 1.7.23: the left thumb keeps the game's own pose (like the gun hand's thumb); 0 = the old curl
  volatile LONG blinkDash;      // 1.7.22: double-tap the left stick = a short burst of speed (0 = off, the default)
  volatile LONG vignettePct;   // 1.7.22: comfort vignette strength (0 = off, the default)
  volatile LONG bodyBendPct, bodyBendMaxDeg;   // 1.7.21: the body bends forward when you look down (percent of the head pitch past 10 deg, limit in degrees)
  volatile LONG controllerLayout, stickAxisForce;   // 1.7.117: settings-file only (no menu row): 0 = detect the controller, 1 Touch, 2 Index, 3 Vive wand, 4 Windows MR, 5 other; stick axis -1 = detect, 0..4 = force
  volatile LONG leftHanded;      // 1.7.19: 1 = left-handed play: the physical left controller is the gun hand (every system mirrors at the controller layer)
  volatile LONG seated;          // 1.7.19: 1 = seated play: no crouch from a head drop; switching it on recenters you where you sit (after the menu closes)
  volatile LONG seatCm;          // 1.7.19: seated: raise (+) or lower (-) the eye relative to where you recentered, cm
  volatile LONG profileSlot;     // 1.7.19: 1..3 = which person's settings are in use (each has its own file); switching saves the old one and loads the new one
  volatile LONG seatRecenterAt;  // 1.7.19: GetTickCount() when the pending seated recenter fires (0 = none)
  volatile LONG leftUnder;       // 1.7.19: 1 = with the left grip squeezed the left hand holds the gun from UNDER the barrel and slides along it
  volatile LONG leftUnderCm;     // 1.7.19: how far under the barrel the hand sits (cm)
  volatile LONG leftGripPct;     // 0.81: how strongly the left hand is drawn onto the gun's foregrip (0 off, 100 full)
  volatile LONG realAnchor;      // 0.84: the hose starts at the game's real pack (from the skeleton snapshot)
  volatile LONG fingers;         // 0.84: the game's own glove fingers curl with the trigger / grip
  volatile LONG pkeBones;        // 0.85: 1 = also glue the game's cloth_pke bones to the hand (they hang on the belt, so default 0)
  volatile LONG watchGame;       // 0.88: 1 = the outside watcher gbvr_watch.exe attaches to the game as a debugger (records fast-fail, exceptions, debug strings)
  volatile LONG skipVideos;      // 0.85: 1 = the game's promo / attract videos are not opened (no start-up videos)
  volatile LONG bodyHeightCm;    // 0.85: the avatar's body is this far higher (+) or lower (-) than before (cm)
  volatile LONG pkeAttach;       // 0.84: while the PKE is in hand, the game's PKE model follows your right hand
  volatile LONG glovesOnly;      // 0.83: 1 = no body or arms at all: the probe draws plain static gloves at the controllers (the PKE keeps the old arms)
  volatile LONG armsStraps;      // 0.80: with armsOnly, the probe draws its own pack straps (the chest is hidden, the game's straps are part of it)
  volatile LONG armsShoulders;   // 0.73: with armsOnly, the shoulders / upper chest (where the pack straps go) stay visible; the neck and head are still squashed away
  volatile LONG simStepCapMs;    // 0.73: the longest single game time step in the headset (ms; 0 = the game's own 62 ms). A hitch no longer becomes one huge step for the ghosts' movement.
  volatile LONG cordPhysics;     // 0.73: the proton hose is a physics cord drawn by the probe from the pack to the wand (the game's own hose is hidden)
  volatile LONG simEveryN;       // 0.74 stuck-ghost test: 1 = the game simulates for every picture (default), 2 / 3 = only every 2nd / 3rd picture
  volatile LONG rigView;         // 0.74: 0 = off, 1..4 = a small copy of the body floats in front of you, seen from the front / right side / back / left side, with a red dot at your real eye
  volatile LONG shoulderSlideCm; // 0.74: after the shoulder swing, the whole shoulder slides up to this far (cm) toward a hand that is still out of reach (0 = off)
  volatile LONG viewUpCm;        // 0.75: the camera (your real eye) sits this far above the avatar's eyes (cm); the head stays hidden, the arms look as if the head were lower
  volatile LONG bodyOutCm;       // 0.75: the whole avatar stands this far (cm) in front of your real eye, so the arms look longer and the hands are closer to the shoulders' reach
  volatile LONG wallDiag;        // 0.75: 1 = log the walls / camera-pull numbers (WALL lines) and save a picture when the view crosses
  volatile LONG rigAutoShots;    // 0.74: with the rig view on, a diagnostic picture is saved by itself now and then (max 6 per run)
  volatile LONG beamDamagePct;   // 0.76: the beams (proton, slime, stasis, capture, slam, crossed...) do this percent of the game's damage to enemies (100 = unchanged, 115 = default)
  volatile LONG hbar;            // 0.76: 1 = a small bold health bar sits inside every enemy (the game's own ring is hidden)
  volatile LONG hbarSizePct;     // 0.76: size of those bars, percent (100 = default; 1.7.19: 60)
  volatile LONG hbarAlphaPct;    // 1.7.19: how solid the health bars are (100 = solid, 50 = see-through)
  volatile LONG hbarDigits;      // 0.76: 1 = the percent number shows for the enemy you look at and for the ones just hit
  volatile LONG slamGesture;     // 0.76: 1 = a quick down-swing of the gun hand while the capture stream is held presses the trigger (the game's slam)
  volatile LONG hbarGate;        // 0.77: 1 = bars only on enemies the game drew in the last frames and that have no wall between you and them
  volatile LONG weaponWheel;     // 0.77: 1 = hold the right grip, flick the right stick, let go = pick a weapon / gadget (the wheel appears at the right hand)
  volatile LONG wheelScalePct;   // 0.77: size of the wheel, percent
  volatile LONG trapThrow;       // 0.77: 1 = squeeze the left grip at the left hip to take the ghost trap, swing the hand out fast to throw it
  volatile LONG slamFlickPct;    // 0.77: how hard the aim stick is flicked toward the side the gun was swept (0 = fire only)
  volatile LONG ltCapture;       // legacy setting; 1.7.57 forces 0: LEFT TRIGGER is always the game's LT / alternate fire, Capture is right stick click
  volatile LONG slamSpeedDeci;   // 0.77: the slam swing counts above this hand speed, 1/10 m/s (any direction)
  volatile LONG viewModelPct;    // 0.77: size of the gun the player sees (percent, 100 = the game's own size)
  volatile LONG chestShield;     // 0.77: 1 = the cord is hidden where it passes behind your chest (an invisible torso written into the depth buffer)
  volatile LONG trapOwnModel;    // 0.79: 1 = draw the probe's own trap model (0 = the game's own trap is carried in the hand instead)
  volatile LONG pkeOwn;         // 0.93: the probe draws its own PKE meter in the right hand; the game's PKE and gun are hidden while the PKE is out
  volatile LONG pkeTiltDeg;     // 0.93: how far the PKE's face is tilted up toward you (degrees)
  volatile LONG pkeGame;        // 0.94: 1 = the GAME's own PKE meter (CPKEMeter) is moved to your right controller (the probe draws nothing); 0 = the game's animation holds it
  volatile LONG pkeFwdCm, pkeUpCm;   // 0.94: slide the game's PKE along its pointing axis / up from the hand (cm), for the fit in the hand
  volatile LONG pkeAssistDeg;   // 0.94: scan help: a PKE source this close (degrees) to where the PKE points pulls the aim onto it (0 = off)
  volatile LONG pkeAssistPct;   // 0.94: how strongly (percent)
  volatile LONG pkeEasy;        // 1.4: 1 = forgiving PKE scan: the game's scan range and cone are widened (the game's own rules: 15 ft, 18 degrees)
  volatile LONG pkeEasyFt;      // 1.4: how far (feet) the PKE can scan with pkeEasy (the game's own is 15)
  volatile LONG pkeCloseHelp;   // 1.7.83: 1 = the scan cone gets wider while a scannable thing is close to the meter (hand-held meter beside the line to what you look at)
  volatile LONG pkeConeDeg;     // 1.4: how far off the PKE's line (degrees) a ghost may be and still be scanned (the game's own is 18)
  volatile LONG pkeAuto;        // 1.4: 1 = the scan starts by itself while the PKE points at something scannable (no trigger needed; the trigger still works)
  volatile LONG pkeFrame;       // 1.4: 1 = the game's green PKE goggle frame is drawn (0 = hidden, the view is clean)
  volatile LONG ringAssist;      // 1.5: 1 = the game's own health ring shows on the ghost you look at (the VR view never gets the game's own lock)
  volatile LONG ringConeDeg;     // 1.5: how far from where you look a ghost may be to get the ring (degrees)
  volatile LONG ringHoldDs;      // 1.5: the ring stays this long after you look away or fire (tenths of a second)
  volatile LONG turnFollow;      // 1.5: 1 = the game's body turns after your head when you turn it past turnFollowDeg
  volatile LONG turnFollowDeg;   // 1.5: how far you turn your head before the body follows (degrees)
  volatile LONG turnSnap;        // 1.5: 1 = the right stick turns in snap steps (0 = the game's smooth stick turn)
  volatile LONG turnSnapDeg;     // 1.5: one snap step (degrees)
  volatile LONG turnSmoothDps;   // 1.7.81: smooth turn speed at full stick (degrees per second, 30..360)
  volatile LONG turnSmoothOwn;   // 1.7.81: 1 = with snap turn off, the MOD turns you smoothly (works where the game ignores its stick); 0 = the game's own stick turn (old way, no menu row)
  volatile LONG gunTwistPct;    // 0.94: how much of the hand's twist about the barrel the gun follows at once (percent; the aim itself keeps its weight)
  volatile LONG pkeWeightPct;   // 0.95: how much the PKE weighs in the hand (percent; 0 = none, 40 = a light device with a little inertia, 100 = clearly heavy)
  volatile LONG leftHandDraw;   // 1.7.174: 1 (default) = left-handed play draws the body's left arm and hand on the gun and the right arm at the free controller
  volatile LONG gunFireFx;      // 1.7.173: 1 = firing moves the gun in the hand (recoil, climb, shake, kick, slower follow); 0 (default) = firing does nothing to the gun's place, only its resting weight stays
  volatile LONG trapNoAnim;     // 1.7.173: 1 (default) = the game's own trap button throws from your off hand and the game's throw animation is kept off your upper body
  volatile LONG gunPunishPct;   // 0.95: how hard a ONE-handed shot is (percent; 0 = the 0.94 feel, 100 = default, 200 = brutal): climb, shake, kick, slower follow
  volatile LONG flatVoid;       // 0.95: 1 = the flat 2D screen (menus, videos) floats in a black void (SteamVR's grid room is faded out)
  volatile LONG flatGlowPct;    // 0.95: strength of the soft TV glow around the flat screen, taken from the picture's own edge colours (0 = off)
  volatile LONG flatBlack;      // 0.98: 1 = black frames keep going to the headset behind the flat screen (SteamVR Home stays away); 0 = the 0.95-0.97 way (ClearLastSubmittedFrame)
  volatile LONG flatGlowSteady; // 0.98: 1 = the TV glow is a calm, slowly changing colour (no flashing with the picture); 0 = the 0.95-0.97 glow that follows the picture closely
  volatile LONG switchHelp;     // 1.1: 1 = a gear switch the game leaves stuck is finished the game's own way, and a PKE/gun request is queued the way the Y button does (0 = only the Y button)
  volatile LONG flatSizePct;    // 1.1: the flat 2D screen's size (percent of the default 3.6 m wide at 2.8 m)
  volatile LONG flatDistCm;     // 1.1: how far away the flat screen floats (centimetres)
  volatile LONG flatDropCm;     // 1.1: how far below your eyes its middle is (centimetres)
  volatile LONG flatCurvePct;   // 1.1: how much the flat screen bends around you (0 = flat, 100 = strongly curved)
  volatile LONG monitorView;    // 1.2: 1 = the game window on the PC screen shows ONE steady eye picture (not the alternating eyes), not stretched
  volatile LONG monitorEye;     // 1.2: which eye the window shows: 0 = left (default: the log showed the body offered less often in the right eye), 1 = right
  volatile LONG monitorFit;     // 1.2: 0 = the whole wide picture (black bars at the sides), 1 = fills the window (cuts a little at the top and bottom)
  volatile LONG monitorLevel;   // 1.2: 1 = the horizon stays level on the monitor when you tilt your head
  volatile LONG monitorZoomPct; // 1.2: how much of the picture is shown (100 = all of it, 50 = the middle half)
  volatile LONG monitorWidePct; // 1.7.9: while the monitor view is on, the game draws this much wider than the headset needs (100 = as the headset needs, 125 = default): the PC window shows much more of the world
  volatile LONG pictureTanX1000;// 1.7.9: half-FOV tangent (x1000) the engine really draws now (the monitor log turns it into degrees)
  volatile LONG holdView;        // 1.7.17: 1 = the game's own heading changes while a trigger is held (capture / fire) are absorbed into the picture (no spin)
  volatile LONG fingerRestPct;   // 1.7.17: how far an open hand's fingers are curled (relaxed hand), percent
  volatile LONG pkeProxBuzz;    // 1.7.13: the PKE hand buzzes faster and stronger the closer the nearest unscanned thing is
  volatile LONG gamePlace;      // 1.7.13: 1 = the game's own animation places the gun and the PKE (and holds them in the avatar's hands); the probe only aims (controller direction), drawing nothing at the controllers
  volatile LONG streamAimGun;   // 1.7.10: 1 = the game's hit point for the proton stream (its camera ray / aim read) is put on the line of the gun's barrel, at the same distance
  volatile LONG pkeGoggles;     // 1.7.9: 1 = the game's green PKE goggle view (and what only shows in it) is on while the PKE is in the hand; 2 = also the game's developer "show everything" switch
  volatile LONG startInVr;      // 1.3: 1 = the headset view starts by itself a moment after the game starts (like pressing F4)
  volatile LONG sceneFadeMs;    // 1.7.186: the Stay Puft roof-fight jumps (into the roof spot and back out) fade up from black over this many ms (3000; 0 = use fade_in_ms)
  volatile LONG fadeInMs;       // 1.3: the 3D picture fades up from black over this many milliseconds when it takes over from a 2D screen (0 = off)
  volatile LONG flatCursor;     // 1.3: 1 = a ring cursor is drawn on the 2D screen where the controller's laser hits it
  volatile LONG flatCursorPct;  // 1.3: size of that ring (100 = default)
  volatile LONG menuDimFlat;    // 1.3: 1 = the 2D screen dims while the VR menu is open in front of it
  volatile LONG pkeShowBody;    // 0.98: 1 = the avatar's body stays visible while the PKE is out (the game hides it for its own PKE view)
  volatile LONG pkePairCache;   // 0.98: 1 = the PKE is placed ONCE per eye pair (both eyes see it in the same place) and the last good grip offset is kept for a short time
  volatile LONG pkeShiftPct;    // 0.98: share of the arm code's "handle in the hand" slide used for the PKE (percent; 0 = the PKE sits exactly on the controller's grip point, 100 = the whole 0.97 slide)
  volatile LONG pkeRigid;       // 1.6: 1 = the PKE keeps ONE fixed spot in the hand (the hand slide is measured in the PKE's own axes and eased slowly) - the game's hand offset jumps up to 15 cm from frame to frame, which made the PKE float
  volatile LONG handLock;       // 1.7.32: direct controller pose and a fixed calibrated grip offset
  volatile LONG vrFpsCap;       // 1.7.33: completed stereo pairs per second; does not change headset refresh
  volatile LONG gunRigid;       // 1.6: the same for the gun
  volatile LONG wheelAlphaPct;  // 1.6: how solid the weapon wheel is (100 = solid, 55 = see-through)
  volatile LONG hudRetry;       // 1.6: 1 = if the game's HUD did not draw for one eye of a pair, ask the game to draw it again for that eye
  volatile LONG pkeScanHelp;    // 1.6: 1 = the scan is also driven by the probe (holds the game's scan input and, when the game's own checks fail only on range/angle, re-checks with the wider cone)
  volatile LONG ringClearGone;  // 1.6: 1 = the ring is dropped as soon as the ghost it points at is gone / dead
  // ---- 1.7
  volatile LONG gunWrapPct;     // 1.7: how far the weapon hand's grip fingers stay wrapped around the gun / PKE when the controller grip is not squeezed (0..100; the 1.6 pictures showed an open hand with the weapon in front of it)
  volatile LONG gunFwdCm, gunUpCm;   // 1.7: the gun's fit in the hand, set in the menu (cm along the pointing direction / along up, -30..30)
  volatile LONG aimGhostOnly;   // 1.7: 1 = the aim assist only pulls toward a living ghost (not toward tables, chairs and other things the game's lock can sit on)
  volatile LONG pkeTrigScan;    // 1.7: 1 = pressing the right trigger with the PKE out scans (the probe sets the game's scan input itself)
  volatile LONG easySprint;     // 1.7: 1 = the game's sprint starts at once (0.08 s instead of 0.55 s), lasts 30 s and is never blocked afterwards
  volatile LONG sprintLatch;    // 1.7: 1 = a quick tap of the left stick click keeps sprint on until you let go of the stick or tap again
  volatile LONG sprintTurnFree; // 1.7: 1 = turning is not slowed while you sprint (the game clamps it to 65 deg/s)
  volatile LONG holsterOnBack;  // 1.7.25: 1 = the holstered gun is drawn at the pack on your back (was: at the game's own hip spot)
  volatile LONG monitorHfovDeg; // 1.7.28: the PC window shows this many degrees across (cropped from the wide picture; 0 = use monitor_zoom_pct). The headset picture is not touched
  volatile LONG monitorDownDeg; // 1.7.48: lower the monitor framing, within the existing eye picture
  volatile LONG monitorHandFrame; // 1.7.48: smoothly lower framing to include forward hands and the gun
  volatile LONG monitorMenuFill;// 1.7.28: 1 = the flat menu / video picture fills the PC window (stretched), 0 = its own square shape with black bars
  volatile LONG heldLive;       // 1.7.84: 1 = the menu gesture opens the VR pages in the hand over the LIVE world (game frozen, you can look all around); 0 = the game's own pause menu with the last picture frozen behind it
  volatile LONG heldMenu;       // 1.7.28: 1 = the game's own pause menu is THE menu: held in the hand that does not hold the gun, world frozen behind it, VR settings inside (the old floating VR menu is off)
  volatile LONG heldMenuCm;     // 1.7.28: width of the hand-held panel in centimetres
  volatile LONG bodyCalmMs;     // 1.7.29: calm walking: time constant (ms) of the smoothing of the body's offset from the eye (0 = off, 1.7.28 behaviour)
  volatile LONG mirrorVr;       // 1.7.30: 1 = mirrors (hotel, bathrooms) are built from your headset eye and view direction (they were built from the flat-screen camera, so they showed the wrong thing); 0 = the game's own mirrors
  volatile LONG hbarSmart;      // 1.7.30: 1 = smart health bars: no bar before the ghost has been seen, none for a ghost that is in the trap or being sucked in; 0 = the 1.7.29 rules
  volatile LONG pairHands;      // 1.7.31: 1 = both eyes of a pair use the hand / controller poses read for the FIRST eye (gun, PKE and arms are in the same place in both pictures); 0 = each eye reads its own
  volatile LONG heldMenuFollow; // 1.7.31: 1 = the hand-held menu follows the hand from its own fast loop (display pace, short smoothing); 0 = placed once per game screen update (1.7.29/30)
  volatile LONG bosonGrip;      // optional legacy shortcut; 1.7.57 defaults 0 because alternate fire belongs on physical LEFT TRIGGER
  volatile LONG sprintGame;     // 1.7.38: 1 = the sprint toggle (left stick click) starts the game's own run (its run bit is set while sprint is on and the stick is pushed); 0 = the 1.7.8 speed boost (measured: no gain)
  volatile LONG chestCam;       // 1.7.38: 1 = the PC window shows a chest camera (upper chest, pushed back, looking where the gun points) so the arms and the weapon are always in view. Costs one extra picture every chest_cam_every pairs
  volatile LONG chestCamEvery;  // 1.7.38: one chest-camera picture after this many eye pairs (1 = every pair, 8 = every eighth)
  volatile LONG chestCamDownCm; // 1.7.38: how far below the eyes the chest camera sits (centimetres)
  volatile LONG chestCamBackCm; // 1.7.38: how far behind the eyes it is pushed (centimetres)
  volatile LONG chestCamNearCm; // 1.7.38: nearest distance it draws (centimetres): the player's own head and neck behind/above it are cut away
  volatile LONG stereoSpecNext; // 1.7.38: set by the render thread after a finished pair: the next prepared frame is the chest-camera picture (consumed by the camera thread)
  volatile LONG trapFree;       // 1.7.37: 1 = a freer trap throw (short lob, half the release speed, shorter pause)
  volatile LONG trapFromHand;   // 1.7.37: 1 = the thrown trap starts from the hand that threw it (the game starts it at your side)
  volatile LONG gunHpBar;       // 1.7.37: 1 = a life bar on top of the gun shows the player's health (green to red, no numbers)
  volatile LONG ghostHpLiquid;  // 1.7.158: 1 = the ghosts' health is a vial of glowing liquid (the mod draws it; the game's own ring is not shown); 0 = as before (og_health / ring / bars)
  volatile LONG gunHpLiquid;    // 1.7.157: 1 = the life bar is a tube of glowing liquid with a beating heart; 0 = the plain 1.7.37 strip
  volatile LONG gunHpFwdCm;     // 1.7.37: where the bar sits along the gun, centimetres in front of the grip
  volatile LONG gunHpUpCm;      // 1.7.37: how far above the grip line, centimetres (1.7.64: may be negative = below)
  volatile LONG gunHpSideCm;    // 1.7.64: sideways from the gun's centre line, centimetres (negative = left)
  volatile LONG hideBeltPke;    // 1.7.64: 1 = the game's belt copy of the PKE (cloth_pke, with its swinging cable) is not drawn on the body
  volatile LONG pkeGripHeal;    // 1.7.64: 1 = a PKE hand grip that disagrees with what the game shows for a while is captured again
  volatile LONG pkeLiveGrip;    // 1.7.66: 1 = the PKE follows the hand-to-meter relation the game shows now (no early freeze); 0 = the 1.7.65 frozen grip
  volatile LONG pkeSetMatrix;   // 1.7.70: 1 = the PKE pose is handed to the game through its own setter (the drawn model takes it)
  volatile LONG handClean;      // 1.7.70: 1 = a stretched / sheared hand bone is made clean
  volatile LONG pkeSteadyOnly;  // 1.7.69: 1 = the PKE's hold is only adjusted while the hand is steady and eases in; 0 = the gun's rule (every fresh sample)
  volatile LONG armReachPct;    // 1.7.69: elbow room: the avatar's arms are this much longer along the limb (100 = as modelled) so the elbows bend
  volatile LONG stairsSmoothMs; // 1.7.69: the eye height is eased over this many ms so stairs do not jolt the view (0 = off)
  volatile LONG stairsRamp;     // 1.7.71: a flight of stairs becomes a smooth slope for the eye (stairsmath.h); 0 = the 1.7.69 easing
  volatile LONG stairsLift;     // 1.7.71: the sprint boost's extra step climbs with the stairs instead of pushing into the riser
  volatile LONG pkeDrawSwap;    // 1.7.71: the PKE is moved where it is drawn (the gun's way, see pkedrawmath.h)
  volatile LONG gunHoldSmoothMs; // 1.7.71: small changes of the game's hold on the gun are eased over this many ms (walking tremble); 0 = every frame as in 1.7.70
  volatile LONG pkeHoldRpke;    // 1.7.74: the PKE grip comes from the animation's R_PKE hold (not the pose fixed in front of the view), kept once steady
  volatile LONG slimeLtEdge;    // 1.7.74: slime blower alternate fire = one short press per squeeze (as 1.7.73)
  volatile LONG keepControl;    // 1.7.79: 1 = the probe ALWAYS keeps the body, arms, gun and eye match, whatever the game does (stairs, moving platforms, portals, level loads, cutscenes): no hand-back to the game's animation
  volatile LONG drawAnim;       // 1.7.98: 1 = the game's own draw / stow animation (the gun or the meter travelling from the back / belt to the hand, its own fingers closing) is shown on your hand for the first moment after a switch (view only); 0 = the prop appears in the hand at once
  volatile LONG gunWaitDraw;  // 1.7.99: 1 = the game decides when you may hold the gun: not allowed (cut-scene, between levels) = holstered; a gun the game GIVES stays holstered until you draw it (the hand buzzes when you may)
  volatile LONG gunCtlFollow;   // 1.7.78: the gun sits on the controller through the locked hand<->controller relation (not the arm solve's hand)
  volatile LONG gunFreshHand;   // 1.7.77: the gun is placed through the hand of the last arm solve moved on with the controller since (no trailing behind fast hands)
  volatile LONG pkeCtlRigid;    // 1.7.76: with the PKE out the right hand turns exactly with the controller (relation captured once at the steady hold), so the meter in it does not swing
  volatile LONG pkeFingersAnim; // 1.7.76: with the PKE out the right hand keeps the game's own fingers (around the handle) instead of following the grip button
  volatile LONG gameFingers;    // 1.7.103: 1 = the hand that supports the gun, and the free hand while the PKE is out, keep the game's own finger pose (0 = the probe's soft finger shape)
  volatile LONG stationBeamFree; // 1.7.169: on the Stay Puft rooftop the stream leaves toward where the game sends it (no forced start = no kink)
  volatile LONG stationBackCm;   // 1.7.169: extra slide back of the body on the rooftop (cm)
  volatile LONG bodyDownBackCm;   // 1.7.168: looking down, the body slides this far back (cm); 0 = off
  volatile LONG gunHpOnGun;    // 1.7.167: 1 = the gun's health tube follows the drawn gun (its muzzle), not the bare controller
  volatile LONG gunHpHandCut;  // 1.7.167: 1 = your hands hide the tube where they are in front of it
  volatile LONG gunHpRigid;    // 1.7.185: 1 = the tube takes the drawn gun's muzzle at once on every new game sample (locked to the gun); 0 = the 1.7.172 slow filter
  volatile LONG bodyHandsYaw;  // 1.7.167: 1 = the body turns with where your hands are, not only with your head
  volatile LONG trapGravity;   // 1.7.182: 1 = the trap hangs straight down from the fist like a case by its handle, flat face to the palm side; 0 = the 1.7.166 hold (top to the controller's up)
  volatile LONG trapHang;      // 1.7.166: 1 = the trap in the hand hangs below the fist like a case by its handle; 0 = the 0.79 hold (the angle it had when taken)
  volatile LONG gunHpPhysics;  // 1.7.162: 1 = the gun tube's liquid moves with the gun (the ghosts' vials never do); 0 = still
  volatile LONG pkeCentre;     // 1.7.158: 1 = the PKE's centre also sits on the controller (up / forward), not only in its centre plane; 0 = the 1.7.111 look
  volatile LONG pkeAlignPitch; // 1.7.111: 1 = the PKE's long side also lies at pke_pitch_deg above the controller's forward (not only straight sideways); 0 = the 1.7.104 look
  volatile LONG gunFingerOpenPct; // 1.7.111: letting the grip go opens the gun hand's grip fingers by up to this % (0 = they stay in the game's fist as before)
  volatile LONG pkeEaseMs;       // 1.7.225: the PKE alignment eases in over this many ms after the grip locks (default 450; 0 = at once)
  volatile LONG pkeTurnMaxDeg; // 1.7.224: the PKE alignment turns the hand by at most this many degrees to lift/lower the meter (default 25; 90 = the old full turn)
  volatile LONG pkePitchDeg;   // 1.7.111: how far the PKE's long side points up from the controller's forward, degrees (0 = straight along it)
  volatile LONG pkeAlign;      // 1.7.104: 1 = the PKE in your hand is turned so its long side lies straight along your controller (not pulled to the side) and is centred on it
  volatile LONG trigFingerDeg; // 1.7.109: the gun hand's trigger finger bends this many degrees (beyond the game's pose) at a full trigger pull (was fixed at 55)
  volatile LONG fingerAnalog;  // 1.7.111: 1 = the hands' fingers follow the controller analog (grip squeeze, thumb off its buttons = up, finger off the trigger = pointing) instead of two fixed poses; 0 = the open / fist poses
  volatile LONG grabOrbitDeg;  // 1.7.111: where round the barrel the held hand sits: 0 = under, 90 = left side, 180 = on top (110 = the overhand hold of the teaser)
  volatile LONG grabOrbitFollowPct; // 1.7.111: how much your real hand moves that place (%)
  volatile LONG grabWrap;      // 1.7.109: 1 = the hand holding the gun wraps AROUND the barrel (palm on it, thumb to the muzzle, fingers round it); 0 = the 1.7.108 look
  volatile LONG gunHandNoAnim;     // 1.7.226: 1 = the game's hand-on-gun animations (weapon change, alt fire, reload, trap throw) are not shown: the gun hand and arm keep their pose
  volatile LONG dartPauseStream;   // 1.7.224: while the left trigger is pulled with the proton gun, the stream trigger is let go for the game (the dart only left the gun when the stream was not held)
  volatile LONG roofAutoCenter;   // 1.7.220: the Stay Puft roof view re-centres once (with the comfort fade) when your head rests 12+ deg off the boss direction (1 = on)
  volatile LONG grabWrapDeg;   // 1.7.109: how far the wrapped fingers lean toward the muzzle (degrees, 0 = straight across the barrel)
  volatile LONG foreGrab;      // 1.7.105: 1 = squeezing the left grip near the barrel makes the hand take hold of the gun and stay on it (follows the gun as its model changes); 0 = the soft slide of 1.7.104
  volatile LONG foreSteady;    // 1.7.104: 1 = the hand that supports the gun does not slide along the barrel while you walk / sprint
  volatile LONG emptyFingers;  // 1.7.104: 1 = with nothing in the right hand its fingers follow the controller (grip / trigger / thumb) fully
  volatile LONG ringWall;      // 1.7.108: 1 = the health ring never goes to an enemy behind a wall (needs a clear line, a hit or a hold)
  volatile LONG ringFollow;    // 1.7.111: 1 = the health ring goes to the ghost you hold or hit (wherever you look), 0 = only by gaze like 1.7.110
  volatile LONG healthStyle;   // 1.7.111: 0 = the round ring on the ghost you aim at (the game's own ring, default); 1 = the small health bars over the ghosts (the ring is hidden)
  volatile LONG foreNearCm;    // 1.7.114: a free left hand within this many cm of the barrel takes hold of the gun by itself (no grip squeeze); 0 = off
  volatile LONG healthAny;     // 1.7.113: 1 = a ghost that is on screen, that you hit or that you hold gets its health shown even when the game's can-lock test says no (default 1)
  volatile LONG twoHandLine;   // 1.7.127: 1 = aim along both hands by default; 0 = right controller only
  volatile LONG captureTap;    // 1.7.111: 0 = the right-stick click (grab / wrangle) is held while you hold it; 1 = one click grabs, the next click lets go
  volatile LONG ogHealth;      // 1.7.106: 1 = the original game enemy health ring (the game's own art) is the ghost / boss health display; the probe's round ring only steps in when the game's is not on the screen. 0 = the 1.7.103 rules (ring_mode / ghost_ring)
  volatile LONG ghostRing;     // 1.7.103: 1 = a round health ring sits on the ghost you look at / hold (same place as the bar); 0 = the bars on every ghost
  volatile LONG trapHold;      // 1.7.103: 1 = the trap in your hand turns with your wrist and hangs from its top (the handle end) in your fist, instead of staying as the game put it with your hand in its middle
  volatile LONG slimeRopeFix;   // 1.7.76: the slime rope is one step per squeeze (two squeezes = the rope's two anchors)
  volatile LONG slimeMuzzle;    // 1.7.71: the slime blower's own attachments (muzzle) are carried onto the gun in your hand
  volatile LONG gunLiveGrip;    // 1.7.68: 1 = the hand on the gun follows the game's hold as the game shows it now (as at spawn); 0 = the hold frozen just after the weapon is equipped
  volatile LONG pkeRigidHand;   // 1.7.67: 1 = the PKE is placed through a clean copy of the drawn hand (axes perpendicular, one size) so a stretched hand matrix cannot stretch or push the meter; 0 = the hand as it is
  volatile LONG gunGripHeal;    // 1.7.66: 1 = in the first seconds after the gun grip is taken, a steady and clearly different game hold (spawn / view model switch) is captured again
  volatile LONG hideGunGap;     // 1.7.66: 1 = while the arms are not there yet (spawn, weapon switch) the gun is not drawn at the game's own spot (the floor); it shows when the hand is ready
  volatile LONG trapHangPct;     // 1.7.197: how far the carried trap hangs below the fist, in percent of the 1.7.193 drop (smaller = the trap sits higher in the hand)
  volatile LONG downVignette;    // 1.7.197: 1 = when you are dying / downed the body is not drawn (the arms stay) and the edges pulse red; the same red pulse in a knock-down
  volatile LONG bodyCalmSlam;    // 1.7.196: 1 = while a ghost is held in the beam or a slam plays, the body's chest does not follow the hands and twists at most 30 deg from the head
  volatile LONG knockComfort;   // 1.7.36: 1 = a ghost's knock-down is not played (no fall); instead slower walking, dark edges and a harder aim for knock_ms
  volatile LONG knockMs;        // 1.7.36: how long that lasts (milliseconds)
  volatile LONG knockWalkPct;   // 1.7.36: walking speed at the strongest point (percent of normal)
  volatile LONG knockAimDeg;    // 1.7.36: aim sway in degrees at the strongest point (0 = none)
  volatile LONG knockDarkPct;   // 1.7.36: how dark the edges get (0 = none)
  volatile LONG heldMenuMinCm;  // 1.7.31: the hand-held menu is never closer than this to your eyes, in centimetres (a panel beside the face looked a different size in each eye); 0 = no limit
  volatile LONG texAniso;       // 1.7.27: 0 = the game's texture filtering as it is; 2..16 = plain linear texture samplers become anisotropic with this many taps (floors, walls and carpet stay sharp at an angle). Applies to samplers made after the start: restart the game.
  volatile LONG hbarWallHide;   // 1.7.27: 1 = a ghost's health bar goes away while the ghost is behind a wall (0.3 s of blocked line); 0 = the bar stays (unspawned and dead ghosts get none either way)
  volatile LONG pairSame;       // 1.7.27: 1 = the right eye uses the left eye's answer for every player part (body, pack, gun, PKE): both eyes always show the same things
  volatile LONG eyeAa;          // 1.7.153: 1 = smooth edges (anti-aliasing) on the headset pictures; 0 (default) = the plain pictures
  volatile LONG eyeAaSharpPct;  // 1.7.153: light sharpening after the smoothing, 0..100 (25)
  volatile LONG cutHoldMs;      // 1.7.151: after a 2D screen, 3D comes back only when the play camera has been there this long without a break (cutscene shots stay 2D); 0 = off
  volatile LONG cutFade;        // 1.7.151: 1 = when the game jumps the character to another place while you are in 3D, the picture goes through black (a cut, not a lurch)
  volatile LONG flatGlowCorners;// 1.7.151: 1 = the TV glow takes the colours of the four corners of the picture (four tinted layers)
  volatile LONG pauseSeenTick;  // 1.7.151: GetTickCount of the last frame the game's pause flag was set (0 = never)
  volatile LONG cineGuard;      // 1.7.26: 1 = while the game is in charge of the character (cutscene walks, cuts) the probe leaves the body, arms and gun alone and eases back in afterwards
  volatile LONG slamAssist;     // 1.7.24: 1 = when the slam sequence is done and the game has not started the slam itself (ghost held, meter full), the probe calls the game's own "start slam" step
  volatile LONG slamTrigger;    // 1.7: 1 = while the capture stream holds a ghost, squeezing the left trigger all the way slams it the way you pull
  volatile LONG slamTrigPct;    // 1.7: how far the left trigger must be squeezed for the slam (percent)
  volatile LONG slamBuzzPct;    // 1.7: strength of the grab / slam vibration (percent, 0 = off)
  volatile LONG itemGlowPct;    // 1.7: how strong the light on items lying on the ground is (0 = off)
  // ---- 1.7.2
  volatile LONG collectMarkers; // 1.7.3: 1 = a small glowing marker on every collectible nearby (and on PKE scan targets while the PKE is out): the game's own glow does not show in the headset
  volatile LONG collectMarkerAlways; // 1.7.3: 0 = a collectible's marker shows only after you scan for it (PKE out, point at it for a moment); 1 = always shown (easy)
  volatile LONG menuStrict;     // 1.7.7: 1 = the menu opens only with the left hand beside the left ear (not in front of the face), not on the gun, hand still 0.6 s; 0 = the old 30 cm ball
  volatile LONG gunWristCm;     // 1.7.7: the weapon hand's wrist sits this far behind the controller point (like the left hand's Wrist back); the weapon slides back with it, so the fist is in the real hand
  volatile LONG sprintSpeedPct; // 1.7.8: sprint on (left stick click) + left stick pushed = the character moves this much faster (100 = off, 170 default), in every direction, without the game's run
  volatile LONG sprintSpeedMethod; // 1.7.8: 0 = auto (tries velocity, then time, then nudge, and keeps the one that measurably works), 1 = velocity, 2 = time, 3 = nudge
  volatile LONG walkHead;       // 1.7.8: 1 = the left stick walks where the HEADSET points (the stick is turned by the head's angle from the game's heading), whatever the game's camera does
  volatile LONG sprintForce;    // 1.7.6: 1 = while sprint is on (click) and you push the left stick, the probe sets the game's sprint bit itself (1.7.1: 336 L3 clicks and 1.7.5: 194 Jump polls started 0 game sprints)
  volatile LONG walkCapPct;     // 1.7.6: limit of the left stick push in percent while sprint is off (100 = off), so full stick stays in the game's walk instead of its run
  volatile LONG sprintToggle;   // 1.7.5: 1 = the left stick click is a real toggle (click on, click again off; a long press does not hold it); 0 = the 1.7 tap/hold behaviour
  volatile LONG turnFollowWalk; // 1.7.5: 1 = while you push the left stick the body follows your head sooner and settles closer (go where you look)
  volatile LONG sprintViaJump;  // 1.7.3: 1 = the left stick click while you move also holds the game's Jump/Evade/Sprint button (the game's real sprint is 'hold Jump/Evade')
  volatile LONG collectMarkerPct; // 1.7.3: size of those markers, percent (100 = default)
  volatile LONG lockGhostOnly;  // 1.7.2: 1 = the game's own lock on the proton stream (player+0xB550) and its ring focus (player+0x2E8) are let go when they sit on anything that is not a ghost (tables, chairs, props)
  volatile LONG sprintClick;    // 1 = LEFT stick click is Sprint (L3); 1.7.57 normal RIGHT stick click is Capture (LB); left trigger is always LT / alternate fire
  volatile LONG pkeEntity;      // 0.97: 1 = the game's PKE is moved by its ENTITY matrix too (that is what the game draws and scans from); 0 = only the second pose (0.94-0.96: stayed in the animation)
  volatile LONG pkeLikeGun;     // 0.91: the PKE is placed on the controller like the gun (the game's animation placement left it 2.3 ft away, stuck in the air)
  volatile LONG hoseOff;         // 0.90: 1 = the proton hose is not drawn at all (neither the game's own, nor the probe's physics cord), also not in the PKE animation
  volatile LONG bodyWhole;       // 0.90: with "chest visible": the whole body is kept except the neck and head (no squashed bones = no stretched "skin void" shards when looking down)
  volatile LONG trapHipDropCm;   // 0.90: where the trap grab zone sits: this far below the head ...
  volatile LONG trapHipRadiusCm; // 0.90: ... and this big (the 0.78 zone was 55 cm / 20 cm: too high for a standing player, nobody could ever grab the trap)
  volatile LONG hoseFromGame;    // 0.78: 1 = the hose takes its colour from the game's own hose texture (walks the player's model parts; logs PARTS lines)
  volatile LONG forearmTwistPct; // 0.77: share of the hand's turn that the forearm takes (percent, 0 = only the hand turns)
  volatile LONG twoHandPitchDeci;// 0.77: when the free hand holds the barrel the gun is tilted up by this much, 1/10 degree (the support hand sits below the barrel axis)
  volatile LONG twoHandRefCm;    // 1.7.111: the two-hand tilt follows the hand distance, equal to two_hand_pitch_deci at this many cm (0 = fixed tilt as before)
  volatile LONG dpadAwayCm;      // 0.77: left grip + free hand this far from the gun hand + right stick = D-pad (equipment / beam choice), cm
  volatile LONG forcedDetect;    // 0.69: 1 = watch for the game moving the character by force (cutscene, knock-back) and ease the body corrections out meanwhile
  volatile LONG beamStraight;    // 0.69: 1 = the proton stream leaves the gun's tip along the barrel (the game's own bend toward the head-ray hit point is removed)
  volatile LONG menuMusic;       // 0.69: 1 = the menu plays the song (gbvr_menu_music.mp3 in the game folder)
  volatile LONG menuMusicPct;    // 0.69: the song's volume, percent
  volatile LONG menuMuteGame;    // 0.69: 1 = the game's own sound is silent while the menu is open
  volatile LONG menuBg;          // 0.69: 1 = the menu has the cover picture behind it (blurred, see-through)
  volatile LONG menuBgPct;       // 0.69: how strongly the picture shows (percent)
  volatile LONG packFollow;      // 0.68: 1 = the pack drops and leans with the torso
  volatile LONG shoulderPullDeg; // 0.68: 0 = off; the shoulder swings up to this many degrees toward a hand that is farther than the arm reaches
  volatile LONG crouchDeadCm;    // 0.68: a head drop smaller than this (cm) is a lean, not a crouch
  volatile LONG aimAssistPct;    // 0.68: 0 = off; how strongly the beam is pulled onto a ghost it nearly hits (100 = default)
  volatile LONG aimAssistDeg;    // 0.68: the cone (degrees) in which a ghost pulls the beam
  volatile LONG bodyLeanCm, bodyLeanDeg, bodyHeadDeg, bodyDropCm, bodyCrouch, armStretchPct;   // 0.61
  volatile LONG menuOwnPointer;  // 0.61: 1 = the menu uses my own pointer ring (ray from the controller) instead of SteamVR's laser events
  volatile LONG noPauseMenu;     // 0.61: 1 = if the game's own pause menu shows up in VR, tap Start to leave it again
  volatile LONG autoPause;       // 0.52: 1 = leaving the game in VR (SteamVR menu, headset off, SteamVR quit) presses Start for you (pause menu)
  volatile LONG realModels;      // 0.51 F1: 1 = the game's own body, pack, hose and wand are shown (the wand at your right hand), our placeholder wand / hands are not drawn
  volatile LONG wandToHand;      // 0.51: 1 = the game's wand model is moved to the controller (needs realModels), 0 = it stays where the game animates it
  volatile LONG gunGlue;         // 0.66: 1 = if the avatar's arm cannot reach the controller the gun stays in the avatar's hand (and the beam starts there), 0 = the gun always sits at the controller
  volatile LONG gripAtHand;      // 0.93: the hand sits exactly on the controller, the gun slides to fit it (1) / the old way: hand offset from the controller (0)
  volatile LONG wandRollDeg;     // 0.58: turns the gun about its barrel (degrees) when the model's up is not the grip's up
  volatile LONG wandBackCm;      // 0.51: real wand slid back (+) / forward (-) along its barrel, centimetres, to fit the hand
  volatile LONG gunWeightPct;    // 0.51: weight of the wand, 0 = none (instant), 100 = default, 200 = very heavy
  volatile LONG hapticPct;       // 0.51: controller motor strength, 0 = off, 100 = default
  volatile LONG hapticPeriodMs;  // 0.51: time between two haptic pulses (3..20)
  volatile LONG handModel;       // 0.34 Ctrl+F3: 1 = gloved hands and a proton wand drawn at the controllers (default)
  volatile LONG stereoSameMoment;// Delete: the second eye of a pair is drawn from the same game moment as the first
                                 // (its frame gets a near-zero time step; the time is added to the next frame)
  int64_t       captureStartQpc;
  HWND          gameHwnd;      // from the game's swap chain
};
extern Control g_ctl;
// 1.7.111 health_style: 1 = bars over the ghosts; the other health settings are read through these so the style wins without rewriting them
static inline int health_og() { return (g_ctl.healthStyle == 1 || (g_ctl.ghostHpLiquid && g_ctl.hbar)) ? 0 : (int)g_ctl.ogHealth; }   // 1.7.158: the vial replaces the game's own ring
static inline int health_ghost_ring() { return g_ctl.healthStyle == 1 ? 0 : (int)g_ctl.ghostRing; }
static inline int health_ring_hidden() { return (g_ctl.healthStyle == 1 || (g_ctl.ghostHpLiquid && g_ctl.hbar)) ? 1 : (int)g_ctl.ringMode; }
// 1.7.63: profiling is genuinely dormant when diagnostics are off.  Older builds
// still called QueryPerformanceCounter at every ProfScope entry even though
// prof_add() immediately discarded the sample.
struct ProfScope {
  int slot; int64_t t0;
  ProfScope(int s) : slot(s), t0(g_ctl.probeData ? qpc_now() : 0) {}
  ~ProfScope() { if (t0) prof_add(slot, t0); }
};
// 0.51: the game's own body is hidden in first person only while the placeholder models are in use (real_models off)
int knockdown_active();  // the game's current big-hurt animation, only in the VR view
static inline int gb_hide_body() { return (g_ctl.hideBody && !g_ctl.realModels) || knockdown_active(); }

// Turn every camera modification off (F6). Safe from any thread; logged.
void control_reset(const char* reason);
LONG control_mode();

// Render-side (render_hooks.cpp)
void render_install_factory_hooks(void* d3d11Device);
void sampler_report(long frame);   // 1.7.27
int  game_window_focused();
LONG render_present_count();

// ---------------------------------------------------------------------------
// 0.44 fail-safes (safety.cpp). Where the code was, what went wrong, and what the tool does about it.
#if GBVR_HEADTRACK
// Stage = what a thread was doing last. Written with plain stores (cheap, any thread); read by the crash note,
// the stall watchdog and the HEALTH line. g_stageR: the render thread (inside the game's Present); g_stageG: the
// game's main loop hooks (tick, simulate, camera prepare...).
enum Stage : LONG {
  ST_NONE = 0, ST_PRESENT_ENTER, ST_KEYS, ST_SESSION, ST_HEADTRACK, ST_REPORT, ST_BEFORE_PRESENT, ST_ACQUIRE_BB, ST_COPY_EYE,
  ST_HAND_MODEL, ST_SUBMIT, ST_FLAT_SCREEN, ST_MENU_PUMP, ST_REAL_PRESENT, ST_AFTER_PRESENT, ST_WAIT_POSES, ST_CONTROLLERS,
  ST_TIMING_REPORT, ST_EXIT, ST_SETTINGS, ST_G_TICK, ST_G_SIMULATE, ST_G_PREPARE, ST_G_AIM, ST_G_TIP, ST_G_BIND, ST_G_HUD, ST_FLATVIEW,
  ST_COUNT
};
extern volatile LONG g_stageR, g_stageG;
const char* stage_name(LONG s);
inline void stage_r(Stage s) { g_stageR = s; }
inline void stage_g(Stage s) { g_stageG = s; }

// Things that went wrong, counted for the HEALTH line.
enum Issue : int { IS_PRESENT_FAIL = 0, IS_DEVICE_REMOVED, IS_TEXTURE, IS_SUBMIT, IS_OVERLAY, IS_WAIT, IS_POSE, IS_STALL, IS_FAULT,
                   IS_MENUFAST_OFF, IS_PERF_FALLBACK, IS_PICTURE_FALLBACK, IS_VRAM, IS_COUNT };
void safety_issue(Issue i);
int  safety_issue_count(Issue i);

void safety_after_settings();                  // init: read the previous run's marker, apply the fallback ladder (log SAFETY...)
LONG safety_saved_value(volatile LONG* v, LONG cur);   // 1.7.117: what the settings file gets for a value the safety step-back changed for this run only
void safety_forget_override(volatile LONG* v);
void safety_reset_health();                    // the player pressed Insert: bad-run counter back to 0
void safety_run_begin();                       // a headset session was requested: write gbvr_run.txt
void safety_run_note(const char* what);        // "exiting=1" etc. added to the marker
void safety_run_end();                         // clean exit: the marker is deleted
void safety_on_fault(const char* summary);     // fatal error seen: marker + gbvr_last_crash.txt
void engine_main_stall_check();                // 0.60: called every second by the heartbeat: the game's main thread has not ticked for a while -> where is it
void crumbs_init();                            // 0.86: black-box ring (gbvr_crumbs.bin, memory-mapped: survives any death of the process); the last run's ring is logged
void crumb(const char* tag, int arg);          // 0.86: remember a step (tag up to 27 chars) + a number; costs well under a microsecond
void safety_start_heartbeat();                 // flusher / stall watchdog thread
int  safety_fallback_picture(int toLevel, const char* why);   // saves a lower picture level for the next start (once per level)
void safety_health(LONG frame);                // one HEALTH line
#else
#define stage_r(x) ((void)0)
#define stage_g(x) ((void)0)
#endif

// 0.23 (proxy.cpp): the first frame was presented - the start-up safety marker can go.
void startup_confirmed();

// 0.25 (settings.cpp): tuning values kept in gbvr_settings.txt.
#if GBVR_HEADTRACK
extern volatile LONG g_guardKeepLevel, g_guardLoweredTo;   // 0.83 settings.cpp
void settings_load();
void settings_changed();           // any thread: a value was changed by a key
void settings_save_if_changed();   // render thread, now and then
#else
inline void settings_load() {}
inline void settings_changed() {}
inline void settings_save_if_changed() {}
#endif

// 0.26 (modes.cpp): sharper picture - the game draws at a higher resolution than the monitor.
#if GBVR_HEADTRACK
void modes_install(void* dxgiFactory);   // from the DXGI factory wrapper, before the game lists display modes
void modes_report();                     // render thread, with the periodic report
int  modes_desktop_size(unsigned* w, unsigned* h);   // 1.7.117
int  modes_active_level();               // level the game was actually given in this run (1 = unchanged)
extern int g_pictureOff;                 // gbvr_picture_off.txt present: the bigger picture is not used (proxy.cpp)
void startup_mark_picture();             // proxy.cpp: the start-up marker now says "bigger picture in use"
void startup_picture_retry();            // proxy.cpp: the player asked again (Insert): forget the off file
int  modes_installed();                  // 1 when the display-mode hook is in place
void mouse_install();                    // mouse.cpp: pointer position when picture and window sizes differ
void mouse_report();
// 0.45 flat view (flatview.cpp): outside the headset the picture is drawn into the swap chain in its own shape
int  flatview_present(void* swapChain, int inHeadset);   // render thread, right before the real Present; 1 = the corrected picture was drawn (inHeadset 1: the 2D screen is shown in the headset, the window gets the right shape)
// 1.2 monitor view (monitorview.cpp): while the headset view is on, the game window shows one steady, undistorted eye picture
int  monitorview_present(void* swapChain);   // render thread, right before the real Present, after stereo_before_present; 1 = the monitor picture was drawn
void monitorview_release();
void eyeaa_release();                                                         // 1.7.153 smooth edges on the headset pictures (eyeaa.cpp)
void eyeaa_apply(void* dev, void* ctx, void* eyeTex, int eye, int gammaSpace);
void* eyeaa_tex(int eye, void* plain);
void eyeaa_report(LONG frame);
void monitorview_report(LONG frame);
int  stereo_monitor_source(int wantEye, void** tex, float* pose34, int* eyeUsed, int* age, float* projection, int* spectator); // projection = actual tanH, tanV, eyeX metres
int  flatview_get_view(double* x, double* y, double* w, double* h);   // where the picture is inside the window (client pixels); 0 = not corrected
void flatview_release();
// 1.3 cursor ring on the 2D screen (flatcursor.cpp); menu_pointer (menu.cpp) = where the laser hits the screen now (picture coordinates 0..1, v from the top)
int  flatcursor_draw(void* device, void* context, void* texture, unsigned w, unsigned h, float u, float v, int sizePct, int pressed);
void flatcursor_release();
void flatcursor_report(long frame);
int  menu_pointer(float* u, float* v, int* down);
void flatview_report(LONG frame);
// 0.95 TV glow around the flat 2D screen (flatglow.cpp). Render thread, once per flat-screen frame, after the picture was copied into flatTex.
void flatglow_frame(void* device, void* context, void* flatTex, unsigned w, unsigned h, int dxgiFormat, const float* screenXf34, float screenWidthM, float aspect);
void flatglow_hide();      // the 3D picture is back
void flatglow_release();   // the device or the textures are going away
void flatglow_report(LONG frame);
#endif

// 0.27 (shot.cpp): diagnostic picture of what each eye is shown (F2).
#if GBVR_HEADTRACK
struct ID3D11Device; struct ID3D11DeviceContext; struct ID3D11Texture2D;
struct ShotSource {
  ID3D11Device* dev; ID3D11DeviceContext* ctx;
  ID3D11Texture2D* tex[2];     // the probe's eye textures (whole game frame each)
  float bounds[2][4];          // uMin, vMin, uMax, vMax of each eye inside its texture
  unsigned w, h; int format;   // texture size and DXGI format
  float eyeTanW, eyeTanH;      // one eye's view, width and height in tangent units
};
void shot_request();                      // key
void shot_on_pair(const ShotSource* s);   // render thread, after the eye pictures were submitted
void shot_release();                      // render thread: device released / headset view off
void shot_expire();                       // render thread, every Present: drop a request that found no 3D picture
int  shot_busy();                         // a three-snapshot sequence is running
#endif

// 0.23 (exit_guard.cpp): clean exit after an OpenVR session was used.
extern volatile LONG g_vrBusy;   // render thread is inside the probe's OpenVR section
extern volatile LONG g_vrStop;   // exit in progress: no further OpenVR calls
void exit_guard_arm();
// Marks the render thread's OpenVR section. ok() is false once the game is exiting.
struct VrSection {
  int allowed;
  VrSection() { InterlockedExchange(&g_vrBusy, 1); allowed = g_vrStop == 0; if (!allowed) InterlockedExchange(&g_vrBusy, 0); }
  ~VrSection() { if (allowed) InterlockedExchange(&g_vrBusy, 0); }
  int ok() const { return allowed; }
};

// Engine-side (engine_hooks.cpp)
int  engine_install_hooks();
void engine_periodic_report(LONG frame);
void engine_issue_report();
void engine_request_sample();
#if GBVR_HEADTRACK
int  body_hiding_available();   // 0.28: own-body hooks installed
int  body_shadow_hiding_available();  // 0.30: own-shadow hooks installed
int  head_aim_available();          // 0.32: aim hook installed
#endif
DWORD engine_last_prepare_tid();

// ---- 0.33 controllers (controllers.cpp, xinput_bridge.cpp) -----------------------
#if GBVR_HEADTRACK
struct ID3D11Device; struct ID3D11DeviceContext; struct ID3D11Texture2D;
// 0.34 (handmodel.cpp): hands and wand drawn into an eye picture, render thread.
void handmodel_draw(ID3D11Device* dev, ID3D11DeviceContext* ctx, ID3D11Texture2D* eyeTex, int eye, const float* headPose34,
                    float eyeX, float tanH, float tanV);
void handmodel_vignette(ID3D11Device* dev, ID3D11DeviceContext* ctx, ID3D11Texture2D* eyeTex, int eye, const float* bounds, float tanH, float tanV);   // 1.7.22: comfort vignette (render thread, after the bounds are known)
void vignette_pulse(int ms);   // 1.7.22: a full-strength vignette burst (the blink dash), any thread
void handmodel_release();
int  handmodel_available();
int  handmodel_cord_active();   // 0.73: the probe drew the physics cord within the last half second (the game's own hose is hidden meanwhile)
void handmodel_report(LONG frame);

// ---- 0.76 fight (damage.cpp): +% beam damage on every enemy class, the enemy list for the health bars, the slam meter --------------
void damage_install();                                        // patches the hurt slot of the enemy classes (needs the exact exe)
void damage_issue_report();                                    // 1.7.116: HEALTH30, the compact always-on health line (player logs)
void damage_report(LONG frame);                               // DMG / DMGSEEN / BARS / SLAM log lines
// game thread, once per eye frame: scans the enemies and publishes their bars (head-centre axes, metres)
void fight_publish(const float* view9, const float* headCenter3, double feetPerMetre, uintptr_t player, int scanActors);
// render thread: the newest bars (returns the count, 0 when none or stale); eyeless: positions are from the head centre
int  fight_hit_age_ms();                                      // 1.4: ms since a ghost last lost health (-1 = none in the last 5 s)
int  fight_ring_pick(float* pos3, float* frac, uintptr_t* actor);   // 1.5: the ghost the game's own health ring is put on (world feet, health 0..1); 1 = there is one (fresh within 250 ms)
int  engine_pke_aim(float dir[3], float grip[3]);                      // 1.7.3: where the PKE points (game world) and its controller point (game feet), 1 = fresh
int  fight_markers_read(void* out, int cap);                          // 1.7.3: out: fight::Marker[cap]; collectibles / PKE scan targets near you (headset axes, metres), 0 = none or older than 0.4 s
int  fight_bars_read(void* out, int cap, int64_t* qpc);      // out: fight::Bar[cap]
void fight_trap_carry(uintptr_t player, int held, const float* lpos, const float* lfwd = nullptr, const float* lup = nullptr);   // 0.79: the game's own trap goes into the left hand while it is taken
void fight_trap_carry_report();
int  controllers_trap_held();
int  controllers_alt_fire_active();                           // 1.7.226: the left trigger (alternate fire) was down in the last 0.7 s with a gun in hand
int  controllers_fire_hold_active();                          // 1.7.177: firing with gun_fire_fx=0: the upper body is held as it was (the game's firing animation does not reach the view)
int  fight_enemy_near(const float* w3, double padFt);            // 1.7: 1 = a living enemy (ghost) is at this world point, 0 = none (a table, a chair...), -1 = no recent enemy scan
int  fight_enemy_stats(long* asks, long* ghost, long* notGhost, long* unknown);   // 1.7 log
int  fight_slam_ready();                                      // 1 when the slam meter is full (the swing gesture is only worth it then)
void settings_profile_switch(int from, int to);   // 1.7.19: save the profile in use, load the other (3 profiles)
void settings_profile_report(LONG frame);
int  fight_lock_guard(uintptr_t player);                         // 1.7.2 lets go of a game lock that sits on a non-ghost (returns how many locks were cleared)
void slam_assist_request(long long qpc);
extern volatile LONG g_reportNow;   // 1.7.25 (render_hooks.cpp)                       // 1.7.24: the left-trigger slam sequence just began (controllers.cpp)
int  fight_actor_dead(uintptr_t actor);                          // 1.7.197 the game's death state of this character (read only)
int  engine_player_downed();                                      // 1.7.197 1 while the player is dying / dead (health about 0): the body is not drawn, the edges pulse red
int  fight_slam_active();                                        // 1.7.196 1 for 3.2 s after a left-trigger slam began
int  fight_wrangled();                                           // 1.7.2 1 when the game says a ghost is held by the capture stream, 0 = not, -1 = the field is not trusted yet
void fight_slam_note(int phase, double a, double b);             // 1.7.2 slam bookkeeping from the controller code (phase 1 = a slam sequence began)
int  engine_player_forced();                                  // 1.7.36: 1 while the game moves the character by force (cutscene walk)
int  engine_scene_arms(uintptr_t actor);                       // distant scripted player camera: arms-only view
int  engine_offhand_support();                               // fresh barrel hold confirmed by the render arm solver
int  fight_staypuft(uintptr_t player, uintptr_t* boss, uintptr_t* world);
int  fight_staypuft_focus(uintptr_t player, float* mouth, int* stage);
int  engine_boss_mouth(uintptr_t boss, float* mouth);
void stereo_comfort_transition();
void stereo_comfort_hold(int on);   // 1.7.182: black from now until stereo_comfort_hold(0) (2 s at most), then the usual fade up
void engine_comfort_recenter();
int engine_secondary_press(unsigned* ageMs, int* rtDown); long engine_secondary_late(); long engine_secondary_asks(int k, long* yes);   // 1.7.223 (the left trigger / Boson Dart trace)
int  engine_gun_placed(double maxAgeS);                         // 1.7.99: the game's gun was placed at the controller within maxAgeS seconds
int  engine_player_health(float* frac);                        // 1.7.37: the player's health 0..1 (1 = read, 0 = not plausible)
void engine_trap_launch_request();                            // 1.7.37: the trap was just thrown by hand: its first frames are moved to the hand
double engine_knock_strength();                               // 1.7.36: 0..1 while the knock-down comfort window is running
double engine_knock_time_sec();                               // 1.7.36: seconds since it began
int  engine_stream_recent(int ms);                           // 0.79: 1 while the game really fires the player's stream (no buzz where it refuses)
void fight_request_item(int item);                            // 0.77: the weapon wheel: the game readies this item (EInventoryItem 1..7) at the next eye frame
void fight_switch_help(int want);                               // 1.1: the game thread finishes a stuck gear switch (the game's own call) and queues `want` the way the Y button does
void fight_switch_note(int reason, int tries);                  // 1.1: log every check the game makes before a gear switch (reason 1 = wheel pressed Y, 2 = check failed, 3 = gave up)
int  engine_glove_mode(void);   // 0.83: the gloves-only view is active right now
int  engine_pke_mode(void);                                       // 0.81: 1 while the PKE meter is in the player's hands (and pke_body is on)
int  fight_items(int* state8, int* current);                  // 0.77: the player's inventory (state per item, item in hand or -1); 1 = fresh
int  fight_trap_state(uintptr_t player);
int  fight_trap_deploy_request(uintptr_t player, const float* handFt);   // 1.7.175: queue the game's own no-animation trap throw (game thread); 0 = not possible, use the game's button                      // 1.7.174
int  fight_trap_deploy_pending();   // 1.7.188: a throw is queued
void fight_trap_deploy_drop();      // 1.7.188: forget a queued throw (menu opened)
void fight_trap_deploy_run(uintptr_t player);   // 1.7.188: run it (start of the game simulation, render queue empty)
int  engine_trap_idle();                                      // 1.7.177: the trap is on the belt (state 1) or unknown: a hip grab may start
int  engine_trap_deploy_now();                                // 1.7.175: 1 = the trap is thrown by the game's own no-animation function (the X button must NOT also reach the game)
void engine_trap_button_launch();                             // 1.7.174: the game's own trap button: from the off hand, only when the trap is not out already
void fight_trap_watch();                                      // 0.83: log the trap state for 4 s after a plain X press
void fight_trap_thrown();
void fight_trap_launch(uintptr_t player, const float* handFt, const float* aimDir);   // 1.7.37: put the game's thrown trap at the hand (game feet) for its first frames                                     // 0.77: a trap was thrown by hand: the log follows it for 4 seconds
// 0.78 hosetex.cpp: the cord (hose) takes its colour from the game's own hose texture (found by walking the player's model parts; see hosetex.cpp)
void hosetex_game_step(uintptr_t player);                     // game thread, once per eye frame (throttled inside): finds the parts / textures, logs PARTS lines
void hosetex_render_step(ID3D11Device* dev, ID3D11DeviceContext* ctx);   // render thread: reads the found textures' average colour (a few times in total)
int  hosetex_color(float* rgb);                               // 1 = the colour comes from the game's texture (smoothed, 0..1 per channel); 0 = unknown, keep the default
void hosetex_report(LONG frame);                              // log lines
// the game's own hose end on the gun ("hose" attachment, asked for by the hose actor), head-centre axes, metres; 1 = fresh
int  fight_hose_end(float* p3);
void fight_hose_raw(const float* worldFt3, uintptr_t asker);  // engine_hooks: raw world position (feet) of the "hose" attachment the game just fetched
void fight_hose_posed(const float* gameWand16, const float* drawnWand16);   // engine_hooks: the gun is posed: carry the hose end over to the drawn gun
#include "padmath.h"
void controllers_poll();                                   // render thread, after the headset pose
void engine_controller_type(int* type, long* tries, long* ok);   // 1.7.86: the game's controller type (0 mouse+keyboard, 1 gamepad, -1 unknown), tries to switch it, tries that worked
struct ControllersFlow { long polls, published, noHand, padHit, padMiss; unsigned long long rawButtons; unsigned padButtons; int stick, validL, validR; };   // 1.7.85: what the controller layer saw since the last call (diagnosis of "buttons do nothing")
void controllers_flow_take(ControllersFlow* f);
int  controllers_pad_state(pad::State* out);               // game thread: the pad state the controllers make (0 = none)
void controllers_set_rumble(unsigned left, unsigned right);// game thread: vibration the game asked for
int  controllers_hand_aim(const float* level, float* out); // aim direction in game axes (0 = no controller)
struct HandsRaw { int64_t sampleQ; int holstered; int validL, validR; float poseL[12], poseR[12]; float trigL, trigR; int gripL, gripR; float gripAnaL, gripAnaR; int thumbTL, thumbTR, trigTL, trigTR;
                  int wandValid, wandTwo; float wandPose[12];
                  int wheelOpen, wheelSel, wheelPicked, wheelPickLocked, trapHeld; float stickX, stickY;
                  float wheelOpenT, wheelFlash, wheelCurX, wheelCurY, wheelHov[10], wheelPose[12]; };   // 0.78: wheelOpen = the wheel is drawn (open or closing), wheelPose = where it stands (tracking space, z toward you), hover amounts, cursor; 0.77: left hand holds the trap, right stick   // 0.51: the wand's (weighted) pose, tracking space; wandTwo: held in two hands (no hand pitch)
int  controllers_raw(HandsRaw* out);                       // 0.34: latest tracked hands (raw OpenVR poses), 1 if any
int  controllers_pad_peek(pad::State* out);              // 1.7.92 game thread: like controllers_pad_state but does not change the INPUTFLOW counters
int  controllers_active();
int  controllers_pad_grace(pad::State* out);
int  engine_gun_muzzle(float* headEngineM, long* sampleNo = nullptr);   // 1.7.167: the drawn gun's muzzle in head space (engine axes, metres), 0 = none fresh   // 1.7.166: a short tracking loss: a connected, idle pad (0 = none / too long)
int  engine_gun_frame(float* r9, float* t3, double* ageMs);   // 1.7.211: the drawn gun's tube frame from one game sample (rotation columns right/up/back, head-space origin, metres)
int  controllers_left_applied();                                // 1.7.181: left-handed as applied by the controller swap (not the menu value, which changes a frame earlier)
int  engine_pke_item();                                    // 0.94 (engine_hooks.cpp): 1 = the PKE is the item in hand (fresh inventory read)
int  follow_head_yaw(double* eRad);    // 1.7.8 (engine_hooks.cpp): 1 = fresh; *eRad = the head's yaw from the game's heading (rad, + = right); the left stick is turned by it (walk where you look)
int  follow_gave_up();                  // 1.7.6 (engine_hooks.cpp): 1 = the game did not answer two pushes in a row; controllers.cpp lets the real right stick turn the game
int  follow_smooth_request(double deg);   // 1.7.81 (engine_hooks.cpp): smooth-turn degrees (+ right) for this poll, from the controllers
int  follow_turn_own();                    // 1.7.81: 1 = the mod makes the right-stick turn itself (snap, or smooth with turn_smooth_own); the game's own stick turn is off
int  follow_snap_request(int steps);     // 1.5 (engine_hooks.cpp): snap-turn steps (+ right, - left) from the controllers
float follow_push_get();                  // 1.5 (engine_hooks.cpp): the push the probe adds to the right stick axis (-1..1; 0 = none)
int  controllers_sprint_want();   // 1.7.6 (controllers.cpp): 1 while sprint is switched on and the left stick is pushed (fresh within 250 ms)
extern long g_twoFlips, g_slimeLtEdges;   // 1.7.74
int  controllers_move_mag();   // 1.7.5 (controllers.cpp): the left stick push x1000 (0..1000)
void controllers_turn_info(int* userMagX1000, int* blocked);   // 1.5 (controllers.cpp): your own right-stick push (x1000), and 1 while turning makes no sense (menu, wheel, D layer, no level)
void engine_goggle_apply();   // 1.4: hides / shows the game's green PKE goggle frame (render thread, between two overlay draws)
void engine_float_mark(const char* why);   // 1.6: one log line with the weapon-in-hand numbers of this moment (F2 picture key)
int  fight_pke_sources(float (*out)[3], int cap, int64_t* qpc);   // 0.94 (damage.cpp): world positions (feet) of the scannable PKE sources, newest scan
int  engine_pke_own();                                     // 0.93 (engine_hooks.cpp): 1 = the PKE is the item in hand and the probe draws its own
int  controllers_holstered();
int  controllers_trap_anim_active();   // 1.7.173: the game's trap throw was asked for within the last 1.5 s (its animation is kept off the upper body)
void engine_holds_reset(const char* why);   // 1.7.173: the stored gun / PKE holds, the hand follow and the draw window start again (as after a model change)
int  controllers_reload_active(); // reload/vent input plus its short animation tail; rendering only
void menu_pump();                                          // 0.42 (menu.cpp): flat-screen pointer -> game mouse
void menu_release();
void menu_report();
void input_flow_report(const char* why);   // 1.7.85: INPUTFLOW line: does the pad reach the game, does the laser reach the menu (menu.cpp)
int  stereo_in_flat_mode();                                // 0.42 (stereo.cpp)
void probe_mark(const char* who);                             // 0.48 (engine_hooks.cpp): "something happened now" marker + snapshot
void bindings_pad(unsigned xbuttons, int lt, int rt);        // 0.46 (engine_hooks.cpp): pad mask -> game action states
void bindings_sample(int lt, int rt);                    // 0.39 (engine_hooks.cpp)
int  bindings_capture_down();                             // 1.7.57: current Capture / wrangle button (normal right-stick click -> game LB)
void controllers_report(LONG frame);
// 0.51 haptics.cpp: controller motors. Sources: see hapticmath.h (hap::Src).
void haptics_start();
void haptics_add(int hand, int src, float level, int ms);   // any thread; hand 0 left / 1 right; level 0..1; renewed by calling again
void haptics_stop_source(int hand, int src);
void haptics_test(int kind);                                // 0 hello, 1 strength ladder
void haptics_report(LONG frame);
// 0.57 arms.cpp / armcore.h: the player's arm bones follow the real hands (the model instance's bone matrices are overwritten after the
// animation, before the render pass draws the body). Targets (struct ArmTargets, armcore.h) are in game world axes (feet), published by engine_hooks.cpp.
void arms_init();                                                       // checks the game functions it calls
void videoguard_arm();     // 0.85
void videoguard_report();
void exit_spy_arm();        // 0.87
int  arms_pke_wand(float out[16]);                                          // 0.85
int  arms_apply(uintptr_t actor, const float* W2, const ArmTargets* t); // 1 = at least one arm moved
int  arms_hose_follow(uintptr_t actor, const float* hoseGame, const float* hoseDraw, const float* gunGame, const float* gunDraw);   // 1.7.148: the game's hose bent to the drawn gun; 1 = done
int  arms_hose_hold(int stale);   // 1.7.182: a refused frame shows the last bent hose pose for up to 0.15 s (no jump to the game's pose); 1 = written
long arms_collapse_stat(int which);   // 1.7.185: 0 squash passes, 1 bones squashed in the last pass, 2 put back, 3 passes with no arms found, 4 bad point
long arms_hose_stat(int which);   // 1.7.148: 0 calls, 1 done, 2 bad layout, 3 chain not at the gun, 4 maths refused
namespace bpack { struct Motion; }
int  arms_torso_motion(bpack::Motion* out);                               // 0.68: what the torso pass did (drop + lean) so the pack can follow; 1 = fresh
int   arms_revalidations();                                              // 1.7.100: counter that goes up when the player's model / skeleton changed (new outfit or rig as the story goes on)
float arms_model_eye_ft();                                               // 0.69: the unscaled model's eye height (tallest histogram peak), 0 = not known yet
void aim_ring_seen(const void* ring);                                  // 0.68 (engine_hooks.cpp): the game's health ring object, from the ring draw hook in hud.cpp
int  arms_hold_numbers(float wrist[3], float miss[3], float animOff[3]);   // 1.7.2: right wrist target, how far it fell short, the game's hand-minus-weapon offset (game feet), 1 = fresh
void arms_finger_text(char* out, int cap);                            // 1.7.1: finger numbers of both hands as text (animation -> drawn), for the F2 line
int  arms_game_hand_pair(uintptr_t actor, float gameHand[16], float finalHand[16]); // 1.7.58: exact full game-hand -> VR-hand matrices, 1 = fresh
void arms_frz_stats(long* captured, long* applied, int* lastDevX10, int* maxDevX10, int* meanDevX10);   // 1.7.76
void arms_frz_reset();
void arms_fail_snapshot(long out[12]);   // 1.7.77
int  arms_mirror_info(long* right, long* left, long* bad);                // 1.7.172: left-handed arm swap passes (right arm, left arm, shoulders not measurable)
long arms_pke_hide_passes();                                          // 1.7.64: arm passes that squashed the belt copy of the PKE
int  arms_grip_shift(float out[3]);                                  // legacy fallback only; 1.7.58 exact hand transform supersedes this
long arms_hand_cleaned(int s);                                            // 1.7.70: how many hand bone matrices were made clean (0 right, 1 left)
int  arms_right_finger_base_x10(int f);                                // 1.7.98: the total bend (degrees x10) the game's animation had in the right hand's finger f (0 thumb .. 4 pinkie) in the last pass; 0 when unknown
int  arms_left_finger_base_x10(int f);   // 1.7.103: the same for the left hand
int  arms_left_finger_kept();             // 1.7.103: passes where the left fingers fully kept the game's pose
int  arms_finger_final_x10(int s, int f);   // 1.7.104: the total bend (degrees x10) finger f of hand s (0 right, 1 left; 0 thumb .. 4 pinkie) was given last pass
int  arms_finger_tg_x10(int s, int f);      // 1.7.104: the curl asked for (0..1000), -1000 = left to the game
long arms_finger_skips(int s, int f);       // 1.7.104: passes where that finger's pass stopped early
long arms_finger_empty_passes();            // 1.7.104: right-hand passes with the free-finger rules
long arms_wrap_passes(); int arms_wrap_tilt_x10(); int arms_wrap_orbit_x10();   // 1.7.109
long arms_bend_n(); long arms_bend_clamped(); int arms_bend_mean_x10(); int arms_bend_max_x10(); long arms_bend_fallback(); int arms_bend_last_x10();   // 1.7.215
int arms_orbit_shift_x10(); int arms_orbit_bend0_x10(); int arms_orbit_bend_x10(); long arms_orbit_n(); long arms_orbit_moved();   // 1.7.220
long arms_grab_passes();   // 1.7.105: arm-solver passes with the fore grab holding the left hand on the gun (running total)
int  arms_finger_axis_fixed(int side);   // 1.7.111: finger passes whose skewed measured bend axis was replaced by the knuckle line (0 right, 1 left)
int  arms_align_info(long* passes, long* fails, double out[9]);   // 1.7.104: PKE alignment of the last pass: lean before / after, pitch, swing (deg), lateral before / after, forward, up (feet)
int  arms_right_stretch_x100();                                           // 1.7.67: how much the right arm was lengthened in the last arm pass (100 = not at all)
int  arms_gun_miss(float out[3]);                                       // 0.66: how far the right wrist fell short of the controller (game world feet), 1 = fresh
void arms_verify(uintptr_t actor);                                      // later in the same render pass: are the new bone matrices still there?
namespace rig { struct Snap; }
int  arms_rig_read(rig::Snap* out);                                     // 0.74: the avatar's joints relative to the camera eye (rig view); 1 = have joints
void arms_rig_part(int which, const float* W2, const double* view9, const double* eye3);   // 0.74: the pack (1) / hose (2) matrix of this render
void arms_report(LONG frame);
struct ArmsWallSnap { int calls, moved, badSpace, badLen, clamped, nonFinite, gripNoPose, torsoFail, missOver, shiftCapped, verifyLost, forcedCalls, eyeErrMaxX100; };
void arms_wall_snap(ArmsWallSnap* o);                                    // 0.75: a few arm counters, to see what changed while the game's camera was pulled in by a wall
void sysinfo_log();       // 0.51 sysinfo.cpp: machine / graphics / process facts, once at start
void sysinfo_modules();   // 0.51: modules loaded in the game process, once a while after start
void sysinfo_env(int late);  // 1.7.87 sysinfo.cpp: ENVCHECK / ENVHINT lines (Steam launch, Steam Input virtual pad, overlay, window / Windows scaling, Windows graphics-card setting); late=0 at start, 1 a while in
void modscan_mark_note(int markNumber);  // 0.98 modscan.cpp: the did-the-mod-load counters at a marked moment (MODLOOK)
void modscan_start();     // 0.96 modscan.cpp: background thread; MODSCAN log lines about ghost.exe, the game folder (other mods) and loaded modules
void sysinfo_file_version(const char* path, char* out, int n);   // 0.67 sysinfo.cpp: "a.b.c.d" of a file, or "?"
void body_calibrate_apply(double eyeM, double leftHandM, double rightHandM);   // 0.52 engine_hooks.cpp: set the player height from the real eye height
int settings_lookup(const char* name, volatile LONG** v, LONG* lo, LONG* hi);   // 0.53 settings.cpp
void vrmenu_tick(LONG frame);          // 0.53 vrmenu.cpp: render thread, every frame of the headset view
int vrmenu_quiet();                    // 0.56 1 while the in-VR menu is open or was closed less than 1.5 s ago (SteamVR's laser mode raises focus events)
void vrmenu_set_cheap(int on);         // 0.58 speed guard: redraw the menu picture at most every 300 ms
int vrmenu_is_open();
const uint8_t* vrmenu_picture(int* w, int* h, long* serial);   // 1.7.90 vrmenu.cpp: the open settings pages' picture (1280x800 RGBA) for the PC window, else null
int vrmenu_pointer(int* x, int* y);   // 1.7.145 vrmenu.cpp: the pointer on the pages (menu pixels); 0 = none
int monitorview_menu_present(void* swapChain, int inset);                  // 1.7.90 monitorview.cpp: draws it into the game window (returns 1 when drawn)                  // 1 while the in-VR menu is open (the game gets no controller input then)
void vrmenu_toggle(const char* why);
void vrmenu_report(LONG frame);
long vrmenu_flow(char* out, int cap);                               // 1.7.93 MENUFLOW text for the settings pages; returns how much they were used (0 = never)
// 1.7.28 the hand-held game menu (heldmenu.cpp; the settings pages and the button picture come from vrmenu.cpp)
int  held_menu_active();                                            // 1 while the game's pause menu is up and held in the hand
void held_menu_tick(LONG frame);                                    // render thread, every headset frame
void held_menu_frame(double aspect);                                // 1.7.29: every flat frame: places the panel on the left hand and runs the right hand's pointer
int  held_menu_place(float* xf12, double* widthM);                  // the flat game screen in the hand (1 = use this placement now)
int  held_vr_place(float* xf12, double* widthM);                    // the settings pages in the hand
int  held_menu_mover_owns(int kind);                                 // 1.7.31: 1 = the follow loop moves this overlay (0 game panel, 1 settings pages): leave its placement alone
void held_menu_note_flat_cost(double ms);                            // 1.7.31: what one whole flat frame cost while the hand-held menu was up
void held_menu_toggle(const char* why);                             // gesture / F12: open the game's pause menu, or close it
int  held_menu_pointer(double u, double v, int type, int button);   // a laser event on the game's picture; 1 = taken by the VR SETTINGS button
int  menu_inject(double u, double v, int type, int button);   // 1.7.29: the hand-held menu's own pointer talks to the game (type 1 move, 2 down, 3 up, 5 wheel); 1 = delivered
void menu_pointer_clear();                                      // 1.7.29: the own pointer left the panel
void held_banner_paint(void* ctx, void* tex, unsigned w, unsigned h, int fmt);
void held_menu_report(long frame);
long held_menu_flow(char* out, int cap);                            // 1.7.93 MENUFLOW text for the hand-held menu; returns how much it was used (0 = never)
int  vrmenu_open_live();                                            // 1.7.84 vrmenu.cpp: the pages in the hand over the live, frozen world (no game pause menu)
int  vrmenu_is_live();
void held_menu_live_end(const char* why);                           // 1.7.84 heldmenu.cpp: the live pages closed
void held_menu_live_to_game(const char* why);                       // 1.7.84 heldmenu.cpp: close the live pages and open the game's own pause menu in the hand
int  vrmenu_open_in_hand();                                         // vrmenu.cpp: the settings pages open in the hand
void vrmenu_close_in_hand(const char* why);
const uint8_t* vrmenu_banner(int hover, int bw, int bh, int rgba);  // the VR SETTINGS button picture (bw x bh, 4 bytes per pixel, RGBA or BGRA order)
void audio_boot();                     // 0.69 audio.cpp: once at start; gives back game sound if the last run ended while muted
void audio_menu(int open);             // 0.69: the menu opened (1) / closed (0): song on/off, game sound muted/given back
void audio_probe();            // 1.7.88 audio.cpp: log the PC's sound setup once (AUDIO probe / AUDIO session lines)
void audio_shutdown();                 // 0.69: at exit: game sound is given back at once
void audio_report(LONG frame);         // 0.69: AUDIO line for the log
void autopause_manual_leave();         // 0.53 engine_hooks.cpp: act as if the player left SteamVR now (pauses the game if it runs)
int engine_pke_source_scanned(uintptr_t actor);   // 1.7.13: 1 = this PKE source is already scanned (or not scannable), 0 = not yet, -1 = unknown
int engine_pke_target_state(uintptr_t actor, int* scannable, int* scanned);   // 1.7.29: the game's own answers for a PKE target; 1 = both were readable
const char* engine_pke_class_name(uintptr_t actor);   // 1.7.29: "PKE source" / "collectible" / "Slimer" / "other" (by the actor's class)
void game_menu_request();              // 1.7.11: open the game's own pause menu (objectives) and keep it open for 3 minutes
void game_menu_request_force();   // 1.7.84 engine_hooks.cpp: the same, but Start is tapped without asking whether the game "runs" (it was frozen by the live pages)
void autopause_tap();                  // press and release Start once
void engine_exit_context(char* out, int n);   // 1.7.9: a line about the game state for the exit log (out >= 300 bytes)
void stereo_ring_probe(int n);          // 0.54 stereo.cpp: logs the Direct3D state while the health ring is drawn
void engine_freeze_pulse(int on);       // 0.54 engine_hooks.cpp: keep the world frozen (App::Simulate left out) for the next 300 ms; 0 = end it now
int engine_freeze_active();
int game_running_now();                // 1 if the game simulates normally (not paused / in a menu)
int game_paused_flag();                 // 1.7.28: 1 if the game's own paused flag is set (pause menu up)
int game_menu_requested();              // 1.7.28: 1 while the player's request for the pause menu is in force (so the auto-close helper stays away)
void game_menu_keep();                  // 1.7.28: keeps that request alive while the hand-held menu is up
void game_menu_close(const char* why);  // 1.7.28: Start once and the request ends
void game_menu_release();               // 1.7.29: the request ends without pressing anything (the game closed its menu itself)
void body_last_calibration(int* cm, int* pct, int* count);
unsigned autopause_buttons();   // 0.52 engine_hooks.cpp: XInput button bits (Start) to add while the auto-pause presses Start, else 0
void autopause_report(LONG frame);
void xinput_bridge_install();                              // engine_install_hooks
int  xinput_bridge_available();
void xinput_bridge_report(LONG frame);
void xinput_bridge_counts(long* getState, long* faked, long* merged, int* hook);   // 1.7.85
void xinput_bridge_guard(int inPlay);                      // 1.7.91: puts our import functions back in front if another program replaced them (render thread, every few seconds)
void xinput_bridge_more(long* caps, long* repaired);       // 1.7.91
void engine_pad_slots(long* state4, unsigned long long* di4);   // 1.7.91 engine_hooks.cpp: the game's own state of its four pad slots (0 none, 2 XInput pad, 12 DirectInput pad) and DirectInput device pointers
void engine_pad_xflags(long* flag4);                         // 1.7.92 engine_hooks.cpp: per slot 1 = the game reads that slot through XInput
void engine_di_takeover_arm();                               // 1.7.92 engine_hooks.cpp: asks the game's main thread to close the game's DirectInput pads (it does so at the start of its next simulation)
void engine_di_takeover_stats(long* runs, long* closed);     // 1.7.92
void xinput_bridge_di_check(int padLive);                    // 1.7.92 xinput_bridge.cpp: render thread, every few seconds: arms the takeover when the game reads a DirectInput pad instead of the VR controllers
void xinput_bridge_di_stats(long* tries);                    // 1.7.92
#endif

// ---- 0.21 alternate-eye stereo (stereo.cpp) ----------------------------------
// One eye is rendered per game frame (left, right, left, ...). The camera
// thread moves the eye and widens the field of view through the engine's own
// setters; the render thread copies each finished frame into that eye's
// texture and hands both textures to the SteamVR compositor.
struct StereoParams {      // written by the render thread, read by the camera thread
  int valid;
  float left[2], right[2], top[2], bottom[2];  // OpenVR raw projection per eye (see vr_pose.h)
  float eyeX[2];           // eye offset from the head centre along its right axis, metres (left eye negative)
  float needTanH, needTanV;// half-FOV tangents that cover both eyes
};
struct StereoFrame {       // written by the camera thread after each stereo prepare
  uint32_t seq;            // filled in by stereo_publish_frame
  int eye;                 // 0 = left, 1 = right
  float pose34[12];        // headset pose this frame was rendered for
  float tanH, tanV;        // half-FOV tangents the engine actually used (read back)
  int spec;                // 1.7.38: 1 = this frame is the chest-camera picture for the PC window (not an eye picture: never shown in the headset)
};
int  stereo_get_params(StereoParams* out);          // camera thread; returns valid
int  stereo_frame_pending();                        // camera thread: 1 if the last published frame was not presented yet
void stereo_publish_frame(const StereoFrame* f);    // camera thread
int  stereo_drawing_eye(int* eye, float* tanH, float* tanV, float* eyeXm, float* limW, float* limH);  // 0.29: render job: the eye being drawn
void hud_install();                                 // 0.29 hud.cpp
void hud_report();
void ring_assist_report();   // 1.5 (hud.cpp)
void ring_fallback_counts(long* og, long* fb, long* none);   // 1.7.106 (handmodel.cpp): frames the ring owner was shown by the game's own ring / by the probe's fallback ring / frames with no owner (running totals)
long long hud_og_ring_age_ms();   // 1.7.106 (hud.cpp): ms since the game's own health ring was last drawn on the screen (placed in the eye picture, its spot inside it); -1 = never
int  hud_available();
void stereo_tick_session();                         // render thread: start/stop the headset session
int  stereo_before_present(void* swapChain, UINT flags);  // 1 = present without waiting for desktop vsync
void stereo_after_present();
void stereo_report(LONG frame);
void stereo_perf_light();   // 1.7.102: compact PERF line for the diagnostics-off downloads

#if GBVR_HEADTRACK
#include "vr_pose.h"
#endif
