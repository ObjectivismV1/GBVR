// 0.78 gear maths: the weapon wheel (Half-Life: Alyx style, round discs, hand + stick), the ghost-trap grab-and-throw, the tap / hold button
// splitter, the any-direction slam sweep and a tiny letter font.
// Pure functions (no game memory, no Direct3D) so tests/test_gear.cpp can check them.
#pragma once
#include <stdint.h>
#include "vmath.h"
#include "fightmath.h"

namespace gear {

// ---- the game's inventory items (EInventoryItem, from the game's own script enum names) ----------------------------------------------
// state per item in the player object (table at +0xCFE0, 0x18 bytes each): 0 = not owned, 1 = owned, 2 = in hand, 3 = switched off
enum { kItemNothing = 0, kItemProton = 1, kItemShotgun = 2, kItemRailgun = 3, kItemTrap = 4, kItemMeter = 5, kItemLight = 6, kItemSlime = 7, kItemCount = 8 };
enum { kKindItem = 0, kKindDpad = 1, kKindNotch = 2 };   // item: the game's own "ready this item"; dpad: a pad D-pad press; notch: one mouse-wheel notch (next / previous weapon)
// label = first name line (also used in the log), code = 3-4 letters inside the disc, n2 = second name line
struct Slot { const char* label; int kind; int arg; const char* code; const char* n2; };
enum { kSlots = 5 };   // 0.83: Light, Next and Previous were taken off the wheel; 0.84: the Trap too (the trap is on your left hip); 1.7: BEAM SWITCH too (it did nothing)
// clockwise from the top
static const Slot kWheel[kSlots] = {
  {"PROTON", kKindItem, kItemProton, "PRO", "STREAM"},
  {"MESON", kKindItem, kItemShotgun, "MES", "COLLIDER"}, {"BOSON", kKindItem, kItemRailgun, "BOS", "DART"},
  {"SLIME", kKindItem, kItemSlime, "SLM", "BLOWER"},     {"PKE", kKindItem, kItemMeter, "PKE", "METER"}};

// 0.78: what a slot is right now. kLocked = the campaign has not given you this yet (shown as "?"), kOff = you own it but it is switched off.
enum { kOk = 0, kLocked = 1, kOff = 2 };
inline int item_usable(int state) { return state == 1 || state == 2; }
inline int slot_status(int slot, const int* st /* kItemCount states or null */) {
  if (slot < 0 || slot >= kSlots) return kLocked;
  if (kWheel[slot].kind != kKindItem || !st) return kOk;
  const int a = kWheel[slot].arg;
  if (a < 0 || a >= kItemCount) return kLocked;
  const int s = st[a];
  if (s == 1 || s == 2) return kOk;
  if (s == 0) return kLocked;
  return kOff;
}
inline int slot_usable(int slot, const int* st) { return slot_status(slot, st) == kOk; }
inline unsigned unusable_mask(const int* st) { unsigned m = 0; for (int i = 0; i < kSlots; ++i) if (slot_status(i, st) != kOk) m |= 1u << i; return m; }
inline unsigned locked_mask(const int* st) { unsigned m = 0; for (int i = 0; i < kSlots; ++i) if (slot_status(i, st) == kLocked) m |= 1u << i; return m; }

// which slot a stick direction points at (-1 = too small). Slot 0 is at the top, clockwise.
inline int slot_from_stick(double sx, double sy, int n, double minMag) {
  const double mag = vm::dsqrt(sx * sx + sy * sy);
  if (!(mag >= minMag) || n < 2) return -1;
  double a = vm::datan2(sx, sy);                // 0 = up, clockwise positive
  if (a < 0) a += 2.0 * vm::kPi;
  const double w = 2.0 * vm::kPi / (double)n;
  int i = (int)((a + 0.5 * w) / w);
  if (i >= n) i -= n;
  return i;
}

// ---- one button, two jobs (0.78) -----------------------------------------------------------------------------------------------------
// A quick tap stays the game's own button (it is replayed as a press when the button comes up); holding it past holdMs claims it for the extra
// feature (the weapon wheel on the right A button). While the button is undecided or claimed the game does not see it. If the feature is not
// allowed at the moment of the press (menu open, not in a level, feature off) the button simply goes through live, as it always did.
struct TapHold {
  int state;               // 0 idle, 1 undecided (hidden from the game), 2 claimed, 3 passing live
  double heldMs, replayMs; // time held so far; time left of a replayed tap
  int prev;
  long taps, claims;
  void reset() { state = 0; heldMs = 0; replayMs = 0; prev = 0; }
  // events: 0 nothing, 1 claimed (hold reached), 2 tap (replay started), 3 claimed button let go
  int update(int pressed, int canClaim, double dtMs, double holdMs, double minTapMs, int* toGame) {
    if (dtMs < 0 || dtMs > 250) dtMs = 250;
    int ev = 0;
    const int edge = pressed && !prev;
    prev = pressed;
    if (edge) { state = canClaim ? 1 : 3; heldMs = 0; }
    if (!pressed) {
      if (state == 1) { replayMs = heldMs > minTapMs ? heldMs : minTapMs; ev = 2; ++taps; }
      else if (state == 2) ev = 3;
      state = 0; heldMs = 0;
    } else {
      if (state == 1) {
        if (!canClaim) state = 3;                       // the feature was switched off while undecided: the game gets the button now
        else { heldMs += dtMs; if (heldMs >= holdMs) { state = 2; ev = 1; ++claims; } }
      } else if (state == 0) state = canClaim ? 1 : 3;  // pressed before we looked (first poll)
    }
    const int live = state == 3 || replayMs > 0;
    if (replayMs > 0) replayMs -= dtMs;
    if (toGame) *toGame = live;
    return ev;
  }
};

// ---- the weapon wheel (0.78: Half-Life: Alyx style) ------------------------------------------------------------------------------------
// Hold the right A button (claimed after 0.2 s, see TapHold): the wheel opens in front of you. Point with the right stick OR move your right hand
// toward a disc (the stick wins while it is pushed), the disc grows and lights up, a tick tells your hand it changed. Let go: that item is readied.
// Let go with nothing lit: nothing changes. Discs of things the campaign has not given you yet show a "?" and refuse.
static const double kHandOn = 0.050, kHandOff = 0.035, kHandFull = 0.12;   // hand offset (metres) that lights a disc / lets it go / fills the cursor
struct Wheel {
  int open, sel, src, picked, pickLocked;   // src: 0 none, 1 stick, 2 hand
  double openT, flash, curX, curY, hov[kSlots];
  long opens, chosen, cancelled, lockedPicks, taps;
  void reset() {
    open = 0; sel = -1; src = 0; picked = -1; pickLocked = 0; openT = 0; flash = 0; curX = curY = 0;
    for (int i = 0; i < kSlots; ++i) hov[i] = 0;
  }
  int active() const { return open || openT > 0.002; }
  // held: the wheel button is claimed. sx,sy: right stick. hx,hy: right hand offset from where the wheel opened, in the wheel's own plane (metres, x right, y up).
  // unusable: bit per slot that refuses (locked / off). Returns 0 nothing, 1 opened, 2 chosen (*slot), 3 closed without a choice, 4 a locked / unavailable disc was picked (*slot).
  int update(int held, double sx, double sy, double hx, double hy, double dtMs, int n, unsigned unusable, int* slot, int* hoverChanged) {
    if (dtMs < 0 || dtMs > 250) dtMs = 250;
    const double dt = dtMs * 0.001;
    int ev = 0;
    if (hoverChanged) *hoverChanged = 0;
    double tx = 0, ty = 0;
    if (held) {
      if (!open) { open = 1; sel = -1; src = 0; picked = -1; pickLocked = 0; flash = 0; ++opens; ev = 1; }
      const double sm = vm::dsqrt(sx * sx + sy * sy), hm = vm::dsqrt(hx * hx + hy * hy);
      int ns = sel, nsrc = src;
      if (sm >= 0.55) { ns = slot_from_stick(sx, sy, n, 0.55); nsrc = 1; }
      else if (src == 1 && sm >= 0.30) { /* the stick keeps its choice until it is nearly centred */ }
      else if (hm >= kHandOn) { ns = slot_from_stick(hx, hy, n, kHandOn); nsrc = 2; }
      else if (src == 2 && hm >= kHandOff) { /* the hand keeps its choice until it is back near the middle */ }
      else { ns = -1; nsrc = 0; }
      if (ns != sel && hoverChanged) *hoverChanged = 1;
      sel = ns; src = nsrc;
      if (src == 1) { const double k = sm > 1.0 ? 1.0 / sm : 1.0; tx = sx * k; ty = sy * k; }
      else if (src == 2) { double k = hm / kHandFull; if (k > 1.0) k = 1.0; tx = hx / hm * k; ty = hy / hm * k; }
    } else if (open) {
      if (sel >= 0) {
        picked = sel; pickLocked = (int)((unusable >> sel) & 1u); flash = 1.0;
        if (slot) *slot = sel;
        if (pickLocked) { ++lockedPicks; ev = 4; } else { ++chosen; ev = 2; }
      } else { ++cancelled; ev = 3; picked = -1; }
      open = 0; src = 0;
      if (picked < 0) sel = -1;
    }
    // animation: the wheel opens in 0.16 s and closes in 0.14 s; the lit disc eases in and out
    if (open) { openT += dt / 0.16; if (openT > 1.0) openT = 1.0; }
    else { openT -= dt / 0.14; if (openT < 0.0) openT = 0.0; }
    if (openT <= 0.0 && !open) { picked = -1; sel = -1; pickLocked = 0; flash = 0; src = 0; }
    flash -= dt / 0.35; if (flash < 0.0) flash = 0.0;
    const double ah = dt / (dt + 0.040), ac = dt / (dt + 0.035);
    for (int i = 0; i < kSlots; ++i) {
      const double t = (i == sel && (open || i == picked)) ? 1.0 : 0.0;
      hov[i] += (t - hov[i]) * ah;
    }
    curX += (tx - curX) * ac; curY += (ty - curY) * ac;
    return ev;
  }
};

// Where the wheel stands. head34 / hand: tracking space (OpenVR 3x4 head pose, hand position). The wheel's centre is put in front of you where the hand is,
// pushed into a comfortable box (never behind, never out of sight); its plane faces your head, upright. out34 is a device-style pose: x right, y up, z toward you.
// Returns 0 if the head pose is unusable.
inline int wheel_anchor(const float* head34, const double* hand, float* out34) {
  double fx = -(double)head34[2], fz = -(double)head34[10];
  double fl = vm::dsqrt(fx * fx + fz * fz);
  if (!(fl > 1e-3)) return 0;
  fx /= fl; fz /= fl;
  const double rx = -fz, rz = fx;
  const double d[3] = {hand[0] - head34[3], hand[1] - head34[7], hand[2] - head34[11]};
  double fwd = d[0] * fx + d[2] * fz, side = d[0] * rx + d[2] * rz, up = d[1];
  if (fwd < 0.42) fwd = 0.42; if (fwd > 0.70) fwd = 0.70;
  if (side < -0.30) side = -0.30; if (side > 0.30) side = 0.30;
  if (up < -0.28) up = -0.28; if (up > 0.10) up = 0.10;
  const double c[3] = {(double)head34[3] + fx * fwd + rx * side, (double)head34[7] + up, (double)head34[11] + fz * fwd + rz * side};
  double z[3] = {(double)head34[3] - c[0], (double)head34[7] - c[1], (double)head34[11] - c[2]};
  double zl = vm::dsqrt(z[0] * z[0] + z[1] * z[1] + z[2] * z[2]);
  if (!(zl > 1e-3)) return 0;
  for (int i = 0; i < 3; ++i) z[i] /= zl;
  double x[3] = {z[2], 0.0, -z[0]};                      // up x z, up = (0,1,0)
  double xl = vm::dsqrt(x[0] * x[0] + x[2] * x[2]);
  if (!(xl > 1e-6)) return 0;
  x[0] /= xl; x[2] /= xl;
  const double y[3] = {z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0]};   // z x x
  for (int r = 0; r < 3; ++r) { out34[r * 4 + 0] = (float)x[r]; out34[r * 4 + 1] = (float)y[r]; out34[r * 4 + 2] = (float)z[r]; out34[r * 4 + 3] = (float)c[r]; }
  return 1;
}
// the hand's movement since the wheel opened, in the wheel's plane (x right, y up as the player sees it), metres
inline void wheel_hand_offset(const float* pose34, const double* origin, const double* hand, double* hx, double* hy) {
  const double d[3] = {hand[0] - origin[0], hand[1] - origin[1], hand[2] - origin[2]};
  *hx = d[0] * pose34[0] + d[1] * pose34[4] + d[2] * pose34[8];
  *hy = d[0] * pose34[1] + d[1] * pose34[5] + d[2] * pose34[9];
}

// ---- the ghost trap on the left hip --------------------------------------------------------------------------------------------------
// 0.78: press the left X button with the left hand at the hip: the trap is in your hand (no grip). Swing the hand away fast and let go, or keep
// holding: the trap is thrown. Let go near the hip without a throw: the trap goes back; if that was a quick tap (under 0.3 s, hand still) the caller
// replays X so the game's own "deploy trap" still works from the hip.
struct Trap {
  int held, armed, have, tapLike; double last[3], v[3], cool, heldMs, peak; int prevBtn;
  double armDist, coolS;   // 1.7.37: how far the hand must leave the hip before a throw counts, and the pause after a throw (the controller sets looser values with trap_free)
  long grabs, throws, putbacks;
  // 1.7.19: the last 0.2 s of hand velocity. A throw goes where the SWING went (speed-weighted), not where the hand happened to drift in the last instant before the button came up
  enum { kHist = 24 };
  double hv[kHist][3], ht[kHist]; int hn, hi; double clock;
  double swingDirDeg;   // angle between the swing direction and the plain release velocity (for the log)
  double swingWinMs;
  void hist_clear() { hn = 0; hi = 0; clock = 0; swingDirDeg = 0; swingWinMs = 0; }
  void reset() { armDist = 0.16; coolS = 1.2; held = 0; armed = 0; have = 0; tapLike = 0; v[0] = v[1] = v[2] = 0; cool = 0; heldMs = 0; peak = 0; prevBtn = 0; hist_clear(); }
  // the speed-weighted mean direction over the last winS seconds; returns the mean speed in m/s (0 = nothing usable)
  double swing(double winS, double* d) const {
    double acc[3] = {0, 0, 0}, spsum = 0; int n = 0;
    for (int k = 0; k < hn; ++k) {
      const int i = (hi - 1 - k + kHist * 2) % kHist;
      if (clock - ht[i] > winS) break;
      const double sp = vm::dsqrt(hv[i][0] * hv[i][0] + hv[i][1] * hv[i][1] + hv[i][2] * hv[i][2]);
      for (int c = 0; c < 3; ++c) acc[c] += hv[i][c] * sp;
      spsum += sp; ++n;
    }
    const double l = vm::dsqrt(acc[0] * acc[0] + acc[1] * acc[1] + acc[2] * acc[2]);
    if (!n || !(l > 1e-9)) return 0.0;
    for (int c = 0; c < 3; ++c) d[c] = acc[c] / l;
    return spsum / (double)n;
  }
  // pos: left hand relative to the head (tracking axes, metres); zoneDist: distance from the hip zone centre.
  // 0 nothing, 1 grabbed, 2 thrown (*dir unit vector, *speed m/s), 3 put back
  int update(double dt, int btn, int inZone, double zoneDist, const double* pos, double minSpeed, double* dir, double* speed) {
    if (!(dt > 1e-4) || dt > 0.25) have = 0;
    if (have) {
      const double a = dt / (dt + 0.03);
      for (int i = 0; i < 3; ++i) v[i] += a * ((pos[i] - last[i]) / dt - v[i]);
    }
    for (int i = 0; i < 3; ++i) last[i] = pos[i];
    if (have && dt > 1e-4 && dt <= 0.25) { clock += dt; for (int c = 0; c < 3; ++c) hv[hi][c] = v[c]; ht[hi] = clock; hi = (hi + 1) % kHist; if (hn < kHist) ++hn; }
    have = 1;
    if (cool > 0) cool -= dt;
    const int edge = btn && !prevBtn;
    prevBtn = btn;
    const double sp = vm::dsqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (!held) {
      if (edge && inZone && cool <= 0) { held = 1; armed = 0; heldMs = 0; peak = 0; tapLike = 0; ++grabs; return 1; }
      return 0;
    }
    heldMs += dt;
    if (sp > peak) peak = sp;
    if (zoneDist > armDist) armed = 1;   // 1.7.19: was 0.22 (a short toss from the hip works too)
    const int fast = armed && sp >= minSpeed;
    const int fastRelease = armed && sp >= 0.8 * minSpeed;   // 0.91: a throw needs force and happens on letting go (holding the button no longer throws)
    (void)fast;
    if (!btn && fastRelease) {
      if (dir && sp > 1e-6) for (int i = 0; i < 3; ++i) dir[i] = v[i] / sp;
      {   // 1.7.19: the direction is the speed-weighted swing of the last 0.16 s; the speed is the best of that swing and the release speed
        double sd[3]; const double ss = swing(0.16, sd);
        swingDirDeg = 0.0;
        if (ss > 0.2 && dir) {
          const double c = (sd[0] * dir[0] + sd[1] * dir[1] + sd[2] * dir[2]);
          swingDirDeg = vm::datan2(vm::dsqrt(1.0 - (c > 1.0 ? 1.0 : c * c)), c) * 57.29577951308232;
          for (int i = 0; i < 3; ++i) dir[i] = sd[i];
        }
        if (speed) *speed = sp > ss ? sp : ss;
      }
      if (speed && !(*speed > 0.0)) *speed = sp;
      held = 0; cool = coolS; ++throws;
      return 2;
    }
    if (!btn) { tapLike = (heldMs < 0.30 && peak < 1.0) ? 1 : 0; held = 0; cool = 0.4; ++putbacks; return 3; }
    return 0;
  }
};

// ---- slam by sweeping the gun in any direction ---------------------------------------------------------------------------------------
// With the capture stream held, a fast sweep of the gun hand (any direction, relative to the head) presses fire for a moment and flicks the
// aim stick toward the side the gun went (screen right / up of the head).
struct Sweep {
  double last[3]; int have; double v[3];
  double refractory, pulse, flick, fx, fy;
  long sweeps; double maxSpeed;
  void reset() { have = 0; v[0] = v[1] = v[2] = 0; refractory = 0; pulse = 0; flick = 0; fx = fy = 0; }
  // right / up: the head's right and up axes in the same space as pos. Returns 1 while fire must be held; *sx *sy: the stick flick (-1..1, 0 when none)
  int update(double dt, const double* pos, int capture, double minSpeed, const double* right, const double* up, double* sx, double* sy) {
    if (!(dt > 1e-4) || dt > 0.25) have = 0;
    if (have) {
      const double a = dt / (dt + 0.035);
      for (int i = 0; i < 3; ++i) v[i] += a * ((pos[i] - last[i]) / dt - v[i]);
    }
    for (int i = 0; i < 3; ++i) last[i] = pos[i];
    have = 1;
    if (refractory > 0) refractory -= dt;
    if (pulse > 0) pulse -= dt;
    if (flick > 0) flick -= dt;
    *sx = *sy = 0;
    const double sp = vm::dsqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (!capture) { pulse = 0; flick = 0; return 0; }
    if (sp > maxSpeed) maxSpeed = sp;
    if (refractory <= 0 && sp >= minSpeed) {
      pulse = 0.45; flick = 0.30; refractory = 1.2; ++sweeps;
      const double px = v[0] * right[0] + v[1] * right[1] + v[2] * right[2], py = v[0] * up[0] + v[1] * up[1] + v[2] * up[2];
      const double ip = vm::dsqrt(px * px + py * py);
      if (ip >= 0.45 * sp && ip > 1e-6) { fx = px / ip; fy = py / ip; } else { fx = 0; fy = 0; }
    }
    if (flick > 0) { *sx = fx; *sy = fy; }
    return pulse > 0 ? 1 : 0;
  }
};

// 1.7 which way the gun hand is pulling: the hand's travel over the last half second, in the head's own right / up axes (the slam goes that way).
struct PullDir {
  enum { kN = 192 };   // 1.7.2: 64 -> 192 (about 2 s of polls at 90 Hz, 4 s at 45 Hz)
  double t[kN], x[kN], y[kN]; int n, head; double clock;
  void reset() { n = 0; head = 0; clock = 0; }
  // pos: the hand relative to the head (metres, same space as right / up); dt: seconds since the last push
  void push(double dt, const double* pos, const double* right, const double* up) {
    if (!(dt > 0.0) || dt > 0.25) { if (dt > 0.25) { n = 0; head = 0; } dt = dt > 0.0 && dt <= 0.25 ? dt : 0.011; }
    clock += dt;
    t[head] = clock;
    x[head] = pos[0] * right[0] + pos[1] * right[1] + pos[2] * right[2];
    y[head] = pos[0] * up[0] + pos[1] * up[1] + pos[2] * up[2];
    head = (head + 1) % kN; if (n < kN) ++n;
  }
  // unit direction (right, up) of the hand's travel over the last `win` seconds; returns the travelled length in metres (0 = the hand stayed put: no direction)
  double dir(double win, double minLen, double* fx, double* fy) const {
    *fx = *fy = 0;
    if (n < 2) return 0.0;
    const int last = (head + kN - 1) % kN;
    int first = last;
    for (int k = 1; k < n; ++k) {
      const int i = (last + kN - k) % kN;
      if (clock - t[i] > win) break;
      first = i;
    }
    const double dx = x[last] - x[first], dy = y[last] - y[first];
    const double len = vm::dsqrt(dx * dx + dy * dy);
    if (len < minLen) return 0.0;
    *fx = dx / len; *fy = dy / len;
    return len;
  }
  // 1.7.2: the strongest recent pull. The 1.7.1 log: 17 of 32 slams saw "no pull" (the hand had already stopped when the trigger was squeezed: it was only looked at over the last 0.5 s).
  // Looks back `win` seconds for the biggest straight move of the hand (a chord of at most `span` seconds), newer moves count a bit more than older ones.
  // Returns the length in metres (0 = the hand never moved `minLen`); *fx *fy = unit direction (right, up).
  double best(double win, double span, double minLen, double* fx, double* fy) const {
    *fx = *fy = 0;
    if (n < 2) return 0.0;
    const int last = (head + kN - 1) % kN;
    double bestScore = 0.0, bestLen = 0.0, bx = 0.0, by = 0.0;
    for (int a = 1; a < n; ++a) {             // a = how far back the END of the chord is
      const int j = (last + kN - (a - 1)) % kN;
      const double age = clock - t[j];
      if (age > win) break;
      for (int b = a; b < n; ++b) {           // b = how far back the START is
        const int i = (last + kN - b) % kN;
        if (t[j] - t[i] > span) break;
        const double dx = x[j] - x[i], dy = y[j] - y[i];
        const double len = vm::dsqrt(dx * dx + dy * dy);
        const double score = len * (1.0 - 0.5 * (age / win));
        if (len >= minLen && score > bestScore) { bestScore = score; bestLen = len; bx = dx / len; by = dy / len; }
      }
    }
    if (bestLen <= 0.0) return 0.0;
    *fx = bx; *fy = by;
    return bestLen;
  }
};

// 1.7 the slam on the left trigger: while the capture stream holds a ghost (meter full), a fresh squeeze of the left trigger all the way slams it toward the way the hand is pulling.
// A squeeze that was already held when the meter filled does nothing by itself (a hand that simply holds the trigger tight never slams by accident), unless the squeeze is less than 0.4 s old.
// 1.7.2: the 1.7.1 log showed the squeeze often ended after 0.1 s (a quick tap): the game saw "capture" end 0.1 s later while the fire press ran for 0.45 s, so the game never had capture AND fire together.
// Now one slam is a short sequence: the capture button is held by the probe for 0.70 s, the fire press comes 0.10 s in and lasts 0.45 s, the aim-stick flick starts with it and lasts 0.30 s.
// The pull is the strongest recent move of the gun hand (1.5 s back), not only the last half second.
// When the game's own "a ghost is held" field is known (held 0/1; -1 = not trusted) a squeeze with nothing held does nothing (the meter can stay full after the ghost got away).
struct TrigSlam {
  // 1.7.23: the 1.7.22 log showed the player was already holding the right trigger (the stream) when a slam started, so the game saw ONE long fire press and never a new one (BTNEVENT: no new
  // action-29 press in three of four slams). The sequence now lets fire go for kFireAt seconds first (releaseNow = 1: the caller zeroes the right trigger), then presses it fresh.
  static constexpr double kCapHold = 0.90, kFireAt = 0.0, kFireLen = 0.0, kFlickLen = 0.30;   // 1.7.25: no more 'let fire go first' gap (the 1.7.24 log showed it dropped the capture stream and the ghost lock); a full squeeze slams at once
  // nobody could test which kind of fire press the game wants for a slam, so consecutive slams try a normal press (0.45 s), a short tap (0.12 s) and a long press (0.90 s); the log says which one each slam used
  double fireLen, capHold; int variant;
  int releaseNow;
  int prevHot, prevSq, prevReady; double refractory, seq, fx, fy, sqAge; long slams, denied, flickless, noGhost, pings; double lastLen;
  void reset() { prevHot = 0; prevSq = 0; prevReady = 0; refractory = 0; seq = -1.0; fx = fy = 0; sqAge = 99.0; releaseNow = 0; fireLen = kFireLen; capHold = kCapHold; variant = 0; }
  // held: 1 a ghost is held, 0 nothing is held, -1 unknown.  Returns 1 while the fire trigger must be held.
  // *forceCapture = 1 while the probe must keep the capture button down; *sx *sy = the aim-stick flick (-1..1, 0 = none: the game then slams downward by itself)
  // *started = 1 on the poll a slam sequence begins; *wasDenied = 1 (meter not full) or 2 (meter full but nothing is held); *ping = 1 when the meter just became full while a ghost is held (tell the player)
  int update(double dt, double trig, int capture, int ready, int held, double level, const PullDir& pd, double* sx, double* sy, int* forceCapture, int* started, int* wasDenied, int* ping) {
    if (started) *started = 0;
    if (wasDenied) *wasDenied = 0;
    if (ping) *ping = 0;
    if (forceCapture) *forceCapture = 0;
    if (!(dt > 0.0) || dt > 0.25) dt = 0.011;
    if (refractory > 0) refractory -= dt;
    if (seq >= 0.0) { seq += dt; if (seq > capHold) seq = -1.0; }
    const int squeezed = capture && trig >= level;
    if (squeezed && !prevSq) sqAge = 0.0; else if (squeezed) sqAge += dt; else sqAge = 99.0;
    const int gate = ready && held != 0;
    const int hot = squeezed && gate;
    const int fresh = (squeezed && !prevSq) || (hot && !prevHot && sqAge < 0.4);
    if (ping && ready && !prevReady && held > 0) { *ping = 1; ++pings; }
    if (hot && fresh && refractory <= 0 && seq < 0.0) {
      double dx, dy;
      lastLen = pd.best(1.5, 0.6, 0.03, &dx, &dy);
      fx = dx; fy = dy;
      if (lastLen <= 0.0) ++flickless;
      fireLen = 0.0; capHold = kCapHold; ++variant;
      seq = 0.0; refractory = 1.2; ++slams;
      if (started) *started = 1;
    } else if (squeezed && !prevSq && !ready) {   // squeezed all the way but the meter is not full: nothing to slam with yet
      ++denied; if (wasDenied) *wasDenied = 1;
    } else if (squeezed && !prevSq && ready && held == 0) {   // the meter reads full but the stream holds nothing
      ++noGhost; if (wasDenied) *wasDenied = 2;
    }
    prevHot = hot; prevSq = squeezed; prevReady = ready;
    const int running = seq >= 0.0;
    releaseNow = 0;   // 1.7.25: fire is never let go
    if (forceCapture) *forceCapture = running ? 1 : 0;
    const int fireOn = 0;   // 1.7.25: the probe does not press fire; the slam is started through the game's own slam function (engine_hooks.cpp slam helper)
    const int flickOn = running && seq >= kFireAt && seq < kFireAt + kFlickLen;
    *sx = flickOn ? fx : 0.0; *sy = flickOn ? fy : 0.0;
    return fireOn ? 1 : 0;
  }
};

// a 3x4 pose (OpenVR device axes: forward is -z) pointing along the unit vector f, no roll; translation 0
inline void aim_pose(const double* f, float* out34) {
  double x[3];   // f x (0,1,0) = (-f.z, 0, f.x)
  x[0] = -f[2]; x[1] = 0.0; x[2] = f[0];
  double xl = vm::dsqrt(x[0] * x[0] + x[2] * x[2]);
  if (xl < 1e-6) { x[0] = 1; x[1] = 0; x[2] = 0; } else { x[0] /= xl; x[2] /= xl; }
  const double y[3] = {x[1] * f[2] - x[2] * f[1], x[2] * f[0] - x[0] * f[2], x[0] * f[1] - x[1] * f[0]};
  for (int r = 0; r < 3; ++r) { out34[r * 4 + 0] = (float)x[r]; out34[r * 4 + 1] = (float)y[r]; out34[r * 4 + 2] = (float)-f[r]; out34[r * 4 + 3] = 0.0f; }
}

// ---- a tiny letter font (3 x 5, rows top to bottom, bit 2 = left column) ---------------------------------------------------------------
static const unsigned char kLetters[26][5] = {
  {2, 5, 7, 5, 5}, {6, 5, 6, 5, 6}, {3, 4, 4, 4, 3}, {6, 5, 5, 5, 6}, {7, 4, 6, 4, 7}, {7, 4, 6, 4, 4}, {3, 4, 5, 5, 3}, {5, 5, 7, 5, 5}, {7, 2, 2, 2, 7},
  {1, 1, 1, 5, 2}, {5, 5, 6, 5, 5}, {4, 4, 4, 4, 7}, {5, 7, 7, 5, 5}, {6, 5, 5, 5, 5}, {2, 5, 5, 5, 2}, {6, 5, 6, 4, 4}, {2, 5, 5, 7, 3}, {6, 5, 6, 5, 5},
  {3, 4, 2, 1, 6}, {7, 2, 2, 2, 2}, {5, 5, 5, 5, 7}, {5, 5, 5, 5, 2}, {5, 5, 7, 7, 5}, {5, 5, 2, 5, 5}, {5, 5, 2, 2, 2}, {7, 1, 2, 4, 7}};
static const unsigned char kQuestion[5] = {7, 1, 2, 0, 2};   // 0.78: the "?" of a locked disc
static const unsigned char kDash[5] = {0, 0, 7, 0, 0};
inline const unsigned char* glyph_for(char c) {
  if (c >= 'A' && c <= 'Z') return kLetters[c - 'A'];
  if (c >= 'a' && c <= 'z') return kLetters[c - 'a'];
  if (c >= '0' && c <= '9') return fight::kGlyph[c - '0'];
  if (c == '%') return fight::kGlyph[10];
  if (c == '?') return kQuestion;
  if (c == '-') return kDash;
  return nullptr;   // a space (or anything else) leaves a gap
}
inline int str_len(const char* s) { int n = 0; while (s && s[n]) ++n; return n; }
inline double str_width(const char* s, double px) { const int n = str_len(s); return n ? n * 3.0 * px + (n - 1) * px : 0.0; }
// align: -1 the right end of the text is at x, 0 centred, +1 the left end is at x. y = centre line.
inline void text_str(fight::Buf& b, const char* s, double x, double y, double z, double px, const float* col, int align) {
  const int n = str_len(s);
  if (!n) return;
  const double w = str_width(s, px);
  double x0 = align < 0 ? x - w : align > 0 ? x : x - 0.5 * w;
  for (int k = 0; k < n; ++k) {
    const unsigned char* g = glyph_for(s[k]);
    const double gx = x0 + k * 4.0 * px;
    if (!g) continue;
    for (int r = 0; r < 5; ++r)
      for (int c = 0; c < 3; ++c)
        if (g[r] & (4 >> c)) fight::rect(b, gx + (c + 0.5) * px, y + (2.0 - r) * px, z, px, px, col);
  }
}

// ---- drawing the wheel ----------------------------------------------------------------------------------------------------------
// Built flat in the wheel's own plane (z = 0, x right, y up, metres); the caller places it with the anchor pose.
struct WheelView {
  double openT;         // 0..1 (linear time of the open / close animation)
  const double* hov;    // kSlots smoothed hover amounts 0..1
  int sel, picked, pickLocked;
  double flash;         // 1 -> 0 after a pick
  int current;          // the item in hand (kItem*), -1 unknown
  const int* state;     // kItemCount item states or null
  double curX, curY;    // smoothed cursor, -1..1
  double scale;         // 1 = default size
};

inline double ramp01(double t) { return t <= 0 ? 0.0 : t >= 1 ? 1.0 : t * t * (3.0 - 2.0 * t); }
inline double smooth01(double t) { if (t <= 0) return 0; if (t >= 1) return 1; return t * t * (3.0 - 2.0 * t); }
inline void mix3(const float* a, const float* b, double t, float* o) { for (int i = 0; i < 3; ++i) o[i] = (float)(a[i] + (b[i] - a[i]) * t); }

inline void ring_piece(fight::Buf& b, double cx, double cy, double z, double r0, double r1, double a0, double a1, int segs, const float* col) {
  for (int s = 0; s < segs; ++s) {
    const double t0 = a0 + (a1 - a0) * s / segs, t1 = a0 + (a1 - a0) * (s + 1) / segs;
    double s0, c0, s1, c1;
    vm::dsincos(t0, &s0, &c0); vm::dsincos(t1, &s1, &c1);
    const float P00[3] = {(float)(cx + r0 * s0), (float)(cy + r0 * c0), (float)z}, P01[3] = {(float)(cx + r1 * s0), (float)(cy + r1 * c0), (float)z};
    const float P10[3] = {(float)(cx + r0 * s1), (float)(cy + r0 * c1), (float)z}, P11[3] = {(float)(cx + r1 * s1), (float)(cy + r1 * c1), (float)z};
    fight::emit(b, P00, col); fight::emit(b, P11, col); fight::emit(b, P01, col);
    fight::emit(b, P00, col); fight::emit(b, P10, col); fight::emit(b, P11, col);
  }
}
inline void disc(fight::Buf& b, double cx, double cy, double z, double r, int segs, const float* col) {
  const float C[3] = {(float)cx, (float)cy, (float)z};
  for (int s = 0; s < segs; ++s) {
    const double t0 = 2.0 * vm::kPi * s / segs, t1 = 2.0 * vm::kPi * (s + 1) / segs;
    double s0, c0, s1, c1;
    vm::dsincos(t0, &s0, &c0); vm::dsincos(t1, &s1, &c1);
    const float A[3] = {(float)(cx + r * s0), (float)(cy + r * c0), (float)z}, B[3] = {(float)(cx + r * s1), (float)(cy + r * c1), (float)z};
    fight::emit(b, C, col); fight::emit(b, B, col); fight::emit(b, A, col);
  }
}

// colours of one disc for a hover amount h (0..1)
inline void slot_colors(int status, int isCur, double h, float* fill, float* ring, float* text) {
  // 1.6: the outlines are red (the discs' fills stay dark so the red stands out; the lit disc's outline turns bright)
  static const float fI[3] = {0.09f, 0.14f, 0.21f}, rI[3] = {0.82f, 0.10f, 0.10f}, tI[3] = {0.80f, 0.92f, 1.00f};
  static const float fH[3] = {0.35f, 0.85f, 1.00f}, rH[3] = {1.00f, 0.45f, 0.38f}, tH[3] = {0.02f, 0.10f, 0.14f};
  static const float fL[3] = {0.06f, 0.06f, 0.07f}, rL[3] = {0.40f, 0.09f, 0.09f}, tL[3] = {0.50f, 0.50f, 0.55f};
  static const float fLH[3] = {0.14f, 0.07f, 0.07f}, rLH[3] = {0.85f, 0.35f, 0.30f}, tLH[3] = {0.95f, 0.45f, 0.40f};
  static const float fO[3] = {0.07f, 0.08f, 0.10f}, rO[3] = {0.50f, 0.22f, 0.10f}, tO[3] = {0.38f, 0.40f, 0.45f};
  static const float fOH[3] = {0.12f, 0.10f, 0.07f}, rOH[3] = {0.90f, 0.65f, 0.20f}, tOH[3] = {0.95f, 0.75f, 0.35f};
  static const float rC[3] = {0.30f, 0.95f, 0.50f};
  const float *f0 = fI, *r0 = rI, *t0 = tI, *f1 = fH, *r1 = rH, *t1 = tH;
  if (status == kLocked) { f0 = fL; r0 = rL; t0 = tL; f1 = fLH; r1 = rLH; t1 = tLH; }
  else if (status == kOff) { f0 = fO; r0 = rO; t0 = tO; f1 = fOH; r1 = rOH; t1 = tOH; }
  mix3(f0, f1, h, fill); mix3(r0, r1, h, ring); mix3(t0, t1, h, text);
  if (isCur && status == kOk) { float c[3]; mix3(rC, r1, h, c); for (int i = 0; i < 3; ++i) ring[i] = c[i]; }
}

// ---- 1.7.189 "make the weapon wheel look better, the same vibe as the health bars, the text looks awful" -------------------------------------------------
// A smooth stroke font (round, evenly thick lines instead of 3 x 5 blocks), gradient steel bezels, dark smoked glass with a neon rim in the slot's colour
// and, when a disc is lit, glowing liquid in it (the same look as the health tube and the ghosts' vials).
struct StrokeGlyph { char c; const char* s; };   // polylines "x,y x,y ...;x,y ..." on a 6 x 10 grid (y up)
static const StrokeGlyph kStroke[] = {
  {'A', "0,0 3,10 6,0;1,3.6 5,3.6"}, {'B', "0,0 0,10 3.5,10 5,9 5.3,7.2 3.5,5.4 0,5.4;3.5,5.4 5.4,4.4 5.7,2.2 4.5,0.6 3,0 0,0"},
  {'C', "6,8 5,9.6 3.6,10 2,9.6 0.8,8 0.2,5 0.8,2 2,0.4 3.6,0 5,0.4 6,2"}, {'D', "0,0 0,10 2.5,10 4.6,9.2 5.6,7 5.8,5 5.6,3 4.6,0.8 2.5,0 0,0"},
  {'E', "6,10 0,10 0,0 6,0;0,5.2 4.5,5.2"}, {'F', "6,10 0,10 0,0;0,5.2 4.5,5.2"},
  {'G', "6,8 5,9.6 3.6,10 2,9.6 0.8,8 0.2,5 0.8,2 2,0.4 3.6,0 5.2,0.6 6,2.5 6,4.5 3.4,4.5"}, {'H', "0,0 0,10;6,0 6,10;0,5.2 6,5.2"},
  {'I', "1,10 5,10;3,10 3,0;1,0 5,0"}, {'J', "6,10 6,2.5 5.2,0.6 3.6,0 2,0.4 0.8,1.6 0.4,3"},
  {'K', "0,0 0,10;6,10 0,4.6;2.2,6.4 6,0"}, {'L', "0,10 0,0 5.6,0"}, {'M', "0,0 0,10 3,4.5 6,10 6,0"}, {'N', "0,0 0,10 6,0 6,10"},
  {'O', "3,10 1.6,9.6 0.5,8 0,5 0.5,2 1.6,0.4 3,0 4.4,0.4 5.5,2 6,5 5.5,8 4.4,9.6 3,10"}, {'P', "0,0 0,10 3.5,10 5,9.2 5.6,7.4 5,5.6 3.5,4.8 0,4.8"},
  {'Q', "3,10 1.6,9.6 0.5,8 0,5 0.5,2 1.6,0.4 3,0 4.4,0.4 5.5,2 6,5 5.5,8 4.4,9.6 3,10;3.8,2.4 6,0"},
  {'R', "0,0 0,10 3.5,10 5,9.2 5.6,7.4 5,5.6 3.5,4.8 0,4.8;3.2,4.8 6,0"},
  {'S', "5.8,8.4 4.8,9.6 3.2,10 1.6,9.6 0.6,8.4 0.6,6.8 1.8,5.6 4.2,4.4 5.4,3.2 5.4,1.6 4.4,0.4 2.8,0 1.2,0.4 0.2,1.6"},
  {'T', "0,10 6,10;3,10 3,0"}, {'U', "0,10 0,3 0.5,1.4 1.6,0.3 3,0 4.4,0.3 5.5,1.4 6,3 6,10"}, {'V', "0,10 3,0 6,10"}, {'W', "0,10 1.5,0 3,6 4.5,0 6,10"},
  {'X', "0,10 6,0;0,0 6,10"}, {'Y', "0,10 3,5 6,10;3,5 3,0"}, {'Z', "0,10 6,10 0,0 6,0"},
  {'0', "3,10 1.6,9.6 0.5,8 0,5 0.5,2 1.6,0.4 3,0 4.4,0.4 5.5,2 6,5 5.5,8 4.4,9.6 3,10"}, {'1', "1.2,8 3,10 3,0;1,0 5,0"},
  {'2', "0.4,8 1,9.4 2.4,10 4,10 5.4,9.4 5.8,8 5.4,6.4 4,5 0.2,0 6,0"},
  {'3', "0.4,9 2,10 4,10 5.4,9.2 5.6,7.8 4.8,6.2 3,5.4 4.8,4.6 5.8,3.2 5.6,1.4 4.2,0.2 2.4,0 1,0.6 0.2,1.6"}, {'4', "4.6,0 4.6,10 0,3 6,3"},
  {'5', "5.6,10 0.8,10 0.4,5.6 2,6.2 3.6,6.2 5.2,5.4 5.8,3.8 5.4,1.6 4,0.3 2.4,0 1,0.4 0.2,1.4"},
  {'6', "5.4,9 4,10 2.4,10 1,8.8 0.2,6 0.2,2.5 1,0.8 2.4,0 3.8,0 5.2,0.8 6,2.6 5.4,4.4 4,5.2 2.4,5.2 1,4.4 0.2,3"}, {'7', "0,10 6,10 2.4,0"},
  {'8', "3,5.2 1.4,5.8 0.6,7.4 1.2,9 3,10 4.8,9 5.4,7.4 4.6,5.8 3,5.2 1.2,4.4 0.4,2.6 1,0.8 3,0 5,0.8 5.6,2.6 4.8,4.4 3,5.2"},
  {'9', "0.6,1 2,0 3.6,0 4.8,1.2 5.8,4 5.8,7.5 5,9.2 3.6,10 2.2,10 0.8,9.2 0,7.6 0.6,5.8 2,4.8 3.6,4.8 5,5.8 5.8,7"},
  {'%', "0.3,9 1,10 1.9,9 1,8 0.3,9;4.1,1 5,2 5.9,1 5,0 4.1,1;5.6,10 0.4,0"}, {'?', "0.6,8 1.4,9.6 3,10 4.6,9.4 5.4,8 5,6.2 3,5 3,3;3,0 3,0.5"}, {'-', "1,5 5,5"}};
inline const char* stroke_for(char c) {
  if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
  for (unsigned i = 0; i < sizeof(kStroke) / sizeof(kStroke[0]); ++i) if (kStroke[i].c == c) return kStroke[i].s;
  return nullptr;
}
static const double kStrokeAspect = 0.62, kStrokeAdvance = 0.80, kStrokeWeight = 0.075;   // glyph width / height, advance / height, half stroke width / height
inline double stroke_width(const char* s, double h) { const int n = str_len(s); return n ? ((n - 1) * kStrokeAdvance + kStrokeAspect) * h : 0.0; }
// a round-ended line from (x0,y0) to (x1,y1), half width hw
inline void stroke_line(fight::Buf& b, double x0, double y0, double x1, double y1, double z, double hw, const float* col) {
  double dx = x1 - x0, dy = y1 - y0; const double l = vm::dsqrt(dx * dx + dy * dy);
  if (l < 1e-9) return;
  dx /= l; dy /= l;
  const double nx = -dy * hw, ny = dx * hw;
  const float A[3] = {(float)(x0 + nx), (float)(y0 + ny), (float)z}, B[3] = {(float)(x0 - nx), (float)(y0 - ny), (float)z};
  const float C[3] = {(float)(x1 - nx), (float)(y1 - ny), (float)z}, D[3] = {(float)(x1 + nx), (float)(y1 + ny), (float)z};
  fight::emit(b, A, col); fight::emit(b, C, col); fight::emit(b, B, col);
  fight::emit(b, A, col); fight::emit(b, D, col); fight::emit(b, C, col);
}
inline void stroke_dot(fight::Buf& b, double cx, double cy, double z, double r, const float* col) {
  const float C[3] = {(float)cx, (float)cy, (float)z};
  for (int k = 0; k < 6; ++k) {
    double s0, c0, s1, c1; vm::dsincos(2.0 * vm::kPi * k / 6.0, &s0, &c0); vm::dsincos(2.0 * vm::kPi * (k + 1) / 6.0, &s1, &c1);
    const float P[3] = {(float)(cx + r * c0), (float)(cy + r * s0), (float)z}, Q[3] = {(float)(cx + r * c1), (float)(cy + r * s1), (float)z};
    fight::emit(b, C, col); fight::emit(b, P, col); fight::emit(b, Q, col);
  }
}
// a plain decimal ("12", "3.5") from s; advances *e past it (no C library: the game build has no strtod)
inline double num_at(const char* s, const char** e) {
  double v = 0.0, f = 0.1; int neg = 0;
  if (*s == '-') { neg = 1; ++s; }
  while (*s >= '0' && *s <= '9') { v = v * 10.0 + (*s - '0'); ++s; }
  if (*s == '.') { ++s; while (*s >= '0' && *s <= '9') { v += (*s - '0') * f; f *= 0.1; ++s; } }
  *e = s; return neg ? -v : v;
}
// one glyph with its lower left corner at (gx, gy), height h. Round caps at the ends of every line and at its sharper bends (a gentle curve needs none).
inline void stroke_glyph(fight::Buf& b, const char* g, double gx, double gy, double z, double h, const float* col) {
  const double sx = h * 0.1 * kStrokeAspect / 0.6, sy = h * 0.1, hw = h * kStrokeWeight;   // grid 6 x 10 -> width 0.62 h, height h
  double px = 0, py = 0, pdx = 0, pdy = 0; int have = 0;
  for (const char* c = g; ; ++c) {
    if (*c == ';' || *c == 0) { if (have) stroke_dot(b, px, py, z, hw, col); have = 0; if (!*c) break; continue; }
    if (*c == ' ') continue;
    const char* e = nullptr;
    const double X = num_at(c, &e); if (!e || *e != ',') break;
    const double Y = num_at(e + 1, &e);
    const double x = gx + X * sx, y = gy + Y * sy;
    if (!have) { stroke_dot(b, x, y, z, hw, col); have = 1; pdx = pdy = 0; }
    else {
      double dx = x - px, dy = y - py; const double l = vm::dsqrt(dx * dx + dy * dy);
      stroke_line(b, px, py, x, y, z, hw, col);
      if (l > 1e-9) { dx /= l; dy /= l; if ((pdx != 0.0 || pdy != 0.0) && dx * pdx + dy * pdy < 0.80) stroke_dot(b, px, py, z, hw, col); pdx = dx; pdy = dy; }
    }
    px = x; py = y; c = e - 1;
  }
}
// centred (align 0), right end at x (-1) or left end at x (+1); y = the middle of the letters, h = the letters' height
inline void stroke_str(fight::Buf& b, const char* s, double x, double y, double z, double h, const float* col, int align) {
  const int n = str_len(s); if (!n) return;
  const double w = stroke_width(s, h);
  const double x0 = align < 0 ? x - w : align > 0 ? x : x - 0.5 * w;
  for (int k = 0; k < n; ++k) {
    const char* g = stroke_for(s[k]);
    if (g) stroke_glyph(b, g, x0 + k * kStrokeAdvance * h, y - 0.5 * h, z, h, col);
  }
}
// a ring piece whose brightness runs from k0 (inside) to k1 (outside)
inline void ring_grad(fight::Buf& b, double cx, double cy, double z, double r0, double r1, double a0, double a1, int segs, const float* col, float k0, float k1) {
  for (int s = 0; s < segs; ++s) {
    const double t0 = a0 + (a1 - a0) * s / segs, t1 = a0 + (a1 - a0) * (s + 1) / segs;
    double s0, c0, s1, c1; vm::dsincos(t0, &s0, &c0); vm::dsincos(t1, &s1, &c1);
    fight::emit2(b, cx + r0 * s0, cy + r0 * c0, z, col, k0); fight::emit2(b, cx + r1 * s1, cy + r1 * c1, z, col, k1); fight::emit2(b, cx + r1 * s0, cy + r1 * c0, z, col, k1);
    fight::emit2(b, cx + r0 * s0, cy + r0 * c0, z, col, k0); fight::emit2(b, cx + r0 * s1, cy + r0 * c1, z, col, k0); fight::emit2(b, cx + r1 * s1, cy + r1 * c1, z, col, k1);
  }
}
// a disc whose colour runs from cc (centre) to ce (edge)
inline void disc_grad(fight::Buf& b, double cx, double cy, double z, double r, int segs, const float* cc, const float* ce) {
  for (int s = 0; s < segs; ++s) {
    double s0, c0, s1, c1; vm::dsincos(2.0 * vm::kPi * s / segs, &s0, &c0); vm::dsincos(2.0 * vm::kPi * (s + 1) / segs, &s1, &c1);
    const float C[3] = {(float)cx, (float)cy, (float)z};
    fight::emit(b, C, cc);
    const float A[3] = {(float)(cx + r * s0), (float)(cy + r * c0), (float)z}, B[3] = {(float)(cx + r * s1), (float)(cy + r * c1), (float)z};
    fight::emit(b, B, ce); fight::emit(b, A, ce);
  }
}
// the colour a slot glows in: cyan = ready, green = in your hand, amber = switched off, red = not yours yet
inline void slot_accent(int status, int isCur, float* a, float* rimK) {
  static const float cy[3] = {0.25f, 0.82f, 1.00f}, gr[3] = {0.30f, 1.00f, 0.42f}, am[3] = {1.00f, 0.72f, 0.20f}, rd[3] = {0.85f, 0.20f, 0.16f};
  const float* c = cy; float k = 0.85f;
  if (status == kLocked) { c = rd; k = 0.50f; } else if (status == kOff) { c = am; k = 0.70f; } else if (isCur) { c = gr; k = 1.0f; }
  for (int i = 0; i < 3; ++i) a[i] = c[i];
  *rimK = k;
}

// builds the wheel (flat, in its own plane) into out. Returns the vertex count, or -1 when out was too small.
// 1.6: the vertices come in two groups. [0, *opaqueFrom) is the body of the wheel (the dark track, the centre, the glass of the discs): the caller draws it see-through (wheel_alpha_pct).
// [*opaqueFrom, n) is everything on top, drawn solid: the neon rims, the steel bezels, the words and the cursor.
inline int build_wheel(const WheelView& w, cord::V* out, int cap, int* opaqueFrom = nullptr) {
  fight::Buf b = {out, 0, cap, 0};
  if (opaqueFrom) *opaqueFrom = 0;
  const double sc = w.scale > 0.2 ? w.scale : 1.0;
  const double e = smooth01(w.openT);
  if (e <= 0.003) return 0;
  const double R = 0.105 * sc, rd = 0.026 * sc;
  const double step = 2.0 * vm::kPi / kSlots, TWO = 2.0 * vm::kPi;
  const float track[3] = {0.012f, 0.020f, 0.032f}, centre[3] = {0.020f, 0.034f, 0.052f}, steel[3] = {0.62f, 0.68f, 0.74f};
  const float glassC[3] = {0.050f, 0.085f, 0.115f}, glassE[3] = {0.012f, 0.022f, 0.034f};
  // ---- the see-through body: the dark track under the discs, the dark centre, the smoked glass of every disc (lit ones fill with glowing liquid)
  ring_piece(b, 0, 0, 0, (R - rd * 1.35) * e, (R + rd * 1.35) * e, 0.0, TWO, 40, track);
  disc_grad(b, 0, 0, 0, (R - rd * 1.45) * e, 32, centre, track);
  struct G { double px, py, drad, h; float acc[3], rimK, text[3]; int st; } g[kSlots];
  for (int i = 0; i < kSlots; ++i) {
    const double h = w.hov ? w.hov[i] : 0.0;
    const int st = slot_status(i, w.state);
    const int isCur = kWheel[i].kind == kKindItem && w.current == kWheel[i].arg;
    float fill[3], ring[3], text[3], acc[3], rimK;
    slot_colors(st, isCur, h, fill, ring, text);
    { float ta[3], tb[3], f2[3], r2[3]; slot_colors(st, isCur, 0.0, f2, r2, ta); slot_colors(st, isCur, 1.0, f2, r2, tb);
      mix3(ta, tb, ramp01((h - 0.40) / 0.45), text); }   // 1.7.189: the letters stay light until the glass is bright enough, then turn dark (no grey in between)
    slot_accent(st, isCur, acc, &rimK);
    const int pk = (i == w.picked);
    const double fl = pk ? w.flash : 0.0;
    if (pk && fl > 0.0) {   // the pick flashes white (a refused pick flashes red and shakes)
      const float flc[3] = {1.0f, 1.0f, 1.0f}, flr[3] = {1.0f, 0.35f, 0.30f};
      mix3(acc, w.pickLocked ? flr : flc, fl, acc);
    }
    double s, c;
    vm::dsincos(i * step, &s, &c);
    const double rr = R * (0.45 + 0.55 * e) + 0.010 * sc * h;   // the discs fly out from the middle while it opens; the lit one leans out a little and grows
    double px0 = rr * s, py0 = rr * c;
    if (pk && w.pickLocked && fl > 0.0) { double ss, cc; vm::dsincos(fl * 40.0, &ss, &cc); px0 += ss * 0.005 * sc * fl; }
    const double drad = rd * (2.0 * e - e * e) * (1.0 + 0.30 * h + (pk ? 0.35 * fl : 0.0));   // 1.7.189: grows from nothing (it used to start at a third of its size: a pop)
    g[i].px = px0; g[i].py = py0; g[i].drad = drad; g[i].st = st; g[i].h = h; g[i].rimK = rimK;
    for (int k = 0; k < 3; ++k) { g[i].acc[k] = acc[k]; g[i].text[k] = text[k]; }
    // the glass: dark and smoky, or (lit) glowing liquid, bright in the middle and deeper at the edge
    const double lit = h * (st == kLocked ? 0.45 : 1.0) + (pk ? fl * 0.5 : 0.0);
    float gc[3], ge[3];
    const float liqC[3] = {acc[0] * 0.95f, acc[1] * 0.95f, acc[2] * 0.95f}, liqE[3] = {acc[0] * 0.42f, acc[1] * 0.42f, acc[2] * 0.42f};
    mix3(glassC, liqC, lit > 1.0 ? 1.0 : lit, gc); mix3(glassE, liqE, lit > 1.0 ? 1.0 : lit, ge);
    disc_grad(b, px0, py0, 0, drad * 0.80, 24, gc, ge);
  }
  const int split = b.n;
  if (opaqueFrom) *opaqueFrom = split;
  // ---- solid: the steel rails of the track, the little lamps between the discs
  ring_grad(b, 0, 0, 0, (R + rd * 1.35) * e, (R + rd * 1.35 + 0.0040 * sc) * e, 0.0, TWO, 40, steel, 0.55f, 0.20f);
  ring_grad(b, 0, 0, 0, (R - rd * 1.35 - 0.0040 * sc) * e, (R - rd * 1.35) * e, 0.0, TWO, 40, steel, 0.20f, 0.55f);
  const double rampD = ramp01((e - 0.35) / 0.45), rampC = ramp01((e - 0.70) / 0.30);   // 1.7.189: words, lamps, cursor and the name GROW in (no pop at a threshold)
  for (int i = 0; i < kSlots && rampD > 0.02; ++i) {
    double s, c; vm::dsincos((i + 0.5) * step, &s, &c);
    const float lamp[3] = {0.25f, 0.82f, 1.00f};
    stroke_dot(b, R * s * e, R * c * e, 0, 0.0030 * sc * rampD, lamp);
  }
  // ---- each disc: steel bezel, neon rim in its colour, a glass reflection, the code
  for (int i = 0; i < kSlots; ++i) {
    const double d = g[i].drad, h = g[i].h, x = g[i].px, y = g[i].py;
    const float* acc = g[i].acc;
    float core[3]; mix3(acc, steel, 0.0, core);
    const float wh[3] = {1.0f, 1.0f, 1.0f};
    float hot[3]; mix3(acc, wh, 0.55, hot);
    const float rk = g[i].rimK + (float)(1.0 - g[i].rimK) * (float)h;
    ring_grad(b, x, y, 0, d * 0.80, d * 0.86, 0.0, TWO, 24, hot, 1.0f * rk, 0.85f * rk);    // the lit core of the neon rim
    ring_grad(b, x, y, 0, d * 0.86, d * 0.93, 0.0, TWO, 24, core, 0.75f * rk, 0.22f * rk);  // and its glow fading outward
    ring_grad(b, x, y, 0, d * 0.93, d * 1.04, 0.0, TWO, 24, steel, 0.30f, 0.46f);           // the steel bezel
    ring_grad(b, x, y, 0, d * 0.93, d * 1.04, 4.6, 6.2, 8, steel, 0.80f, 0.60f);            // light catching its upper left
    if (rampD <= 0.02) continue;
    { // a long reflection across the glass, upper left
      const float rf[3] = {0.80f, 0.92f, 1.0f};
      ring_grad(b, x, y, 0, d * 0.60, d * 0.68, 4.75, 5.85, 8, rf, (float)((0.24 + 0.22 * h) * rampD), (float)((0.24 + 0.22 * h) * rampD));
    }
    if (g[i].st == kLocked) {
      stroke_str(b, "?", x, y, 0, 0.0155 * sc * rampD * (1.0 + 0.30 * h), g[i].text, 0);
    } else {
      const double ch = (kWheel[i].code[3] ? 0.0125 : 0.0145) * sc * rampD * (1.0 + 0.30 * h);
      stroke_str(b, kWheel[i].code, x, y, 0, ch, g[i].text, 0);
    }
  }
  // the cursor: where the stick / hand points (drawn under the name so the words stay readable)
  if (rampC > 0.02) {
    const float dot[3] = {1.0f, 1.0f, 1.0f}, halo[3] = {0.25f, 0.82f, 1.0f};
    disc(b, w.curX * R * 0.55 * e, w.curY * R * 0.55 * e, 0, 0.0075 * sc * rampC, 14, halo);
    disc(b, w.curX * R * 0.55 * e, w.curY * R * 0.55 * e, 0, 0.0045 * sc * rampC, 12, dot);
  }
  // the middle: the name of the lit disc (or what is in your hand). 1.6: a weapon you do not have yet shows "?" and not its name
  {
    const double ts = sc * (0.70 + 0.30 * e) * rampC;
    const int shown = w.sel >= 0 ? w.sel : -1;
    const char *l1 = "WEAPONS", *l2 = "", *l3 = "";
    float c1[3] = {0.88f, 0.95f, 1.0f}, c2[3] = {0.55f, 0.78f, 0.92f}, c3[3] = {0.60f, 0.72f, 0.82f};
    double p1 = 0.0150;
    float rimc[3] = {0.25f, 0.82f, 1.0f};
    if (shown >= 0) {
      const int st = slot_status(shown, w.state);
      l1 = kWheel[shown].label; l2 = kWheel[shown].n2;
      float rk0; slot_accent(st, kWheel[shown].kind == kKindItem && w.current == kWheel[shown].arg, rimc, &rk0);
      if (st == kLocked) { l1 = "?"; l2 = ""; p1 = 0.026; l3 = "LOCKED"; c3[0] = 1.0f; c3[1] = 0.45f; c3[2] = 0.40f; c1[0] = 0.80f; c1[1] = 0.80f; c1[2] = 0.86f; }
      else if (st == kOff) { l3 = "NOT NOW"; c3[0] = 0.95f; c3[1] = 0.75f; c3[2] = 0.35f; }
      else if (kWheel[shown].kind == kKindItem && w.current == kWheel[shown].arg) { l3 = "IN HAND"; c3[0] = 0.40f; c3[1] = 1.0f; c3[2] = 0.55f; }
    } else if (w.current > 0 && w.current < kItemCount) {
      for (int i = 0; i < kSlots; ++i) if (kWheel[i].kind == kKindItem && kWheel[i].arg == w.current) { l1 = kWheel[i].label; l2 = kWheel[i].n2; l3 = "IN HAND"; c3[0] = 0.40f; c3[1] = 1.0f; c3[2] = 0.55f; break; }
    }
    // the centre's own rim, in the colour of the lit disc: steel outside, a thin neon line inside
    const double rc = (R - rd * 1.45) * e;
    ring_grad(b, 0, 0, 0, rc * 0.93, rc * 0.97, 0.0, TWO, 32, rimc, 0.95f, 0.25f);
    ring_grad(b, 0, 0, 0, rc * 0.97, rc * 1.03, 0.0, TWO, 32, steel, 0.30f, 0.46f);
    if (rampC > 0.02) {
      stroke_str(b, l1, 0, 0.020 * ts, 0, p1 * ts, c1, 0);
      stroke_str(b, l2, 0, 0.001 * ts, 0, 0.0085 * ts, c2, 0);
      stroke_str(b, l3, 0, -0.019 * ts, 0, 0.0078 * ts, c3, 0);
    }
  }
  return b.over ? -1 : b.n;
}

}  // namespace gear
