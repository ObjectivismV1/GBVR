// 1.7.118: "is this ghost really flying about". The game keeps every enemy of a level in its list, also the ones that have not spawned yet (a pack of floaters waiting 70 m away at 100 %), and
// its own can-lock test says no to nearly all of them in VR (the VR view never gets the game's lock). Until now a ghost only got a health ring / bar after you HIT or HELD it, so the first
// shots at a ghost came with no ring at all. A ghost that has not spawned stands exactly where the level put it; a ghost that is out and flying moves. Pure math, tests/test_ghostmove.cpp.
#pragma once
#include <stdint.h>
namespace ghostmove {
static const double kMoveFt = 0.6;     // farther than this from the anchor = it moved
static const double kReanchorS = 1.0;  // a slow drift is not a move: the anchor follows after this long
static const double kHoldS = 2.0;      // "moving" lasts this long after the last move
inline void step(float* anchor, int64_t* anchorQ, int64_t* moveQ, const float* pos, int64_t now, int64_t freq) {
  if (!*anchorQ) { anchor[0] = pos[0]; anchor[1] = pos[1]; anchor[2] = pos[2]; *anchorQ = now; return; }
  const double dx = (double)pos[0] - anchor[0], dy = (double)pos[1] - anchor[1], dz = (double)pos[2] - anchor[2];
  const double d2 = dx * dx + dy * dy + dz * dz;
  if (d2 > kMoveFt * kMoveFt) { *moveQ = now; anchor[0] = pos[0]; anchor[1] = pos[1]; anchor[2] = pos[2]; *anchorQ = now; }
  else if ((double)(now - *anchorQ) > kReanchorS * (double)freq) { anchor[0] = pos[0]; anchor[1] = pos[1]; anchor[2] = pos[2]; *anchorQ = now; }
}
inline int moving(int64_t moveQ, int64_t now, int64_t freq) { return moveQ && (double)(now - moveQ) < kHoldS * (double)freq; }
}  // namespace ghostmove
