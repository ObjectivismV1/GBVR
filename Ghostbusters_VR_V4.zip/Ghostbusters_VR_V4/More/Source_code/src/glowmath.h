// 0.95 TV glow around the flat 2D screen (menus, cutscenes). Pure math, no Windows dependency; unit-tested in tests/test_glow.cpp.
//
// The flat screen floats in a black void. Around it sits one more, larger, see-through picture: a soft halo that takes its colour from the edges of the
// game's picture (like bias lighting behind a TV) plus a little of the picture's average colour. The game picture is shrunk on the graphics card to a
// grid of a few cells (flatglow.cpp), read back a few times a second, and turned into that halo here.
//
// Units: x / y are measured in screen WIDTHS from the screen centre (so the screen itself spans x -0.5 .. 0.5 and y -0.5/aspect .. 0.5/aspect).
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "vmath.h"

namespace glow {

enum { kRGBA8 = 0, kBGRA8 = 1, kRGB10A2 = 2 };
static const int kMaxCells = 32;

struct Grid {
  int w, h;                              // cells across / down
  float c[kMaxCells * kMaxCells * 3];    // RGB 0..1, row by row
  void clear() { w = h = 0; }
};

inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float smooth01(float t) { t = clampf(t, 0.0f, 1.0f); return t * t * (3.0f - 2.0f * t); }

// Pixels as the graphics card hands them back (w x h, `pitch` bytes per row) -> a grid of RGB floats. Returns 0 for a size or format it cannot read.
inline int decode(const uint8_t* src, unsigned pitch, int w, int h, int fmt, Grid* g) {
  if (!src || !g || w < 1 || h < 1 || w > kMaxCells || h > kMaxCells || fmt < 0 || fmt > 2) return 0;
  g->w = w; g->h = h;
  for (int y = 0; y < h; ++y) {
    const uint8_t* row = src + (size_t)y * pitch;
    for (int x = 0; x < w; ++x) {
      float r, gr, b;
      if (fmt == kRGB10A2) {
        const uint32_t v = (uint32_t)row[x * 4] | ((uint32_t)row[x * 4 + 1] << 8) | ((uint32_t)row[x * 4 + 2] << 16) | ((uint32_t)row[x * 4 + 3] << 24);
        r = (float)(v & 1023u) / 1023.0f; gr = (float)((v >> 10) & 1023u) / 1023.0f; b = (float)((v >> 20) & 1023u) / 1023.0f;
      } else if (fmt == kBGRA8) {
        b = row[x * 4] / 255.0f; gr = row[x * 4 + 1] / 255.0f; r = row[x * 4 + 2] / 255.0f;
      } else {
        r = row[x * 4] / 255.0f; gr = row[x * 4 + 1] / 255.0f; b = row[x * 4 + 2] / 255.0f;
      }
      float* o = &g->c[(y * w + x) * 3];
      o[0] = r; o[1] = gr; o[2] = b;
    }
  }
  return 1;
}

inline void fill_grid(Grid* g, int w, int h, float r, float gr, float b) {
  g->w = w; g->h = h;
  for (int i = 0; i < w * h; ++i) { g->c[i * 3] = r; g->c[i * 3 + 1] = gr; g->c[i * 3 + 2] = b; }
}

// Black bars (a letterboxed cutscene, a 4:3 picture on the 16:9 screen): cells at the edges that are black are skipped, so the halo takes the colour of the
// picture itself and not of the bars. At most 40 % of the grid from any edge.
struct Insets { int l, r, t, b; };
inline float cell_peak(const Grid& g, int x, int y) {
  const float* c = &g.c[(y * g.w + x) * 3];
  float m = c[0]; if (c[1] > m) m = c[1]; if (c[2] > m) m = c[2];
  return m;
}
inline Insets bars(const Grid& g) {
  Insets in = {0, 0, 0, 0};
  if (g.w < 3 || g.h < 3) return in;
  const float kBlack = 0.03f;
  float any = 0;
  for (int y = 0; y < g.h; ++y) for (int x = 0; x < g.w; ++x) { const float p = cell_peak(g, x, y); if (p > any) any = p; }
  if (any <= kBlack) return in;   // an all-black picture has no bars to skip
  const int maxX = (g.w * 2) / 5, maxY = (g.h * 2) / 5;
  auto rowDark = [&](int y) { for (int x = 0; x < g.w; ++x) if (cell_peak(g, x, y) > kBlack) return 0; return 1; };
  auto colDark = [&](int x) { for (int y = 0; y < g.h; ++y) if (cell_peak(g, x, y) > kBlack) return 0; return 1; };
  while (in.t < maxY && rowDark(in.t)) ++in.t;
  while (in.b < maxY && rowDark(g.h - 1 - in.b)) ++in.b;
  while (in.l < maxX && colDark(in.l)) ++in.l;
  while (in.r < maxX && colDark(g.w - 1 - in.r)) ++in.r;
  return in;
}

inline void mean_rgb(const Grid& g, const Insets& in, float* m) {
  m[0] = m[1] = m[2] = 0; int n = 0;
  for (int y = in.t; y < g.h - in.b; ++y) for (int x = in.l; x < g.w - in.r; ++x) { const float* c = &g.c[(y * g.w + x) * 3]; m[0] += c[0]; m[1] += c[1]; m[2] += c[2]; ++n; }
  if (n > 0) { m[0] /= n; m[1] /= n; m[2] /= n; }
}

// The picture's colour at u, v (0..1 across the part of the picture that is not a black bar), bilinear between cells.
inline void sample(const Grid& g, const Insets& in, double u, double v, float* rgb) {
  const double x0 = in.l, x1 = g.w - 1 - in.r, y0 = in.t, y1 = g.h - 1 - in.b;
  double fx = (x1 > x0) ? x0 + u * (x1 - x0) : (g.w - 1) * 0.5, fy = (y1 > y0) ? y0 + v * (y1 - y0) : (g.h - 1) * 0.5;
  if (fx < 0) fx = 0; if (fx > g.w - 1) fx = g.w - 1; if (fy < 0) fy = 0; if (fy > g.h - 1) fy = g.h - 1;
  int ix = (int)fx, iy = (int)fy;
  if (ix > g.w - 2) ix = g.w - 2; if (iy > g.h - 2) iy = g.h - 2; if (ix < 0) ix = 0; if (iy < 0) iy = 0;
  const float tx = (float)(fx - ix), ty = (float)(fy - iy);
  const int ix1 = (g.w > 1) ? ix + 1 : ix, iy1 = (g.h > 1) ? iy + 1 : iy;
  for (int k = 0; k < 3; ++k) {
    const float a = g.c[(iy * g.w + ix) * 3 + k], b = g.c[(iy * g.w + ix1) * 3 + k], c = g.c[(iy1 * g.w + ix) * 3 + k], d = g.c[(iy1 * g.w + ix1) * 3 + k];
    rgb[k] = (a + (b - a) * tx) * (1.0f - ty) + (c + (d - c) * tx) * ty;
  }
}

// ---- the halo picture --------------------------------------------------------------------------------------------
struct Look {
  double strength;   // 0..1 (the "TV glow" setting / 100)
  double reach;      // how far the halo reaches beyond each screen edge, in screen widths
  double aspect;     // screen width / height
  double edgeShare;  // 0..1 how much of the halo colour comes from the nearest picture edge (the rest: the picture's average)
  double peak;       // alpha right at the screen edge at strength 1
};
inline Look default_look(double strength, double aspect) { Look l; l.strength = strength; l.reach = 0.35; l.aspect = aspect; l.edgeShare = 0.7; l.peak = 0.5; return l; }

// The halo picture covers the screen plus `reach` on every side. Size in screen widths:
inline void quad_units(const Look& l, double* w, double* h) { *w = 1.0 + 2.0 * l.reach; *h = 1.0 / l.aspect + 2.0 * l.reach; }
inline void image_size(const Look& l, int baseW, int* iw, int* ih) {
  double w, h; quad_units(l, &w, &h);
  int ww = baseW, hh = (int)(baseW * h / w + 0.5);
  if (hh < 8) hh = 8;
  *iw = ww; *ih = hh;
}

// rgba: iw x ih x 4 floats, straight (not premultiplied) alpha. Inside the screen the picture is transparent (the screen covers it anyway).
inline void render_target(const Grid& g, const Look& l, int iw, int ih, float* rgba) {
  const Insets in = bars(g);
  float mean[3]; mean_rgb(g, in, mean);
  double qw, qh; quad_units(l, &qw, &qh);
  qh = qw * (double)ih / (double)iw;   // the overlay's real shape is the picture's own, so the cut-out for the screen lines up exactly
  const double halfW = 0.5, halfH = 0.5 / l.aspect;
  const float boost = 1.6f;
  for (int j = 0; j < ih; ++j) {
    const double y = (((double)j + 0.5) / ih - 0.5) * qh;
    for (int i = 0; i < iw; ++i) {
      const double x = (((double)i + 0.5) / iw - 0.5) * qw;
      const double ax = x < 0 ? -x : x, ay = y < 0 ? -y : y;
      const double dx = ax > halfW ? ax - halfW : 0.0, dy = ay > halfH ? ay - halfH : 0.0;
      const double d = vm::dsqrt(dx * dx + dy * dy);
      // colour of the nearest point on the screen edge
      double px = x < -halfW ? -halfW : (x > halfW ? halfW : x), py = y < -halfH ? -halfH : (y > halfH ? halfH : y);
      float edge[3];
      sample(g, in, px / (2.0 * halfW) + 0.5, py / (2.0 * halfH) + 0.5, edge);
      float* o = &rgba[((size_t)j * iw + i) * 4];
      float a = 0.0f;
      if (d > 0.0 && l.reach > 0.0) {
        const float t = (float)(d / l.reach);
        if (t < 1.0f) { const float s = 1.0f - smooth01(t); a = (float)(l.peak * l.strength) * s * s; }
      }
      for (int k = 0; k < 3; ++k) {
        float c = ((float)l.edgeShare * edge[k] + (1.0f - (float)l.edgeShare) * mean[k]) * boost;
        o[k] = clampf(c, 0.0f, 1.0f);
      }
      o[3] = clampf(a, 0.0f, 1.0f);
    }
  }
}

// 0.98 calm glow. The look: more of the picture's AVERAGE colour and less of the nearest edge, a little fainter, so no part of it jumps when a cutscene cuts.
inline Look steady_look(double strength, double aspect) { Look l = default_look(strength, aspect); l.edgeShare = 0.35; l.peak = 0.49; return l; }

// The readings are averaged over several seconds (time constant tau): `slow` moves toward the newest reading by dt / (tau + dt) of the way, so a flash
// or a quick cut changes the glow only a little and a lasting change in colour takes a few seconds. A new size of grid, or nothing yet, starts from the reading.
// dt is clamped to 0 .. 1 s (a long gap does not make one reading count for everything).
inline void blend_toward(Grid* slow, const Grid& reading, double dt, double tau) {
  if (!slow || reading.w < 1 || reading.h < 1) return;
  if (slow->w != reading.w || slow->h != reading.h) { *slow = reading; return; }
  if (!(dt > 0.0)) return;
  if (dt > 1.0) dt = 1.0;
  const float k = tau > 0.0 ? (float)(dt / (tau + dt)) : 1.0f;
  const int n = reading.w * reading.h * 3;
  for (int i = 0; i < n; ++i) slow->c[i] += (reading.c[i] - slow->c[i]) * k;
}

// cur moves toward target: k is the share of the way (0..1); no component moves by more than maxStep in one go (a white flash in the picture never
// makes the halo flash). Returns the largest remaining difference.
inline float ease(float* cur, const float* target, int n, float k, float maxStep) {
  float worst = 0;
  for (int i = 0; i < n; ++i) {
    float d = (target[i] - cur[i]) * k;
    if (d > maxStep) d = maxStep; if (d < -maxStep) d = -maxStep;
    cur[i] += d;
    float r = target[i] - cur[i]; if (r < 0) r = -r;
    if (r > worst) worst = r;
  }
  return worst;
}

// Bytes for the overlay. The alpha gets a little ordered noise (+-1 step) so the dark gradient does not show bands.
inline uint8_t dither_byte(float v, unsigned i, unsigned j, unsigned frame) {
  unsigned h = i * 73856093u ^ j * 19349663u ^ frame * 83492791u;
  h ^= h >> 13; h *= 1274126177u; h ^= h >> 16;
  const float n = ((float)(h & 255u) / 255.0f) - 0.5f;   // -0.5 .. 0.5
  int q = (int)(v * 255.0f + 0.5f + n);
  if (q < 0) q = 0; if (q > 255) q = 255;
  return (uint8_t)q;
}
inline void to_bytes(const float* rgba, int iw, int ih, uint8_t* out, unsigned frame) {
  for (int j = 0; j < ih; ++j)
    for (int i = 0; i < iw; ++i) {
      const float* p = &rgba[((size_t)j * iw + i) * 4];
      uint8_t* o = &out[((size_t)j * iw + i) * 4];
      for (int k = 0; k < 3; ++k) { int q = (int)(p[k] * 255.0f + 0.5f); o[k] = (uint8_t)(q < 0 ? 0 : (q > 255 ? 255 : q)); }
      o[3] = p[3] <= 0.0f ? 0 : dither_byte(p[3], (unsigned)i, (unsigned)j, frame);
    }
}


// ---- 1.1 the steady glow --------------------------------------------------------------------------------------------------------------------------
// The 1.0 glow was a picture that was re-sent to SteamVR about 15 times a second while it changed, and it followed the picture's brightness. Both made it flash.
// Now the halo picture is sent ONCE (white, with the soft edge fade as its see-through part) and everything that follows the picture is a single COLOUR
// handed to SteamVR as the layer's tint (no new picture). The colour keeps the hue of the picture's average and always the same brightness, so a dark scene and
// a bright scene glow equally; a nearly black picture keeps the default soft blue-white. The colour moves slowly (time constant tau, and never faster than
// maxPerSec per colour channel), so even a cut from a red room to a blue room is a drift of several seconds, never a flash.
struct Tint { float r, g, b; };
inline float tint_luma(const Tint& t) { return 0.2126f * t.r + 0.7152f * t.g + 0.0722f * t.b; }
static const float kTintLuma = 0.64f;   // every glow colour has this brightness (as far as full strength allows)
inline Tint default_tint() { Tint t = {0.50f, 0.66f, 0.95f}; return t; }
// m = the picture's average colour (0..1 per channel, black bars left out)
inline Tint ambient_target(const float m[3]) {
  const Tint d = default_tint();
  float mx = m[0] > m[1] ? m[0] : m[1];
  if (m[2] > mx) mx = m[2];
  if (!(mx > 0.0001f)) return d;                       // black (or not a number): the default
  const float w = smooth01(clampf((mx - 0.03f) / 0.10f, 0.0f, 1.0f));   // 0 for a black picture ... 1 from a mean of 0.13 up
  float hue[3];
  for (int k = 0; k < 3; ++k) hue[k] = 0.40f + 0.60f * clampf(m[k] / mx, 0.0f, 1.0f);   // the picture's hue, never harsher than 40 % white
  Tint t;
  t.r = d.r + (hue[0] - d.r) * w;
  t.g = d.g + (hue[1] - d.g) * w;
  t.b = d.b + (hue[2] - d.b) * w;
  // the same brightness for every hue: scaled so its luma is kTintLuma (a colour that would need more than full strength stays at full strength)
  const float L = tint_luma(t);
  float k = L > 0.01f ? kTintLuma / L : 1.0f;
  float big = t.r > t.g ? t.r : t.g; if (t.b > big) big = t.b;
  if (big * k > 1.0f) k = 1.0f / big;
  t.r *= k; t.g *= k; t.b *= k;
  return t;
}
// cur moves toward target by dt / (tau + dt) of the way, and no channel moves faster than maxPerSec. dt is clamped to 0 .. 0.25 s (a long gap is not one big step).
inline void follow_tint(Tint* cur, const Tint& target, double dt, double tau, double maxPerSec) {
  if (!cur || !(dt > 0.0)) return;
  if (dt > 0.25) dt = 0.25;
  const float k = tau > 0.0 ? (float)(dt / (tau + dt)) : 1.0f;
  const float cap = (float)(maxPerSec * dt);
  float* c = &cur->r; const float* t = &target.r;
  for (int i = 0; i < 3; ++i) {
    float d = (t[i] - c[i]) * k;
    if (d > cap) d = cap;
    if (d < -cap) d = -cap;
    c[i] += d;
  }
}
// ---- 1.7.151 the glow takes the colours of the picture's four corners ---------------------------------------------------
// "can the ambient light be the colour of the screen ... the colour of whatever is being played in the corner".
// The one white halo picture becomes four (top-left, top-right, bottom-left, bottom-right): the same halo with its see-through part multiplied by that
// corner's share. The shares of the four add up to 1 everywhere, so with four equal colours the glow looks like the single one. Each layer is sent ONCE
// and then only tinted (no new pictures: nothing flashes), with the colour of its own quarter of the game's picture.
// corner: 0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right. u, v: 0..1 across / down the halo picture.
inline float corner_weight(int corner, double u, double v) {
  const float su = smooth01((float)u), sv = smooth01((float)v);
  const float wu = (corner & 1) ? su : 1.0f - su, wv = (corner & 2) ? sv : 1.0f - sv;
  return wu * wv;
}
inline void corner_mask(const float* rgba, int iw, int ih, int corner, float* out) {
  for (int j = 0; j < ih; ++j) for (int i = 0; i < iw; ++i) {
    const float* p = &rgba[((size_t)j * iw + i) * 4]; float* o = &out[((size_t)j * iw + i) * 4];
    o[0] = p[0]; o[1] = p[1]; o[2] = p[2];
    o[3] = p[3] * corner_weight(corner, ((double)i + 0.5) / iw, ((double)j + 0.5) / ih);
  }
}
// 1.7.161: the colour of that corner's part of the picture (45 % of the width and height from the corner, black bars left out), the way a TV's ambient
// light picks it: bright and vivid cells count much more than dark grey ones, so a dark menu with orange writing glows orange, not grey or blue.
// The result has the hue of those cells and the corner's plain average brightness (so a dark corner still glows fainter).
inline void corner_mean(const Grid& g, const Insets& in, int corner, float* m) {
  m[0] = m[1] = m[2] = 0.0f;
  const int x0 = in.l, x1 = g.w - in.r, y0 = in.t, y1 = g.h - in.b;
  if (x1 <= x0 || y1 <= y0) return;
  int cw = ((x1 - x0) * 45 + 99) / 100, ch = ((y1 - y0) * 45 + 99) / 100;
  if (cw < 1) cw = 1; if (ch < 1) ch = 1;
  const int xa = (corner & 1) ? x1 - cw : x0, ya = (corner & 2) ? y1 - ch : y0;
  double plain[3] = {0, 0, 0}, vivid[3] = {0, 0, 0}, wsum = 0.0; int n = 0;
  for (int y = ya; y < ya + ch; ++y) for (int x = xa; x < xa + cw; ++x) {
    const float* c = &g.c[(y * g.w + x) * 3];
    if (!(c[0] == c[0] && c[1] == c[1] && c[2] == c[2])) continue;
    float mx = c[0] > c[1] ? c[0] : c[1]; if (c[2] > mx) mx = c[2];
    float mn = c[0] < c[1] ? c[0] : c[1]; if (c[2] < mn) mn = c[2];
    const double sat = mx > 0.0001f ? (double)(mx - mn) / mx : 0.0;
    const double w = ((double)mx + 0.02) * ((double)mx + 0.02) * (0.25 + sat);
    for (int k = 0; k < 3; ++k) { plain[k] += c[k]; vivid[k] += w * c[k]; }
    wsum += w; ++n;
  }
  if (n == 0) return;
  double pm = 0.0; for (int k = 0; k < 3; ++k) { plain[k] /= n; if (plain[k] > pm) pm = plain[k]; }
  if (!(wsum > 1e-9)) { for (int k = 0; k < 3; ++k) m[k] = (float)plain[k]; return; }
  double vm_ = 0.0; for (int k = 0; k < 3; ++k) { vivid[k] /= wsum; if (vivid[k] > vm_) vm_ = vivid[k]; }
  if (!(vm_ > 1e-6)) { for (int k = 0; k < 3; ++k) m[k] = (float)plain[k]; return; }
  // brightness: between the plain mean and the bright cells' level (a few bright things in a dark corner still light it a little)
  const double level = 0.65 * pm + 0.35 * vm_;
  for (int k = 0; k < 3; ++k) m[k] = (float)(vivid[k] / vm_ * level);
}
// a dark corner glows a faint neutral light (1.7.161: no longer the blue default, which made dark menus and dark scenes glow blue)
inline Tint neutral_tint() { Tint t = {0.62f, 0.62f, 0.66f}; return t; }
// The corner's glow colour: the picture's own hue (at most 12 % white mixed in), and its brightness follows the picture (a dark corner glows fainter,
// never off: 45 % .. 100 % of the usual brightness). A black corner keeps a faint neutral light.
inline Tint corner_target(const float m[3]) {
  const Tint d = neutral_tint();
  float mx = m[0] > m[1] ? m[0] : m[1];
  if (m[2] > mx) mx = m[2];
  const float kDim = 0.45f;
  const int finite = m[0] == m[0] && m[1] == m[1] && m[2] == m[2];
  if (!finite || !(mx > 0.0001f) || !(mx < 100.0f)) { const float L0 = tint_luma(d); const float k0 = kTintLuma * kDim / L0; Tint t = {d.r * k0, d.g * k0, d.b * k0}; return t; }
  const float w = smooth01(clampf((mx - 0.02f) / 0.08f, 0.0f, 1.0f));
  float hue[3];
  for (int k = 0; k < 3; ++k) hue[k] = 0.12f + 0.88f * clampf(m[k] / mx, 0.0f, 1.0f);
  Tint t;
  t.r = d.r + (hue[0] - d.r) * w; t.g = d.g + (hue[1] - d.g) * w; t.b = d.b + (hue[2] - d.b) * w;
  const float L = tint_luma(t);
  const float want = kTintLuma * (kDim + (1.0f - kDim) * smooth01(clampf(mx / 0.45f, 0.0f, 1.0f)));
  float k = L > 0.01f ? want / L : 1.0f;
  float big = t.r > t.g ? t.r : t.g; if (t.b > big) big = t.b;
  if (big * k > 1.0f) k = 1.0f / big;
  t.r *= k; t.g *= k; t.b *= k;
  return t;
}
// the fade-in of the glow and of the screen when they appear: 0 .. 1 over `secs` seconds, eased
inline float fade_in(double secsSinceShown, double secs) {
  if (!(secsSinceShown > 0.0)) return 0.0f;
  if (!(secs > 0.0) || secsSinceShown >= secs) return 1.0f;
  return smooth01((float)(secsSinceShown / secs));
}
// the bend of the flat screen: pct 0 = flat, 100 = wrapped around you exactly (the screen is part of a circle around the viewer: width = 2 pi r c, r = distance).
// OpenVR's curvature is that same c (0 flat ... 1 a full cylinder). Never more than 0.45 (a half circle would turn the edges away).
inline float screen_curvature(double pct, double widthM, double distM) {
  if (!(widthM > 0.1) || !(distM > 0.1) || !(pct > 0.0)) return 0.0f;
  double c = (pct / 100.0) * widthM / (6.283185307179586 * distM);
  if (c > 0.45) c = 0.45;
  return (float)c;
}

}  // namespace glow
