// 0.79 the hands hold on. Pure math, no Windows dependency; unit-tested in tests/test_grip.cpp.
//
// 1. The gun hand keeps ONE grip on the gun. Outside combat the game carries the gun differently (the 0.78 log: the animation's hand was 55-77 cm
//    from the wand in the hotel lobby, 9-11 cm in a fight) and the 0.75 placement copied whatever the animation did, so the hand left the gun and
//    the arm flailed. Now the grip is LEARNED while the animation really holds the gun (hand within kHeldFt of the wand's origin): the hand's place
//    and turn in the wand's own frame, averaged slowly. From then on the hand is put there whatever the game's animation does, and the grip is
//    saved in the settings so the next session starts with it.
// 2. A hand that has no gun to copy (the left hand, or the gun hand before any grip is known) is turned by its own finger bones: the line from
//    the wrist to the middle knuckle points along the controller (tilted down by the hand angle) and the line from the little-finger knuckle to the
//    index knuckle runs up the controller's handle. Both lines fixed = the whole turn, roll included (0.78 only swung the hand to point forward).
// Rotations are 3x3 matrices in column form (v' = Q v), like armmath.h.
#pragma once
#include "vmath.h"
#include "weightmath.h"

namespace grip {

static const double kHeldFt = 0.55;   // the animation's hand within this of the wand's origin = it holds the gun (fight: 0.30-0.36 ft, lobby: 1.8-2.5 ft)

inline double dot(const double* a, const double* b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
inline double len(const double* a) { return vm::dsqrt(dot(a, a)); }

// an orthonormal frame (columns) whose first axis is along a and whose second lies in the plane of a and c. 0 when a and c are (almost) parallel.
inline int frame(const double* a, const double* c, double* F) {
  const double la = len(a);
  if (!(la > 1e-9)) return 0;
  double x[3] = {a[0] / la, a[1] / la, a[2] / la};
  const double d = dot(c, x);
  double y[3] = {c[0] - x[0] * d, c[1] - x[1] * d, c[2] - x[2] * d};
  const double ly = len(y);
  if (!(ly > 0.2 * len(c)) || !(ly > 1e-9)) return 0;   // c must stand at least ~12 degrees off a
  for (int i = 0; i < 3; ++i) y[i] /= ly;
  const double z[3] = {x[1] * y[2] - x[2] * y[1], x[2] * y[0] - x[0] * y[2], x[0] * y[1] - x[1] * y[0]};
  for (int i = 0; i < 3; ++i) { F[i * 3 + 0] = x[i]; F[i * 3 + 1] = y[i]; F[i * 3 + 2] = z[i]; }
  return 1;
}

// the rotation Q (column form) that takes the frame Fc onto Ft: Q = Ft Fc^T
inline void onto(const double* Ft, const double* Fc, double* Q) {
  double T[9];
  weight::transpose3(Fc, T);
  weight::mul3(Ft, T, Q);
}

// where a hand that holds a controller has its knuckle line (a) and its handle line (c), from the controller's forward and up (unit vectors)
// and the hand angle (radians; the knuckles point this far below the controller's forward, the handle leans this far forward of its up)
inline void hand_lines(const double* fwd, const double* up, double angle, double* a, double* c) {
  double s, k;
  vm::dsincos(angle, &s, &k);
  for (int i = 0; i < 3; ++i) { a[i] = fwd[i] * k - up[i] * s; c[i] = up[i] * k + fwd[i] * s; }
}

// a vector given in a bone matrix's rows (row-vector form: v_model = sum l[k] * row_k) and back
inline void to_rows(const float* B, const double* l, double* v) {
  for (int i = 0; i < 3; ++i) v[i] = l[0] * B[0 * 4 + i] + l[1] * B[1 * 4 + i] + l[2] * B[2 * 4 + i];
}
inline int from_rows(const float* B, const double* v, double* l) {
  for (int k = 0; k < 3; ++k) {
    const double r[3] = {B[k * 4], B[k * 4 + 1], B[k * 4 + 2]};
    const double n2 = dot(r, r);
    if (!(n2 > 1e-12)) return 0;
    l[k] = dot(v, r) / n2;
  }
  return 1;
}

// quaternion (w, x, y, z) <-> rotation matrix (column form), for the settings file
inline void quat_from(const double* m, double* q) {
  const double tr = m[0] + m[4] + m[8];
  if (tr > 0) {
    const double s = vm::dsqrt(tr + 1.0) * 2.0;
    q[0] = 0.25 * s; q[1] = (m[7] - m[5]) / s; q[2] = (m[2] - m[6]) / s; q[3] = (m[3] - m[1]) / s;
  } else if (m[0] > m[4] && m[0] > m[8]) {
    const double s = vm::dsqrt(1.0 + m[0] - m[4] - m[8]) * 2.0;
    q[0] = (m[7] - m[5]) / s; q[1] = 0.25 * s; q[2] = (m[1] + m[3]) / s; q[3] = (m[2] + m[6]) / s;
  } else if (m[4] > m[8]) {
    const double s = vm::dsqrt(1.0 + m[4] - m[0] - m[8]) * 2.0;
    q[0] = (m[2] - m[6]) / s; q[1] = (m[1] + m[3]) / s; q[2] = 0.25 * s; q[3] = (m[5] + m[7]) / s;
  } else {
    const double s = vm::dsqrt(1.0 + m[8] - m[0] - m[4]) * 2.0;
    q[0] = (m[3] - m[1]) / s; q[1] = (m[2] + m[6]) / s; q[2] = (m[5] + m[7]) / s; q[3] = 0.25 * s;
  }
  const double l = vm::dsqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
  if (l > 1e-12) for (int i = 0; i < 4; ++i) q[i] /= l;
  if (q[0] < 0) for (int i = 0; i < 4; ++i) q[i] = -q[i];
}
inline int mat_from(const double* q0, double* m) {
  double q[4] = {q0[0], q0[1], q0[2], q0[3]};
  const double l = vm::dsqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
  if (!(l > 0.5)) return 0;
  for (int i = 0; i < 4; ++i) q[i] /= l;
  const double w = q[0], x = q[1], y = q[2], z = q[3];
  m[0] = 1 - 2 * (y * y + z * z); m[1] = 2 * (x * y - z * w);     m[2] = 2 * (x * z + y * w);
  m[3] = 2 * (x * y + z * w);     m[4] = 1 - 2 * (x * x + z * z); m[5] = 2 * (y * z - x * w);
  m[6] = 2 * (x * z - y * w);     m[7] = 2 * (y * z + x * w);     m[8] = 1 - 2 * (x * x + y * y);
  return 1;
}

// The learned grip: the hand's place (feet) and turn in the wand's frame Wa (columns = the wand's axes in game world, orthonormal).
struct Learn {
  int n;              // samples taken
  double pos[3];      // hand origin minus wand origin, in the wand frame
  double rel[9];      // Wa^T * hand axes
  void reset() { n = 0; for (int i = 0; i < 3; ++i) pos[i] = 0; weight::ident(rel); }
  // one sample: d = hand origin - wand origin (world), G = the hand's axes (columns, world). The first sample is taken as it is, then a slow average
  // (the animation's hand bobs a little while walking and firing: the average is the steady grip).
  void add(const double* Wa, const double* d, const double* G) {
    double WT[9], p[3], r[9];
    weight::transpose3(Wa, WT);
    for (int i = 0; i < 3; ++i) p[i] = WT[i * 3] * d[0] + WT[i * 3 + 1] * d[1] + WT[i * 3 + 2] * d[2];
    weight::mul3(WT, G, r);
    const double a = n == 0 ? 1.0 : (n < 30 ? 1.0 / (double)(n + 1) : 0.03);
    for (int i = 0; i < 3; ++i) pos[i] += a * (p[i] - pos[i]);
    for (int i = 0; i < 9; ++i) rel[i] += a * (r[i] - rel[i]);
    weight::orthonormalize(rel);
    ++n;
  }
  // the hand's offset (world) and axes (columns, world) for the wand frame Wa
  void apply(const double* Wa, double* d, double* G) const {
    for (int i = 0; i < 3; ++i) d[i] = Wa[i * 3] * pos[0] + Wa[i * 3 + 1] * pos[1] + Wa[i * 3 + 2] * pos[2];
    weight::mul3(Wa, rel, G);
  }
};

// the wand frame from a wand world matrix (row-vector form: rows 0..2 are its axes, maybe scaled): columns = the normalised rows. 0 = degenerate.
inline int wand_frame(const float* W, double* Wa) {
  for (int r = 0; r < 3; ++r) {
    const double v[3] = {W[r * 4], W[r * 4 + 1], W[r * 4 + 2]};
    const double l = len(v);
    if (!(l > 1e-6)) return 0;
    for (int i = 0; i < 3; ++i) Wa[i * 3 + r] = v[i] / l;
  }
  weight::orthonormalize(Wa);
  return 1;
}

}  // namespace grip
