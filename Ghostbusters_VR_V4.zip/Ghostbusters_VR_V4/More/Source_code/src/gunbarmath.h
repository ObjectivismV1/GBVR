// 1.7.37 the life bar on the gun: pure math (tests/test_gunbar.cpp).
// A thin strip on top of the gun that shows the player's health: green when well, yellow in the middle, red when low. No numbers.
#pragma once
#include "vmath.h"
#include "handmath.h"
namespace gunbar {
// health fraction from the game's two numbers (current, maximum); -1 = not plausible (the caller draws nothing)
inline double fraction(double cur, double mx) {
  if (!vm::is_finite_f((float)cur) || !vm::is_finite_f((float)mx)) return -1.0;
  double f = (mx > 0.001) ? cur / mx : cur;
  if (f < -0.01 || f > 1.5) return -1.0;
  return f < 0.0 ? 0.0 : f > 1.0 ? 1.0 : f;
}
// Show player health on every held gun style. Inventory IDs 4-6 are
// trap/PKE/light and have no gun barrel for the strip.
inline int show_for_item(int fresh, int item) { return fresh && (item == 1 || item == 2 || item == 3 || item == 7); }
// colour of the fill: 1.0 = green, 0.5 = yellow, 0.0 = red (linear blends)
inline void colour(double f, float* rgb) {
  static const float g[3] = {0.15f, 0.90f, 0.25f}, y[3] = {0.95f, 0.80f, 0.10f}, r[3] = {0.95f, 0.12f, 0.08f};
  if (f < 0.0) f = 0.0; if (f > 1.0) f = 1.0;
  const float* a; const float* b; double t;
  if (f >= 0.5) { a = y; b = g; t = (f - 0.5) * 2.0; } else { a = r; b = y; t = f * 2.0; }
  for (int i = 0; i < 3; ++i) rgb[i] = (float)((double)a[i] + ((double)b[i] - (double)a[i]) * t);
}
// glow scale: steady, a slow pulse below 25 % so a low bar is noticed without flashing
inline float glow(double f, double tSec) {
  if (f >= 0.25) return 0.80f;
  double s, c; vm::dsincos(tSec * 4.0, &s, &c);
  return (float)(0.70 + 0.30 * (0.5 + 0.5 * s));
}
// the fill's length in metres for a bar of `lenM`: at least 4 mm while there is any health
inline double fill_len(double f, double lenM) {
  if (f <= 0.0) return 0.0;
  const double l = lenM * f;
  return l < 0.004 ? 0.004 : l;
}

// ---- 1.7.157 the life bar as a tube of glowing liquid, with a beating heart ---------------------------------------------------
// "make the health bar and heart on the gun ... with an effect like green liquid, it changes colour and goes down; make sure it looks good".
// The same place on the gun as the 1.7.37 strip (the same three offsets), now: a dark cradle with two metal collars, a glass tube, and in it a liquid
// that glows slime green when you are well, turns yellow, amber and red as it drains toward the heart at the rear end, with a moving surface, a few
// bubbles and a light streak along the top. A hit makes the lost part flash pale for a moment and the surface slosh, then it settles. The heart beats:
// calmly at full health, fast when you are nearly out, and stops (grey) at zero. Pure math: the state, the colours and every vertex (tests/test_gunliquid.cpp).

// what is shown (the game's number jumps; the liquid does not)
struct Liquid {
  int have;
  double shown;     // level drawn, 0..1
  double lost;      // the pale "just lost" part ends here (>= shown)
  double lostHold;  // seconds the pale part still waits before it shrinks
  double slosh;     // 0..1, set by a hit, dies away
  double t;         // seconds, for the surface, the bubbles
  double beat;      // heart phase, 0..1 per beat
  double target;    // the health of the last step (a hit = the health fell since then)
  // 1.7.162 liquid physics (the gun's tube only; the ghosts' vials never step these, so they stay 0): the surface's tilt in the tube (z change per metre
  // of x and of y across the tube), its speed, and the controller's last position / speed / smoothed acceleration in the room
  double sx, sy, vx, vy, agit;
  double pp[3], pv[3], pa[3]; int phys;
  void reset() { have = 0; shown = lost = target = 1.0; lostHold = slosh = t = beat = 0.0; reset_phys(); }
  void reset_phys() { sx = sy = vx = vy = agit = 0.0; for (int i = 0; i < 3; ++i) pp[i] = pv[i] = pa[i] = 0.0; phys = 0; }
};
inline double clamp01d(double v) { return v < 0.0 ? 0.0 : v > 1.0 ? 1.0 : v; }
inline double heart_bpm(double f) { return 62.0 + (1.0 - clamp01d(f)) * 88.0; }   // 62 a minute at full health, 150 at the end
// One step. frac: the game's health 0..1; dt: seconds (any size: clamped).
inline void step(Liquid* s, double frac, double dt) {
  frac = (frac == frac) ? clamp01d(frac) : 0.0;
  if (!(dt > 0.0)) dt = 0.0; if (dt > 0.25) dt = 0.25;
  if (!s->have) { s->have = 1; s->shown = s->lost = s->target = frac; s->lostHold = 0.0; s->slosh = 0.0; s->t = 0.0; s->beat = 0.0; return; }
  const double fell = s->target - frac;   // a hit, once: the pale part starts at the level shown now, the surface sloshes
  s->target = frac;
  if (fell > 0.01) {
    if (s->lost <= s->shown + 1e-9) s->lost = s->shown;
    s->lostHold = 0.35;
    const double k = s->slosh + fell * 4.0; s->slosh = k > 1.0 ? 1.0 : k;
  }
  s->t += dt; if (s->t > 3600.0) s->t -= 3600.0;
  if (frac < s->shown) {            // a loss: the level runs down quickly (about a fifth of a second), the lost part is remembered
    const double a = 1.0 - 1.0 / (1.0 + dt / 0.16);
    s->shown += (frac - s->shown) * a;
    if (s->shown - frac < 0.002) s->shown = frac;
  } else if (frac > s->shown) {     // healing: it rises gently (half a second)
    const double a = 1.0 - 1.0 / (1.0 + dt / 0.45);
    s->shown += (frac - s->shown) * a;
    if (frac - s->shown < 0.002) s->shown = frac;
  }
  if (s->lost < s->shown) s->lost = s->shown;
  if (s->lostHold > 0.0) s->lostHold -= dt;
  else if (s->lost > s->shown) { const double a = 1.0 - 1.0 / (1.0 + dt / 0.30); s->lost += (s->shown - s->lost) * a; if (s->lost - s->shown < 0.002) s->lost = s->shown; }
  s->slosh *= 1.0 / (1.0 + dt / 0.55); if (s->slosh < 0.002) s->slosh = 0.0;
  if (frac > 0.0) { s->beat += dt * heart_bpm(frac) / 60.0; s->beat -= (double)(long)s->beat; } else s->beat = 0.0;
}
// the liquid's colour: slime green, yellow, amber, red
inline void liquid_colour(double f, float* rgb) {
  static const double k[4][4] = {{0.00, 1.00, 0.08, 0.05}, {0.22, 1.00, 0.42, 0.04}, {0.50, 0.92, 0.88, 0.08}, {0.78, 0.18, 1.00, 0.22}};   // level, r, g, b
  f = (f == f) ? clamp01d(f) : 0.0;
  int i = 0; while (i < 2 && f > k[i + 1][0]) ++i;
  double u = (f - k[i][0]) / (k[i + 1][0] - k[i][0]); u = clamp01d(u);
  for (int c = 0; c < 3; ++c) rgb[c] = (float)(k[i][1 + c] + (k[i + 1][1 + c] - k[i][1 + c]) * u);
}
// the heart's size factor over one beat (phase 0..1): two quick swells ("lub-dub"), then rest. 1 = resting size.
inline double heart_scale(double phase) {
  phase -= (double)(long)phase; if (phase < 0.0) phase += 1.0;
  auto bump = [](double x, double c, double w) { const double d = (x - c) / w; return d > -1.0 && d < 1.0 ? (1.0 - d * d) * (1.0 - d * d) : 0.0; };
  return 1.0 + 0.17 * bump(phase, 0.10, 0.10) + 0.10 * bump(phase, 0.32, 0.11);
}
// 0..1 how hard the heart is "on" this instant (for its brightness)
inline double heart_pulse(double phase) { return (heart_scale(phase) - 1.0) / 0.17; }
// the heart's outline, point i of n (i = 0 is the notch at the top), in units where the heart is about 2 wide and 2 tall, centre near 0
inline void heart_point(int i, int n, double* x, double* y) {
  const double t = 2.0 * vm::kPi * (double)i / (double)n;
  double s1, c1, s2, c2, s3, c3, s4, c4;
  vm::dsincos(t, &s1, &c1); vm::dsincos(2.0 * t, &s2, &c2); vm::dsincos(3.0 * t, &s3, &c3); vm::dsincos(4.0 * t, &s4, &c4);
  *x = (16.0 * s1 * s1 * s1) / 16.0;
  *y = (13.0 * c1 - 5.0 * c2 - 2.0 * c3 - c4 + 2.5) / 16.0;   // + 2.5: the middle of the shape at 0
}
// 1.7.162 the liquid inside the gun's tube moves with the gun. pose = the gun's 3x4 pose in the room (row-major: rotation columns = the gun's x/y/z axes,
// last column = position, metres, y up). The surface stays level with the room's "down", leans back when you swing or jerk the gun, overshoots and settles
// like water (about 2.2 sloshes a second, dying away in 2-3 s). The health level itself never changes: only the surface's shape.
// A tracking jump (recentre, lost tracking: > 0.5 m in a step) or anything not a number starts the motion again calm. dt any size (clamped, sub-stepped).
static const double kSloshHz = 1.5, kSloshDamp = 0.45, kMaxTilt = 1.2;   // 1.7.166 "very unsteady, flickers": a thick, calm liquid (was 2.0 Hz, 0.15, 2.6: it never stopped moving while you aim)   // 1.7.163: a little slower and calmer (smoother)
inline void step_phys(Liquid* s, const float* pose, double dt) {
  if (!s || !pose) return;
  for (int i = 0; i < 12; ++i) if (!(pose[i] == pose[i]) || pose[i] > 1e5f || pose[i] < -1e5f) { s->reset_phys(); return; }
  if (!(dt > 0.0)) return; if (dt > 0.25) dt = 0.25;
  const double p[3] = {pose[3], pose[7], pose[11]};
  double a[3] = {0, 0, 0};
  if (s->phys >= 1) {
    double v[3]; double jump = 0.0;
    for (int i = 0; i < 3; ++i) { v[i] = (p[i] - s->pp[i]) / dt; jump += (p[i] - s->pp[i]) * (p[i] - s->pp[i]); }
    if (jump > 0.25 || dt > 0.2) { for (int i = 0; i < 3; ++i) { s->pp[i] = p[i]; s->pv[i] = 0.0; s->pa[i] = 0.0; } s->phys = 1; return; }   // a jump or a long gap: no fake shove
    if (s->phys >= 2) for (int i = 0; i < 3; ++i) a[i] = (v[i] - s->pv[i]) / dt;
    for (int i = 0; i < 3; ++i) s->pv[i] = v[i];
    s->phys = 2;
  } else s->phys = 1;
  for (int i = 0; i < 3; ++i) s->pp[i] = p[i];
  // tracking noise: the acceleration is smoothed (40 ms) and capped (4 g)
  const double k = dt / (0.12 + dt);   // 1.7.166: 120 ms (1.7.163: 60): aiming jitter no longer moves the surface
  double am = 0.0;
  for (int i = 0; i < 3; ++i) { s->pa[i] += (a[i] - s->pa[i]) * k; am += s->pa[i] * s->pa[i]; }
  am = vm::dsqrt(am);
  const double cap = 40.0;
  const double sc = am > cap ? cap / am : 1.0;
  // what the liquid feels: gravity minus the gun's acceleration, in the gun's own axes
  const double ge[3] = {-s->pa[0] * sc, -9.81 - s->pa[1] * sc, -s->pa[2] * sc};
  double g[3];
  for (int c = 0; c < 3; ++c) g[c] = (double)pose[c] * ge[0] + (double)pose[4 + c] * ge[1] + (double)pose[8 + c] * ge[2];
  const double gl = vm::dsqrt(g[0] * g[0] + g[1] * g[1] + g[2] * g[2]);
  if (!(gl > 1e-6)) return;
  for (int c = 0; c < 3; ++c) g[c] /= gl;
  // the surface at right angles to that: z = level - (gx x + gy y) / gz, softened where the tube lies flat (gz near 0) so it never flips
  const double kk = g[2] / (g[2] * g[2] + 0.35);   // 1.7.166: softer (0.10 made an ordinary aim 15 deg up tilt the surface a long way)
  double tx = -g[0] * kk, ty = -g[1] * kk;
  if (tx > kMaxTilt) tx = kMaxTilt; if (tx < -kMaxTilt) tx = -kMaxTilt; if (ty > kMaxTilt) ty = kMaxTilt; if (ty < -kMaxTilt) ty = -kMaxTilt;
  // a damped spring toward it (sub-steps of at most 1/240 s)
  const double w = 2.0 * vm::kPi * kSloshHz;
  int n = (int)(dt * 240.0) + 1; if (n > 64) n = 64;
  const double h = dt / n;
  for (int i = 0; i < n; ++i) {
    s->vx += (w * w * (tx - s->sx) - 2.0 * kSloshDamp * w * s->vx) * h; s->sx += s->vx * h;
    s->vy += (w * w * (ty - s->sy) - 2.0 * kSloshDamp * w * s->vy) * h; s->sy += s->vy * h;
  }
  if (s->sx > kMaxTilt * 1.4) { s->sx = kMaxTilt * 1.4; s->vx = 0; } if (s->sx < -kMaxTilt * 1.4) { s->sx = -kMaxTilt * 1.4; s->vx = 0; }
  if (s->sy > kMaxTilt * 1.4) { s->sy = kMaxTilt * 1.4; s->vy = 0; } if (s->sy < -kMaxTilt * 1.4) { s->sy = -kMaxTilt * 1.4; s->vy = 0; }
  // a hard swing also stirs the surface's ripple (the same wave a hit makes) and speeds the bubbles up
  const double stir = am * sc > 12.0 ? (am * sc - 12.0) / 30.0 : 0.0;   // 1.7.166: only a real swing (over about 1.2 g) stirs it
  s->agit += (stir - s->agit) * (stir > s->agit ? dt / (0.05 + dt) : dt / (0.8 + dt));
  if (s->agit > 1.0) s->agit = 1.0;
  if (s->agit * 0.6 > s->slosh) s->slosh = s->agit * 0.6;
}
struct Layout { float xc, yc, zc; float lenM; };   // the old strip's centre and length
enum { kSeg = 20, kHeartN = 32, kMaxVerts = 4200 };   // 1.7.163: 20 sides (was 12: the tube showed flat faces); 4200 vertices   // 1.7.161: 1100 -> 2600 (the housing, straps, screws and lamp)
inline void vput(hand::Mesh* m, float x, float y, float z, float nx, float ny, float nz, const float* rgb, float k, float em) {
  if (m->n >= m->cap) return;
  hand::Vertex& o = m->v[m->n++];
  o.p[0] = x; o.p[1] = y; o.p[2] = z; o.n[0] = nx; o.n[1] = ny; o.n[2] = nz;
  for (int c = 0; c < 3; ++c) { float q = rgb[c] * k; o.c[c] = q < 0.0f ? 0.0f : q > 1.0f ? 1.0f : q; }
  o.c[3] = em;
}
// a tube along z between two rings; each ring has its own z per corner (zA[i], zB[i]) and brightness (kA, kB); shade(angle) makes the top brighter
inline void tube(hand::Mesh* m, float cx, float cy, float r, const float* zA, const float* zB, const float* rgb, float kA, float kB, float em, float topGain) {
  for (int i = 0; i < kSeg; ++i) {
    const int j = (i + 1) % kSeg;
    double s0, c0, s1, c1; vm::dsincos(2.0 * vm::kPi * i / kSeg, &s0, &c0); vm::dsincos(2.0 * vm::kPi * j / kSeg, &s1, &c1);
    const float sh0 = 1.0f - topGain + topGain * (float)(0.5 + 0.5 * s0), sh1 = 1.0f - topGain + topGain * (float)(0.5 + 0.5 * s1);
    const float x0 = cx + r * (float)c0, y0 = cy + r * (float)s0, x1 = cx + r * (float)c1, y1 = cy + r * (float)s1;
    vput(m, x0, y0, zA[i], (float)c0, (float)s0, 0, rgb, kA * sh0, em); vput(m, x1, y1, zA[j], (float)c1, (float)s1, 0, rgb, kA * sh1, em); vput(m, x1, y1, zB[j], (float)c1, (float)s1, 0, rgb, kB * sh1, em);
    vput(m, x0, y0, zA[i], (float)c0, (float)s0, 0, rgb, kA * sh0, em); vput(m, x1, y1, zB[j], (float)c1, (float)s1, 0, rgb, kB * sh1, em); vput(m, x0, y0, zB[i], (float)c0, (float)s0, 0, rgb, kB * sh0, em);
  }
}
// a disc closing a ring (fan from a centre at zc)
inline void cap(hand::Mesh* m, float cx, float cy, float r, const float* zr, float zc, float nz, const float* rgb, float kRim, float kMid, float em) {
  for (int i = 0; i < kSeg; ++i) {
    const int j = (i + 1) % kSeg;
    double s0, c0, s1, c1; vm::dsincos(2.0 * vm::kPi * i / kSeg, &s0, &c0); vm::dsincos(2.0 * vm::kPi * j / kSeg, &s1, &c1);
    vput(m, cx, cy, zc, 0, 0, nz, rgb, kMid, em);
    vput(m, cx + r * (float)c0, cy + r * (float)s0, zr[i], 0, 0, nz, rgb, kRim, em);
    vput(m, cx + r * (float)c1, cy + r * (float)s1, zr[j], 0, 0, nz, rgb, kRim, em);
  }
}
// 1.7.161: a ring lying flat (in the x-z plane, facing up) between radius r0 and r1 at height y, and its outer wall down to y - wall
inline void flat_ring(hand::Mesh* m, float cx, float y, float cz, float r0, float r1, float wall, int seg, const float* rgb, float kIn, float kOut, float em) {
  for (int i = 0; i < seg; ++i) {
    double s0, c0, s1, c1; vm::dsincos(2.0 * vm::kPi * i / seg, &s0, &c0); vm::dsincos(2.0 * vm::kPi * (i + 1) / seg, &s1, &c1);
    const float ax = cx + r0 * (float)c0, az = cz + r0 * (float)s0, bx = cx + r0 * (float)c1, bz = cz + r0 * (float)s1;
    const float Ax = cx + r1 * (float)c0, Az = cz + r1 * (float)s0, Bx = cx + r1 * (float)c1, Bz = cz + r1 * (float)s1;
    vput(m, ax, y, az, 0, 1, 0, rgb, kIn, em); vput(m, Bx, y, Bz, 0, 1, 0, rgb, kOut, em); vput(m, bx, y, bz, 0, 1, 0, rgb, kIn, em);
    vput(m, ax, y, az, 0, 1, 0, rgb, kIn, em); vput(m, Ax, y, Az, 0, 1, 0, rgb, kOut, em); vput(m, Bx, y, Bz, 0, 1, 0, rgb, kOut, em);
    if (wall > 0.0f) {
      vput(m, Ax, y, Az, (float)c0, 0, (float)s0, rgb, kOut * 0.85f, em); vput(m, Bx, y - wall, Bz, (float)c1, 0, (float)s1, rgb, kOut * 0.55f, em); vput(m, Bx, y, Bz, (float)c1, 0, (float)s1, rgb, kOut * 0.85f, em);
      vput(m, Ax, y, Az, (float)c0, 0, (float)s0, rgb, kOut * 0.85f, em); vput(m, Ax, y - wall, Az, (float)c0, 0, (float)s0, rgb, kOut * 0.55f, em); vput(m, Bx, y - wall, Bz, (float)c1, 0, (float)s1, rgb, kOut * 0.55f, em);
    }
  }
}
// a box with a lit colour and a lighter bevel line along its two top long edges (machined metal catches the light there)
inline void metal_bar(hand::Mesh* m, float cx, float cy, float cz, float hx, float hy, float hz, const float* col, const float* edge) {
  const float c4[4] = {col[0], col[1], col[2], 0}, e4[4] = {edge[0], edge[1], edge[2], 0};
  m->box(cx, cy, cz, hx, hy, hz, c4);
  const float t = hy * 0.22f < 0.00035f ? hy * 0.22f : 0.00035f;
  m->box(cx - hx + t, cy + hy - t * 0.5f, cz, t, t * 0.6f, hz * 0.995f, e4);
  m->box(cx + hx - t, cy + hy - t * 0.5f, cz, t, t * 0.6f, hz * 0.995f, e4);
}
// Everything, in the gun's own space (grip at the origin, barrel along -z, up +y; metres). Returns the number of vertices written.
// Emissive colours are final (draw with an emissive scale of 1).
// 1.7.161 "blend in more with the gun, a realistic look": the tube now sits in a gun-metal channel bolted to the gun (rails, machined end blocks,
// steel straps round the glass, four screws), the empty glass is dark smoked glass with one long reflection, the liquid glows softer and deeper,
// and the heart is an indicator lamp: a steel bezel, a dark red lens that lights up with each beat, a small heart under the lens.
inline int build(hand::Mesh* m, const Layout& L, const Liquid& s) {
  const int n0 = m->n;
  const float len = L.lenM, half = len * 0.5f;
  const float zRear = L.zc + half, zFront = L.zc - half;          // rear = toward you (the indicator's end), front = toward the muzzle
  const float rL = 0.0043f, cy = L.yc + 0.0052f;                 // liquid / glass radius, tube axis height
  const double shown = clamp01d(s.shown), lost = clamp01d(s.lost < s.shown ? s.shown : s.lost);
  float rgb[3]; liquid_colour(shown, rgb);
  const double pulse = heart_pulse(s.beat);
  const float low = shown < 0.25 ? (float)(0.74 + 0.26 * pulse) : 1.0f;   // nearly out: the liquid throbs with the heart
  static const float gun[3] = {0.036f, 0.038f, 0.042f}, gunEdge[3] = {0.080f, 0.084f, 0.092f}, steel[3] = {0.095f, 0.099f, 0.107f}, steelDark[3] = {0.060f, 0.063f, 0.070f};   // 1.7.197: darker again (1.7.177: 0.07..0.185): the housing is nearly black so the goo and the heart stand out
  const float hzLamp = zRear + 0.0125f;                           // the indicator's centre
  // 1. the base plate under everything, the two rails either side of the glass (the tube lies in their channel), the end blocks
  metal_bar(m, L.xc, L.yc + 0.0006f, 0.5f * (zFront - 0.0060f + hzLamp + 0.0078f), 0.0074f, 0.0012f, 0.5f * (hzLamp + 0.0078f - (zFront - 0.0060f)), gun, gunEdge);
  for (int sd = -1; sd <= 1; sd += 2) {
    const float yb = L.yc + 0.0018f, yt = cy + 0.0006f;
    metal_bar(m, L.xc + sd * 0.0060f, 0.5f * (yb + yt), L.zc, 0.0011f, 0.5f * (yt - yb), half + 0.0010f, gun, gunEdge);
  }
  for (int e = 0; e < 2; ++e) {   // machined blocks holding the glass at both ends
    const float zb = e ? zFront - 0.0030f : zRear + 0.0030f;
    metal_bar(m, L.xc, 0.5f * (L.yc + 0.0018f + cy + 0.0058f), zb, 0.0072f, 0.5f * (cy + 0.0058f - L.yc - 0.0018f), 0.0030f, gun, gunEdge);
    // the steel collar where the glass enters the block
    float za[kSeg], zc2[kSeg]; const float z0 = e ? zFront : zRear - 0.0016f, z1 = z0 + 0.0016f;
    for (int i = 0; i < kSeg; ++i) { za[i] = z0; zc2[i] = z1; }
    tube(m, L.xc, cy, rL + 0.0011f, za, zc2, steel, 1.0f, 1.0f, 0.0f, 0.35f);
  }
  // 2. screws: four small steel heads on the plate round the indicator
  for (int q = 0; q < 4; ++q) {
    const float sx = L.xc + ((q & 1) ? 0.0056f : -0.0056f), sz = hzLamp + ((q & 2) ? 0.0056f : -0.0056f);
    flat_ring(m, sx, L.yc + 0.0021f, sz, 0.0f, 0.00075f, 0.0003f, 6, steel, 1.0f, 0.70f, 0.0f);
  }
  // the liquid's surface: where it ends, per corner of the ring (a slow ripple, plus the slosh of a hit)
  const float zLevel = zRear - (float)(shown * len);
  float zs[kSeg], zr[kSeg], zf[kSeg], zl[kSeg];
  for (int i = 0; i < kSeg; ++i) {
    const double th = 2.0 * vm::kPi * i / kSeg; double a, b, c0;
    vm::dsincos(th + s.t * 4.2, &a, &c0); vm::dsincos(2.0 * th - s.t * 9.0, &b, &c0);
    double cth, sth; vm::dsincos(th, &sth, &cth);
    // 1.7.166: a full (or empty) tube has no free surface to tilt: the tilt fades out within 6 % of the ends (it flickered against the tube's end before)
    const double room = shown < 1.0 - shown ? shown : 1.0 - shown, roomK = room >= 0.06 ? 1.0 : (room > 0.0 ? room / 0.06 : 0.0);
    const double lean = (s.sx * cth + s.sy * sth) * rL * roomK;   // 1.7.162: the surface's tilt with the gun's motion (0 on the ghosts' vials)
    float z = zLevel + (float)((0.00045 * a + 0.0024 * s.slosh * b) * roomK + (lean == lean ? lean : 0.0));   // 1.7.166: the ripple fades at the ends too
    if (z < zFront) z = zFront; if (z > zRear) z = zRear;
    zs[i] = shown > 0.0 ? z : zRear; zr[i] = zRear; zf[i] = zFront;
    zl[i] = zRear - (float)(lost * len); if (zl[i] > zs[i]) zl[i] = zs[i];
  }
  // 3. the empty glass in front of the liquid: dark smoked glass (lit, so it reads as glass on metal, not as a light), a trace of the liquid's colour
  { float tint[3]; for (int c = 0; c < 3; ++c) tint[c] = 0.030f + 0.040f * rgb[c];   // 1.7.197: darker smoked glass
    const float* from = lost > shown + 1e-6 ? zl : zs;
    tube(m, L.xc, cy, rL, from, zf, tint, 1.0f, 1.0f, 0.0f, 0.65f); }
  // 4. the part just lost: pale, fading into the liquid's colour as it shrinks
  if (lost > shown + 1e-6) {
    float pale[3]; for (int c = 0; c < 3; ++c) pale[c] = rgb[c] * 0.40f + 0.42f;
    tube(m, L.xc, cy, rL, zs, zl, pale, 0.85f, 0.70f, 1.0f, 0.35f);
    cap(m, L.xc, cy, rL, zl, zRear - (float)(lost * len), -1, pale, 0.70f, 0.80f, 1.0f);
  }
  // 5. the liquid: deep at the bottom, lighter on top (seen through curved glass), a softer glow than before; a lighter meniscus at its surface
  if (shown > 0.0) {
    tube(m, L.xc, cy, rL, zr, zs, rgb, 0.85f * low, 1.0f * low, 1.0f, 0.40f);   // 1.7.197: the goo is brighter (was 0.50 / 0.80, top gain 0.62)
    float surf[3]; for (int c = 0; c < 3; ++c) surf[c] = rgb[c] * 0.70f + 0.24f;
    float zmid = zLevel - 0.0008f; if (zmid < zFront) zmid = zFront;
    cap(m, L.xc, cy, rL, zs, zmid, -1, surf, 1.0f * low, 1.0f * low, 1.0f);
    const float fl = (float)(shown * len);
    if (fl > 0.016f) {   // two small bubbles rising along the top toward the surface
      float bub[3]; for (int c = 0; c < 3; ++c) bub[c] = rgb[c] * 0.45f + 0.45f;
      for (int b = 0; b < 2; ++b) {
        double u = 0.21 + 0.47 * b + s.t * (0.09 + 0.04 * b); u -= (double)(long)u;
        const double ang = vm::kPi * (0.32 + 0.16 * b);
        double sn, cs; vm::dsincos(ang, &sn, &cs);
        const float r2 = rL + 0.0002f, zb = zRear - 0.003f - (float)u * (fl - 0.007f), sz = 0.00045f + 0.00012f * (float)b;
        const float px = L.xc + r2 * (float)cs, py = cy + r2 * (float)sn, tx = -(float)sn, ty = (float)cs;
        vput(m, px, py, zb - sz, (float)cs, (float)sn, 0, bub, 0.9f, 1); vput(m, px + tx * sz, py + ty * sz, zb, (float)cs, (float)sn, 0, bub, 0.9f, 1); vput(m, px, py, zb + sz, (float)cs, (float)sn, 0, bub, 0.9f, 1);
        vput(m, px, py, zb - sz, (float)cs, (float)sn, 0, bub, 0.9f, 1); vput(m, px, py, zb + sz, (float)cs, (float)sn, 0, bub, 0.9f, 1); vput(m, px - tx * sz, py - ty * sz, zb, (float)cs, (float)sn, 0, bub, 0.9f, 1);
      }
    }
  }
  // 6. the glass's reflection: one thin streak along the whole tube, a little left of the top (over liquid and empty glass alike)
  { static const float shine[3] = {0.40f, 0.42f, 0.45f};   // 1.7.176: was 0.80-0.88 (a neon streak)
    double sa, ca, sb, cb; vm::dsincos(vm::kPi * 0.62, &sa, &ca); vm::dsincos(vm::kPi * 0.66, &sb, &cb);
    const float r2 = rL + 0.00022f, z0 = zRear - 0.0012f, z1 = zFront + 0.0012f;
    const float ax = L.xc + r2 * (float)ca, ay = cy + r2 * (float)sa, bx = L.xc + r2 * (float)cb, by = cy + r2 * (float)sb;
    vput(m, ax, ay, z0, 0, 1, 0, shine, 0.30f, 1); vput(m, bx, by, z0, 0, 1, 0, shine, 0.30f, 1); vput(m, bx, by, z1, 0, 1, 0, shine, 0.55f, 1);
    vput(m, ax, ay, z0, 0, 1, 0, shine, 0.30f, 1); vput(m, bx, by, z1, 0, 1, 0, shine, 0.55f, 1); vput(m, ax, ay, z1, 0, 1, 0, shine, 0.55f, 1); }
  // 7. steel straps round the glass at a quarter, half and three quarters (on top of liquid and glass)
  for (int q = 1; q <= 3; ++q) {
    float za[kSeg], zb2[kSeg]; const float zm = zRear - len * 0.25f * q;
    for (int i = 0; i < kSeg; ++i) { za[i] = zm - 0.0007f; zb2[i] = zm + 0.0007f; }
    tube(m, L.xc, cy, rL + 0.00045f, za, zb2, steelDark, 1.0f, 1.0f, 0.0f, 0.55f);
  }
  // 8. the heart: an indicator lamp at the rear. A steel bezel, a dark red domed lens that lights with each beat, a small heart under the lens.
  {
    const int alive = shown > 0.0 ? 1 : 0;
    const float yLens = L.yc + 0.0030f, rLens = 0.0040f;
    flat_ring(m, L.xc, yLens + 0.0004f, hzLamp, rLens, rLens + 0.0013f, 0.0012f, 24, steel, 1.0f, 0.62f, 0.0f);   // the bezel
    const float beatK = alive ? (float)(0.55 + 0.45 * pulse) : 0.0f;   // 1.7.197: the heart is brighter (was 0.30 + 0.70 * pulse)
    float lens[3];
    if (alive) { for (int c = 0; c < 3; ++c) lens[c] = 0.0f; lens[0] = 0.55f + 0.45f * beatK; lens[1] = 0.04f + 0.10f * beatK; lens[2] = 0.05f + 0.10f * beatK; }
    else { lens[0] = 0.10f; lens[1] = 0.10f; lens[2] = 0.11f; }
    for (int i = 0; i < 24; ++i) {   // the dome: brighter in the middle
      double s0, c0, s1, c1; vm::dsincos(2.0 * vm::kPi * i / 24, &s0, &c0); vm::dsincos(2.0 * vm::kPi * (i + 1) / 24, &s1, &c1);
      const float em = alive ? 1.0f : 0.0f;
      vput(m, L.xc, yLens + 0.0011f, hzLamp, 0, 1, 0, lens, 1.0f, em);
      vput(m, L.xc + rLens * (float)c1, yLens, hzLamp + rLens * (float)s1, (float)c1 * 0.5f, 0.85f, (float)s1 * 0.5f, lens, 0.62f, em);
      vput(m, L.xc + rLens * (float)c0, yLens, hzLamp + rLens * (float)s0, (float)c0 * 0.5f, 0.85f, (float)s0 * 0.5f, lens, 0.62f, em);
    }
    // the heart symbol inside the lens, its point toward you; it swells a little with the beat
    const float sc = 0.0021f * (float)(alive ? heart_scale(s.beat) : 0.94);
    float hc[3]; if (alive) { hc[0] = 0.85f + 0.15f * beatK; hc[1] = 0.20f + 0.30f * beatK; hc[2] = 0.22f + 0.28f * beatK; } else { hc[0] = 0.30f; hc[1] = 0.29f; hc[2] = 0.31f; }
    const float hy = yLens + 0.00115f;
    for (int i = 0; i < kHeartN; ++i) {
      double x0, y0, x1, y1; heart_point(i, kHeartN, &x0, &y0); heart_point((i + 1) % kHeartN, kHeartN, &x1, &y1);
      vput(m, L.xc, hy, hzLamp, 0, 1, 0, hc, 1.0f, alive ? 1.0f : 0.0f);
      vput(m, L.xc + sc * (float)x1, hy, hzLamp - sc * (float)y1, 0, 1, 0, hc, 1.0f, alive ? 1.0f : 0.0f);
      vput(m, L.xc + sc * (float)x0, hy, hzLamp - sc * (float)y0, 0, 1, 0, hc, 1.0f, alive ? 1.0f : 0.0f);
    }
    { static const float spec[3] = {1.0f, 0.92f, 0.92f};   // the lens's glint, upper left
      const float gx = L.xc - rLens * 0.42f, gz = hzLamp - rLens * 0.40f, g = rLens * 0.16f, gy = yLens + 0.0012f;
      const float k = alive ? 0.75f : 0.45f;
      vput(m, gx - g, gy, gz, 0, 1, 0, spec, k, 1); vput(m, gx, gy, gz - g * 0.6f, 0, 1, 0, spec, k, 1); vput(m, gx + g, gy, gz, 0, 1, 0, spec, k, 1);
      vput(m, gx - g, gy, gz, 0, 1, 0, spec, k, 1); vput(m, gx + g, gy, gz, 0, 1, 0, spec, k, 1); vput(m, gx, gy, gz + g * 0.6f, 0, 1, 0, spec, k, 1); }
  }
  return m->n - n0;
}
}  // namespace gunbar
