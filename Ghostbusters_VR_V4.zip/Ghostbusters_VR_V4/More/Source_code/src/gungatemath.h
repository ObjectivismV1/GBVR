// 1.7.99 "the game decides when you may hold the gun". Pure math (tests/test_gungate.cpp).
//
// The mod used to leave the gun in your hand whenever you had drawn it, even where the game itself would not let you have it (a cut-scene, a forced walk, between levels), and
// the game's own "here is your gun" moments (level start, after a cut-scene) put it straight in your hand. Now:
//   * the game lets you have a gun (raw = 1) when a level runs, the game does not move the character by force, and the equipped item is a gun (proton, meson, boson, light, slime);
//   * the game does not (raw = 0) between levels, in a forced walk, or with nothing equipped;
//   * the PKE or the trap in hand (and an unknown item) change nothing (raw = -1): the PKE round trip stays as it was.
// A short debounce keeps a one-frame flicker of the item reading from taking the gun away. When the game starts allowing a gun after it did not (the gun was GIVEN), the gun
// comes back as it was (see DrawMemory below). A gun-to-gun switch never goes through here.
#pragma once

namespace gungate {

static const double kLoseS = 0.40;   // "not allowed" must last this long before the gun is put away
static const double kGainS = 0.50;   // "allowed" must last this long before the draw is unlocked (and the hand buzzes)

enum { kNone = 0, kLost = 1, kGained = 2 };

struct Gate {
  int stable;        // 1 = the game allows a gun in hand (draw unlocked), 0 = it does not
  double loseSince, gainSince;   // -1 = not running
};

inline void reset(Gate* g) { g->stable = 0; g->loseSince = g->gainSince = -1.0; }

inline int is_gun_item(int item) { return item == 1 || item == 2 || item == 3 || item == 6 || item == 7; }

// 1 = a gun is allowed, 0 = not allowed, -1 = no change (PKE / trap in hand, item unknown while a level runs)
inline int raw(int inGame, int forced, int item) {
  if (!inGame || forced) return 0;
  if (is_gun_item(item)) return 1;
  if (item == 0) return 0;
  return -1;
}

// 1.7.117: a knock-down (the game moves the character by force for a moment, in a level, a gun equipped) does NOT put the gun away: the forced move has to last longer than
// graceS before it counts as "not allowed" (cut-scene walks and long forced moves still do). forcedForS = how long the forced move has been running (0 when it is not).
static const double kKnockGraceS = 6.0;
inline int raw_knock(int inGame, int forced, int item, double forcedForS, double graceS) {
  if (inGame && forced && is_gun_item(item) && forcedForS < graceS) return -1;
  return raw(inGame, forced, item);
}

inline int step(Gate* g, double nowS, int rawNow) {
  if (!g) return kNone;
  if (rawNow < 0) { g->loseSince = g->gainSince = -1.0; return kNone; }
  if (rawNow == 1) {
    g->loseSince = -1.0;
    if (g->stable) return kNone;
    if (g->gainSince < 0.0) g->gainSince = nowS;
    if (nowS - g->gainSince >= kGainS) { g->stable = 1; g->gainSince = -1.0; return kGained; }
    return kNone;
  }
  g->gainSince = -1.0;
  if (!g->stable) return kNone;
  if (g->loseSince < 0.0) g->loseSince = nowS;
  if (nowS - g->loseSince >= kLoseS) { g->stable = 0; g->loseSince = -1.0; return kLost; }
  return kNone;
}

// 1.7.117: a temporary "no gun" (level load, cut-scene, forced move) must not turn a drawn gun into a holstered one for good, and the FIRST gun the game gives
// you in a session is simply in your hand (a new player who does not know the draw gesture used to see no gun at all). The state you chose last (the draw / holster
// gesture) or had when the game took the gun away comes back when it allows a gun again.
struct DrawMemory {
  int drawnBeforeDenial;
  int initialized;
};
inline void remember_loss(DrawMemory* m, int holstered) { m->drawnBeforeDenial = !holstered; m->initialized = 1; }
inline void remember_player_choice(DrawMemory* m, int holstered) { m->drawnBeforeDenial = !holstered; m->initialized = 1; }
// holstered state to use when the game allows a gun again (1 = holstered, 0 = in hand)
inline int restore_on_gain(const DrawMemory* m) { return m->initialized ? !m->drawnBeforeDenial : 0; }

// the gun stays holstered and cannot be drawn
inline int blocked(const Gate& g, int inGame) { return inGame && !g.stable; }

}  // namespace gungate
