// 1.7.170 the gun tube's shift to the drawn gun, kept in the CONTROLLER's own frame.
// Before (1.7.167) the gap was kept in eye space with 50 ms smoothing: when the hand turned the kept gap pointed the old way for a moment
// (the tube bounced), and a gap just over the 30 cm check was dropped and the old eye-space gap stayed while the hand moved (the tube floated off).
// Now: gap measured -> turned into the controller's frame -> smoothed slowly there (the game's hold changes slowly) -> turned back with the
// controller's turn of this frame, so the tube turns with the hand exactly and only the slow gap is smoothed.
#pragma once
#include "vmath.h"

namespace gunshift {

const double kMaxM = 0.45;       // a gap bigger than this is not the same gun
// 1.7.172 recheck (stress test): the 1.7.170 filter held back every sample more than 6 cm from the kept gap and only moved on after 0.6 s of samples that
// agreed with each other. With noisy samples (the 1.7.170 report: 37 % held back) a first sample that was off - taken while the gun swung into the hand -
// could stay for good, because noisy samples never agree for 0.6 s. Now: no gate. Every sample pulls, but by no more than kPullM (an outlier moves the
// tube by under 4 mm), into a smoothed mean, and the kept gap follows the mean smoothly. A wrong start heals in about a second; a real change of the
// hold is followed in about a second; noise of several cm leaves a few mm.
const double kPullM = 0.10;      // the most one sample may differ from the mean, as far as its pull goes
const double kTauMeanS = 0.25;   // 1.7.176: was 0.45 ("it floats around following behind": the tube now follows the drawn gun within about a third of a second)   // smoothing of the mean of the samples
const double kTauKeptS = 0.10;   // 1.7.176: was 0.20   // the kept gap follows the mean
const double kSnapM = 0.02;      // 1.7.186 take(): a sample closer than this to the kept gap is blended in, a farther one replaces it
const double kBlendSmall = 0.6;  // 1.7.186 take(): how much of a small difference is followed per sample
const double kOutlierM = 0.09;   // 1.7.186 take(): a sample this far from the kept gap (more than any grab moves the gun, 5-7 cm) must be confirmed by the next sample before it is taken
const double kConfirmM = 0.03;   // ... the two far samples must lie within this of each other
const double kMaxDtS = 0.05;     // a sample after a pause counts as at most this much time (one sample never moves the gap far)

struct Filter {
  float lo[3]; int have;         // the kept gap (controller frame, metres)
  float mean[3];
  float pend[3]; int pendHave;   // 1.7.186 take(): a far-off sample waiting for a second one that agrees
  long used, rejected, jumps;    // samples taken, samples out of range or limited, (jumps: unused since 1.7.172, kept for the log line)
  void reset() { for (int i = 0; i < 3; ++i) lo[i] = mean[i] = 0.0f; have = 0; pendHave = 0; for (int i = 0; i < 3; ++i) pend[i] = 0.0f; used = rejected = jumps = 0; }
};

inline double len3(const float* a) { return vm::dsqrt((double)a[0] * a[0] + (double)a[1] * a[1] + (double)a[2] * a[2]); }

// world/eye gap -> controller frame (r is the controller's turn, row-major, as hand::Xform: e = r*p + t)
inline void to_local(const float* r, const float* g, float* o) {
  for (int i = 0; i < 3; ++i) o[i] = r[i] * g[0] + r[3 + i] * g[1] + r[6 + i] * g[2];
}
inline void to_eye(const float* r, const float* l, float* o) {
  for (int i = 0; i < 3; ++i) o[i] = r[i * 3] * l[0] + r[i * 3 + 1] * l[1] + r[i * 3 + 2] * l[2];
}

// one measured gap (controller frame), dt seconds since the last sample; returns 1 when it was taken (0 = not a number or out of range: nothing changes)
inline int feed(Filter& f, const float* s, double dt) {
  if (!(dt >= 0.0)) dt = 0.0;
  if (dt > kMaxDtS) dt = kMaxDtS;
  const double L = len3(s);
  if (!(L < kMaxM)) { ++f.rejected; return 0; }
  if (!f.have) { for (int i = 0; i < 3; ++i) f.lo[i] = f.mean[i] = s[i]; f.have = 1; ++f.used; return 1; }
  double d[3] = {(double)s[0] - f.mean[0], (double)s[1] - f.mean[1], (double)s[2] - f.mean[2]};
  const double dl = vm::dsqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
  if (dl > kPullM) { const double q = kPullM / dl; for (int i = 0; i < 3; ++i) d[i] *= q; ++f.rejected; }   // limited, not dropped
  const double km = dt / (kTauMeanS + dt), kk = dt / (kTauKeptS + dt);
  for (int i = 0; i < 3; ++i) { f.mean[i] += (float)(d[i] * km); f.lo[i] += (float)(((double)f.mean[i] - f.lo[i]) * kk); }
  ++f.used;
  return 1;
}

// 1.7.185 "lock the tube to the gun": a fresh sample of the drawn muzzle is taken AT ONCE, once per sample (not smoothed, not held back while the hand moves).
// The old filter learned the gap slowly and only while the controller was nearly still, so every grab with the other hand (the game's hold moves the gun 5-7 cm
// from the controller) left the tube trailing for a second. A sample is paired with the controller of the frame it is first seen in, so it is wrong by at most
// one frame of hand movement. Returns 1 when taken. jump = how far the kept gap moved (metres) for the log.
inline int take(Filter& f, const float* s, double* jump) {
  const double L = len3(s);
  if (!(L < kMaxM)) { ++f.rejected; return 0; }
  double j = 0.0;
  if (f.have) { const double d0 = (double)s[0] - f.lo[0], d1 = (double)s[1] - f.lo[1], d2 = (double)s[2] - f.lo[2]; j = vm::dsqrt(d0 * d0 + d1 * d1 + d2 * d2); }
  if (f.have && j > kOutlierM) {   // far from the kept gap: one lone sample is not believed; two that agree are (a real change of the hold or a different gun)
    const double e0 = (double)s[0] - f.pend[0], e1 = (double)s[1] - f.pend[1], e2 = (double)s[2] - f.pend[2];
    if (!(f.pendHave && vm::dsqrt(e0 * e0 + e1 * e1 + e2 * e2) < kConfirmM)) { for (int i = 0; i < 3; ++i) f.pend[i] = s[i]; f.pendHave = 1; ++f.rejected; return 0; }
  }
  f.pendHave = 0;
  // 1.7.186 a small difference (under 2 cm: measuring noise, a slightly different frame) is followed 60 % of the way so the tube does not tremble with every sample;
  // a bigger one (a real change of the hold: a grab, a release) is taken whole at once so the tube never trails the gun
  const double q = (f.have && j <= kSnapM) ? kBlendSmall : 1.0;
  for (int i = 0; i < 3; ++i) { f.lo[i] += (float)(((double)s[i] - f.lo[i]) * q); f.mean[i] = f.lo[i]; }
  f.have = 1; ++f.used;
  if (jump) *jump = j;
  return 1;
}

// 1.7.191 / 1.7.193: the drawn muzzle's sample is a game tick old. While the muzzle moves in the WORLD (the player walks or the hand swings) that age is a position error, so nothing is
// learned then; the kept gap holds (it is rigid with the controller). still() is fed once per new sample (time in s, world position in ft); speedLimit is in ft/s.
struct StillGate {
  double w0[3]; double t0; int have; int still;
  void reset() { have = 0; still = 1; t0 = 0.0; for (int i = 0; i < 3; ++i) w0[i] = 0.0; }
  int step(const double* w, double t, double speedLimit) {
    if (!have) { have = 1; still = 1; }
    else if (t > t0) { const double dx = w[0] - w0[0], dy = w[1] - w0[1], dz = w[2] - w0[2]; still = (vm::dsqrt(dx * dx + dy * dy + dz * dz) / (t - t0)) < speedLimit; }
    for (int i = 0; i < 3; ++i) w0[i] = w[i]; t0 = t;
    return still;
  }
};

}  // namespace gunshift
