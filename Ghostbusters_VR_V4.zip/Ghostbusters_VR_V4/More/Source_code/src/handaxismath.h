// 1.7.87 where the thumb stick is read from, per controller family. Plain C so vr_openvr.c (C) and tests/test_handaxis.cpp can both use it.
//
// OpenVR's old input layer (GetControllerState) numbers the analog axes by controller type:
//   Touch-style (Quest, Rift, Pico): axis 0 = thumb stick, axis 1 = trigger
//   Valve Index:  axis 0 = trackpad, axis 1 = trigger, axis 3 = thumb stick
//   Windows MR:   axis 0 = trackpad, axis 1 = trigger, axis 2 = thumb stick
//   Vive wand:    axis 0 = trackpad (used as the stick)
// The stick's click comes as the bit of ITS axis (bit 32 + axis); the rest of the mod expects it as axis 0's bit (32).
//
// Virtual Desktop can make a Quest look like an Index ("Emulate Index Controllers", for finger tracking). Which axis the stick lands on then depends on
// the driver, and there is no trackpad to confuse it with, so for such a look-alike the stick is whichever of axis 3 and axis 0 is pushed further.
#pragma once
#include <stdint.h>

struct GbvrStickRead { float x, y; uint64_t pressed, touched; int axis; };   /* axis: which analog axis the stick was read from (0, 2 or 3) */

static inline float gbvr_absf(float v) { return v < 0.0f ? -v : v; }
static inline float gbvr_maxabs2(float a, float b) { const float x = gbvr_absf(a), y = gbvr_absf(b); return x > y ? x : y; }

/* family: 0 unknown, 1 Touch-style, 2 Index, 3 Vive, 4 Windows MR, 5 other (same numbers as vr_capi_family)
 * axis3Seen (1.7.96): the real Index's axis 3 has been pushed at least once on this controller. A REAL Valve Index whose axis 3 has never moved while axis 0 does is read from
 * axis 0: the first Index report (Valve Index, SteamVR's own legacy bindings) showed axis 0 pushed up to 100 % and axis 3 never above 0 in three runs, with the left stick dead.
 * Once axis 3 has moved, axis 0 (the trackpad) is ignored again, exactly as before. */
static inline void gbvr_pick_stick(int family, int indexLookalike, int axis3Seen, const float* axX, const float* axY, uint64_t pressed, uint64_t touched, struct GbvrStickRead* o) {
  const uint64_t bit0 = 1ull << 32, bit3 = 1ull << 35;
  int ax = 0;
  if (family == 2) ax = 3; else if (family == 4) ax = 2;
  const int p0 = gbvr_maxabs2(axX[0], axY[0]) > gbvr_maxabs2(axX[3], axY[3]);
  if (family == 2 && indexLookalike && p0) ax = 0;
  const int realFallback = family == 2 && !indexLookalike && !axis3Seen;   /* a real Index that has never used axis 3 */
  if (realFallback && p0) ax = 0;
  o->x = axX[ax];
  o->y = axY[ax];
  o->axis = ax;
  o->pressed = pressed;
  o->touched = touched;
  if (family == 2 && (indexLookalike || realFallback)) {   /* the stick may be on either axis: a click on either axis' bit is the stick click */
    const uint64_t both = bit0 | bit3;
    uint64_t pr = pressed & ~both, tc = touched & ~both;
    if (pressed & both) pr |= bit0;
    if (touched & both) tc |= bit0;
    o->pressed = pr; o->touched = tc;
  } else if (ax) {   /* the stick's click comes in as that axis' button bit: it is handed on as the normal stick click (axis 0 = bit 32), and the trackpad's own click is not mistaken for it */
    const uint64_t bitAx = 1ull << (32 + ax);
    uint64_t pr = pressed & ~bit0, tc = touched & ~bit0;
    if (pressed & bitAx) pr |= bit0;
    if (touched & bitAx) tc |= bit0;
    o->pressed = pr; o->touched = tc;
  }
}

/* "made by Valve" without the C runtime: a tiny case-insensitive search */
static inline int gbvr_has_valve(const char* s) {
  static const char k[] = "valve";
  for (; *s; ++s) {
    int i = 0;
    while (k[i]) {
      char c = s[i];
      if (!c) return 0;
      if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
      if (c != k[i]) break;
      ++i;
    }
    if (!k[i]) return 1;
  }
  return 0;
}

/* An Index-type controller that is not Valve's. An unreadable maker keeps the real-Index reading (nothing changes from before). */
static inline int gbvr_index_lookalike(int family, const char* maker) {
  return family == 2 && maker && maker[0] && !gbvr_has_valve(maker) ? 1 : 0;
}

/* largest push seen on each of the 5 axes (for the log line that shows which axis a stick really uses) */
static inline void gbvr_axis_peaks(float* peaks, const float* axX, const float* axY) {
  for (int i = 0; i < 5; ++i) {
    const float m = gbvr_maxabs2(axX[i], axY[i]);
    if (m > peaks[i]) peaks[i] = m;
  }
}
