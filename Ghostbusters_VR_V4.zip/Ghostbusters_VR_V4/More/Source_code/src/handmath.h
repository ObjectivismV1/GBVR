// Hands and proton wand drawn into the eye pictures (0.34). Pure math and
// geometry, no Windows or Direct3D dependency; unit-tested in tests/test_hand.cpp.
//
// The game's own wand is hidden in first person (it is attached to the hidden
// body). The probe draws its own simple wand and two gloved hands at the
// controllers, into each eye picture after the game has finished it.
//
// Coordinates. Models are written in OpenVR device axes (x right, y up, -z
// forward), in metres, with the origin at the controller's grip centre. The
// eye picture is rendered by the game in engine axes (x right, y up, +z
// forward) with the picture centre on the head's forward axis, so a model
// point becomes
//     p_eye = S * ( Rh^T * (Rd * p + td - th)  -  eyeOffset )      S = diag(1,1,-1)
// (Rh, th head pose, Rd, td controller pose, both device-to-tracking).
#pragma once
#include <stdint.h>
#include "vmath.h"

namespace hand {

// Proximity can steady the legacy right-only mode. Steering the beam always
// requires a deliberate grip, including while the hand remains near the gun.
inline int support_requested(int grip, int proximity, int lineAim) {
  return grip || (proximity && !lineAim);
}
struct SupportHold {
  int on = 0, run = 0;
  int step(int requested, int poseOk) {
    const int raw = requested && poseOk;
    if (raw) { if (run < 3) ++run; } else run = 0;
    on = raw && (on || run >= 3);
    return on;
  }
};

struct Vertex { float p[3]; float n[3]; float c[4]; };  // c[3] > 0.5: emissive (not shaded)

// Rows of a 3x4 matrix that maps a model point to eye space: e = R*p + t.
struct Xform { float r[9]; float t[3]; };

inline void rot_x(double deg, float* o) {   // rotation about the device x axis (positive = forward axis turns up)
  double s, c; vm::dsincos(deg * vm::kPi / 180.0, &s, &c);
  o[0] = 1; o[1] = 0; o[2] = 0;
  o[3] = 0; o[4] = (float)c; o[5] = (float)-s;
  o[6] = 0; o[7] = (float)s; o[8] = (float)c;
}

// head34, dev34: OpenVR 3x4 poses (row-major, 4 floats per row). eyeOff: eye
// position in head space (metres, OpenVR axes, e.g. (-0.0353, 0, 0)). pitchDeg
// tilts the model about its x axis (the pointing direction, see padmath.h).
inline int model_to_eye(const float* head34, const float* dev34, const float* eyeOff, double pitchDeg, Xform* out) {
  float Rh[9], Rd[9], Rt[9], Rp[9], Rm[9], Rrel[9];
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) { Rh[r * 3 + c] = head34[r * 4 + c]; Rd[r * 3 + c] = dev34[r * 4 + c]; }
  if (!vm::is_rotation(Rh, 5e-3) || !vm::is_rotation(Rd, 5e-3)) return 0;
  vm::transpose(Rh, Rt);
  vm::mul(Rt, Rd, Rrel);           // device -> head axes
  rot_x(pitchDeg, Rp);
  vm::mul(Rrel, Rp, Rm);
  double d[3] = {(double)dev34[3] - head34[3], (double)dev34[7] - head34[7], (double)dev34[11] - head34[11]};
  double t[3];
  for (int i = 0; i < 3; ++i) t[i] = Rt[i * 3] * d[0] + Rt[i * 3 + 1] * d[1] + Rt[i * 3 + 2] * d[2] - (eyeOff ? eyeOff[i] : 0.0);
  for (int i = 0; i < 9; ++i) out->r[i] = Rm[i];
  for (int i = 6; i < 9; ++i) out->r[i] = -out->r[i];   // S: flip z (engine forward is +z)
  out->t[0] = (float)t[0]; out->t[1] = (float)t[1]; out->t[2] = (float)-t[2];
  for (int i = 0; i < 9; ++i) if (!vm::is_finite_f(out->r[i])) return 0;
  for (int i = 0; i < 3; ++i) if (!vm::is_finite_f(out->t[i])) return 0;
  return 1;
}


// Two-handed hold: the wand lies along the line from the right (rear) hand to the left (front)
// hand, rolled like the right controller. right34/left34/out34: OpenVR 3x4 row-major poses.
// Returns 0 if the hands are closer than minDist metres or a pose is not a rotation.
// 0.77: maxDist = the farthest the free hand may be to still count as holding the barrel (the D-pad gesture starts where this ends);
// pitchDeg tilts the barrel up (+) because the support hand sits below the barrel's axis, which made the nose point down.
// 1.7.111: refM > 0 makes the tilt follow the hand distance (the support hand sits a fixed height below the barrel, so the nearer it is
// the more the line right->left points down): tilt = asin(h/d) with h chosen so the tilt equals pitchDeg at d = refM. Sliding the hand
// along the barrel then no longer moves the muzzle up and down. refM = 0 keeps the old fixed tilt.
inline int two_hand_pose_ref(const float* right34, const float* left34, double minDist, double maxDist, double pitchDeg, double refM, float* out34) {
  double f[3] = {(double)left34[3] - right34[3], (double)left34[7] - right34[7], (double)left34[11] - right34[11]};
  double l2 = f[0] * f[0] + f[1] * f[1] + f[2] * f[2];
  if (!(l2 >= minDist * minDist) || !(l2 < maxDist * maxDist)) return 0;   // farther than maxDist the left hand is not on the wand
  double il = 1.0 / vm::dsqrt(l2);
  for (int i = 0; i < 3; ++i) f[i] *= il;
  double u[3] = {right34[1], right34[5], right34[9]};            // right controller's up
  double x[3] = {f[1] * u[2] - f[2] * u[1], f[2] * u[0] - f[0] * u[2], f[0] * u[1] - f[1] * u[0]};   // f x up
  double xl = x[0] * x[0] + x[1] * x[1] + x[2] * x[2];
  if (!(xl > 1e-6)) return 0;                                     // pointing straight along "up": no roll reference
  double ix = 1.0 / vm::dsqrt(xl);
  for (int i = 0; i < 3; ++i) x[i] *= ix;
  double y[3] = {x[1] * f[2] - x[2] * f[1], x[2] * f[0] - x[0] * f[2], x[0] * f[1] - x[1] * f[0]};   // x x f
  if (refM > 0.05 && (pitchDeg > 0.05 || pitchDeg < -0.05)) {
    const double d = vm::dsqrt(l2);
    double sref, cref; vm::dsincos(pitchDeg * vm::kPi / 180.0, &sref, &cref);
    double q = sref * refM / (d > 0.08 ? d : 0.08);   // sin(tilt) = h/d with h = sin(pitchDeg)*refM
    if (q > 0.5) q = 0.5; else if (q < -0.5) q = -0.5;
    pitchDeg = vm::dasin(q) * 180.0 / vm::kPi;
  }
  if (pitchDeg > 0.05 || pitchDeg < -0.05) {   // turn the barrel up about its right axis x
    double s, c; vm::dsincos(pitchDeg * vm::kPi / 180.0, &s, &c);
    for (int i = 0; i < 3; ++i) { const double fi = f[i] * c + y[i] * s, yi = y[i] * c - f[i] * s; f[i] = fi; y[i] = yi; }
  }
  for (int r = 0; r < 3; ++r) { out34[r * 4 + 0] = (float)x[r]; out34[r * 4 + 1] = (float)y[r]; out34[r * 4 + 2] = (float)-f[r]; out34[r * 4 + 3] = right34[r * 4 + 3]; }
  return 1;
}
inline int two_hand_pose_ex(const float* right34, const float* left34, double minDist, double maxDist, double pitchDeg, float* out34) {
  return two_hand_pose_ref(right34, left34, minDist, maxDist, pitchDeg, 0.0, out34);
}
inline int two_hand_pose(const float* right34, const float* left34, double minDist, float* out34) {
  return two_hand_pose_ex(right34, left34, minDist, 0.8, 0.0, out34);
}

inline void apply(const Xform& x, const float* p, float* e) {
  for (int i = 0; i < 3; ++i) e[i] = x.r[i * 3] * p[0] + x.r[i * 3 + 1] * p[1] + x.r[i * 3 + 2] * p[2] + x.t[i];
}

// Picture position of an eye-space point for the game's frustum (tangents of
// the half field of view). Returns 0 if the point is behind the eye.
inline int project(const float* e, double tanH, double tanV, double* nx, double* ny) {
  if (!(e[2] > 1e-6)) return 0;
  *nx = e[0] / (e[2] * tanH);
  *ny = e[1] / (e[2] * tanV);
  return 1;
}

// ---- geometry ---------------------------------------------------------------------
struct Mesh {
  Vertex* v; int n; int cap;
  void tri(const float* a, const float* b, const float* c, const float* nrm, const float* col) {
    if (n + 3 > cap) return;
    const float* q[3] = {a, b, c};
    for (int i = 0; i < 3; ++i) {
      Vertex& o = v[n++];
      for (int k = 0; k < 3; ++k) { o.p[k] = q[i][k]; o.n[k] = nrm[k]; }
      for (int k = 0; k < 4; ++k) o.c[k] = col[k];
    }
  }
  void quad(const float* a, const float* b, const float* c, const float* d, const float* nrm, const float* col) {
    tri(a, b, c, nrm, col); tri(a, c, d, nrm, col);
  }
  // axis-aligned box: centre cx,cy,cz, half sizes hx,hy,hz
  void box(float cx, float cy, float cz, float hx, float hy, float hz, const float* col) {
    float x0 = cx - hx, x1 = cx + hx, y0 = cy - hy, y1 = cy + hy, z0 = cz - hz, z1 = cz + hz;
    float P[8][3] = {{x0,y0,z0},{x1,y0,z0},{x1,y1,z0},{x0,y1,z0},{x0,y0,z1},{x1,y0,z1},{x1,y1,z1},{x0,y1,z1}};
    static const float nz0[3] = {0,0,-1}, nz1[3] = {0,0,1}, nx0[3] = {-1,0,0}, nx1[3] = {1,0,0}, ny0[3] = {0,-1,0}, ny1[3] = {0,1,0};
    quad(P[0], P[3], P[2], P[1], nz0, col);
    quad(P[4], P[5], P[6], P[7], nz1, col);
    quad(P[0], P[4], P[7], P[3], nx0, col);
    quad(P[1], P[2], P[6], P[5], nx1, col);
    quad(P[0], P[1], P[5], P[4], ny0, col);
    quad(P[3], P[7], P[6], P[2], ny1, col);
  }
  // cylinder along z from z0 to z1 (both ends capped), centre cx,cy, radius r
  void cyl_z(float cx, float cy, float z0, float z1, float r, int seg, const float* col) {
    for (int i = 0; i < seg; ++i) {
      double a0 = 2 * vm::kPi * i / seg, a1 = 2 * vm::kPi * (i + 1) / seg, s0, c0, s1, c1;
      vm::dsincos(a0, &s0, &c0); vm::dsincos(a1, &s1, &c1);
      float p00[3] = {cx + r * (float)c0, cy + r * (float)s0, z0}, p01[3] = {cx + r * (float)c0, cy + r * (float)s0, z1};
      float p10[3] = {cx + r * (float)c1, cy + r * (float)s1, z0}, p11[3] = {cx + r * (float)c1, cy + r * (float)s1, z1};
      double am = 0.5 * (a0 + a1), sm, cm; vm::dsincos(am, &sm, &cm);
      float nrm[3] = {(float)cm, (float)sm, 0};
      quad(p00, p10, p11, p01, nrm, col);
      float ca[3] = {cx, cy, z0}, cb[3] = {cx, cy, z1};
      float nb[3] = {0, 0, -1}, nf[3] = {0, 0, 1};
      tri(ca, p10, p00, nb, col);
      tri(cb, p01, p11, nf, col);
    }
  }
};

enum { kMaxVerts = 3800 };   // 0.77: 1400 -> 2800 (the ghost trap model is part of the static mesh)

// Where the proton stream starts: the glowing tip of the wand model (model axes, metres).
static const float kTipX = 0.0f, kTipY = 0.020f, kTipZ = -0.488f;

// Wand (right controller). Forward is -z. Returns the number of vertices used by
// the wand; the hand geometry follows (see build_all).
inline void build_wand(Mesh* m) {
  static const float body[4] = {0.34f, 0.36f, 0.40f, 0}, silver[4] = {0.74f, 0.76f, 0.80f, 0}, black[4] = {0.11f, 0.11f, 0.12f, 0};
  static const float glow[4] = {1.0f, 0.55f, 0.18f, 1}, blue[4] = {0.25f, 0.55f, 1.0f, 1}, red[4] = {0.85f, 0.12f, 0.10f, 0};
  m->box(0.0f, 0.020f, -0.120f, 0.028f, 0.030f, 0.190f, body);        // main body: 38 cm long, 5.6 cm wide
  m->box(0.0f, 0.062f, -0.150f, 0.014f, 0.012f, 0.060f, black);       // top rail
  m->box(0.0f, 0.062f, -0.060f, 0.016f, 0.010f, 0.012f, blue);        // gauge light
  m->box(0.0f, -0.045f, 0.000f, 0.020f, 0.060f, 0.022f, black);       // pistol grip
  m->box(0.0f, 0.020f, 0.090f, 0.024f, 0.026f, 0.020f, red);          // rear pack connector
  m->cyl_z(0.0f, 0.020f, -0.310f, -0.440f, 0.026f, 10, silver);       // barrel
  m->cyl_z(0.0f, 0.020f, -0.440f, -0.480f, 0.034f, 10, black);        // muzzle
  m->cyl_z(0.0f, 0.020f, -0.478f, -0.488f, 0.037f, 10, glow);         // glowing tip ring
}

// Gloved fist with a sleeve running back toward the elbow (+z).
inline void build_hand(Mesh* m) {
  static const float glove[4] = {0.10f, 0.10f, 0.11f, 0}, sleeve[4] = {0.52f, 0.46f, 0.32f, 0}, cuff[4] = {0.82f, 0.80f, 0.72f, 0};
  m->box(0.0f, -0.005f, 0.000f, 0.042f, 0.045f, 0.050f, glove);       // fist
  m->box(0.050f, 0.020f, -0.010f, 0.010f, 0.020f, 0.030f, glove);     // thumb side
  m->cyl_z(0.0f, -0.005f, 0.055f, 0.075f, 0.040f, 8, cuff);           // cuff stripe
  m->cyl_z(0.0f, -0.005f, 0.075f, 0.230f, 0.042f, 8, sleeve);         // forearm
}

// 0.77: the ghost trap (a flat box with two yellow-and-black striped doors on top and a red light at the far end). The origin is where the hand
// holds it (a handle block under the near end); the trap extends forward (-z) like the wand. 14 x 6 x 24 cm.
inline void build_trap(Mesh* m) {
  static const float body[4] = {0.16f, 0.16f, 0.17f, 0}, steel[4] = {0.52f, 0.54f, 0.58f, 0}, yellow[4] = {0.95f, 0.76f, 0.06f, 0}, black[4] = {0.05f, 0.05f, 0.06f, 0};
  static const float red[4] = {0.95f, 0.10f, 0.08f, 1}, grip[4] = {0.09f, 0.09f, 0.10f, 0};
  m->box(0.0f, 0.035f, -0.100f, 0.070f, 0.030f, 0.120f, body);              // the box
  m->box(0.0f, 0.068f, -0.100f, 0.074f, 0.004f, 0.124f, steel);             // top plate
  m->box(-0.036f, 0.074f, -0.100f, 0.031f, 0.003f, 0.108f, yellow);         // the two doors
  m->box(0.036f, 0.074f, -0.100f, 0.031f, 0.003f, 0.108f, yellow);
  for (int i = 0; i < 5; ++i) {                                              // hazard stripes across each door
    const float z = -0.100f + (i - 2) * 0.040f;
    m->box(-0.036f, 0.0775f, z, 0.030f, 0.0010f, 0.0075f, black);
    m->box(0.036f, 0.0775f, z, 0.030f, 0.0010f, 0.0075f, black);
  }
  m->box(0.0f, 0.020f, 0.000f, 0.030f, 0.022f, 0.016f, grip);               // the handle block under the near end
  m->box(0.0f, 0.082f, -0.212f, 0.014f, 0.006f, 0.007f, red);               // status light
  m->box(0.0f, 0.040f, -0.222f, 0.050f, 0.020f, 0.003f, black);             // front plate
}

// 0.93: the PKE meter, the probe's own model (the game's own PKE could not be placed reliably). The origin is where the hand holds it (the handle);
// the device extends forward (-z) like the wand, the screen faces up (+y). Two wings fold up from the front like the film prop. ~20 cm long, 8 cm wide.
inline void build_pke(Mesh* m) {
  static const float body[4] = {0.20f, 0.21f, 0.23f, 0}, dark[4] = {0.07f, 0.07f, 0.08f, 0}, steel[4] = {0.62f, 0.64f, 0.68f, 0}, brass[4] = {0.70f, 0.55f, 0.22f, 0};
  static const float screen[4] = {0.15f, 0.80f, 0.95f, 1}, red[4] = {1.0f, 0.15f, 0.10f, 1}, amber[4] = {1.0f, 0.70f, 0.10f, 1}, green[4] = {0.20f, 1.0f, 0.30f, 1};
  m->box(0.0f, 0.030f, -0.075f, 0.042f, 0.026f, 0.095f, body);          // main housing
  m->box(0.0f, -0.030f, 0.000f, 0.019f, 0.050f, 0.021f, dark);          // the handle the hand holds
  m->box(0.0f, 0.058f, -0.060f, 0.031f, 0.0035f, 0.052f, dark);         // screen frame
  m->box(0.0f, 0.0615f, -0.060f, 0.026f, 0.0012f, 0.046f, screen);      // the glowing screen
  m->box(-0.024f, 0.058f, -0.138f, 0.007f, 0.004f, 0.007f, red);        // three lights along the front edge
  m->box(0.0f, 0.058f, -0.138f, 0.007f, 0.004f, 0.007f, amber);
  m->box(0.024f, 0.058f, -0.138f, 0.007f, 0.004f, 0.007f, green);
  m->box(0.0f, 0.030f, -0.176f, 0.030f, 0.020f, 0.004f, brass);         // front plate
  m->box(0.0f, 0.036f, 0.026f, 0.030f, 0.020f, 0.004f, brass);          // back plate
  // the wings: flat plates hinged on the housing's top corners, swung 50 degrees out from upright
  for (int side = -1; side <= 1; side += 2) {
    const double th = 50.0 * vm::kPi / 180.0;
    double s, c; vm::dsincos(th, &s, &c);
    const float hx = side * 0.040f, hy = 0.056f;
    const float ux = (float)(side * s), uy = (float)c, len = 0.085f;
    const float z0 = -0.030f, z1 = -0.155f;
    float a[3] = {hx, hy, z0}, b[3] = {hx, hy, z1}, cc[3] = {hx + ux * len, hy + uy * len, z1}, d[3] = {hx + ux * len, hy + uy * len, z0};
    const float n1[3] = {(float)(side * c), (float)-s, 0}, n2[3] = {(float)(-side * c), (float)s, 0};
    m->quad(a, b, cc, d, n1, steel);
    m->quad(a, d, cc, b, n2, steel);
    // glowing edge strip along the free edge
    const float e = 0.012f;
    float a2[3] = {cc[0] - ux * e, cc[1] - uy * e, z1}, b2[3] = {d[0] - ux * e, d[1] - uy * e, z0};
    m->quad(a2, b2, d, cc, n1, amber);
    m->quad(a2, cc, d, b2, n2, amber);
  }
}

}  // namespace hand
