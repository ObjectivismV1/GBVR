// 0.34 hands and proton wand drawn into the eye pictures.
//
// Render thread, inside the game's Present, right after the finished frame was
// copied into the eye texture (stereo.cpp): the copy gets a simple gloved hand
// at each controller and a proton wand in the right hand. The game's own
// picture (back buffer) is not touched. All Direct3D state that is changed is
// saved first and restored afterwards. The shaders are compiled at the first
// use with d3dcompiler_47.dll (part of Windows); if that is missing the
// feature switches itself off and says so in the log.
#include "gunbarmath.h"
#include "gbvr.h"

#if GBVR_HEADTRACK
#include <d3d11.h>
#include <d3dcompiler.h>
#include "vmath.h"
#include "gunshift.h"
#include "handmath.h"
#include "cordmath.h"
#include "rigmath.h"
#include "fightmath.h"
#include "bossringmath.h"
#include "gearmath.h"
#include "vignettemath.h"

namespace {
const char* kShader =
  "cbuffer C : register(b0) { float4 R0; float4 R1; float4 R2; float4 P; float4 Lt; };\n"
  "struct VI { float3 p : POSITION; float3 n : NORMAL; float4 c : COLOR; };\n"
  "struct VO { float4 pos : SV_Position; float3 col : COLOR0; float3 ep : TEXCOORD0; };\n"
  "VO VSMain(VI v) {\n"
  "  VO o;\n"
  "  float3 e = float3(dot(R0.xyz, v.p) + R0.w, dot(R1.xyz, v.p) + R1.w, dot(R2.xyz, v.p) + R2.w);\n"
  "  float3 n = normalize(float3(dot(R0.xyz, v.n), dot(R1.xyz, v.n), dot(R2.xyz, v.n)));\n"
  "  float l = saturate(dot(n, Lt.xyz));\n"
  "  o.col = v.c.a > 0.5 ? v.c.rgb * Lt.w : v.c.rgb * (0.38 + 0.62 * l);\n"
  "  o.pos = float4(e.x * P.x, e.y * P.y, e.z * P.z + P.w, e.z);\n"
  "  o.ep = e;\n"
  "  return o;\n"
  "}\n"
  "float4 PSMain(VO i) : SV_Target { return float4(i.col, 1.0); }\n"
  // 1.7.167 "I can see the health bar through my hand": the game's hands are not in our depth, so the tube is cut where a hand (a ball round each
  // tracked hand, eye space) sits in front of it on the way from the eye
  "cbuffer O : register(b1) { float4 S0; float4 S1; };\n"
  "float hid(float3 e, float4 S) { if (S.w <= 0.0) return 0.0; float ee = dot(e, e); float t = dot(S.xyz, e) / max(ee, 1e-6); if (t <= 0.0 || t >= 1.0) return 0.0; float3 q = e * t - S.xyz; return dot(q, q) < S.w * S.w ? 1.0 : 0.0; }\n"
  "float4 PSOcc(VO i) : SV_Target { if (hid(i.ep, S0) + hid(i.ep, S1) > 0.0) discard; return float4(i.col, 1.0); }\n";

ID3D11Device* g_dev;                     // device the resources below belong to (no reference kept)
ID3D11VertexShader* g_vs;
ID3D11PixelShader* g_ps;
ID3D11PixelShader* g_psOcc;
volatile LONG g_gunShiftUsed, g_gunShiftNone, g_occDraws, g_occCut; double g_gunShiftMaxCm, g_gunShiftLastCm;   // 1.7.167               // 1.7.167: the gun tube's shader, cut by the hands
ID3D11Buffer* g_cbOcc;                     // 1.7.167: the two hand balls (eye space, metres)
ID3D11InputLayout* g_il;
ID3D11Buffer *g_vb, *g_cb;
ID3D11RasterizerState* g_rs;
ID3D11DepthStencilState* g_ds;
ID3D11DepthStencilState* g_dsOff;        // 0.76: no depth test (the health bars are drawn far to near)
ID3D11Buffer* g_barVb;                   // 0.76: the enemies' health bars
ID3D11Buffer* g_uiVb;                    // 0.77: the weapon wheel
enum { kUiCap = 20000 };
int g_pkeStart, g_pkeEnd;                // 0.93: the probe's own PKE meter
int g_trapStart, g_trapEnd;              // 0.77: the ghost trap model inside the static mesh
struct { volatile LONG pkeDraws, pkeNoPose; } g_pkeOwn;   // 0.93
// 0.93 HANDFEEL: how the tracked hands move, to tell shake / lag / jumps apart ("hands feel awful"): per hand (0 right, 1 left), once per frame
struct HandFeel { long n; double sumDt, maxDt; int have[2]; double p1[2][3], p2[2][3]; float r1[2][9]; double sumV[2], maxV[2], sumJ[2], maxJ[2], sumA[2], maxA[2]; long still[2], jumps[2], bigTurn[2], used[2]; int64_t q; } g_hf;
struct { volatile LONG wheelDraws, wheelMapFail, wheelOver, trapHandDraws, trapHipDraws, shieldDraws, strapDraws, strapMiss; int lastWheelVerts; } g_gear;
enum { kBarCap = 12000, kMarkCap = 1500 };   // 1.7.163: 9000 -> 12000 (rounder vials and rings); 1.7.158: 4000 -> 9000 (a vial of liquid is about 290 vertices, up to 24 of them)
struct { volatile LONG draws, mapFail, over, none; int lastN, lastVerts, maxN; long total; } g_mkd;   // 1.7.3: the collectible markers
struct { volatile LONG draws, mapFail, over, none, seeThrough, solid; int lastBars, lastVerts, maxBars; long barsTotal; } g_bar;
static struct { long fallbackFrames, ogFrames, noFocus; } s_ogc;   // 1.7.106: frames with a ring owner: shown by the game's own ring / by the probe's fallback ring; frames without one
ID3D11BlendState* g_bs;
ID3D11BlendState* g_bsDark;              // 1.7.22: out = dst * (1 - src colour): the comfort vignette (darkness in the vertex colour)
ID3D11BlendState* g_bsWheel;             // 1.6: see-through (constant blend factor = wheel_alpha_pct) for the body of the weapon wheel
ID3D11BlendState* g_bsNoCol;             // 0.77: depth only (the chest shield)
double g_shHead[3], g_shScale = 1.0, g_shYaw; int g_shOk;   // 0.77: where the cord's keep-out torso is (set by the cord step)
ID3D11Texture2D* g_depth;
ID3D11DepthStencilView* g_dsv;
ID3D11Texture2D* g_rtTex[2];             // eye textures an RTV exists for
ID3D11RenderTargetView* g_rtv[2];
UINT g_w, g_h;
int g_wandVerts, g_totalVerts;
int g_state;                             // 0 not tried, 1 ready, <0 failed (why)
struct { volatile LONG draws, noPose, failed; } g_hs;
int g_logged;
// 0.73 the proton hose as a physics cord (cordmath.h): drawn here from a small dynamic vertex buffer, once per eye
ID3D11Buffer* g_cordVb;
cord::Rope g_rope;
int g_ropeInit;
int64_t g_ropeQ;          // when the rope was last stepped
int64_t g_cordDrawQ;      // when the cord was last drawn (read by the game thread: hide the game's own hose while this is fresh)
struct { volatile LONG draws, mapFail, noPose, buildFail; float lastA[3], lastB[3]; long lastTaut; double aboveFloorMin;
        long anchorReal, anchorRej, anchorStale, anchorNone, shieldSkippedDown, cordDownDraws; double anchorDistSum, anchorDistMax; float anchorLastRej;
        long hoseUsed, hoseRej, hoseNone; double hoseDistSum, hoseDistMax; float hoseLast, hoseLastRej; } g_cs;
// 0.74 the rig view (rigmath.h): a small figure of the avatar, seen from the front, with a red dot at the real eye
enum { kRigCap = 14000 };
ID3D11Buffer* g_rigVb;
cord::Rope g_yawRope;     // only its slow body yaw is used: the rig view sits in front of where the player faces
int g_yawInit;
int64_t g_yawQ;
struct RigStat {
  volatile LONG draws, noSnap, stale, mapFail, over, shots;
  int lastVerts; long lastSeq; int64_t seqQ, shotQ, firstQ, dataQ; int dataLogged;
} g_rg;

template <class T> void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

void release_all() {
  rel(g_vs); rel(g_ps); rel(g_psOcc); rel(g_cbOcc); rel(g_il); rel(g_vb); rel(g_cordVb); rel(g_rigVb); rel(g_barVb); rel(g_uiVb); rel(g_cb); rel(g_rs); rel(g_ds); rel(g_dsOff); rel(g_bs); rel(g_bsWheel); rel(g_bsDark); rel(g_bsNoCol); rel(g_dsv); rel(g_depth);
  for (int i = 0; i < 2; ++i) { rel(g_rtv[i]); g_rtTex[i] = nullptr; }
  g_dev = nullptr; g_w = g_h = 0; g_state = 0;
}

int create_resources(ID3D11Device* dev) {
  HMODULE lib = LoadLibraryW(L"d3dcompiler_47.dll");
  if (!lib) return -1;
  pD3DCompile compile = (pD3DCompile)GetProcAddress(lib, "D3DCompile");
  if (!compile) return -2;
  ID3DBlob *vsb = nullptr, *psb = nullptr, *err = nullptr;
  HRESULT h = compile(kShader, lstrlenA(kShader), "gbvr_hands", nullptr, nullptr, "VSMain", "vs_4_0", 0, 0, &vsb, &err);
  if (FAILED(h) || !vsb) {
    if (err) { log_line("HANDS vertex shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    return -3;
  }
  h = compile(kShader, lstrlenA(kShader), "gbvr_hands", nullptr, nullptr, "PSMain", "ps_4_0", 0, 0, &psb, &err);
  if (FAILED(h) || !psb) {
    if (err) { log_line("HANDS pixel shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    vsb->Release();
    return -4;
  }
  int rc = 0;
  D3D11_INPUT_ELEMENT_DESC il[3] = {
    {"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0},
    {"NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0},
    {"COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 24, D3D11_INPUT_PER_VERTEX_DATA, 0}};
  if (FAILED(dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs))) rc = -5;
  else if (FAILED(dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps))) rc = -6;
  else if (FAILED(dev->CreateInputLayout(il, 3, vsb->GetBufferPointer(), vsb->GetBufferSize(), &g_il))) rc = -7;
  vsb->Release(); psb->Release();
  if (rc) return rc;
  {   // 1.7.167: the hand-cut shader for the gun tube (if it fails, the tube is drawn as before)
    ID3DBlob* pob = nullptr; ID3DBlob* er2 = nullptr;
    if (SUCCEEDED(compile(kShader, lstrlenA(kShader), "gbvr_hands", nullptr, nullptr, "PSOcc", "ps_4_0", 0, 0, &pob, &er2)) && pob) {
      if (FAILED(dev->CreatePixelShader(pob->GetBufferPointer(), pob->GetBufferSize(), nullptr, &g_psOcc))) g_psOcc = nullptr;
      pob->Release();
    } else if (er2) { log_line("GUNTUBE hand-cut shader error: %s", (const char*)er2->GetBufferPointer()); }
    if (er2) er2->Release();
    D3D11_BUFFER_DESC bd = {}; bd.ByteWidth = 32; bd.Usage = D3D11_USAGE_DYNAMIC; bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_cbOcc))) g_cbOcc = nullptr;
  }

  static hand::Vertex verts[hand::kMaxVerts];
  hand::Mesh m = {verts, 0, hand::kMaxVerts};
  hand::build_wand(&m);
  g_wandVerts = m.n;
  hand::build_hand(&m);
  g_totalVerts = m.n;
  g_trapStart = m.n;
  hand::build_trap(&m);
  g_trapEnd = m.n;
  g_pkeStart = m.n;
  hand::build_pke(&m);
  g_pkeEnd = m.n;
  D3D11_BUFFER_DESC bd;
  ZeroMemory(&bd, sizeof(bd));
  bd.ByteWidth = (UINT)(m.n * sizeof(hand::Vertex)); bd.Usage = D3D11_USAGE_IMMUTABLE; bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
  D3D11_SUBRESOURCE_DATA sd;
  ZeroMemory(&sd, sizeof(sd));
  sd.pSysMem = verts;
  if (FAILED(dev->CreateBuffer(&bd, &sd, &g_vb))) return -8;
  ZeroMemory(&bd, sizeof(bd));
  bd.ByteWidth = (UINT)(cord::vertex_count() * sizeof(cord::V)); bd.Usage = D3D11_USAGE_DYNAMIC; bd.BindFlags = D3D11_BIND_VERTEX_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
  if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_cordVb))) return -13;
  ZeroMemory(&bd, sizeof(bd));
  bd.ByteWidth = (UINT)(kRigCap * sizeof(cord::V)); bd.Usage = D3D11_USAGE_DYNAMIC; bd.BindFlags = D3D11_BIND_VERTEX_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
  if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_rigVb))) return -14;
  ZeroMemory(&bd, sizeof(bd));
  bd.ByteWidth = (UINT)(kBarCap * sizeof(cord::V)); bd.Usage = D3D11_USAGE_DYNAMIC; bd.BindFlags = D3D11_BIND_VERTEX_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
  if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_barVb))) return -15;
  ZeroMemory(&bd, sizeof(bd));
  bd.ByteWidth = (UINT)(kUiCap * sizeof(cord::V)); bd.Usage = D3D11_USAGE_DYNAMIC; bd.BindFlags = D3D11_BIND_VERTEX_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
  if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_uiVb))) return -17;
  ZeroMemory(&bd, sizeof(bd));
  bd.ByteWidth = 5 * 16; bd.Usage = D3D11_USAGE_DYNAMIC; bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
  if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_cb))) return -9;
  D3D11_RASTERIZER_DESC rd;
  ZeroMemory(&rd, sizeof(rd));
  rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
  if (FAILED(dev->CreateRasterizerState(&rd, &g_rs))) return -10;
  D3D11_DEPTH_STENCIL_DESC dd;
  ZeroMemory(&dd, sizeof(dd));
  dd.DepthEnable = TRUE; dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL; dd.DepthFunc = D3D11_COMPARISON_LESS;
  if (FAILED(dev->CreateDepthStencilState(&dd, &g_ds))) return -11;
  dd.DepthEnable = FALSE; dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO; dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
  if (FAILED(dev->CreateDepthStencilState(&dd, &g_dsOff))) return -16;
  D3D11_BLEND_DESC bl;
  ZeroMemory(&bl, sizeof(bl));
  bl.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
  if (FAILED(dev->CreateBlendState(&bl, &g_bs))) return -12;
  {   // 1.6: out = src*factor + dst*(1-factor); the factor is set at draw time (wheel_alpha_pct). A failure here only means the wheel is drawn solid.
    D3D11_BLEND_DESC bw = bl;
    bw.RenderTarget[0].BlendEnable = TRUE;
    bw.RenderTarget[0].SrcBlend = D3D11_BLEND_BLEND_FACTOR; bw.RenderTarget[0].DestBlend = D3D11_BLEND_INV_BLEND_FACTOR; bw.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bw.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE; bw.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO; bw.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bw.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    if (FAILED(dev->CreateBlendState(&bw, &g_bsWheel))) { g_bsWheel = nullptr; log_line("HANDS wheel see-through blend state failed: the wheel will be drawn solid"); }
  }
  {   // 1.7.22: the vignette multiplies the picture by (1 - colour). A failure only means no vignette.
    D3D11_BLEND_DESC bd2 = bl;
    bd2.RenderTarget[0].BlendEnable = TRUE;
    bd2.RenderTarget[0].SrcBlend = D3D11_BLEND_ZERO; bd2.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_COLOR; bd2.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bd2.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ZERO; bd2.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE; bd2.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bd2.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    if (FAILED(dev->CreateBlendState(&bd2, &g_bsDark))) { g_bsDark = nullptr; log_line("VIGNETTE the darkening blend state could not be made: the comfort vignette is not available"); }
  }
  bl.RenderTarget[0].RenderTargetWriteMask = 0;
  if (FAILED(dev->CreateBlendState(&bl, &g_bsNoCol))) return -18;
  return 1;
}

int ensure_target(ID3D11Device* dev, ID3D11Texture2D* tex, int eye) {
  D3D11_TEXTURE2D_DESC d;
  tex->GetDesc(&d);
  if (d.SampleDesc.Count != 1 || !(d.BindFlags & D3D11_BIND_RENDER_TARGET)) return 0;
  if (d.Width != g_w || d.Height != g_h || !g_depth) {
    rel(g_dsv); rel(g_depth);
    for (int i = 0; i < 2; ++i) { rel(g_rtv[i]); g_rtTex[i] = nullptr; }
    D3D11_TEXTURE2D_DESC t;
    ZeroMemory(&t, sizeof(t));
    t.Width = d.Width; t.Height = d.Height; t.MipLevels = 1; t.ArraySize = 1; t.Format = DXGI_FORMAT_D32_FLOAT;
    t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT; t.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    if (FAILED(dev->CreateTexture2D(&t, nullptr, &g_depth))) return 0;
    if (FAILED(dev->CreateDepthStencilView(g_depth, nullptr, &g_dsv))) { rel(g_depth); return 0; }
    g_w = d.Width; g_h = d.Height;
  }
  if (g_rtTex[eye] != tex || !g_rtv[eye]) {
    rel(g_rtv[eye]);
    g_rtTex[eye] = tex;
    if (FAILED(dev->CreateRenderTargetView(tex, nullptr, &g_rtv[eye]))) { g_rtTex[eye] = nullptr; return 0; }
  }
  return 1;
}

struct Saved {
  ID3D11RenderTargetView* rtv[1]; ID3D11DepthStencilView* dsv;
  D3D11_VIEWPORT vp[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE]; UINT nvp;
  ID3D11RasterizerState* rs; ID3D11BlendState* bs; float bf[4]; UINT mask; ID3D11DepthStencilState* ds; UINT sref;
  ID3D11InputLayout* il; D3D11_PRIMITIVE_TOPOLOGY topo;
  ID3D11Buffer* vb; UINT stride, offset;
  ID3D11VertexShader* vs; ID3D11PixelShader* ps; ID3D11GeometryShader* gs; ID3D11HullShader* hs; ID3D11DomainShader* dsh;
  ID3D11Buffer* cb;
  ID3D11Buffer* pcb1;   // 1.7.167: pixel shader constants slot 1 (the hand balls)
};

void save(ID3D11DeviceContext* c, Saved* s) {
  ZeroMemory(s, sizeof(*s));
  c->OMGetRenderTargets(1, s->rtv, &s->dsv);
  s->nvp = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
  c->RSGetViewports(&s->nvp, s->vp);
  c->RSGetState(&s->rs);
  c->OMGetBlendState(&s->bs, s->bf, &s->mask);
  c->OMGetDepthStencilState(&s->ds, &s->sref);
  c->IAGetInputLayout(&s->il);
  c->IAGetPrimitiveTopology(&s->topo);
  c->IAGetVertexBuffers(0, 1, &s->vb, &s->stride, &s->offset);
  c->VSGetShader(&s->vs, nullptr, nullptr);
  c->PSGetShader(&s->ps, nullptr, nullptr);
  c->GSGetShader(&s->gs, nullptr, nullptr);
  c->HSGetShader(&s->hs, nullptr, nullptr);
  c->DSGetShader(&s->dsh, nullptr, nullptr);
  c->VSGetConstantBuffers(0, 1, &s->cb);
  c->PSGetConstantBuffers(1, 1, &s->pcb1);
}

void restore(ID3D11DeviceContext* c, Saved* s) {
  c->OMSetRenderTargets(1, s->rtv, s->dsv);
  c->RSSetViewports(s->nvp, s->vp);
  c->RSSetState(s->rs);
  c->OMSetBlendState(s->bs, s->bf, s->mask);
  c->OMSetDepthStencilState(s->ds, s->sref);
  c->IASetInputLayout(s->il);
  c->IASetPrimitiveTopology(s->topo);
  c->IASetVertexBuffers(0, 1, &s->vb, &s->stride, &s->offset);
  c->VSSetShader(s->vs, nullptr, 0);
  c->PSSetShader(s->ps, nullptr, 0);
  c->GSSetShader(s->gs, nullptr, 0);
  c->HSSetShader(s->hs, nullptr, 0);
  c->DSSetShader(s->dsh, nullptr, 0);
  c->VSSetConstantBuffers(0, 1, &s->cb);
  c->PSSetConstantBuffers(1, 1, &s->pcb1);
  rel(s->pcb1);
  rel(s->rtv[0]); rel(s->dsv); rel(s->rs); rel(s->bs); rel(s->ds); rel(s->il); rel(s->vb);
  rel(s->vs); rel(s->ps); rel(s->gs); rel(s->hs); rel(s->dsh); rel(s->cb);
}

int set_constants(ID3D11DeviceContext* c, const hand::Xform& x, double tanH, double tanV, float glow, double farM = 10.0) {
  D3D11_MAPPED_SUBRESOURCE mp;
  if (FAILED(c->Map(g_cb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp))) return 0;
  float* f = (float*)mp.pData;
  const double n = 0.02, fa = farM;
  for (int r = 0; r < 3; ++r) { f[r * 4] = x.r[r * 3]; f[r * 4 + 1] = x.r[r * 3 + 1]; f[r * 4 + 2] = x.r[r * 3 + 2]; f[r * 4 + 3] = x.t[r]; }
  f[12] = (float)(1.0 / tanH); f[13] = (float)(1.0 / tanV); f[14] = (float)(fa / (fa - n)); f[15] = (float)(-fa * n / (fa - n));
  f[16] = 0.35f; f[17] = 0.8f; f[18] = -0.45f; f[19] = glow;   // light direction (towards the light, eye axes), emissive scale
  c->Unmap(g_cb, 0);
  return 1;
}
}  // namespace

int handmodel_available() { return g_state >= 0 && g_ctl.handModel; }

void ring_fallback_counts(long* og, long* fb, long* none) { *og = s_ogc.ogFrames; *fb = s_ogc.fallbackFrames; *none = s_ogc.noFocus; }   // 1.7.106

void handmodel_release() { release_all(); }

// 0.73: true while the probe keeps drawing the physics cord (so the game's own hose is hidden)
int handmodel_cord_active() {
  if (g_state != 1 || !g_cordDrawQ) return 0;
  return qpc_now() - g_cordDrawQ < qpc_freq() / 2;
}

namespace {
// Steps the rope once per frame pair (both eyes use the same shape). Returns 1 if a cord can be drawn.
int cord_update(const float* headPose34, const HandsRaw& hr) {
  const float* wp = hr.wandValid ? hr.wandPose : (hr.validR ? hr.poseR : nullptr);
  if (!wp) return 0;
  const int64_t now = qpc_now();
  double dt = g_ropeQ ? (double)(now - g_ropeQ) / (double)qpc_freq() : 0.011;
  if (!g_ropeInit) { g_rope.init(); g_ropeInit = 1; dt = 0.011; }
  double head[3] = {headPose34[3], headPose34[7], headPose34[11]};
  const double hh = head[1];
  const double scale = hh < 0.9 ? 1.0 : hh / 1.6;   // the pack hangs lower on a tall player (a bad height reading is ignored)
  if (g_ropeQ && dt < 0.002) return g_rope.have;     // second eye of the same frame: same shape
  g_ropeQ = now;
  cord::body_yaw(&g_rope, cord::pose_yaw(headPose34), dt);
  double A[3], eA[3], B[3], dir[3];
  // 0.75: the avatar stands bodyOutCm in front of the real eye and viewUpCm lower (arm_drive): its pack, and the torso the cord lies over, do too
  const int bodyShift = g_ctl.fullBody && g_ctl.bodyFollow && g_ctl.bodyEyeAlign;
  const double outM = bodyShift ? 0.01 * (double)g_ctl.bodyOutCm : 0.0, downM = bodyShift ? -0.01 * (double)g_ctl.bodyHeightCm : 0.0;
  cord::pack_anchor(headPose34, g_rope.yaw, scale, A, eA, outM, downM);
  {   // 0.84: the hose starts at the game's REAL pack (its bottom, a little to the right), not at a guessed spot behind the head: the 0.83 hose hung in the air in front of the pack
    static long s_seq; static int64_t s_q;
    rig::Snap ps;
    ps.clear();
    if (g_ctl.realAnchor && arms_rig_read(&ps) && ps.have && ps.packOk && ps.ok[rig::J_SHR] && ps.ok[rig::J_SHL] && ps.ok[rig::J_NECK] && ps.ok[rig::J_SPINE3] && ps.fpm > 0.5f) {
      if (ps.seq != s_seq) { s_seq = ps.seq; s_q = now; }
      if (s_q && now - s_q < qpc_freq() / 3) {
        double R[3], U[3];
        for (int i = 0; i < 3; ++i) { R[i] = (double)ps.j[rig::J_SHR][i] - (double)ps.j[rig::J_SHL][i]; U[i] = (double)ps.j[rig::J_NECK][i] - (double)ps.j[rig::J_SPINE3][i]; }
        const double rl = cord::len3(R), ul = cord::len3(U);
        if (rl > 0.3 && rl < 4.0 && ul > 0.05) {
          double q[3], P[3];
          for (int i = 0; i < 3; ++i) q[i] = (double)ps.pack[i] - U[i] / ul * 0.42 + R[i] / rl * 0.06;   // headset axes, feet
          const double h[3] = {q[0] / ps.fpm, q[1] / ps.fpm, -q[2] / ps.fpm};
          for (int r = 0; r < 3; ++r) P[r] = (double)headPose34[r * 4 + 3] + (double)headPose34[r * 4 + 0] * h[0] + (double)headPose34[r * 4 + 1] * h[1] + (double)headPose34[r * 4 + 2] * h[2];
          const double dx = P[0] - A[0], dy = P[1] - A[1], dz = P[2] - A[2], dd = vm::dsqrt(dx * dx + dy * dy + dz * dz);
          if (dd < 0.60) {
            for (int i = 0; i < 3; ++i) A[i] = P[i];
            ++g_cs.anchorReal; g_cs.anchorDistSum += dd; if (dd > g_cs.anchorDistMax) g_cs.anchorDistMax = dd;
          } else { ++g_cs.anchorRej; g_cs.anchorLastRej = (float)dd; }
        }
      } else ++g_cs.anchorStale;
    } else ++g_cs.anchorNone;
  }
  cord::wand_anchor(wp, B, dir);
  {
    double fw[3], rt[3];
    cord::yaw_axes(g_rope.yaw, fw, rt);
    for (int i = 0; i < 3; ++i) head[i] += fw[i] * outM;
    head[1] -= downM;
  }
  // 0.76: where the game itself puts the hose on the drawn gun (headset axes from the head centre -> tracking space); the cord ends exactly there
  int hoseUsed = 0;
  {
    float he[3];
    if (fight_hose_end(he)) {
      const double x = he[0], y = he[1], z = -(double)he[2];
      double P[3];
      for (int j = 0; j < 3; ++j) P[j] = (double)headPose34[j * 4 + 3] + (double)headPose34[j * 4 + 0] * x + (double)headPose34[j * 4 + 1] * y + (double)headPose34[j * 4 + 2] * z;
      const double dx = P[0] - B[0], dy = P[1] - B[1], dz = P[2] - B[2];
      const double d = vm::dsqrt(dx * dx + dy * dy + dz * dz);
      if (d < 0.30) {
        for (int i = 0; i < 3; ++i) B[i] = P[i];
        hoseUsed = 1;
        ++g_cs.hoseUsed; g_cs.hoseDistSum += d; if (d > g_cs.hoseDistMax) g_cs.hoseDistMax = d; g_cs.hoseLast = (float)d;
      } else { ++g_cs.hoseRej; g_cs.hoseLastRej = (float)d; }
    } else ++g_cs.hoseNone;
  }
  const double back = (double)g_ctl.wandBackCm * 0.01;   // the wand slid back along its barrel
  if (back != 0.0 && !hoseUsed) for (int i = 0; i < 3; ++i) B[i] += dir[i] * back;
  for (int i = 0; i < 3; ++i) { g_cs.lastA[i] = (float)A[i]; g_cs.lastB[i] = (float)B[i]; }
  cord::step(&g_rope, A, eA, B, dir, head, scale, 0.0, dt);
  for (int i = 0; i < 3; ++i) g_shHead[i] = head[i];
  g_shScale = scale; g_shYaw = g_rope.yaw; g_shOk = 1;   // 0.77: the chest shield uses the same torso the cord was kept out of
  g_cs.lastTaut = g_rope.taut;
  return g_rope.have;
}
}  // namespace

namespace {
// 0.74 the rig view: where the miniature stands and how it is turned. Returns 1 if there is something to draw.
void rig_frame(const float* h34, const HandsRaw& hr, const rig::Snap& sn, int haveSnap, rig::Frame* f, int64_t now) {
  char* z = (char*)f;
  for (size_t i = 0; i < sizeof(*f); ++i) z[i] = 0;
  for (int i = 0; i < 3; ++i) f->head[i] = h34[i * 4 + 3];
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) f->Rh[r * 3 + c] = h34[r * 4 + c];
  if (!g_yawInit) { g_yawRope.init(); g_yawInit = 1; g_yawQ = 0; }
  const double dt = g_yawQ ? (double)(now - g_yawQ) / (double)qpc_freq() : 0.011;
  if (!g_yawQ || dt > 0.002) { cord::body_yaw(&g_yawRope, cord::pose_yaw(h34), dt > 0.1 ? 0.1 : dt); g_yawQ = now; }
  double fw[3], rt[3];
  cord::yaw_axes(g_yawRope.yaw, fw, rt);
  for (int i = 0; i < 3; ++i) f->C[i] = f->head[i] + fw[i] * 1.15 - rt[i] * 0.50;
  f->C[1] = f->head[1] + 0.05;
  const int mode = (int)g_ctl.rigView;
  f->delta = mode == 1 ? vm::kPi : mode == 2 ? 0.5 * vm::kPi : mode == 3 ? 0.0 : -0.5 * vm::kPi;
  f->k = 0.4;
  f->fpm = (haveSnap && sn.fpm > 0.5f) ? (double)sn.fpm : 3.28084;
  f->floorY = 0.0;
  const float* wp = hr.wandValid ? hr.wandPose : (hr.validR ? hr.poseR : nullptr);
  if (wp) {
    f->haveR = 1;
    for (int i = 0; i < 3; ++i) { f->ctrlR[i] = wp[i * 4 + 3]; f->ctrlRAim[i] = -(double)wp[i * 4 + 2]; }
  }
  if (hr.validL) { f->haveL = 1; for (int i = 0; i < 3; ++i) f->ctrlL[i] = hr.poseL[i * 4 + 3]; }
  if (g_rope.have && handmodel_cord_active()) {
    f->haveCord = 1;
    for (int i = 0; i < cord::kN; ++i) for (int k = 0; k < 3; ++k) f->cord[i][k] = g_rope.p[i][k];
    for (int k = 0; k < 3; ++k) { f->anchorA[k] = g_rope.p[0][k]; f->anchorB[k] = g_rope.p[cord::kN - 1][k]; }
  }
}

// metres from the eye in the headset's axes (right, up, forward) of a tracking-space point
void head_rel(const float* h34, const double* P, double* o) {
  const double v[3] = {P[0] - h34[3], P[1] - h34[7], P[2] - h34[11]};
  for (int c = 0; c < 3; ++c) o[c] = h34[0 * 4 + c] * v[0] + h34[1 * 4 + c] * v[1] + h34[2 * 4 + c] * v[2];
  o[2] = -o[2];
}

// numbers for the log: the avatar's joints and the real controllers, in metres from the eye (right, up, forward)
void rig_log(const float* h34, const HandsRaw& hr, const rig::Snap& sn) {
  const double m = 1.0 / (double)(sn.fpm > 0.5f ? sn.fpm : 3.28084f);
  static const char* const nm[rig::kJ] = {"head", "neck", "spine3", "spine1", "pelvis", "clavR", "shoulderR", "elbowR", "wristR", "clavL", "shoulderL", "elbowL", "wristL",
                                          "hipL", "kneeL", "footL", "hipR", "kneeR", "footR", "eyeL", "eyeR"};
  char b[1400]; int n = 0;
  for (int i = 0; i < rig::kJ && n < 1250; ++i)
    if (sn.ok[i]) n += wsprintfA(b + n, " %s=%d,%d,%d", nm[i], (int)(sn.j[i][0] * m * 100.0), (int)(sn.j[i][1] * m * 100.0), (int)(sn.j[i][2] * m * 100.0));
  b[n] = 0;
  log_line("RIGDATA joints in cm from the eye (right,up,forward):%s", b);
  n = 0;
  if (sn.packOk) n += wsprintfA(b + n, " pack=%d,%d,%d (axes x %d,%d,%d y %d,%d,%d z %d,%d,%d)", (int)(sn.pack[0] * m * 100.0), (int)(sn.pack[1] * m * 100.0), (int)(sn.pack[2] * m * 100.0),
                                (int)(sn.packAx[0][0] * 100), (int)(sn.packAx[0][1] * 100), (int)(sn.packAx[0][2] * 100), (int)(sn.packAx[1][0] * 100), (int)(sn.packAx[1][1] * 100), (int)(sn.packAx[1][2] * 100),
                                (int)(sn.packAx[2][0] * 100), (int)(sn.packAx[2][1] * 100), (int)(sn.packAx[2][2] * 100));
  if (sn.hoseOk) n += wsprintfA(b + n, " gameHose=%d,%d,%d", (int)(sn.hose[0] * m * 100.0), (int)(sn.hose[1] * m * 100.0), (int)(sn.hose[2] * m * 100.0));
  const float* wp = hr.wandValid ? hr.wandPose : (hr.validR ? hr.poseR : nullptr);
  double o[3];
  if (wp) { const double P[3] = {wp[3], wp[7], wp[11]}; head_rel(h34, P, o); n += wsprintfA(b + n, " controllerR=%d,%d,%d", (int)(o[0] * 100.0), (int)(o[1] * 100.0), (int)(o[2] * 100.0)); }
  if (hr.validL) { const double P[3] = {hr.poseL[3], hr.poseL[7], hr.poseL[11]}; head_rel(h34, P, o); n += wsprintfA(b + n, " controllerL=%d,%d,%d", (int)(o[0] * 100.0), (int)(o[1] * 100.0), (int)(o[2] * 100.0)); }
  if (g_rope.have) { const double A[3] = {g_rope.p[0][0], g_rope.p[0][1], g_rope.p[0][2]}; head_rel(h34, A, o); n += wsprintfA(b + n, " cordPackEnd=%d,%d,%d", (int)(o[0] * 100.0), (int)(o[1] * 100.0), (int)(o[2] * 100.0)); }
  b[n] = 0;
  log_line("RIGDATA parts in cm from the eye (right,up,forward):%s | arm stretch R/L %d%%/%d%% | head tilt: up-vector y %.2f", b, (int)(sn.stretch[0] * 100.0f), (int)(sn.stretch[1] * 100.0f), (double)h34[5]);
}

// 1.4 FLOATCHECK: the numbers that tell a "floating body" from a good one, without the rig view: how far the body stands from the eye, how far the torso leans from the vertical, how far the avatar's wrist is from the controller.
// Returns the wrist-to-controller miss in cm (-1 = not known) and the torso lean (degrees from the vertical, forward positive; -999 = not known).
void float_log(const float* h34, const HandsRaw& hr, const rig::Snap& sn, int cur, double* missCm, double* leanDeg) {
  *missCm = -1.0; *leanDeg = -999.0;
  const double m = 1.0 / (double)(sn.fpm > 0.5f ? sn.fpm : 3.28084f);
  auto J = [&](int i, double* o) -> int { for (int k = 0; k < 3; ++k) o[k] = (double)sn.j[i][k] * m * 100.0; return sn.ok[i]; };   // 0 head 1 neck 2 spine3 3 spine1 4 pelvis 5 clavR 6 shoulderR 7 elbowR 8 wristR
  double neck[3] = {0}, pelvis[3] = {0}, spine3[3] = {0}, shR[3] = {0}, wrR[3] = {0};
  const int okN = J(1, neck), okP = J(4, pelvis), okS = J(2, spine3), okSh = J(6, shR), okW = J(8, wrR);
  const double fwdY = -(double)h34[9];
  const double pitch = vm::datan2(fwdY, vm::dsqrt(1.0 - (fwdY > 1 ? 1 : (fwdY < -1 ? -1 : fwdY)) * (fwdY > 1 ? 1 : (fwdY < -1 ? -1 : fwdY)))) * 180.0 / vm::kPi;
  if (okN && okP) {
    const double up = neck[1] - pelvis[1], fw = neck[2] - pelvis[2];
    *leanDeg = vm::datan2(fw, up) * 180.0 / vm::kPi + pitch;   // 1.7.23: the points are in the head's axes, so the world tilt is the angle PLUS the head pitch (1.7.22 subtracted it and printed -120 for an upright torso)
  }
  double ctl[3] = {0}; int okC = 0;
  const float* wp = hr.wandValid ? hr.wandPose : (hr.validR ? hr.poseR : nullptr);
  if (wp) { const double P[3] = {wp[3], wp[7], wp[11]}; head_rel(h34, P, ctl); for (int k = 0; k < 3; ++k) ctl[k] *= 100.0; okC = 1; }
  double armLen = 0.0, miss = -1.0, reach = 0.0;
  if (okSh && okW) armLen = vm::dsqrt((wrR[0] - shR[0]) * (wrR[0] - shR[0]) + (wrR[1] - shR[1]) * (wrR[1] - shR[1]) + (wrR[2] - shR[2]) * (wrR[2] - shR[2]));
  if (okW && okC) miss = vm::dsqrt((wrR[0] - ctl[0]) * (wrR[0] - ctl[0]) + (wrR[1] - ctl[1]) * (wrR[1] - ctl[1]) + (wrR[2] - ctl[2]) * (wrR[2] - ctl[2]));
  if (okSh && okC) reach = vm::dsqrt((ctl[0] - shR[0]) * (ctl[0] - shR[0]) + (ctl[1] - shR[1]) * (ctl[1] - shR[1]) + (ctl[2] - shR[2]) * (ctl[2] - shR[2]));
  *missCm = miss;
  static const char* const itemName[8] = {"none", "proton gun", "meson", "boson", "trap", "PKE", "light", "slime"};
  log_line("FLOATCHECK item in hand=%d (%s), body stays with the PKE=%d | torso lean from the vertical %.0f deg (neck above pelvis %d cm), head pitch %.0f deg, head tilt up-y %.2f | "
           "from the eye (right,up,forward cm): neck %d,%d,%d spine3 %d,%d,%d pelvis %d,%d,%d shoulderR %d,%d,%d wristR %d,%d,%d | controllerR %d,%d,%d | avatar arm %d cm long, shoulder to controller %d cm, wrist misses the controller by %d cm | arm stretch R %d%% (%s)",
           cur, (cur >= 0 && cur < 8) ? itemName[cur] : "?", (int)g_ctl.pkeShowBody, *leanDeg > -900.0 ? *leanDeg : 0.0, (int)(okN && okP ? neck[1] - pelvis[1] : 0), pitch, (double)h34[5],
           (int)neck[0], (int)neck[1], (int)neck[2], (int)spine3[0], (int)spine3[1], (int)spine3[2], (int)pelvis[0], (int)pelvis[1], (int)pelvis[2], (int)shR[0], (int)shR[1], (int)shR[2], (int)wrR[0], (int)wrR[1], (int)wrR[2],
           (int)ctl[0], (int)ctl[1], (int)ctl[2], (int)armLen, (int)reach, (int)miss, (int)(sn.stretch[0] * 100.0f), okSh && okW && okC ? "known" : "some joints missing");
}
}  // namespace

// headPose34: head pose the picture was rendered for. eyeX: eye offset in head space (metres).
void handmodel_draw(ID3D11Device* dev, ID3D11DeviceContext* ctx, ID3D11Texture2D* eyeTex, int eye, const float* headPose34,
                    float eyeX, float tanH, float tanV) {
  if (!g_ctl.handModel || g_state < 0 || !dev || !ctx || !eyeTex) return;
  if (!(tanH > 0.01f) || !(tanV > 0.01f)) return;
  // the hands and wand are drawn only where the game's own body and wand are hidden (first-person headset view);
  // 0.73: the physics cord is drawn with the game's own models too (its pack end and the wand end are the probe's own anchors)
  const int gloveMode = engine_glove_mode();   // 0.83: no body or arms: plain static gloves at the controllers, the game's own gun / hose stay
  const int doHands = gloveMode || (!g_ctl.realModels && g_ctl.hideBody && g_ctl.hideWand && g_ctl.firstPerson);   // 0.51: with the game's own models shown no hands are drawn here
  const int doCord = g_ctl.cordPhysics && g_ctl.firstPerson && !g_ctl.hoseOff && !engine_scene_arms(0); // clear view during the Stay Puft fight
  const int doRig = g_ctl.rigView != 0;   // 0.74
  const int doBars = g_ctl.hbar != 0 && g_ctl.ringAssist != 0;   // 1.7.180: Ghost health Off = the mod adds no ghost health at all     // 0.76: the enemies' health bars
  const int doMarks = g_ctl.collectMarkers != 0;   // 1.7.3: glowing markers on collectibles
  const int doGear = g_ctl.weaponWheel != 0 || (g_ctl.trapThrow != 0 && g_ctl.firstPerson);   // 0.77: weapon wheel, ghost trap on the hip / in the hand
  const int doGunBar = g_ctl.gunHpBar != 0 && g_ctl.firstPerson;   // 1.7.37: the life bar on top of the gun
  const int doPke = g_ctl.pkeOwn != 0 && g_ctl.firstPerson;   // 0.93: the probe's own PKE meter in the right hand while the PKE is the item in hand
  if (!doHands && !doCord && !doRig && !doBars && !doMarks && !doGear && !doPke && !doGunBar) return;
  HandsRaw hr;
  { char* z = (char*)&hr; for (size_t i = 0; i < sizeof(hr); ++i) z[i] = 0; }
  if (!controllers_raw(&hr)) { InterlockedIncrement(&g_hs.noPose); if (!doRig && !doBars && !doMarks) return; }
  if (g_ctl.probeData && (eye & 1) == 0 && hr.validR) {   // diagnostic controller motion statistics
    const int64_t qn = qpc_now();
    const double dt = g_hf.q ? (double)(qn - g_hf.q) / (double)qpc_freq() : 0.0;
    g_hf.q = qn;
    if (dt > 0.0005 && dt < 0.2) {
      ++g_hf.n; g_hf.sumDt += dt; if (dt > g_hf.maxDt) g_hf.maxDt = dt;
      for (int h = 0; h < 2; ++h) {
        const float* pose = h == 0 ? hr.poseR : hr.poseL;
        if (h == 1 && !hr.validL) { g_hf.have[1] = 0; continue; }
        const double p[3] = {pose[3], pose[7], pose[11]};
        if (g_hf.have[h]) {
          const double dx = p[0] - g_hf.p1[h][0], dy = p[1] - g_hf.p1[h][1], dz = p[2] - g_hf.p1[h][2];
          const double d = vm::dsqrt(dx * dx + dy * dy + dz * dz), v = d / dt;
          g_hf.sumV[h] += v; if (v > g_hf.maxV[h]) g_hf.maxV[h] = v;
          if (v > 8.0) ++g_hf.jumps[h];
          if (d < 0.0004) ++g_hf.still[h];
          if (g_hf.have[h] > 1) {   // the second difference: how far the point is from the straight line through the last two (shake)
            const double jx = p[0] - 2 * g_hf.p1[h][0] + g_hf.p2[h][0], jy = p[1] - 2 * g_hf.p1[h][1] + g_hf.p2[h][1], jz = p[2] - 2 * g_hf.p1[h][2] + g_hf.p2[h][2];
            const double j = vm::dsqrt(jx * jx + jy * jy + jz * jz);
            g_hf.sumJ[h] += j; if (j > g_hf.maxJ[h]) g_hf.maxJ[h] = j;
          }
          double tr = 0;
          for (int i = 0; i < 3; ++i) for (int k = 0; k < 3; ++k) tr += (double)g_hf.r1[h][k * 3 + i] * (double)pose[k * 4 + i];
          double cs = (tr - 1.0) * 0.5; if (cs > 1.0) cs = 1.0; if (cs < -1.0) cs = -1.0;
          const double ang = vm::datan2(vm::dsqrt(1.0 - cs * cs), cs) * 180.0 / vm::kPi;
          g_hf.sumA[h] += ang; if (ang > g_hf.maxA[h]) g_hf.maxA[h] = ang;
          if (ang > 25.0) ++g_hf.bigTurn[h];
          ++g_hf.used[h];
        }
        for (int i = 0; i < 3; ++i) { g_hf.p2[h][i] = g_hf.p1[h][i]; g_hf.p1[h][i] = p[i]; }
        for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) g_hf.r1[h][r * 3 + c] = pose[r * 4 + c];
        if (g_hf.have[h] < 2) ++g_hf.have[h];
      }
    }
  }
  if (g_dev != dev) { release_all(); g_dev = dev; }
  if (g_state == 0) {
    g_state = create_resources(dev);
    if (g_state != 1) {
      log_line("HANDS could not be set up (code %d): the hands, wand, cord and rig view are not drawn", g_state);
      return;
    }
    log_line("HANDS ready: wand %d vertices, total %d, cord %d vertices, rig view up to %d", g_wandVerts, g_totalVerts, cord::vertex_count(), (int)kRigCap);
  }
  if (!ensure_target(dev, eyeTex, eye & 1)) { InterlockedIncrement(&g_hs.failed); return; }
  if ((eye & 1) == 0) hosetex_render_step(dev, ctx);   // 0.78: reads the game's hose texture(s) found by the game thread (a few times in total)
  {   // 0.78: the hose's colour = the game's hose texture's average colour relative to the default black rubber (1,1,1 = unchanged)
    float* tn = cord::hose_tint();
    float rgb[3];
    if (hosetex_color(rgb)) { for (int i = 0; i < 3; ++i) { float t = rgb[i] / 0.06f; if (t < 0.3f) t = 0.3f; if (t > 10.0f) t = 10.0f; tn[i] = t; } }
    else { tn[0] = tn[1] = tn[2] = 1.0f; }
  }
  float eyeOff[3] = {eyeX, 0, 0};
  hand::Xform xr, xl;
  double pitch = g_ctl.handPitchDeci / 10.0;
  int haveR = 0, haveL = 0;
  if (doHands) {
    // both grips held: the wand lies along the line between the hands (same line the beam uses)
    float two[12];
    int twoHand = g_ctl.twoHandLine && hr.validR && hr.validL && hr.gripL && hand::two_hand_pose_ref(hr.poseR, hr.poseL, 0.12, (double)g_ctl.dpadAwayCm / 100.0, (double)g_ctl.twoHandPitchDeci / 10.0, (double)g_ctl.twoHandRefCm / 100.0, two);
    haveR = hr.validR && (hr.wandValid ? hand::model_to_eye(headPose34, hr.wandPose, eyeOff, hr.wandTwo ? 0.0 : pitch, &xr)   // 0.51: weighted wand pose
                          : twoHand ? hand::model_to_eye(headPose34, two, eyeOff, 0.0, &xr)
                                    : hand::model_to_eye(headPose34, hr.poseR, eyeOff, pitch, &xr));
    haveL = hr.validL && hand::model_to_eye(headPose34, hr.poseL, eyeOff, 0.0, &xl);
  }
  // 0.73 the cord (and 0.74 the rig view): tracking space -> this eye (a device at the tracking origin with no turn)
  hand::Xform xc;
  int haveX = 0, haveC = 0, haveRig = 0;
  {
    static const float ident[12] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0};
    haveX = hand::model_to_eye(headPose34, ident, eyeOff, 0.0, &xc);
  }
  if (doCord && !hr.holstered && (hr.validR || hr.wandValid) && !engine_pke_mode()) {
    if (haveX && cord_update(headPose34, hr)) haveC = 1;
    else InterlockedIncrement(&g_cs.noPose);
  }
  // the rig view: the miniature (built below, after the other things are set up)
  static rig::Snap sn;
  int snOk = 0, snFresh = 0;
  const int64_t nowQ = qpc_now();
  if (doRig && haveX) {
    haveRig = 1;
    rig::Snap t;
    t.clear();
    if (arms_rig_read(&t)) {
      sn = t; snOk = 1;
      if (t.seq != g_rg.lastSeq) { g_rg.lastSeq = t.seq; g_rg.seqQ = nowQ; }
      snFresh = g_rg.seqQ && (nowQ - g_rg.seqQ) < qpc_freq() * 3 / 2;
    }
    if (!snFresh) InterlockedIncrement(&g_rg.stale);
    if (!snOk) InterlockedIncrement(&g_rg.noSnap);
  }
  // 1.4: every 4 s (first 160 times) the numbers of the avatar's body, with or without the rig view; a picture when the body looks wrong (wrist away from the controller, or the torso leaning a lot more than a moment ago)
  if (g_ctl.probeData && haveX && (eye & 1) == 0) {
    static int64_t s_fq, s_pq; static LONG s_fn, s_shots; static double s_lastLean = -999.0;
    const int64_t nq = qpc_now();
    const double fq = (double)qpc_freq();
    if (s_fn < 160 && (!s_fq || (double)(nq - s_fq) / fq >= 4.0)) {
      rig::Snap t; t.clear();
      if (arms_rig_read(&t) && t.have) {
        s_fq = nq; ++s_fn;
        int stx[gear::kItemCount]; int curx = -1;
        fight_items(stx, &curx);
        double miss = -1.0, lean = -999.0;
        float_log(headPose34, hr, t, curx, &miss, &lean);
        const int bad = (miss > 15.0) || (s_lastLean > -900.0 && lean > -900.0 && (lean - s_lastLean > 18.0 || s_lastLean - lean > 18.0));
        if (lean > -900.0) s_lastLean = lean;
        if (bad && s_shots < 6 && (!s_pq || (double)(nq - s_pq) / fq >= 20.0)) {
          s_pq = nq; ++s_shots;
          log_line("FLOATCHECK the body looks off (wrist %.0f cm from the controller, torso lean %.0f deg): a picture of both eyes is saved (%ld of 6)", miss, lean, s_shots);
          shot_request();
        }
      }
    }
  }
  // 0.76: the health bars (their positions are in the headset's axes from the head centre, so no controller pose is needed)
  static fight::Bar bars[fight::kMaxBars];
  int nBars = 0;
  if (doBars) {
    nBars = fight_bars_read(bars, fight::kMaxBars, nullptr);
    if (nBars < 0) nBars = 0;
    if (!nBars) InterlockedIncrement(&g_bar.none);
  }
  int haveBars = nBars > 0;
  {   // 1.7.106: with og_health the ring you see is the game's own; the probe's round ring is drawn only when the game's has not been on the screen for 0.3 s although a ghost or boss has the ring (and after a 0.6 s wait, so it does not flash while the game's ring fades in)
    static long long s_ogSince;
    if (haveBars && health_og()) {
      int focus = 0;
      for (int i = 0; i < nBars; ++i) if (bars[i].flags & fight::kFlagFocus) { focus = 1; break; }
      const long long nowMs = (long long)qpc_ms();
      const long long ageMs = hud_og_ring_age_ms();
      const long long ogMs = ageMs >= 0 ? nowMs - ageMs : 0;
      const int fb = bossring::fallback_due(focus, nowMs, ogMs, &s_ogSince, 300, 600);
      if (!focus) ++s_ogc.noFocus; else if (fb) ++s_ogc.fallbackFrames; else ++s_ogc.ogFrames;
      if (!fb) haveBars = 0;
      static long s_ogLogged;
      if (focus && fb && ++s_ogLogged <= 5) log_line("RINGOG the game's own health ring is not on the screen (last drawn %lld ms ago): the probe's round ring is shown instead (fallback #%ld)", ageMs, s_ogLogged);
    }
  }
  // 0.77: the weapon wheel (at the right hand while it is open) and the ghost trap (in the left hand, or on the left hip waiting)
  static cord::V uv[kUiCap];
  int wheelN = 0, wheelSolidFrom = 0, haveTrapHand = 0, haveTrapHip = 0, havePke = 0;
  hand::Xform xPke;
  hand::Xform xTrapHand, xTrapHip, xWheel;
  if (doGear) {
    if (g_ctl.weaponWheel && hr.wheelOpen && hr.wheelOpenT > 0.0f) {   // 0.78: the wheel stands where it opened (pose in tracking space), its plane faces you
      int st[gear::kItemCount];
      int cur = -1;
      const int fresh = fight_items(st, &cur);
      double hv[gear::kSlots];
      for (int i = 0; i < gear::kSlots; ++i) hv[i] = (double)hr.wheelHov[i];
      gear::WheelView wv;
      wv.openT = (double)hr.wheelOpenT; wv.hov = hv;
      wv.sel = hr.wheelSel; wv.picked = hr.wheelPicked; wv.pickLocked = hr.wheelPickLocked; wv.flash = (double)hr.wheelFlash;
      wv.current = fresh ? cur : -1;
      wv.state = fresh ? st : nullptr;
      wv.curX = (double)hr.wheelCurX; wv.curY = (double)hr.wheelCurY;
      wv.scale = (double)g_ctl.wheelScalePct / 100.0;
      wheelN = gear::build_wheel(wv, uv, (int)kUiCap, &wheelSolidFrom);
      if (wheelN < 0) { InterlockedIncrement(&g_gear.wheelOver); wheelN = 0; }
      if (wheelN > 0 && !hand::model_to_eye(headPose34, hr.wheelPose, eyeOff, 0.0, &xWheel)) wheelN = 0;
    }
    if (g_ctl.trapThrow && g_ctl.firstPerson && g_ctl.trapOwnModel) {   // 0.79: only when asked for; otherwise the game's own trap is carried
      if (hr.trapHeld && hr.validL) haveTrapHand = hand::model_to_eye(headPose34, hr.poseL, eyeOff, 0.0, &xTrapHand);
      else if (!hr.trapHeld) {
        // waiting on the left hip: yaw-only pose, same point the grab zone uses (22 cm to the left, 55 cm below the eye)
        const double yaw = cord::pose_yaw(headPose34);
        double fw[3], rt[3];
        cord::yaw_axes(yaw, fw, rt);
        float hp[12];
        for (int r = 0; r < 3; ++r) {
          hp[r * 4 + 0] = (float)rt[r];
          hp[r * 4 + 1] = r == 1 ? 1.0f : 0.0f;
          hp[r * 4 + 2] = (float)-fw[r];
          hp[r * 4 + 3] = (float)((double)headPose34[r * 4 + 3] - rt[r] * (controllers_left_applied() ? -0.22 : 0.22) - (r == 1 ? 0.01 * (double)g_ctl.trapHipDropCm : 0.0));
        }
        haveTrapHip = hand::model_to_eye(headPose34, hp, eyeOff, 0.0, &xTrapHip);
      }
    }
  }
  if (doPke && hr.validR && engine_pke_own()) {   // 0.93
    if (hand::model_to_eye(headPose34, hr.poseR, eyeOff, (double)g_ctl.pkeTiltDeg, &xPke)) havePke = 1;
    else InterlockedIncrement(&g_pkeOwn.pkeNoPose);
  }
  // 1.7.37 the life bar on the gun: a strip on top of the gun (the gun's own pose, grip at the origin, barrel along -z), only while the gun is in the hand
  int haveGunBar = 0; hand::Xform xGun; double gunFrac = 0.0;
  float gunPose[12] = {0};   // 1.7.162: the gun's pose in the room, for the liquid's physics
  // All four gun styles share the held-gun strip; the trap, PKE, light and empty hand are excluded.
  int gbItems[gear::kItemCount]; int gbCur = -1; const int gbFresh = doGunBar ? fight_items(gbItems, &gbCur) : 0;
  if (doGunBar && !gunbar::show_for_item(gbFresh, gbCur)) { static LONG s_gbHidden; if (InterlockedIncrement(&s_gbHidden) == 1) log_line("GUNBAR life bar hidden: it shows only while a gun (items 1/2/3/7) is in hand; the item now is %d (fresh %d)", gbCur, gbFresh); }
  // 1.7.99: and only while the game's gun is really drawn at the controller (not hidden, not in a cut-scene, not on the back): otherwise the strip stayed over an empty hand
  const int gunAtHand = !doGunBar || engine_gun_placed(0.5);   // 1.7.224: grace 0.25 -> 0.5 s (only this bar): no between-shot / walking flicker
  if (doGunBar && gunbar::show_for_item(gbFresh, gbCur) && !hr.holstered && !gunAtHand) { static LONG s_gbNoGun; if (InterlockedIncrement(&s_gbNoGun) <= 3) log_line("GUNBAR life bar hidden: a gun is the item but it is not drawn at the hand right now (cut-scene, hidden or on the back)"); }
  if (doGunBar && gunbar::show_for_item(gbFresh, gbCur) && gunAtHand && (hr.validR || hr.wandValid) && !hr.holstered && !engine_pke_item() && !hr.wheelOpen) {
    float hf = 0.0f;
    if (engine_player_health(&hf)) {
      const float* gp = hr.wandValid ? hr.wandPose : hr.poseR;
      if (hand::model_to_eye(headPose34, gp, eyeOff, 0.0, &xGun)) {
        haveGunBar = 1; gunFrac = (double)hf; for (int i = 0; i < 12; ++i) gunPose[i] = gp[i];
        // 1.7.167 "the health bar does not sit on the gun": the game draws the gun where the GAME's hand holds it (HANDGRIP), not exactly at the controller.
        // The tube now moves with the drawn gun: by how far the drawn gun's muzzle is from where the controller says the muzzle is (engine_gun_shift).
        float mh[3];
        // 1.7.170 / 1.7.172: the gap is kept in the controller's frame and smoothed slowly (gunshift.h): no bounce when the hand turns, no float-off, a wrong start heals
        static gunshift::Filter s_gf; static int64_t s_shQ; static int s_gfInit;
        static int s_gfLeft = -1; const int leftNow = controllers_left_applied();
        if (!s_gfInit || s_gfLeft != leftNow) { s_gf.reset(); s_gfInit = 1; s_gfLeft = leftNow; }   // 1.7.181: the gap learned with the other hand is dropped
        long sampleNo = 0; float shDirect[3] = {0, 0, 0}; int haveDirect = 0;
        static long s_rigTaken, s_rigReused, s_rigDirect; static double s_rigJumpSum, s_rigJumpMax;   // 1.7.185 GUNRIGID
        if (g_ctl.gunHpOnGun && engine_gun_muzzle(mh, &sampleNo)) {
          // the drawn muzzle in this eye's space (as model_to_eye: minus the eye offset, z flipped) minus where the controller frame puts the muzzle
          const float eoE[3] = {eyeOff[0], eyeOff[1], -eyeOff[2]};
          const float kt[3] = {hand::kTipX, hand::kTipY, hand::kTipZ}; float et[3]; hand::apply(xGun, kt, et);
          float sh[3]; for (int i = 0; i < 3; ++i) sh[i] = (mh[i] - eoE[i]) - et[i];
          float lo[3]; gunshift::to_local(xGun.r, sh, lo);
          const double dt = s_shQ ? (double)(nowQ - s_shQ) / (double)qpc_freq() : 0.0;
          s_shQ = nowQ;
          // 1.7.177 "the health bar still floats, lock it": the offset between the drawn gun and the controller is a constant (the gun is locked in the hand), but each sample of it
          // is stale by a game tick, so while the hand MOVES it is wrong by how far the hand moved. The offset is therefore learned only while the controller is nearly still and is
          // otherwise held, so the tube is rigid with the controller (and the gun) and no longer swims behind it.
          static float s_pPrev[3]; static int s_pHave; static double s_spd;
          if (dt > 0.004) { const double dtp = dt;   // once per picture pair (the second eye comes a moment later)
            if (s_pHave) { const double dx = gp[3] - s_pPrev[0], dy = gp[7] - s_pPrev[1], dz = gp[11] - s_pPrev[2]; const double v = vm::dsqrt(dx * dx + dy * dy + dz * dz) / dtp; s_spd += (v - s_spd) * 0.3; }
            s_pPrev[0] = gp[3]; s_pPrev[1] = gp[7]; s_pPrev[2] = gp[11]; s_pHave = 1; }
          if (false && g_ctl.gunHpRigid) {   // 1.7.191: OFF - pinning to the game's muzzle sample trailed the tube while walking (each sample is a tick old); the tube now keeps the learned gap in the controller frame (below), so it is rigid with the hand. 1.7.185 / 1.7.188: locked to the drawn gun
            static long s_lastSample = -1; static int s_direct;
            if (sampleNo != s_lastSample) {   // a new game sample: believed (a lone far-off one is not, see gunshift::take) or not
              s_lastSample = sampleNo; double jmp = 0.0;
              if (gunshift::take(s_gf, lo, &jmp)) { s_direct = 1; InterlockedIncrement(&g_gunShiftUsed); ++s_rigTaken; s_rigJumpSum += jmp; if (jmp > s_rigJumpMax) s_rigJumpMax = jmp; }
              else s_direct = 0;
            } else ++s_rigReused;
            if (s_direct) {   // 1.7.188: the tube's muzzle point IS the drawn muzzle (its world place turned into this picture's head space); the controller only turns it
              for (int i = 0; i < 3; ++i) shDirect[i] = sh[i];
              haveDirect = 1; ++s_rigDirect;
              for (int i = 0; i < 3; ++i) { s_gf.lo[i] = lo[i]; s_gf.mean[i] = lo[i]; }   // the controller-frame gap follows, for the frames without a fresh sample
            }
          }
          else {
            // 1.7.197 "LOCK THE HEALTH BAR TO THE GUN, why does it follow": the gap between the gun and the controller is learned while the hand is nearly still (about 12 updates) and then
            // FROZEN: the tube is a fixed part of the gun in the controller's frame and nothing moves it any more. It is learned again only when the gun is a different one (item, hand,
            // holster) or when the gun has really moved on the hand (a gap more than 3 cm off the frozen one, seen 10 still updates in a row: the other hand took hold, a new hold).
            static long s_lockSig = -1; static int s_lockOn, s_lockN, s_lockDev; static long s_lockRel;
            // 1.7.224 "the health bar glitches a lot while walking": the game's gun sways with the walk (up to 27 cm from the controller in the report), so the gap is neither learned nor
            // re-learned while the player walks (left stick pushed, plus 0.5 s after): the tube keeps its frozen place (or the nominal 25/2/0 cm before the first learn) and stays rigid with the controller.
            static int64_t s_walkQ; static long s_walkSkips; static int s_walkNow;
            if (controllers_move_mag() > 150) s_walkQ = nowQ;
            s_walkNow = s_walkQ && (double)(nowQ - s_walkQ) / (double)qpc_freq() < 0.5;
            const long sig = (long)gbCur * 4 + (leftNow ? 1 : 0) + (hr.holstered ? 2 : 0);
            if (sig != s_lockSig) { s_lockSig = sig; s_lockOn = 0; s_lockN = 0; s_lockDev = 0; s_gf.reset(); }
            if (s_walkNow) { ++s_walkSkips; InterlockedIncrement(&g_gunShiftNone); }
            else if (!s_gf.have || (!s_lockOn && s_spd < 0.25)) { if (gunshift::feed(s_gf, lo, dt)) { InterlockedIncrement(&g_gunShiftUsed); if (++s_lockN >= 12) s_lockOn = 1; } }
            else {
              if (s_lockOn && s_spd < 0.25) {
                const double d0 = (double)lo[0] - s_gf.lo[0], d1 = (double)lo[1] - s_gf.lo[1], d2 = (double)lo[2] - s_gf.lo[2];
                if (vm::dsqrt(d0 * d0 + d1 * d1 + d2 * d2) > 0.06) { if (++s_lockDev >= 40) { s_lockOn = 0; s_lockN = 0; s_lockDev = 0; ++s_lockRel; } } else s_lockDev = 0;
              }
              InterlockedIncrement(&g_gunShiftNone);
            }
            static LONG s_walkLog; if (s_walkSkips > 0 && s_walkLog < 6 && (s_walkSkips >> 8) != s_walkLog) { s_walkLog = (LONG)(s_walkSkips >> 8); log_line("GUNTUBE 1.7.224: %ld draws while walking kept the tube where it was (not learned, not re-learned)", s_walkSkips); }
            static LONG s_lockLog; if (s_lockRel > 0 && s_lockLog < 20 && s_lockRel != s_lockLog) { s_lockLog = (LONG)s_lockRel; log_line("GUNTUBE lock #%ld released: the gun moved on the hand by more than 6 cm for 40 still updates in a row (1.7.225: was 3 cm / 10; a dart kick or recoil is not a new hold), the gap is learned again", s_lockRel); }
          }
        } else InterlockedIncrement(&g_gunShiftNone);
        float s_sh[3] = {0, 0, 0};
        if (haveDirect) { for (int i = 0; i < 3; ++i) s_sh[i] = shDirect[i]; }   // 1.7.188
        else if (s_gf.have) gunshift::to_eye(xGun.r, s_gf.lo, s_sh);
        if (g_ctl.gunHpOnGun && (s_gf.have || haveDirect)) {   // the kept gap turns with the hand every frame (1.7.188: or the drawn muzzle itself)
          for (int i = 0; i < 3; ++i) xGun.t[i] += s_sh[i];
          const double cm = 100.0 * vm::dsqrt((double)s_sh[0] * s_sh[0] + (double)s_sh[1] * s_sh[1] + (double)s_sh[2] * s_sh[2]);
          if (cm > g_gunShiftMaxCm) g_gunShiftMaxCm = cm;
          g_gunShiftLastCm = cm;
        }
        {   // 1.7.211 "tube floats": the tube's frame is the drawn gun's own (one game sample), not the controller of this moment + a learned gap. Falls back to the old placement when there is no fresh sample.
          static long s_frN, s_frNone, s_frBad; static double s_frDevMax, s_frDevSum, s_frAngMax, s_frAgeMax, s_frCm[3]; static int64_t s_frQ; static LONG s_frLogs;
          float fR[9], fT[3]; double fAge = 0.0;
          // 1.7.224: OFF. The drawn gun's own frame swayed with the walk and fire (mean 3 cm, up to 27 cm from the controller) and made the bar glitch; the tube is rigid with the controller again.
          static const int kDrawnFrame = 0;
          if (kDrawnFrame && g_ctl.gunHpOnGun && g_ctl.gunHpRigid && engine_gun_frame(fR, fT, &fAge)) {
            const float eoF[3] = {eyeOff[0], eyeOff[1], -eyeOff[2]};
            const float nt[3] = {fT[0] - eoF[0], fT[1] - eoF[1], fT[2] - eoF[2]};
            const double dev = vm::dsqrt((double)(nt[0] - xGun.t[0]) * (nt[0] - xGun.t[0]) + (double)(nt[1] - xGun.t[1]) * (nt[1] - xGun.t[1]) + (double)(nt[2] - xGun.t[2]) * (nt[2] - xGun.t[2]));   // old (controller + gap) vs the drawn gun's
            const double dot = (double)xGun.r[2] * fR[2] + (double)xGun.r[5] * fR[5] + (double)xGun.r[8] * fR[8];   // cos of the turn between the two barrel axes (both columns are 'back')
            const double sn = vm::dsqrt(1.0 - (dot > 1.0 ? 1.0 : (dot < -1.0 ? -1.0 : dot)) * (dot > 1.0 ? 1.0 : (dot < -1.0 ? -1.0 : dot)));
            const double ang = 57.29577951308232 * vm::datan2(sn, dot);   // vm::dacos does not exist
            if (dev < 0.45 && ang < 25.0) {   // a barrel turned more than 25 deg from the controller's: not trusted (keeps the old placement if my rotation convention were wrong)
              for (int i = 0; i < 9; ++i) xGun.r[i] = fR[i];
              for (int i = 0; i < 3; ++i) xGun.t[i] = nt[i];
              ++s_frN; s_frDevSum += dev; if (dev > s_frDevMax) s_frDevMax = dev; if (ang > s_frAngMax) s_frAngMax = ang; if (fAge > s_frAgeMax) s_frAgeMax = fAge;
              for (int i = 0; i < 3; ++i) s_frCm[i] = 100.0 * nt[i];
            } else ++s_frBad;   // more than 45 cm / 25 deg from the controller: not this gun, keep the old placement
          } else ++s_frNone;
          if (kDrawnFrame && (!s_frQ || (double)(nowQ - s_frQ) / (double)qpc_freq() >= 10.0) && s_frLogs < 120) { s_frQ = nowQ; ++s_frLogs;
            log_line("GUNFRAME 1.7.211 tube frame from the drawn gun: used %ld draws, no fresh sample %ld, rejected (>45 cm from controller) %ld | old placement (controller + kept gap) vs drawn gun: mean %.1f cm, most %.1f cm, barrel turned by up to %.1f deg | oldest sample %.0f ms | tube centre now (eye space, right/up/fwd cm) %.0f/%.0f/%.0f | gun_hp_rigid=%d",
                     s_frN, s_frNone, s_frBad, s_frN ? 100.0 * s_frDevSum / (double)s_frN : 0.0, 100.0 * s_frDevMax, s_frAngMax, s_frAgeMax, s_frCm[0], s_frCm[1], s_frCm[2], (int)g_ctl.gunHpRigid);
            s_frDevMax = 0.0; s_frAngMax = 0.0; s_frAgeMax = 0.0; }
        }
        {   // GUNTUBE every 30 s: how far the drawn gun is from the controller's gun (the tube follows the drawn one), and how often a hand hid it
          static int64_t s_gtQ; static LONG s_gtN;
          if ((!s_gtQ || (double)(nowQ - s_gtQ) / (double)qpc_freq() >= 30.0) && s_gtN < 40) { s_gtQ = nowQ; ++s_gtN;
            log_line("GUNTUBE on_gun=%d hand_cut=%d: the drawn gun's muzzle is %.1f cm from the controller's (largest %.1f cm); measured %ld times, not measured %ld, samples limited or out of range %ld, kept gap behind the newest mean by %ld mm (kept in the controller frame, 1.7.172: smoothed mean, no gate) | tube drawn hand-cut %ld times, a hand in front of it %ld times (shader %s) | place %d/%d/%d cm",
                     (int)g_ctl.gunHpOnGun, (int)g_ctl.gunHpHandCut, g_gunShiftLastCm, g_gunShiftMaxCm, (long)g_gunShiftUsed, (long)g_gunShiftNone, s_gf.rejected, (long)(1000.0 * vm::dsqrt((double)(s_gf.mean[0] - s_gf.lo[0]) * (s_gf.mean[0] - s_gf.lo[0]) + (double)(s_gf.mean[1] - s_gf.lo[1]) * (s_gf.mean[1] - s_gf.lo[1]) + (double)(s_gf.mean[2] - s_gf.lo[2]) * (s_gf.mean[2] - s_gf.lo[2]))), (long)g_occDraws, (long)g_occCut, g_psOcc ? "ok" : "missing",
                     (int)g_ctl.gunHpFwdCm, (int)g_ctl.gunHpUpCm, (int)g_ctl.gunHpSideCm); }
          if (s_gtN <= 40 && s_gtQ == nowQ) log_line("GUNRIGID gun_hp_rigid=%d: new game samples taken %ld, frames that reused the last sample %ld | the kept gap moved per new sample: mean %.1f mm, most %.1f mm (1.7.185: the tube follows the drawn gun on every sample); 1.7.188 frames with the tube pinned straight to the drawn muzzle %ld", (int)g_ctl.gunHpRigid, s_rigTaken, s_rigReused, s_rigTaken ? 1000.0 * s_rigJumpSum / (double)s_rigTaken : 0.0, 1000.0 * s_rigJumpMax, s_rigDirect);
        }
      }
    }
  }
  const int haveGear = haveGunBar || wheelN > 0 || haveTrapHand || haveTrapHip || havePke;
  if (!haveR && !haveL && !haveC && !haveRig && !haveBars && !haveGear) { InterlockedIncrement(&g_hs.noPose); return; }

  Saved sv;
  save(ctx, &sv);
  D3D11_VIEWPORT vp = {0, 0, (float)g_w, (float)g_h, 0.0f, 1.0f};
  ctx->OMSetRenderTargets(1, &g_rtv[eye & 1], g_dsv);
  ctx->ClearDepthStencilView(g_dsv, D3D11_CLEAR_DEPTH, 1.0f, 0);
  ctx->RSSetViewports(1, &vp);
  ctx->RSSetState(g_rs);
  float bf[4] = {0, 0, 0, 0};
  ctx->OMSetBlendState(g_bs, bf, 0xffffffff);
  ctx->OMSetDepthStencilState(g_ds, 0);
  ctx->IASetInputLayout(g_il);
  ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  UINT stride = sizeof(hand::Vertex), offset = 0;
  ctx->IASetVertexBuffers(0, 1, &g_vb, &stride, &offset);
  ctx->VSSetShader(g_vs, nullptr, 0);
  ctx->PSSetShader(g_ps, nullptr, 0);
  ctx->GSSetShader(nullptr, nullptr, 0);
  ctx->HSSetShader(nullptr, nullptr, 0);
  ctx->DSSetShader(nullptr, nullptr, 0);
  ctx->VSSetConstantBuffers(0, 1, &g_cb);
  if (haveR && set_constants(ctx, xr, tanH, tanV, 0.65f + 0.35f * hr.trigR)) {
    if (!hr.holstered && !gloveMode) ctx->Draw((UINT)g_wandVerts, 0);               // the wand (not while holstered)
    ctx->Draw((UINT)(g_totalVerts - g_wandVerts), (UINT)g_wandVerts); // the right hand around its grip
  }
  if (haveL && set_constants(ctx, xl, tanH, tanV, 1.0f)) ctx->Draw((UINT)(g_totalVerts - g_wandVerts), (UINT)g_wandVerts);
  if (haveTrapHand && g_trapEnd > g_trapStart && set_constants(ctx, xTrapHand, tanH, tanV, 1.0f)) {   // 0.77: the ghost trap in the left hand
    ctx->Draw((UINT)(g_trapEnd - g_trapStart), (UINT)g_trapStart);
    InterlockedIncrement(&g_gear.trapHandDraws);
  }
  if (havePke && g_pkeEnd > g_pkeStart) {   // 0.93: the probe's own PKE meter; its lights and screen pulse
    double bs, bc;
    vm::dsincos((double)(nowQ / (qpc_freq() / 1000)) * 0.006, &bs, &bc);
    const float blink = 0.60f + 0.40f * (float)(0.5 + 0.5 * bs);
    if (set_constants(ctx, xPke, tanH, tanV, blink)) {
      ctx->Draw((UINT)(g_pkeEnd - g_pkeStart), (UINT)g_pkeStart);
      if (InterlockedIncrement(&g_pkeOwn.pkeDraws) == 1) log_line("PKEOWN first draw of the probe's own PKE meter (%d vertices, tilt %d degrees)", g_pkeEnd - g_pkeStart, (int)g_ctl.pkeTiltDeg);
    }
  }
  if (haveTrapHip && g_trapEnd > g_trapStart && set_constants(ctx, xTrapHip, tanH, tanV, 1.0f)) {     // 0.77: the ghost trap waiting on the left hip
    ctx->Draw((UINT)(g_trapEnd - g_trapStart), (UINT)g_trapStart);
    InterlockedIncrement(&g_gear.trapHipDraws);
  }
  if (haveC) {
    static cord::V cv[cord::kVerts];
    const int n = cord::build_mesh(g_rope, cv, (int)(sizeof(cv) / sizeof(cv[0])));
    D3D11_MAPPED_SUBRESOURCE mp;
    if (n <= 0) InterlockedIncrement(&g_cs.buildFail);
    else if (FAILED(ctx->Map(g_cordVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp))) InterlockedIncrement(&g_cs.mapFail);
    else {
      for (int i = 0; i < n; ++i) ((cord::V*)mp.pData)[i] = cv[i];
      ctx->Unmap(g_cordVb, 0);
      if (set_constants(ctx, xc, tanH, tanV, 1.0f)) {
        const double fwdY = -(double)headPose34[9];   // the way the head looks, vertical part (+1 up, -1 down)
        const int lookDown = fwdY < -0.30;
        if (lookDown) ++g_cs.cordDownDraws;
        if (g_ctl.chestShield && g_shOk && g_bsNoCol && lookDown) ++g_cs.shieldSkippedDown;   // 0.84: looking down you see the cord from above: no blocker then
        if (g_ctl.chestShield && g_shOk && g_bsNoCol && !lookDown) {   // 0.77: your chest hides the cord where it passes behind it (depth only, no colour)
          static cord::V shv[400];
          const int ns = cord::build_shield(g_shHead, g_shYaw, g_shScale, shv, (int)(sizeof(shv) / sizeof(shv[0])));
          D3D11_MAPPED_SUBRESOURCE mp2;
          if (ns > 0 && SUCCEEDED(ctx->Map(g_uiVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp2))) {
            for (int i = 0; i < ns; ++i) ((cord::V*)mp2.pData)[i] = shv[i];
            ctx->Unmap(g_uiVb, 0);
            ctx->OMSetBlendState(g_bsNoCol, bf, 0xffffffff);
            ctx->IASetVertexBuffers(0, 1, &g_uiVb, &stride, &offset);
            ctx->Draw((UINT)ns, 0);
            ctx->OMSetBlendState(g_bs, bf, 0xffffffff);
            InterlockedIncrement(&g_gear.shieldDraws);
          }
        }
        ctx->IASetVertexBuffers(0, 1, &g_cordVb, &stride, &offset);
        ctx->Draw((UINT)n, 0);
        g_cordDrawQ = qpc_now();
        InterlockedIncrement(&g_cs.draws);
      }
    }
  }
  if (g_ctl.armsOnly && g_ctl.armsStraps && g_ctl.armIk == 1 && g_ctl.firstPerson && haveX && !engine_pke_mode() && !engine_scene_arms(0) && !(g_ctl.armsShoulders && g_ctl.bodyWhole)) {   // 0.80: no straps in the scripted floating-arms view
    static long strapSeq; static int64_t strapQ;
    static cord::V stv[800];
    rig::Snap ts;
    ts.clear();
    int n = 0;
    if (arms_rig_read(&ts)) {
      if (ts.seq != strapSeq) { strapSeq = ts.seq; strapQ = nowQ; }
      if (strapQ && (nowQ - strapQ) < qpc_freq() / 3) {
        double hd[3] = {headPose34[3], headPose34[7], headPose34[11]}, Rh[9];
        for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) Rh[r * 3 + c] = headPose34[r * 4 + c];
        n = rig::build_straps(ts, hd, Rh, stv, (int)(sizeof(stv) / sizeof(stv[0])));
      }
    }
    D3D11_MAPPED_SUBRESOURCE mp3;
    if (n > 0 && SUCCEEDED(ctx->Map(g_uiVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp3))) {
      for (int i = 0; i < n; ++i) ((cord::V*)mp3.pData)[i] = stv[i];
      ctx->Unmap(g_uiVb, 0);
      if (set_constants(ctx, xc, tanH, tanV, 1.0f)) {
        ctx->IASetVertexBuffers(0, 1, &g_uiVb, &stride, &offset);
        ctx->Draw((UINT)n, 0);
        InterlockedIncrement(&g_gear.strapDraws);
      }
    } else InterlockedIncrement(&g_gear.strapMiss);
  }
  if (haveRig) {
    static cord::V rv[kRigCap];
    rig::Frame fr;
    rig_frame(headPose34, hr, sn, snOk && snFresh, &fr, nowQ);
    rig::Snap none;
    none.clear();
    const int n = rig::build((snOk && snFresh) ? sn : none, fr, rv, (int)kRigCap);
    D3D11_MAPPED_SUBRESOURCE mp;
    if (n <= 0) InterlockedIncrement(&g_rg.over);
    else if (FAILED(ctx->Map(g_rigVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp))) InterlockedIncrement(&g_rg.mapFail);
    else {
      for (int i = 0; i < n; ++i) ((cord::V*)mp.pData)[i] = rv[i];
      ctx->Unmap(g_rigVb, 0);
      if (set_constants(ctx, xc, tanH, tanV, 1.0f)) {
        ctx->IASetVertexBuffers(0, 1, &g_rigVb, &stride, &offset);
        ctx->Draw((UINT)n, 0);
        g_rg.lastVerts = n;
        InterlockedIncrement(&g_rg.draws);
      }
    }
    // numbers for the log, and a picture of both eyes now and then (so the rig view can be looked at afterwards)
    if (eye == 0 && snOk && snFresh) {
      if (!g_rg.dataQ || (nowQ - g_rg.dataQ) > qpc_freq() * 25) {
        if (g_rg.dataLogged < 40) { rig_log(headPose34, hr, sn); ++g_rg.dataLogged; }
        g_rg.dataQ = nowQ;
      }
      if (g_ctl.rigAutoShots && g_rg.shots < 6 && !shot_busy()) {
        if (!g_rg.firstQ) g_rg.firstQ = nowQ;
        const double since = (double)(nowQ - (g_rg.shotQ ? g_rg.shotQ : g_rg.firstQ)) / (double)qpc_freq();
        if (since > (g_rg.shots == 0 ? 6.0 : 40.0)) {
          shot_request();
          InterlockedIncrement(&g_rg.shots);
          g_rg.shotQ = nowQ;
          log_line("RIGSHOT picture #%d saved by itself (gbvr_picture_*.jpg in the game folder; the rig view is in it)", (int)g_rg.shots);
        }
      }
    }
  }
  if (haveBars) {
    // drawn last, far to near, without depth (they sit inside the ghosts and must stay readable); identity transform: the bars are already in eye space
    static cord::V bv[kBarCap];
    fight::Look look;
    look.sizePct = (double)g_ctl.hbarSizePct;
    look.digitsFocus = g_ctl.hbarDigits != 0;
    look.focusDeg = 7.0;
    look.ringStyle = health_ghost_ring() != 0 || health_og() != 0;   // 1.7.103 (1.7.106: the fallback is the round ring on the one that owns the ring)
    // 1.7.158: the ghosts' health as a vial of liquid, like the gun's. Each ghost keeps its own liquid (level shown, the part just lost, slosh), found by its actor.
    static struct { unsigned long long actor; gunbar::Liquid s; int64_t q; } s_gl[fight::kMaxBars];
    static gunbar::Liquid s_glNow[fight::kMaxBars];
    static long s_glDraws, s_glHits;
    if (g_ctl.ghostHpLiquid) {
      const int stepNow = !(eye & 1);
      for (int i = 0; i < nBars; ++i) {
        int slot = -1, freeSlot = 0; int64_t oldest = 0x7fffffffffffffffLL;
        for (int k = 0; k < fight::kMaxBars; ++k) { if (s_gl[k].actor == bars[i].actor && s_gl[k].q) { slot = k; break; } if (s_gl[k].q < oldest) { oldest = s_gl[k].q; freeSlot = k; } }
        if (slot < 0) { slot = freeSlot; s_gl[slot].actor = bars[i].actor; s_gl[slot].s.reset(); s_gl[slot].q = 0; }
        const double since = s_gl[slot].q ? (double)(nowQ - s_gl[slot].q) / (double)qpc_freq() : 1.0;
        if (!s_gl[slot].q || stepNow || since > 0.05 || since < 0.0) {
          if (since > 2.0 || since < 0.0) s_gl[slot].s.reset();
          const double hb = s_gl[slot].s.lostHold;
          gunbar::step(&s_gl[slot].s, (double)bars[i].frac, since > 0.25 ? 0.25 : since);
          if (s_gl[slot].s.lostHold > hb + 0.1) ++s_glHits;
          s_gl[slot].q = nowQ ? nowQ : 1;
        }
        s_glNow[i] = s_gl[slot].s;
      }
      look.liquid = 1; look.liq = s_glNow;
      if (++s_glDraws == 1 || (s_glDraws % 20000) == 0) log_line("GHOSTLIQUID the ghosts' health is drawn as a vial of liquid: %d on the list now, first one %.0f%% (shown %.0f%%), hits shown so far %ld, draws %ld | ghost_hp_liquid=1 (0 = the bar / ring as before)",
                                                                 nBars, nBars ? (double)bars[0].frac * 100.0 : -1.0, nBars ? s_glNow[0].shown * 100.0 : -1.0, s_glHits, s_glDraws);
    }
    const int n = fight::build(bars, nBars, (double)eyeX, look, bv, (int)kBarCap);
    D3D11_MAPPED_SUBRESOURCE mp;
    if (n < 0) InterlockedIncrement(&g_bar.over);
    else if (n > 0) {
      if (FAILED(ctx->Map(g_barVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp))) InterlockedIncrement(&g_bar.mapFail);
      else {
        for (int i = 0; i < n; ++i) ((cord::V*)mp.pData)[i] = bv[i];
        ctx->Unmap(g_barVb, 0);
        hand::Xform xid;
        for (int i = 0; i < 9; ++i) xid.r[i] = (i % 4 == 0) ? 1.0f : 0.0f;
        xid.t[0] = xid.t[1] = xid.t[2] = 0.0f;
        if (set_constants(ctx, xid, tanH, tanV, 1.0f, 80.0)) {
          ctx->OMSetDepthStencilState(g_dsOff, 0);
          ctx->IASetVertexBuffers(0, 1, &g_barVb, &stride, &offset);
          {   // 1.7.19: see-through bars (the constant blend factor is hbar_alpha_pct); the same blend state the weapon wheel uses
            const int ap = g_ctl.hbarAlphaPct < 15 ? 15 : (g_ctl.hbarAlphaPct > 100 ? 100 : g_ctl.hbarAlphaPct);
            if (g_bsWheel && ap < 100) {
              const float af = (float)ap / 100.0f; const float abf[4] = {af, af, af, af};
              ctx->OMSetBlendState(g_bsWheel, abf, 0xffffffff);
              InterlockedIncrement(&g_bar.seeThrough);
            } else InterlockedIncrement(&g_bar.solid);
          }
          ctx->Draw((UINT)n, 0);
          ctx->OMSetBlendState(g_bs, bf, 0xffffffff);
          InterlockedIncrement(&g_bar.draws);
          g_bar.lastBars = nBars; g_bar.lastVerts = n;
          if (nBars > g_bar.maxBars) g_bar.maxBars = nBars;
          g_bar.barsTotal += nBars;
        }
      }
    }
  }
  if (doMarks) {   // 1.7.3 the collectible markers: eye space like the bars, drawn last, far to near, without depth
    static fight::Marker mkr[fight::kMaxMarkers];
    static cord::V mv[kMarkCap];
    const int nm = fight_markers_read(mkr, fight::kMaxMarkers);
    if (nm <= 0) InterlockedIncrement(&g_mkd.none);
    else {
      const int n = fight::build_markers(mkr, nm, (double)eyeX, (double)g_ctl.collectMarkerPct, (double)qpc_now() / (double)qpc_freq(), mv, (int)kMarkCap);
      D3D11_MAPPED_SUBRESOURCE mp;
      if (n < 0) InterlockedIncrement(&g_mkd.over);
      else if (n > 0) {
        if (FAILED(ctx->Map(g_barVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp))) InterlockedIncrement(&g_mkd.mapFail);
        else {
          for (int i = 0; i < n; ++i) ((cord::V*)mp.pData)[i] = mv[i];
          ctx->Unmap(g_barVb, 0);
          hand::Xform xid;
          for (int i = 0; i < 9; ++i) xid.r[i] = (i % 4 == 0) ? 1.0f : 0.0f;
          xid.t[0] = xid.t[1] = xid.t[2] = 0.0f;
          if (set_constants(ctx, xid, tanH, tanV, 1.0f, 80.0)) {
            ctx->OMSetDepthStencilState(g_dsOff, 0);
            ctx->IASetVertexBuffers(0, 1, &g_barVb, &stride, &offset);
            ctx->Draw((UINT)n, 0);
            InterlockedIncrement(&g_mkd.draws);
            g_mkd.lastN = nm; g_mkd.lastVerts = n;
            if (nm > g_mkd.maxN) g_mkd.maxN = nm;
            g_mkd.total += nm;
          }
        }
      }
    }
  }
  if (wheelN > 0) {
    // 0.78: the weapon wheel, on top of everything (no depth test); built flat, placed with its own pose (it stands in the world where it opened)
    D3D11_MAPPED_SUBRESOURCE mp;
    if (FAILED(ctx->Map(g_uiVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp))) InterlockedIncrement(&g_gear.wheelMapFail);
    else {
      for (int i = 0; i < wheelN; ++i) ((cord::V*)mp.pData)[i] = uv[i];
      ctx->Unmap(g_uiVb, 0);
      if (set_constants(ctx, xWheel, tanH, tanV, 1.0f, 80.0)) {
        ctx->OMSetDepthStencilState(g_dsOff, 0);
        ctx->IASetVertexBuffers(0, 1, &g_uiVb, &stride, &offset);
        // 1.6: the body (track, centre, disc fills) is see-through; the red outline, the words and the cursor go on top, solid
        int body = wheelSolidFrom;
        if (body < 0 || body > wheelN) body = 0;
        const int pct = g_ctl.wheelAlphaPct < 10 ? 10 : (g_ctl.wheelAlphaPct > 100 ? 100 : g_ctl.wheelAlphaPct);
        if (body > 0 && g_bsWheel && pct < 100) {
          const float wf = (float)pct / 100.0f;
          const float wbf[4] = {wf, wf, wf, wf};
          ctx->OMSetBlendState(g_bsWheel, wbf, 0xffffffff);
          ctx->Draw((UINT)body, 0);
          ctx->OMSetBlendState(g_bs, bf, 0xffffffff);
          if (wheelN > body) ctx->Draw((UINT)(wheelN - body), (UINT)body);
        } else ctx->Draw((UINT)wheelN, 0);
        InterlockedIncrement(&g_gear.wheelDraws);
        g_gear.lastWheelVerts = wheelN;
      }
    }
  }
  if (haveGunBar) {
    static hand::Vertex gv[gunbar::kMaxVerts];
    hand::Mesh m = {gv, 0, gunbar::kMaxVerts};
    const double lenM = 0.085, fwdM = 0.01 * (double)g_ctl.gunHpFwdCm, upM = 0.01 * (double)g_ctl.gunHpUpCm;
    const float zc = (float)(-fwdM), yc = (float)upM, xc = (float)(0.01 * (double)g_ctl.gunHpSideCm * (controllers_left_applied() ? -1.0 : 1.0));   // 1.7.165: left-handed: mirrored, so the tube stays on the side toward you
    float glowK = 1.0f;
    if (g_ctl.gunHpLiquid) {
      // 1.7.157: a tube of glowing liquid with a beating heart (gunbarmath.h). The liquid's state moves on once per picture pair (with the left eye, or after
      // a pause), so both eyes see the same surface, bubbles and heartbeat.
      static gunbar::Liquid s_liq; static int s_liqInit; static int64_t s_liqQ; static long s_liqSteps, s_liqHits; static double s_liqMin = 2.0;
      if (!s_liqInit) { s_liq.reset(); s_liqInit = 1; }
      const double since = s_liqQ ? (double)(nowQ - s_liqQ) / (double)qpc_freq() : 1.0;
      if (!(eye & 1) || since > 0.05 || since < 0.0) {
        if (since > 2.0 || since < 0.0) s_liq.reset();   // the bar was away (holstered, PKE, a cut-scene): it comes back at the level of now, no old slosh
        const double before = s_liq.lostHold;
        gunbar::step(&s_liq, gunFrac, since > 0.25 ? 0.25 : since);
        if (g_ctl.gunHpPhysics) gunbar::step_phys(&s_liq, gunPose, since > 0.25 ? 0.25 : since);   // 1.7.162: the liquid moves with the gun
        else s_liq.reset_phys();
        { static double s_tiltMax; static long s_swings; static int s_wasHard; const double tl = vm::dsqrt(s_liq.sx * s_liq.sx + s_liq.sy * s_liq.sy);
          if (tl > s_tiltMax) s_tiltMax = tl; const int hard = s_liq.agit > 0.5; if (hard && !s_wasHard) ++s_swings; s_wasHard = hard;
          static int64_t s_physLogQ; static LONG s_physLogs;
          if ((!s_physLogQ || (double)(nowQ - s_physLogQ) / (double)qpc_freq() >= 30.0) && s_physLogs < 40) { s_physLogQ = nowQ; ++s_physLogs;
            log_line("GUNLIQUIDPHYS physics=%d surface tilt now %.2f / %.2f (largest so far %.2f, cap %.1f), stirred %.2f, hard swings %ld", (int)g_ctl.gunHpPhysics, s_liq.sx, s_liq.sy, s_tiltMax, gunbar::kMaxTilt, s_liq.agit, s_swings); } }
        if (s_liq.lostHold > before + 0.1) ++s_liqHits;
        s_liqQ = nowQ; ++s_liqSteps;
        if (gunFrac < s_liqMin) s_liqMin = gunFrac;
        static int64_t s_liqLogQ; static LONG s_liqLogs;
        if ((!s_liqLogQ || (double)(nowQ - s_liqLogQ) / (double)qpc_freq() >= 30.0) && s_liqLogs < 40) {
          s_liqLogQ = nowQ; ++s_liqLogs;
          float lc[3]; gunbar::liquid_colour(s_liq.shown, lc);
          log_line("GUNLIQUID health %.0f%% shown %.0f%% (pale 'just lost' part to %.0f%%), liquid colour %.2f/%.2f/%.2f, heart %.0f beats a minute, slosh %.2f | steps %ld, hits shown %ld, lowest health seen %.0f%% | gun_hp_liquid=1 (0 = the plain strip)",
                   gunFrac * 100.0, s_liq.shown * 100.0, s_liq.lost * 100.0, (double)lc[0], (double)lc[1], (double)lc[2], gunFrac > 0.0 ? gunbar::heart_bpm(gunFrac) : 0.0, s_liq.slosh, s_liqSteps, s_liqHits, s_liqMin * 100.0);
        }
      }
      const gunbar::Layout L = {xc, yc, zc, (float)lenM};
      gunbar::build(&m, L, s_liq);
    } else {
      // the 1.7.37 strip: a dark frame and the fill (rear to front, the fill shrinks toward the rear as health drops); the fill glows a little, the frame does not
      static const float frameCol[4] = {0.05f, 0.05f, 0.06f, 0};
      float rgb[3]; gunbar::colour(gunFrac, rgb);
      const float fillCol[4] = {rgb[0], rgb[1], rgb[2], 1};
      m.box(xc, yc, zc, 0.0095f, 0.0028f, (float)(lenM * 0.5 + 0.0035), frameCol);   // frame
      const double fl = gunbar::fill_len(gunFrac, lenM);
      if (fl > 0.0) {
        const float zRear = zc + (float)(lenM * 0.5);
        m.box(xc, yc + 0.0032f, zRear - (float)(fl * 0.5), 0.0058f, 0.0018f, (float)(fl * 0.5), fillCol);
      }
      glowK = gunbar::glow(gunFrac, (double)(nowQ / (qpc_freq() / 1000)) * 0.001);
    }
    D3D11_MAPPED_SUBRESOURCE mp;
    if (m.n > 0 && (size_t)m.n * sizeof(hand::Vertex) <= (size_t)kUiCap * sizeof(cord::V) && SUCCEEDED(ctx->Map(g_uiVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp))) {   // 1.7.161: never more than the buffer holds
      for (int i = 0; i < m.n; ++i) ((hand::Vertex*)mp.pData)[i] = gv[i];
      ctx->Unmap(g_uiVb, 0);
      if (set_constants(ctx, xGun, tanH, tanV, glowK * 0.65f)) {   // 1.7.176: the glow is 35 % lower (blends with the gun)
        ctx->OMSetBlendState(g_bs, bf, 0xffffffff);
        ctx->OMSetDepthStencilState(g_ds, 0);   // 1.7.157: the tube's parts sort by depth (the weapon wheel before it may have left the depth test off)
        ctx->IASetVertexBuffers(0, 1, &g_uiVb, &stride, &offset);
        int occ = 0;
        if (g_ctl.gunHpHandCut && g_psOcc && g_cbOcc) {   // 1.7.167: the hands hide the tube where they are in front of it
          float S[8] = {0, 0, 0, 0, 0, 0, 0, 0};
          for (int h = 0; h < 2; ++h) {
            const float* hp = h == 0 ? (hr.validL ? hr.poseL : nullptr) : (hr.validR ? hr.poseR : nullptr);
            hand::Xform xh;
            if (!hp || !hand::model_to_eye(headPose34, hp, eyeOff, 0.0, &xh)) continue;
            const float palm[3] = {0.0f, -0.015f, 0.045f};   // the palm: a little below and behind the controller's origin (controller axes)
            float pe[3]; hand::apply(xh, palm, pe);
            S[h * 4] = pe[0]; S[h * 4 + 1] = pe[1]; S[h * 4 + 2] = pe[2]; S[h * 4 + 3] = h == 0 ? 0.070f : 0.060f;
          }
          D3D11_MAPPED_SUBRESOURCE mo;
          if ((S[3] > 0.0f || S[7] > 0.0f) && SUCCEEDED(ctx->Map(g_cbOcc, 0, D3D11_MAP_WRITE_DISCARD, 0, &mo))) {
            for (int i = 0; i < 8; ++i) ((float*)mo.pData)[i] = S[i];
            ctx->Unmap(g_cbOcc, 0);
            ctx->PSSetConstantBuffers(1, 1, &g_cbOcc);
            ctx->PSSetShader(g_psOcc, nullptr, 0);
            occ = 1; InterlockedIncrement(&g_occDraws);
            // a hand in front of the tube's middle (for the log)
            float mid[3]; const float c0[3] = {xc, yc + 0.005f, zc}; hand::apply(xGun, c0, mid);
            for (int h = 0; h < 2; ++h) if (S[h * 4 + 3] > 0.0f) {
              const double ee = (double)mid[0] * mid[0] + (double)mid[1] * mid[1] + (double)mid[2] * mid[2];
              const double t = ((double)S[h * 4] * mid[0] + (double)S[h * 4 + 1] * mid[1] + (double)S[h * 4 + 2] * mid[2]) / (ee > 1e-9 ? ee : 1e-9);
              if (t > 0.0 && t < 1.0) { double q2 = 0; for (int k = 0; k < 3; ++k) { const double d = (double)mid[k] * t - S[h * 4 + k]; q2 += d * d; } if (q2 < (double)S[h * 4 + 3] * S[h * 4 + 3]) InterlockedIncrement(&g_occCut); }
            }
          }
        }
        ctx->Draw((UINT)m.n, 0);
        if (occ) ctx->PSSetShader(g_ps, nullptr, 0);
        static long s_gbDraws; if (++s_gbDraws == 1) log_line("GUNBAR first draw: health %.0f%%, %d vertices, %d cm forward, %d cm up, %d cm sideways (negative = left), liquid tube and heart %d", gunFrac * 100.0, m.n, (int)g_ctl.gunHpFwdCm, (int)g_ctl.gunHpUpCm, (int)g_ctl.gunHpSideCm, (int)g_ctl.gunHpLiquid);
      }
    }
  }
  restore(ctx, &sv);
  if (InterlockedIncrement(&g_hs.draws) == 1) log_line("HANDS first draw: eye=%d right=%d left=%d cord=%d rig=%d pitch=%.1f", eye & 1, haveR, haveL, haveC, haveRig, pitch);
}


namespace {
// 1.7.22: comfort vignette bookkeeping (render thread; the pulse is set from the game thread)
struct VigStat {
  LONG draws, offFrames, mapFail, noBlend, noTarget, tooBig, menuPreview, sprintFrames, pulses;
  double maxLevel, lastLevel, maxMove, maxTurn; int lastVerts; int logged;
  float lastCx, lastCy, lastHx, lastHy;
} g_vg;
vig::State g_vigState;
int64_t g_vigQ;                 // last time the level was stepped (both eyes of one frame share one step)
int g_vigRed;                   // 1.7.197: the knock-down / dying vignette is red and pulses
double g_vigLevel;              // the level (already times the strength setting) used by both eyes
volatile LONG64 g_vigPulseUntilQ;   // QPC time until which a dash pulse holds the vignette fully on
}  // namespace

// 1.7.22: a short full-strength burst (the blink dash). Safe from any thread.
void vignette_pulse(int ms) {
  if (ms < 1) return;
  InterlockedExchange64(&g_vigPulseUntilQ, qpc_now() + qpc_freq() * ms / 1000);
  InterlockedIncrement(&g_vg.pulses);
}

// 1.7.22: draws the vignette into one eye picture (after the hands, bars and wheel). bounds = the eye's visible window in the texture (uMin, vMin, uMax, vMax).
void handmodel_vignette(ID3D11Device* dev, ID3D11DeviceContext* ctx, ID3D11Texture2D* eyeTex, int eye, const float* bounds, float tanH, float tanV) {
  const int pct = (int)g_ctl.vignettePct;
  if ((pct <= 0 && engine_knock_strength() <= 0.0 && !engine_player_downed()) || !dev || !ctx || !eyeTex || !bounds) { if ((eye & 1) == 0) g_vigState.level = 0.0; return; }
  if (!(tanH > 0.01f) || !(tanV > 0.01f)) return;
  if (g_dev != dev) { release_all(); g_dev = dev; }
  if (g_state == 0) {
    g_state = create_resources(dev);
    if (g_state != 1) { log_line("HANDS could not be set up (code %d): the comfort vignette is not drawn either", g_state); return; }
  }
  if (g_state != 1) return;
  if (!g_bsDark) { InterlockedIncrement(&g_vg.noBlend); return; }
  // one step per frame pair
  const int64_t now = qpc_now();
  double dt = g_vigQ ? (double)(now - g_vigQ) / (double)qpc_freq() : 0.014;
  {
    if (dt >= 0.002 || !g_vigQ) {
      g_vigQ = now;
      const double mv = engine_player_forced() ? 0.0 : (double)controllers_move_mag() / 1000.0;   // 1.7.180: the stick does not darken the edges while the game moves the character (cutscene)
      int tu = 0, tb = 0; controllers_turn_info(&tu, &tb);
      const double tn = tb ? 0.0 : (double)tu / 1000.0;
      const int spr = controllers_sprint_want();
      const LONG64 pu = g_vigPulseUntilQ;
      double pulse = 0.0;
      if (pu > now) pulse = 1.0; else if (pu && now - pu < qpc_freq() / 4) pulse = 1.0 - (double)(now - pu) / ((double)qpc_freq() / 4.0);
      const int menu = vrmenu_is_open();
      double tgt = menu ? 0.6 : vig::want(mv, tn, spr, pulse);   // while the menu is open a half-strength preview is shown so the setting can be judged
      g_vigLevel = vig::step(&g_vigState, tgt, dt, (double)pct / 100.0);
      {  // 1.7.36 knock-down comfort: dark edges for the length of the skipped fall (on top of whatever the comfort vignette is)
        const double ks = engine_knock_strength() * (double)g_ctl.knockDarkPct / 100.0;
        // 1.7.197 "a pulsing red vignette" for a knock-down and for dying: the edges throb red (the darkness is taken out of the red channel only)
        const int dn = engine_player_downed();
        g_vigRed = 0;
        if (dn || ks > 0.0) {
          double sw, cw; vm::dsincos(6.283185307179586 * 1.1 * (double)now / (double)qpc_freq(), &sw, &cw);
          const double w = 0.5 + 0.5 * sw;
          const double base = dn ? 0.92 : (ks > 0.0 ? (ks < 0.15 ? ks : 0.15 + (ks - 0.15) * 1.0) : 0.0);   // 1.7.203: the knock-down edge is steady black (no pulse), the dying edge still pulses red
          const double lv = dn ? base * (0.50 + 0.50 * w) : (base > 1.0 ? 1.0 : base);
          if (lv > g_vigLevel) g_vigLevel = lv;
          g_vigRed = dn ? 1 : 0;   // 1.7.200: a knock-down is black, dying stays red
        { static int s_kv; if (ks > 0.0 && !dn && s_kv++ < 6) log_line("KNOCKVIG black edges level %.2f (strength %.2f)", lv, engine_knock_strength()); }
        }
      {   // 1.7.203 KNOCKVIG summary: how strong the knock-down edge got (so a missing edge can be told from a too weak one)
        static int s_act; static double s_mx; static long s_n;
        if (!dn && ks > 0.0) { s_act = 1; ++s_n; if (g_vigLevel > s_mx) s_mx = g_vigLevel; }
        else if (s_act && ks <= 0.0) { s_act = 0; static LONG s_sl; if (InterlockedIncrement(&s_sl) <= 12) log_line("KNOCKVIG summary: the knock-down edge was set on %ld steps, strongest level %.2f (1.0 = the darkest the edge can get)", s_n, s_mx); s_mx = 0.0; s_n = 0; }
      }
      }
      if (menu) InterlockedIncrement(&g_vg.menuPreview);
      if (spr && mv > 0.2) InterlockedIncrement(&g_vg.sprintFrames);
      if (mv > g_vg.maxMove) g_vg.maxMove = mv;
      if (tn > g_vg.maxTurn) g_vg.maxTurn = tn;
      g_vg.lastLevel = g_vigLevel;
      if (g_vigLevel > g_vg.maxLevel) g_vg.maxLevel = g_vigLevel;
    }
  }
  if (g_vigLevel <= 0.01) { InterlockedIncrement(&g_vg.offFrames); return; }
  if (!ensure_target(dev, eyeTex, eye & 1)) { InterlockedIncrement(&g_vg.noTarget); return; }
  const double cx = (double)bounds[0] + (double)bounds[2] - 1.0, cy = 1.0 - ((double)bounds[1] + (double)bounds[3]);
  const double hx = (double)bounds[2] - (double)bounds[0], hy = (double)bounds[3] - (double)bounds[1];
  static vig::Vert vv[vig::kSegments * (vig::kBands + 1) * 6];
  static cord::V cv[vig::kSegments * (vig::kBands + 1) * 6];
  const int n = vig::build(g_vigLevel, cx, cy, hx, hy, vv, (int)(sizeof(vv) / sizeof(vv[0])));
  if (n <= 0) { InterlockedIncrement(n < 0 ? &g_vg.tooBig : &g_vg.offFrames); return; }
  if (n > (int)kUiCap) { InterlockedIncrement(&g_vg.tooBig); return; }
  for (int i = 0; i < n; ++i) {
    cord::V& o = cv[i];
    o.p[0] = vv[i].p[0]; o.p[1] = vv[i].p[1]; o.p[2] = vv[i].p[2];
    o.n[0] = 0.0f; o.n[1] = 0.0f; o.n[2] = 1.0f;
    for (int k = 0; k < 4; ++k) o.c[k] = vv[i].c[k];
    if (g_vigRed) o.c[0] *= 0.10f;   // 1.7.197: the red channel keeps its light (the blend takes dst * (1 - colour)), so the dark edge shows red
  }
  Saved sv;
  save(ctx, &sv);
  D3D11_VIEWPORT vp = {0, 0, (float)g_w, (float)g_h, 0.0f, 1.0f};
  ctx->OMSetRenderTargets(1, &g_rtv[eye & 1], nullptr);
  ctx->RSSetViewports(1, &vp);
  ctx->RSSetState(g_rs);
  const float bf[4] = {0, 0, 0, 0};
  ctx->OMSetBlendState(g_bsDark, bf, 0xffffffff);
  ctx->OMSetDepthStencilState(g_dsOff, 0);
  ctx->IASetInputLayout(g_il);
  ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  ctx->VSSetShader(g_vs, nullptr, 0);
  ctx->PSSetShader(g_ps, nullptr, 0);
  ctx->GSSetShader(nullptr, nullptr, 0);
  ctx->HSSetShader(nullptr, nullptr, 0);
  ctx->DSSetShader(nullptr, nullptr, 0);
  ctx->VSSetConstantBuffers(0, 1, &g_cb);
  D3D11_MAPPED_SUBRESOURCE mp;
  if (FAILED(ctx->Map(g_uiVb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mp))) InterlockedIncrement(&g_vg.mapFail);
  else {
    for (int i = 0; i < n; ++i) ((cord::V*)mp.pData)[i] = cv[i];
    ctx->Unmap(g_uiVb, 0);
    // the vertices are flat NDC (x, y, 0): the transform scales them to eye space at depth z (x * tanH * z, y * tanV * z, z), so the picture coordinates stay exact
    const double z = 0.5;
    hand::Xform xv;
    for (int i = 0; i < 9; ++i) xv.r[i] = 0.0f;
    xv.r[0] = (float)(tanH * z); xv.r[4] = (float)(tanV * z); xv.r[8] = 1.0f;   // (the z row keeps the normal valid; the vertices have z = 0)
    xv.t[0] = 0.0f; xv.t[1] = 0.0f; xv.t[2] = (float)z;
    if (set_constants(ctx, xv, tanH, tanV, 1.0f, 80.0)) {
      UINT stride = sizeof(cord::V), offset = 0;
      ctx->IASetVertexBuffers(0, 1, &g_uiVb, &stride, &offset);
      ctx->Draw((UINT)n, 0);
      InterlockedIncrement(&g_vg.draws);
      g_vg.lastVerts = n; g_vg.lastCx = (float)cx; g_vg.lastCy = (float)cy; g_vg.lastHx = (float)hx; g_vg.lastHy = (float)hy;
      if (!g_vg.logged) { g_vg.logged = 1; log_line("VIGNETTE first draw: eye=%d level=%.2f centre=(%.3f, %.3f) half-size=(%.3f, %.3f) vertices=%d (picture coordinates, -1..1)", eye & 1, g_vigLevel, cx, cy, hx, hy, n); }
    }
  }
  restore(ctx, &sv);
}

void handmodel_report(LONG frame) {
  if (g_hf.n > 10) {
    const double n = (double)g_hf.n;
    log_line("HANDFEEL frames=%ld meanDt=%.2fms maxDt=%.1fms | predict=%dms | RIGHT: speed mean %.2f max %.1f m/s, shake(2nd diff) mean %.2f max %.1f mm, still %.0f%%, jumps(>8m/s) %ld, turn mean %.2f max %.1f deg/frame, turns>25deg %ld | LEFT: speed mean %.2f max %.1f m/s, shake mean %.2f max %.1f mm, still %.0f%%, jumps %ld, turn mean %.2f max %.1f, turns>25deg %ld",
             g_hf.n, g_hf.sumDt / n * 1000.0, g_hf.maxDt * 1000.0, (int)g_ctl.handPredictMs,
             g_hf.used[0] ? g_hf.sumV[0] / g_hf.used[0] : 0.0, g_hf.maxV[0], g_hf.used[0] ? g_hf.sumJ[0] / g_hf.used[0] * 1000.0 : 0.0, g_hf.maxJ[0] * 1000.0, g_hf.used[0] ? 100.0 * g_hf.still[0] / g_hf.used[0] : 0.0, g_hf.jumps[0],
             g_hf.used[0] ? g_hf.sumA[0] / g_hf.used[0] : 0.0, g_hf.maxA[0], g_hf.bigTurn[0],
             g_hf.used[1] ? g_hf.sumV[1] / g_hf.used[1] : 0.0, g_hf.maxV[1], g_hf.used[1] ? g_hf.sumJ[1] / g_hf.used[1] * 1000.0 : 0.0, g_hf.maxJ[1] * 1000.0, g_hf.used[1] ? 100.0 * g_hf.still[1] / g_hf.used[1] : 0.0, g_hf.jumps[1],
             g_hf.used[1] ? g_hf.sumA[1] / g_hf.used[1] : 0.0, g_hf.maxA[1], g_hf.bigTurn[1]);
  }
  log_line("PKEOWN on=%d tilt=%d draws=%d noPose=%d (the probe's own PKE meter in the right hand; the game's wand-slot model and cloth_pke bones are hidden while the PKE is out)", (int)g_ctl.pkeOwn, (int)g_ctl.pkeTiltDeg, (int)g_pkeOwn.pkeDraws, (int)g_pkeOwn.pkeNoPose);
  hosetex_report(frame);
  log_line("GEARDRAW frame=%d wheel=%d trap=%d wheelDraws=%d lastWheelVertices=%d mapFail=%d tooBig=%d trapInHandDraws=%d trapOnHipDraws=%d chestShield=%d shieldDraws=%d strapDraws=%d strapMiss=%d", (int)frame, (int)g_ctl.weaponWheel, (int)g_ctl.trapThrow,
           (int)g_gear.wheelDraws, g_gear.lastWheelVerts, (int)g_gear.wheelMapFail, (int)g_gear.wheelOver, (int)g_gear.trapHandDraws, (int)g_gear.trapHipDraws, (int)g_ctl.chestShield, (int)g_gear.shieldDraws, (int)g_gear.strapDraws, (int)g_gear.strapMiss);
  log_line("MARKDRAW frame=%d on=%d draws=%d nothingToShow=%d mapFail=%d tooBig=%d lastMarkers=%d lastVertices=%d mostAtOnce=%d markersDrawnTotal=%ld (the collectible markers in the eye pictures)", (int)frame, (int)g_ctl.collectMarkers, (int)g_mkd.draws, (int)g_mkd.none, (int)g_mkd.mapFail, (int)g_mkd.over, g_mkd.lastN, g_mkd.lastVerts, g_mkd.maxN, g_mkd.total);
  log_line("HANDS frame=%d on=%d state=%d draws=%d noPose=%d targetFail=%d", (int)frame, (int)g_ctl.handModel, g_state,
           (int)g_hs.draws, (int)g_hs.noPose, (int)g_hs.failed);
  log_line("CORD frame=%d on=%d active=%d draws=%d noPose=%d mapFail=%d buildFail=%d steps=%ld resets=%ld tautSteps=%ld floorTouches=%ld torsoTouches=%ld "
           "packEnd(last)=%.2f,%.2f,%.2f wandEnd(last)=%.2f,%.2f,%.2f m, ends apart min/mean/max=%.2f/%.2f/%.2f m, cordLength=%.2f m, fastestPoint=%.1f m/s, bodyYawDeg=%.0f",
           (int)frame, (int)g_ctl.cordPhysics, handmodel_cord_active(), (int)g_cs.draws, (int)g_cs.noPose, (int)g_cs.mapFail, (int)g_cs.buildFail,
           g_rope.steps, g_rope.resets, g_rope.taut, g_rope.floorHits, g_rope.capsuleHits,
           (double)g_cs.lastA[0], (double)g_cs.lastA[1], (double)g_cs.lastA[2], (double)g_cs.lastB[0], (double)g_cs.lastB[1], (double)g_cs.lastB[2],
           g_rope.steps ? g_rope.dMin : 0.0, g_rope.steps ? g_rope.dSum / (double)g_rope.steps : 0.0, g_rope.dMax, g_rope.len, g_rope.maxSpeed, g_rope.yaw * 57.29578);
  log_line("CORD2 length min/mean/max=%.2f/%.2f/%.2f m, middle hangs below the line between the ends: mean %.2f max %.2f m, tightest bend %.2f (1 = straight), bend pushes=%ld",
           g_rope.steps ? g_rope.lenMin : 0.0, g_rope.steps ? g_rope.lenSum / (double)g_rope.steps : 0.0, g_rope.lenMax,
           g_rope.sagN ? g_rope.sagSum / (double)g_rope.sagN : 0.0, g_rope.sagMax, g_rope.steps ? g_rope.foldMin : 0.0, g_rope.bendHits);
  log_line("CORD3 hose end taken from the game's gun: used=%ld (mean gap to the controller-based end %.1f cm, max %.1f cm, last %.1f cm) rejected(too far)=%ld (last %.1f cm) noData=%ld",
           g_cs.hoseUsed, g_cs.hoseUsed ? 100.0 * g_cs.hoseDistSum / (double)g_cs.hoseUsed : 0.0, 100.0 * g_cs.hoseDistMax, 100.0 * (double)g_cs.hoseLast, g_cs.hoseRej, 100.0 * (double)g_cs.hoseLastRej, g_cs.hoseNone);
  log_line("CORD4 hose start at the game's real pack: used=%ld (mean gap to the guessed spot %.1f cm, max %.1f cm) rejected=%ld (last %.1f cm) stale=%ld noPack=%ld | cord drawn while looking down %ld times, chest blocker skipped then %ld times",
           g_cs.anchorReal, g_cs.anchorReal ? 100.0 * g_cs.anchorDistSum / (double)g_cs.anchorReal : 0.0, 100.0 * g_cs.anchorDistMax, g_cs.anchorRej, 100.0 * (double)g_cs.anchorLastRej, g_cs.anchorStale, g_cs.anchorNone, g_cs.cordDownDraws, g_cs.shieldSkippedDown);
  log_line("RIGVIEW frame=%d mode=%d draws=%d lastVertices=%d noSnapshot=%d staleSnapshot=%d mapFail=%d tooBig=%d autoPictures=%d/6 (auto=%d)", (int)frame, (int)g_ctl.rigView, (int)g_rg.draws, g_rg.lastVerts,
           (int)g_rg.noSnap, (int)g_rg.stale, (int)g_rg.mapFail, (int)g_rg.over, (int)g_rg.shots, (int)g_ctl.rigAutoShots);
  log_line("HBARS frame=%d on=%d size=%d%% digits_setting=%d (ignored since 1.7.24, no percent is drawn; frame is black with a health-colour hairline) draws=%d noEnemies=%d mapFail=%d tooBig=%d lastBars=%d lastVertices=%d mostBarsAtOnce=%d barsDrawnTotal=%ld", (int)frame, (int)g_ctl.hbar,
           (int)g_ctl.hbarSizePct, (int)g_ctl.hbarDigits, (int)g_bar.draws, (int)g_bar.none, (int)g_bar.mapFail, (int)g_bar.over, g_bar.lastBars, g_bar.lastVerts, g_bar.maxBars, g_bar.barsTotal);
  log_line("VIGNETTE frame=%d strength=%d%% (0 = off) | drawn %ld times, level now %.2f, highest %.2f, lastVertices=%d window centre (%.2f, %.2f) half-size (%.2f, %.2f) | skipped(too faint) %ld, noTarget %ld, mapFail %ld, tooBig %ld, noBlendState %ld | inputs: biggest walk push %.2f, biggest turn push %.2f, sprint frames %ld, menu preview frames %ld, dash pulses %ld",
           (int)frame, (int)g_ctl.vignettePct, (long)g_vg.draws, g_vg.lastLevel, g_vg.maxLevel, g_vg.lastVerts, (double)g_vg.lastCx, (double)g_vg.lastCy, (double)g_vg.lastHx, (double)g_vg.lastHy,
           (long)g_vg.offFrames, (long)g_vg.noTarget, (long)g_vg.mapFail, (long)g_vg.tooBig, (long)g_vg.noBlend, g_vg.maxMove, g_vg.maxTurn, (long)g_vg.sprintFrames, (long)g_vg.menuPreview, (long)g_vg.pulses);
  log_line("HBARALPHA frame=%d see-through %d%% solid-ness (100 = solid): drawn see-through %ld times, solid %ld times%s", (int)frame, (int)g_ctl.hbarAlphaPct, (long)g_bar.seeThrough, (long)g_bar.solid, g_bsWheel ? "" : " (the see-through blend state could not be made: bars are solid)");
}

#endif
