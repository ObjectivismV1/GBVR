// 1.7.58 exact game-hand prop anchoring.
//
// The game already knows where a hand holds each prop.  Preserve that complete
// prop->hand relationship (translation + rotation + scale) and reapply it to
// the VR-driven hand.  No guessed centimetre offsets are involved.
//
// Matrices are the game's row-vector 3x4/4x4 affine layout:
//     childWorld = childLocal * parentWorld
// and translation is at [12..14].
#pragma once
#include "vmath.h"

namespace handprop {

inline int finite16(const float* m) {
  for (int i = 0; i < 16; ++i) if (!vm::is_finite_f(m[i])) return 0;
  return 1;
}

inline void ident(float* o) {
  for (int i = 0; i < 16; ++i) o[i] = 0.0f;
  o[0] = o[5] = o[10] = o[15] = 1.0f;
}

// A tracked-hand frame in game-world coordinates. The exact relation to this
// frame is captured from a successful game-hand placement, never guessed.
inline int tracked_frame(const float* grip, const float* forward, const float* up, float* o) {
  if (!grip || !forward || !up || !o) return 0;
  for (int i=0;i<3;++i) if (!vm::is_finite_f(grip[i]) || !vm::is_finite_f(forward[i]) || !vm::is_finite_f(up[i])) return 0;
  double f[3]={forward[0],forward[1],forward[2]}, u[3]={up[0],up[1],up[2]};
  double fl=vm::dsqrt(f[0]*f[0]+f[1]*f[1]+f[2]*f[2]);
  if (!(fl>0.5 && fl<2.0)) return 0;
  for (int i=0;i<3;++i) f[i]/=fl;
  double dot=u[0]*f[0]+u[1]*f[1]+u[2]*f[2];
  for (int i=0;i<3;++i) u[i]-=dot*f[i];
  double ul=vm::dsqrt(u[0]*u[0]+u[1]*u[1]+u[2]*u[2]);
  if (!(ul>0.3 && ul<2.0)) return 0;
  for (int i=0;i<3;++i) u[i]/=ul;
  double r[3]={u[1]*f[2]-u[2]*f[1],u[2]*f[0]-u[0]*f[2],u[0]*f[1]-u[1]*f[0]};
  ident(o);
  for (int i=0;i<3;++i) { o[i]=(float)r[i]; o[4+i]=(float)u[i]; o[8+i]=(float)f[i]; o[12+i]=grip[i]; }
  return finite16(o);
}

inline void mul34(float* o, const float* a, const float* b) {
  float t[16];
  for (int i = 0; i < 16; ++i) t[i] = 0.0f;
  // row-vector affine: linear = A.linear * B.linear,
  // translation = A.translation * B.linear + B.translation.
  for (int r = 0; r < 3; ++r) {
    for (int c = 0; c < 3; ++c)
      t[r * 4 + c] = a[r * 4 + 0] * b[0 * 4 + c] + a[r * 4 + 1] * b[1 * 4 + c] + a[r * 4 + 2] * b[2 * 4 + c];
  }
  for (int c = 0; c < 3; ++c)
    t[12 + c] = a[12] * b[c] + a[13] * b[4 + c] + a[14] * b[8 + c] + b[12 + c];
  t[15] = 1.0f;
  for (int i = 0; i < 16; ++i) o[i] = t[i];
}

inline int inv34(const float* m, float* o) {
  const double A[9] = {m[0],m[1],m[2], m[4],m[5],m[6], m[8],m[9],m[10]};
  const double c0 = A[4] * A[8] - A[5] * A[7];
  const double c1 = A[5] * A[6] - A[3] * A[8];
  const double c2 = A[3] * A[7] - A[4] * A[6];
  const double d = A[0] * c0 + A[1] * c1 + A[2] * c2;
  if (!(vm::dabs(d) > 1e-12)) return 0;
  const double id = 1.0 / d;
  const double Ai[9] = {
    c0 * id, (A[2] * A[7] - A[1] * A[8]) * id, (A[1] * A[5] - A[2] * A[4]) * id,
    c1 * id, (A[0] * A[8] - A[2] * A[6]) * id, (A[2] * A[3] - A[0] * A[5]) * id,
    c2 * id, (A[1] * A[6] - A[0] * A[7]) * id, (A[0] * A[4] - A[1] * A[3]) * id
  };
  for (int i = 0; i < 16; ++i) o[i] = 0.0f;
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) o[r * 4 + c] = (float)Ai[r * 3 + c];
  for (int c = 0; c < 3; ++c)
    o[12 + c] = (float)-(m[12] * Ai[c] + m[13] * Ai[3 + c] + m[14] * Ai[6 + c]);
  o[15] = 1.0f;
  return finite16(o);
}

inline int relative(const float* propGame, const float* handGame, float* rel) {
  float ih[16];
  if (!finite16(propGame) || !finite16(handGame) || !inv34(handGame, ih)) return 0;
  mul34(rel, propGame, ih); // prop = rel * hand
  return finite16(rel);
}

inline int place(const float* rel, const float* handFinal, float* propFinal) {
  if (!finite16(rel) || !finite16(handFinal)) return 0;
  mul34(propFinal, rel, handFinal);
  return finite16(propFinal);
}

inline double row_len(const float* m, int r) {
  const double x=m[r*4], y=m[r*4+1], z=m[r*4+2];
  return vm::dsqrt(x*x+y*y+z*z);
}

inline double rel_pos_delta(const float* a, const float* b) {
  const double x=(double)a[12]-b[12], y=(double)a[13]-b[13], z=(double)a[14]-b[14];
  return vm::dsqrt(x*x+y*y+z*z);
}

inline double rel_axis_delta(const float* a, const float* b) {
  // Return worst 1-dot between corresponding normalized axes.  This avoids any CRT trig dependency.
  double worst = 0.0;
  for (int r=0;r<3;++r) {
    const double la=row_len(a,r), lb=row_len(b,r);
    if (!(la>1e-8 && lb>1e-8)) return 2.0;
    double dot=0.0;
    for (int c=0;c<3;++c) dot += ((double)a[r*4+c]/la)*((double)b[r*4+c]/lb);
    if (dot>1.0) dot=1.0; if (dot<-1.0) dot=-1.0;
    const double e=1.0-dot; if (e>worst) worst=e;
  }
  return worst;
}

// 1.7.93: how far a prop's origin may be from the hand that holds it, for the relation to count as a HOLD (feet; 1.0 ft = 30.5 cm).
// Real holds in the logs: the guns 9-10 cm, the meter 6-20 cm.  The logs of players whose game starts in a cut-scene also show relations of 40.3 cm and 77.6 cm: the
// gun is still on the back, not in the hand.  Those were locked as "the grip" and the gun then floated that far from the hand for the whole session.
static const double kMaxHoldFt = 0.5;   // 1.7.175: was 1.0; real holds are 9-17 cm (0.3-0.55 ft), a 30 cm lock was a prop caught mid-draw

inline double rel_len_ft(const float* rel) {
  if (!rel) return 0.0;
  const double x = rel[12], y = rel[13], z = rel[14];
  return vm::dsqrt(x * x + y * y + z * z);
}

struct GripLock {
  float rel[16];
  float prev[16];
  int havePrev;
  int stable;
  int locked;
  long captures;
  long resets;
  long tooFar;        // 1.7.93: samples refused because the prop was farther from the hand than kMaxHoldFt (not a hold)
  double lastFarFt;   // 1.7.93: the length of the last refused relation
};

// Preserve how the FINAL rendered game hand sits on the tracked controller.
// This is intentionally a hand->controller relationship, never a prop->controller
// relationship.  During a short rig/view-model gap we reconstruct the hand first,
// then apply the game's locked prop->hand relationship to that hand.
struct HandFollower {
  float rel[16];
  float prev[16];
  int have;
  int havePrev;
  int stable;
  int locked;
  long captures;
  long resets;
};

inline void reset(HandFollower* s) {
  if (!s) return;
  for (int i=0;i<16;++i) s->rel[i]=s->prev[i]=0.0f;
  s->have=s->havePrev=s->stable=s->locked=0; s->captures=s->resets=0;
}

inline int capture_hand(HandFollower* s, const float* finalHand, const float* tracked) {
  if (!s || !finalHand || !tracked) return 0;
  float fresh[16];
  if (!relative(finalHand, tracked, fresh)) return 0; // finalHand = rel * tracked
  ++s->captures;
  if (!s->locked) {
    if (s->havePrev) {
      const double dp=rel_pos_delta(fresh,s->prev), da=rel_axis_delta(fresh,s->prev);
      if (dp <= 0.05 && da <= 0.00137046525) ++s->stable;
      else { s->stable=0; ++s->resets; }
    }
    for (int i=0;i<16;++i) { s->prev[i]=fresh[i]; s->rel[i]=fresh[i]; }
    s->havePrev=1; s->have=1;
    if (s->stable >= 5) s->locked=1;
  }
  return s->have;
}

// 1.7.143 THE HELD GUN / PKE DRIFTING OUT OF THE HAND: the hand <-> controller relation (HandFollower) is locked once and was then kept for the whole life of the
// player actor. The gun (gun_ctl_follow) and the PKE (when its hand is rebuilt from the controller) sit on the CONTROLLER through it, but the hand you SEE is the arm
// solve's hand. Whatever later changes where the arm puts the hand for a given controller pose (world / player size, a height measure, the body's size following the
// model, a lock taken while the arm had not reached yet) left the prop where the old relation says: in a review video the gun sat 20-30 cm above the hand after 15
// minutes, and GUNSLIP lines showed 6-54 cm with no stretch. Now, once locked, the relation follows the drawn hand back: when the arm's hand disagrees with it by more
// than minFt while the two are steady (not a fast swing, where the arm trails for a moment, the 1.7.78 reason for the lock), it eases to the drawn hand.
struct HandDrift { float ema[16]; int haveEma, run, easing; long eases, relocks; double lastCm, maxCm; };
inline void reset(HandDrift* d) { if (!d) return; d->haveEma = 0; d->run = 0; d->easing = 0; d->lastCm = 0.0; }
// armHand: the hand the arm solve drew; tracked: the controller frame of that moment. Returns 1 when the relation was moved this call.
// The drawn hand's relation is first smoothed (ema, about 80 ms), so tracking jitter and walking bob neither block the check nor shake the gun; a sample far from
// the smoothed one (more than 3 cm: a fast swing, the arm trailing) stops it, and the relation eases toward the SMOOTHED hand only.
inline int drift_step(HandFollower* s, HandDrift* d, const float* armHand, const float* tracked, double minFt = 0.1, double stepFrac = 0.12, int needRun = 20) {
  if (!s || !d || !armHand || !tracked || !s->locked) return 0;
  float fresh[16];
  if (!relative(armHand, tracked, fresh)) return 0;
  if (!d->haveEma || !finite16(d->ema)) { for (int i = 0; i < 16; ++i) d->ema[i] = fresh[i]; d->haveEma = 1; d->run = 0; return 0; }
  const double jump = rel_pos_delta(fresh, d->ema), jumpAx = rel_axis_delta(fresh, d->ema);
  float prevEma[16]; for (int i = 0; i < 16; ++i) prevEma[i] = d->ema[i];
  if (jump > 0.5 || jumpAx > 0.06) { for (int i = 0; i < 16; ++i) d->ema[i] = fresh[i]; d->run = 0; d->easing = 0; return 0; }   // a cut / teleport / new pose: start the smoothing again
  for (int i = 0; i < 16; ++i) d->ema[i] += (fresh[i] - d->ema[i]) * 0.15f;
  const int steady = jump <= 0.1 && jumpAx <= 0.0152 && rel_pos_delta(d->ema, prevEma) <= 0.01 && rel_axis_delta(d->ema, prevEma) <= 0.0005;
  const double dp = rel_pos_delta(d->ema, s->rel), da = rel_axis_delta(d->ema, s->rel);
  d->lastCm = dp * 30.48; if (d->lastCm > d->maxCm) d->maxCm = d->lastCm;
  if (!steady) { d->run = 0; return 0; }
  if (!d->easing) {
    if (dp > minFt || da > 0.0152) { if (++d->run >= needRun) { d->easing = 1; ++d->relocks; } else return 0; }
    else { d->run = 0; return 0; }
  }
  if (dp <= 0.02 && da <= 0.0005) { d->easing = 0; d->run = 0; return 0; }   // back in the hand (within about 6 mm)
  const float k = (float)stepFrac;
  for (int i = 0; i < 16; ++i) s->rel[i] += (d->ema[i] - s->rel[i]) * k;
  ++d->eases;
  return 1;
}

inline int follow_hand(const HandFollower* s, const float* tracked, float* finalHand) {
  if (!s || !s->have || !tracked || !finalHand) return 0;
  return place(s->rel, tracked, finalHand);
}

inline void reset(GripLock* s) {
  if (!s) return;
  for (int i=0;i<16;++i) s->rel[i]=s->prev[i]=0.0f;
  s->havePrev=s->stable=s->locked=0; s->captures=s->resets=0; s->tooFar=0; s->lastFarFt=0.0;
}

// Use the game's exact current relation immediately.  Once that relation is
// stable for several consecutive samples, freeze it for this item so an
// animation/view-model rebuild or holster/draw cannot move the grip.
inline int step(GripLock* s, const float* propGame, const float* handGame, const float* handFinal, float* propFinal) {
  if (!s || !propGame || !handGame || !handFinal || !propFinal) return 0;
  float fresh[16];
  if (!relative(propGame, handGame, fresh)) return 0;
  ++s->captures;
  if (!s->locked) {
    // 1.7.93: a prop that is not within reach of the hand (still on the back, or on its way out of the holster) is not held: nothing is locked or placed from it.
    // The caller then leaves the game's own model where the game put it until the real hold shows up (about 10 cm from the hand) and has been steady for a moment.
    const double len = rel_len_ft(fresh);
    if (!(len <= kMaxHoldFt)) {
      ++s->tooFar; s->lastFarFt = len;
      s->stable = 0; s->havePrev = 0;
      return 0;
    }
    // 1.7.175: stability is measured from an ANCHOR (the first sample), not between consecutive samples. A prop sliding into the hand at 1 m/s passes a
    // sample-to-sample test and was locked mid-draw (the "floats after switching" bug). Now it must stay within 1.5 mm and 1 degree of the anchor for 20 samples.
    if (s->havePrev) {
      const double dp = rel_pos_delta(fresh, s->prev);
      const double da = rel_axis_delta(fresh, s->prev);
      if (dp <= 0.005 && da <= 0.000152) ++s->stable;   // cos(1 deg) ~= 0.99985
      else { s->stable = 0; ++s->resets; for (int i=0;i<16;++i) s->prev[i]=fresh[i]; }
    } else {
      for (int i=0;i<16;++i) s->prev[i]=fresh[i];
    }
    for (int i=0;i<16;++i) s->rel[i]=fresh[i];
    s->havePrev=1;
    if (s->stable >= 20) s->locked=1;
  }
  const float* use = s->locked ? s->rel : fresh;
  return place(use, handFinal, propFinal);
}

// 1.7.66: the PKE follows the relation the game shows NOW (live) instead of a relation frozen early.
// 1.7.65's PKE log showed the freeze being taken while the meter was still coming out of the belt (15 cm from the hand, the game's own hold is 8-13 cm),
// and the self-check only re-captured after 9 cm / 10 degrees for 20 samples, so the meter stayed far from the hand for seconds.
// A fresh relation that moves a little from the one in use is followed at once. A big jump is believed only when the same new relation is seen for
// `run` fresh samples in a row, so a one-frame glitch while the view model is rebuilt is ignored.
struct Live {
  float rel[16];
  float cand[16];
  int have, candRun;
  long accepted, held, jumps;
  double lastJumpFt, maxStepFt;
};

inline void reset(Live* s) {
  if (!s) return;
  for (int i = 0; i < 16; ++i) s->rel[i] = s->cand[i] = 0.0f;
  s->have = s->candRun = 0; s->accepted = s->held = s->jumps = 0; s->lastJumpFt = s->maxStepFt = 0.0;
}

// fresh = the game's current prop->hand relation (or nullptr when this call had no fresh game sample). Returns 1 when a relation is in use.
inline int live_update(Live* s, const float* fresh, double posJumpFt, double axJump, int run) {
  if (!s) return 0;
  if (!fresh || !finite16(fresh)) return s->have;
  if (!s->have) {
    for (int i = 0; i < 16; ++i) s->rel[i] = fresh[i];
    s->have = 1; s->candRun = 0; ++s->accepted;
    return 1;
  }
  const double dp = rel_pos_delta(fresh, s->rel), da = rel_axis_delta(fresh, s->rel);
  if (dp <= posJumpFt && da <= axJump) {
    for (int i = 0; i < 16; ++i) s->rel[i] = fresh[i];
    s->candRun = 0; ++s->accepted;
    if (dp > s->maxStepFt) s->maxStepFt = dp;
    return 1;
  }
  // a big change: only believed when the same new relation is seen again and again
  if (s->candRun > 0 && rel_pos_delta(fresh, s->cand) <= 0.05 && rel_axis_delta(fresh, s->cand) <= 0.00137046525) ++s->candRun;
  else { for (int i = 0; i < 16; ++i) s->cand[i] = fresh[i]; s->candRun = 1; }
  if (s->candRun >= run) {
    for (int i = 0; i < 16; ++i) s->rel[i] = fresh[i];
    s->candRun = 0; ++s->jumps; s->lastJumpFt = dp;
  } else ++s->held;
  return 1;
}

// the average length of the three axis rows (1.0 = no scale); used to log whether the final hand is scaled against the game's hand
inline double mean_scale(const float* m) {
  return (row_len(m, 0) + row_len(m, 1) + row_len(m, 2)) / 3.0;
}

// 1.7.67: the 1.7.66 log showed the drawn hand matrix itself changing size from one moment to the next (average axis length 1.02 -> 1.38, one axis up to about 1.9
// times the others) while the game's own hand stayed at 1.00. A prop placed through that hand was stretched and pushed out by the same factor ("the PKE is pulled").
// row_ratio = longest axis / shortest axis of the 3x3 (1.0 = no stretch, 0 = not usable).
inline double row_ratio(const float* m) {
  double lo = 1e30, hi = 0.0;
  for (int r = 0; r < 3; ++r) { const double l = row_len(m, r); if (!(l > 1e-6)) return 0.0; if (l < lo) lo = l; if (l > hi) hi = l; }
  return hi / lo;
}

// A clean copy of a hand matrix: the three axes keep their directions, are made exactly perpendicular, all get the same length `s`, and the position is kept.
// (Row-vector 3x4: rows 0..2 are the axes, row 3 = position.)  Returns 0 when the matrix cannot be cleaned (flat, mirrored, not finite).
inline int rigid_frame(const float* m, double s, float* out) {
  if (!m || !out || !(s > 1e-3) || !finite16(m)) return 0;
  double R[9];
  for (int r = 0; r < 3; ++r) {
    const double l = row_len(m, r);
    if (!(l > 1e-6)) return 0;
    for (int c = 0; c < 3; ++c) R[r * 3 + c] = (double)m[r * 4 + c] / l;
  }
  // polish to the nearest rotation: R <- (R + R^-T) / 2   (a few rounds; exact for axes that were only scaled)
  for (int it = 0; it < 6; ++it) {
    const double c0 = R[4] * R[8] - R[5] * R[7], c1 = R[5] * R[6] - R[3] * R[8], c2 = R[3] * R[7] - R[4] * R[6];
    const double d = R[0] * c0 + R[1] * c1 + R[2] * c2;
    if (!(d > 1e-6)) return 0;   // flat or mirrored
    const double id = 1.0 / d;
    // inverse transpose = cofactor matrix / det
    const double T[9] = { c0 * id, c1 * id, c2 * id,
                          (R[2] * R[7] - R[1] * R[8]) * id, (R[0] * R[8] - R[2] * R[6]) * id, (R[1] * R[6] - R[0] * R[7]) * id,
                          (R[1] * R[5] - R[2] * R[4]) * id, (R[2] * R[3] - R[0] * R[5]) * id, (R[0] * R[4] - R[1] * R[3]) * id };
    for (int i = 0; i < 9; ++i) R[i] = 0.5 * (R[i] + T[i]);
  }
  for (int i = 0; i < 16; ++i) out[i] = 0.0f;
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = (float)(R[r * 3 + c] * s);
  out[12] = m[12]; out[13] = m[13]; out[14] = m[14]; out[15] = 1.0f;
  return finite16(out);
}

// Map a child/attachment that belongs to a prop through the same exact rigid
// model transform used to move the prop itself.
inline int map_part(const float* partGame, const float* propGame, const float* propFinal, float* partFinal) {
  float rel[16];
  if (!relative(partGame, propGame, rel)) return 0;
  return place(rel, propFinal, partFinal);
}

} // namespace handprop
