// 0.51 controller motors. Pure math, no Windows dependency; unit-tested in tests/test_haptic.cpp.
//
// SteamVR's old haptic call plays ONE short buzz (at most 4 ms) per call. One call per game
// frame (what 0.33-0.50 did, and only when the game asked for rumble) is a barely noticeable tick.
// 0.51 keeps a list of effects per hand ("the right hand: fire sustain 0.3 for the next 80 ms,
// a kick 0.9 for 45 ms ...") and a small thread turns the strongest of them into a stream of
// pulses every few milliseconds: the pulse length is the strength (0.1 = 0.4 ms ... 1.0 = 4 ms),
// so a strength of 1 is a continuous buzz and 0.3 a light one.
#pragma once
#include <stdint.h>

namespace hap {

// who asked (also the index of the per-source counters in the log)
enum Src {
  kSrcGame = 0,   // the game's own rumble request (XInputSetState)
  kSrcFireKick,   // trigger just pulled
  kSrcFireHold,   // trigger held: the stream
  kSrcBlast,      // secondary fire
  kSrcTwoHand,    // the off hand took hold of the wand
  kSrcPack,       // a hand touched the pack zone
  kSrcVent,       // venting
  kSrcHolster,    // holster / draw
  kSrcMark,       // MARK gesture
  kSrcButton,     // any other button press (confirmation tick)
  kSrcHello,      // start-up check / test
  kSrcTrigger,    // trigger clicks that are not firing (menus)
  kSrcScan,       // 1.4 PKE: a ghost is in the scan, the scan runs, the scan is done
  kSrcSlam,       // 1.7: the capture stream took hold of a ghost / the slam
  kSrcKnock,      // 1.7.190: the soft knock-down window: a light rumble
  kSrcCount
};
inline const char* src_name(int s) {
  static const char* n[kSrcCount] = {"game", "fireKick", "fireHold", "blast", "twoHand", "pack", "vent", "holster", "mark", "button", "hello", "trigger", "scan", "slam", "knock"};
  return (unsigned)s < (unsigned)kSrcCount ? n[s] : "?";
}

// 1.7.13 PKE proximity: the closer the nearest thing to scan, the faster AND the stronger the right hand buzzes (a Geiger counter).
// ft = distance to the nearest unscanned source / collectible; nothing is felt beyond kProxRangeFt.
constexpr double kProxRangeFt = 60.0;
inline double prox_closeness(double ft) { if (!(ft >= 0.0)) return 0.0; double t = 1.0 - ft / kProxRangeFt; return t < 0.0 ? 0.0 : (t > 1.0 ? 1.0 : t); }
inline double prox_level(double ft) { const double t = prox_closeness(ft); return t <= 0.0 ? 0.0 : 0.12 + 0.88 * t * t; }       // 0.12 far .. 1.0 on top of it
inline double prox_period_s(double ft) { const double t = prox_closeness(ft); return 0.80 - 0.70 * t; }                          // 0.8 s far .. 0.1 s close
inline int prox_ms(double ft) { const double t = prox_closeness(ft); return (int)(30.0 + 70.0 * t); }                            // 30 ms far .. 100 ms close

struct Mixer {
  double until[2][kSrcCount];   // seconds (absolute) at which the effect ends
  double level[2][kSrcCount];   // 0..1
  uint32_t starts[2][kSrcCount];   // how many times an effect was (re)started
  double peak[2][kSrcCount];
  void reset() {
    for (int h = 0; h < 2; ++h) for (int s = 0; s < kSrcCount; ++s) { until[h][s] = 0; level[h][s] = 0; starts[h][s] = 0; peak[h][s] = 0; }
  }
  // An effect of this source on this hand: level 0..1 for ms milliseconds from now. A new call
  // for the same source replaces the old one (sustained effects are simply renewed every poll).
  void add(int hand, int src, double lvl, double nowSec, double ms) {
    if ((unsigned)hand > 1u || (unsigned)src >= (unsigned)kSrcCount) return;
    if (lvl < 0) lvl = 0; if (lvl > 1) lvl = 1;
    if (!(until[hand][src] > nowSec)) starts[hand][src]++;
    until[hand][src] = nowSec + ms * 0.001;
    level[hand][src] = lvl;
    if (lvl > peak[hand][src]) peak[hand][src] = lvl;
  }
  void stop(int hand, int src) { if ((unsigned)hand <= 1u && (unsigned)src < (unsigned)kSrcCount) until[hand][src] = 0; }
  // strength of the hand now: the strongest effect plus a quarter of the second strongest (so
  // two simultaneous effects feel a little stronger than one), capped at 1.
  double level_now(int hand, double nowSec, int* topSrc = 0) const {
    double a = 0, b = 0; int top = -1;
    for (int s = 0; s < kSrcCount; ++s) {
      if (!(until[hand][s] > nowSec)) continue;
      double l = level[hand][s];
      if (l > a) { b = a; a = l; top = s; } else if (l > b) b = l;
    }
    if (topSrc) *topSrc = top;
    double v = a + 0.25 * b;
    return v > 1.0 ? 1.0 : v;
  }
};

// strength 0..1 (after the user's percentage) -> pulse length in microseconds (0 = silence).
inline unsigned pulse_us(double strength) {
  if (!(strength > 0.04)) return 0;
  if (strength > 1.0) strength = 1.0;
  unsigned us = (unsigned)(strength * 3999.0);
  return us < 300 ? 300 : us;
}

// the game's two rumble motors (0..65535) -> strength 0..1 (small values still give a clear buzz)
inline double rumble_strength(unsigned left, unsigned right) {
  unsigned m = left > right ? left : right;
  if (m < 1500) return 0;
  double s = (double)m / 65535.0;
  return 0.30 + 0.70 * s;
}

}  // namespace hap
