// 0.51 controller motors: a thread turns the effects asked for by the rest of the tool (the game's rumble,
// firing, venting, touching the pack, two-hand grip, button ticks ...) into a steady stream of SteamVR haptic
// pulses. See hapticmath.h for why. Everything is counted and written to the log (HAPTIC line).
#include "gbvr.h"

#if GBVR_HEADTRACK
#include "vr_pose.h"
#include "hapticmath.h"

namespace {
SRWLOCK g_lock = SRWLOCK_INIT;
hap::Mixer g_mix;
volatile LONG g_started;

struct Stats {
  volatile LONG ticks, pulses[2], notReady, noDevice, silent, inputOff, adds[hap::kSrcCount];
  volatile LONG maxGapX10, gapOver20, gapSamples;   // time between two ticks, milliseconds x 10
  volatile LONG lastUs[2], maxUs[2];
  volatile LONG timerKind;                          // 1 high resolution waitable timer, 2 normal timer, 3 Sleep
  volatile LONG scriptRuns;
} g_st;

// scripted tests: {start ms, hand, level, duration ms}
struct Step { int atMs; int hand; double level; int ms; };
const Step kHello[] = {{0, 0, 0.60, 300}, {450, 1, 0.60, 300}};
const Step kTest[] = {
  {0, 1, 0.20, 250}, {400, 1, 0.45, 250}, {800, 1, 0.70, 250}, {1200, 1, 1.00, 250},
  {1900, 0, 0.20, 250}, {2300, 0, 0.45, 250}, {2700, 0, 0.70, 250}, {3100, 0, 1.00, 250},
  {3800, 0, 0.70, 400}, {3800, 1, 0.70, 400}};
const Step* g_script;
int g_scriptN;
int g_scriptDone;                // bit mask of steps already started
double g_scriptT0;               // seconds
const char* g_scriptName = "";

double now_sec() { return (double)qpc_now() / (double)qpc_freq(); }

typedef LONG(NTAPI* PFN_NtSetTimerResolution)(ULONG, BOOLEAN, PULONG);

DWORD WINAPI haptics_thread(LPVOID) {
  HANDLE tm = CreateWaitableTimerExW(nullptr, nullptr, 0x00000002 /* CREATE_WAITABLE_TIMER_HIGH_RESOLUTION */, 0x1F0003 /* TIMER_ALL_ACCESS */);
  g_st.timerKind = 1;
  if (!tm) { tm = CreateWaitableTimerW(nullptr, TRUE, nullptr); g_st.timerKind = tm ? 2 : 3; }
  if (g_st.timerKind != 1) {   // the normal timer is only as fine as the system clock: ask for 1 ms
    HMODULE nt = GetModuleHandleW(L"ntdll.dll");
    PFN_NtSetTimerResolution f = nt ? (PFN_NtSetTimerResolution)GetProcAddress(nt, "NtSetTimerResolution") : nullptr;
    ULONG cur = 0;
    if (f) f(10000, TRUE, &cur);
  }
  double last = now_sec();
  int64_t lastLog = 0; (void)lastLog;
  for (;;) {
    LONG periodMs = g_ctl.hapticPeriodMs;
    if (periodMs < 3) periodMs = 3;
    if (periodMs > 20) periodMs = 20;
    if (tm) {
      LARGE_INTEGER due;
      due.QuadPart = -(LONGLONG)periodMs * 10000;
      if (SetWaitableTimer(tm, &due, 0, nullptr, nullptr, FALSE)) WaitForSingleObject(tm, 100);
      else Sleep((DWORD)periodMs);
    } else {
      Sleep((DWORD)periodMs);
    }
    double now = now_sec();
    double gapMs = (now - last) * 1000.0;
    last = now;
    InterlockedIncrement(&g_st.ticks);
    if (g_st.ticks > 3) {
      LONG g10 = (LONG)(gapMs * 10.0);
      if (g10 > g_st.maxGapX10) g_st.maxGapX10 = g10;
      if (gapMs > 20.0) InterlockedIncrement(&g_st.gapOver20);
      InterlockedIncrement(&g_st.gapSamples);
    }
    (void)lastLog;
    // scripted test steps
    AcquireSRWLockExclusive(&g_lock);
    if (g_script) {
      int allDone = 1;
      for (int i = 0; i < g_scriptN; ++i) {
        if (g_scriptDone & (1 << i)) continue;
        allDone = 0;
        if ((now - g_scriptT0) * 1000.0 >= g_script[i].atMs) {
          g_mix.add(g_script[i].hand, hap::kSrcHello, g_script[i].level, now, g_script[i].ms);
          InterlockedIncrement(&g_st.adds[hap::kSrcHello]);
          g_scriptDone |= 1 << i;
        }
      }
      if (allDone) g_script = nullptr;
    }
    double lvl[2] = {g_mix.level_now(0, now), g_mix.level_now(1, now)};
    ReleaseSRWLockExclusive(&g_lock);
    if (!g_ctl.padEnabled) continue;
    double scale = (double)g_ctl.hapticPct / 100.0;
    if (scale <= 0.0) continue;
    for (int h = 0; h < 2; ++h) {
      // 1.7.96: a Valve Index's actuators are far stronger than a Touch controller's for the same pulse (the Index report: "any button, the rumble is intense"): 30 % of the strength, real Index only
      static int s_idxKind[2] = {-1, -1}; static DWORD s_idxAt[2];
      if (s_idxKind[h] < 0 || GetTickCount() - s_idxAt[h] > 2000) { int lk = 0; s_idxKind[h] = (vr_capi_axis_peaks(h, nullptr, &lk) == 2 && !lk) ? 1 : 0; s_idxAt[h] = GetTickCount(); }
      unsigned us = hap::pulse_us(lvl[h] * scale * (s_idxKind[h] == 1 ? 0.30 : 1.0));
      if (!us) { if (lvl[h] > 0.0) InterlockedIncrement(&g_st.silent); continue; }
      int r = vr_capi_haptic_dev(h, us);
      if (r == 1) {
        InterlockedIncrement(&g_st.pulses[h]);
        g_st.lastUs[h] = (LONG)us;
        if ((LONG)us > g_st.maxUs[h]) g_st.maxUs[h] = (LONG)us;
      } else if (r == 0) InterlockedIncrement(&g_st.notReady);
      else InterlockedIncrement(&g_st.noDevice);
    }
  }
  return 0;
}
}  // namespace

void haptics_start() {
  if (InterlockedCompareExchange(&g_started, 1, 0) != 0) return;
  AcquireSRWLockExclusive(&g_lock);
  g_mix.reset();
  ReleaseSRWLockExclusive(&g_lock);
  HANDLE t = CreateThread(nullptr, 0, haptics_thread, nullptr, 0, nullptr);
  if (t) { SetThreadPriority(t, THREAD_PRIORITY_ABOVE_NORMAL); CloseHandle(t); log_line("HAPTIC thread started (pulse period %d ms, strength %d %%)", (int)g_ctl.hapticPeriodMs, (int)g_ctl.hapticPct); }
  else log_line("HAPTIC could not start the haptics thread: the controller motors stay silent");
}

// any thread. level 0..1, ms duration (renewed by calling again)
void haptics_add(int hand, int src, float level, int ms) {
  if (!g_started) haptics_start();
  double now = now_sec();
  AcquireSRWLockExclusive(&g_lock);
  g_mix.add(hand, src, level, now, ms);
  ReleaseSRWLockExclusive(&g_lock);
  if ((unsigned)src < (unsigned)hap::kSrcCount) InterlockedIncrement(&g_st.adds[src]);
}

void haptics_stop_source(int hand, int src) {
  AcquireSRWLockExclusive(&g_lock);
  g_mix.stop(hand, src);
  ReleaseSRWLockExclusive(&g_lock);
}

// kind 0: short "hello" (left, then right); kind 1: strength ladder on each hand (Ctrl+H)
void haptics_test(int kind) {
  if (!g_started) haptics_start();
  double now = now_sec();
  AcquireSRWLockExclusive(&g_lock);
  g_script = kind ? kTest : kHello;
  g_scriptN = kind ? (int)(sizeof(kTest) / sizeof(kTest[0])) : (int)(sizeof(kHello) / sizeof(kHello[0]));
  g_scriptDone = 0;
  g_scriptT0 = now;
  g_scriptName = kind ? "test ladder (right hand 4 steps, left hand 4 steps, both)" : "hello (left, then right)";
  ReleaseSRWLockExclusive(&g_lock);
  InterlockedIncrement(&g_st.scriptRuns);
  log_line("HAPTIC %s started (strength %d %%, input available=%d)", kind ? "test ladder" : "hello", (int)g_ctl.hapticPct, vr_capi_input_available());
}

void haptics_report(LONG frame) {
  if (!g_started) return;
  char per[420];
  int n = 0;
  per[0] = 0;
  AcquireSRWLockShared(&g_lock);
  for (int s = 0; s < hap::kSrcCount; ++s) {
    if (!g_st.adds[s]) continue;
    n += wsprintfA(per + n, " %s=%d(L%d/R%d,peak%d%%)", hap::src_name(s), (int)g_st.adds[s], (int)g_mix.starts[0][s], (int)g_mix.starts[1][s],
                   (int)(g_mix.peak[0][s] > g_mix.peak[1][s] ? g_mix.peak[0][s] * 100.0 : g_mix.peak[1][s] * 100.0));
    if (n > 380) break;
  }
  ReleaseSRWLockShared(&g_lock);
  int input = vr_capi_input_available();
  if (input == 0) InterlockedIncrement(&g_st.inputOff);
  log_line("HAPTIC frame=%d on=%d strength=%d%% period=%dms timer=%d ticks=%d pulses(L/R)=%d/%d lastUs=%d/%d maxUs=%d/%d notReady=%d noDevice=%d silent=%d "
           "maxGap=%d.%dms gapOver20ms=%d inputAvailable=%d(offSeen=%d) tests=%d sources:%s",
           (int)frame, (int)g_ctl.padEnabled, (int)g_ctl.hapticPct, (int)g_ctl.hapticPeriodMs, (int)g_st.timerKind, (int)g_st.ticks,
           (int)g_st.pulses[0], (int)g_st.pulses[1], (int)g_st.lastUs[0], (int)g_st.lastUs[1], (int)g_st.maxUs[0], (int)g_st.maxUs[1],
           (int)g_st.notReady, (int)g_st.noDevice, (int)g_st.silent, (int)(g_st.maxGapX10 / 10), (int)(g_st.maxGapX10 % 10),
           (int)g_st.gapOver20, input, (int)g_st.inputOff, (int)g_st.scriptRuns, per);
}

#endif
