// Pure head-tracking math (no Windows dependency). Unit-tested in
// tests/test_headtrack.cpp. See headtrack.cpp for the conversion notes.
#pragma once
#include "vmath.h"

inline int make_yaw_reference(const float* H, float* Y) {
  // forward = H * (0,0,-1) = -(third column)
  double fx = -H[2], fz = -H[8];
  double n = vm::dsqrt(fx * fx + fz * fz);
  if (n < 0.2) return 0;  // looking almost straight up/down: keep previous reference
  fx /= n; fz /= n;
  // rotation about +Y by t maps (0,0,-1) to (-sin t, 0, -cos t)
  double s = -fx, c = -fz;
  Y[0] = (float)c;  Y[1] = 0; Y[2] = (float)s;
  Y[3] = 0;         Y[4] = 1; Y[5] = 0;
  Y[6] = (float)-s; Y[7] = 0; Y[8] = (float)c;
  return 1;
}

inline void gbvr_head_to_engine(const float* H, const float* Yref, float* L, float* yawDeg, float* pitchDeg,
                                    float* rollDeg) {
  float Yt[9], D[9];
  vm::transpose(Yref, Yt);
  vm::mul(Yt, H, D);
  vm::orthonormalize(D);
  // S*D*S flips the sign of elements that mix z with x or y.
  for (int i = 0; i < 9; ++i) L[i] = D[i];
  L[2] = -D[2]; L[5] = -D[5]; L[6] = -D[6]; L[7] = -D[7];
  // Angles for logging (OpenVR convention: yaw left +, pitch up +, roll left +)
  double fx = -D[2], fy = -D[5], fz = -D[8];
  *yawDeg = (float)(vm::datan2(-fx, -fz) * 180.0 / vm::kPi);
  *pitchDeg = (float)(vm::dasin(fy) * 180.0 / vm::kPi);
  *rollDeg = (float)(vm::datan2(D[3], D[4]) * 180.0 / vm::kPi);
}

// 0.21: 3x3 rotation part of an OpenVR 3x4 pose (row-major, 4 floats per row).
inline void pose34_rotation(const float* p, float* H) {
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 3; ++c) H[r * 3 + c] = p[r * 4 + c];
}

// 0.21: head position relative to the recenter point, in the engine's
// camera-local axes (x right, y up, z forward), metres.
//   d = Yref^T * (p - pRef)  is the offset in the recentered OpenVR frame
//   (x right, y up, -z forward); flipping z gives the engine frame.
inline void gbvr_head_pos_to_engine(const float* pose34, const float* Yref, const float* refPos, float* out) {
  double d[3] = {(double)pose34[3] - refPos[0], (double)pose34[7] - refPos[1], (double)pose34[11] - refPos[2]};
  out[0] = (float)(Yref[0] * d[0] + Yref[3] * d[1] + Yref[6] * d[2]);
  out[1] = (float)(Yref[1] * d[0] + Yref[4] * d[1] + Yref[7] * d[2]);
  out[2] = (float)-(Yref[2] * d[0] + Yref[5] * d[1] + Yref[8] * d[2]);
}
