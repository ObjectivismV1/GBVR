// 0.17 head tracking: the render thread turns the HMD pose into an engine
// camera-local rotation and publishes a locked snapshot for the camera
// thread. The camera hook never calls the VR runtime.
//
// Conversion (all row-major 3x3):
//   H    = HMD rotation in OpenVR standing space (right-handed, +Y up, -Z fwd)
//   Y    = yaw-only rotation captured at recenter (F9); pitch/roll stay
//          absolute so the horizon follows the real headset
//   D    = Y^T * H                 head rotation relative to recenter
//   L    = S * D * S, S=diag(1,1,-1)   same rotation in the engine's
//          left-handed camera-local frame (x right, y up, z forward)
//   M'   = M * L                   applied to the engine basis
// Check: a pure head yaw of +t (turning left in OpenVR) gives
// L = [[c,0,-s],[0,1,0],[s,0,c]], identical to 0.16's F7 (+t) edit.
//
// 0.21: the snapshot also carries the head position relative to the recenter
// point (same frame as L) and the raw OpenVR pose, which is handed back to
// the compositor together with the picture rendered for it.
#include "gbvr.h"
#include "vmath.h"
#include "headmath.h"
#include "stereomath.h"

static SRWLOCK g_snapLock = SRWLOCK_INIT;
static GbvrPose g_snap;
static int g_haveSnap;
static float g_refYaw[9];
static float g_refPos[3];
static float g_refBaseY;   // 1.7.19: the recenter height before the seat offset
static int g_haveRef;
static uint32_t g_seq;

// 1.5 head-follow turning: A = the yaw (radians, + = right) the game's heading has been turned FOR the player by the probe (follow.h / followmath.h).
// The headset rotation is turned back by A, so the picture does not turn twice; hands and head position are turned the same way.
static volatile LONG64 g_followABits;
static double follow_a() {
  union { LONG64 i; double d; } u;
  u.i = InterlockedCompareExchange64(&g_followABits, 0, 0);
  return u.d;
}
static void follow_a_set(double a) {
  while (a > vm::kPi) a -= 2.0 * vm::kPi;
  while (a < -vm::kPi) a += 2.0 * vm::kPi;
  union { LONG64 i; double d; } u;
  u.d = a;
  InterlockedExchange64(&g_followABits, u.i);
}
static void follow_apply(float* L, float* pos) {
  const double a = follow_a();
  if (a == 0.0) return;
  float lev[9];
  stereo::level_basis(-a, lev);
  if (L) vm::mul(lev, L, L);
  if (pos) {
    const float p0 = pos[0], p1 = pos[1], p2 = pos[2];
    for (int r = 0; r < 3; ++r) pos[r] = lev[r * 3] * p0 + lev[r * 3 + 1] * p1 + lev[r * 3 + 2] * p2;
  }
}

extern "C" int vr_publish_pose(const float* pose34, int recenter) {
  float H[9];
  int ok = 0;
  if (pose34) {
    pose34_rotation(pose34, H);
    ok = vm::is_rotation(H, 5e-3);
  }
  GbvrPose p;
  ZeroMemory(&p, sizeof(p));
  p.qpc = qpc_now();
  if (ok && (recenter || !g_haveRef)) {
    float Y[9];
    if (make_yaw_reference(H, Y)) {
      for (int i = 0; i < 9; ++i) g_refYaw[i] = Y[i];
      g_refPos[0] = pose34[3]; g_refPos[1] = pose34[7]; g_refPos[2] = pose34[11];
      g_refBaseY = pose34[7];
      g_haveRef = 1;
      if (follow_a() != 0.0) log_line("HEADTRACK recentered: the turn the body made after your head (%.1f deg) is dropped, straight ahead is the body's front", follow_a() * 180.0 / vm::kPi);
      follow_a_set(0.0);
      log_line("HEADTRACK recentered frame=%d", (int)g_ctl.worldFrames);
    } else if (!g_haveRef) {
      ok = 0;
    }
  }
  if (g_haveRef) g_refPos[1] = g_refBaseY - (g_ctl.seated ? 0.01f * (float)g_ctl.seatCm : 0.0f);   // 1.7.19: seated: seat_cm above 0 raises the eye (the reference moves down), below 0 lowers it. Head and controllers share this reference
  if (ok) {
    gbvr_head_to_engine(H, g_refYaw, p.m, &p.yawDeg, &p.pitchDeg, &p.rollDeg);
    gbvr_head_pos_to_engine(pose34, g_refYaw, g_refPos, p.pos);
    follow_apply(p.m, p.pos);   // 1.5
    for (int i = 0; i < 12; ++i) p.raw34[i] = pose34[i];
    p.valid = vm::is_rotation(p.m) && vm::is_finite_f(p.pos[0]) && vm::is_finite_f(p.pos[1]) && vm::is_finite_f(p.pos[2]);
  } else {
    vm::identity(p.m);
    p.valid = 0;
  }
  AcquireSRWLockExclusive(&g_snapLock);
  p.seq = ++g_seq;
  g_snap = p;
  g_haveSnap = 1;
  ReleaseSRWLockExclusive(&g_snapLock);
  return p.valid;
}

// 0.33: a controller pose in the same engine-local frame as the head (rotation
// L: columns right / up / forward; position relative to the recenter point).
// Returns 0 until the first headset pose has set the reference.
extern "C" int vr_pose_to_engine_local(const float* pose34, float* L9, float* pos3) {
  if (!g_haveRef || !pose34) return 0;
  float H[9];
  pose34_rotation(pose34, H);
  if (!vm::is_rotation(H, 5e-3)) return 0;
  float yaw, pitch, roll;
  gbvr_head_to_engine(H, g_refYaw, L9, &yaw, &pitch, &roll);
  gbvr_head_pos_to_engine(pose34, g_refYaw, g_refPos, pos3);
  follow_apply(L9, pos3);   // 1.5
  return vm::is_rotation(L9) && vm::is_finite_f(pos3[0]) && vm::is_finite_f(pos3[1]) && vm::is_finite_f(pos3[2]);
}

extern "C" int vr_sample_on_render_thread(int recenter) {
  float pose[12];
  int tr = 0;
  return vr_publish_pose(vr_capi_hmd_pose(pose, &tr) ? pose : nullptr, recenter);
}

extern "C" int vr_read_snapshot(GbvrPose* out) {
  AcquireSRWLockShared(&g_snapLock);
  int have = g_haveSnap;
  if (have) *out = g_snap;
  ReleaseSRWLockShared(&g_snapLock);
  if (!have) ZeroMemory(out, sizeof(*out));
  return have;
}

// 1.5: add d (radians) to A and rebuild the newest snapshot from its raw pose, so the very next read already has it.
extern "C" void vr_follow_add(double d) {
  if (d == 0.0 || !(d == d)) return;
  follow_a_set(follow_a() + d);
  AcquireSRWLockExclusive(&g_snapLock);
  if (g_haveSnap && g_snap.valid && g_haveRef) {
    float H[9];
    pose34_rotation(g_snap.raw34, H);
    float yaw, pitch, roll;
    gbvr_head_to_engine(H, g_refYaw, g_snap.m, &yaw, &pitch, &roll);
    gbvr_head_pos_to_engine(g_snap.raw34, g_refYaw, g_refPos, g_snap.pos);
    follow_apply(g_snap.m, g_snap.pos);
    g_snap.yawDeg = yaw; g_snap.pitchDeg = pitch; g_snap.rollDeg = roll;
  }
  ReleaseSRWLockExclusive(&g_snapLock);
}
extern "C" double vr_follow_total(void) { return follow_a(); }

extern "C" void vr_invalidate_snapshot(void) {
  AcquireSRWLockExclusive(&g_snapLock);
  g_snap.valid = 0;
  g_haveRef = 0;
  follow_a_set(0.0);
  ReleaseSRWLockExclusive(&g_snapLock);
}
