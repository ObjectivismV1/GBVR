#pragma once
#include <stdint.h>
#include "vmath.h"

namespace healthpos {
// Smooth only the world anchor. The headset's current view is applied after
// this, so looking around never adds lag to the health marker.
inline void step(float anchor[3], int64_t* lastQ, const float target[3],
                 int64_t now, int64_t freq, float out[3]) {
  const double dx = (double)target[0] - anchor[0], dy = (double)target[1] - anchor[1], dz = (double)target[2] - anchor[2];
  const double gap = vm::dsqrt(dx * dx + dy * dy + dz * dz);
  const double dt = *lastQ && freq > 0 ? (double)(now - *lastQ) / (double)freq : 1.0;
  if (!*lastQ || dt <= 0.0 || dt > 0.30 || gap > 8.0) {
    for (int i = 0; i < 3; ++i) anchor[i] = target[i];
  } else {
    const double alpha = dt / (0.07 + dt);
    for (int i = 0; i < 3; ++i) anchor[i] += (float)(((double)target[i] - anchor[i]) * alpha);
    // Never let a fast ghost leave its marker noticeably behind.
    const double ex = (double)target[0] - anchor[0], ey = (double)target[1] - anchor[1], ez = (double)target[2] - anchor[2];
    const double lag = vm::dsqrt(ex * ex + ey * ey + ez * ez);
    if (lag > 0.6) for (int i = 0; i < 3; ++i) anchor[i] = target[i] + (float)(((double)anchor[i] - target[i]) * (0.6 / lag));
  }
  *lastQ = now;
  for (int i = 0; i < 3; ++i) out[i] = anchor[i];
}
// 1.7.163 "follow well": a velocity-tracking smoother (alpha-beta). The marker predicts where a moving ghost is going, so it rides ON the ghost at
// any speed instead of trailing behind (the 70 ms smoother above trailed a ghost flying 20 ft/s by over a foot, then snapped at the 0.6 cap), while the
// small shakes of the game's positions are still smoothed. Same snaps as above (first sight, a pause over 0.3 s, a jump over 8 units); vel is reset with them.
inline void step_v(float anchor[3], float vel[3], int64_t* lastQ, const float target[3], int64_t now, int64_t freq, float out[3]) {
  const double dx = (double)target[0] - anchor[0], dy = (double)target[1] - anchor[1], dz = (double)target[2] - anchor[2];
  const double gap = vm::dsqrt(dx * dx + dy * dy + dz * dz);
  const double dt = *lastQ && freq > 0 ? (double)(now - *lastQ) / (double)freq : 1.0;
  const int finite = target[0] == target[0] && target[1] == target[1] && target[2] == target[2];
  if (!finite) { *lastQ = now; for (int i = 0; i < 3; ++i) out[i] = anchor[i]; return; }
  if (!*lastQ || dt <= 0.0 || dt > 0.30 || gap > 8.0 || !(vel[0] == vel[0] && vel[1] == vel[1] && vel[2] == vel[2])) {
    for (int i = 0; i < 3; ++i) { anchor[i] = target[i]; vel[i] = 0.0f; }
  } else {
    const double a = dt / (0.040 + dt), b = a * a / (2.0 - a);
    double sp = 0.0;
    for (int i = 0; i < 3; ++i) {
      const double pred = (double)anchor[i] + (double)vel[i] * dt;
      const double r = (double)target[i] - pred;
      anchor[i] = (float)(pred + a * r);
      vel[i] = (float)((double)vel[i] + b * r / dt);
      sp += (double)vel[i] * vel[i];
    }
    sp = vm::dsqrt(sp);
    if (sp > 80.0) for (int i = 0; i < 3; ++i) vel[i] = (float)((double)vel[i] * 80.0 / sp);   // no ghost is faster: a burst of noise never flings the marker
    const double ex = (double)target[0] - anchor[0], ey = (double)target[1] - anchor[1], ez = (double)target[2] - anchor[2];
    const double lag = vm::dsqrt(ex * ex + ey * ey + ez * ez);
    if (lag > 0.6) for (int i = 0; i < 3; ++i) anchor[i] = target[i] + (float)(((double)anchor[i] - target[i]) * (0.6 / lag));
  }
  *lastQ = now;
  for (int i = 0; i < 3; ++i) out[i] = anchor[i];
}
}
