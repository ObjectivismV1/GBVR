// 1.7.28 the hand-held game menu: pure math (tests/test_held.cpp).
//
// The game's own pause menu is the menu. While it is up (the game is paused, the picture is the flat 2D screen) the panel is not 2.8 m away
// any more: it hovers above the hand that does not hold the gun, turned to face the eyes, a little above and toward you so it can be read like a
// tablet. The world behind it stays frozen (the last 3D picture).
//
// Coordinates are OpenVR standing space; a pose is a row-major 3x4: columns = right, up, back, last column = position.
#pragma once
#include "vmath.h"

namespace held {

// Panel placement. The panel's own axes: +x right, +y up, +z toward the viewer (same convention as vmenu::place_in_front). Its middle is `upM` above the hand and `towardM`
// toward the head (sideways in the floor plane), and it faces the eyes exactly. Returns 0 when no sensible panel exists (hand and head on top of each other, or the panel straight
// above/below the eyes).
inline int place_panel(const float* hand34, const float* head34, double upM, double towardM, float* xf) {
  const double hx = (double)hand34[3], hy = (double)hand34[7], hz = (double)hand34[11];
  const double ex = (double)head34[3], ey = (double)head34[7], ez = (double)head34[11];
  double dx = ex - hx, dz = ez - hz;
  const double l2 = dx * dx + dz * dz;
  double cx = hx, cz = hz;
  if (l2 > 1e-6) { const double inv = towardM / vm::dsqrt(l2); cx += dx * inv; cz += dz * inv; }
  const double cy = hy + upM;
  double nx = ex - cx, ny = ey - cy, nz = ez - cz;
  const double nl = vm::dsqrt(nx * nx + ny * ny + nz * nz);
  if (!(nl > 0.08)) return 0;
  nx /= nl; ny /= nl; nz /= nl;
  const double rl = vm::dsqrt(nx * nx + nz * nz);   // right = up x normal
  if (!(rl > 0.05)) return 0;
  const double rx = nz / rl, rz = -nx / rl;
  const double ux = ny * rz, uy = nz * rx - nx * rz, uz = -ny * rx;   // up = normal x right
  xf[0] = (float)rx; xf[1] = (float)ux; xf[2] = (float)nx; xf[3] = (float)cx;
  xf[4] = 0.0f;      xf[5] = (float)uy; xf[6] = (float)ny; xf[7] = (float)cy;
  xf[8] = (float)rz; xf[9] = (float)uz; xf[10] = (float)nz; xf[11] = (float)cz;
  return 1;
}

// 1.7.31 keep the panel away from the eyes. The open gesture puts the left hand beside the head, and a panel that hangs 15 cm above that hand is then 20-30 cm from the face: each eye sees
// it from a very different side, so it looks a different size in each eye, and it is hard to read. The middle of the panel is pushed straight out along the line from the head to the panel
// until it is `minM` away (the panel faces the head, so its direction does not change). `minM` is given for a 36 cm wide panel; a wider panel keeps the same angular size (the distance
// grows with the width). minCm <= 0 = off. Returns 1 when it pushed. xf is a 3x4 panel pose (position in the last column), head34 the headset pose.
inline int keep_away(const float* head34, double widthM, float* xf, double minCm) {
  if (!(minCm > 0.0) || !(widthM > 0.01)) return 0;
  const double minM = minCm * 0.01 * (widthM / 0.36);
  const double dx = (double)xf[3] - (double)head34[3], dy = (double)xf[7] - (double)head34[7], dz = (double)xf[11] - (double)head34[11];
  const double d = vm::dsqrt(dx * dx + dy * dy + dz * dz);
  if (!(d > 0.05) || d >= minM) return 0;
  const double k = minM / d;
  xf[3] = (float)((double)head34[3] + dx * k); xf[7] = (float)((double)head34[7] + dy * k); xf[11] = (float)((double)head34[11] + dz * k);
  return 1;
}

// Smoothing of the hand position (the panel must not shake with the hand). A jump of more than 0.6 m (tracking came back) is taken at once.
struct Smooth { double p[3]; int has; };
inline void smooth_reset(Smooth* s) { s->has = 0; s->p[0] = s->p[1] = s->p[2] = 0.0; }
inline void smooth_step(Smooth* s, const double* target, double dt, double tau, double* out) {
  if (!(dt > 0.0)) dt = 0.0;
  if (dt > 0.25) dt = 0.25;
  double d2 = 0.0;
  if (s->has) { for (int i = 0; i < 3; ++i) { const double d = target[i] - s->p[i]; d2 += d * d; } }
  if (!s->has || d2 > 0.36) { for (int i = 0; i < 3; ++i) s->p[i] = target[i]; s->has = 1; }
  else { const double a = dt / (tau + dt); for (int i = 0; i < 3; ++i) s->p[i] += (target[i] - s->p[i]) * a; }
  for (int i = 0; i < 3; ++i) out[i] = s->p[i];
}

// Which hand holds the panel: the logical LEFT hand (vr_capi_hand(0)). In left-handed play the controllers are swapped at the controller layer, so the logical left hand is always the one that
// does not hold the gun.
static const int kHoldingHand = 0;

// Is the hand-held menu up? Every condition must be true: the setting, the headset view, the flat 2D screen (the game draws no 3D picture) and the player asked for the menu a moment ago
// (the game also shows flat screens by itself - loading, SteamVR taking focus - and those are not menus the player wants to hold).
// 1.7.29: no "game paused" flag any more. The 1.7.28 run showed the game's pause menu does not set it (appPaused stayed 0), so the hand-held menu never came up.
inline int is_active(int setting, int headsetView, int flatScreen, int requestedRecently) {
  return setting && headsetView && flatScreen && requestedRecently;
}
// the request counts for this long: the game must show its flat menu within it (Start tap -> 3 black frames -> flat mode takes well under a second)
static const unsigned kRequestWindowMs = 6000;
inline int request_recent(unsigned nowMs, unsigned reqMs) { return reqMs != 0 && (int)(nowMs - reqMs) >= 0 && (nowMs - reqMs) < kRequestWindowMs; }

// The pointing hand's ray against the panel. hand34: the controller's 3x4 pose (it points along -z), xf: the panel's 3x4 (columns right, up, toward the viewer, then the middle), wM x hM metres.
// u, v in 0..1 of the panel, v counted from the TOP. A ray that lands up to `margin` (a fraction of the size) outside the edge still counts and is put on the edge, so the pointer does not
// blink out at the border. t = the distance along the ray.
inline int ray_hit(const float* hand34, const float* xf, double wM, double hM, double margin, double* u, double* v, double* tOut) {
  if (!(wM > 0.01) || !(hM > 0.01)) return 0;
  const double ox = (double)hand34[3], oy = (double)hand34[7], oz = (double)hand34[11];
  const double dx = -(double)hand34[2], dy = -(double)hand34[6], dz = -(double)hand34[10];
  const double nx = (double)xf[2], ny = (double)xf[6], nz = (double)xf[10];
  const double den = dx * nx + dy * ny + dz * nz;
  if (den > -1e-4 && den < 1e-4) return 0;
  const double t = (((double)xf[3] - ox) * nx + ((double)xf[7] - oy) * ny + ((double)xf[11] - oz) * nz) / den;
  if (!(t > 0.03) || t > 3.0) return 0;
  const double rx = ox + dx * t - (double)xf[3], ry = oy + dy * t - (double)xf[7], rz = oz + dz * t - (double)xf[11];
  double uu = (rx * (double)xf[0] + ry * (double)xf[4] + rz * (double)xf[8]) / wM + 0.5;
  double vv = (rx * (double)xf[1] + ry * (double)xf[5] + rz * (double)xf[9]) / hM + 0.5;
  if (uu < -margin || uu > 1.0 + margin || vv < -margin || vv > 1.0 + margin) return 0;
  if (uu < 0.0) uu = 0.0; if (uu > 1.0) uu = 1.0;
  if (vv < 0.0) vv = 0.0; if (vv > 1.0) vv = 1.0;
  *u = uu; *v = 1.0 - vv;
  if (tOut) *tOut = t;
  return 1;
}

// The right stick scrolls lists: notches per second at a full push, with a dead zone; the fraction is kept between calls. Returns whole notches (+ up) to send now.
inline int scroll_notches(double* acc, double stick, double dt) {
  const double dead = 0.35;
  double s = stick;
  if (s > -dead && s < dead) { *acc = 0.0; return 0; }
  s = s > 0 ? (s - dead) / (1.0 - dead) : (s + dead) / (1.0 - dead);
  if (dt > 0.1) dt = 0.1;
  *acc += s * 7.0 * dt;
  int n = 0;
  while (*acc >= 1.0) { *acc -= 1.0; ++n; }
  while (*acc <= -1.0) { *acc += 1.0; --n; }
  return n;
}

// The "VR settings" button painted onto the bottom of the game's menu picture. u, v in 0..1 of the picture, v from the top.
struct Rect01 { double u0, v0, u1, v1; };
inline Rect01 banner_rect() { Rect01 r = {0.28, 0.925, 0.72, 0.992}; return r; }
inline int banner_hit(double u, double v) { const Rect01 r = banner_rect(); return u >= r.u0 && u <= r.u1 && v >= r.v0 && v <= r.v1; }
// Pixel box of the button in a picture of w x h (right/bottom exclusive).
inline void banner_box(int w, int h, int* x0, int* y0, int* x1, int* y1) {
  const Rect01 r = banner_rect();
  *x0 = (int)(r.u0 * (double)w + 0.5); *x1 = (int)(r.u1 * (double)w + 0.5);
  *y0 = (int)(r.v0 * (double)h + 0.5); *y1 = (int)(r.v1 * (double)h + 0.5);
  if (*x1 > w) *x1 = w;
  if (*y1 > h) *y1 = h;
}

// 1.7.84: the menu gesture opens the VR pages over the LIVE world (the game is only frozen: the 3D world stays drawn all around, both eyes as always) when the setting is on, the headset
// view runs in 3D and the game runs. Otherwise (a flat screen is up already, the game is paused / loading) the game's own pause menu is used as before.
inline int live_wanted(int setting, int stereoOn, int flatScreen, int gameRunning) { return (setting && stereoOn && !flatScreen && gameRunning) ? 1 : 0; }

}  // namespace held
