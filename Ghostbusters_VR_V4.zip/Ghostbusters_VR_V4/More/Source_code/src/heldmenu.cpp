// 1.7.28 the hand-held game menu (1.7.29: comes up for real, own smooth pointer in the other hand).
//
// The game's own pause menu is THE menu now. The player asks for it (left hand beside the head + left grip, or F12): the probe presses Start once, the
// game pauses and draws its menu (no 3D picture, so the headset shows the flat 2D screen). While that lasts this module
//   - hangs the flat screen on the left hand (the hand that does not hold the gun) like the screen of a hand-held PKE meter: a bit above the hand, tilted to face the
//     eyes, about 36 cm wide (stereo.cpp asks held_menu_place every flat frame; heldmath.h has the geometry),
//   - 1.7.29: the right hand is the pointer. A ray from the controller meets the panel, the point is filtered (the same smoothing the VR settings pages use: it stays put when the
//     hand trembles, glides when it moves, and is held still while the trigger is squeezed), a ring follows it and the game gets the mouse moves and clicks. The right stick
//     scrolls lists, A (bottom button) closes the menu. SteamVR's own laser on the flat screen is switched off meanwhile (it reached the game only 8 times in the 1.7.28 run),
//   - keeps the last 3D picture behind it, so the world stands still around you instead of a black void (stereo.cpp: submit_frozen),
//   - plays the song and mutes the game's own sound (audio.cpp, the only thing kept from the old floating menu),
//   - paints a "VR SETTINGS" button onto the bottom of the game's menu picture. Pointing at it and pulling the trigger opens the probe's settings pages
//     (vrmenu.cpp) in the same hand, in place of the game's picture; "< Game menu" there goes back.
// The same left-hand gesture (or F12, or B) closes it again: the probe presses Start once more.
// 1.7.29 why 1.7.28 never came up: it waited for the game's "paused" flag, and the pause menu does not set it. Now the flat screen after a recent request is enough.
// Nothing here is drawn into the headset's 3D pictures; the button and the ring are painted into the flat screen's own texture only (the PC window's copy is the game's back buffer
// and is not touched). If anything is missing (no hand pose, the texture format is unknown) the flat screen simply stays where it was before 1.7.28.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include <d3d11.h>
#include "vr_pose.h"
#include "padmath.h"
#include "vmenumath.h"
#include "heldmath.h"
#include "hapticmath.h"

namespace {

const double kUpM = 0.15, kTowardM = 0.08, kTau = 0.07;     // the game's panel: middle 15 cm above the hand, 8 cm toward the head, hand smoothing 70 ms
const double kVrUpM = 0.19, kVrWidthM = 0.64;               // the VR settings pages (a 1.6:1 picture) hang a little higher and wider

struct Held {
  int active, hover, pressInside, bannerOn;
  int live; DWORD liveSince; int liveBWas, liveFlat; long liveOpens, liveCloses, liveToGame, liveABtn;   // 1.7.84: the pages in the hand over the live world
  DWORD since, lastKeepLog, reqMs;
  int noFlat;                         // consecutive ticks without the flat screen while the menu was up (hysteresis)
  held::Smooth sm;
  int64_t stepQ;                      // when the smoother last stepped
  double pos[3]; int havePos;         // smoothed hand position (this frame's answer)
  int handLost;
  // the panel as placed this frame (held_menu_frame) and the own pointer
  float xf[12]; double widthM, heightM; int placeOk;
  vmenu::Pointer ptr; int ptrOn; int64_t ptrQ; int trigArmed, trigDown, bWas; double scrollAcc; double lastU, lastV;
  int waitLogged, laserOff;
  long ticks, activeTicks, opens, closes, requests, vrOpens, banners, bannerFails, clicks, hovers, placed, noHand, swallowed;
  long ptrFrames, ptrOff, ptrNoHand, ptrClicks, scrolls, bCloses, ptrStarts, requestsNoFlat;
  long lastLogOpenFrame;
  double maxHandStep, maxWanderPx; double jitterSum; long jitterN;
  // 1.7.31 timing and geometry: how often the flat screen runs while the menu is up, what one flat frame costs, where the panel is relative to the eyes
  int64_t flatQ; long flatN, flatHist[7]; double flatMaxMs, flatSumMs; long costN; double costSumMs, costMaxMs, frameSumUs, frameMaxUs;
  DWORD geomMs; long geomLogs;
} g_h;

// ---- 1.7.31 the follow loop ------------------------------------------------------------------------------------------------------------------------------------------------------
// "the menu is very laggy and slow": the panel used to be moved once per FLAT frame (the game's menu runs at its own pace, often 30-60 a second, and every frame also copies the screen,
// pumps the menu and re-submits the frozen world) and the hand was smoothed over 70 ms. An overlay stays where it was put until the next call, so the panel trailed the hand.
// Now a small thread of its own reads the hand and the head about every 4 ms, places the panel (same geometry), and moves the SteamVR overlay itself; the render thread only reads the
// newest placement (a seqlock) for the pointer and for the first placement. The smoothing is 25 ms. The measured hand pose is used (no prediction, no shared smoother state).
const double kTauFollow = 0.025;
struct Mover {
  volatile LONG seq, started;               // seq odd = being written
  float xf[2][12]; double w[2]; int ok[2]; int64_t q;   // [0] the game's panel, [1] the settings pages
  held::Smooth sm; int64_t lastQ; int lost;
  volatile LONG ticks, noHand, noHead, pushes, gameMoves, vrMoves, staleReads, fromMover, fallbacks, gapOver12, gapOver25, maxGapX10, runs;
  volatile LONG gameShownMs, vrShownMs;     // last time the render thread placed the game's panel / the pages in the hand (the thread moves an overlay only while that goes on)
  volatile LONG distMm[2];                  // panel middle to the head, last tick
  volatile LONG pushedNow;
  int64_t prevTickQ;
} g_mv;

int mover_read(int kind, float* xf, double* w) {
  if (!g_ctl.heldMenuFollow || !g_mv.started) return 0;
  for (int tries = 0; tries < 8; ++tries) {
    const LONG s0 = InterlockedCompareExchange(&g_mv.seq, 0, 0);
    if (s0 & 1) continue;
    float t[12]; double tw; const int ok = g_mv.ok[kind]; const int64_t q = g_mv.q;
    for (int i = 0; i < 12; ++i) t[i] = g_mv.xf[kind][i];
    tw = g_mv.w[kind];
    if (s0 != InterlockedCompareExchange(&g_mv.seq, 0, 0)) continue;
    if (!ok || !q) return 0;
    const double age = (double)(qpc_now() - q) / (double)qpc_freq();
    if (!(age < 0.08)) { InterlockedIncrement(&g_mv.staleReads); return 0; }
    for (int i = 0; i < 12; ++i) xf[i] = t[i];
    *w = tw;
    return 1;
  }
  return 0;
}

void mover_step(int64_t now) {
  GbvrHandRaw hr; float head[12];
  if (!vr_capi_hand_measured(held::kHoldingHand, &hr)) { InterlockedIncrement(&g_mv.noHand); g_mv.lost = 1; return; }
  if (!vr_capi_hmd_pose(head, nullptr)) { InterlockedIncrement(&g_mv.noHead); return; }
  double dt = g_mv.lastQ ? (double)(now - g_mv.lastQ) / (double)qpc_freq() : 0.004;
  g_mv.lastQ = now;
  if (g_mv.lost) { held::smooth_reset(&g_mv.sm); g_mv.lost = 0; }
  const double tp[3] = {(double)hr.pose34[3], (double)hr.pose34[7], (double)hr.pose34[11]};
  double p[3];
  held::smooth_step(&g_mv.sm, tp, dt, kTauFollow, p);
  float hand[12];
  for (int i = 0; i < 12; ++i) hand[i] = hr.pose34[i];
  hand[3] = (float)p[0]; hand[7] = (float)p[1]; hand[11] = (float)p[2];
  float xf[2][12]; double w[2]; int ok[2];
  const double up[2] = {kUpM, kVrUpM};
  double cm = (double)g_ctl.heldMenuMinCm;
  if (cm > 120.0) cm = 120.0;
  double pw = (double)g_ctl.heldMenuCm; if (!(pw >= 30.0)) pw = 36.0; if (pw > 90.0) pw = 90.0;
  w[0] = pw * 0.01; w[1] = kVrWidthM;
  for (int k = 0; k < 2; ++k) {
    ok[k] = held::place_panel(hand, head, up[k], kTowardM, xf[k]);
    if (ok[k]) {
      if (held::keep_away(head, w[k], xf[k], cm) && k == 0) { InterlockedIncrement(&g_mv.pushes); g_mv.pushedNow = 1; } else if (k == 0) g_mv.pushedNow = 0;
      const double dx = (double)xf[k][3] - head[3], dy = (double)xf[k][7] - head[7], dz = (double)xf[k][11] - head[11];
      g_mv.distMm[k] = (LONG)(vm::dsqrt(dx * dx + dy * dy + dz * dz) * 1000.0);
    }
  }
  InterlockedIncrement(&g_mv.seq);
  for (int k = 0; k < 2; ++k) { for (int i = 0; i < 12; ++i) g_mv.xf[k][i] = xf[k][i]; g_mv.w[k] = w[k]; g_mv.ok[k] = ok[k]; }
  g_mv.q = now;
  InterlockedIncrement(&g_mv.seq);
  const DWORD tk = GetTickCount();
  if (vrmenu_is_open()) {
    if (ok[1] && (DWORD)(tk - (DWORD)g_mv.vrShownMs) < 300u) { vr_capi_menu_move(xf[1], (float)w[1]); InterlockedIncrement(&g_mv.vrMoves); }
  } else if (ok[0] && (DWORD)(tk - (DWORD)g_mv.gameShownMs) < 300u) {
    vr_capi_overlay_move(xf[0], (float)w[0]); InterlockedIncrement(&g_mv.gameMoves);
  }
}

DWORD WINAPI mover_thread(LPVOID) {
  HANDLE tm = CreateWaitableTimerExW(nullptr, nullptr, 0x00000002 /* CREATE_WAITABLE_TIMER_HIGH_RESOLUTION */, 0x1F0003 /* TIMER_ALL_ACCESS */);
  for (;;) {
    const int active = (g_h.active || g_h.live) && g_ctl.heldMenuFollow && g_ctl.stereoActive;
    const LONG periodMs = active ? 4 : 30;
    if (tm) {
      LARGE_INTEGER due; due.QuadPart = -(LONGLONG)periodMs * 10000;
      if (SetWaitableTimer(tm, &due, 0, nullptr, nullptr, FALSE)) WaitForSingleObject(tm, 100); else Sleep((DWORD)periodMs);
    } else Sleep((DWORD)periodMs);
    if (!active) { g_mv.lost = 1; g_mv.prevTickQ = 0; continue; }
    const int64_t now = qpc_now();
    if (g_mv.prevTickQ) {
      const double gapMs = (double)(now - g_mv.prevTickQ) * 1000.0 / (double)qpc_freq();
      const LONG g10 = (LONG)(gapMs * 10.0);
      if (g10 > g_mv.maxGapX10) g_mv.maxGapX10 = g10;
      if (gapMs > 12.0) InterlockedIncrement(&g_mv.gapOver12);
      if (gapMs > 25.0) InterlockedIncrement(&g_mv.gapOver25);
    }
    g_mv.prevTickQ = now;
    InterlockedIncrement(&g_mv.ticks);
    mover_step(now);
  }
  return 0;
}

void mover_start() {
  if (InterlockedCompareExchange(&g_mv.started, 1, 0) != 0) return;
  HANDLE t = CreateThread(nullptr, 256 * 1024, mover_thread, nullptr, 0, nullptr);
  if (t) { SetThreadPriority(t, THREAD_PRIORITY_ABOVE_NORMAL); CloseHandle(t); log_line("HELDMENU follow loop started: the panel is placed from its own thread about every 4 ms (smoothing %.0f ms, never closer than %d cm to the eyes)", kTauFollow * 1000.0, (int)g_ctl.heldMenuMinCm); }
  else { g_mv.started = 0; log_line("HELDMENU the follow loop could not start: the panel follows once per flat frame as in 1.7.30"); }
}

// the smoothed position of the support hand (logical left). Steps at most once per 2 ms so that the game's panel and the VR pages, asked in the same frame, agree.
int hand_position(double* out, float* pose34Out) {
  GbvrHandRaw hr;
  vr_capi_hand_predict_off(1);   // the measured pose, not the predicted one: the prediction adds noise to a panel you are reading
  const int ok = vr_capi_hand(held::kHoldingHand, &hr);
  vr_capi_hand_predict_off(0);
  if (!ok) { ++g_h.noHand; g_h.handLost = 1; return 0; }
  const int64_t now = qpc_now();
  const double dt = g_h.stepQ ? (double)(now - g_h.stepQ) / (double)qpc_freq() : 0.0;
  if (g_h.havePos && dt < 0.002) {   // already stepped for this frame
    out[0] = g_h.pos[0]; out[1] = g_h.pos[1]; out[2] = g_h.pos[2];
  } else {
    if (g_h.handLost) { held::smooth_reset(&g_h.sm); g_h.handLost = 0; }
    const double t[3] = {(double)hr.pose34[3], (double)hr.pose34[7], (double)hr.pose34[11]};
    double before[3] = {g_h.pos[0], g_h.pos[1], g_h.pos[2]};
    held::smooth_step(&g_h.sm, t, dt, kTau, g_h.pos);
    g_h.havePos = 1; g_h.stepQ = now;
    if (before[0] != 0.0 || before[1] != 0.0) {
      const double dx = g_h.pos[0] - before[0], dy = g_h.pos[1] - before[1], dz = g_h.pos[2] - before[2];
      const double st = vm::dsqrt(dx * dx + dy * dy + dz * dz);
      if (st > g_h.maxHandStep && st < 0.5) g_h.maxHandStep = st;
    }
    out[0] = g_h.pos[0]; out[1] = g_h.pos[1]; out[2] = g_h.pos[2];
  }
  for (int i = 0; i < 12; ++i) pose34Out[i] = hr.pose34[i];
  pose34Out[3] = (float)out[0]; pose34Out[7] = (float)out[1]; pose34Out[11] = (float)out[2];
  return 1;
}

int panel_at(int kind, double upM, double widthM, double* widthOut, float* xf) {
  if (mover_read(kind, xf, widthOut)) { InterlockedIncrement(&g_mv.fromMover); ++g_h.placed; return 1; }   // 1.7.31: the follow loop's newest placement
  if (g_ctl.heldMenuFollow) InterlockedIncrement(&g_mv.fallbacks);
  double p[3]; float hand[12], head[12];
  if (!hand_position(p, hand)) return 0;
  if (!vr_capi_hmd_pose(head, nullptr)) return 0;
  if (!held::place_panel(hand, head, upM, kTowardM, xf)) return 0;
  held::keep_away(head, widthM, xf, (double)g_ctl.heldMenuMinCm);
  *widthOut = widthM;
  ++g_h.placed;
  return 1;
}

double panel_width() {
  double cm = (double)g_ctl.heldMenuCm;
  if (!(cm >= 30.0)) cm = 36.0;
  if (cm > 90.0) cm = 90.0;
  return cm * 0.01;
}

// the pointer hand lets go of everything: a button that is down comes up where it went down, the ring goes away
void pointer_stop() {
  if (g_h.trigDown) { g_h.trigDown = 0; menu_inject(g_h.lastU, g_h.lastV, 3, 1); }
  if (g_h.ptrOn) { g_h.ptrOn = 0; menu_pointer_clear(); }
  g_h.scrollAcc = 0.0;
}

// The right hand's ray, filtered, to the game's mouse (every flat frame, after the panel was placed).
void pointer_step(double aspect) {
  GbvrHandRaw hr;
  vr_capi_hand_predict_off(1);   // the measured pose, not the predicted one (the prediction's velocity noise is jitter at a pointer)
  const int ok = vr_capi_hand(1, &hr);
  vr_capi_hand_predict_off(0);
  if (!ok) { ++g_h.ptrNoHand; pointer_stop(); return; }
  const int64_t now = qpc_now();
  double dt = g_h.ptrQ ? (double)(now - g_h.ptrQ) / (double)qpc_freq() : 0.011;
  g_h.ptrQ = now;
  if (!(dt > 0.0005)) dt = 0.0005;
  if (dt > 0.25) dt = 0.25;
  // A (the bottom face button of the pointing hand) closes the menu (a press, not a hold; not in the first half second, so the press that started something else cannot close it at once)
  const int bNow = pad::vr_pressed(hr.pressed, pad::kVrA);   // the bottom face button (A); never the grip, never Menu
  if (bNow && !g_h.bWas && (GetTickCount() - g_h.since) > 500) { g_h.bWas = 1; ++g_h.bCloses; pointer_stop(); held_menu_toggle("A button"); return; }
  g_h.bWas = bNow;
  const double hM = g_h.widthM / (aspect > 0.1 ? aspect : 1.0);
  g_h.heightM = hM;
  double u = 0, v = 0, t = 0;
  if (!held::ray_hit(hr.pose34, g_h.xf, g_h.widthM, hM, 0.05, &u, &v, &t)) { ++g_h.ptrOff; pointer_stop(); return; }
  ++g_h.ptrFrames;
  const double nx = g_h.widthM * 2000.0, ny = hM * 2000.0;   // the filter works in "pixels" of half a millimetre, the size the VR settings pages were tuned on
  if (!g_h.ptrOn) { g_h.ptr.reset(); g_h.ptrOn = 1; ++g_h.ptrStarts; g_h.trigArmed = 0; }
  double ox = u * nx, oy = v * ny;
  const double trig = (double)hr.trigger;
  g_h.ptr.update(u * nx, v * ny, dt, trig, &ox, &oy);
  double su = ox / nx, sv = oy / ny;
  if (su < 0.0) su = 0.0; if (su > 1.0) su = 1.0; if (sv < 0.0) sv = 0.0; if (sv > 1.0) sv = 1.0;
  g_h.lastU = su; g_h.lastV = sv;
  menu_inject(su, sv, 1, 1);   // the move (the ring, the game's hover, the VR SETTINGS button's hover)
  if (!g_h.trigArmed && trig < 0.2) g_h.trigArmed = 1;
  if (!g_h.trigDown && g_h.trigArmed && trig > 0.6) {
    g_h.trigDown = 1; ++g_h.ptrClicks;
    haptics_add(1, hap::kSrcButton, 0.62f, 8);   // a short tick in the pointing hand (1.7.180: through the buzz-strength mixer, so Buzz strength 0 is silent)
    if (g_h.ptrClicks <= 24) log_line("HELDPOINT click #%ld at %.3f,%.3f of the panel (%.0f cm wide), %.2f m from the hand, trigger %.2f, the raw ray was %.3f,%.3f, wandered %.0f half-mm while squeezing, filtered jitter %.2f half-mm",
                                      g_h.ptrClicks, su, sv, g_h.widthM * 100.0, t, trig, u, v, g_h.ptr.lockedMovePx, g_h.ptr.jitterN ? g_h.ptr.jitterSum / (double)g_h.ptr.jitterN : 0.0);
    if (g_h.ptr.lockedMovePx > g_h.maxWanderPx) g_h.maxWanderPx = g_h.ptr.lockedMovePx;
    menu_inject(su, sv, 2, 1);
  } else if (g_h.trigDown && trig < 0.35) {
    g_h.trigDown = 0;
    menu_inject(su, sv, 3, 1);
  }
  const int n = held::scroll_notches(&g_h.scrollAcc, (double)hr.stickY, dt);
  if (n) { g_h.scrolls += n > 0 ? n : -n; menu_inject(su, sv, 5, n); }
}

// 1.7.31 HELDGEOM: where the panel is relative to the eyes and how wide each eye sees it (a panel that is much closer to one eye than the other looks bigger to that eye)
double edge_angle_deg(const double* eye, const double* c, const double* r, double w) {
  double a[3], b[3];
  for (int i = 0; i < 3; ++i) { a[i] = c[i] - 0.5 * w * r[i] - eye[i]; b[i] = c[i] + 0.5 * w * r[i] - eye[i]; }
  const double cx = a[1] * b[2] - a[2] * b[1], cy = a[2] * b[0] - a[0] * b[2], cz = a[0] * b[1] - a[1] * b[0];
  const double cr = vm::dsqrt(cx * cx + cy * cy + cz * cz), dt = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  return vm::datan2(cr, dt) * 180.0 / vm::kPi;
}
void geom_log(DWORD nowMs) {
  if (nowMs - g_h.geomMs < 1500 || g_h.geomLogs >= 80) return;
  g_h.geomMs = nowMs;
  const int kind = vrmenu_is_open() ? 1 : 0;
  float xf[12]; double w = 0.0; float head[12], hand[12];
  if (!vr_capi_hmd_pose(head, nullptr)) return;
  if (!mover_read(kind, xf, &w)) {
    if (kind || !g_h.placeOk) return;
    for (int i = 0; i < 12; ++i) xf[i] = g_h.xf[i];
    w = g_h.widthM;
  }
  ++g_h.geomLogs;
  const double c[3] = {(double)xf[3], (double)xf[7], (double)xf[11]}, r[3] = {(double)xf[0], (double)xf[4], (double)xf[8]};
  const double hr3[3] = {(double)head[0], (double)head[4], (double)head[8]};   // the head's right
  const double h[3] = {(double)head[3], (double)head[7], (double)head[11]};
  const double eyeL[3] = {h[0] - 0.032 * hr3[0], h[1] - 0.032 * hr3[1], h[2] - 0.032 * hr3[2]}, eyeR[3] = {h[0] + 0.032 * hr3[0], h[1] + 0.032 * hr3[1], h[2] + 0.032 * hr3[2]};
  const double dH = vm::dsqrt((c[0] - h[0]) * (c[0] - h[0]) + (c[1] - h[1]) * (c[1] - h[1]) + (c[2] - h[2]) * (c[2] - h[2]));
  const double dL = vm::dsqrt((c[0] - eyeL[0]) * (c[0] - eyeL[0]) + (c[1] - eyeL[1]) * (c[1] - eyeL[1]) + (c[2] - eyeL[2]) * (c[2] - eyeL[2]));
  const double dR = vm::dsqrt((c[0] - eyeR[0]) * (c[0] - eyeR[0]) + (c[1] - eyeR[1]) * (c[1] - eyeR[1]) + (c[2] - eyeR[2]) * (c[2] - eyeR[2]));
  const double aL = edge_angle_deg(eyeL, c, r, w), aR = edge_angle_deg(eyeR, c, r, w);
  double handCm = -1.0;
  { GbvrHandRaw hr; if (vr_capi_hand_measured(held::kHoldingHand, &hr)) { for (int i = 0; i < 12; ++i) hand[i] = hr.pose34[i]; const double dx = hand[3] - h[0], dy = hand[7] - h[1], dz = hand[11] - h[2]; handCm = 100.0 * vm::dsqrt(dx * dx + dy * dy + dz * dz); } }
  log_line("HELDGEOM #%ld %s | middle %.0f cm from the head (left eye %.0f, right eye %.0f; eyes assumed 64 mm apart), %.0f cm wide, covers %.1f deg for the left eye and %.1f deg for the right | hand %.0f cm from the head | pushed out by the closest-to-eyes rule now: %d (limit %d cm) | follow loop %d",
           g_h.geomLogs, kind ? "settings pages" : "game menu", dH * 100.0, dL * 100.0, dR * 100.0, w * 100.0, aL, aR, handCm, (int)g_mv.pushedNow, (int)g_ctl.heldMenuMinCm, (int)g_ctl.heldMenuFollow);
}

}  // namespace

int held_menu_active() { return g_h.active; }

// Every headset frame (render thread, from vrmenu_tick). Decides whether the hand-held menu is up and does the start / end work.
void held_menu_tick(LONG frame) {
  ++g_h.ticks;
  const int flat = stereo_in_flat_mode();
  const DWORD nowMs = GetTickCount();
  const int recent = held::request_recent((unsigned)nowMs, (unsigned)g_h.reqMs);
  const int want = held::is_active(g_ctl.heldMenu != 0, g_ctl.stereoActive != 0, flat != 0, recent);
  if (g_h.live) {   // 1.7.84: the pages are in the hand over the live world
    if (g_ctl.heldMenuFollow) mover_start();
    geom_log(nowMs);
    if (flat) { if (++g_h.liveFlat > 20) { g_h.liveFlat = 0; vrmenu_close_in_hand("the game left the 3D view"); return; } } else g_h.liveFlat = 0;
    // A (the bottom face button of the pointing hand) closes the pages; not in the first half second, so the press that opened them cannot close them at once
    GbvrHandRaw hr;
    vr_capi_hand_predict_off(1);
    const int okh = vr_capi_hand(1, &hr);
    vr_capi_hand_predict_off(0);
    if (okh) {
      const int bNow = pad::vr_pressed(hr.pressed, pad::kVrA);
      if (bNow && !g_h.liveBWas && (nowMs - g_h.liveSince) > 500) { g_h.liveBWas = 1; ++g_h.liveABtn; held_menu_toggle("A button"); return; }
      g_h.liveBWas = bNow;
    }
    return;
  }
  if (!g_h.active) {
    if (want) {
      g_h.active = 1; g_h.since = nowMs; g_h.hover = g_h.pressInside = 0; g_h.noFlat = 0; g_h.waitLogged = 0;
      held::smooth_reset(&g_h.sm); g_h.havePos = 0; g_h.stepQ = 0; g_h.pos[0] = g_h.pos[1] = g_h.pos[2] = 0.0; g_h.handLost = 0;
      g_h.ptrOn = 0; g_h.trigDown = 0; g_h.trigArmed = 0; g_h.bWas = 1; g_h.scrollAcc = 0.0; g_h.placeOk = 0; g_h.ptrQ = 0;   // bWas 1: a B that is down now is not a close
      ++g_h.opens;
      audio_menu(1);   // the song starts, the game's own sound is muted (the only thing kept from the old floating menu)
      log_line("HELDMENU opened (#%ld): the game shows its menu %lu ms after the request (paused flag %d, game running %d); it is held on the left hand (%.0f cm wide), the right hand points; the world behind it stays frozen; song on (frame %d)",
               g_h.opens, (unsigned long)(nowMs - g_h.reqMs), game_paused_flag(), game_running_now(), panel_width() * 100.0, (int)frame);
    } else if (recent && g_ctl.heldMenu && g_ctl.stereoActive && !flat && !g_h.waitLogged && (nowMs - g_h.reqMs) > 2500) {
      g_h.waitLogged = 1; ++g_h.requestsNoFlat;
      log_line("HELDMENU the game showed no menu 2.5 s after the request (paused flag %d, game running %d): the Start tap did not open its pause menu (cutscene? a loading screen?); try again", game_paused_flag(), game_running_now());
    }
    if (g_h.laserOff) { vr_capi_flat_laser(1); g_h.laserOff = 0; }
    return;
  }
  if (g_ctl.heldMenuFollow) mover_start();
  geom_log(nowMs);
  // active: keep the player's request alive (the auto-close helper must not press Start on a menu the player is reading)
  if (g_ctl.stereoActive && flat) game_menu_keep();
  ++g_h.activeTicks;
  audio_menu(1);   // cheap; also starts the sound thread if a Sound switch was turned on meanwhile
  if (!flat) ++g_h.noFlat; else g_h.noFlat = 0;
  const int laserWant = !vrmenu_is_open();   // SteamVR's laser on the game's picture: off while the game's panel is the thing pointed at
  if (laserWant && !g_h.laserOff) { vr_capi_flat_laser(0); g_h.laserOff = 1; }
  else if (!laserWant && g_h.laserOff) { vr_capi_flat_laser(1); g_h.laserOff = 0; }
  if (!g_ctl.heldMenu || !g_ctl.stereoActive || g_h.noFlat > 8) {
    const char* why = !g_ctl.heldMenu ? "switched off" : !g_ctl.stereoActive ? "the headset view ended" : "the game runs again";
    pointer_stop();
    if (vrmenu_is_open()) vrmenu_close_in_hand(why);
    audio_menu(0);
    if (g_h.laserOff) { vr_capi_flat_laser(1); g_h.laserOff = 0; }
    g_h.active = 0; g_h.hover = g_h.pressInside = 0; g_h.placeOk = 0;
    game_menu_release();   // the request is over: a later loading screen is not a menu to hold
    ++g_h.closes;
    log_line("HELDMENU closed (#%ld): %s; was up for %lu ms, %ld VR-settings openings, %ld pointer clicks so far (frame %d)", g_h.closes, why, (unsigned long)(GetTickCount() - g_h.since), g_h.vrOpens, g_h.ptrClicks, (int)frame);
  }
}

// Once per flat frame, after the game's laser events were drained and before the screen is drawn: places the panel on the hand and runs the own pointer.
void held_menu_frame(double aspect) {
  if (!g_h.active) { g_h.placeOk = 0; g_h.flatQ = 0; return; }
  const int64_t t0 = qpc_now();
  if (g_h.flatQ) {   // 1.7.31 how often the flat screen runs while the menu is up
    const double gap = (double)(t0 - g_h.flatQ) * 1000.0 / (double)qpc_freq();
    if (gap < 2000.0) {
      ++g_h.flatN; g_h.flatSumMs += gap; if (gap > g_h.flatMaxMs) g_h.flatMaxMs = gap;
      ++g_h.flatHist[gap < 8.0 ? 0 : gap < 12.0 ? 1 : gap < 16.0 ? 2 : gap < 25.0 ? 3 : gap < 40.0 ? 4 : gap < 80.0 ? 5 : 6];
    }
  }
  g_h.flatQ = t0;
  if (vrmenu_is_open()) { pointer_stop(); g_h.placeOk = 0; return; }   // the settings pages are in the hand: they have their own pointer
  g_h.placeOk = panel_at(0, kUpM, panel_width(), &g_h.widthM, g_h.xf);
  if (g_h.placeOk) pointer_step(aspect);
  else pointer_stop();
  const double us = (double)(qpc_now() - t0) * 1e6 / (double)qpc_freq();
  g_h.frameSumUs += us; if (us > g_h.frameMaxUs) g_h.frameMaxUs = us;
}

// 1.7.31: what a whole flat frame (show_flat in stereo.cpp) cost, in ms, while the hand-held menu was up
void held_menu_note_flat_cost(double ms) {
  ++g_h.costN; g_h.costSumMs += ms; if (ms > g_h.costMaxMs) g_h.costMaxMs = ms;
}

// The flat game screen in the hand (stereo.cpp, every flat frame, after held_menu_frame). 1 = xf / widthM are the placement to use now.
int held_menu_place(float* xf, double* widthM) {
  if (!g_h.active || !g_h.placeOk) return 0;
  for (int i = 0; i < 12; ++i) xf[i] = g_h.xf[i];
  *widthM = g_h.widthM;
  g_mv.gameShownMs = (LONG)GetTickCount();   // 1.7.31: from now on the follow loop moves the overlay
  return 1;
}

// 1.7.31: 1 = the follow loop is moving this overlay (0 = the game's panel, 1 = the settings pages); the caller then leaves the placement alone, so it is not set back to an older spot every flat frame
int held_menu_mover_owns(int kind) {
  if (!g_ctl.heldMenuFollow || !g_mv.started || !(g_h.active || g_h.live)) return 0;
  const DWORD tk = GetTickCount();
  const LONG shown = kind ? g_mv.vrShownMs : g_mv.gameShownMs;
  if (!shown || (DWORD)(tk - (DWORD)shown) > 300u) return 0;
  const double age = g_mv.q ? (double)(qpc_now() - g_mv.q) / (double)qpc_freq() : 9.0;
  return g_mv.ok[kind] && age < 0.08;
}

// The probe's settings pages in the hand (vrmenu.cpp, every frame while they are open).
int held_vr_place(float* xf, double* widthM) {
  if (!(g_h.active || g_h.live)) return 0;
  const int ok = panel_at(1, kVrUpM, kVrWidthM, widthM, xf);
  if (ok) g_mv.vrShownMs = (LONG)GetTickCount();
  return ok;
}

// 1.7.84: the game's own pause menu in the hand (Start once; the request latch keeps the auto-close helper away)
static void request_game_menu(const char* why, int force = 0) {
  ++g_h.requests;
  g_h.reqMs = GetTickCount(); if (!g_h.reqMs) g_h.reqMs = 1;
  g_h.waitLogged = 0;
  log_line("HELDMENU the player asked for the game menu (%s): game running=%d, paused flag=%d%s", why, game_running_now(), game_paused_flag(), force ? " (from the live pages: the game was only frozen)" : "");
  if (force) game_menu_request_force(); else game_menu_request();   // Start once if the game runs; the request latch keeps the auto-close helper away
}

// 1.7.84: the live pages start: the hand smoothing starts fresh, the A button that may still be down is not a close
static void live_begin() {
  g_h.live = 1; g_h.liveSince = GetTickCount(); g_h.liveBWas = 1; g_h.liveFlat = 0; ++g_h.liveOpens;
  held::smooth_reset(&g_h.sm); g_h.havePos = 0; g_h.stepQ = 0; g_h.pos[0] = g_h.pos[1] = g_h.pos[2] = 0.0; g_h.handLost = 0; g_h.placeOk = 0;
}
void held_menu_live_end(const char* why) {
  if (!g_h.live) return;
  g_h.live = 0; ++g_h.liveCloses;
  log_line("HELDLIVE closed (%s): the pages were up for %lu ms (%ld openings, %ld closes by the A button, %ld trips to the game menu so far)", why, (unsigned long)(GetTickCount() - g_h.liveSince), g_h.liveOpens, g_h.liveABtn, g_h.liveToGame);
}
void held_menu_live_to_game(const char* why) {
  ++g_h.liveToGame;
  if (g_h.live) vrmenu_close_in_hand(why);   // the pages go (the world unfreezes for a moment), then the game's own pause menu opens in the hand
  request_game_menu(why, 1);
}

// The gesture / F12 / B / the pages' close button when the hand-held menu is in use: open the game's pause menu, or close it again.
void held_menu_toggle(const char* why) {
  if (!g_ctl.stereoActive) { log_line("MENU: not available now - start the headset view first (F4)"); return; }
  if (g_h.live) { vrmenu_close_in_hand(why); return; }   // 1.7.84: the live pages: closing them is all there is to do (the game was never paused, nothing is pressed)
  if (g_h.active || vrmenu_is_open()) {
    if (vrmenu_is_open()) vrmenu_close_in_hand(why);
    game_menu_close(why);
    return;
  }
  // 1.7.84: with the game running in the 3D view the pages open in the hand over the LIVE world (the game is only frozen): you see the whole world around you, both eyes drawn as always.
  // The game's own pause menu stops all 3D drawing (only a still picture of what was in front of you can stay behind it), so it is used only when the live pages cannot be (a loading screen, a cutscene)
  if (held::live_wanted((int)g_ctl.heldLive, (int)g_ctl.stereoActive, stereo_in_flat_mode(), game_running_now())) {
    live_begin();
    if (vrmenu_open_live()) { log_line("HELDLIVE opened (#%ld, %s): the VR pages are in your hand over the live 3D world; the game is frozen, not paused: look all around. 'Game menu >' opens the game's own menu", g_h.liveOpens, why); return; }
    g_h.live = 0;
    log_line("HELDLIVE the pages could not open (%s): the game's own pause menu is used", why);
  }
  request_game_menu(why);
}

// A laser event on the game's picture (menu.cpp / menu_inject): u, v in 0..1 of the picture, v from the top; type 1 move, 2 down, 3 up. 1 = the probe took it (the game does not see it).
int held_menu_pointer(double u, double v, int type, int button) {
  (void)button;
  if (!g_h.active) return 0;
  const int inside = held::banner_hit(u, v);
  if (type == 1 || type == 2) { if (inside != g_h.hover) { g_h.hover = inside; if (inside) ++g_h.hovers; } }
  if (type == 2 && inside) { g_h.pressInside = 1; ++g_h.swallowed; return 1; }
  if (type == 3 && g_h.pressInside) {
    g_h.pressInside = 0; ++g_h.swallowed;
    if (inside) {
      ++g_h.clicks;
      if (vrmenu_open_in_hand()) { ++g_h.vrOpens; log_line("HELDMENU the VR SETTINGS button was pressed (#%ld): the settings pages are in your hand now", g_h.vrOpens); }
      else log_line("HELDMENU the VR SETTINGS button was pressed but the pages could not open");
    }
    return 1;
  }
  return 0;
}

// Paints the button onto the bottom of the flat screen's texture (stereo.cpp, every flat frame while the hand-held menu is up, before the pointer ring).
void held_banner_paint(void* ctxp, void* texp, unsigned w, unsigned h, int fmt) {
  ID3D11DeviceContext* ctx = (ID3D11DeviceContext*)ctxp;
  ID3D11Texture2D* tex = (ID3D11Texture2D*)texp;
  if (!g_h.active || !ctx || !tex || w < 256 || h < 256) return;
  int rgba;
  if (fmt == 28 || fmt == 29) rgba = 1;        // R8G8B8A8 UNORM / UNORM_SRGB
  else if (fmt == 87 || fmt == 91) rgba = 0;   // B8G8R8A8 UNORM / UNORM_SRGB
  else { if (++g_h.bannerFails == 1) log_line("HELDMENU the 2D screen's texture format (%d) is not one the button can be painted into: no VR SETTINGS button (use F12 and the settings file)", fmt); return; }
  int x0, y0, x1, y1;
  held::banner_box((int)w, (int)h, &x0, &y0, &x1, &y1);
  const int bw = x1 - x0, bh = y1 - y0;
  if (bw < 64 || bh < 24) return;
  const uint8_t* img = vrmenu_banner(g_h.hover ? 1 : 0, bw, bh, rgba);
  if (!img) { if (++g_h.bannerFails == 1) log_line("HELDMENU the button picture could not be made (GDI): no VR SETTINGS button"); return; }
  D3D11_BOX box;
  box.left = (UINT)x0; box.right = (UINT)x1; box.top = (UINT)y0; box.bottom = (UINT)y1; box.front = 0; box.back = 1;
  ctx->UpdateSubresource(tex, 0, &box, img, (UINT)bw * 4u, 0);
  ++g_h.banners;
  g_h.bannerOn = 1;
}

void held_menu_report(long frame) {
  log_line("HELDLIVE frame=%ld setting=%d | live pages now=%d, opened %ld, closed %ld, closed by the A button %ld, trips to the game menu %ld (the live pages keep the 3D world drawn around you; the game is frozen, not paused)", frame, (int)g_ctl.heldLive, g_h.live, g_h.liveOpens, g_h.liveCloses, g_h.liveABtn, g_h.liveToGame);
  log_line("HELDMENU frame=%ld on=%d active=%d opens=%ld closes=%ld requests=%ld requestsWithNoMenu=%ld ticks=%ld activeTicks=%ld placed=%ld noHand=%ld banners=%ld bannerFails=%ld hovers=%ld clicks=%ld swallowed=%ld vrOpens=%ld "
           "maxHandStepMm=%.1f width=%.0fcm (1.7.29: the flat game menu after a request is held on the left hand; the world is frozen behind it; the song plays)",
           frame, (int)g_ctl.heldMenu, g_h.active, g_h.opens, g_h.closes, g_h.requests, g_h.requestsNoFlat, g_h.ticks, g_h.activeTicks, g_h.placed, g_h.noHand, g_h.banners, g_h.bannerFails, g_h.hovers, g_h.clicks,
           g_h.swallowed, g_h.vrOpens, g_h.maxHandStep * 1000.0, panel_width() * 100.0);
  log_line("HELDPOINT frame=%ld the right hand's own pointer: frames on the panel=%ld off the panel=%ld noHand=%ld starts=%ld clicks=%ld scroll notches=%ld A closes=%ld | widest wander while squeezing %.0f half-mm, filter jitter %.2f half-mm | SteamVR laser on the flat screen off now: %d",
           frame, g_h.ptrFrames, g_h.ptrOff, g_h.ptrNoHand, g_h.ptrStarts, g_h.ptrClicks, g_h.scrolls, g_h.bCloses, g_h.maxWanderPx, g_h.ptr.jitterN ? g_h.ptr.jitterSum / (double)g_h.ptr.jitterN : 0.0, g_h.laserOff);
  g_h.maxHandStep = 0.0;
  const double meanGap = g_h.flatN ? g_h.flatSumMs / (double)g_h.flatN : 0.0;
  log_line("HELDTIMING frame=%ld follow=%d | flat screen while the menu was up: %ld frames, mean gap %.1f ms (%.0f per second), longest gap %.0f ms; gaps <8/<12/<16/<25/<40/<80/more ms: %ld/%ld/%ld/%ld/%ld/%ld/%ld | whole flat frame cost mean %.1f ms, longest %.1f ms (%ld frames) | placing + pointer part mean %.0f us, longest %.0f us",
           frame, (int)g_ctl.heldMenuFollow, g_h.flatN, meanGap, meanGap > 0.0 ? 1000.0 / meanGap : 0.0, g_h.flatMaxMs, g_h.flatHist[0], g_h.flatHist[1], g_h.flatHist[2], g_h.flatHist[3], g_h.flatHist[4], g_h.flatHist[5], g_h.flatHist[6],
           g_h.costN ? g_h.costSumMs / (double)g_h.costN : 0.0, g_h.costMaxMs, g_h.costN, g_h.flatN ? g_h.frameSumUs / (double)g_h.flatN : 0.0, g_h.frameMaxUs);
  log_line("HELDFOLLOW frame=%ld on=%d started=%ld | loop ticks=%ld (gaps over 12 ms: %ld, over 25 ms: %ld, longest %.1f ms), overlay moves game/pages=%ld/%ld, no hand=%ld, no head=%ld | placements taken from the loop=%ld, computed in the render thread instead=%ld (stale loop answers %ld) | pushed out by the closest-to-eyes rule %ld times, limit %d cm | panel from the head now game/pages %ld/%ld mm",
           frame, (int)g_ctl.heldMenuFollow, (long)g_mv.started, (long)g_mv.ticks, (long)g_mv.gapOver12, (long)g_mv.gapOver25, (double)g_mv.maxGapX10 / 10.0, (long)g_mv.gameMoves, (long)g_mv.vrMoves, (long)g_mv.noHand, (long)g_mv.noHead,
           (long)g_mv.fromMover, (long)g_mv.fallbacks, (long)g_mv.staleReads, (long)g_mv.pushes, (int)g_ctl.heldMenuMinCm, (long)g_mv.distMm[0], (long)g_mv.distMm[1]);
}
// 1.7.93 MENUFLOW (the hand-held part): the numbers that say why the hand-held menu could not be seen or used. Runs in every build (the HELDMENU report above is part of the full dump only).
// Returns how much the menu has been used (0 = never), so the caller stays quiet for people who never opened it.
long held_menu_flow(char* out, int cap) {
  const long uses = g_h.requests + g_h.opens + g_h.liveOpens + g_h.ptrFrames + g_h.ptrOff + g_h.ptrNoHand + g_h.noHand;
  const char* hint = "";
  if (g_h.requests > 0 && g_h.opens == 0 && g_h.liveOpens == 0) hint = " => the game's own pause menu never came up after the gesture";
  else if (g_h.opens > 0 && g_h.placed == 0) hint = " => the menu opened but the left hand was never tracked, so it could not be hung on the hand";
  else if (g_h.opens > 0 && g_h.ptrFrames == 0 && g_h.ptrNoHand > 0) hint = " => the pointing (right) hand was never tracked";
  else if (g_h.opens > 0 && g_h.ptrFrames == 0 && g_h.ptrOff > 0) hint = " => the pointing ray never landed on the panel";
  else if (g_h.ptrFrames > 0 && g_h.ptrClicks == 0) hint = " => the ray reached the panel but no trigger click was counted";
  log_fmt(out, cap, "hand-held game menu: asked %ld, opened %ld, no menu after the ask %ld, live pages opened %ld (up now: game menu %d, pages %d) | panel placed %ld times, left hand untracked %ld | pointer: on the panel %ld frames, off it %ld, right hand untracked %ld, trigger clicks %ld, scroll notches %ld, A closes %ld | VR SETTINGS button painted %ld (failed %ld), settings opened from it %ld%s",
          g_h.requests, g_h.opens, g_h.requestsNoFlat, g_h.liveOpens, g_h.active, g_h.live, g_h.placed, g_h.noHand, g_h.ptrFrames, g_h.ptrOff, g_h.ptrNoHand, g_h.ptrClicks, g_h.scrolls, g_h.bCloses,
          g_h.banners, g_h.bannerFails, g_h.vrOpens, hint);
  return uses;
}

#endif
