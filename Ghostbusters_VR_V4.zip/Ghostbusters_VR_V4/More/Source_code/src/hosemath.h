#pragma once
// 1.7.148 the game's OWN proton hose follows the drawn gun.
//
// The hose is a skinned model instance of its own (actor+0xD7B0, the same model class as the body at actor+0x430: skeleton at +0x7930, bone count +0x2090,
// local pose +0x2AE8, model-space matrices +0x2B00). The game poses it with the body's animation (0x38E270 from the player's update), so in the game it meets
// the gun the animation holds. In VR the gun is drawn somewhere else (the controller), so the hose's gun end hung where the animation's gun is; the mod hid it
// (hose_off 1) and drew a cord of its own instead. Here the game's own hose is bent instead: the gun end of its bone chain is moved by exactly the move that
// takes the game's gun to the drawn gun, the pack end is left where the game has it, and the bones between get a smooth share of that move.
//
// Matrices are 4x4 row-major with row vectors (axes in rows 0..2, position in row 3), as everywhere in the game. Pure math, unit-tested (tests/test_hose.cpp).
#include "vmath.h"

namespace hose {

static const int kMaxBones = 200;

// the longest root-to-leaf path of a skeleton (-1 = root). Parents may come in any order; a loop or a parent out of range makes it unusable.
// chain[0] = the first bone of that path, chain[len-1] = its leaf. Returns the length (0 = not a usable skeleton).
inline int longest_chain(const int* parent, int n, int* chain, int maxc) {
  if (!parent || !chain || n <= 0 || n > kMaxBones || maxc <= 0) return 0;
  int depth[kMaxBones];
  for (int i = 0; i < n; ++i) {
    int d = 1, b = parent[i], steps = 0;
    while (b >= 0) {
      if (b >= n || ++steps > n) return 0;   // out of range or a loop
      ++d; b = parent[b];
    }
    if (b < -1) return 0;
    depth[i] = d;
  }
  int best = 0;
  for (int i = 1; i < n; ++i) if (depth[i] > depth[best]) best = i;
  const int len = depth[best];
  if (len > maxc) return 0;
  for (int k = len - 1, b = best; k >= 0; --k, b = parent[b]) chain[k] = b;
  return len;
}

inline double smooth01(double s) { if (s <= 0.0) return 0.0; if (s >= 1.0) return 1.0; return s * s * (3.0 - 2.0 * s); }

// weight of every bone: 0 at the chain's pack end, 1 at its gun end, smooth by the length along the chain; bones off the chain take the weight of their
// nearest ancestor on it (0 if none). gunAtStart = 1 when chain[0] is the gun end. Returns the chain's length (model units), 0 if degenerate.
inline double chain_weights(const float* world, const int* parent, int n, const int* chain, int cn, int gunAtStart, float* w) {
  if (!world || !parent || !chain || !w || cn < 2 || n <= 0 || n > kMaxBones) return 0.0;
  double cum[kMaxBones]; cum[0] = 0.0;
  for (int k = 1; k < cn; ++k) {
    const float* a = world + 16 * chain[k - 1]; const float* b = world + 16 * chain[k];
    const double dx = (double)b[12] - a[12], dy = (double)b[13] - a[13], dz = (double)b[14] - a[14];
    cum[k] = cum[k - 1] + vm::dsqrt(dx * dx + dy * dy + dz * dz);
  }
  const double L = cum[cn - 1];
  if (!(L > 1e-6)) return 0.0;
  int onChain[kMaxBones];
  for (int i = 0; i < n; ++i) onChain[i] = -1;
  for (int k = 0; k < cn; ++k) if (chain[k] >= 0 && chain[k] < n) onChain[chain[k]] = k;
  for (int i = 0; i < n; ++i) {
    int b = i;
    while (b >= 0 && onChain[b] < 0) b = parent[b];
    if (b < 0) { w[i] = 0.0f; continue; }
    double s = cum[onChain[b]] / L;
    if (gunAtStart) s = 1.0 - s;
    w[i] = (float)smooth01(s);
  }
  return L;
}

inline void mul44(const double* a, const double* b, double* o) {
  double t[16];
  for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) {
    double s = 0.0;
    for (int k = 0; k < 4; ++k) s += a[r * 4 + k] * b[k * 4 + c];
    t[r * 4 + c] = s;
  }
  for (int i = 0; i < 16; ++i) o[i] = t[i];
}

// inverse of an affine row-vector matrix (rows 0..2 = 3x3 part, row 3 = translation; column 3 = 0,0,0,1)
inline int inv_affine(const double* m, double* o) {
  const double a = m[0], b = m[1], c = m[2], d = m[4], e = m[5], f = m[6], g = m[8], h = m[9], i = m[10];
  const double A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
  const double det = a * A + b * B + c * C;
  if (!(vm::dabs(det) > 1e-12) || det != det) return 0;
  const double id = 1.0 / det;
  double r[9];
  r[0] = A * id; r[1] = -(b * i - c * h) * id; r[2] = (b * f - c * e) * id;
  r[3] = B * id; r[4] = (a * i - c * g) * id;  r[5] = -(a * f - c * d) * id;
  r[6] = C * id; r[7] = -(a * h - b * g) * id; r[8] = (a * e - b * d) * id;
  for (int rr = 0; rr < 3; ++rr) { for (int cc = 0; cc < 3; ++cc) o[rr * 4 + cc] = r[rr * 3 + cc]; o[rr * 4 + 3] = 0.0; }
  for (int cc = 0; cc < 3; ++cc) o[12 + cc] = -(m[12] * r[cc] + m[13] * r[3 + cc] + m[14] * r[6 + cc]);
  o[15] = 1.0;
  return 1;
}

inline void to44(const float* f, double* d) { for (int i = 0; i < 16; ++i) d[i] = f[i]; d[3] = d[7] = d[11] = 0.0; d[15] = 1.0; }

// the move, in the hose's model space, that takes the game's gun to the drawn gun: Dm = inv(gunGame x inv(hoseGame)) x (gunDraw x inv(hoseDraw)).
inline int model_move(const float* hoseGame, const float* hoseDraw, const float* gunGame, const float* gunDraw, double* Dm) {
  double HG[16], HD[16], GG[16], GD[16], iHG[16], iHD[16], Gm[16], Vm[16], iGm[16];
  to44(hoseGame, HG); to44(hoseDraw, HD); to44(gunGame, GG); to44(gunDraw, GD);
  if (!inv_affine(HG, iHG) || !inv_affine(HD, iHD)) return 0;
  mul44(GG, iHG, Gm); mul44(GD, iHD, Vm);
  if (!inv_affine(Gm, iGm)) return 0;
  mul44(iGm, Vm, Dm);
  for (int i = 0; i < 16; ++i) if (Dm[i] != Dm[i] || vm::dabs(Dm[i]) > 1e6) return 0;
  return 1;
}

// rotation (row form, rows normalised) -> quaternion (w, x, y, z) of the matching column-form rotation
inline void quat_from_rows(const double* r, double* q) {
  // column form C = transpose(rows)
  const double m00 = r[0], m01 = r[3], m02 = r[6], m10 = r[1], m11 = r[4], m12 = r[7], m20 = r[2], m21 = r[5], m22 = r[8];
  const double tr = m00 + m11 + m22;
  if (tr > 0.0) { const double s = vm::dsqrt(tr + 1.0) * 2.0; q[0] = 0.25 * s; q[1] = (m21 - m12) / s; q[2] = (m02 - m20) / s; q[3] = (m10 - m01) / s; }
  else if (m00 > m11 && m00 > m22) { const double s = vm::dsqrt(1.0 + m00 - m11 - m22) * 2.0; q[0] = (m21 - m12) / s; q[1] = 0.25 * s; q[2] = (m01 + m10) / s; q[3] = (m02 + m20) / s; }
  else if (m11 > m22) { const double s = vm::dsqrt(1.0 + m11 - m00 - m22) * 2.0; q[0] = (m02 - m20) / s; q[1] = (m01 + m10) / s; q[2] = 0.25 * s; q[3] = (m12 + m21) / s; }
  else { const double s = vm::dsqrt(1.0 + m22 - m00 - m11) * 2.0; q[0] = (m10 - m01) / s; q[1] = (m02 + m20) / s; q[2] = (m12 + m21) / s; q[3] = 0.25 * s; }
}
inline void rows_from_quat(const double* q, double* r) {
  const double w = q[0], x = q[1], y = q[2], z = q[3];
  const double c00 = 1 - 2 * (y * y + z * z), c01 = 2 * (x * y - z * w), c02 = 2 * (x * z + y * w);
  const double c10 = 2 * (x * y + z * w), c11 = 1 - 2 * (x * x + z * z), c12 = 2 * (y * z - x * w);
  const double c20 = 2 * (x * z - y * w), c21 = 2 * (y * z + x * w), c22 = 1 - 2 * (x * x + y * y);
  r[0] = c00; r[1] = c10; r[2] = c20; r[3] = c01; r[4] = c11; r[5] = c21; r[6] = c02; r[7] = c12; r[8] = c22;   // rows = transpose
}

// the bone moved by w of Dm: w = 0 the bone as it is, w = 1 the bone x Dm. Rotation by nlerp from no turn (always the short way), size and position linearly.
inline int blend_bone(const float* bone, const double* Dm, double w, float* out) {
  if (!bone || !Dm || !out) return 0;
  if (w <= 0.0) { for (int i = 0; i < 16; ++i) out[i] = bone[i]; return 1; }
  if (w > 1.0) w = 1.0;
  double R[9], k = 0.0;
  for (int r = 0; r < 3; ++r) {
    const double l = vm::dsqrt(Dm[r * 4] * Dm[r * 4] + Dm[r * 4 + 1] * Dm[r * 4 + 1] + Dm[r * 4 + 2] * Dm[r * 4 + 2]);
    if (!(l > 1e-9)) return 0;
    for (int c = 0; c < 3; ++c) R[r * 3 + c] = Dm[r * 4 + c] / l;
    k += l / 3.0;
  }
  double q[4]; quat_from_rows(R, q);
  if (q[0] < 0.0) for (int i = 0; i < 4; ++i) q[i] = -q[i];
  double qw[4] = {1.0 - w + w * q[0], w * q[1], w * q[2], w * q[3]};
  const double ql = vm::dsqrt(qw[0] * qw[0] + qw[1] * qw[1] + qw[2] * qw[2] + qw[3] * qw[3]);
  if (!(ql > 1e-9)) return 0;
  for (int i = 0; i < 4; ++i) qw[i] /= ql;
  double Rw[9]; rows_from_quat(qw, Rw);
  const double kw = 1.0 + w * (k - 1.0);
  double B[16]; to44(bone, B);
  // axes: A x (kw * Rw)
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) {
    double s = 0.0;
    for (int m = 0; m < 3; ++m) s += B[r * 4 + m] * Rw[m * 3 + c];
    out[r * 4 + c] = (float)(s * kw);
  }
  // position: lerp(p, p x Dm, w)
  double pf[3];
  for (int c = 0; c < 3; ++c) pf[c] = B[12] * Dm[c] + B[13] * Dm[4 + c] + B[14] * Dm[8 + c] + Dm[12 + c];
  for (int c = 0; c < 3; ++c) out[12 + c] = (float)(B[12 + c] + w * (pf[c] - B[12 + c]));
  out[3] = bone[3]; out[7] = bone[7]; out[11] = bone[11]; out[15] = bone[15];
  for (int i = 0; i < 16; ++i) if ((i & 3) != 3 && out[i] != out[i]) return 0;   // 1.7.203: the 4th column (padding, never read or written back) may hold junk in the game's memory; it refused every bone in the 1.7.202 log
  return 1;
}

// The game's own pose of the hose, kept apart from the bent one. The bone cache holds the game's pose after the game posed the hose, and OUR bent pose after we
// wrote it (the second eye of the same frame, or a frame in which the game did not pose the hose again, e.g. paused). game_pose() tells them apart: a cache that is
// still exactly what we wrote last is ours, and the copy of the game's pose taken before is used; anything else is a new game pose and is copied.
// So the bend never piles up on itself, however often it is applied.
struct Keeper { float orig[kMaxBones * 16], last[kMaxBones * 16]; int have, n; long fresh, reused; int stage; long stageN[4]; double dbgL; };   // 1.7.200 stage: why the last bend was refused (1 move maths, 2 chain length, 3 a bone)
inline const float* game_pose(Keeper* k, const float* cache, int n) {
  if (!k || !cache || n <= 0 || n > kMaxBones) return nullptr;
  if (k->n != n) { k->have = 0; k->n = n; }
  int ours = k->have;
  for (int i = 0; ours && i < n * 16; ++i) if ((i & 3) != 3 && cache[i] != k->last[i]) ours = 0;
  if (!ours) { for (int i = 0; i < n * 16; ++i) k->orig[i] = cache[i]; ++k->fresh; } else ++k->reused;
  return k->orig;
}
inline void wrote(Keeper* k, const float* cache, int n) { if (!k || !cache || n != k->n) return; for (int i = 0; i < n * 16; ++i) k->last[i] = cache[i]; k->have = 1; }
// a refused bend: put the game's pose back if the cache still held ours, and forget what we wrote
inline void give_back(Keeper* k, float* cache, int n) {
  if (!k || !cache || n != k->n) return;
  int ours = k->have;
  for (int i = 0; ours && i < n * 16; ++i) if ((i & 3) != 3 && cache[i] != k->last[i]) ours = 0;
  if (ours) for (int i = 0; i < n * 16; ++i) if ((i & 3) != 3) cache[i] = k->orig[i];
  k->have = 0;
}

// 1.7.150 the stretch is shared evenly: the blend alone puts most of the gun's move into the middle of the hose (segments there grew up to 3.6x while others
// folded to nothing in the stress test). The chain's bones are slid along the bent line so every segment keeps its share of the hose's length (each is stretched or
// shortened by the same factor: new length / the game's length). Both ends stay exactly where they are; bones off the chain move with their chain bone.
inline void even_out(const float* game, float* bent, const int* parent, int n, const int* chain, int cn) {
  if (!game || !bent || !parent || !chain || cn < 3 || n <= 0 || n > kMaxBones) return;
  double so[kMaxBones], sn[kMaxBones], P[kMaxBones][3];
  so[0] = sn[0] = 0.0;
  for (int k = 0; k < cn; ++k) for (int c = 0; c < 3; ++c) P[k][c] = bent[(size_t)16 * chain[k] + 12 + c];
  for (int k = 1; k < cn; ++k) {
    double a = 0.0, b = 0.0;
    for (int c = 0; c < 3; ++c) {
      const double da = (double)game[(size_t)16 * chain[k] + 12 + c] - game[(size_t)16 * chain[k - 1] + 12 + c], db = P[k][c] - P[k - 1][c];
      a += da * da; b += db * db;
    }
    so[k] = so[k - 1] + vm::dsqrt(a); sn[k] = sn[k - 1] + vm::dsqrt(b);
  }
  const double Lo = so[cn - 1], Ln = sn[cn - 1];
  if (!(Lo > 1e-6) || !(Ln > 1e-6)) return;
  double delta[kMaxBones][3];
  int seg = 1;
  for (int k = 0; k < cn; ++k) {
    const double want = so[k] / Lo * Ln;
    while (seg < cn - 1 && sn[seg] < want) ++seg;
    const double l = sn[seg] - sn[seg - 1];
    double u = l > 1e-9 ? (want - sn[seg - 1]) / l : 0.0;
    if (u < 0.0) u = 0.0; if (u > 1.0) u = 1.0;
    for (int c = 0; c < 3; ++c) delta[k][c] = (k == 0 || k == cn - 1) ? 0.0 : (P[seg - 1][c] + u * (P[seg][c] - P[seg - 1][c])) - P[k][c];
  }
  int onChain[kMaxBones];
  for (int i = 0; i < n; ++i) onChain[i] = -1;
  for (int k = 0; k < cn; ++k) onChain[chain[k]] = k;
  for (int i = 0; i < n; ++i) {
    int b = i, steps = 0;
    while (b >= 0 && onChain[b] < 0 && ++steps <= n) b = parent[b];
    if (b < 0 || onChain[b] < 0) continue;
    for (int c = 0; c < 3; ++c) bent[(size_t)16 * i + 12 + c] += (float)delta[onChain[b]][c];
  }
}

// the whole bend of one call, cache -> cache (what arms_hose_follow does once the hose is found). Returns 1 done, 0 refused (the cache then holds the game's pose).
// endFt: out, how far the chain's nearer end is from the game's gun (world units).
inline int bend(Keeper* k, float* cache, const int* parent, int n, const int* chain, int cn, const float* hoseGame, const float* hoseDraw, const float* gunGame,
                const float* gunDraw, double maxEndFt, double* endFt) {
  const float* g = game_pose(k, cache, n);
  if (!g || cn < 3) return 0;
  double HG[16], GG[16];
  to44(hoseGame, HG); to44(gunGame, GG);
  double d[2];
  for (int e = 0; e < 2; ++e) {
    const float* b = g + (size_t)16 * chain[e ? cn - 1 : 0];
    double d2 = 0.0;
    for (int c = 0; c < 3; ++c) { double pw = HG[12 + c]; for (int m = 0; m < 3; ++m) pw += (double)b[12 + m] * HG[m * 4 + c]; d2 += (pw - GG[12 + c]) * (pw - GG[12 + c]); }
    d[e] = vm::dsqrt(d2);
  }
  const int gunAtStart = d[0] < d[1] ? 1 : 0;
  const double nearFt = gunAtStart ? d[0] : d[1];
  if (endFt) *endFt = nearFt;
  if (!(nearFt <= maxEndFt)) { give_back(k, cache, n); return -1; }
  double Dm[16]; float w[kMaxBones];
  static float bent[kMaxBones * 16];
  if (!model_move(hoseGame, hoseDraw, gunGame, gunDraw, Dm)) { k->stage = 1; ++k->stageN[1]; give_back(k, cache, n); return 0; }
  { const double L = chain_weights(g, parent, n, chain, cn, gunAtStart, w); k->dbgL = L; if (!(L > 0.0)) { k->stage = 2; ++k->stageN[2]; give_back(k, cache, n); return 0; } }
  for (int b = 0; b < n; ++b) if (!blend_bone(g + (size_t)16 * b, Dm, w[b], bent + (size_t)16 * b)) { k->stage = 3; ++k->stageN[3]; give_back(k, cache, n); return 0; }
  even_out(g, bent, parent, n, chain, cn);
  for (int b = 0; b < n; ++b) for (int i = 0; i < 16; ++i) if ((i & 3) != 3) cache[(size_t)16 * b + i] = bent[(size_t)16 * b + i];
  wrote(k, cache, n);
  return 1;
}

}  // namespace hose
