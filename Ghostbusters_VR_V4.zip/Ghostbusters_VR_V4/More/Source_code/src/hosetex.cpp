// 0.78 the hose takes its colour from the game's own hose texture.
//
// The player's pack, hose and wand are separate model instances inside the player object (hose: +0xD7B0, wand: +0xD728, the pack and other extras
// in the 0x90-byte entries from +0xD450; see layout.h). Each instance has a model with a list of meshes (list pointer at instance+0x78, count at
// list+0x34, pointer array at list+0x38, the mesh's name at mesh+0x18). None of the deeper layout (mesh -> material -> texture) is known yet, so this
// file WALKS it: from every mesh it follows pointers a few levels deep and asks every object that looks like a Direct3D 11 object (its vtable lives in
// d3d11.dll) whether it is a shader-resource view or a 2D texture. Textures found are handed to the render thread, which copies the smallest mip to a
// staging texture and averages it (plain 8-bit formats and BC1 / BC2 / BC3). The hose's average colour becomes the hose tint; when the player changes
// pack, suit or anything else the mesh names change, and the walk runs again.
//
// Everything here is guarded: every pointer is checked with memcache::readable before it is read, objects are only called when their vtable and
// the first three slots lie inside d3d11.dll, and the whole thing can be switched off (hose_from_game=0). It also writes PARTS lines (mesh names, textures
// with format, size and average colour) and PARTSRAW hex dumps into the log, so the exact mesh -> texture layout can be pinned down in the next version.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include <d3d11.h>
#include "memcache.h"

namespace {
const GUID kIidSrv = {0xb0e06fe0, 0x8192, 0x4e1e, {0xb1, 0xca, 0x36, 0xd7, 0x41, 0x47, 0x10, 0xb2}};
const GUID kIidTex2D = {0x6f15aaf2, 0xd208, 0x4e89, {0x9a, 0xb4, 0x48, 0x95, 0x35, 0xd3, 0x4f, 0x9c}};
const uint32_t kInst[] = {0xD450, 0xD4E0, 0xD570, 0xD600, 0xD690, 0xD720, 0xD728, 0xD7B0, 0xD840};
const uint32_t kHoseInst = 0xD7B0;
enum { kMaxCand = 16, kMaxNodes = 700, kMaxMesh = 24, kNameLen = 40, kDepthMax = 3 };

struct Cand {
  volatile LONG state;      // 0 free, 1 waiting for the render thread, 2 done
  ID3D11Texture2D* tex;
  int scan, inst, mesh, depth, hose;
  char name[kNameLen];
  unsigned fmt, w, h, mips;
  float avg[3];
  int ok, normalMap, unsupported;
};
Cand g_c[kMaxCand];
struct ModCache { HMODULE h; int yes; };
ModCache g_mc[24];
int g_mcn;
HMODULE g_self;
uintptr_t g_exeLo, g_exeHi;
struct HoseState {
  long steps, scans, nodes, comObjs, texFound, queued, processed, usable, unsupported, rejected, qiFail;
  int instValid, lastMeshes, haveTarget, targetScan, curSet;
  unsigned nameHash;
  int64_t firstQ, nextQ, curQ, lastScanQ;
  int budget;
  float target[3], cur[3];
  long partsLogged, rawLogged;
} g_h;

int plausible(uintptr_t v) { return (v & 7) == 0 && v > 0x10000 && v < 0x00007FFFFFFFFFFFull && !(v >= g_exeLo && v < g_exeHi); }

// is the address inside a Direct3D 11 module (not our own proxy of the same name)? cached per module
int in_d3d11(uintptr_t a) {
  HMODULE hm = nullptr;
  if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)a, &hm) || !hm) return 0;
  if (hm == g_self) return 0;
  for (int i = 0; i < g_mcn; ++i) if (g_mc[i].h == hm) return g_mc[i].yes;
  wchar_t fn[260];
  const DWORD n = GetModuleFileNameW(hm, fn, 260);
  int yes = 0;
  if (n > 0 && n < 260) {
    int s = (int)n;
    while (s > 0 && fn[s - 1] != L'\\' && fn[s - 1] != L'/') --s;
    static const wchar_t want[] = L"d3d11";
    yes = 1;
    for (int i = 0; i < 5; ++i) { wchar_t ch = fn[s + i]; if (ch >= L'A' && ch <= L'Z') ch = (wchar_t)(ch + 32); if (ch != want[i]) { yes = 0; break; } }
  }
  if (g_mcn < 24) { g_mc[g_mcn].h = hm; g_mc[g_mcn].yes = yes; ++g_mcn; }
  return yes;
}
// 0.89: the address must be committed, executable code (0.88 crashed by "calling" a pointer that lay inside d3d11.dll but was data, not code)
int is_code(uintptr_t a) {
  MEMORY_BASIC_INFORMATION mbi;
  if (VirtualQuery((LPCVOID)a, &mbi, sizeof mbi) != sizeof mbi) return 0;
  if (mbi.State != MEM_COMMIT || mbi.Type != MEM_IMAGE) return 0;
  return (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
}
int looks_com(uintptr_t p) {
  if (!memcache::readable((const void*)p, 8, 0, 0)) return 0;
  const uintptr_t vt = *(const uintptr_t*)p;
  if (!plausible(vt) && !(vt > 0x10000 && (vt & 7) == 0)) return 0;
  if (!in_d3d11(vt)) return 0;                      // a real object's table lives inside d3d11.dll itself (its read-only data)
  if (is_code(vt)) return 0;                        // ... and is data, not code
  if (!memcache::readable((const void*)vt, 24, 0, 0)) return 0;
  const uintptr_t* f = (const uintptr_t*)vt;
  for (int i = 0; i < 3; ++i) if (!in_d3d11(f[i]) || !is_code(f[i])) return 0;
  return 1;
}
ID3D11Texture2D* com_texture(uintptr_t p) {
  IUnknown* u = (IUnknown*)p;
  ID3D11ShaderResourceView* srv = nullptr;
  if (SUCCEEDED(u->QueryInterface(kIidSrv, (void**)&srv)) && srv) {
    ID3D11Resource* res = nullptr;
    srv->GetResource(&res);
    srv->Release();
    if (!res) return nullptr;
    ID3D11Texture2D* t = nullptr;
    if (FAILED(res->QueryInterface(kIidTex2D, (void**)&t))) t = nullptr;
    res->Release();
    return t;
  }
  ID3D11Texture2D* t = nullptr;
  if (SUCCEEDED(u->QueryInterface(kIidTex2D, (void**)&t)) && t) return t;
  return nullptr;
}

int read_str(uintptr_t p, char* out, int cap) {
  int n = 0;
  while (n < cap - 1) {
    if ((n & 15) == 0 && !memcache::readable((const void*)(p + n), 16, 0, 0)) break;
    const unsigned char ch = *(const unsigned char*)(p + n);
    if (ch < 0x20 || ch > 0x7E) break;
    out[n++] = (char)ch;
  }
  out[n] = 0;
  return n;
}
// the mesh's name: a pointer to a string at mesh+0x18, or the characters themselves
int mesh_name(uintptr_t m, char* out, int cap) {
  out[0] = 0;
  if (!memcache::readable((const void*)(m + 0x18), 16, 0, 0)) return 0;
  const uintptr_t q = *(const uintptr_t*)(m + 0x18);
  if (plausible(q) && memcache::readable((const void*)q, 8, 0, 0) && read_str(q, out, cap) >= 2) return 1;
  if (read_str(m + 0x18, out, cap) >= 2) return 1;
  out[0] = 0;
  return 0;
}
void hexline(char* o, int cap, const uint8_t* p, int n) {
  static const char H[] = "0123456789abcdef";
  int k = 0;
  for (int i = 0; i < n && k + 4 < cap; ++i) { o[k++] = H[p[i] >> 4]; o[k++] = H[p[i] & 15]; if ((i & 7) == 7 && i + 1 < n) o[k++] = ' '; }
  o[k] = 0;
}
void raw_dump(const char* what, uintptr_t p, int bytes) {
  if (g_h.rawLogged >= 90 || !memcache::readable((const void*)p, (size_t)bytes, 0, 0)) return;
  char line[120];
  for (int o = 0; o < bytes; o += 32) {
    hexline(line, sizeof(line), (const uint8_t*)(p + o), bytes - o < 32 ? bytes - o : 32);
    log_line("PARTSRAW %s %p +0x%02x: %s", what, (const void*)p, o, line);
    ++g_h.rawLogged;
  }
}

struct Node { uintptr_t p; int depth; };
Node g_q[kMaxNodes];
int g_qn;
int seen(uintptr_t p) { for (int i = 0; i < g_qn; ++i) if (g_q[i].p == p) return 1; return 0; }

// a texture was found while walking from a mesh: hand it to the render thread
void offer(ID3D11Texture2D* t, int scan, int inst, int mesh, int depth, const char* name) {
  for (int i = 0; i < kMaxCand; ++i) if (g_c[i].state != 0 && g_c[i].tex == t && g_c[i].scan == scan) { t->Release(); return; }
  for (int i = 0; i < kMaxCand; ++i) {
    Cand& c = g_c[i];
    if (c.state != 0) continue;
    c.tex = t; c.scan = scan; c.inst = inst; c.mesh = mesh; c.depth = depth; c.hose = inst == (int)kHoseInst;
    int k = 0; while (name && name[k] && k < kNameLen - 1) { c.name[k] = name[k]; ++k; } c.name[k] = 0;
    c.ok = 0; c.normalMap = 0; c.unsupported = 0; c.avg[0] = c.avg[1] = c.avg[2] = 0;
    D3D11_TEXTURE2D_DESC d;
    t->GetDesc(&d);
    c.fmt = (unsigned)d.Format; c.w = d.Width; c.h = d.Height; c.mips = d.MipLevels;
    InterlockedExchange(&c.state, 1);
    ++g_h.queued;
    return;
  }
  t->Release();   // no free slot
}

void crawl(uintptr_t root, int scan, int inst, int mesh, const char* name) {
  g_qn = 0;
  g_q[g_qn++] = {root, 0};
  for (int i = 0; i < g_qn; ++i) {
    const Node n = g_q[i];
    if (n.depth >= kDepthMax || g_h.budget <= 0) continue;
    --g_h.budget;
    if (!memcache::readable((const void*)n.p, 0x100, 0, 0)) continue;
    const uintptr_t* f = (const uintptr_t*)n.p;
    for (int k = 0; k < 32 && g_qn < kMaxNodes; ++k) {
      const uintptr_t v = f[k];
      if (!plausible(v) || seen(v)) continue;
      if (!memcache::readable((const void*)v, 0x40, 0, 0)) continue;
      g_q[g_qn++] = {v, n.depth + 1};
      ++g_h.nodes;
      if (looks_com(v)) {
        ++g_h.comObjs;
        ID3D11Texture2D* t = com_texture(v);
        if (t) { ++g_h.texFound; offer(t, scan, inst, mesh, n.depth + 1, name); }
        else ++g_h.qiFail;
      }
    }
  }
}

uint32_t fnv(uint32_t h, const char* s) { while (*s) { h ^= (unsigned char)*s++; h *= 16777619u; } return h; }

// ---- render thread: the average colour of a texture --------------------------------------------------------------------------------------------------
struct Fmt { int kind; };   // 1 RGBA8, 2 BGRA8, 3 BC1, 4 BC2/BC3
int fmt_kind(unsigned f) {
  switch (f) {
    case 28: case 29: return 1;
    case 87: case 88: case 91: case 93: return 2;
    case 71: case 72: return 3;
    case 74: case 75: case 77: case 78: return 4;
    default: return 0;
  }
}
void bc1_texel(const uint8_t* b, int tx, int ty, int fourColor, float* rgb) {
  const unsigned c0 = b[0] | (b[1] << 8), c1 = b[2] | (b[3] << 8);
  float col[4][3];
  const float r0 = (float)((c0 >> 11) & 31) / 31.0f, g0 = (float)((c0 >> 5) & 63) / 63.0f, b0 = (float)(c0 & 31) / 31.0f;
  const float r1 = (float)((c1 >> 11) & 31) / 31.0f, g1 = (float)((c1 >> 5) & 63) / 63.0f, b1 = (float)(c1 & 31) / 31.0f;
  col[0][0] = r0; col[0][1] = g0; col[0][2] = b0; col[1][0] = r1; col[1][1] = g1; col[1][2] = b1;
  if (c0 > c1 || fourColor) {
    for (int i = 0; i < 3; ++i) { col[2][i] = (2.0f * col[0][i] + col[1][i]) / 3.0f; col[3][i] = (col[0][i] + 2.0f * col[1][i]) / 3.0f; }
  } else {
    for (int i = 0; i < 3; ++i) { col[2][i] = 0.5f * (col[0][i] + col[1][i]); col[3][i] = 0.0f; }
  }
  const int sel = (b[4 + ty] >> (tx * 2)) & 3;
  rgb[0] = col[sel][0]; rgb[1] = col[sel][1]; rgb[2] = col[sel][2];
}
void fetch(int kind, const uint8_t* base, unsigned pitch, int x, int y, float* rgb) {
  if (kind == 1 || kind == 2) {
    const uint8_t* p = base + (size_t)y * pitch + (size_t)x * 4;
    const int ri = kind == 1 ? 0 : 2, bi = kind == 1 ? 2 : 0;
    rgb[0] = p[ri] / 255.0f; rgb[1] = p[1] / 255.0f; rgb[2] = p[bi] / 255.0f;
  } else if (kind == 3) {
    bc1_texel(base + (size_t)(y >> 2) * pitch + (size_t)(x >> 2) * 8, x & 3, y & 3, 0, rgb);
  } else {
    bc1_texel(base + (size_t)(y >> 2) * pitch + (size_t)(x >> 2) * 16 + 8, x & 3, y & 3, 1, rgb);
  }
}

void evaluate(ID3D11Device* dev, ID3D11DeviceContext* ctx, Cand& c) {
  ID3D11Texture2D* t = c.tex;
  D3D11_TEXTURE2D_DESC d;
  t->GetDesc(&d);
  const int kind = fmt_kind((unsigned)d.Format);
  c.ok = 0;
  if (d.SampleDesc.Count > 1 || d.ArraySize != 1 || (d.MiscFlags & D3D11_RESOURCE_MISC_TEXTURECUBE) || (d.BindFlags & (D3D11_BIND_RENDER_TARGET | D3D11_BIND_DEPTH_STENCIL)) || d.Usage == D3D11_USAGE_DYNAMIC || d.Usage == D3D11_USAGE_STAGING ||
      (unsigned long long)d.Width * d.Height > 16ull * 1024 * 1024 || d.Width < 1 || d.Height < 1) { ++g_h.rejected; return; }
  if (!kind) { c.unsupported = 1; ++g_h.unsupported; return; }
  D3D11_TEXTURE2D_DESC sd = d;
  sd.Usage = D3D11_USAGE_STAGING; sd.BindFlags = 0; sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ; sd.MiscFlags = 0;
  ID3D11Texture2D* stg = nullptr;
  if (FAILED(dev->CreateTexture2D(&sd, nullptr, &stg)) || !stg) { ++g_h.rejected; return; }
  ctx->CopyResource(stg, t);
  unsigned m = 0;
  const unsigned mips = d.MipLevels ? d.MipLevels : 1;
  while (m + 1 < mips && (((d.Width >> m) > 16) || ((d.Height >> m) > 16))) ++m;
  unsigned w = d.Width >> m, h = d.Height >> m;
  if (w < 1) w = 1;
  if (h < 1) h = 1;
  D3D11_MAPPED_SUBRESOURCE mp;
  if (SUCCEEDED(ctx->Map(stg, m, D3D11_MAP_READ, 0, &mp)) && mp.pData) {
    double sum[3] = {0, 0, 0};
    int cnt = 0;
    const unsigned sx = w > 16 ? w / 16 : 1, sy = h > 16 ? h / 16 : 1;
    for (unsigned y = 0; y < h; y += sy)
      for (unsigned x = 0; x < w; x += sx) {
        float rgb[3];
        fetch(kind, (const uint8_t*)mp.pData, mp.RowPitch, (int)x, (int)y, rgb);
        sum[0] += rgb[0]; sum[1] += rgb[1]; sum[2] += rgb[2]; ++cnt;
      }
    ctx->Unmap(stg, m);
    if (cnt > 0) {
      for (int i = 0; i < 3; ++i) c.avg[i] = (float)(sum[i] / cnt);
      // a normal map is mostly (0.5, 0.5, 1.0): not a colour texture
      c.normalMap = (c.avg[2] > 0.82f && c.avg[0] > 0.38f && c.avg[0] < 0.62f && c.avg[1] > 0.38f && c.avg[1] < 0.62f) ? 1 : 0;
      c.ok = 1;
    }
  }
  stg->Release();
}
}  // namespace

// ---- game thread ------------------------------------------------------------------------------------------------------------------------------------------
void hosetex_game_step(uintptr_t player) {
  if (!g_ctl.hoseFromGame || !player) return;
  const int64_t now = qpc_now();
  if (!g_h.firstQ) {
    g_h.firstQ = now;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)&hosetex_game_step, &g_self);
    const uintptr_t base = (uintptr_t)GetModuleHandleW(nullptr);
    if (base && memcache::readable((const void*)base, 0x400, 0, 0)) {
      const IMAGE_DOS_HEADER* dh = (const IMAGE_DOS_HEADER*)base;
      if (dh->e_magic == IMAGE_DOS_SIGNATURE && dh->e_lfanew > 0 && dh->e_lfanew < 0x300) {
        const IMAGE_NT_HEADERS64* nt = (const IMAGE_NT_HEADERS64*)(base + dh->e_lfanew);
        if (nt->Signature == IMAGE_NT_SIGNATURE) { g_exeLo = base; g_exeHi = base + nt->OptionalHeader.SizeOfImage; }
      }
    }
  }
  if (now < g_h.nextQ) return;
  if (g_h.steps == 0 && now - g_h.firstQ < 6 * qpc_freq()) return;   // the first look 6 s after the level started: the model parts exist by then
  g_h.nextQ = now + 3 * qpc_freq();
  ++g_h.steps;
  // ---- the census: every model instance that has a readable mesh list
  static char names[kMaxMesh * 4][kNameLen];
  static uintptr_t meshes[kMaxMesh * 4];
  static int meshInst[kMaxMesh * 4];
  int nm = 0, valid = 0;
  uint32_t hash = 2166136261u;
  for (unsigned bi = 0; bi < sizeof(kInst) / sizeof(kInst[0]); ++bi) {
    const uintptr_t inst = player + kInst[bi];
    if (!memcache::readable((const void*)(inst + 0x78), 8, 0, 0)) continue;
    const uintptr_t list = *(const uintptr_t*)(inst + 0x78);
    if (!plausible(list) || !memcache::readable((const void*)(list + 0x30), 16, 0, 0)) continue;
    const int count = *(const int*)(list + 0x34);
    const uintptr_t arr = *(const uintptr_t*)(list + 0x38);
    if (count < 1 || count > 64 || !plausible(arr) || !memcache::readable((const void*)arr, (size_t)count * 8, 0, 0)) continue;
    int got = 0;
    for (int i = 0; i < count && i < kMaxMesh && nm < kMaxMesh * 4; ++i) {
      const uintptr_t mp = ((const uintptr_t*)arr)[i];
      if (!plausible(mp) || !memcache::readable((const void*)mp, 0x40, 0, 0)) continue;
      mesh_name(mp, names[nm], kNameLen);
      meshes[nm] = mp; meshInst[nm] = (int)kInst[bi];
      hash = fnv(hash, names[nm]); hash ^= (uint32_t)kInst[bi]; hash *= 16777619u;
      ++nm; ++got;
    }
    if (got) ++valid;
  }
  g_h.instValid = valid; g_h.lastMeshes = nm;
  const int retry = !g_h.haveTarget && g_h.scans < 6 && g_h.lastScanQ && now - g_h.lastScanQ > 20 * qpc_freq();   // nothing usable yet: look again every 20 s (the textures may load late)
  if (g_h.steps == 1 || hash != g_h.nameHash || retry) {   // first look or the parts changed (pack, suit, ...): list them and look for textures again
    g_h.nameHash = hash;
    g_h.lastScanQ = now;
    g_h.budget = 6000;
    const int scan = (int)++g_h.scans;
    for (int i = 0; i < kMaxCand; ++i) if (g_c[i].state == 2) InterlockedExchange(&g_c[i].state, 0);   // finished candidates of earlier scans
    if (g_h.partsLogged < 40) {
      ++g_h.partsLogged;
      if (!nm) log_line("PARTS scan=%d: no model instance with a readable mesh list was found at the assumed places (checked %d) - the PARTSRAW lines show what is there instead", scan, (int)(sizeof(kInst) / sizeof(kInst[0])));
      for (unsigned bi = 0; bi < sizeof(kInst) / sizeof(kInst[0]); ++bi) {
        char line[420]; int ln = 0, cnt = 0;
        for (int i = 0; i < nm; ++i) {
          if (meshInst[i] != (int)kInst[bi]) continue;
          ++cnt;
          if (ln < 340) { const char* s = names[i][0] ? names[i] : "(no name)"; ln += wsprintfA(line + ln, "%s%s", cnt > 1 ? " | " : "", s); }
        }
        if (cnt) log_line("PARTS scan=%d instance +0x%x%s meshes=%d: %s", scan, (unsigned)kInst[bi], kInst[bi] == kHoseInst ? " (hose)" : kInst[bi] == 0xD728 ? " (wand)" : "", cnt, line);
      }
    }
    if (scan == 1) {   // raw bytes of the hose and wand instances, their model lists and first meshes, for working out the layout offline
      static const uint32_t raws[2] = {kHoseInst, 0xD728};
      for (int r = 0; r < 2; ++r) {
        const uintptr_t inst = player + raws[r];
        raw_dump(r == 0 ? "hose-instance" : "wand-instance", inst, 0x90);
        if (memcache::readable((const void*)(inst + 0x78), 8, 0, 0)) {
          const uintptr_t list = *(const uintptr_t*)(inst + 0x78);
          if (plausible(list)) {
            raw_dump(r == 0 ? "hose-modellist" : "wand-modellist", list, 0x60);
            if (memcache::readable((const void*)(list + 0x30), 16, 0, 0)) {
              const uintptr_t arr = *(const uintptr_t*)(list + 0x38);
              if (plausible(arr) && memcache::readable((const void*)arr, 8, 0, 0)) {
                const uintptr_t m0 = *(const uintptr_t*)arr;
                if (plausible(m0)) raw_dump(r == 0 ? "hose-mesh0" : "wand-mesh0", m0, 0x80);
              }
            }
          }
        }
      }
    }
    // look for textures: from every mesh, from every instance itself and from every model list
    const long n0 = g_h.nodes, c0 = g_h.comObjs, t0 = g_h.texFound, q0 = g_h.queued;
    for (int pass = 0; pass < 2; ++pass)   // the hose's own meshes first, then the rest
      for (int i = 0; i < nm; ++i) if ((meshInst[i] == (int)kHoseInst) == (pass == 0)) crawl(meshes[i], scan, meshInst[i], i, names[i]);
    for (unsigned bi = 0; bi < sizeof(kInst) / sizeof(kInst[0]); ++bi) {
      const uintptr_t inst = player + kInst[bi];
      if (!memcache::readable((const void*)(inst + 0x78), 8, 0, 0)) continue;
      const uintptr_t list = *(const uintptr_t*)(inst + 0x78);
      int has = 0;
      for (int i = 0; i < nm; ++i) if (meshInst[i] == (int)kInst[bi]) { has = 1; break; }
      if (!has) continue;
      crawl(inst, scan, (int)kInst[bi], -1, "(instance)");
      if (plausible(list)) crawl(list, scan, (int)kInst[bi], -2, "(model list)");
    }
    if (g_h.partsLogged <= 40)
      log_line("PARTS scan=%d walk: %ld objects looked at, %ld Direct3D objects, %ld textures found, %ld queued for reading (instances with meshes: %d)", scan, g_h.nodes - n0, g_h.comObjs - c0, g_h.texFound - t0, g_h.queued - q0, valid);
  }
}

// ---- render thread --------------------------------------------------------------------------------------------------------------------------------------
void hosetex_render_step(ID3D11Device* dev, ID3D11DeviceContext* ctx) {
  if (!g_ctl.hoseFromGame || !dev || !ctx) return;
  static int s_n;
  if ((++s_n & 3) != 0) return;
  int done = 0;
  for (int i = 0; i < kMaxCand && done < 2; ++i) {
    Cand& c = g_c[i];
    if (c.state != 1) continue;
    evaluate(dev, ctx, c);
    ++g_h.processed; ++done;
    if (c.ok) ++g_h.usable;
    if (g_h.processed <= 70)
      log_line("PARTS texture scan=%d instance +0x%x mesh=%d \"%s\" found %d levels down: format %u, %ux%u, %u mip levels, %s%s", c.scan, (unsigned)c.inst, c.mesh, c.name, c.depth, c.fmt, c.w, c.h, c.mips,
               c.ok ? "average colour" : (c.unsupported ? "format not readable by the probe (only plain 8-bit and BC1-BC3)" : "not read (render target / array / too big / copy failed)"), c.ok ? "" : "");
    if (c.ok && g_h.processed <= 70) log_line("PARTS color %d %d %d of 255 (mesh \"%s\")%s%s", (int)(c.avg[0] * 255.0f + 0.5f), (int)(c.avg[1] * 255.0f + 0.5f), (int)(c.avg[2] * 255.0f + 0.5f), c.name, c.normalMap ? " - looks like a normal map, not used" : "", c.hose ? " [hose]" : "");
    if (c.ok && c.hose && !c.normalMap && c.scan > g_h.targetScan) {
      for (int k = 0; k < 3; ++k) g_h.target[k] = c.avg[k];
      g_h.haveTarget = 1; g_h.targetScan = c.scan;
      log_line("HOSECOLOR the hose takes the colour %d %d %d of 255 from the game's texture of mesh \"%s\" (scan %d)", (int)(c.avg[0] * 255.0f + 0.5f), (int)(c.avg[1] * 255.0f + 0.5f), (int)(c.avg[2] * 255.0f + 0.5f), c.name, c.scan);
    }
    if (c.tex) { c.tex->Release(); c.tex = nullptr; }
    InterlockedExchange(&c.state, 2);
  }
}

int hosetex_color(float* rgb) {
  if (!g_ctl.hoseFromGame || !g_h.haveTarget) return 0;
  const int64_t now = qpc_now();
  double dt = g_h.curQ ? (double)(now - g_h.curQ) / (double)qpc_freq() : 10.0;
  g_h.curQ = now;
  if (dt < 0.0) dt = 0.0;
  if (dt > 10.0) dt = 10.0;
  if (!g_h.curSet) { for (int i = 0; i < 3; ++i) g_h.cur[i] = g_h.target[i]; g_h.curSet = 1; }
  const double a = dt / (dt + 0.8);
  for (int i = 0; i < 3; ++i) { g_h.cur[i] += (float)((g_h.target[i] - g_h.cur[i]) * a); rgb[i] = g_h.cur[i]; }
  return 1;
}

void hosetex_report(LONG frame) {
  log_line("HOSETEX frame=%d on=%d scans=%ld instances with meshes=%d (meshes %d) | objects walked=%ld, Direct3D objects=%ld, textures=%ld (QI failed %ld), queued=%ld, read=%ld, usable=%ld, unsupported format=%ld, rejected=%ld | game-texture hose colour %s (%d %d %d of 255)",
           (int)frame, (int)g_ctl.hoseFromGame, g_h.scans, g_h.instValid, g_h.lastMeshes, g_h.nodes, g_h.comObjs, g_h.texFound, g_h.qiFail, g_h.queued, g_h.processed, g_h.usable, g_h.unsupported, g_h.rejected,
           g_h.haveTarget ? "KNOWN" : "not known yet (the default black rubber is used)", (int)(g_h.cur[0] * 255.0f), (int)(g_h.cur[1] * 255.0f), (int)(g_h.cur[2] * 255.0f));
}
#endif
