// 0.29 the game's 2D overlay (HUD) placed in front of the player for both
// eyes (hudmath.h explains the geometry; layout.h "Overlay" the game side).
//
// The overlay is drawn by HUD::Draw 0x253240 on the render job, after the 3D
// scene and all post-processing, entirely through Direct3D viewport + screen-
// space vertices. Every Direct3D viewport the engine sets goes through one
// function, 0x3F5880(x, y, w, h). While HUD::Draw runs for an eye picture the
// probe hands that function a moved and smaller rectangle, so everything the
// overlay draws (sprites, text, the subtitle boxes' own sub-viewports) lands
// in the right place for that eye; afterwards the engine's own rectangle is
// set again. Exception: the targeted ghost's health ring, which the game
// already projects from the ghost's 3D position for the current view - it is
// drawn with the engine's own rectangle. Nothing in the game's memory is
// changed; text the engine has queued is drawn before each switch (the
// engine's own text flush 0x3D62E0) so it lands on the side it belongs to.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include "layout.h"
#include "hudmath.h"
#include "MinHook.h"

typedef void(__fastcall* PFN_Viewport)(int x, int y, int w, int h);
typedef void(__fastcall* PFN_Draw)(void* self);
typedef void (*PFN_Flush)();
static PFN_Viewport o_viewport;
static PFN_Draw o_hudDraw, o_ringDraw;
static int g_hudHooks;  // 1 installed, 0 not yet, <0 why not

// Last rectangle the engine asked for, per thread (the render job and, in the
// game's menu loops or with "render in parallel" off, the main thread).
struct VpRec { volatile LONG tid; int x, y, w, h, valid; };
static VpRec g_vp[8];   // the game runs up to 5 job workers plus the main thread
static volatile LONG g_on;           // overlay transform active ...
static DWORD g_onTid;                // ... on this thread
static hud::Xf g_xf;
static struct { volatile LONG drawCalls, placed, notEye, badParams, viewports, ring, ringHidden, noSlot; int lastEye; double lastDx, lastSx, lastSy; } g_hs;

// 1.6 the HUD of each eye: how long the game's own HUD draw took (a near-empty draw = the game drew nothing for that eye), the two flags that make it return early, and a redraw for an eye that came out empty
static struct {
  volatile LONG draws[2], empty[2], retried[2], retryHelped[2], levelOff[2], flag1e0[2], bucket[2][5], logged, shots;
  volatile LONG forced[2], forcedHelped[2];
  double ema[2]; double maxUs[2]; int64_t shotQ, goodQ[2];
} g_he;

static VpRec* vp_rec(DWORD tid) {
  for (VpRec& r : g_vp) if ((DWORD)r.tid == tid) return &r;
  for (VpRec& r : g_vp) if (InterlockedCompareExchange(&r.tid, (LONG)tid, 0) == 0) return &r;
  return nullptr;
}

static void __fastcall hk_viewport(int x, int y, int w, int h) {
  DWORD tid = GetCurrentThreadId();
  VpRec* r = vp_rec(tid);
  if (r) { r->x = x; r->y = y; r->w = w; r->h = h; r->valid = 1; }
  else InterlockedIncrement(&g_hs.noSlot);
  if (g_on && g_onTid == tid) {
    int x2, y2, w2, h2;
    hud::apply(g_xf, x, y, w, h, &x2, &y2, &w2, &h2);
    InterlockedIncrement(&g_hs.viewports);
    o_viewport(x2, y2, w2, h2);
    return;
  }
  o_viewport(x, y, w, h);
}

// Set the engine's current rectangle again (moved or not, depending on g_on).
// Without a record for this thread: the engine's own cache of the last
// rectangle (floats x, y, w, h at 0x2840D60), read once at overlay entry while
// it is still untransformed (hk_hud_draw), and used for both switches.
static float g_entryCache[4];
static int g_entryCacheValid;
static void reissue() {
  VpRec* r = vp_rec(GetCurrentThreadId());
  if (r && r->valid) { hk_viewport(r->x, r->y, r->w, r->h); return; }
  if (g_entryCacheValid) {
    hk_viewport((int)g_entryCache[0], (int)g_entryCache[1], (int)g_entryCache[2], (int)g_entryCache[3]);
    return;
  }
  hk_viewport(0, 0, *(const volatile int*)rva(layout::kRvaWantedWidth), *(const volatile int*)rva(layout::kRvaWantedHeight));
}

static void flush_text() { ((PFN_Flush)rva(layout::kRvaTextFlush))(); }

// 1.7.192 "remove the crosshair on screen": the game's reticle is three sprites of the HUD object (elements at +0x5918, +0x59F0, +0x5AC8); each has a set-alpha method at vtable +0x20 (the HUD's own update
// fades them with it, 0x252E20). The HUD update runs before the draw, so setting the alpha to 0 right before the draw hides them for this picture; the update sets it again next time.
static void hide_reticle(void* overlay) {
  if (!overlay || !g_game.identityOK || !g_ctl.stereoActive) return;
  static const uint32_t kEl[3] = {0x5918, 0x59F0, 0x5AC8};
  {   // the three reticle sprites are the same class: one vtable, one set-alpha method; anything else is not the gameplay HUD
    uintptr_t vt0 = 0;
    for (int i = 0; i < 3; ++i) { const uint8_t* el = (const uint8_t*)overlay + kEl[i]; if (IsBadReadPtr(el, 8)) return; const uintptr_t vt = *(const uintptr_t*)el; if (i == 0) vt0 = vt; else if (vt != vt0) return; }
  }
  for (int i = 0; i < 3; ++i) {
    uint8_t* el = (uint8_t*)overlay + kEl[i];
    if (IsBadReadPtr(el, 8)) return;
    const uintptr_t vt = *(const uintptr_t*)el;
    if (vt < g_game.base || vt >= g_game.base + 0x4000000 || IsBadReadPtr((const void*)(vt + 0x20), 8)) return;
    const uintptr_t fn = *(const uintptr_t*)(vt + 0x20);
    if (fn < g_game.base || fn >= g_game.base + 0x3200000) return;
    ((void(__fastcall*)(void*, float))fn)(el, 0.0f);
  }
}
static void __fastcall hk_hud_draw(void* overlay) {
  ProfScope psHud(PF_HUD);
  hide_reticle(overlay);
  engine_goggle_apply();   // 1.4: the game's green PKE goggle frame is shown / hidden here (same thread as the overlay draw, which runs just before HUD::Draw)
  stage_g(ST_G_HUD);
  InterlockedIncrement(&g_hs.drawCalls);
  int eye = 0;
  float tH = 0, tV = 0, ex = 0, limW = 0, limH = 0;
  if (!g_ctl.hudMode || !stereo_drawing_eye(&eye, &tH, &tV, &ex, &limW, &limH)) {
    InterlockedIncrement(&g_hs.notEye);
    o_hudDraw(overlay);
    return;
  }
  hud::Xf xf;
  int W = *(const volatile int*)rva(layout::kRvaWantedWidth), H = *(const volatile int*)rva(layout::kRvaWantedHeight);
  if (!hud::make(W, H, tH, tV, ex, (int)g_ctl.hudSizePct, (double)g_ctl.hudDistanceCm / 100.0, &xf, limW, limH)) {
    InterlockedIncrement(&g_hs.badParams);
    o_hudDraw(overlay);
    return;
  }
  flush_text();                    // anything queued before the overlay keeps the engine's rectangle
  g_entryCacheValid = 0;           // a thread without a record takes the engine's cache, read below with g_on still 0
  g_xf = xf;
  {
    VpRec* r = vp_rec(GetCurrentThreadId());
    if (!r || !r->valid) {
      const volatile float* c = (const volatile float*)rva(layout::kRvaViewportCache);
      for (int i = 0; i < 4; ++i) g_entryCache[i] = c[i];
      g_entryCacheValid = g_entryCache[2] >= 1 && g_entryCache[3] >= 1 && g_entryCache[2] <= 16384 && g_entryCache[3] <= 16384;
    }
  }
  g_onTid = GetCurrentThreadId();
  InterlockedExchange(&g_on, 1);
  reissue();
  {
    const int e = eye ? 1 : 0;
    const uintptr_t wp = *(const uintptr_t*)rva(layout::kRvaWorldPtrHud);
    int lvl = -1, f1e0 = -1;
    if (wp && IsBadReadPtr((const void*)(wp + 0x3ada0), 1) == 0 && IsBadReadPtr((const void*)(wp + 0x1e0), 4) == 0) { lvl = *(const unsigned char*)(wp + 0x3ada0) != 0; f1e0 = *(const int*)(wp + 0x1e0) != 0; }   // HUD::Draw returns at once when the byte is 0 or the dword is not 0
    const double fq = (double)qpc_freq();
    const int64_t t0 = qpc_now();
    o_hudDraw(overlay);
    double us = (double)(qpc_now() - t0) * 1.0e6 / fq;
    InterlockedIncrement(&g_he.draws[e]);
    if (lvl == 0) InterlockedIncrement(&g_he.levelOff[e]);
    if (f1e0 > 0) InterlockedIncrement(&g_he.flag1e0[e]);
    InterlockedIncrement(&g_he.bucket[e][us < 10 ? 0 : us < 30 ? 1 : us < 100 ? 2 : us < 300 ? 3 : 4]);
    if (us > g_he.maxUs[e]) g_he.maxUs[e] = us;
    const double other = g_he.ema[1 - e];
    const int empty = other > 40.0 && us < 0.2 * other;   // the other eye's HUD cost something; this one drew (almost) nothing
    if (empty) {
      InterlockedIncrement(&g_he.empty[e]);
      if (g_ctl.hudRetry) {   // ask the game's HUD draw once more for this eye (still inside the eye's placement)
        InterlockedIncrement(&g_he.retried[e]);
        // the game's own early-out flags were the reason and the other eye drew its HUD a moment ago: the flags are held at "draw" for this one call (put back right after)
        const int otherGood = g_he.goodQ[1 - e] && (double)(qpc_now() - g_he.goodQ[1 - e]) / fq < 0.12;
        volatile LONG* pf = (volatile LONG*)(wp + 0x1e0); volatile unsigned char* pl = (volatile unsigned char*)(wp + 0x3ada0);
        int forcedNow = 0;
        LONG origF = 0;
        if (wp && otherGood && f1e0 > 0) { origF = *pf; InterlockedExchange(pf, 0); forcedNow |= 1; }
        if (wp && otherGood && lvl == 0) { *pl = 1; forcedNow |= 2; }
        const int64_t t1 = qpc_now();
        o_hudDraw(overlay);
        const double us2 = (double)(qpc_now() - t1) * 1.0e6 / fq;
        if (forcedNow & 1) InterlockedCompareExchange(pf, origF, 0);   // the old value goes back, only if nobody changed it meanwhile
        if (forcedNow & 2) *pl = 0;
        if (forcedNow) { InterlockedIncrement(&g_he.forced[e]); if (us2 > 0.5 * other) InterlockedIncrement(&g_he.forcedHelped[e]); }
        if (us2 > 0.5 * other) InterlockedIncrement(&g_he.retryHelped[e]);
        if (InterlockedIncrement(&g_he.logged) <= 40) log_line("HUDEYE the %s eye's HUD came out EMPTY (%.0f us against %.0f us for the other eye; level-loaded flag %d, flag 1e0 %d): asked the game's HUD draw again, the second draw took %.0f us", e ? "RIGHT" : "LEFT", us, other, lvl, f1e0, us2);
      } else if (InterlockedIncrement(&g_he.logged) <= 40) log_line("HUDEYE the %s eye's HUD came out EMPTY (%.0f us against %.0f us for the other eye; level-loaded flag %d, flag 1e0 %d); hud_retry is off", e ? "RIGHT" : "LEFT", us, other, lvl, f1e0);
      const int64_t nq = qpc_now();
      if (g_ctl.probeData && g_he.shots < 4 && (!g_he.shotQ || (double)(nq - g_he.shotQ) / fq > 20.0)) { g_he.shotQ = nq; InterlockedIncrement(&g_he.shots); log_line("HUDEYE a picture of both eyes is saved (%ld of 4)", (long)g_he.shots); shot_request(); }
    } else { g_he.ema[e] = g_he.ema[e] <= 0.0 ? us : g_he.ema[e] * 0.97 + us * 0.03; if (us > 40.0) g_he.goodQ[e] = qpc_now(); }
  }
  flush_text();
  InterlockedExchange(&g_on, 0);
  reissue();
  InterlockedIncrement(&g_hs.placed);
  g_hs.lastEye = eye; g_hs.lastDx = xf.dx; g_hs.lastSx = xf.sx; g_hs.lastSy = xf.sy;
}

// 0.94 data: where the game's own health ring lands. The game projects the targeted ghost (ring+0x1A8..0x1B0, world feet) with its camera into its 1280x720 overlay space (ring+0x19C / +0x1A0);
// the ring is drawn with the engine's own rectangle, i.e. inside the picture of the eye that is being drawn, so it sits on the ghost as that eye sees it. These lines show the numbers.
static void ring_diag(void* ring, LONG nr, int placed) {
  static volatile LONG s_n;
  const LONG n = InterlockedIncrement(&s_n);
  if (!(n <= 12 || (n % 600) == 0)) return;
  const float* r = (const float*)ring;
  if (!ring || IsBadReadPtr(ring, 0x1C0)) return;
  const float* sx = (const float*)((const uint8_t*)ring + 0x19C);
  const float* wp = (const float*)((const uint8_t*)ring + 0x1A8);
  log_line("RING #%ld the game's health ring: on screen at %.0f,%.0f of 1280x720 (the picture centre is 640,360), ghost at %.1f,%.1f,%.1f ft, drawn in the eye picture=%d eye=%d (hud placed %d, ring hidden %d)", n, (double)sx[0], (double)sx[1], (double)wp[0], (double)wp[1], (double)wp[2], placed, g_hs.lastEye, (int)g_hs.placed, (int)g_ctl.ringMode);
  (void)r; (void)nr;
}

// 1.7.14: the ring is drawn only while there is something to show it on. The 1.7.12 log: the game keeps the ring object (its last ghost position, its last screen spot) after the target is gone, and
// the ring was drawn in every one of 28,643 ring draws - e.g. at screen position 355,3 for ghost -12.5,51.5,-64.5 for thousands of frames, or in the middle of the picture (640,360) with no ghost at all.
static int g_ringHooks;   // 1 installed, 0 not yet, <0 why not
static volatile LONGLONG g_ringNativeQ;   // when the game last had a focus of its own for the ring (a real lock, the PKE's target)
static struct { volatile LONG drawSkipped, drawPick, drawNative, drawPke, drawOff; } g_rd;   // the ring's draws by why they were allowed / skipped
// 1.7.106: the game's own ring on the screen? (placed in the eye picture, and its spot inside the 1280x720 overlay). The probe's round ring steps in only when it is not.
static volatile LONGLONG g_ogQ;
static struct { volatile LONG onScreen, offScreen, notPlaced; float lastX, lastY; } g_og;
static int ring_spot_ok(void* ring) {
  if (!ring || IsBadReadPtr(ring, 0x1C0)) return 0;
  const float* sx = (const float*)((const uint8_t*)ring + 0x19C);
  const float x = sx[0], y = sx[1];
  g_og.lastX = x; g_og.lastY = y;
  return x == x && y == y && x >= 0.0f && x <= 1280.0f && y >= 0.0f && y <= 720.0f;
}
long long hud_og_ring_age_ms() {
  const LONGLONG q = g_ogQ;
  if (!q) return -1;
  const long long d = (long long)(qpc_now() - q);
  return d < 0 ? 0 : d * 1000 / (long long)qpc_freq();
}
static int ring_draw_allowed() {
  const int flat = stereo_in_flat_mode();   // 1.7.82: a cutscene / menu / video is on the flat 2D screen: no ring over it (rules: hudmath.h ring_allowed, tested)
  const int probeRules = g_ctl.ringAssist && g_ringHooks == 1;
  const int pke = probeRules && !flat && engine_pke_item();
  const int pick = probeRules && !flat && !pke && fight_ring_pick(nullptr, nullptr, nullptr);
  const LONGLONG q = g_ringNativeQ;
  const int native = probeRules && !flat && q && qpc_now() - q < qpc_freq() / 5;
  const int ok = hud::ring_allowed(g_ctl.ringAssist, g_ringHooks == 1, flat, pke, pick, native);
  if (!ok) InterlockedIncrement(&g_rd.drawSkipped);
  else if (!probeRules) InterlockedIncrement(&g_rd.drawOff);
  else if (pke) InterlockedIncrement(&g_rd.drawPke);
  else if (pick) InterlockedIncrement(&g_rd.drawPick);
  else InterlockedIncrement(&g_rd.drawNative);
  return ok;
}
static void __fastcall hk_ring_draw(void* ring) {
  static volatile LONG s_probes;
  aim_ring_seen(ring);   // 0.68: the ghost the game has targeted (aim assist)
  if (g_ctl.probeData && s_probes < 6 && g_on) { const LONG n = InterlockedIncrement(&s_probes); if (n <= 6) stereo_ring_probe((int)n); }
  if (g_ctl.ringAssist && !health_og() && (health_ring_hidden() || (health_ghost_ring() && g_ctl.hbar))) { InterlockedIncrement(&g_hs.ringHidden); return; }   // 1.7.106: with og_health the game's own ring is the one shown; ring_mode / ghost_ring only matter with og_health=0   // 1.7.103: the round ring is drawn on the ghost by the probe; the flat HUD copy of it stays hidden
  if (!ring_draw_allowed()) { InterlockedIncrement(&g_hs.ringHidden); return; }   // 1.7.14: nothing to show it on   // 0.54 experiment: the ring is not drawn at all (0.77: the game's own ring stays on even with the bars inside the ghosts)
  if (g_on && g_onTid == GetCurrentThreadId()) {
    const LONG nr = InterlockedIncrement(&g_hs.ring);
    flush_text();
    InterlockedExchange(&g_on, 0);
    reissue();
    o_ringDraw(ring);
    flush_text();
    InterlockedExchange(&g_on, 1);
    reissue();
    ring_diag(ring, nr, 1);
    if (ring_spot_ok(ring)) { InterlockedExchange64(&g_ogQ, (LONGLONG)qpc_now()); InterlockedIncrement(&g_og.onScreen); } else InterlockedIncrement(&g_og.offScreen);   // 1.7.106
    return;
  }
  o_ringDraw(ring);
  if (ring_spot_ok(ring)) InterlockedExchange64(&g_ogQ, (LONGLONG)qpc_now());   // 1.7.180: with the HUD placement off the game's ring is still the ring: no second (mod) ring on top of it
  InterlockedIncrement(&g_og.notPlaced);   // 1.7.106: drawn the way the game draws it, not placed in the eye picture: not counted as on the screen
  ring_diag(ring, 0, 0);
}

// ---- 1.5 the game's own health ring on the ghost you look at ----------------------------------------------------------------------------------
// The ring is a HUD object (update 0x24D450, draw 0x24D810, see layout.h). It shows only when the player has a "focus" (a locked target, or the PKE's target)
// and the VR view never gets one (0 of 81,030 ring draws in the 1.3 log). While the ring's own update runs, two small getters it asks are answered here:
// the focus position (0xDE1F0) and the focus health (0xDE1E0), for the ghost damage.cpp picked (fight_ring_pick). Everything else - the fade, the sprite,
// the fill, hiding it again - is the game's own code. The getters answer for the ring update only (same thread, flag set), nothing else in the game sees it.
typedef void(__fastcall* PFN_RingUpdate)(void* ring, float dt);
typedef unsigned char(__fastcall* PFN_FocusPos)(void* player, float* out);
typedef float(__fastcall* PFN_FocusHealth)(void* player);
static PFN_RingUpdate o_ringUpdate;
static PFN_FocusPos o_focusPos;
static PFN_FocusHealth o_focusHealth;
static volatile LONG g_ringUpd;
static volatile LONG g_ringUpdTid;
static struct { volatile LONG updates, posAsked, posNative, posForced, posNoPick, healthAsked, healthNative, healthForced, healthNoPick; float lastPos[3], lastFrac; volatile LONG logged; } g_rf;

static void __fastcall hk_ring_update(void* ring, float dt) {
  InterlockedIncrement(&g_rf.updates);
  InterlockedExchange(&g_ringUpdTid, (LONG)GetCurrentThreadId());
  InterlockedExchange(&g_ringUpd, 1);
  o_ringUpdate(ring, dt);
  InterlockedExchange(&g_ringUpd, 0);
}
static int ring_mine() { return g_ringUpd && (DWORD)g_ringUpdTid == GetCurrentThreadId() && g_ctl.ringAssist; }
static unsigned char __fastcall hk_focus_pos(void* player, float* out) {
  const unsigned char r = o_focusPos(player, out);
  if (!ring_mine()) return r;
  InterlockedIncrement(&g_rf.posAsked);
  if (r) { InterlockedIncrement(&g_rf.posNative); g_ringNativeQ = qpc_now(); return r; }   // the game has its own target (PKE, a real lock): its answer stands
  float p[3];
  if (out && fight_ring_pick(p, nullptr, nullptr)) {
    out[0] = p[0]; out[1] = p[1]; out[2] = p[2];
    g_rf.lastPos[0] = p[0]; g_rf.lastPos[1] = p[1]; g_rf.lastPos[2] = p[2];
    InterlockedIncrement(&g_rf.posForced);
    return 1;
  }
  InterlockedIncrement(&g_rf.posNoPick);
  return r;
}
static float __fastcall hk_focus_health(void* player) {
  const float v = o_focusHealth(player);
  if (!ring_mine()) return v;
  InterlockedIncrement(&g_rf.healthAsked);
  if (v > -0.5f) { InterlockedIncrement(&g_rf.healthNative); return v; }   // the game has a health of its own (-1 = none)
  float f = 0;
  if (fight_ring_pick(nullptr, &f, nullptr)) {
    if (f < 0.0f) f = 0.0f;
    if (f > 1.0f) f = 1.0f;
    g_rf.lastFrac = f;
    InterlockedIncrement(&g_rf.healthForced);
    return f;
  }
  InterlockedIncrement(&g_rf.healthNoPick);
  return v;
}

static int same16(uint32_t r, const uint8_t* b) {
  const uint8_t* p = (const uint8_t*)rva(r);
  for (int i = 0; i < 16; ++i) if (p[i] != b[i]) return 0;
  return 1;
}

void hud_install() {
  if (g_hudHooks) return;
  if (!g_game.identityOK) { g_hudHooks = -1; return; }
  const uint8_t* call = (const uint8_t*)rva(layout::kRvaHudDrawCall);
  int callOK = call[0] == 0xe8 && (uintptr_t)(call + 5 + *(const int32_t*)(call + 1)) == rva(layout::kRvaHudDraw);
  int ok = same16(layout::kRvaD3DViewport, layout::kBytesD3DViewport) && same16(layout::kRvaHudDraw, layout::kBytesHudDraw) &&
           same16(layout::kRvaRingDraw, layout::kBytesRingDraw) && same16(layout::kRvaTextFlush, layout::kBytesTextFlush) && callOK;
  if (!ok) {
    g_hudHooks = -2;
    log_line("HUD placement not available (code does not match): the overlay is drawn as the game draws it");
    return;
  }
  struct { uint32_t r; void* hook; void** orig; } h[3] = {
    {layout::kRvaD3DViewport, (void*)hk_viewport, (void**)&o_viewport},
    {layout::kRvaHudDraw, (void*)hk_hud_draw, (void**)&o_hudDraw},
    {layout::kRvaRingDraw, (void*)hk_ring_draw, (void**)&o_ringDraw},
  };
  MH_STATUS s = MH_OK;
  for (auto& e : h) if (s == MH_OK) s = MH_CreateHook((void*)rva(e.r), e.hook, e.orig);
  if (s == MH_OK) for (auto& e : h) if (s == MH_OK) s = MH_EnableHook((void*)rva(e.r));
  if (s != MH_OK) for (auto& e : h) MH_DisableHook((void*)rva(e.r));
  g_hudHooks = s == MH_OK ? 1 : -3;
  log_line("HOOK overlay (viewport %x, HUD draw %x, health ring %x) status=%d: the 2D overlay %s", layout::kRvaD3DViewport,
           layout::kRvaHudDraw, layout::kRvaRingDraw, (int)s, g_hudHooks == 1 ? "can be placed for both eyes" : "is drawn as the game draws it");
  // 1.5: the ring's update and its two getters (each checked against the exe's bytes first)
  {
    const int okR = same16(layout::kRvaRingUpdate, layout::kBytesRingUpdate) && same16(layout::kRvaFocusPos, layout::kBytesFocusPos) &&
                    same16(layout::kRvaFocusHealth, layout::kBytesFocusHealth);
    if (!okR) { g_ringHooks = -2; log_line("HOOK ring-assist not installed (code does not match): the game's health ring shows only on a locked target"); return; }
    struct { uint32_t r; void* hook; void** orig; } h2[3] = {
      {layout::kRvaRingUpdate, (void*)hk_ring_update, (void**)&o_ringUpdate},
      {layout::kRvaFocusPos, (void*)hk_focus_pos, (void**)&o_focusPos},
      {layout::kRvaFocusHealth, (void*)hk_focus_health, (void**)&o_focusHealth},
    };
    MH_STATUS s2 = MH_OK;
    for (auto& e : h2) if (s2 == MH_OK) s2 = MH_CreateHook((void*)rva(e.r), e.hook, e.orig);
    if (s2 == MH_OK) for (auto& e : h2) if (s2 == MH_OK) s2 = MH_EnableHook((void*)rva(e.r));
    if (s2 != MH_OK) for (auto& e : h2) MH_DisableHook((void*)rva(e.r));
    g_ringHooks = s2 == MH_OK ? 1 : -3;
    log_line("HOOK ring-assist (ring update %x, focus position %x, focus health %x) status=%d: the game's own health ring %s", layout::kRvaRingUpdate, layout::kRvaFocusPos, layout::kRvaFocusHealth, (int)s2,
             g_ringHooks == 1 ? "can be put on the ghost you look at" : "shows only on a locked target");
  }
}

int hud_available() { return g_hudHooks == 1; }

void hud_eye_report();
void hud_report() {
  hud_eye_report();
  log_line("HUD mode=%d hooks=%d size=%d%% distance=%dcm drawCalls=%d placed=%d notEyeFrame=%d badParams=%d viewportsMoved=%d "
           "ringDraws=%d ringHidden=%d lastEye=%d lastShiftPx=%.1f lastScale=%.3f/%.3f", (int)g_ctl.hudMode, g_hudHooks,
           (int)g_ctl.hudSizePct, (int)g_ctl.hudDistanceCm, (int)g_hs.drawCalls, (int)g_hs.placed, (int)g_hs.notEye,
           (int)g_hs.badParams, (int)g_hs.viewports, (int)g_hs.ring, (int)g_hs.ringHidden, g_hs.lastEye, g_hs.lastDx, g_hs.lastSx, g_hs.lastSy);
}

void hud_eye_report() {
  log_line("HUDEYE hud_retry=%d | draws left=%ld right=%ld | EMPTY draws (the eye got no HUD while the other eye did) left=%ld right=%ld | asked again left=%ld right=%ld, of which the second draw helped left=%ld right=%ld (early-out flags held at draw-it for that call: left=%ld right=%ld, helped %ld/%ld) | level-loaded flag was 0: left=%ld right=%ld, flag 1e0 set: left=%ld right=%ld | "
           "draw time buckets (<10us / <30 / <100 / <300 / more) left=%ld/%ld/%ld/%ld/%ld right=%ld/%ld/%ld/%ld/%ld | typical us left=%.0f right=%.0f, slowest left=%.0f right=%.0f",
           (int)g_ctl.hudRetry, g_he.draws[0], g_he.draws[1], g_he.empty[0], g_he.empty[1], g_he.retried[0], g_he.retried[1], g_he.retryHelped[0], g_he.retryHelped[1], g_he.forced[0], g_he.forced[1], g_he.forcedHelped[0], g_he.forcedHelped[1], g_he.levelOff[0], g_he.levelOff[1], g_he.flag1e0[0], g_he.flag1e0[1],
           g_he.bucket[0][0], g_he.bucket[0][1], g_he.bucket[0][2], g_he.bucket[0][3], g_he.bucket[0][4], g_he.bucket[1][0], g_he.bucket[1][1], g_he.bucket[1][2], g_he.bucket[1][3], g_he.bucket[1][4],
           g_he.ema[0], g_he.ema[1], g_he.maxUs[0], g_he.maxUs[1]);
}

void ring_assist_report() {
  { static LONG s_onPrev, s_offPrev, s_npPrev;
    const LONG on = g_og.onScreen, off = g_og.offScreen, np = g_og.notPlaced;
    log_line("RINGOG og_health=%d (30 s window): the game's own health ring was drawn on the screen %ld times, with its spot outside the picture %ld times, not placed in the eye picture %ld times | last spot %.0f,%.0f of 1280x720 | last drawn on the screen %lld ms ago | the probe's round ring is the fallback only when the game's has not been on the screen for 0.3 s and a ghost or boss has the ring",
             (int)g_ctl.ogHealth, (long)(on - s_onPrev), (long)(off - s_offPrev), (long)(np - s_npPrev), (double)g_og.lastX, (double)g_og.lastY, hud_og_ring_age_ms());
    s_onPrev = on; s_offPrev = off; s_npPrev = np;
    long og = 0, fb = 0, none = 0; ring_fallback_counts(&og, &fb, &none);
    log_line("RINGOG frames (running total, both eyes): a ghost or boss had the ring and the game's own ring covered it %ld, the probe's round ring covered it (fallback) %ld, nobody had the ring %ld", og, fb, none); }
  log_line("RINGDRAW ring draws allowed: a ghost you look at %ld, the game's own lock %ld, the PKE's target %ld, probe ring off %ld | SKIPPED (nothing to show it on) %ld (1.7.14: before, the ring was drawn in every frame, also where no ghost was)", (long)g_rd.drawPick, (long)g_rd.drawNative, (long)g_rd.drawPke, (long)g_rd.drawOff, (long)g_rd.drawSkipped);
  log_line("RINGFORCE hooks=%d on=%d | ring updates=%ld | position asked=%ld (the game's own target %ld, put on the picked ghost %ld, nobody picked %ld) | health asked=%ld (own %ld, picked ghost's %ld, nobody %ld) | last ghost at %.1f,%.1f,%.1f ft, health %.0f%% | ring draws by the game=%d (hidden by setting: %d)",
           g_ringHooks, (int)g_ctl.ringAssist, (long)g_rf.updates, (long)g_rf.posAsked, (long)g_rf.posNative, (long)g_rf.posForced, (long)g_rf.posNoPick, (long)g_rf.healthAsked, (long)g_rf.healthNative, (long)g_rf.healthForced, (long)g_rf.healthNoPick,
           (double)g_rf.lastPos[0], (double)g_rf.lastPos[1], (double)g_rf.lastPos[2], (double)g_rf.lastFrac * 100.0, (int)g_hs.ring, (int)g_hs.ringHidden);
}

#endif
