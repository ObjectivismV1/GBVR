// 0.29 the game's 2D overlay (HUD) in the headset. Pure functions
// (tests/test_hud.cpp).
//
// The game draws its overlay (money, button prompts, the aiming circle,
// subtitles) into the same place of every frame. In the headset each eye sees
// its own part of the frame, so the overlay appeared at an infinite distance
// (both eyes looking parallel at it) and pieces near the frame edges were in
// one eye only. The probe draws the overlay into a smaller rectangle around the
// eye's own straight-ahead point, shifted sideways by the eye's offset:
//   - size: the overlay keeps its shape and spans 2*atan(a) horizontally,
//     a = tan(30 deg) * size% (60 degrees at 100 %), limited so that it stays
//     inside what both eyes see;
//   - depth: a point straight ahead of the head at distance D is seen by an
//     eye at sideways offset e (metres, left eye negative) at tan = -e / D,
//     so the overlay centre moves by that much (left eye: to the right).
// In frame pixels (frame W x H, half-FOV tangents tanH x tanV of the frame,
// centre cx = W/2, cy = H/2) every overlay pixel goes to
//   x' = cx + sx * (x - cx) + dx,   y' = cy + sy * (y - cy)
//   sx = a / tanH,  sy = (a * H / W) / tanV,  dx = (-e / D) / tanH * W / 2
// which the probe applies by changing the Direct3D viewport rectangle while
// the overlay is drawn (hud.cpp).
#pragma once
#include <stdint.h>
#include <math.h>

namespace hud {

struct Xf { double sx, sy, dx, dy, cx, cy; double a, b, shift; };

static const double kHalfWidth100 = 0.5773502692;  // tan(30 degrees)
static const double kMaxHalfWidth = 0.80, kMaxHalfHeight = 0.85;

// limW / limH (optional, > 0): the headset's smallest sideways / up-down
// half-view over both eyes (tangents); the overlay keeps 5 % inside them.
inline int make(int frameW, int frameH, double tanH, double tanV, double eyeXm, int sizePct, double distM, Xf* o,
                double limW = 0, double limH = 0) {
  if (frameW < 64 || frameH < 64 || !(tanH > 0.05 && tanH < 20) || !(tanV > 0.05 && tanV < 20)) return 0;
  if (!(distM >= 0.2 && distM <= 100) || !(eyeXm > -0.1 && eyeXm < 0.1) || sizePct < 10 || sizePct > 400) return 0;
  double maxW = kMaxHalfWidth, maxH = kMaxHalfHeight;
  if (limW > 0.2 && limW * 0.95 < maxW) maxW = limW * 0.95;
  if (limH > 0.2 && limH * 0.95 < maxH) maxH = limH * 0.95;
  double a = kHalfWidth100 * sizePct / 100.0;
  double shift = -eyeXm / distM;
  if (a + fabs(shift) > maxW) a = maxW - fabs(shift);
  if (a < 0.05) return 0;
  double b = a * (double)frameH / (double)frameW;
  if (b > maxH) { a *= maxH / b; b = maxH; }
  if (a > tanH) { b *= tanH / a; a = tanH; }      // never larger than the frame itself
  if (b > tanV) { a *= tanV / b; b = tanV; }
  o->a = a; o->b = b; o->shift = shift;
  o->cx = frameW * 0.5; o->cy = frameH * 0.5;
  o->sx = a / tanH;
  o->sy = b / tanV;
  o->dx = shift / tanH * frameW * 0.5;
  o->dy = 0;
  return 1;
}

// Round to the nearest whole pixel (halves up). 0.30: written out instead of
// floor() - in the cross-built DLL msvcrt's floor is only importable as data,
// and 0.29's calls to it went to the import table instead of the function
// (crash as soon as the overlay was placed). The link now refuses that case.
inline int round_i(double v) {
  if (!(v > -1e9)) v = -1e9;   // also catches NaN
  if (v > 1e9) v = 1e9;
  double f = v + 0.5;
  int i = (int)f;               // toward zero
  if ((double)i > f) --i;       // -> toward minus infinity
  return i;
}

// A viewport rectangle (left, top, width, height in frame pixels) as the
// engine asked for it -> the rectangle to give Direct3D.
inline void apply(const Xf& x, int L, int T, int W, int H, int* L2, int* T2, int* W2, int* H2) {
  double l = x.cx + x.sx * (L - x.cx) + x.dx, t = x.cy + x.sy * (T - x.cy) + x.dy;
  double r = x.cx + x.sx * (L + W - x.cx) + x.dx, b = x.cy + x.sy * (T + H - x.cy) + x.dy;
  *L2 = round_i(l);
  *T2 = round_i(t);
  *W2 = round_i(r) - *L2;
  *H2 = round_i(b) - *T2;
  if (*W2 < 1) *W2 = 1;
  if (*H2 < 1) *H2 = 1;
}

// 1.7.82: is the game's PKE / target ring drawn now? (The ring is part of the game's picture; on the flat 2D screen - cutscene, menu, video - it floated over the scene: seen in a
// YouTuber's video of the mod.) flatScreen -> never. Otherwise the 1.7.14 rules: with the probe's rules off the game decides; else only with something to show it on.
inline int ring_allowed(int ringAssist, int hooksOk, int flatScreen, int pkeOut, int pick, int nativeRecent) {
  if (flatScreen) return 0;
  if (!ringAssist || !hooksOk) return 1;
  return (pkeOut || pick || nativeRecent) ? 1 : 0;
}

}  // namespace hud
