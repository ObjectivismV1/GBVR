// 1.7.36 knockdown comfort: pure math (tests/test_knock.cpp).
// When a ghost knocks the player down, the game's fall animation (the camera is thrown about) is skipped. For the time the fall would have
// lasted there is instead: slower walking, dark edges (a comfort vignette) and a harder aim (the gun sways). All three follow one envelope.
#pragma once
#include "vmath.h"
namespace knock {
inline int expired(unsigned elapsedMs, unsigned durationMs) { return elapsedMs >= durationMs; }
// envelope 0..1 at `elapsedMs` of a window of `durMs`: rises over 120 ms, holds, fades over the last 40 %
inline double strength(double elapsedMs, double durMs) {
  if (!(durMs > 1.0) || !(elapsedMs >= 0.0) || elapsedMs >= durMs) return 0.0;
  double s = 1.0;
  if (elapsedMs < 120.0) s = elapsedMs / 120.0;
  const double fadeStart = durMs * 0.6;
  if (elapsedMs > fadeStart) s = s * (durMs - elapsedMs) / (durMs - fadeStart);
  return s < 0.0 ? 0.0 : s > 1.0 ? 1.0 : s;
}
// walking factor: 1 = normal, walkPct/100 at full strength
inline double walk_factor(double s, double walkPct) {
  double w = walkPct * 0.01; if (w < 0.1) w = 0.1; if (w > 1.0) w = 1.0;
  return 1.0 - s * (1.0 - w);
}
// aim sway in degrees (yaw, pitch): two slow, unrelated waves, scaled by the strength
inline void sway(double tSec, double s, double ampDeg, double* yaw, double* pitch) {
  const double a = ampDeg * s;
  double s1, c1, s2, c2, s3, c3, s4, c4;
  vm::dsincos(tSec * 5.1, &s1, &c1); vm::dsincos(tSec * 8.3 + 1.0, &s2, &c2);
  vm::dsincos(tSec * 4.3 + 2.0, &s3, &c3); vm::dsincos(tSec * 7.1, &s4, &c4);
  *yaw = a * (0.6 * s1 + 0.4 * s2);
  *pitch = a * (0.6 * s3 + 0.4 * s4);
}
}  // namespace knock
