// Ghostbusters: The Video Game Remastered - verified engine layout.
// Every value here was checked by static analysis of the user's ghost.exe
// (SHA-256 ea5edecb590ace8efa2274df354ad266ada95a3100dbe6cabc5a5fb34a225038,
// PE timestamp 0x5FA8FC04, SizeOfImage 0x31CB000) and matches the hook
// targets recorded in gbvr_render_probe(20261006-211914).log (probe 0.16).
//
// RVAs are only valid for that exact executable. The DLL refuses to install
// any engine hook unless the running module matches the identity below and
// every hook site still holds the expected bytes.
#pragma once
#include <stdint.h>

namespace layout {

// ---- Executable identity -------------------------------------------------
static const uint32_t kExpectedTimeDateStamp = 0x5FA8FC04u;
static const uint32_t kExpectedSizeOfImage   = 0x031CB000u;  // 52,211,712
// 0.96: the analysed ghost.exe as a file (15,854,592 bytes); the mod scan logs whether the running game is that file.
static const uint32_t kVanillaExeFileSize    = 0x00F1EC00u;
static const uint32_t kVanillaExeCrc32       = 0x2E738F86u;

// ---- Functions we hook ---------------------------------------------------
// Camera "prepare" (source camera vtable slot +0x40).
//   void __fastcall Prepare(Camera* camera /*rcx*/, RenderContext* ctx /*rdx*/)
//   Reads eye (+0x08), Euler pitch/yaw/roll (+0x14), FOV (+0x20),
//   viewport (+0x24..+0x30), projection mode (+0x34), then calls
//   SetOrientationFromEuler(camera+0x14) at 0x3019B0, which calls the basis
//   setter at 0x3019F0. Finally snapshots the prepared view into ctx+0x6A3C8.
static const uint32_t kRvaCameraPrepare   = 0x455010;
// Basis setter: void __fastcall SetCameraBasis(const float m[9] /*rcx*/)
//   Only argument is rcx (verified: rdx/r8/r9 are written before any read).
//   Copies the 3x3 basis into the global camera state at 0x236B96C.
static const uint32_t kRvaBasisSetter     = 0x3019F0;
// Visibility stage (vtable slot +0x48): void __fastcall(Camera*, RenderContext*)
//   Uses the prepared main view at ctx+0x6A3C8 to query the world and build
//   the visibility hull. Hooked for audit only (never modified).
static const uint32_t kRvaVisibilityStage = 0x450740;

// Eye setter: void __fastcall SetEye(const float eye[3] /*rcx*/), leaf; copies
//   to the global eye 0x236B954 used by the prepared-view snapshot. Prepare
//   calls it with camera+0x08 at 0x455070 (return 0x455075). 18 callers total.
static const uint32_t kRvaSetEye          = 0x3021C0;
// Main spatial query: void __fastcall(View* view /*rcx*/, const float eye[3] /*rdx*/)
//   copies eye to view+0x17F60 and finds the world sector containing it
//   (result view+0x17F6C). VisibilityStage calls it with camera+0x6C at
//   0x450777 (return 0x45077C). This is the portal/sector origin for culling.
static const uint32_t kRvaMainSpatial     = 0x42C620;

// Near/far setter: void __fastcall SetNearFar(float near /*xmm0*/, float far /*xmm1*/),
//   leaf; stores to globals 0x236EDA0 / 0x236EDA4. Prepare calls it at
//   0x455181 (return 0x455186) with near = min(FOV/23*0.25, 0.25) = 0.25 ft
//   (camera vtable +0x18, 0x1FF4E0) and far = clamp(..., 2048, 30000).
static const uint32_t kRvaSetNearFar      = 0x300EB0;

// Projection setter (0.21): void __fastcall SetProjection(float zoom /*xmm0*/, int mode /*edx*/)
//   Prepare calls it at 0x455067 (return 0x45506C) with zoom = camera FOV field
//   (+0x20, default 23) / 18 * global scale (0xDE54EC, 1.0) and mode = camera+0x34.
//   For mode 0 with aspect a = viewport width/height (> 4/3):
//     scaleY = 4/3 * zoom, scaleX = scaleY / a
//   stored as scaleX 0x236EDC4, scaleY 0x236EDD4, 1/scaleX 0x236BB54,
//   1/scaleY 0x236BB58. The renderer's projection matrix (0x3F5020, built in
//   the basis setter) is P[0][0] = scaleX, P[1][1] = scaleY, w = z, with no
//   off-centre terms, so the globals at 0x236BB54 / 0x236BB58 are exactly
//   tan(half horizontal FOV) and tan(half vertical FOV). Default: 1.043 /
//   0.587 at 16:9 (92.4 x 60.8 degrees). A larger zoom means a narrower view.
//   The basis setter scales the view matrix with the same values (culling)
//   and the prepared-view snapshot (0x42BF70) copies them, so one change here
//   reaches rendering and visibility together.
static const uint32_t kRvaSetProjection   = 0x302520;
// Direct scale setter (0.24, called, not hooked): void __fastcall SetScales(float scaleX /*xmm0*/,
//   float scaleY /*xmm1*/), leaf. Stores scaleX 0x236EDC4, 1/scaleX 0x236BB54, scaleY 0x236EDD4,
//   1/scaleY 0x236BB58 - the same four globals SetProjection writes, but with independent
//   horizontal and vertical values. The engine uses it itself when it restores a prepared view
//   (0x42C0E3, from the two values the snapshot 0x42BF70 saved).
static const uint32_t kRvaSetScales       = 0x302650;
// Frame tick / limiter (0.24): void __fastcall App::Tick(App* this, float fps /*xmm1*/),
//   application vtable 0x7BE9C0 slot +0x158. The main loop calls it once per frame with 30, 60
//   or 120 (0x1F05C8 / 0x1F0608). It calls the frame timer 0x2D9CF0, which busy-waits until
//   1/fps has passed since the previous tick and then derives the frame's time step from the
//   time that really elapsed.
static const uint32_t kRvaAppTick         = 0x1F1C40;
static const uint32_t kRvaAppVtable       = 0x7BE9C0;
// Frame timer 0x2D9CF0(App*, fps) in detail (0.27, "same moment for both eyes"):
//   minimum = 1179648 / fps (the timer's own units, 1179648 per second)
//   wait until now - app[+0x1AC] >= minimum; app[+0x1AC] = now
//   ticks = elapsed / 18              (1/65536 s)
//   ticks = min(ticks, [0xDD6748])    longest frame the game accepts; default 4096 = 1/16 s
//   [0x251E084] = ticks; time step = ticks / 65536 -> app[+0x1B8], [0x251E080], app[+0x1B0]
// App::Tick then multiplies the ticks by the game's own time scale (slow motion) and stores
// the result back to [0x251E084] and app[+0x1B0]. [0xDD6748] has no other per-frame reader.
// Main loop, one iteration (0x1F02A4 .. 0x1F0622, all on the main thread):
//   [vtable+0x160], 0x1F0E20, 0x1F1210        housekeeping
//   App::Simulate = [vtable+0x108] = 0x1F09C0  (call at 0x1F038A) - physics and the whole game update,
//                                              with the time step the PREVIOUS iteration's tick stored.
//                                              Not called at all while the game is paused (app[+0x4A9C1]).
//   0x3DDAC0                                   wait until the render thread finished the previous frame
//   0x1F1D00                                   camera prepare + scene traversal (the probe's eye is set here)
//   render job handed to the render thread     (it presents later; [0xDCF34F] = render in parallel)
//   App::Tick = [vtable+0x158]                 (call at 0x1F0608) frame timer: time step for the NEXT iteration
// So the time step measured by the tick that follows eye A's prepare is what moves the world before
// eye B is drawn. App::Simulate divides 1 by the step (0x1F0A71: physics rate = 2 * max(30, 1/step)),
// so a step of exactly zero must never reach it.
// The render job (0x1F9B70 -> 0x1F1E30: draw the prepared view, HUD, present) runs on a worker thread
// while the main thread already runs the next iteration's housekeeping and simulation; the main loop
// waits for it with WaitQueue(&RenderQueue) = 0x3DDAC0(0x1671938) before the next prepare (and in a few
// other places, e.g. 0x1F047F, 0x1F04B8). The wait only returns when the queue is empty; calling it
// again is harmless.
static const uint32_t kRvaWaitQueue       = 0x3DDAC0;
static const uint32_t kRvaRenderQueue     = 0x1671938;
static const uint32_t kRvaAppSimulate     = 0x1F09C0;
static const uint32_t kRvaAppSimulateRet  = 0x1F0390;  // return address of the main loop's call
static const uint32_t kAppPaused          = 0x4A9C1;   // byte in the App object (read-only for the probe)
// 0.43 menu frame rate. The App constructor (0x1ED181) sets app[+0x4A9C0] = 1 and app[+0x4A9BC] = 30.0f.
// App::Tick (0x1F1C40: cmp byte [rcx+0x4A9C0],0 / movss xmm1,[rcx+0x4A9BC]) then ignores the fps it was
// given and waits for 30 FPS. The main loop (0x1F05D0..0x1F060E) clears the byte for the duration of the
// tick only while the game is running normally (not paused, no menu: "sil"), so menus and the pause
// screen run at 30 FPS - 33.33 ms exactly in every 0.37-0.42 log (lockTo30Hz was 0 all the time).
static const uint32_t kAppFpsCapFlag      = 0x4A9C0;   // byte: 1 = App::Tick uses the cap below instead of its argument
static const uint32_t kAppFpsCapValue     = 0x4A9BC;   // float: 30.0
static const uint32_t kRvaFrameTimer      = 0x2D9CF0;
static const uint32_t kRvaMaxFrameTicks   = 0xDD6748;  // int, 4096
static const uint32_t kRvaFrameTicks      = 0x251E084; // int, this frame's ticks (1/65536 s)
static const uint32_t kAppLastTick        = 0x1AC;     // uint32 in the App object: time of the previous tick
static const uint32_t kAppRawStep         = 0x1B8;     // float: this frame's time step before the time scale (seconds)
static const uint32_t kAppStep            = 0x1B0;     // float: this frame's time step after the time scale
static const uint32_t kAppRealStep        = 0x1B4;     // float: real time since the previous tick, not limited (seconds; read by game behaviour callbacks)
static const uint32_t kTimerUnitsPerTick  = 0x12;     // 18 timer units = 1 tick
// Input (0.27 review): keys are read only inside App::Simulate (0x1F13B0 -> 0x1FC240: key bytes
// 0x2523F00 compared with the previous copy 0x1651E90). A key release (0x458D00, deferred while
// [0xDD6766] = 1, the default) and every mouse-wheel notch (0x458948: pseudo-keys 0x20F / 0x210 set
// down and release-pending in the same message) only mark the key in the int array 0x2A87180
// (600 entries, 1 = release pending). The input poll 0x45A450, called once per iteration at 0x1F03F1
// (after the camera prepare, before the render job is handed over), first releases every marked key
// and then pumps the window messages. So a release or wheel notch pumped in one iteration is seen by
// the NEXT simulation only; if that simulation were left out it would be lost. The probe therefore
// leaves the second eye's simulation out only while no key is marked (read-only check).
static const uint32_t kRvaKeyReleasePending = 0x2A87180;  // int[600], read only
static const uint32_t kKeyCount             = 0x258;     // 600
static const uint32_t kRvaInputPollCall     = 0x1F03F1;   // call 0x45A450 in the main loop
static const uint32_t kRvaInputPoll         = 0x45A450;

// ---- Call-site checks (return addresses) ----------------------------------
// Prepare is called from the camera render routine (vtable +0x38, 0x450DD0)
// at 0x450DF1; its return address is 0x450DF4. The visibility stage is
// called immediately after, returning to 0x450E00.
static const uint32_t kRvaPrepareReturn    = 0x450DF4;
static const uint32_t kRvaVisibilityReturn = 0x450E00;
// The basis setter call inside SetOrientationFromEuler returns to 0x3019DA.
static const uint32_t kRvaBasisReturn      = 0x3019DA;
static const uint32_t kRvaSetEyeReturn     = 0x455075;   // inside Prepare
static const uint32_t kRvaSpatialReturn    = 0x45077C;   // inside VisibilityStage
static const uint32_t kRvaNearFarReturn    = 0x455186;   // inside Prepare
static const uint32_t kRvaProjectionReturn = 0x45506C;   // inside Prepare

// ---- Data -----------------------------------------------------------------
static const uint32_t kRvaCameraVtable     = 0x7C2268;   // source camera class
static const uint32_t kRvaActiveCameraPtr  = 0xDCF990;   // Camera* g_activeCamera
static const uint32_t kRvaRenderContext    = 0x1671950;  // static render context
static const uint32_t kRvaGlobalBasis      = 0x236B96C;  // float[9] written by setter
static const uint32_t kRvaGlobalEye        = 0x236B954;  // float[3] used by snapshot
static const uint32_t kRvaGlobalNear       = 0x236EDA0;  // float near plane (far at +4)
static const uint32_t kRvaTanHalfFovH      = 0x236BB54;  // float, written by SetProjection (0x302632)
static const uint32_t kRvaTanHalfFovV      = 0x236BB58;  // float, written by SetProjection (0x302616)
// Byte flag read throughout the pause-menu code ("Pause menu is not running
// ..." report at 0x234560 tests it). Semantics not yet runtime-confirmed, so
// it is used only as a transition trigger and logged, never as a hard block.
static const uint32_t kRvaPauseMenuFlag    = 0x2229519;

// ---- Frame-rate limiter (read-only, logged) --------------------------------
// settings.ini keys lockTo30Hz / lockTo60Hz are loaded into these bytes
// (reader 0x240594, writer 0x240B55; defaults set at 0x1F4094: 30Hz on).
// Main loop 0x1F05B6: lockTo30Hz -> 30 FPS, else lockTo60Hz -> 60 FPS,
// else 120 FPS cap (constants 0x73776C=30.0, 0x73AF8C=60.0, 0x73AF90=120.0).
// settings.ini: %LOCALAPPDATA%\GHOSTBUSTERS\settings.ini (SHGetFolderPathW 0x1C, title cut
// at the first ":" by strtok at 0x241342; read/written with Get/WritePrivateProfileStringW).
static const uint32_t kRvaLockTo30Hz       = 0x2629D6E;  // uint8
static const uint32_t kRvaLockTo60Hz       = 0x2629D6F;  // uint8

// ---- DXGI factory (0.21.1) ---------------------------------------------------
// The game creates its DXGI factory with the DXGI 1.0 call CreateDXGIFactory
// (only DXGI import; call at 0x3F2C59, factory pointer stored at 0x265D460),
// enumerates the adapter from it (0x3F2D61) and passes that adapter to
// D3D11CreateDevice (0x3F2E12). Devices on a DXGI 1.0 factory cannot create
// keyed-mutex shared textures, which the SteamVR compositor needs to receive
// eye pictures (Submit fails with VRCompositorError_SharedTexturesNotSupported
// = 106, seen in the 0.21 test). The probe therefore points this import slot
// at a wrapper that returns a DXGI 1.1 factory (CreateDXGIFactory1), exactly
// the fix Valve recommends for this error.
static const uint32_t kRvaIatCreateDXGIFactory = 0x732DA8;  // import address table slot, dxgi.dll!CreateDXGIFactory

// ---- Overlay / HUD (0.29, hud.cpp) ------------------------------------------
// Render job (0x1F9B70 -> 0x1F1E30): the active camera's Draw (CGameView
// 0x1FE4D0) draws the 3D scene (0x451E10 at 0x1FE55D), all post-processing
// (0x41BE90 at 0x1FE5F1: bloom, depth of field, FXAA ...), the damage/goggles
// full-screen overlay (0x205660 at 0x1FE60A) and then the HUD: HUD::Draw
// 0x253240(COverlay*) at 0x1FE64D, its only call. Menus (0x2471F0) and the
// full-screen fade come later in 0x1F1E30. HUD::Draw lays nothing out (that
// happens on the main thread, 0x252680, in a virtual 1280 x 720 space scaled
// to the viewport); it flushes queued text (0x3D62E0) at its start and end and
// draws the element tree. Every sprite and text quad uses screen-space
// vertices in back-buffer pixels with the shaders tlvertex / v4bit:
// Pos.xy = (vPos.xy - cScreenCenter.xy) * cScreenCenter.zw (constant 29, from
// the engine viewport globals 0x236B920..0x236B92C, written by SetViewport
// 0x302200). The only Direct3D viewport setter is 0x3F5880(int x, y, w, h)
// (reached through the slot 0x2550778, filled at 0x3B811B): it caches the
// rectangle at 0x2840D60 and calls RSSetViewports under the critical section
// 0x2629D80. So a different Direct3D viewport during HUD::Draw moves and
// scales everything the overlay draws, including the subtitle boxes' own
// sub-viewports. The aiming reticle is a sprite at the fixed virtual point
// (640, 360) = the frame centre (0x251C81..0x251CAB). The targeted ghost's
// health ring (draw 0x24D810, vtable slot 0x7DED68) projects the ghost's 3D
// position with the current camera matrix at draw time: already right per eye.
static const uint32_t kRvaHudDraw      = 0x253240;
static const uint32_t kRvaHudDrawCall  = 0x1FE64D;  // e8 rel32 -> kRvaHudDraw
static const uint32_t kRvaD3DViewport  = 0x3F5880;
static const uint32_t kRvaViewportSlot = 0x2550778;
static const uint32_t kRvaViewportCache = 0x2840D60; // float x, y, w, h, minZ, maxZ of the last Direct3D viewport (read only)
static const uint32_t kRvaRingDraw     = 0x24D810;
static const uint32_t kRvaRingDrawSlot = 0x7DED68;
static const uint32_t kRvaTextFlush    = 0x3D62E0;

// ---- Own body in first person (0.28, engine_hooks.cpp "Own body") ------------
// The player is a CGhostbuster (vtable 0x774440). Its render function (actor
// slot +0xE8 = 0xD1D30 -> 0xD2030, called from the world traversal 0x479860 at
// 0x479CED) adds the body (gb_player.dfm, head included), the shadow-only
// mesh, the pack attachments, the wand (weap_proton_gun.smf) and the hose as
// separate render items. For each of them it asks the virtual "mirrors only"
// check, slot +0x8C0 = 0xD35D0 (vtable entry at 0x774D00), and stores the
// answer in the item's per-frame block. At draw time 0xEEC70 skips an item
// with that flag unless the view is a mirror view or the pass is the depth-only
// pass 8 (shadow maps, soft-particle depth). The game itself answers true only
// for the local player in the first-person PKE-goggles view (blend at
// +0x247C4 >= 1). Call sites (return addresses) of the check:
//   0xD2A66 body + shadow mesh (0xD2980)   0xD2C97 pack parts (0xD2B20)
//   0xD320F hose (0xD3150)                 0xD343F wand (0xD3340)
//   0x10B79C extra body pass (0x10B690), first item
//   0x10B800 extra body pass, second item (0.30)
//   (the PKE meter also asks it, at 0x141820 / 0x144D21 - never answered by the probe)
// The traversal runs inside the active camera's render call 0x450DD0
// (camera vtable +0x38: prepare 0x455010, visibility 0x450740, then +0x90 =
// 0x1FE2C0 -> 0x44F3A0 -> 0x479860), called by the main loop's 0x1F1D00 at
// 0x1F1E07 (return 0x1F1E0A) with the active camera [0xDCF990].
static const uint32_t kRvaCameraRender      = 0x450DD0;
static const uint32_t kRvaCameraRenderRet   = 0x1F1E0A;
static const uint32_t kRvaGhostbusterVtable = 0x774440;
static const uint32_t kRvaMirrorOnly        = 0xD35D0;
static const uint32_t kRvaMirrorOnlySlot    = 0x774D00;   // = vtable + 0x8C0
static const uint32_t kRvaMirrorOnlyRetBody = 0xD2A66;
static const uint32_t kRvaMirrorOnlyRetPack = 0xD2C97;
static const uint32_t kRvaMirrorOnlyRetHose = 0xD320F;
static const uint32_t kRvaMirrorOnlyRetWand = 0xD343F;
static const uint32_t kRvaMirrorOnlyRetBody2 = 0x10B79C;
static const uint32_t kRvaMirrorOnlyRetBody2b = 0x10B800;  // 0.30: second item of the extra body pass (missed in 0.28/0.29)
// The extra body pass 0x10B690 draws the body model's 'part_thigh_R_0x' piece
// (sub-mesh index actor+0xCE04, names at 0x73D658..) as two items with the draw
// callback 0x10F340; the first item asks the check at 0x10B796, the second at
// 0x10B7FA. Each stores the answer as a byte: block+0x11.
//
// 0.30 own shadow. The answer of the check is stored as a whole byte (al) in
// the item's per-frame block and read back only by these draw callbacks:
//   0xD2AC0 body/shadow mesh  movzx edx, byte [block+0x1C] -> call 0xEEC70
//   0xD2FC0 pack parts        movzx edx, byte [block+0x40] -> call 0xEEC70
//   0xD3290 hose              movzx edx, byte [block+0x14] -> call 0xEEC70
//   0xD3520 wand              movzx edx, byte [block+0x14] -> call 0xEEC70
//   0x10F340 extra body       cmp byte [block+0x11], 0 (same rule written inline)
// 0xEEC70(actor rcx, flag dl, drawCtx r8) is called from exactly these four
// places. Draw context: +0x00 pass (int), +0x68 item (item+0x78 = block),
// +0x80 view (view+0x180D8 != 0: mirror view). Pass 8 is the shadow-map pass
// (it also skips the light owner's own items: drawCtx+0x08 = light, light+0x198
// = owner). The game's rule for a flagged item: drawn in mirror views and in
// pass 8, nowhere else - so the player keeps a shadow. Pass 8 is set only by
// the light shadow-view renderer (0x4537A0, at 0x45390B). The probe answers 2
// instead of 1 for the player's own items when the shadow is to be hidden too;
// every reader only tests the byte for zero, so for the game 2 means the same
// as 1, and the two hooked readers below treat 2 as "mirror views only".
// Exception: hose (0xD3212) and wand (0xD3442) set their byte to 1 themselves
// while actor+0x24D78 > 0, a 0.1/0.25 s timer started when the PKE goggles are
// switched (0xE414E / 0xE41BC); for that moment their shadow is drawn.
static const uint32_t kRvaDrawPredicate     = 0xEEC70;   // hooked from 0.30 (only the value 2 is handled)
static const uint32_t kRvaBody2DrawCallback = 0x10F340;  // hooked from 0.30 (only the value 2 is handled)
static const uint32_t kRvaDrawPredicateCalls[4] = {0xD2AE0, 0xD2FED, 0xD32BF, 0xD354F};  // its only callers (e8 rel32)
static const uint32_t kDrawCtxPass   = 0x00;
static const uint32_t kDrawCtxItem   = 0x68;
static const uint32_t kItemDrawBlock = 0x78;
static const uint32_t kDrawCtxView   = 0x80;
static const uint32_t kViewMirror    = 0x180D8;
static const uint32_t kViewType      = 0x180C4;   // 1.7.30: the view's kind (3 = mirror view, 0 = the main picture ...); only read for the VIEWDRAW log
static const uint32_t kBody2BlockFlag = 0x11;
static const uint32_t kPassShadow    = 0x8;

// ---- Aim direction (0.32, head aim) --------------------------------------------
// Every actor class that fires has a unit vector "iAimDir" at actor+0xB584 (a
// network-history property; the string 'iAimDir' is at 0x753710, default
// {0,0,1} at 0xDD4F40). The game's player-aim code (0xD9FD0 .. 0xDBD00, strings
// 'processPlayerAim', 'processPlayerAim2', 'processPlayerAim3') smooths two
// angles, aimHeading (+0x24870) and aimPitch (+0x24898), turns them into a
// direction (Euler -> matrix 0x3DD40, forward row) and stores that direction
// every frame through
//   0x76DC0  void __fastcall Wrapper(actor rcx, const float v[3] rdx, label r8)
//            rcx += 0xB584; if v is not a unit vector or equals the stored one
//            nothing happens, otherwise it jumps to
//   0x76D20  void __fastcall SetAimField(float* field rcx /*actor+0xB584*/, const float v[3] rdx)
//            marks the property dirty, then stores the three floats.
// Only 0x76DC0 (8 call sites, all e8 rel32: 0xDA175 0xDACA2 0xDACBA 0xDAED5
// 0xDBA02 0xDBA1A 0xDBCDF 0xDFD5B) and one call in the actor set-up (0x70DB8)
// reach 0x76D20; the three jumps are in 0x76DC0 (0x76E48, 0x76E6C).
// Readers: the getter 0x76E80 (actor rcx, out vec3 rdx) has 17 callers. The
// proton stream update 0xE6360 reads it at 0xE659A (ret 0xE659F) and, with no
// lock-on target (actor+0xB550 == 0), ends the stream at
//   muzzle + aim * length ([0xDD2DD0]) - so the stream, its hit test and what the
// game counts as a hit all follow this one vector.
// 0.32 substitutes the head direction for the vector given to 0x76D20 (player
// actor only); the game's own calculation, smoothing and lock-on stay as they
// are, and the game decides what the shot hits.
// ---- Gamepad (0.33) ----------------------------------------------------------
// The game imports XINPUT1_3.dll by ordinal. Import address table slots
// (verified in the exe's import directory): ordinal 2 XInputGetState,
// 3 XInputSetState, 4 XInputGetCapabilities. The pad is detected by the
// function at 0x45D7B0 (GetCapabilities, then GetState).
static const uint32_t kRvaIatXInputGetState  = 0x732D78;
static const uint32_t kRvaIatXInputSetState  = 0x732D80;
static const uint32_t kRvaIatXInputGetCaps   = 0x732D88;
static const uint32_t kRvaPadDetect          = 0x45D7B0;
// 1.7.92 DirectInput pads. The game opens DirectInput game controllers at start (0x45D690, one per slot) and then does NOT ask XInput for a slot that has one: the scan
// 0x460480 skips XInputGetState when the slot's device pointer is non-zero. kRvaPadDisconnect(slot) is the game's own "pad gone" function: it clears the slot (0x6C0 bytes)
// and its XInput flag; it does not close the DirectInput device (only the game's shutdown does: Unacquire = vtable +0x40, Release = +0x10, pointer = 0).
static const uint32_t kRvaPadScan       = 0x460480;
static const uint32_t kRvaPadDisconnect = 0x45DE00;
static const uint32_t kRvaDiDevices     = 0x2A92648;   // IDirectInputDevice8* [4]
static const uint32_t kRvaDiGuids       = 0x2A92670;   // GUID [4]: instance GUID of the device each slot opened (the enumeration callback skips ones already used)
static const uint32_t kRvaPadXFlags     = 0x2A8AAC8;   // uint8 [4]: 1 = this slot is read through XInput (set at the end of the detection 0x45D7B0)
static const uint8_t kBytesPadDisconnect[16] = {0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x57,0x48,0x83,0xec,0x20,0x48};
static const uint8_t kBytesPadScan[16]       = {0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c,0x24,0x10,0x48,0x89,0x74,0x24,0x18,0x57};

// ---- Proton wand tip (0.34) --------------------------------------------------
// 0xD3C90(actor, float out[16], name) returns the world matrix (row-major 4x4,
// translation = floats 12..14) of the named attachment of a Ghostbuster's
// model (bone matrix x actor world matrix at actor+0x24718). The proton
// stream update 0xE6360 asks for "tip" (string 0x76B4D4) at 0xE63F7 and uses its
// translation as the start of the stream (muzzle, [rbp+0x3D0..] in that
// function). Other callers: 0xCBB38, 0xE2D41, 0xE2E88, 0xE78E0, 0xE833F.
// 0.35 input probe: the game's button getters over the control array behind the
// pointer at 0xDD36D8 (0x297160 = pressed-once, 0x297230 = held-since-edge,
// 0x297290 = held); control numbers 0 Y, 1 B, 2 A, 3 X, 4 LT, 5 RT, 6 LB, 7 RB.
static const uint32_t kRvaBtnPressed = 0x297160;
static const uint32_t kRvaBtnHeld2 = 0x297230;
static const uint32_t kRvaBtnHeld = 0x297290;
static const uint32_t kRvaBtnArrayPtr = 0xDD36D8;
static const uint32_t kRvaPadArray = 0x2A88EF0;
static const uint32_t kPadStride = 0x6C0;
static const uint8_t kBytesBtnPressed[16] = {0x80,0x3d,0xb2,0x23,0xf9,0x01,0x00,0x74,0x0c,0x80,0x3d,0xb0,0x9a,0xb3,0x00,0x00};
static const uint8_t kBytesBtnHeld2[16]   = {0x80,0x3d,0xe2,0x22,0xf9,0x01,0x00,0x74,0x0c,0x80,0x3d,0xe0,0x99,0xb3,0x00,0x00};
static const uint8_t kBytesBtnHeld[16]    = {0x48,0x8b,0x05,0x41,0xc4,0xb3,0x00,0x48,0x63,0xca,0x83,0xbc,0x88,0x38,0x01,0x00};
// 0.36 controller type: the settings object behind the pointer at 0xDCF680 keeps the controller type at
// +0x49200 (0 mouse+keyboard, 1 gamepad); setter 0x1F4D50(this, 0, type). With type 0 the game does not
// read the pad during play at all (shown by the 0.35.1 pad-memory watch).
static const uint32_t kRvaSettingsObjPtr = 0xDCF680;
static const uint32_t kRvaSetControllerType = 0x1F4D50;
static const uint32_t kRvaGetControllerType = 0x1F4D40;
static const uint32_t kOffControllerType = 0x49200;
static const uint8_t kBytesSetControllerType[16] = {0x40,0x55,0x56,0x41,0x56,0x48,0x83,0xec,0x20,0x8b,0xa9,0x00,0x92,0x04,0x00,0x45};
static const uint8_t kBytesGetControllerType[16] = {0x8b,0x81,0x00,0x92,0x04,0x00,0xc3,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc};
// 1.7.8 the character update the game runs once per game tick for every character (CGhostbuster's slot 2 is a jump to it, 0xED0E0): 0x84390(this, float dt). It ends in the base character
// update 0x2d3ef0(this, dt) that moves the character. The sprint speed boost wraps it for the player only. The player's physics body hangs at +0xB658 (the debug text 'Velocity %.2f ft/s'
// reads its velocity at body+0x170; body+0x90 is its position, body+0xE0..0x12F its transform).
static const uint32_t kRvaCharUpdate = 0x84390;
static const uint8_t kBytesCharUpdate[16] = {0x48,0x89,0x5c,0x24,0x18,0x48,0x89,0x6c,0x24,0x20,0x56,0x57,0x41,0x56,0x48,0x81};
static const uint32_t kOffCharBody = 0xB658;
static const uint32_t kBodyVel = 0x170;
static const uint32_t kBodyPos = 0x90;
static const uint32_t kBodyXformPos = 0x110;
// 0.40 binding update: 0x1FC240(block, dt) fills the state of the 50 bindings; queries read it.
static const uint32_t kRvaBindUpdate = 0x1FC240;
static const uint8_t kBytesBindUpdate[16] = {0x48,0x8b,0xc4,0x57,0x48,0x81,0xec,0x90,0x00,0x00,0x00,0x48,0x89,0x58,0x08,0x48};
static const uint32_t kRvaBindQ0 = 0x1FC5C0;
static const uint8_t kBytesBindQ0[16] = {0x48,0x63,0xc2,0x48,0x8d,0x14,0x40,0x8b,0x04,0xd1,0xff,0xc8,0xa9,0xfd,0xff,0xff};
static const uint32_t kRvaBindQ1 = 0x1FC5F0;
static const uint8_t kBytesBindQ1[16] = {0x48,0x63,0xc2,0x48,0x8d,0x14,0x40,0x8b,0x04,0xd1,0xff,0xc8,0xa9,0xfd,0xff,0xff};
static const uint32_t kRvaBindQ2 = 0x1FC620;
static const uint8_t kBytesBindQ2[16] = {0x48,0x63,0xc2,0x48,0x8d,0x14,0x40,0x8b,0x04,0xd1,0xff,0xc8,0xa9,0xfd,0xff,0xff};
// 0.89 release-a-binding: 0x1FC680(block, index) clears the keyboard/pad state of one binding. For a keyboard binding (kind 3) it uses the code at +4 as an index
// into a 600-entry table and the game's C runtime kills the process on purpose (fast-fail 8) when the code is 600 or more (0.88 log, after the cutscene).
static const uint32_t kRvaBindRelease = 0x1FC680;
static const uint8_t kBytesBindRelease[16] = {0x48,0x89,0x5C,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x57,0x48,0x83,0xEC,0x20,0x48};
// 1.7.140 Steam achievements / stats: 0x44C040(int id) unlocks one through the manager at 0x2A867B0. The manager is only made when SteamAPI_Init worked
// (0x44C080; it fails when the game is started outside Steam, e.g. ghost.exe opened directly): then the pointer is null and the first achievement the game
// gives crashes it (read of address 8 at ghost.exe+0x50376A; two crashes in Keith's 1.7.139 report, both "launchedBySteam=0").
static const uint32_t kRvaStatsUnlock = 0x44C040;
static const uint8_t kBytesStatsUnlock[16] = {0x48,0x83,0xec,0x28,0x8b,0xd1,0x48,0x8b,0x0d,0x63,0xa7,0x63,0x02,0xe8,0x0e,0x77};
static const uint32_t kRvaStatsManager = 0x2A867B0;
static const uint32_t kRvaAttachMatrix = 0xD3C90;
static const uint32_t kRvaTipCallers[6] = {0xCBB38, 0xE2D41, 0xE2E88, 0xE63F7, 0xE78E0, 0xE833F};
static const uint32_t kRvaTipString = 0x76B4D4;
// 0.51 the wand is its own model instance (actor+0xD728, collector 0xD3340 -> draw callback 0xD3520) drawn with the world
// matrix at actor+0x24718 (4x4 floats, row vectors, translation = row 3). The render pass multiplies that matrix with
// the view matrix by calling the matrix product 0x17210(A, out, B) = A x B from 0xD2470 (return address 0xD2475), then
// pushes the product on the draw context's matrix stack. The "tip" attachment is tipLocal x actor+0x24718 (0xD3CE3).
// The hose (instance 0xD7B0, matrix 0x24758, collector 0xD3150, callback 0xD3290) is left alone.
static const uint32_t kRvaMatMul = 0x17210;
static const uint8_t kBytesMatMul[16] = {0x48,0x83,0xec,0x48,0xf3,0x41,0x0f,0x10,0x18,0xf3,0x0f,0x10,0x69,0x10,0xf3,0x0f};
static const uint32_t kRvaWandPushCall = 0xD2470;   // e8 rel32 -> kRvaMatMul
static const uint32_t kRvaWandPushRet = 0xD2475;
static const uint32_t kOffWandWorld = 0x24718;
static const uint32_t kOffHoseWorld = 0x24758;
// 0.52 the other world matrices the player's render function multiplies with the view (same product 0x17210):
//   0xD213F  body base: a stack matrix built from the actor's basis (+0xF4..) and position (+0x54)   returns to 0xD2144
//   0xD2384  extras (pack ...): actor+0x246d8                                                         returns to 0xD2389
//   0xD257F  hose: actor+0x24758                                                                      returns to 0xD2584
static const uint32_t kRvaBodyPushCall   = 0xD213F;
static const uint32_t kRvaBodyPushRet    = 0xD2144;
static const uint32_t kRvaExtrasPushCall = 0xD2384;
static const uint32_t kRvaExtrasPushRet  = 0xD2389;
static const uint32_t kRvaHosePushCall   = 0xD257F;
static const uint32_t kRvaHosePushRet    = 0xD2584;
static const uint32_t kOffExtrasWorld    = 0x246d8;
// 0.45: the proton stream update turns the hit point into the tip's own frame (inverse tip matrix), asks this
// function for its two angles (heading = atan2(x,z), pitch = -atan2(y,hypot(x,z))), limits them (30 degrees fade,
// 60 degrees zero) and builds the stream end from them in the tip frame. +Z of that frame is row 2 of the tip matrix.
static const uint32_t kRvaVecToAngles = 0x31FFC0;
static const uint32_t kRvaStreamAnglesReturn = 0xE6BEE;   // return address of the call to kRvaVecToAngles inside the stream update
static const uint32_t kRvaAimFieldSet  = 0x76D20;
static const uint32_t kRvaAimWrapper   = 0x76DC0;
static const uint32_t kRvaAimGetter    = 0x76E80;
static const uint32_t kRvaAimStreamRead = 0xE659A;  // e8 rel32 -> kRvaAimGetter, in the proton stream update
static const uint32_t kRvaAimWrapperCalls[8] = {0xDA175, 0xDACA2, 0xDACBA, 0xDAED5, 0xDBA02, 0xDBA1A, 0xDBCDF, 0xDFD5B};
static const uint32_t kAimDirOffset    = 0xB584;   // float[3] unit vector (iAimDir)
// 1.7.10 stream hit point (disassembly of the stream update 0xE6360, no lock-on target): the stream's end is hit = (the "view" object's virtual +0x168 result) when 0xDBD10(actor)
// is true, else muzzle + (aim getter result) * length [0xDD2DD0]; with the byte at actor+0xC7E0 set it is the tip matrix's own forward (row 2) instead. The 1.7.9 log: the hit was 75 degrees
// off the barrel on average and the stream left the muzzle sideways. Both reads are put on the barrel line (hk_aim_getter / hk_view_hit in engine_hooks.cpp).
// 1.7.19 the capture stream's wrangle step of the player (CGhostbuster::processWrangling, called once from the player update at 0xD890C): it does nothing unless the lock target (player+0x2E8) and the wrangle beam
// (player+0x24D80) are both set. The game's lock candidates include CPhysicsObject / CAniModel / CGlass / CBoneSimActor (props). Hooked to let go of a lock that is not an enemy right before it runs.
// 1.7.27 the proton stream update (0xE6360, one caller at 0xCAEB2: rcx = player, xmm1 = dt). With [player+0xB550] (the HUD) set it ends the stream at a point the HUD gives (0xE67FA); with it 0 it uses the camera view's crosshair
// hit or muzzle + aim * length (the paths hk_view_hit / hk_aim_getter put on the barrel line). The probe hides the HUD pointer only while this function runs and puts it back afterwards (hk_stream_update).
static const uint32_t kRvaStreamUpdate = 0xE6360;
static const uint8_t kBytesStreamUpdate[16] = {0x48,0x8b,0xc4,0x55,0x56,0x57,0x48,0x8d,0xa8,0xc8,0xfa,0xff,0xff,0x48,0x81,0xec};
static const uint32_t kRvaWrangle = 0xDEDA0;
static const uint8_t kBytesWrangle[16] = {0x4c,0x8b,0xdc,0x55,0x53,0x49,0x8d,0xab,0x98,0xfd,0xff,0xff,0x48,0x81,0xec,0x58};
// 1.7.24 the slam entry (disassembly of the player update at 0xD8596, beam mode 4): with the capture beam in mode 4 (player+0x24D80 -> +0x170), the action mask's fire bits set and no slam running, the
// game calls TryEnterSlam (0xDE390): if the slam meter (player+0x24A40) >= the threshold at RVA 0xDCD278 (0.25) it calls EnterSlam (0xDE410, dl=1) which sets the flag at player+0x24A48 and takes 0.25 off the meter.
static const uint32_t kRvaTrySlam = 0xDE390;
static const uint8_t kBytesTrySlam[16] = {0x40,0x53,0x48,0x83,0xec,0x20,0x48,0x8b,0xd9,0xe8,0x32,0x00,0x00,0x00,0x84,0xc0};
static const uint32_t kOffBeamPtr = 0x24D80, kOffBeamMode = 0x170, kOffBeamSub = 0x174;   // the CProtonBeam; mode 0 idle, 2 proton stream, 3 ending, 4 capture stream (wrangle)
static const uint32_t kOffSlamMeter = 0x24A40, kOffSlamFlag = 0x24A48, kRvaSlamLimit = 0xDCD278;
static const uint32_t kOffStreamView   = 0x24FD8;   // actor -> the object whose virtual +0x168 gives the game's hit point (the camera's crosshair ray hit)
static const uint32_t kOffViewHitSlot  = 0x168;     // vtable offset of that virtual function
static const uint32_t kRvaStreamViewHitRet = 0xE6755;   // return address of the `call [rax+0x168]` at 0xE674F in the stream update (ff 90 68 01 00 00)
static const uint32_t kRvaStreamViewHitCall = 0xE674F;
static const uint32_t kRvaStreamHitAimCall = 0xE6778;   // e8 rel32 -> kRvaAimGetter: the aim read that builds muzzle + aim * length
static const uint32_t kRvaStreamHitAimRet  = 0xE677D;
static const uint8_t kBytesAimGetter[16] = {0x40,0x53,0x48,0x83,0xec,0x20,0x8b,0x81,0x84,0xb5,0x00,0x00,0x48,0x8b,0xda,0x89};   // 0x76E80: reads actor+0xB584..
static const uint32_t kOffStreamEuler  = 0xC7E0;    // byte: set = the stream follows the tip matrix's own forward

// ---- Display modes / picture size (0.26, modes.cpp) -------------------------
// EnumerateAdapters 0x3F0C10 (reached through the callback slot 0x2550718,
// thunk 0x3B7DA0) fills one 0x190-byte record per adapter output:
//   +0x80/+0x84  desktop width/height (GetMonitorInfo of the output)
//   +0x88        up to 32 {width,height} pairs   +0x188  their count
// The pairs come from IDXGIOutput::GetDisplayModeList(format [0xDDA1BC], 0):
//   0x3F0E8F  call [rax+0x40]   count query (pDesc = NULL)
//   0x3F0ED5  call [r10+0x40]   fill
// keeping distinct sizes of at least 640 x 480, the last 32 of them. These are
// the only two GetDisplayModeList calls in the executable.
// Three places then pick a size with the same code: start-up 0x3B7DD0
// (0x3B7E3C..), the options menu's monitor/apply path 0x301800, and the
// window/device routine 0x48A550 (0x48A7D0.., runs last at start-up and when a
// resolution is picked in the options). Each takes the entry equal to the
// wanted size in 0xDD674C/0xDD6750 (from the game's settings / menu), else
// the entry equal to the desktop size, else entry 0, stores it back into
// 0xDD674C/0xDD6750 and calls InitDevice 0x3F2CE0. InitDevice creates the swap
// chain with that back-buffer size (no clamping; Windowed = 1, DISCARD, two
// buffers) or, when it exists, calls SetResolutionBorderlessWindow 0x3EE780:
// ResizeBuffers(width,height) and SetWindowPos to the monitor rectangle - the
// window covers the monitor and DXGI stretches the back buffer into it.
// (With runWindowed=1 in the game's settings, 0xDD6758 != 0, the game instead
// sizes a normal window from its own saved size and the list is not used.)
// The perspective's aspect ratio is width/height of 0xDD674C/0xDD6750
// (0x2FA4C0). The exclusive-fullscreen routine 0x3EEA10 has no callers.
// Hard limit: 0x2FD160 writes one entry per picture line into two 1440-entry
// tables at 0x251E090 / 0x2520D90 (cleared by 0x302B10); more than 2880 lines
// would overwrite the variables behind them (picturemath.h kMaxLines).
static const uint32_t kRvaModeListCallCount   = 0x3F0E8F;  // ff 50 40
static const uint32_t kRvaModeListReturnCount = 0x3F0E92;
static const uint32_t kRvaModeListCallFill    = 0x3F0ED5;  // 41 ff 52 40
static const uint32_t kRvaModeListReturnFill  = 0x3F0ED9;
static const uint8_t kBytesModeListCallCount[3] = {0xff, 0x50, 0x40};
static const uint8_t kBytesModeListCallFill[4]  = {0x41, 0xff, 0x52, 0x40};
static const uint32_t kRvaWantedWidth  = 0xDD674C;  // int, read-only for the probe
static const uint32_t kRvaWantedHeight = 0xDD6750;  // int
static const uint32_t kRvaRunWindowed  = 0xDD6758;  // int, != 0 = the game's "runWindowed" mode (logged)
static const uint32_t kRvaLineTable    = 0x251E090; // 2 x 1440 qwords (see above)
static const uint32_t kRvaLineTableEnd = 0x2523A90;

// ---- Mouse (0.26, mouse.cpp) --------------------------------------------------
// The game installs a WH_GETMESSAGE hook (0x457D60) that passes every removed
// message to HandleMessage(MSG*) 0x4586A0. For WM_MOUSEMOVE (0x4587A1) and the
// button messages (0x45B450) it stores the low/high word of lParam - window
// client pixels - in 0x25241BC / 0x25241C0; for WM_MOUSEWHEEL it converts the
// screen position with ScreenToClient first (0x458969). Those two variables
// are then used as picture pixels (pointer sprite 0x20BB8C, menu hit tests
// 0x3BA5C9 ..). SetCursor(x, y) 0x45CB50 stores x, y in the same variables and
// moves the Windows pointer with ClientToScreen (call at 0x45CB7D through the
// import slot 0x7329A0) + SetCursorPos. Mouse look uses DirectInput
// (GetDeviceState, 0x45EF92), not these positions.
static const uint32_t kRvaHandleMessage      = 0x4586A0;
static const uint32_t kRvaHandleMessageRet   = 0x457D85;  // return address of its only call
static const uint32_t kRvaIatClientToScreen  = 0x7329A0;  // import slot, user32.dll!ClientToScreen
static const uint32_t kRvaSetCursorC2SReturn = 0x45CB83;  // return address of SetCursor's ClientToScreen call
static const uint32_t kRvaMouseX             = 0x25241BC; // int (not written by the probe)
static const uint32_t kRvaMouseY             = 0x25241C0;

// ---- Camera object fields (offsets from Camera*) ---------------------------
static const uint32_t kCamEye      = 0x08;  // float[3]
static const uint32_t kCamEuler    = 0x14;  // float pitch, yaw, roll (radians)
static const uint32_t kCamFov      = 0x20;  // float degrees
static const uint32_t kCamViewport = 0x24;  // float x, y, w, h
static const uint32_t kCamProjMode = 0x34;  // int, 0 = perspective (all samples)
static const uint32_t kCamEyeCopy  = 0x6C;  // float[3], eye used by the main spatial query
// Third-person pivot camera (verified in the standard-mode update 0x2023A9):
//   pivot(+0x240) = target(+0x210)->pos(+0x54) + rotated(offset +0x28C,
//   height +0x290, +0x294); eye = pivot - forward * distance(+0x24C).
//   Tuning defaults: Standard Distance 4.5, Pivot Height 5.5, Pivot Offset 1.75
//   (game units are feet). Read-only for the probe.
static const uint32_t kCamFollowTarget = 0x210;  // actor*
static const uint32_t kCamPivot        = 0x240;  // float[3]
static const uint32_t kCamDistance     = 0x24C;  // float
static const uint32_t kCamDistTarget   = 0x2F4;  // float: the distance the camera spring is heading for (0.75: read only, to tell a wall pulling the camera in from the aim zoom)
static const uint32_t kActorPos        = 0x54;   // float[3] world position of the actor
static const uint32_t kViewSpatialEye  = 0x17F60; // float[3] inside the prepared view

// ---- Expected first bytes at each hook site --------------------------------
static const uint8_t kBytesCameraPrepare[16] = {
  0x40,0x53,0x56,0x57,0x48,0x83,0xec,0x70,0x48,0x89,0x0a,0x48,0x8b,0xda,0xf3,0x0f };
static const uint8_t kBytesBasisSetter[16] = {
  0x48,0x8b,0xc4,0x53,0x56,0x57,0x48,0x81,0xec,0xe0,0x00,0x00,0x00,0x0f,0x29,0x70 };
static const uint8_t kBytesSetEye[16] = {
  0xf3,0x0f,0x10,0x01,0xf3,0x0f,0x11,0x05,0x88,0x97,0x06,0x02,0xf3,0x0f,0x10,0x49 };
static const uint8_t kBytesMainSpatial[16] = {
  0x40,0x53,0x48,0x83,0xec,0x20,0x4c,0x8b,0xc2,0x48,0x8b,0xd9,0x48,0x8d,0x91,0x60 };
static const uint8_t kBytesSetNearFar[16] = {
  0xf3,0x0f,0x11,0x05,0xe8,0xde,0x06,0x02,0xf3,0x0f,0x11,0x0d,0xe4,0xde,0x06,0x02 };
static const uint8_t kBytesSetProjection[16] = {
  0x40,0x53,0x48,0x83,0xec,0x60,0x83,0x3d,0xb7,0x01,0x07,0x02,0x00,0x8b,0xda,0x0f };
static const uint8_t kBytesSetScales[16] = {
  0xf3,0x0f,0x10,0x1d,0x64,0x28,0x43,0x00,0x0f,0x28,0xd3,0xf3,0x0f,0x11,0x05,0x61 };
static const uint8_t kBytesAppSimulate[16] = {
  0x40,0x53,0x48,0x83,0xec,0x20,0xf3,0x0f,0x10,0x05,0x82,0x38,0x33,0x02,0x48,0x8b };
static const uint8_t kBytesAppTick[16] = {
  0x40,0x53,0x48,0x83,0xec,0x20,0x80,0xb9,0xc0,0xa9,0x04,0x00,0x00,0x48,0x8b,0xd9 };
static const uint8_t kBytesHandleMessage[16] = {
  0x40,0x53,0x48,0x83,0xec,0x20,0x8b,0x41,0x08,0x48,0x8b,0xd9,0x3d,0x00,0x02,0x00 };
static const uint8_t kBytesD3DViewport[16] = {
  0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c,0x24,0x10,0x48,0x89,0x74,0x24,0x18,0x57 };
static const uint8_t kBytesHudDraw[16] = {
  0x48,0x89,0x4c,0x24,0x08,0x53,0x55,0x56,0x57,0x41,0x54,0x41,0x55,0x41,0x56,0x41 };
static const uint8_t kBytesRingDraw[16] = {
  0x40,0x53,0x48,0x83,0xec,0x30,0x48,0x8b,0xd9,0x48,0x8d,0x91,0xc0,0x01,0x00,0x00 };
static const uint8_t kBytesTextFlush[16] = {
  0x40,0x53,0x48,0x83,0xec,0x20,0x33,0xdb,0x39,0x1d,0x32,0x29,0x19,0x02,0x7e,0x2c };
static const uint8_t kBytesCameraRender[16] = {
  0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x20,0x48,0x8b,0xf9,0x48,0x8b,0xda };
static const uint8_t kBytesMirrorOnly[16] = {
  0x40,0x53,0x48,0x83,0xec,0x20,0x48,0x8b,0xd9,0xe8,0x22,0xa0,0x20,0x00,0x84,0xc0 };
static const uint8_t kBytesDrawPredicate[16] = {
  0x45,0x8b,0x08,0x41,0x83,0xf9,0x08,0x75,0x15,0x49,0x8b,0x40,0x08,0x48,0x85,0xc0 };
static const uint8_t kBytesBody2DrawCallback[16] = {
  0x48,0x8b,0xc4,0x57,0x48,0x81,0xec,0xe0,0x00,0x00,0x00,0x48,0xc7,0x44,0x24,0x20 };
// 0.59: the game's "bool Get(obj, key)" helper (0.58 log: crash here with obj = 0x00FFFFFF00FFFFFF while a level loaded)
static const uint32_t kRvaPropGet = 0x2D6670;
static const uint8_t kBytesPropGet[16] = {
  0x48,0x89,0x54,0x24,0x10,0x48,0x83,0xec,0x28,0x48,0x85,0xc9,0x75,0x07,0x32,0xc0 };
static const uint8_t kBytesAttachMatrix[16] = {
  0x48,0x89,0x5c,0x24,0x20,0x57,0x48,0x83,0xec,0x70,0x48,0x8b,0x05,0xff,0xb6,0xd3 };
static const uint8_t kBytesVecToAngles[16] = {
  0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x60,0x44,0x0f,0x29,0x44,0x24,0x30 };
static const uint8_t kBytesAimFieldSet[16] = {
  0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x48,0x89,0x7c,0x24,0x18,0x41 };
static const uint8_t kBytesVisibilityStage[16] = {
  0x40,0x57,0x48,0x83,0xec,0x50,0x48,0xc7,0x44,0x24,0x30,0xfe,0xff,0xff,0xff,0x48 };

// ---- 1.7.30 mirrors (hotel, bathrooms) ------------------------------------------------------------------------------------------------
// 0x454530 (camera vtable slot +0x50, called from the visibility stage right after the world query) calls the mirror-view builder 0x427210(list, ctx) once per frame.
// The builder reads the camera in ctx[0] directly: its eye at cam+0x08/0x0C/0x10 and its Euler angles at cam+0x14 (turned into a 9-float basis by 0x3DD40 at 0x4272A5,
// forward = out[2], out[5], out[8]); both are the flat-screen camera's, not the headset's, so the mirror views showed the scene from the wrong place and direction.
// The probe gives the builder the headset eye (written into the camera for the duration of the call) and the headset basis (replaces the result of 0x3DD40 at that one call site).
static const uint32_t kRvaBuildMirrors        = 0x427210;
static const uint32_t kRvaEulerToBasis        = 0x3DD40;
static const uint32_t kRvaBuildMirrorsEulerRet = 0x4272AA;   // return address of the 0x3DD40 call inside the builder
static const uint32_t kRvaBuildMirrorsCaller  = 0x454530;    // the only caller (camera vtable slot +0x50)
static const uint32_t kRvaBuildMirrorsRet     = 0x454553;    // return address of the builder call inside that caller
static const uint32_t kCamEyeOffset           = 0x08;        // camera: eye x, y, z
static const uint8_t kBytesBuildMirrors[16] = {
  0x48,0x8b,0xc4,0x55,0x56,0x57,0x41,0x54,0x41,0x55,0x41,0x56,0x41,0x57,0x48,0x8d };
static const uint8_t kBytesEulerToBasis[16] = {
  0x48,0x8b,0xc4,0x48,0x89,0x58,0x08,0x57,0x48,0x81,0xec,0x80,0x00,0x00,0x00,0x0f };

// ---- 0.57 skeleton (arms follow the hands) ----------------------------------------------------------------------------
// The player's body is a model instance at actor+0x430 (class with the bone code at 0x309000-0x315000, skeleton loader 0x329xxx).
//   +0x7930 skeleton: +0x88 bone count, bone definitions from +0x8c, 0x4c bytes each: +0x00 name (char[0x18]), +0x1c parent index (-1 root)
//   +0x2090 bone count of the instance, +0x2ae8 local pose (0x28 bytes per bone: quaternion xyzw, scale xyz at +0x10, position xyz at +0x1c)
//   +0x2b00 model-space matrices (0x40 bytes per bone, 3x4 affine used: rows 0..2 axes, row 3 position), +0x2b08 state (>0 all valid,
//   0 / -1 stale), +0x2b0c one flag byte per bone (lazy mode).
// 0x30D410 EnsureWorld(model): computes every bone's matrix from the local pose when the state is not > 0 (0x329560), sets state 1.
// 0x30D950 LocalToMatrix(local*, out*): quaternion / scale / position -> 3x4 matrix (the fourth column is left alone).
// 0x32E510 Mul34(out, a, b): out = a x b (row vectors, parent on the right: world[i] = local[i] x world[parent]).
// The render pass calls 0x15640 (-> 0x30A8B0, which calls EnsureWorld again, and the skinning) right after the body-base matrix
// product at 0xD213F, so bone matrices written before that product's return (0xD2144) are what gets drawn.
// Bone indices are stored in the actor: +0xCDC8 bone_head, +0xCDCC bone_spine3, +0xCDD0 bone_R_upperArm, +0xCDD4 bone_L_upperArm,
// +0xCDD8 bone_R_hand, +0xCDDC bone_L_hand (set by the loader at 0x1FD40 from the bone names).
static const uint32_t kRvaModelEnsureWorld = 0x30D410;
static const uint8_t kBytesModelEnsureWorld[16] = {0x40,0x53,0x48,0x83,0xec,0x20,0x83,0xb9,0x08,0x2b,0x00,0x00,0x00,0x48,0x8b,0xd9};
static const uint32_t kRvaModelLocalToMatrix = 0x30D950;
static const uint8_t kBytesModelLocalToMatrix[16] = {0x4c,0x8b,0xdc,0x48,0x83,0xec,0x78,0x0f,0x29,0x74,0x24,0x60,0x0f,0x29,0x7c,0x24};
static const uint32_t kRvaModelMul34 = 0x32E510;
static const uint8_t kBytesModelMul34[16] = {0xf3,0x0f,0x10,0x12,0xf3,0x41,0x0f,0x59,0x10,0xf3,0x41,0x0f,0x10,0x40,0x10,0xf3};
static const uint32_t kOffActorModel = 0x430;
static const uint32_t kOffModelSkeleton = 0x7930;
static const uint32_t kOffModelBoneCount = 0x2090;
static const uint32_t kOffModelLocal = 0x2ae8;
static const uint32_t kOffModelWorld = 0x2b00;
static const uint32_t kOffModelState = 0x2b08;
static const uint32_t kOffActorBoneIdx = 0xcdc8;

// ---- 0.94 the game's own PKE meter (CPKEMeter) ------------------------------------------------------------------------
// The PKE the player holds is NOT the wand-slot model and NOT the cloth_pke bones (those are a stowed gun and the belt copy): it is a separate object,
// CPKEMeter (size 0x690), pointed to by the player at +0x24D90. Its owner (the player) is at +0x4A8, its model instance at +0x428.
// World pose: position float[3] at +0x4B8, rotation 3x3 at +0x4C4 stored as s[3*i+j] = M[j*4+i] of the 4x4 matrix (so local axis j in world = (s[j], s[3+j], s[6+j]);
// forward = local +Z = (s[2], s[5], s[8]) = row 2 of the 4x4). The player's update function (0xD6270) writes it every frame from the animated "R_PKE" attach plus the
// aim heading / pitch (setters 0x141E60 (4x4), 0x141EE0 (pos, euler), 0x141F10 (pos, 3x3)). Its collect function (vtable +0xE8, 0x141070) draws the model at that pose
// and its update (vtable +0x80, 0x141860, args this, dt) scans: the ray starts at the model's "tip" attachment (entity attach getter 0x2C1E40(this, name, out4x4),
// the local attachment times the entity matrix at +0xF4 (rotation, same layout) / +0x54 (position)) and points along the player's aim direction.
// CPKESource (vtable 0x791568, size 0x478) is the scannable "PKE Source" actor; it is in the world's actor list like the enemies.
static const uint32_t kRvaPkeMeterVtable = 0x790d18;
static const uint32_t kRvaPkeSourceVtable = 0x791568;
static const uint32_t kRvaTrinketVtable = 0x7a4408;      // 1.7.29: CTrinket (the collectibles; the PKE scans them too)
static const uint32_t kRvaSlimerVtable = 0x799910;       // 1.7.29: CSlimer (named in the PKE logs)
static const uint32_t kOffPlayerPke = 0x24D90;     // player -> CPKEMeter*
static const uint32_t kOffPkeOwner = 0x4A8;
static const uint32_t kOffPkePos = 0x4B8;
static const uint32_t kOffPkeRot = 0x4C4;
static const uint32_t kSizePkeMeter = 0x690;
static const uint32_t kRvaPkeCollect = 0x141070;
static const uint8_t kBytesPkeCollect[16] = {0x40,0x53,0x57,0x48,0x83,0xec,0x38,0x48,0x8b,0xd9,0x48,0x8b,0xfa,0x48,0x8b,0x89};
static const uint32_t kRvaPkeUpdate = 0x141860;
static const uint8_t kBytesPkeUpdate[16] = {0x48,0x89,0x5c,0x24,0x20,0x55,0x48,0x8d,0x6c,0x24,0x80,0x48,0x81,0xec,0x80,0x01};
static const uint32_t kRvaPkeSetMatrix = 0x141E60;
static const uint8_t kBytesPkeSetMatrix[16] = {0xf3,0x0f,0x10,0x42,0x30,0xf3,0x0f,0x10,0x4a,0x34,0xf3,0x0f,0x10,0x52,0x38,0xf3};
// ---- 1.7.72 read from ghost.exe (checked in tests/verify_layout.py) -------------------------------------------------------------------------------------------
// How the PKE is really drawn: the collect (0x141070) pushes the meter's ENTITY pose (+0x54 position / +0xF4 rotation, through 0x2C2800 -> 0x41360) onto the draw context's matrix stack
// and, with the goggles on, its second pose (+0x4B8 / +0x4C4, direct calls to 0x41360 at 0x1411C8 and 0x141236). 0x41360(ctx, pos, rot) = push rot/pos x top of the stack.
// The player's update (0xD6270) sets the ENTITY every frame to the player's position plus a fixed offset turned by the player's aim (0x2C3AB0 -> virtual SetTransform), i.e. a
// pose fixed in front of the view: the "floating PKE". The +0x4B8 pose is the animated R_PKE hold (0x141E60). The draw callback (0x1412D0) skips the +0x4B8 record in the normal view.
static const uint32_t kRvaMatPush = 0x41360;
static const uint8_t kBytesMatPush[16] = {0x48,0x63,0x81,0xf0,0xc6,0x4e,0x00,0x4c,0x8b,0xd0,0x49,0xc1,0xe2,0x06,0xff,0xc0};
// The slime blower: CGadgetTether (vtable 0x764058) is an entity of its own. Its fire logic (0xAB320, called from its update 0xAAD80) takes the stream's start from the tether's
// entity attachment "slime" (0x2C1E40, name pointer at 0xDCCE90) and its end from the game view (player+0xB550: camera position +0x08, angles +0x14) when that pointer is set,
// else from the attachment plus the player's aim (0x76E80) times the range. The tether's owner (the player) is at +0x4A8.
static const uint32_t kRvaTetherVtable = 0x764058;
static const uint32_t kRvaTetherFire = 0xAB320;
static const uint8_t kBytesTetherFire[16] = {0x48,0x8b,0xc4,0x55,0x41,0x54,0x41,0x55,0x41,0x56,0x41,0x57,0x48,0x8d,0xa8,0x18};
static const uint32_t kOffTetherOwner = 0x4A8;
// 1.7.75: the player's tether is at player+0x24D98 (stored by allocInventory 0xE26F7). The player update places its ENTITY every frame through the virtual SetTransform
// (vtable +0x58 = 0x2C3730, called at 0xD5C97, returns to 0xD5C9A) from the animation's gun-hand attachment times the player: the game's gun, beside you. The rope, its
// "slime" attachment, the shot and the end point all follow that entity.
static const uint32_t kOffPlayerTether = 0x24D98;
static const uint32_t kRvaSetTransform = 0x2C3730;
static const uint8_t kBytesSetTransform[16] = {0x40,0x55,0x56,0x57,0x41,0x56,0x41,0x57,0x48,0x8d,0xac,0x24,0x00,0xd0,0xff,0xff};
static const uint32_t kRvaTetherPlaceRet = 0xD5C9A;
// 1.7.76 the slime rope, read from ghost.exe.  The player's update (0xD8BD5) calls the tether's rope step AAF40(tether, 0) every frame the alt-fire flag is set.  It puts the
// ray's hit (tether+0x500 entity, else the point at +0x508) into one of the rope manager's two anchor slots (manager = [tether+0x5B8], slots at manager+0x25FA8, stride 0x98,
// first qword = the anchored entity, slot free = entity 0 and position 0).  A hit on an entity that already holds a slot CLEARS the manager first (0x289010) and stores the hit again,
// so a squeeze that lasts a few frames leaves both slots on the SAME entity: a rope from the bridge to the bridge, "complete" at once (0x289060: both slots used -> the manager is
// let go and the tether goes to mode 3) - the rope that "breaks on impact".  One step per squeeze puts the first anchor on the first squeeze and the second on the next.
static const uint32_t kRvaTetherRopeStep = 0xAAF40;
static const uint8_t kBytesTetherRopeStep[16] = {0x48,0x8b,0xc4,0x55,0x57,0x41,0x54,0x41,0x56,0x41,0x57,0x48,0x8d,0xa8,0x38,0xfb};
static const uint32_t kRvaTetherRopeCall = 0xD8BD5;   // call 0xAAF40 in the player update (xor edx,edx before it)
static const uint32_t kOffTetherRopeMgr = 0x5B8, kOffTetherHitEntity = 0x500, kOffTetherHitPos = 0x508, kOffTetherMode = 0x4B8;
static const uint32_t kOffRopeSlots = 0x25FA8, kRopeSlotStride = 0x98, kRopeSlotCount = 2, kOffRopeState = 0x25F78;
static const uint32_t kRvaEntityAttachWorld = 0x2C1E40;
static const uint8_t kBytesEntityAttachWorld[16] = {0x48,0x89,0x5c,0x24,0x20,0x57,0x48,0x81,0xec,0xf0,0x00,0x00,0x00,0x48,0x8b,0x05};
static const uint32_t kOffEntityRot = 0xF4;        // entity rotation 3x3 (same s[3*i+j] layout); position at kActorPos (0x54)

// ---- 1.4 the game's real PKE scan rules (read from the disassembly, checked in tests/verify_layout.py) ---------------------------------------------------------------------------
// The meter keeps its scan target in a record array at +0x4E8 (stride 0x38, slot index at +0x520); the update (0x141860) refills it every frame (enumeration 0x142120):
//   +0x4E8 target actor, +0x4F0 "scan range squared" (225.0 = 15 ft), +0x4F4 far range squared, +0x4F8 distance squared (ground plane), +0x4FC visible flag,
//   +0x500 alignment (cosine of the angle between where the meter points and the target), +0x504 strength.
// A scan only runs when scan_ok (0x1456A0) is true: equipped (+0x53C), a target, cooldown (+0x540) over, the target's two virtual checks pass, the visible flag is set,
// distance squared <= scan range squared and alignment > the global at kRvaPkeAlignMin (= cos 18 deg = 0.951, set once by the static initialiser kRvaPkeAlignInit from the double 18 deg degrees at 0x791170).
// The enumeration also drops every target whose alignment is below that global, so lowering it widens the cone for the whole scan (enumeration, scan_ok, strength).
// The player's per-frame code (0xD8F60) sets the meter's input byte +0x538 = 1 while the primary request bit (player+0xC7A8 & 0x40) is down and the PKE is the held item.
static const uint32_t kRvaPkeScanOk = 0x1456A0;
static const uint8_t kBytesPkeScanOk[16] = {0x40,0x53,0x48,0x83,0xec,0x20,0x83,0xb9,0x3c,0x05,0x00,0x00,0x00,0x48,0x8b,0xd9};
static const uint32_t kRvaPkeAlignMin = 0xEA9C88;      // float, cos(18 deg) once the static initialiser has run
static const uint32_t kRvaPkeAlignInit = 0x5BB0;
static const uint8_t kBytesPkeAlignInit[16] = {0x48,0x83,0xec,0x28,0xf2,0x0f,0x10,0x05,0xb4,0xb5,0x78,0x00,0xe8,0x5f,0x52,0x69};
static const uint32_t kRvaPkeAlignAngle = 0x791170;    // double, radians (18 degrees)
static const uint32_t kOffPkeRecords = 0x4E8;
static const uint32_t kOffPkeSlot = 0x520;
static const uint32_t kOffPkeState = 0x53C;
static const uint32_t kOffPkeInput = 0x538;
static const uint32_t kOffPkeCooldown = 0x540;
static const uint32_t kOffPkeScanTimer = 0x550;
static const uint32_t kOffPkeScanning = 0x67C;
static const uint32_t kOffPkeScanBar = 0x680;
static const uint32_t kSizePkeRecord = 0x38;
// The green goggle frame (ui\pke_goggles_overlay) is the second full-screen quad of the overlay draw (0x205660): drawn only when overlay+0x448 is 1 or 2.
// kRvaGoggleStateRead is "mov eax,[rdi+0x448]" (6 bytes); "xor eax,eax; nop x4" makes the game think the state is 0, so the frame is skipped.
static const uint32_t kRvaGoggleStateRead = 0x20594B;
static const uint8_t kBytesGoggleStateRead[16] = {0x8b,0x87,0x48,0x04,0x00,0x00,0xff,0xc8,0x83,0xf8,0x01,0x77,0x29,0x48,0x8b,0x05};

// ---- 1.6 how a PKE scan really adds progress (read from the disassembly, checked in tests/verify_layout.py) --------------------------------------------------------------------
// The update (0x141F60) calls the "scan ping" 0x1460D0(meter, 1) every update while the input byte is set AND scan_ok is true; the ping sets the cooldown (+0x540, 2.0 s, 1.25 s with the upgrade),
// so in practice there is one ping per 2 s. A ping adds `rate` to the target's progress through the target's virtual 0x3E8(target, rate) when the target has the scan component and is not yet scanned.
//   rate = 0x145F20: level = 0x145E00 (0 when the target is exactly in line (alignment == 1.0); else the sideways offset S at meter+0x534 against 40/80/140 (48/96/168 with the upgrade) times a game factor:
//   level 0 -> rate 1.0, level 1 -> 0.5, level 2 -> 0.25, level -1 (S too big) -> rate 0.0: THE PING ADDS NOTHING but still burns the 2 s cooldown. 1.6 puts a floor under the rate (pke_scan_help).
// Target virtuals used by scan_ok / the ping (the target is the actor at record +0x4E8): +0x3E0 IsScanned, +0x3E8 AddProgress(float), +0x3F0 GetProgress (0..1), +0x3F8 IsScannable, +0x278 IsBlocked (scan_ok wants it false).
// The whole PKE update returns early while the owner's state (player+0xD3E8) is not 0.
static const uint32_t kRvaWorldPtrHud = 0xDCF680;       // the world object pointer; HUD::Draw returns early when [world+0x3ada0] (level loaded) is 0 or [world+0x1e0] is set
static const uint32_t kRvaPkeScanPulse = 0x1460D0;
static const uint8_t kBytesPkeScanPulse[16] = {0x40,0x53,0x55,0x48,0x83,0xec,0x48,0x48,0x63,0x81,0x20,0x05,0x00,0x00,0x0f,0xb6};
static const uint32_t kRvaPkeScanRate = 0x145F20;
static const uint8_t kBytesPkeScanRate[16] = {0x48,0x83,0xec,0x28,0xe8,0xd7,0xfe,0xff,0xff,0x8b,0xc8,0x83,0xf8,0xff,0x75,0x08};
static const uint32_t kRvaPkeScanLevel = 0x145E00;
static const uint32_t kOffPkeSignal = 0x534;           // float S: sideways offset of the target from the meter's line (the level thresholds 40 / 80 / 140 compare against it)
static const uint32_t kOffPlayerState = 0xD3E8;        // int: 0 = free; the PKE update does nothing while it is not 0
static const uint32_t kVtTargetBlocked = 0x278;
static const uint32_t kVtTargetScanned = 0x3E0;
static const uint32_t kVtTargetAddProgress = 0x3E8;
static const uint32_t kVtTargetProgress = 0x3F0;
static const uint32_t kVtTargetScannable = 0x3F8;

// ---- 1.5: the game's own health ring on the ghost you look at ----------------------------------------------------------------------------
// The ring (HUD object, update 0x24D450 (this, dt), draw 0x24D810) shows only when the player has a "focus": the locked target (player+0x2E8) or the PKE's target.
//   0xDE1F0  bool GetFocusPos(player, float out[3])   world position of that focus (target+0x54), false = none -> the ring hides
//   0xDE1E0  float GetFocusHealth(player)             = [player+0x24938] = the target's health fraction (B860/B868), -1 = none
// The VR view never gets a lock (0 of 81,030 ring draws in the 1.3 log). While the ring update runs, the probe answers these two for the ghost you look at.
static const uint32_t kRvaRingUpdate = 0x24D450;
static const uint8_t kBytesRingUpdate[16] = {0x4c,0x8b,0xdc,0x57,0x48,0x83,0xec,0x70,0x48,0x8b,0x05,0x09,0x46,0xb8,0x00,0x48};
static const uint32_t kRvaFocusHealth = 0xDE1E0;
static const uint8_t kBytesFocusHealth[16] = {0xf3,0x0f,0x10,0x81,0x38,0x49,0x02,0x00,0xc3,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0xcc};
static const uint32_t kRvaFocusPos = 0xDE1F0;
static const uint8_t kBytesFocusPos[16] = {0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x30,0xf3,0x0f,0x10,0x05,0xa6,0xbf};
static const uint32_t kOffFocusHealth = 0x24938;      // float in the player
static const uint32_t kOffLockTarget = 0x2E8;         // pointer in the player: the locked target

// ---- 1.7.9: the PKE goggles (the green view, and the marks / things that only show in it) -----------------------------------------------------
// The game decides every frame whether the goggles are on: isGogglesActive(player) = 0xD6580 = item 5 (the PKE) is in the hand (inventory state 2) AND byte [player+0xB568] (set while the
// goggle button is held) AND 0x78DA0(player) == 0 AND !0x7D1F0(player) AND !((player+0x4C) >> 7 & 1). Its result goes to HUD::setGoggles(hud, on) (0x1FEFB0 -> the fader at hud+0x448:
// 0 off, 1 fading in, 2 on, 3 fading out; progress float at hud+0x45C) from two places, and into the render view flags for the things that only show in the goggles (call at 0x141133).
// 1.7.8 log: the VR player never held the goggle button, so the answer was always "no": no green tint, nothing hidden shown. The probe answers "yes" at exactly those three call sites while
// the PKE is in the hand (the other two callers, which smooth a value and move the PKE, keep the game's answer, and [player+0xB568] is not touched: the PKE meter stays visible in the hand).
static const uint32_t kRvaIsGoggles = 0xD6580;
static const uint8_t kBytesIsGoggles[16] = {0x40,0x53,0x48,0x83,0xec,0x20,0xba,0x05,0x00,0x00,0x00,0x48,0x8b,0xd9,0xe8,0x2d};
static const uint32_t kRetGogHud = 0xCAB3E;        // return address after the call at 0xCAB39 (HUD::setGoggles(hud, isGogglesActive(player)))
static const uint32_t kRetGogHudFrame = 0xD7AC3;   // ... at 0xD7ABE (the same, every player update)
static const uint32_t kRetGogRender = 0x141138;    // ... at 0x141133 (the render command's "goggles" view flag: UV-only things are drawn when it is set)
static const uint32_t kRvaHudSetGoggles = 0x1FEFB0;
static const uint8_t kBytesHudSetGoggles[16] = {0x48,0x81,0xc1,0x48,0x04,0x00,0x00,0xe9,0xa4,0x65,0x00,0x00,0xcc,0xcc,0xcc,0xcc};
static const uint32_t kOffPlayerHud = 0xB550;      // player -> HUD object (CGameView; HUD::Init at 0x1FDBA3 stores itself there, the player's destructor deletes it). 1.7.27: it is NOT a lock-on target (the 1.7.2 guard wiped it)
static const uint32_t kOffPlayerGogByte = 0xB568;  // byte: the goggle button is held (read only by the probe)
static const uint32_t kOffPlayerInv = 0xCFE0;      // inventory states: int at player + 0xCFE0 + 0x18 * item; 2 = in the hand
static const uint32_t kInvStride = 0x18;
static const uint32_t kOffPlayerFlags = 0x4C;      // bit 7 set: the goggles are not allowed (read by the game's own check)
static const uint32_t kOffPlayerB640 = 0xB640;     // pointer (0x78DA0 asks it); read only by the probe
static const uint32_t kOffHudGogState = 0x448;
static const uint32_t kOffHudGogProgress = 0x45C;
static const uint32_t kRvaUvDebugByte = 0x23224D2; // 14 readers (HUD::Draw tint amount, the UV draw command 0x16FD0 ...), no writer in the code: a developer "show everything" switch; level 2 of pke_goggles sets it

// ---- 1.7.36 knockdown comfort ---------------------------------------------------------------------------------------------------------------
// CGhostbuster::knockBack(this, float3* direction, float force) at 0xED100 starts the fall: it sets the player's flag byte +0xB695, the knock velocity at
// +0xB698..0xB6A0 and the timers +0xB6B4 / +0xB6BC, and the consumer (0x70F90) plays the fall through vfunc +0x5D0. For the player the probe skips the call
// (and clears the flag if it is ever set) and gives slow walking, dark edges and a harder aim instead. The game's reset sequence (what it writes when a fall ends):
// b695 = 0, b6b4 (qword) = 0, b6b0 = 0, b69c (qword) = 0, b698 = 0, b6bc = -1.
static const uint32_t kRvaKnockBack      = 0xED100;
static const uint8_t  kBytesKnockBack[16] = {0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x70,0x0f,0x29,0x74,0x24,0x60,0x48};
// CGhostbuster's per-frame fall consumer. It checks B695 and invokes the fall animation at vslot 0x5D0.
// Intercepting its entry catches fall requests that bypass the knockBack method before that animation can start.
static const uint32_t kRvaKnockConsumer = 0x70F90;
static const uint8_t kBytesKnockConsumer[16] = {0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x30,0x33,0xdb,0x0f,0x29,0x74,0x24};
static const uint32_t kOffKnockFlag      = 0xB695;   // byte
static const uint32_t kOffKnockVel       = 0xB698;   // 3 floats (B698, B69C, B6A0)
static const uint32_t kOffKnockB6B0      = 0xB6B0;   // dword
static const uint32_t kOffKnockB6B4      = 0xB6B4;   // qword (float 5.0 while falling)
static const uint32_t kOffKnockB6BC      = 0xB6BC;   // dword (-1 when idle)

}  // namespace layout
