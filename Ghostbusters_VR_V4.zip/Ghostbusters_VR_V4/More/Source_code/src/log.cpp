// Session log: gbvr_probe_<version>_<yyyymmdd-hhmmss>.log in the game folder.
#include "gbvr.h"
#include "memcache.h"
#include "speedmath.h"
#include "quietlogmath.h"

#if defined(_MSC_VER) && !defined(__clang__)
#include <stdio.h>
#define GBVR_VSNPRINTF(b, n, f, a) vsnprintf(b, n, f, a)
#else
extern "C" int __cdecl _vsnprintf(char*, size_t, const char*, va_list);
#define GBVR_VSNPRINTF(b, n, f, a) _vsnprintf(b, n, f, a)
#endif

static HANDLE g_logFile = INVALID_HANDLE_VALUE;
static HANDLE g_logFlushHandle = INVALID_HANDLE_VALUE;   // 0.44: second handle to the same file, only used to flush
static wchar_t g_logPath[MAX_PATH + 96];
static SRWLOCK g_logLock = SRWLOCK_INIT;
static int64_t g_qpcStart, g_qpcFreq;
static volatile LONG g_logLines, g_importantAfterCap;
static const LONG kMaxLogLines = 150000;  // hard cap so a stuck state cannot fill the disk (0.44: was 60000, about 90 minutes of play)
static const LONG kExtraImportant = 5000;  // 0.44: after the cap only lines that say what went wrong still get through

static int important_line(const char* f) {
  static const char* const k[] = {"CRASH", "SAFETY", "STALL", "PRESENTFAIL", "EXIT", "HEALTH", "STEREO off", "RATE"};
  for (const char* w : k) {
    int i = 0;
    while (w[i] && f[i] == w[i]) ++i;
    if (!w[i]) return 1;
  }
  return 0;
}

int64_t qpc_now() { LARGE_INTEGER t; QueryPerformanceCounter(&t); return t.QuadPart; }
int64_t qpc_freq() { return g_qpcFreq; }
double qpc_ms() { return (double)(qpc_now() - g_qpcStart) * 1000.0 / (double)g_qpcFreq; }

static wchar_t g_logDir[MAX_PATH + 64];   // folder the log was created in (with trailing backslash)
const wchar_t* log_dir() { return g_logDir[0] ? g_logDir : g_selfDir; }

static HANDLE try_create(const wchar_t* dir, const SYSTEMTIME& st) {
  wchar_t path[MAX_PATH + 96];
  wsprintfW(path, L"%sgbvr_probe_%S_%04u%02u%02u-%02u%02u%02u.log", dir, GBVR_VERSION_FILE, st.wYear, st.wMonth,
            st.wDay, st.wHour, st.wMinute, st.wSecond);
  HANDLE h = CreateFileW(path, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (h != INVALID_HANDLE_VALUE) lstrcpynW(g_logPath, path, MAX_PATH + 90);
  return h;
}

// Log goes to the game folder; if that is not writable (e.g. Program Files
// without admin rights) it falls back to Documents\GhostbustersVR_logs.
void log_open() {
  LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_qpcFreq = f.QuadPart;
  g_qpcStart = qpc_now();
  SYSTEMTIME st; GetLocalTime(&st);
  g_logFile = try_create(g_selfDir, st);
  if (g_logFile != INVALID_HANDLE_VALUE) lstrcpynW(g_logDir, g_selfDir, MAX_PATH);
  if (g_logFile == INVALID_HANDLE_VALUE) {
    wchar_t dir[MAX_PATH + 64];
    DWORD n = GetEnvironmentVariableW(L"USERPROFILE", dir, MAX_PATH);
    if (n > 0 && n < MAX_PATH) {
      lstrcatW(dir, L"\\Documents\\GhostbustersVR_logs\\");
      CreateDirectoryW(dir, nullptr);
      g_logFile = try_create(dir, st);
      if (g_logFile != INVALID_HANDLE_VALUE) lstrcpynW(g_logDir, dir, MAX_PATH + 60);
    }
  }
  if (g_logFile == INVALID_HANDLE_VALUE) {   // 0.44: last resort, the temporary folder (so a log exists whatever the folder rights are)
    wchar_t dir[MAX_PATH + 64];
    DWORD n = GetTempPathW(MAX_PATH, dir);
    if (n > 0 && n < MAX_PATH) {
      g_logFile = try_create(dir, st);
      if (g_logFile != INVALID_HANDLE_VALUE) lstrcpynW(g_logDir, dir, MAX_PATH + 60);
    }
  }
}

void log_line(const char* fmt, ...) {
  if (!g_ctl.probeData && !quietlog::keep(fmt)) return;
  if (g_logFile == INVALID_HANDLE_VALUE) return;
  LONG n = InterlockedIncrement(&g_logLines);
  if (n > kMaxLogLines) {
    if (!important_line(fmt) || InterlockedIncrement(&g_importantAfterCap) > kExtraImportant) return;
  }
  char buf[1536];
  va_list ap; va_start(ap, fmt);
  int len = GBVR_VSNPRINTF(buf, sizeof(buf) - 2, fmt, ap);
  va_end(ap);
  if (len < 0 || len > (int)sizeof(buf) - 2) len = (int)sizeof(buf) - 2;  // truncated
  buf[len++] = '\r'; buf[len++] = '\n';
  if (n == kMaxLogLines) { const char* m = "LOG LINE LIMIT REACHED\r\n"; len = lstrlenA(m); lstrcpyA(buf, m); }
  AcquireSRWLockExclusive(&g_logLock);
  DWORD w = 0; WriteFile(g_logFile, buf, (DWORD)len, &w, nullptr);
  ReleaseSRWLockExclusive(&g_logLock);
}

int log_fmt(char* buf, int size, const char* fmt, ...) {
  if (size <= 0) return 0;
  va_list ap; va_start(ap, fmt);
  int len = GBVR_VSNPRINTF(buf, (size_t)size, fmt, ap);
  va_end(ap);
  if (len < 0 || len >= size) len = size - 1;
  buf[len] = 0;
  return len;
}

void log_flush() {
  if (g_logFile == INVALID_HANDLE_VALUE) return;
  AcquireSRWLockExclusive(&g_logLock);
  FlushFileBuffers(g_logFile);
  ReleaseSRWLockExclusive(&g_logLock);
}

// 0.44: called from the heartbeat thread about every 2 s. A flush on the writing handle would hold up the thread that
// is logging (the render thread) while the disk works; a second handle to the same file flushes the same cached data
// without that. If the second handle cannot be opened nothing is flushed here (the render thread still flushes now and then).
void log_flush_quiet() {
  if (g_logFile == INVALID_HANDLE_VALUE || !g_logPath[0]) return;
  if (g_logFlushHandle == INVALID_HANDLE_VALUE)
    g_logFlushHandle = CreateFileW(g_logPath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (g_logFlushHandle != INVALID_HANDLE_VALUE) FlushFileBuffers(g_logFlushHandle);
}

// ---- 0.56 profile --------------------------------------------------------------------------------------------------
static struct { volatile LONG64 sumUs; volatile LONG calls; volatile LONG maxUs; volatile LONG over; } g_prof[PF_COUNT];
void prof_add(int slot, int64_t t0Qpc) {
  if (!g_ctl.probeData) return;
  if (slot < 0 || slot >= PF_COUNT) return;
  const int64_t us = (qpc_now() - t0Qpc) * 1000000 / qpc_freq();
  InterlockedExchangeAdd64(&g_prof[slot].sumUs, us);
  InterlockedIncrement(&g_prof[slot].calls);
  if (us > 5000) InterlockedIncrement(&g_prof[slot].over);
  LONG m = g_prof[slot].maxUs;
  if (us > m) InterlockedExchange(&g_prof[slot].maxUs, (LONG)(us > 2000000000 ? 2000000000 : us));
}
void prof_report(LONG frame) {
  if (!g_ctl.probeData) return;
  static const char* const kName[PF_COUNT] = {"tick", "simulate", "present", "controllers", "menu", "bodyPush", "hud", "armStereo", "submit", "waitPoses", "arms"};
  static int64_t s_lastQpc;
  static speed::Guard s_guard;
  static int s_guardInit;
  if (!s_guardInit) { s_guardInit = 1; s_guard.reset(); }
  const int64_t nowq = qpc_now();
  const double secs = s_lastQpc ? (double)(nowq - s_lastQpc) / (double)qpc_freq() : 0.0;
  s_lastQpc = nowq;
  char buf[700];
  int n = log_fmt(buf, (int)sizeof(buf), "PROFILE frame=%d (calls avgUs maxUs over5ms per slot, since the last report):", (int)frame);
  double msPerSec[PF_COUNT];
  LONG callsOf[PF_COUNT];
  for (int i = 0; i < PF_COUNT && n < (int)sizeof(buf) - 90; ++i) {
    const LONG64 sum = InterlockedExchange64(&g_prof[i].sumUs, 0);
    const LONG calls = InterlockedExchange(&g_prof[i].calls, 0);
    const LONG mx = InterlockedExchange(&g_prof[i].maxUs, 0);
    const LONG over = InterlockedExchange(&g_prof[i].over, 0);
    msPerSec[i] = secs > 0.2 ? (double)sum / 1000.0 / secs : 0.0;
    callsOf[i] = calls;
    n += log_fmt(buf + n, (int)sizeof(buf) - n, " %s=%d/%d/%d/%d", kName[i], (int)calls, calls ? (int)(sum / calls) : 0, (int)mx, (int)over);
  }
  log_line("%s", buf);
  {   // 0.66: the cached memory checks (memcache.h): how often the full Windows check was still needed and what one cost
    LARGE_INTEGER fq; QueryPerformanceFrequency(&fq);
    const LONG misses = memcache::g_misses;
    log_line("MEMCACHE frame=%d enabled=%d cachedHits=%d fullChecks=%d busy=%d refused=%d fullCheckAvgUs=%.1f fullCheckMaxUs=%d (hits are free; a full check is the slow Windows call)",
             (int)frame, (int)memcache::g_enabled, (int)memcache::g_hits, (int)misses, (int)memcache::g_busy, (int)memcache::g_bad,
             misses ? (double)memcache::g_vqTicks * 1e6 / (double)fq.QuadPart / (double)misses : 0.0, (int)memcache::g_vqMaxUs);
    InterlockedExchange(&memcache::g_hits, 0); InterlockedExchange(&memcache::g_misses, 0); InterlockedExchange(&memcache::g_busy, 0);
    InterlockedExchange(&memcache::g_bad, 0); InterlockedExchange64(&memcache::g_vqTicks, 0); InterlockedExchange(&memcache::g_vqMaxUs, 0);
  }
  // 0.58 speed guard: ms of every second used by each part of the probe, the frame pairs per second the headset got
  // (one frame wait per pair), and - when the game is slow and one part is heavy - that part is switched off for this run.
  if (secs > 0.2) {
    const double pairs = (double)callsOf[PF_WAITPOSES] / secs;
    double load[speed::P_COUNT];
    load[speed::P_NONE] = 0;
    load[speed::P_MENU] = msPerSec[PF_MENU];
    load[speed::P_ARMS] = msPerSec[PF_ARMS];
    load[speed::P_BODY] = msPerSec[PF_BODYPUSH] > msPerSec[PF_ARMS] ? msPerSec[PF_BODYPUSH] - msPerSec[PF_ARMS] : 0.0;
    load[speed::P_HUD] = msPerSec[PF_HUD];
    load[speed::P_CTRL] = msPerSec[PF_CTRL];
    log_line("SPEED frame=%d seconds=%.2f pairsPerSecond=%.1f ownMsPerSec(menu/body/arms/hud/controllers)=%.0f/%.0f/%.0f/%.0f/%.0f gameMsPerSec(tick/simulate/present/submit/wait)=%.0f/%.0f/%.0f/%.0f/%.0f guard(menu/body/arms/hud/ctrl fired)=%d/%d/%d/%d/%d",
             (int)frame, secs, pairs, load[speed::P_MENU], load[speed::P_BODY], load[speed::P_ARMS], load[speed::P_HUD], load[speed::P_CTRL],
             msPerSec[PF_TICK], msPerSec[PF_SIM], msPerSec[PF_PRESENT], msPerSec[PF_SUBMIT], msPerSec[PF_WAITPOSES],
             s_guard.fired[speed::P_MENU], s_guard.fired[speed::P_BODY], s_guard.fired[speed::P_ARMS], s_guard.fired[speed::P_HUD], s_guard.fired[speed::P_CTRL]);
    const int hit = s_guard.update(load, pairs, g_ctl.stereoActive && callsOf[PF_WAITPOSES] >= 3 ? 1 : 0);
    if (hit != speed::P_NONE) {
      log_line("SPEEDGUARD the headset got only %.1f frame pairs per second and %s used %.0f ms of every second for %d windows in a row: switching it off for this run",
               pairs, speed::part_name(hit), load[hit], speed::Guard::kWindows);
      switch (hit) {
#if GBVR_HEADTRACK
        case speed::P_MENU: vrmenu_set_cheap(1); break;
#endif
        case speed::P_BODY: log_line("SPEEDGUARD 0.61: body follow stays ON (the full body matters more; a dip is usually the SteamVR dashboard)"); break;
        case speed::P_ARMS: log_line("SPEEDGUARD 0.61: arms stay ON"); break;
        case speed::P_HUD: log_line("SPEEDGUARD 1.7.180: the HUD placement stays ON (switching it off would only draw the HUD flat and was saved to the settings by mistake)"); break;
        default: break;   // the controller reading cannot be switched off: the log line is the information
      }
    }
  }
}
