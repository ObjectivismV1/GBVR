// 0.66 cached "is this memory readable" check.
//
// The 0.64 profile showed the body code (bodyPush) using about 8 ms of every ~26 ms frame pair although its own maths takes
// microseconds. The cause that fits the numbers: every push asked Windows (VirtualQuery) whether a pointer into the player's
// object is readable, ~20 times per frame. VirtualQuery has to walk the page tables of the whole committed region the address
// is in; for the game's big heap blocks that can take far longer than the call looks.
//
// Here a region that VirtualQuery described is remembered for a short time (kTtlMs). Later checks inside the same region are a
// few comparisons. The game's heap blocks live for the whole level, so a region that was committed 0.2 s ago is committed now;
// only a block released in the last 0.2 s could be wrongly accepted, and the callers only read pointers the game itself is
// using right now. Many threads call this: one tiny spin flag guards the slots; when it is busy the call just does the full
// check (never waits).
#pragma once
#include <windows.h>
#include <stdint.h>

namespace memcache {

enum { kSlots = 16, kTtlMs = 200 };
struct Slot { uintptr_t base, end; DWORD tick; int writable; };
inline Slot g_slot[kSlots];
inline volatile LONG g_lock;
inline volatile LONG g_next;
inline volatile LONG g_hits, g_misses, g_busy, g_bad;
inline volatile LONG64 g_vqTicks;      // QueryPerformanceCounter ticks spent inside VirtualQuery
inline volatile LONG g_vqMaxUs;
inline volatile LONG g_enabled = 1;    // 0 = every call is a full VirtualQuery (settings: mem_cache=0)

// QPF is constant for the lifetime of Windows.  Cache it once; cache misses are
// exactly the path we are trying to make cheaper.
inline LONG64 perf_freq() {
  static volatile LONG64 f = 0;
  LONG64 v = f;
  if (!v) {
    LARGE_INTEGER q; QueryPerformanceFrequency(&q);
    InterlockedCompareExchange64(&f, q.QuadPart ? q.QuadPart : 1, 0);
    v = f;
  }
  return v ? v : 1;
}

// needAlign: the 4-byte rule of the old memory_readable (strings and single bytes pass 0)
inline int readable(const void* p, size_t n, int write, int needAlign) {
  if (!p) return 0;
  if (needAlign && ((uintptr_t)p & 3)) return 0;
  const uintptr_t a = (uintptr_t)p, e = a + n;
  if (e < a) return 0;
  const DWORD now = GetTickCount();
  if (g_enabled) {
    if (InterlockedCompareExchange(&g_lock, 1, 0) == 0) {
      int hit = 0;
      for (int i = 0; i < kSlots; ++i) {
        const Slot& s = g_slot[i];
        if (s.base && a >= s.base && e <= s.end && (DWORD)(now - s.tick) < (DWORD)kTtlMs && (!write || s.writable)) { hit = 1; break; }
      }
      InterlockedExchange(&g_lock, 0);
      if (hit) { InterlockedIncrement(&g_hits); return 1; }
    } else InterlockedIncrement(&g_busy);
  }
  LARGE_INTEGER t0, t1;
  QueryPerformanceCounter(&t0);
  MEMORY_BASIC_INFORMATION mbi;
  const SIZE_T got = VirtualQuery(p, &mbi, sizeof(mbi));
  QueryPerformanceCounter(&t1);
  InterlockedIncrement(&g_misses);
  {
    const LONG64 fq = perf_freq();
    const LONG64 d = t1.QuadPart - t0.QuadPart;
    InterlockedExchangeAdd64(&g_vqTicks, d);
    const LONG us = (LONG)(d * 1000000 / fq);
    if (us > g_vqMaxUs) InterlockedExchange(&g_vqMaxUs, us);
  }
  if (got != sizeof(mbi)) { InterlockedIncrement(&g_bad); return 0; }
  if (mbi.State != MEM_COMMIT || (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS))) { InterlockedIncrement(&g_bad); return 0; }
  const DWORD rd = PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
  const DWORD wr = PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
  if (!(mbi.Protect & rd)) { InterlockedIncrement(&g_bad); return 0; }
  const uintptr_t rb = (uintptr_t)mbi.BaseAddress, re = rb + mbi.RegionSize;
  const int canWrite = (mbi.Protect & wr) != 0;
  if (g_enabled && InterlockedCompareExchange(&g_lock, 1, 0) == 0) {   // remember the region (the whole run of pages from this one on)
    int idx = -1;
    for (int i = 0; i < kSlots; ++i) if (g_slot[i].base == rb && g_slot[i].end == re) { idx = i; break; }   // same region again: refresh it
    if (idx < 0) idx = (int)((DWORD)InterlockedIncrement(&g_next) % (DWORD)kSlots);
    g_slot[idx].base = rb; g_slot[idx].end = re; g_slot[idx].tick = now; g_slot[idx].writable = canWrite;
    InterlockedExchange(&g_lock, 0);
  }
  if (write && !canWrite) return 0;
  return e <= re;
}

}  // namespace memcache
