// 0.42 VR menus.
//
// While the game shows a menu (no 3D picture) the picture is on a flat screen in front of the player (stereo.cpp).
// That screen is a SteamVR overlay with "mouse" input: SteamVR draws a laser from each controller and reports where
// it hits the screen; the trigger is the left mouse button, the grip-side button the right one, the stick scrolls.
// Here those events become the window messages a real mouse would send to the game window (the game's own
// message handler, patched in mouse.cpp, already maps window pixels to picture pixels).
#include "gbvr.h"
#include "vr_pose.h"

#if GBVR_HEADTRACK
static int g_down;            // bit mask of buttons we pressed: 1 left, 2 right, 4 middle
static int g_lastX = -1, g_lastY = -1;
static volatile LONG g_evMove, g_evDown, g_evUp, g_evScroll, g_posted, g_noWindow, g_logged;
static float g_lastU = -1, g_lastV = -1;
// 1.3: where the laser hits the screen now (picture coordinates, v from the top); the ring cursor (flatcursor.cpp) is drawn there
static float g_ptrU = -1, g_ptrV = -1;
static DWORD g_ptrMs;
static volatile LONG g_ptrLogs, g_suppressed;

static LPARAM pack(int x, int y) { return (LPARAM)(uint32_t)(((uint32_t)(uint16_t)y << 16) | (uint32_t)(uint16_t)x); }

static HWND game_window() {
  HWND w = g_ctl.gameHwnd;
  return (w && IsWindow(w)) ? w : nullptr;
}

static WPARAM key_state(int buttons) {
  WPARAM w = 0;
  if (buttons & 1) w |= MK_LBUTTON;
  if (buttons & 2) w |= MK_RBUTTON;
  if (buttons & 4) w |= MK_MBUTTON;
  return w;
}

// 1.3: 1 while the laser was on the screen in the last 0.4 s (and the VR menu is not in front of it)
int menu_pointer(float* u, float* v, int* down) {
  if (!g_ptrMs || (int32_t)(GetTickCount() - g_ptrMs) > 400 || g_ptrU < 0.0f) return 0;
  *u = g_ptrU; *v = g_ptrV; *down = (g_down & 1) ? 1 : 0;
  return 1;
}

void menu_pump() {
  GbvrOverlayEvt ev[64];
  int n = vr_capi_overlay_events(ev, 64);
  // 1.3: the VR menu is open in front of the screen: the laser events are read and thrown away, the game gets no clicks through the menu
  if (vrmenu_is_open()) {
    if (n > 0) InterlockedExchangeAdd(&g_suppressed, n);
    g_ptrMs = 0;
    if (g_down) menu_release();
    return;
  }
  if (n <= 0) return;
  HWND w = game_window();
  RECT rc;
  if (!w || !GetClientRect(w, &rc) || rc.right < 16 || rc.bottom < 16) { InterlockedIncrement(&g_noWindow); return; }
  // 1.3: while the window shows the picture in its own shape (black bars), the laser's position on the picture goes to the window position the picture
  // pixel is drawn at - the same view mouse.cpp maps back with, so the game gets exactly the point the laser touches
  double vx = 0, vy = 0, vw = (double)rc.right, vh = (double)rc.bottom;
  const int haveView = g_ctl.flatView && flatview_get_view(&vx, &vy, &vw, &vh);
  for (int i = 0; i < n; ++i) {
    const GbvrOverlayEvt& e = ev[i];
    if (e.type == 4) {   // scroll: notches -> wheel delta (120 per notch), screen position of the pointer
      InterlockedIncrement(&g_evScroll);
      POINT p = {g_lastX < 0 ? rc.right / 2 : g_lastX, g_lastY < 0 ? rc.bottom / 2 : g_lastY};
      ClientToScreen(w, &p);
      int delta = (int)(e.scrollY * 120.0f);
      PostMessageW(w, WM_MOUSEWHEEL, (WPARAM)(((uint32_t)(uint16_t)(short)delta << 16) | key_state(g_down)), pack(p.x, p.y));
      InterlockedIncrement(&g_posted);
      continue;
    }
    float u = e.x, v = g_ctl.menuFlip ? e.y : 1.0f - e.y;   // SteamVR counts y from the bottom, windows from the top
    if (!(u >= 0.0f) || !(u <= 1.0f) || !(v >= 0.0f) || !(v <= 1.0f)) continue;
    g_lastU = e.x; g_lastV = e.y;
    g_ptrU = u; g_ptrV = v; g_ptrMs = GetTickCount();
    if (held_menu_pointer((double)u, (double)v, e.type, e.button)) continue;   // 1.7.28: the VR SETTINGS button at the bottom of the hand-held game menu takes its own clicks
    int x = (int)(u * (rc.right - 1) + 0.5f), y = (int)(v * (rc.bottom - 1) + 0.5f);
    if (haveView) {
      x = (int)(vx + (double)u * vw + 0.5); y = (int)(vy + (double)v * vh + 0.5);
      if (x < 0) x = 0; if (x > rc.right - 1) x = rc.right - 1;
      if (y < 0) y = 0; if (y > rc.bottom - 1) y = rc.bottom - 1;
    }
    if (e.type != 1 || (g_lastX >= 0 && (x - g_lastX > 160 || g_lastX - x > 160 || y - g_lastY > 160 || g_lastY - y > 160))) {
      if (InterlockedIncrement(&g_ptrLogs) <= 24)   // the laser's point, the window pixel it became and the view the game maps back with (data for the next version)
        log_line("POINTERMAP %s laser uv=%.4f,%.4f -> window pixel %d,%d of %dx%d, view=%s %.0f,%.0f %.0fx%.0f (the picture pixel the game gets = uv x picture size)",
                 e.type == 1 ? "jump" : e.type == 2 ? "down" : "up", (double)u, (double)v, x, y, (int)rc.right, (int)rc.bottom, haveView ? "letterbox" : "full window", vx, vy, vw, vh);
    }
    if (e.type == 1) {
      InterlockedIncrement(&g_evMove);
      if (x != g_lastX || y != g_lastY) {
        PostMessageW(w, WM_MOUSEMOVE, key_state(g_down), pack(x, y));
        InterlockedIncrement(&g_posted);
      }
    } else if (e.type == 2 || e.type == 3) {
      int bit = e.button == 2 ? 2 : e.button == 4 ? 4 : 1;
      UINT msg;
      if (e.type == 2) { InterlockedIncrement(&g_evDown); msg = bit == 1 ? WM_LBUTTONDOWN : bit == 2 ? WM_RBUTTONDOWN : WM_MBUTTONDOWN; }
      else { InterlockedIncrement(&g_evUp); msg = bit == 1 ? WM_LBUTTONUP : bit == 2 ? WM_RBUTTONUP : WM_MBUTTONUP; }
      if (x != g_lastX || y != g_lastY) PostMessageW(w, WM_MOUSEMOVE, key_state(g_down), pack(x, y));   // the pointer is there before the click
      if (e.type == 2) g_down |= bit; else g_down &= ~bit;
      PostMessageW(w, msg, key_state(g_down), pack(x, y));
      InterlockedExchangeAdd(&g_posted, 2);
      if (InterlockedIncrement(&g_logged) <= 6)
        log_line("MENU click %s button=%d at %.3f,%.3f -> window pixel %d,%d of %dx%d (reversed=%d)", e.type == 2 ? "down" : "up", e.button,
                 (double)e.x, (double)e.y, x, y, (int)rc.right, (int)rc.bottom, (int)g_ctl.menuFlip);
    }
    g_lastX = x; g_lastY = y;
  }
}

// 1.7.29: the hand-held menu's own pointer (heldmenu.cpp) speaks to the game like SteamVR's laser did: u, v in 0..1 of the picture (v from the top), type 1 move, 2 button down, 3 button up,
// 5 wheel (button = notches, + up). The ring cursor follows the point. 1 = delivered.
static volatile LONG g_ownMoves, g_ownDowns, g_ownUps, g_ownWheels;
int menu_inject(double uu, double vv, int type, int button) {
  HWND w = game_window();
  RECT rc;
  if (!w || !GetClientRect(w, &rc) || rc.right < 16 || rc.bottom < 16) { InterlockedIncrement(&g_noWindow); return 0; }
  if (!(uu >= 0.0) || !(uu <= 1.0) || !(vv >= 0.0) || !(vv <= 1.0)) return 0;
  g_ptrU = (float)uu; g_ptrV = (float)vv; g_ptrMs = GetTickCount();
  g_lastU = (float)uu; g_lastV = g_ctl.menuFlip ? (float)vv : 1.0f - (float)vv;
  if (type != 5 && held_menu_pointer(uu, vv, type, button)) return 1;   // the VR SETTINGS button at the bottom of the picture takes its own clicks
  double vx = 0, vy = 0, vw = (double)rc.right, vh = (double)rc.bottom;
  const int haveView = g_ctl.flatView && flatview_get_view(&vx, &vy, &vw, &vh);
  int x = (int)(uu * (rc.right - 1) + 0.5), y = (int)(vv * (rc.bottom - 1) + 0.5);
  if (haveView) {
    x = (int)(vx + uu * vw + 0.5); y = (int)(vy + vv * vh + 0.5);
    if (x < 0) x = 0; if (x > rc.right - 1) x = rc.right - 1;
    if (y < 0) y = 0; if (y > rc.bottom - 1) y = rc.bottom - 1;
  }
  if (type == 5) {   // wheel: the position first (the game scrolls the list under the pointer)
    POINT p = {x, y};
    ClientToScreen(w, &p);
    PostMessageW(w, WM_MOUSEWHEEL, (WPARAM)(((uint32_t)(uint16_t)(short)(button * 120) << 16) | key_state(g_down)), pack(p.x, p.y));
    InterlockedIncrement(&g_ownWheels); InterlockedIncrement(&g_posted);
    return 1;
  }
  if (x != g_lastX || y != g_lastY) { PostMessageW(w, WM_MOUSEMOVE, key_state(g_down), pack(x, y)); InterlockedIncrement(&g_posted); InterlockedIncrement(&g_ownMoves); }
  if (type == 2 || type == 3) {
    const int bit = button == 2 ? 2 : 1;
    UINT msg;
    if (type == 2) { msg = bit == 1 ? WM_LBUTTONDOWN : WM_RBUTTONDOWN; g_down |= bit; InterlockedIncrement(&g_ownDowns); }
    else { msg = bit == 1 ? WM_LBUTTONUP : WM_RBUTTONUP; g_down &= ~bit; InterlockedIncrement(&g_ownUps); }
    PostMessageW(w, msg, key_state(g_down), pack(x, y));
    InterlockedIncrement(&g_posted);
    if (InterlockedIncrement(&g_logged) <= 12)
      log_line("MENU own pointer click %s at %.3f,%.3f -> window pixel %d,%d of %dx%d (1.7.29: the hand-held menu's own pointer, not SteamVR's laser)", type == 2 ? "down" : "up", uu, vv, x, y, (int)rc.right, (int)rc.bottom);
  }
  g_lastX = x; g_lastY = y;
  return 1;
}
// the own pointer left the panel: the ring goes away
void menu_pointer_clear() { g_ptrMs = 0; }

// Leaving the flat screen: a button that is still down is released.
void menu_release() {
  if (!g_down) return;
  HWND w = game_window();
  if (w) {
    int x = g_lastX < 0 ? 0 : g_lastX, y = g_lastY < 0 ? 0 : g_lastY;
    if (g_down & 1) PostMessageW(w, WM_LBUTTONUP, 0, pack(x, y));
    if (g_down & 2) PostMessageW(w, WM_RBUTTONUP, 0, pack(x, y));
    if (g_down & 4) PostMessageW(w, WM_MBUTTONUP, 0, pack(x, y));
  }
  g_down = 0;
}

// 1.7.93 MENUFLOW: "I cannot select anything in the menu / I only see it on the desktop". One line, only for people who used a menu, and only when a number changed since the last one.
// It says whether the picture reached SteamVR, whether each hand was tracked, whether the pointer landed on the panel, whether the trigger was counted.
static void menu_flow_report(const char* why) {
  static char s_prev[1250];
  static int s_lines;
  char h[640], v[480], now[1250];   // about 540 + 370 characters at most; the log line holds 1536
  const long uh = held_menu_flow(h, (int)sizeof(h)), uv = vrmenu_flow(v, (int)sizeof(v));
  if (!uh && !uv) return;
  log_fmt(now, (int)sizeof(now), "%s | %s", h, v);
  if (lstrcmpA(now, s_prev) == 0 || s_lines >= 60) return;
  ++s_lines;
  lstrcpynA(s_prev, now, (int)sizeof(s_prev));
  GbvrHandRaw a, b;
  const int okL = vr_capi_hand_measured(0, &a), okR = vr_capi_hand_measured(1, &b);
  log_line("MENUFLOW %s | hands tracked now: left %s, right %s, left-handed play %s, smooth turn %s | %s", why ? why : "", okL ? "yes" : "NO", okR ? "yes" : "NO", g_ctl.leftHanded ? "ON" : "off", g_ctl.turnSnap ? "off (snap)" : "ON", now);
}

// 1.7.85 INPUTFLOW: one line that answers "do the controllers reach the game / the menu right now". Every number is the change since the previous INPUTFLOW line.
void input_flow_report(const char* why) {
  static long pGs, pFk, pMg, pMove, pDown, pUp, pPosted, pSupp, pNoWin;
  static int64_t pQ;
  long gs = 0, fk = 0, mg = 0; int hook = 0;
  xinput_bridge_counts(&gs, &fk, &mg, &hook);
  ControllersFlow f;
  controllers_flow_take(&f);
  const int64_t nq = qpc_now();
  const double secs = pQ ? (double)(nq - pQ) / (double)qpc_freq() : 0.0;
  pQ = nq;
  HWND fg = GetForegroundWindow(), gw = g_ctl.gameHwnd;
  int ctype = -1; long ctTries = 0, ctOk = 0;
  engine_controller_type(&ctype, &ctTries, &ctOk);
  const long evMove = g_evMove, evDown = g_evDown, evUp = g_evUp, posted = g_posted, supp = g_suppressed, noWin = g_noWindow;
  int axL[5], axR[5], lookL = 0, lookR = 0;   // 1.7.87: which analog axis each hand's stick really uses (largest push so far, per mille)
  vr_capi_axis_peaks(0, axL, &lookL);
  vr_capi_axis_peaks(1, axR, &lookR);
  long padSt[4]; unsigned long long padDi[4];
  engine_pad_slots(padSt, padDi);
  long xCaps = 0, xRep = 0;
  xinput_bridge_more(&xCaps, &xRep);
  long xFlag[4]; engine_pad_xflags(xFlag);                   // 1.7.92
  long tdTries = 0, tdRuns = 0, tdClosed = 0;
  xinput_bridge_di_stats(&tdTries); engine_di_takeover_stats(&tdRuns, &tdClosed);
  const int anyDi = padDi[0] || padDi[1] || padDi[2] || padDi[3];
  {   // 1.7.91: in play, controllers tracked, game type = gamepad, and the game has not asked Windows for the pad once: say so (once) in plain words
    static int s_silent, s_hinted;
    const int inPlay = !stereo_in_flat_mode() && f.validL && f.validR && ctype == 1;
    if (inPlay && hook == 1 && gs - pGs == 0 && secs >= 5.0) ++s_silent; else if (gs - pGs > 0) s_silent = 0;
    // 1.7.92: when the game has DirectInput pads open the mod closes them by itself (DITAKEOVER); the hint is only for what is left after that
    if (s_silent >= 2 && !s_hinted && (!anyDi || tdTries >= 2)) {
      s_hinted = 1;
      log_line("ENVHINT The game is in play with your controllers tracked, but it has not read the gamepad even once in %.0f s, so walking with the left stick cannot work (turning and buttons come through the mod and still do). Try: Steam > right-click the game > Properties > Controller > set \"Disable Steam Input\", close other controller programs, restart the game, and send a new report.", secs);
    }
  }
  log_line("INPUTFLOW %s (last %.1f s) | the game's controller type is %d (0 mouse+keyboard: the pad is IGNORED in play, 1 gamepad), switched to gamepad %ld times of %ld tries | the game read the pad %ld times (a real pad was there %ld, none %ld), xinput hook %s | controller layer: left %s right %s tracked, "
           "pad handed to the game %ld times, withheld %ld times | VR buttons seen 0x%llx, pad buttons given to the game 0x%04x, biggest stick %d%% | SteamVR gives the game the controller input=%d (1 yes, 0 no, -1 unknown), scene app=%d | "
           "game window is the active window=%d (active %p, game %p, minimised=%d) | screen: flat=%d, VR pages open=%d (live %d), hand-held game menu=%d | laser on the 2D screen: moves %ld, presses %ld, releases %ld, "
           "sent to the game %ld, thrown away behind the VR pages %ld, no game window %ld, laser seen in the last 0.4 s=%d | "
           "largest push on each analog axis 0..4 (per mille; the stick is axis 0 on Touch-style, 3 on Index, 2 on Windows MR): left %d/%d/%d/%d/%d right %d/%d/%d/%d/%d, Index look-alike left=%d right=%d | the game's pad slots: state %ld/%ld/%ld/%ld (0 none, 2 XInput pad, 12 DirectInput pad), DirectInput device %llx/%llx/%llx/%llx, capability asks %ld, import slots repaired %ld | XInput flag per slot %ld/%ld/%ld/%ld, DI takeovers asked %ld run %ld closed %ld",
           why ? why : "", secs, ctype, ctOk, ctTries, gs - pGs, mg - pMg, fk - pFk, hook == 1 ? "installed" : "NOT installed", f.validL ? "yes" : "no", f.validR ? "yes" : "no",
           f.padHit, f.padMiss, f.rawButtons, f.padButtons, f.stick * 100 / 32767,
           vr_capi_input_available(), vr_capi_is_scene(),
           (fg && fg == gw) ? 1 : 0, (void*)fg, (void*)gw, (gw && IsIconic(gw)) ? 1 : 0,
           stereo_in_flat_mode() ? 1 : 0, vrmenu_is_open() ? 1 : 0, vrmenu_is_live() ? 1 : 0, held_menu_active() ? 1 : 0,
           evMove - pMove, evDown - pDown, evUp - pUp, posted - pPosted, supp - pSupp, noWin - pNoWin,
           (g_ptrMs && (int32_t)(GetTickCount() - g_ptrMs) <= 400) ? 1 : 0,
           axL[0], axL[1], axL[2], axL[3], axL[4], axR[0], axR[1], axR[2], axR[3], axR[4], lookL, lookR,
           padSt[0], padSt[1], padSt[2], padSt[3], padDi[0], padDi[1], padDi[2], padDi[3], xCaps, xRep, xFlag[0], xFlag[1], xFlag[2], xFlag[3], tdTries, tdRuns, tdClosed);
  pGs = gs; pFk = fk; pMg = mg; pMove = evMove; pDown = evDown; pUp = evUp; pPosted = posted; pSupp = supp; pNoWin = noWin;
  menu_flow_report(why);   // 1.7.93
}

void menu_report() {
  log_line("MENU pointer events move=%d down=%d up=%d scroll=%d posted=%d noWindow=%d last=%.3f,%.3f reversed=%d ignoredWhileVrMenuOpen=%d | 1.7.29 own pointer: moves=%d downs=%d ups=%d wheel=%d", (int)g_evMove, (int)g_evDown,
           (int)g_evUp, (int)g_evScroll, (int)g_posted, (int)g_noWindow, (double)g_lastU, (double)g_lastV, (int)g_ctl.menuFlip, (int)g_suppressed, (int)g_ownMoves, (int)g_ownDowns, (int)g_ownUps, (int)g_ownWheels);
}
#endif
