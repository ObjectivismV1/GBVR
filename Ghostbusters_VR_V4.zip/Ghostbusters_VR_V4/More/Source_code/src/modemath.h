// 0.69 the avatar's eye height by its MOST COMMON value. 0.68 kept a running mean of the avatar's eye height above its feet; the
// animations (breathing, shifting weight, walking, a dodge, a cutscene pose) pulled that mean between 4.7 and 5.5 ft, the body scale
// followed and the whole avatar breathed in and out. A histogram does not care how far the rare poses go: the standing pose is the
// tallest peak, and old samples fade out slowly (a different skin or suit settles in half a minute).
// Pure math, no libm; unit-tested in tests/test_modemath.cpp.
#pragma once

namespace modem {

struct Hist {
  enum { N = 180 };
  double lo, step;
  float cnt[N];
  int n;          // samples added in all
  int sinceDecay;
  float total;    // sum of cnt
  void init(double low, double high) {
    lo = low; step = (high - low) / (double)N;
    for (int i = 0; i < N; ++i) cnt[i] = 0;
    n = 0; sinceDecay = 0; total = 0;
  }
  void add(double v) {
    if (!(v >= lo)) return;
    const int i = (int)((v - lo) / step);
    if (i < 0 || i >= N) return;
    cnt[i] += 1.0f; total += 1.0f; ++n;
    if (++sinceDecay >= 64) {   // half-life about 2200 samples: 20-40 seconds of play
      sinceDecay = 0;
      float t = 0;
      for (int k = 0; k < N; ++k) { cnt[k] *= 0.98f; t += cnt[k]; }
      total = t;
    }
  }
  // The value of the tallest peak (three neighbouring bins together, so a peak that straddles two bins is not split). 0 = not enough samples.
  double mode(float* peakShare = 0) const {
    if (total < 40.0f) return 0.0;
    int best = -1; float bw = 0;
    for (int i = 0; i < N; ++i) {
      float w = cnt[i] + (i > 0 ? cnt[i - 1] : 0.0f) + (i + 1 < N ? cnt[i + 1] : 0.0f);
      if (w > bw) { bw = w; best = i; }
    }
    if (best < 0 || bw < 25.0f) return 0.0;
    double sw = 0, sv = 0;
    for (int k = best - 1; k <= best + 1; ++k) {
      if (k < 0 || k >= N) continue;
      sw += cnt[k]; sv += cnt[k] * (lo + ((double)k + 0.5) * step);
    }
    if (peakShare) *peakShare = (float)(bw / total);
    return sw > 0 ? sv / sw : 0.0;
  }
};

}  // namespace modem
