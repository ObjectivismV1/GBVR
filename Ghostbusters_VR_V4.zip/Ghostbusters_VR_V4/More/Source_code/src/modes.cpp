// 0.26 sharper picture: the game draws a bigger picture than the monitor shows.
//
// How the game chooses its picture size (verified in the executable, see
// layout.h "Display modes"):
//   - it asks every DXGI output for its display-mode list
//     (IDXGIOutput::GetDisplayModeList, two calls: count, then fill) and keeps
//     the distinct width x height pairs;
//   - it looks for the size saved in its settings in that list; if it is not
//     there it takes the entry equal to the desktop size; if that is not there
//     either it takes the first entry (the same code in three places: start-up
//     0x3B7DD0, options 0x301800, window/device routine 0x48A550);
//   - the swap chain's back buffer gets that size, while the borderless
//     window covers the monitor: DXGI stretches the picture into the window.
//     The game's whole renderer and menu follow the back-buffer size - this
//     is the same path a player uses who picks an NVIDIA DSR resolution in
//     the game's options.
// So the probe changes nothing inside the game: for the game's own two
// mode-list calls it answers with exactly one mode, the wanted picture size.
// The game then selects it by its own rules. Nothing is written to the game's
// variables by the probe; without the probe the saved size is simply not in
// the list any more and the game falls back to the desktop size.
// Any other caller of GetDisplayModeList (DXGI itself, Steam, SteamVR) gets the
// real list.
// The level is fixed for the whole run when the hook is installed (the game
// lists its modes more than once; the answer must never change in between).
#include "gbvr.h"

#if GBVR_HEADTRACK
#include "layout.h"
#include "picturemath.h"
#include "MinHook.h"
#include <dxgi.h>

typedef HRESULT(STDMETHODCALLTYPE* PFN_GetDisplayModeList)(IDXGIOutput*, DXGI_FORMAT, UINT, UINT*, DXGI_MODE_DESC*);
static PFN_GetDisplayModeList o_getModes;
static int g_installState;                // 1 hooked, 0 not tried, <0 why not
static volatile LONG g_gameCalls, g_replaced, g_otherCalls, g_passedThrough;
static LONG g_runLines = 0;               // 1.7.117: explicit picture lines of this run (0 = by level)
static LONG g_runLevel = 1;               // level of this run, fixed at install time
static volatile LONG g_activeLevel = 1;   // g_runLevel once the game was actually given the bigger mode
static UINT g_givenW, g_givenH, g_deskW, g_deskH, g_realModes;

int modes_active_level() { return (int)g_activeLevel; }
// 1.7.117: the desktop size the picture levels are worked out from (the VR menu shows the real resolution of each level)
int modes_desktop_size(unsigned* w, unsigned* h) {
  unsigned dw = g_deskW, dh = g_deskH;
  if (!dw || !dh) { const int cx = GetSystemMetrics(SM_CXSCREEN), cy = GetSystemMetrics(SM_CYSCREEN); dw = cx > 0 ? (unsigned)cx : 0; dh = cy > 0 ? (unsigned)cy : 0; }
  if (!dw || !dh) return 0;
  *w = dw; *h = dh;
  return 1;
}
int modes_installed() { return g_installState == 1; }

static HRESULT STDMETHODCALLTYPE hk_getModes(IDXGIOutput* self, DXGI_FORMAT fmt, UINT flags, UINT* num,
                                             DXGI_MODE_DESC* desc) {
  uintptr_t ret = (uintptr_t)GBVR_RETURN_ADDRESS() - g_game.base;
  int fromGame = g_game.identityOK &&
                 (ret == layout::kRvaModeListReturnCount || ret == layout::kRvaModeListReturnFill);
  if (!fromGame) {
    InterlockedIncrement(&g_otherCalls);
    return o_getModes(self, fmt, flags, num, desc);
  }
  InterlockedIncrement(&g_gameCalls);
  LONG level = g_runLevel;
  UINT w = 0, h = 0, n0 = 0;
  DXGI_OUTPUT_DESC od;
  ZeroMemory(&od, sizeof(od));
  int want = level > 1 && num && SUCCEEDED(self->GetDesc(&od));
  if (want) {
    UINT dw = (UINT)(od.DesktopCoordinates.right - od.DesktopCoordinates.left);
    UINT dh = (UINT)(od.DesktopCoordinates.bottom - od.DesktopCoordinates.top);
    uint32_t pw = 0, ph = 0;
    want = g_runLines >= (LONG)picture::kMinLines ? picture::lines_size((uint32_t)g_runLines, dw, dh, &pw, &ph) : picture::level_size((int)level, dw, dh, &pw, &ph);
    w = pw; h = ph;
    g_deskW = dw; g_deskH = dh;
  }
  // The output must really have modes for this format; otherwise the game's
  // own handling of an unusable output stays exactly as it is.
  if (want) want = SUCCEEDED(o_getModes(self, fmt, flags, &n0, nullptr)) && n0 > 0;
  if (!want) {
    InterlockedIncrement(&g_passedThrough);
    return o_getModes(self, fmt, flags, num, desc);
  }
  if (!desc) {  // first call: how many modes?
    *num = 1;
    return S_OK;
  }
  if (*num < 1) return DXGI_ERROR_MORE_DATA;
  // Second call: one mode. Refresh rate and the like are copied from the
  // output's highest real mode (the game only reads width and height).
  DXGI_MODE_DESC m;
  ZeroMemory(&m, sizeof(m));
  DXGI_MODE_DESC* real = (DXGI_MODE_DESC*)HeapAlloc(GetProcessHeap(), 0, (SIZE_T)n0 * sizeof(DXGI_MODE_DESC));
  if (real) {
    UINT n = n0;
    if (SUCCEEDED(o_getModes(self, fmt, flags, &n, real)) && n > 0 && n <= n0) m = real[n - 1];
    HeapFree(GetProcessHeap(), 0, real);
  }
  if (!m.RefreshRate.Numerator || !m.RefreshRate.Denominator) { m.RefreshRate.Numerator = 60; m.RefreshRate.Denominator = 1; }
  m.Width = w;
  m.Height = h;
  m.Format = fmt;
  m.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_PROGRESSIVE;
  m.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
  desc[0] = m;
  *num = 1;
  LONG count = InterlockedIncrement(&g_replaced);
  g_givenW = w; g_givenH = h; g_realModes = n0;
  InterlockedExchange(&g_activeLevel, level);
  if (count == 1) startup_mark_picture();
  if (count <= 4) {  // the first few answers in full, afterwards the counters in PICTURE
    log_line("PICTURE level %d = %s: the game's display-mode list (%u real modes, desktop %u x %u, format %d) was "
             "answered with the single mode %u x %u", (int)level, picture::level_name((int)level), n0, g_deskW, g_deskH,
             (int)fmt, w, h);
    log_flush();
  }
  return S_OK;
}

void modes_install(void* dxgiFactory) {
  if (g_installState) return;
  if (!g_game.identityOK) {  // unknown executable: the two call sites are not known
    g_installState = -1;
    log_line("PICTURE not available: unknown game executable (the game chooses its picture size as usual)");
    return;
  }
  const uint8_t* c1 = (const uint8_t*)rva(layout::kRvaModeListCallCount);
  const uint8_t* c2 = (const uint8_t*)rva(layout::kRvaModeListCallFill);
  for (int i = 0; i < 3; ++i) if (c1[i] != layout::kBytesModeListCallCount[i]) g_installState = -5;
  for (int i = 0; i < 4; ++i) if (c2[i] != layout::kBytesModeListCallFill[i]) g_installState = -5;
  if (g_installState) {
    log_line("PICTURE not available: the game's display-mode calls are not where they are expected");
    return;
  }
  IDXGIFactory* f = nullptr;
  if (!dxgiFactory || FAILED(((IUnknown*)dxgiFactory)->QueryInterface(__uuidof(IDXGIFactory), (void**)&f)) || !f) {
    g_installState = -2;
    log_line("PICTURE not available: no IDXGIFactory");
    return;
  }
  // Every IDXGIOutput of dxgi.dll shares one implementation: take the function
  // from the first output that exists.
  void* target = nullptr;
  for (UINT a = 0; a < 8 && !target; ++a) {
    IDXGIAdapter* ad = nullptr;
    if (FAILED(f->EnumAdapters(a, &ad)) || !ad) break;
    IDXGIOutput* o = nullptr;
    if (SUCCEEDED(ad->EnumOutputs(0, &o)) && o) {
      target = (*(void***)o)[8];  // IDXGIOutput::GetDisplayModeList
      {   // 1.7.117: the real desktop size in pixels (the VR menu's Resolution row shows picture sizes from it; GetSystemMetrics can be DPI-scaled)
        DXGI_OUTPUT_DESC od0;
        ZeroMemory(&od0, sizeof(od0));
        if (SUCCEEDED(o->GetDesc(&od0)) && !g_deskW) {
          const LONG dw0 = od0.DesktopCoordinates.right - od0.DesktopCoordinates.left, dh0 = od0.DesktopCoordinates.bottom - od0.DesktopCoordinates.top;
          if (dw0 >= 640 && dh0 >= 480) { g_deskW = (UINT)dw0; g_deskH = (UINT)dh0; }
        }
      }
      o->Release();
    }
    ad->Release();
  }
  f->Release();
  if (!target) {
    g_installState = -3;
    log_line("PICTURE not available: no display output found");
    return;
  }
  MH_STATUS s = MH_CreateHook(target, (void*)hk_getModes, (void**)&o_getModes);
  if (s == MH_OK) s = MH_EnableHook(target);
  g_installState = s == MH_OK ? 1 : -4;
  LONG lv = g_ctl.pictureLevel;
  if (lv < picture::kLevelMin || lv > picture::kLevelMax) lv = 1;
  {   // 1.7.117: an explicit size (VR menu Resolution) switches the hook on at level 2 (the levels >= 3 rules of the memory guard do not apply to a smaller picture)
    const LONG pl = g_ctl.pictureLines;
    g_runLines = (pl >= (LONG)picture::kMinLines && pl <= (LONG)picture::kMaxLines) ? pl : 0;
    if (g_runLines) lv = 2;
  }
  g_runLevel = (g_installState == 1 && !g_pictureOff) ? lv : 1;
  log_line("HOOK display-mode-list status=%d target=%p; picture level of this run: %d = %s (saved level %d, picture_lines %d)%s", (int)s,
           target, (int)g_runLevel, picture::level_name((int)g_runLevel), (int)g_ctl.pictureLevel, (int)g_runLines,
           g_pictureOff ? " - switched OFF by gbvr_picture_off.txt" : "");
  mouse_install();
}

void modes_report() {
  log_line("PICTURE savedLevel=%d runLevel=%d active=%d given=%ux%u desktop=%ux%u gameCalls=%d replaced=%d "
           "passedThrough=%d otherCallers=%d hook=%d off=%d", (int)g_ctl.pictureLevel, (int)g_runLevel, (int)g_activeLevel,
           g_givenW, g_givenH, g_deskW, g_deskH, (int)g_gameCalls, (int)g_replaced, (int)g_passedThrough,
           (int)g_otherCalls, g_installState, g_pictureOff);
  mouse_report();
}

#endif
