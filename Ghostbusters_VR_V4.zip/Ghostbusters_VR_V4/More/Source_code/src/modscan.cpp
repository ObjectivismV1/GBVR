// 0.96 mod scan: what else is in the game folder and in the game process (other mods, loaders, overlays), written to the log as MODSCAN lines.
//
// Why: the probe is a d3d11.dll in the game folder; other mods are files next to it or code loaded beside it. When a report arrives, these lines say
// which mods were there, whether ghost.exe is the one the probe was built for, and which DLLs were loaded, without anyone describing the PC.
//
// Read-only. Runs on its own low-priority thread a few seconds after the start, so the game is never held up. It only lists, never opens a mod's
// files for writing, and never touches winmm.dll / .asi files (the intro-skip mod).
#include "gbvr.h"
#include "layout.h"
#include "modscanmath.h"
#include "MinHook.h"

#if GBVR_HEADTRACK

namespace {

typedef BOOL(WINAPI* PFN_EnumProcessModules)(HANDLE, HMODULE*, DWORD, LPDWORD);
typedef DWORD(WINAPI* PFN_GetModuleFileNameExW)(HANDLE, HMODULE, LPWSTR, DWORD);
typedef DWORD(WINAPI* PFN_GetFileVersionInfoSizeW)(LPCWSTR, LPDWORD);
typedef BOOL(WINAPI* PFN_GetFileVersionInfoW)(LPCWSTR, DWORD, DWORD, LPVOID);
typedef BOOL(WINAPI* PFN_VerQueryValueW)(LPCVOID, LPCWSTR, LPVOID*, PUINT);

volatile LONG g_started;

int to_u8(const wchar_t* w, char* o, int n) {
  if (n <= 0) return 0;
  o[0] = 0;
  const int k = WideCharToMultiByte(CP_UTF8, 0, w, -1, o, n, nullptr, nullptr);
  if (k <= 0) { o[n - 1] = 0; return 0; }
  return k - 1;
}

void fmt_date(uint64_t ft, char* out) {
  int y, m, d;
  modscan::ymd_from_day(modscan::day_of(ft), &y, &m, &d);
  wsprintfA(out, "%04d-%02d-%02d", y, m, d);
}
uint64_t ft64(const FILETIME& f) { return ((uint64_t)f.dwHighDateTime << 32) | f.dwLowDateTime; }

// ---- version resource (file version, company, product) -----------------------------------------------------------------------
struct VerInfo { char ver[32]; char company[64]; char product[64]; };

void get_ver(const wchar_t* path, VerInfo* o) {
  lstrcpyA(o->ver, "?"); o->company[0] = 0; o->product[0] = 0;
  static HMODULE v;
  static PFN_GetFileVersionInfoSizeW sz;
  static PFN_GetFileVersionInfoW gi;
  static PFN_VerQueryValueW q;
  if (!v) {
    v = LoadLibraryA("version.dll");
    if (!v) return;
    sz = (PFN_GetFileVersionInfoSizeW)GetProcAddress(v, "GetFileVersionInfoSizeW");
    gi = (PFN_GetFileVersionInfoW)GetProcAddress(v, "GetFileVersionInfoW");
    q = (PFN_VerQueryValueW)GetProcAddress(v, "VerQueryValueW");
  }
  if (!sz || !gi || !q) return;
  DWORD z = 0, len = sz(path, &z);
  if (!len || len > 65536) return;
  static char buf[65536];   // only this thread uses it
  if (!gi(path, 0, len, buf)) return;
  VS_FIXEDFILEINFO* fi = nullptr;
  UINT fl = 0;
  if (q(buf, L"\\", (LPVOID*)&fi, &fl) && fi)
    wsprintfA(o->ver, "%u.%u.%u.%u", (unsigned)HIWORD(fi->dwFileVersionMS), (unsigned)LOWORD(fi->dwFileVersionMS), (unsigned)HIWORD(fi->dwFileVersionLS), (unsigned)LOWORD(fi->dwFileVersionLS));
  WORD* tr = nullptr;
  UINT tl = 0;
  WORD lang = 0x0409, cp = 0x04B0;
  if (q(buf, L"\\VarFileInfo\\Translation", (LPVOID*)&tr, &tl) && tr && tl >= 4) { lang = tr[0]; cp = tr[1]; }
  const wchar_t* keys[2] = {L"CompanyName", L"ProductName"};
  char* outs[2] = {o->company, o->product};
  for (int i = 0; i < 2; ++i) {
    wchar_t sub[96];
    wsprintfW(sub, L"\\StringFileInfo\\%04x%04x\\%s", (unsigned)lang, (unsigned)cp, keys[i]);
    wchar_t* s = nullptr;
    UINT sl = 0;
    if (q(buf, sub, (LPVOID*)&s, &sl) && s && sl) to_u8(s, outs[i], 64);
  }
}

// ---- ghost.exe -------------------------------------------------------------------------------------------------------------------
void scan_exe() {
  wchar_t path[MAX_PATH];
  const DWORD pn = GetModuleFileNameW(nullptr, path, MAX_PATH);
  if (pn == 0 || pn >= MAX_PATH) { log_line("MODSCAN exe path not available"); return; }
  HANDLE h = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, nullptr);
  if (h == INVALID_HANDLE_VALUE) { log_line("MODSCAN exe could not be read (error %lu)", (unsigned long)GetLastError()); return; }
  LARGE_INTEGER sz = {};
  GetFileSizeEx(h, &sz);
  FILETIME mt = {};
  GetFileTime(h, nullptr, nullptr, &mt);
  static uint8_t buf[1 << 20];
  uint32_t crc = 0;
  uint64_t total = 0;
  for (;;) {
    DWORD got = 0;
    if (!ReadFile(h, buf, sizeof(buf), &got, nullptr) || got == 0) break;
    crc = modscan::crc32_update(crc, buf, got);
    total += got;
    if (total > (256ull << 20)) break;   // not a game exe of ours
  }
  CloseHandle(h);
  char date[16];
  fmt_date(ft64(mt), date);
  const int vanilla = (uint64_t)sz.QuadPart == (uint64_t)layout::kVanillaExeFileSize && crc == layout::kVanillaExeCrc32;
  log_line("MODSCAN exe size=%llu crc32=%08x lastWrite=%s sameAsAnalysedGame=%s", (unsigned long long)sz.QuadPart, (unsigned)crc, date, vanilla ? "YES" : "NO");
  if (!vanilla)
    log_line("MODSCAN exe is NOT the file the probe was built for (analysed: size=%u crc32=%08x). identityOK=%d hookBytesOK=%d. The probe only hooks code whose bytes match, "
             "so a changed ghost.exe makes it do less, not break the game.",
             (unsigned)layout::kVanillaExeFileSize, (unsigned)layout::kVanillaExeCrc32, g_game.identityOK, g_game.hookBytesOK);
}

// ---- the game folder ---------------------------------------------------------------------------------------------------------------
struct Agg { int files, dirs; uint64_t bytes, newest, oldest; };
struct Ctx {
  modscan::DayTable days;
  int topLines, dllLines, textLines, noteLines, verCalls;
  int totalFiles, totalDirs, skippedLong, level3, level2, deluxe, modsFiles;
  uint64_t modsAccess, modsWrite;
  uint64_t totalBytes;
  DWORD t0;
  int stop;
};

void agg_add(Agg* a, uint64_t size, uint64_t t) {
  a->files++; a->bytes += size;
  if (t > a->newest) a->newest = t;
  if (!a->oldest || t < a->oldest) a->oldest = t;
}
void agg_merge(Agg* a, const Agg& b) {
  a->files += b.files; a->dirs += b.dirs; a->bytes += b.bytes;
  if (b.newest > a->newest) a->newest = b.newest;
  if (b.oldest && (!a->oldest || b.oldest < a->oldest)) a->oldest = b.oldest;
}

const int kMaxDepth = 4;

void visit(const wchar_t* dir, int depth, const char* rel, Agg* agg, Ctx* c) {
  wchar_t pat[MAX_PATH + 8];
  const int dl = lstrlenW(dir);
  if (dl > MAX_PATH - 8) { c->skippedLong++; return; }
  lstrcpyW(pat, dir);
  lstrcatW(pat, L"*");
  WIN32_FIND_DATAW fd;
  HANDLE h = FindFirstFileExW(pat, FindExInfoBasic, &fd, FindExSearchNameMatch, nullptr, FIND_FIRST_EX_LARGE_FETCH);
  if (h == INVALID_HANDLE_VALUE) return;
  do {
    if (fd.cFileName[0] == L'.' && (fd.cFileName[1] == 0 || (fd.cFileName[1] == L'.' && fd.cFileName[2] == 0))) continue;
    if (c->stop) break;
    if ((c->totalFiles & 255) == 0 && GetTickCount() - c->t0 > 8000) { c->stop = 1; break; }
    if (c->totalFiles > 80000) { c->stop = 1; break; }
    char name[MAX_PATH * 3];
    to_u8(fd.cFileName, name, sizeof(name));
    char relName[MAX_PATH * 3 + 8];
    if (lstrlenA(rel) + lstrlenA(name) + 2 >= (int)sizeof(relName)) { c->skippedLong++; continue; }
    lstrcpyA(relName, rel); lstrcatA(relName, name);
    const uint64_t t = ft64(fd.ftLastWriteTime);
    const unsigned flags = modscan::classify(name);
    if (modscan::icontains(name, "deluxe") && c->deluxe < 6) { c->deluxe++; log_line("MODSCAN deluxe marker: %s", relName); }
    if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
      if (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) { log_line("MODSCAN link (not followed): %s", relName); continue; }
      agg->dirs++; c->totalDirs++;
      const int lvl = modscan::level_of(flags, 0);
      if (lvl >= 1 && c->noteLines < 60) { c->noteLines++; log_line("MODSCAN note folder %s (%s)", relName, modscan::what_is(flags)[0] ? modscan::what_is(flags) : "named like a mod"); }
      if (depth + 1 > kMaxDepth) continue;
      wchar_t sub[MAX_PATH + 8];
      if (dl + lstrlenW(fd.cFileName) + 2 > MAX_PATH - 8) { c->skippedLong++; continue; }
      lstrcpyW(sub, dir); lstrcatW(sub, fd.cFileName); lstrcatW(sub, L"\\");
      char subRel[MAX_PATH * 3 + 8];
      lstrcpyA(subRel, relName); lstrcatA(subRel, "\\");
      if (depth == 0) {
        Agg a = {};
        visit(sub, depth + 1, subRel, &a, c);
        char n[16], o[16];
        fmt_date(a.newest, n); fmt_date(a.oldest, o);
        log_line("MODSCAN dir %s files=%d folders=%d MB=%llu oldest=%s newest=%s", relName, a.files, a.dirs, (unsigned long long)(a.bytes >> 20), a.oldest ? o : "-", a.newest ? n : "-");
        agg_merge(agg, a);
      } else {
        visit(sub, depth + 1, subRel, agg, c);
      }
      continue;
    }
    const uint64_t size = ((uint64_t)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
    agg_add(agg, size, t);
    c->totalFiles++; c->totalBytes += size;
    c->days.add(modscan::day_of(t), size);
    if (modscan::istarts(relName, "MODS\\")) { c->modsFiles++; const uint64_t a = ft64(fd.ftLastAccessTime); if (a > c->modsAccess) c->modsAccess = a; if (t > c->modsWrite) c->modsWrite = t; }
    const int lvl = modscan::level_of(flags, depth == 0);
    if (lvl == 3) c->level3++;
    if (lvl == 2) c->level2++;
    const int binary = (flags & (modscan::F_DLL | modscan::F_EXE | modscan::F_ASI)) != 0;
    int show = 0;
    if (depth == 0) show = c->topLines < 160;
    else if (lvl >= 2) show = c->noteLines < 60;
    else if (binary) show = c->dllLines < 60;
    else if (lvl == 1) show = c->noteLines < 60;
    else if ((flags & modscan::F_TEXT) && depth <= 1 && !(flags & modscan::F_OURS)) show = c->textLines < 40;
    if (!show) continue;
    if (depth == 0) c->topLines++;
    else if (lvl >= 1) c->noteLines++;
    else if (binary) c->dllLines++;
    else c->textLines++;
    char date[16];
    fmt_date(t, date);
    char extra[220];
    extra[0] = 0;
    if (binary && !(flags & modscan::F_OURS) && c->verCalls < 50) {
      c->verCalls++;
      wchar_t full[MAX_PATH + 8];
      if (dl + lstrlenW(fd.cFileName) + 1 < MAX_PATH) {
        lstrcpyW(full, dir); lstrcatW(full, fd.cFileName);
        VerInfo vi;
        get_ver(full, &vi);
        wsprintfA(extra, " version=%s company=\"%s\" product=\"%s\"", vi.ver, vi.company, vi.product);
      }
    }
    const char* what = modscan::what_is(flags);
    log_line("MODSCAN %s %s size=%llu date=%s%s%s%s%s", lvl >= 3 ? "CONFLICT?" : (lvl == 2 ? "WATCH" : "file"), relName, (unsigned long long)size, date,
             what[0] ? " [" : "", what, what[0] ? "]" : "", extra);
  } while (FindNextFileW(h, &fd));
  FindClose(h);
}

// Other folders next to the game's own that hold a ghost.exe (a stand-alone copy of the game with a mod in it is a common way to try one).
void scan_siblings(const wchar_t* gameDir) {
  wchar_t parent[MAX_PATH];
  lstrcpynW(parent, gameDir, MAX_PATH);
  int n = lstrlenW(parent);
  while (n > 0 && (parent[n - 1] == L'\\' || parent[n - 1] == L'/')) parent[--n] = 0;
  while (n > 0 && parent[n - 1] != L'\\' && parent[n - 1] != L'/') parent[--n] = 0;
  if (n < 3 || n > MAX_PATH - 8) return;
  wchar_t own[MAX_PATH];
  lstrcpynW(own, gameDir, MAX_PATH);
  int on = lstrlenW(own);
  while (on > 0 && (own[on - 1] == L'\\' || own[on - 1] == L'/')) own[--on] = 0;
  const wchar_t* ownName = own + n;
  wchar_t pat[MAX_PATH + 8];
  lstrcpyW(pat, parent); lstrcatW(pat, L"*");
  WIN32_FIND_DATAW fd;
  HANDLE h = FindFirstFileExW(pat, FindExInfoBasic, &fd, FindExSearchNameMatch, nullptr, 0);
  if (h == INVALID_HANDLE_VALUE) return;
  int shown = 0, seen = 0;
  do {
    if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || fd.cFileName[0] == L'.') continue;
    if (++seen > 400) break;
    if (lstrcmpiW(fd.cFileName, ownName) == 0) continue;
    wchar_t exe[MAX_PATH + 16];
    if (lstrlenW(parent) + lstrlenW(fd.cFileName) + 12 >= MAX_PATH) continue;
    lstrcpyW(exe, parent); lstrcatW(exe, fd.cFileName); lstrcatW(exe, L"\\ghost.exe");
    if (GetFileAttributesW(exe) == INVALID_FILE_ATTRIBUTES) continue;
    wchar_t pr[MAX_PATH + 16];
    lstrcpyW(pr, parent); lstrcatW(pr, fd.cFileName); lstrcatW(pr, L"\\d3d11.dll");
    char nm[MAX_PATH * 3];
    to_u8(fd.cFileName, nm, sizeof(nm));
    if (shown < 8) { ++shown; log_line("MODSCAN other game folder next to this one: %s (has ghost.exe; d3d11.dll there: %s)", nm, GetFileAttributesW(pr) != INVALID_FILE_ATTRIBUTES ? "yes" : "no"); }
  } while (FindNextFileW(h, &fd));
  FindClose(h);
}

// 1.7.24 "deluxe mod has been added, take note and look for changes specific from that": a read-only look at MODS\<name>\ (version from previews\modinfo.ini, and what data\tweak.txt
// changes: the sections it edits, the hit-point numbers, and how many sections switch the game's own health bar off). Nothing is written and nothing is patched.
int read_small(const wchar_t* path, char* buf, int cap) {
  const HANDLE h = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (h == INVALID_HANDLE_VALUE) return -1;
  DWORD got = 0;
  const BOOL ok = ReadFile(h, buf, (DWORD)(cap - 1), &got, nullptr);
  CloseHandle(h);
  if (!ok) return -1;
  buf[got] = 0;
  return (int)got;
}
void join_path(wchar_t* out, const wchar_t* dir, const wchar_t* a, const wchar_t* b, const wchar_t* c) {
  lstrcpynW(out, dir, MAX_PATH);
  if (a) lstrcatW(out, a);
  if (b) lstrcatW(out, b);
  if (c) lstrcatW(out, c);
}
void deluxe_report_one(const wchar_t* dir, const wchar_t* name) {
  static char buf[65536];
  wchar_t path[MAX_PATH * 2];
  char nm[260];
  to_u8(name, nm, sizeof(nm));
  wchar_t mid[MAX_PATH];
  lstrcpynW(mid, L"MODS\\", MAX_PATH); lstrcatW(mid, name);
  join_path(path, dir, mid, L"\\previews\\modinfo.ini", nullptr);
  char ver[40]; ver[0] = 0;
  char desc[120]; desc[0] = 0;
  int n = read_small(path, buf, (int)sizeof(buf));
  if (n > 0) {
    for (int i = 0; i < n;) {
      int e = i; while (e < n && buf[e] != '\n' && buf[e] != '\r') ++e;
      const char* ln = buf + i; const int ll = e - i;
      if (ll > 9 && modscan::istarts(ln, "version=\"")) { int k = 0; for (int j = 9; j < ll && ln[j] != '"' && k < 38; ++j) ver[k++] = ln[j]; ver[k] = 0; }
      if (ll > 14 && modscan::istarts(ln, "description=\"")) { int k = 0; for (int j = 13; j < ll && ln[j] != '"' && k < 118; ++j) desc[k++] = ln[j]; desc[k] = 0; }
      i = e; while (i < n && (buf[i] == '\n' || buf[i] == '\r')) ++i;
    }
  }
  log_line("DELUXE mod folder MODS\\%s modinfo.ini %s version=%s | %s", nm, n > 0 ? "read" : "not found", ver[0] ? ver : "?", desc[0] ? desc : "-");
  join_path(path, dir, mid, L"\\data\\tweak.txt", nullptr);
  n = read_small(path, buf, (int)sizeof(buf));
  if (n < 0) { log_line("DELUXE MODS\\%s has no data\\tweak.txt (no enemy numbers are changed by it)", nm); return; }
  int sections = 0, healthBarOff = 0, healthBarOn = 0, keysTotal = 0;
  char cur[48]; cur[0] = 0;
  char list[900]; int ll2 = 0; list[0] = 0;
  char secs[500]; int sl = 0; secs[0] = 0;
  for (int i = 0; i < n;) {
    int e = i; while (e < n && buf[e] != '\n' && buf[e] != '\r') ++e;
    const char* ln = buf + i; const int l = e - i;
    if (l > 2 && ln[0] == '[') {
      int k = 0; for (int j = 1; j < l && ln[j] != ']' && k < 46; ++j) cur[k++] = ln[j]; cur[k] = 0;
      ++sections;
      if (sl < 440 && !modscan::icontains(cur, "sound")) sl += wsprintfA(secs + sl, "%s%s", sl ? ", " : "", cur);
    } else if (l > 2) {
      int eq = -1; for (int j = 0; j < l; ++j) if (ln[j] == '=') { eq = j; break; }
      if (eq > 0) {
        ++keysTotal;
        char key[64]; int k = 0; for (int j = 0; j < eq && k < 62; ++j) key[k++] = ln[j]; key[k] = 0;
        char val[24]; int vk = 0; for (int j = eq + 1; j < l && vk < 22; ++j) val[vk++] = ln[j]; val[vk] = 0;
        if (modscan::ieq(key, "Render Health Bar")) { if (val[0] == '0') ++healthBarOff; else ++healthBarOn; }
        if ((modscan::icontains(key, "max") && (modscan::icontains(key, "hit") || modscan::icontains(key, "health"))) && !modscan::icontains(key, "lose") && ll2 < 800)
          ll2 += wsprintfA(list + ll2, "%s%s %s=%s", ll2 ? "; " : "", cur, key, val);
      }
    }
    i = e; while (i < n && (buf[i] == '\n' || buf[i] == '\r')) ++i;
  }
  log_line("DELUXE tweak.txt %d bytes, %d sections, %d settings | sections (not sound): %s", n, sections, keysTotal, secs[0] ? secs : "-");
  log_line("DELUXE max health set by the mod: %s", list[0] ? list : "-");
  log_line("DELUXE \"Render Health Bar=0\" in %d sections (%d say 1): the game's OWN ghost bars are switched off by the mod for those enemies; the probe's small bars read each ghost's live health and max health, so the changed numbers show correctly. "
           "The probe changes no damage or health file and no tweak value (beam_damage_pct is 100).", healthBarOff, healthBarOn);
}
void deluxe_report(const wchar_t* dir) {
  // 1.7.25: the 1.7.24 report showed the Deluxe mod installed as MODS.POD / PATCH.POD next to ghost.exe (no MODS folder any more): say what they are, size and date
  static const wchar_t* const pods[2] = {L"MODS.POD", L"PATCH.POD"};
  for (int i = 0; i < 2; ++i) {
    wchar_t pp[MAX_PATH * 2];
    join_path(pp, dir, pods[i], nullptr, nullptr);
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (GetFileAttributesExW(pp, GetFileExInfoStandard, &fa)) {
      char nm[40], dt[16];
      to_u8(pods[i], nm, sizeof(nm));
      const uint64_t ft = ((uint64_t)fa.ftLastWriteTime.dwHighDateTime << 32) | fa.ftLastWriteTime.dwLowDateTime;
      fmt_date(ft, dt);
      log_line("DELUXE %s present: %llu bytes, written %s (the Deluxe mod installs its changes as a data archive here; its enemy health / tuning / UI files are inside, so the probe cannot list them; the probe changes none of those numbers)",
               nm, (unsigned long long)(((uint64_t)fa.nFileSizeHigh << 32) | fa.nFileSizeLow), dt);
    }
  }
  wchar_t pat[MAX_PATH];
  join_path(pat, dir, L"MODS\\*", nullptr, nullptr);
  WIN32_FIND_DATAW fd;
  const HANDLE h = FindFirstFileW(pat, &fd);
  if (h == INVALID_HANDLE_VALUE) { log_line("DELUXE no MODS folder next to ghost.exe"); return; }
  int shown = 0;
  do {
    if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)) continue;
    if (fd.cFileName[0] == L'.') continue;
    if (shown >= 6) break;
    ++shown;
    deluxe_report_one(dir, fd.cFileName);
  } while (FindNextFileW(h, &fd));
  FindClose(h);
  if (!shown) log_line("DELUXE MODS folder has no mod folders");
}

void scan_folder() {
  wchar_t dir[MAX_PATH];
  lstrcpynW(dir, g_selfDir, MAX_PATH - 2);
  int n = lstrlenW(dir);
  if (n == 0) { log_line("MODSCAN game folder unknown"); return; }
  if (dir[n - 1] != L'\\' && dir[n - 1] != L'/') { dir[n++] = L'\\'; dir[n] = 0; }
  static Ctx c;
  ZeroMemory(&c, sizeof(c));
  c.days.clear();
  c.t0 = GetTickCount();
  Agg total = {};
  char u8[MAX_PATH * 3];
  to_u8(dir, u8, sizeof(u8));
  log_line("MODSCAN folder %s", u8);
  visit(dir, 0, "", &total, &c);
  log_line("MODSCAN folder done: files=%d folders=%d MB=%llu scanMs=%u%s%s", c.totalFiles, c.totalDirs, (unsigned long long)(c.totalBytes >> 20), (unsigned)(GetTickCount() - c.t0),
           c.stop ? " (stopped early: time or count limit)" : "", c.skippedLong ? " (some very long paths skipped)" : "");
  if (c.modsFiles) {
    SYSTEMTIME st; GetSystemTime(&st);
    char na[16], nw[16];
    fmt_date(c.modsAccess, na); fmt_date(c.modsWrite, nw);
    log_line("MODSCAN MODS folder: %d files, newest file written %s, newest 'last opened' date %s, today %04d-%02d-%02d (Windows often does not update the 'last opened' date: a date of today means a file in MODS was opened, an old date proves nothing)",
             c.modsFiles, nw, na, (int)st.wYear, (int)st.wMonth, (int)st.wDay);
  }
  log_line("MODSCAN summary: likelyConflicts=%d watch=%d deluxeMarkers=%d%s", c.level3, c.level2, c.deluxe,
           c.deluxe ? "" : " (nothing is named \"deluxe\"; the mod may use other names: see the busiest days below)");
  // Files written on the same day came in together (a Steam install, a mod unpacked). The busiest few days say where a mod went in.
  char line[900];
  int len = 0;
  line[0] = 0;
  for (int k = 0; k < 6; ++k) {
    const int i = c.days.rank(k);
    if (i < 0) break;
    int y, m, d;
    modscan::ymd_from_day(c.days.day[i], &y, &m, &d);
    len += wsprintfA(line + len, "%s%04d-%02d-%02d: %d files %u MB", k ? "; " : "", y, m, d, (int)c.days.files[i], (unsigned)(c.days.bytes[i] >> 20));
    if (len > 800) break;
  }
  log_line("MODSCAN busiest days (files last written that day): %s%s", line, c.days.overflow ? " (more days than fit)" : "");
  scan_siblings(dir);
  deluxe_report(dir);   // 1.7.24
}

// ---- loaded modules -------------------------------------------------------------------------------------------------------------------
HMODULE g_seen[512];
int g_nSeen;

int was_seen(HMODULE m) {
  for (int i = 0; i < g_nSeen; ++i) if (g_seen[i] == m) return 1;
  return 0;
}

void snapshot(int tag) {
  HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
  PFN_EnumProcessModules em = k32 ? (PFN_EnumProcessModules)GetProcAddress(k32, "K32EnumProcessModules") : nullptr;
  PFN_GetModuleFileNameExW gn = k32 ? (PFN_GetModuleFileNameExW)GetProcAddress(k32, "K32GetModuleFileNameExW") : nullptr;
  if (!em || !gn) { log_line("MODSCAN modules[%d] not available", tag); return; }
  static HMODULE mods[512];
  DWORD need = 0;
  if (!em(GetCurrentProcess(), mods, sizeof(mods), &need)) { log_line("MODSCAN modules[%d] could not be listed", tag); return; }
  int n = (int)(need / sizeof(HMODULE));
  if (n > 512) n = 512;
  char gameDir[MAX_PATH * 3], winDir[MAX_PATH * 3];
  to_u8(g_selfDir, gameDir, sizeof(gameDir));
  wchar_t wd[MAX_PATH];
  const UINT wl = GetWindowsDirectoryW(wd, MAX_PATH);
  if (wl > 0 && wl < MAX_PATH) to_u8(wd, winDir, sizeof(winDir)); else winDir[0] = 0;
  int cnt[5] = {0, 0, 0, 0, 0}, fresh = 0, shown = 0;
  char steam[900];
  int sl = 0;
  steam[0] = 0;
  HMODULE self = g_selfModule, exe = GetModuleHandleW(nullptr);
  for (int i = 0; i < n; ++i) {
    wchar_t wp[MAX_PATH];
    if (!gn(GetCurrentProcess(), mods[i], wp, MAX_PATH)) continue;
    char path[MAX_PATH * 3];
    to_u8(wp, path, sizeof(path));
    const modscan::PathKind kind = modscan::path_kind(path, gameDir, winDir[0] ? winDir : nullptr);
    cnt[kind]++;
    const int isNew = !was_seen(mods[i]);
    if (isNew) { ++fresh; if (g_nSeen < 512) g_seen[g_nSeen++] = mods[i]; }
    if (!isNew && tag > 1) continue;                 // later snapshots only report what arrived
    if (mods[i] == exe || mods[i] == self) continue;  // the game and the probe
    const char* nm = modscan::base_of(path);
    if (kind == modscan::P_STEAM && !modscan::overlay_hint(nm)) {
      if (sl + lstrlenA(nm) + 2 < (int)sizeof(steam)) sl += wsprintfA(steam + sl, "%s ", nm);
      continue;
    }
    if (kind == modscan::P_SYSTEM || kind == modscan::P_DRIVER) {
      if (!modscan::overlay_hint(nm)) continue;
    }
    if (shown >= 60) continue;
    ++shown;
    VerInfo vi;
    get_ver(wp, &vi);
    WIN32_FILE_ATTRIBUTE_DATA ad = {};
    GetFileAttributesExW(wp, GetFileExInfoStandard, &ad);
    static const char* const kKind[] = {"windows", "game-folder", "steam", "driver", "other"};
    log_line("MODSCAN module[%d]%s %s where=%s version=%s company=\"%s\" product=\"%s\" sizeKB=%u%s path=%s", tag, tag > 1 ? " NEW" : "", nm, kKind[kind], vi.ver, vi.company,
             vi.product, (unsigned)(ad.nFileSizeLow >> 10), modscan::overlay_hint(nm) ? " [overlay or capture tool: can hook the same Present call as the probe]" : "", path);
  }
  if (tag == 1 && steam[0]) log_line("MODSCAN modules[1] from Steam / SteamVR: %s", steam);
  log_line("MODSCAN modules[%d] total=%d (windows=%d game-folder=%d steam=%d driver=%d other=%d) new=%d", tag, n, cnt[0], cnt[1], cnt[2], cnt[3], cnt[4], fresh);
}

// ---- 0.97 which files under MODS (and which tweak.txt) the game really opens ----------------------------------------------------------
// "Did the Deluxe mod load?" cannot be told from the file list: the files being there proves nothing, and ghost.exe has no MODS string of its own. If the game opens a file under MODS
// the line says so here (ok = the file was there and was opened, NOT FOUND = the game looked and found nothing). Only opens made after the probe started are seen (the probe starts with the
// graphics): nothing logged is NOT proof that the mod did not load, but a MODOPEN line IS proof that the game reached for it.
typedef HANDLE(WINAPI* PFN_CreateFileW)(LPCWSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
PFN_CreateFileW o_createFileW;
struct OpenRec { wchar_t path[220]; DWORD err; int ok, kind; volatile LONG ready; };
OpenRec g_open[64];
volatile LONG g_openN, g_openMods, g_openModsOk, g_openTweak, g_openFlushed, g_openTotal;
int g_openHook;

HANDLE WINAPI hk_createFileW(LPCWSTR name, DWORD acc, DWORD share, LPSECURITY_ATTRIBUTES sa, DWORD disp, DWORD flags, HANDLE tmpl) {
  const HANDLE h = o_createFileW(name, acc, share, sa, disp, flags, tmpl);
  const DWORD le = GetLastError();
  InterlockedIncrement(&g_openTotal);
  const int kind = modscan::mod_path_hit(name);
  if (kind) {
    const int ok = h != INVALID_HANDLE_VALUE;
    if (kind == 1) { InterlockedIncrement(&g_openMods); if (ok) InterlockedIncrement(&g_openModsOk); } else InterlockedIncrement(&g_openTweak);
    const LONG i = InterlockedIncrement(&g_openN) - 1;
    if (i >= 0 && i < 64) {
      OpenRec& r = g_open[i];
      int k = 0;
      while (k < 219 && name[k]) { r.path[k] = name[k]; ++k; }
      r.path[k] = 0;
      r.err = ok ? 0 : le; r.ok = ok; r.kind = kind;
      MemoryBarrier();
      r.ready = 1;
    }
  }
  SetLastError(le);
  return h;
}

void install_open_observer() {
  HMODULE kb = GetModuleHandleW(L"kernelbase.dll");
  void* t = kb ? (void*)GetProcAddress(kb, "CreateFileW") : nullptr;
  if (!t) { g_openHook = -1; log_line("MODOPEN observer not installed (CreateFileW not found)"); return; }
  MH_STATUS s = MH_CreateHook(t, (void*)hk_createFileW, (void**)&o_createFileW);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_openHook = s == MH_OK ? 1 : -2;
  log_line("MODOPEN observer status=%d: opens of files under a MODS folder and of tweak.txt are listed from now on (only opens after this point are seen)", (int)s);
}

void flush_opens() {
  for (;;) {
    const LONG k = g_openFlushed;
    if (k >= 64 || k >= g_openN) break;
    OpenRec& r = g_open[k];
    if (!r.ready) break;
    char u8[MAX_PATH * 3];
    to_u8(r.path, u8, sizeof(u8));
    log_line("MODOPEN #%ld %s %s %s", (long)(k + 1), r.kind == 1 ? "MODS file" : "tweak.txt", r.ok ? "opened OK:" : "NOT FOUND / refused:", u8);
    g_openFlushed = k + 1;
  }
}

void open_summary(const char* when) {
  flush_opens();
  log_line("MODOPEN %s: the game opened %ld file(s) under MODS (%ld of them opened OK) and %ld tweak.txt, out of %ld file opens seen since the probe started%s", when, (long)g_openMods, (long)g_openModsOk, (long)g_openTweak, (long)g_openTotal,
           g_openHook != 1 ? " (observer not running)" : (g_openMods == 0 ? " - nothing under MODS was reached for since then (reads before the probe started are not seen: this alone does not prove the mod is off)" : ""));
}

void wait_flush(DWORD t0, DWORD ms) {
  while (GetTickCount() - t0 < ms) { flush_opens(); Sleep(500); }
}

DWORD WINAPI scan_thread(LPVOID) {
  SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
  const DWORD t0 = GetTickCount();
  install_open_observer();
  wait_flush(t0, 4000);
  scan_exe();
  scan_folder();
  wait_flush(t0, 25000);
  snapshot(1);
  log_line("MODSCAN hooks: identityOK=%d hookBytesOK=%d", g_game.identityOK, g_game.hookBytesOK);
  open_summary("after 25 s");
  wait_flush(t0, 100000);
  snapshot(2);
  open_summary("after 100 s");
  wait_flush(t0, 300000);
  snapshot(3);
  open_summary("after 5 min");
  wait_flush(t0, 900000);
  snapshot(4);
  open_summary("after 15 min");
  wait_flush(t0, 3600000);   // the observer keeps listing what the game opens (a level that loads later) for the first hour
  open_summary("after 1 hour");
  return 0;
}

}  // namespace

// 0.98: called when the player marks a moment (F2 / both grips + both stick clicks / menu button): the "did the mod load" counters at that moment
void modscan_mark_note(int markNumber) {
  log_line("MODLOOK mark #%d: the game has opened %ld file(s) under MODS (%ld OK) and %ld tweak.txt so far, out of %ld file opens seen since the probe started%s. The picture saved now shows what you saw (rain, tint, textures): tell me in words what looked off at this spot.",
           markNumber, (long)g_openMods, (long)g_openModsOk, (long)g_openTweak, (long)g_openTotal, g_openHook != 1 ? " (observer not running)" : "");
}

void modscan_start() {
  if (InterlockedExchange(&g_started, 1)) return;
  HANDLE t = CreateThread(nullptr, 256 * 1024, scan_thread, nullptr, 0, nullptr);
  if (t) CloseHandle(t); else log_line("MODSCAN thread could not be started");
}

#endif  // GBVR_HEADTRACK
