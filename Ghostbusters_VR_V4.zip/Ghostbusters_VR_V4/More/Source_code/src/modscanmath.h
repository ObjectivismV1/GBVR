// 0.96 mod scan: pure helpers (no Windows dependency), unit-tested in tests/test_modscan.cpp.
//
// The probe looks at what else sits in the game folder and in the game process (other mods, loaders, overlays) so that a report says
// "this mod + the probe" without anyone having to describe the PC. Everything here only classifies names and paths.
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace modscan {

// ---- CRC-32 (the same one zip / PowerShell tools use) ----------------------------------------------------------------
inline uint32_t crc32_update(uint32_t crc, const uint8_t* p, size_t n) {
  static uint32_t table[256];
  static int ready = 0;
  if (!ready) {
    for (uint32_t i = 0; i < 256; ++i) {
      uint32_t c = i;
      for (int k = 0; k < 8; ++k) c = (c & 1u) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
      table[i] = c;
    }
    ready = 1;
  }
  crc = ~crc;
  for (size_t i = 0; i < n; ++i) crc = table[(crc ^ p[i]) & 0xFFu] ^ (crc >> 8);
  return ~crc;
}

// ---- ASCII text helpers ------------------------------------------------------------------------------------------------
inline char lower(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }
inline int ieq(const char* a, const char* b) {
  if (!a || !b) return 0;
  while (*a && *b) { if (lower(*a) != lower(*b)) return 0; ++a; ++b; }
  return *a == 0 && *b == 0;
}
inline int istarts(const char* s, const char* prefix) {
  if (!s || !prefix) return 0;
  while (*prefix) { if (!*s || lower(*s) != lower(*prefix)) return 0; ++s; ++prefix; }
  return 1;
}
inline int icontains(const char* hay, const char* needle) {
  if (!hay || !needle || !*needle) return 0;
  for (; *hay; ++hay) if (istarts(hay, needle)) return 1;
  return 0;
}
inline size_t slen(const char* s) { size_t n = 0; while (s && s[n]) ++n; return n; }
inline int iends(const char* s, const char* suffix) {
  const size_t a = slen(s), b = slen(suffix);
  if (!b || b > a) return 0;
  return ieq(s + (a - b), suffix);
}
inline const char* base_of(const char* path) {
  const char* b = path;
  for (; path && *path; ++path) if (*path == '\\' || *path == '/') b = path + 1;
  return b;
}
// does `name` contain `token` as a whole word (letters/digits form words; "game_mod.ini" has "mod", "models" does not)
inline int has_word(const char* name, const char* token) {
  const size_t t = slen(token);
  if (!t) return 0;
  for (size_t i = 0; name && name[i]; ++i) {
    if (i > 0) { const char p = name[i - 1]; if ((p >= '0' && p <= '9') || (lower(p) >= 'a' && lower(p) <= 'z')) continue; }
    size_t k = 0;
    while (k < t && name[i + k] && lower(name[i + k]) == lower(token[k])) ++k;
    if (k != t) continue;
    const char n = name[i + t];
    if ((n >= '0' && n <= '9') || (lower(n) >= 'a' && lower(n) <= 'z')) continue;
    return 1;
  }
  return 0;
}

// ---- file names -----------------------------------------------------------------------------------------------------------
enum Flag {
  F_ASI = 1,          // .asi plugin (loaded by an ASI loader)
  F_LOADER = 2,       // a DLL name that mod loaders pretend to be (winmm, version, dsound, dinput8 ...)
  F_GFX = 4,          // a graphics DLL name (dxgi, d3d9, d3d10, d3d12, opengl32 ...): ReShade / DXVK / Special K style
  F_INPUT = 8,        // an input DLL name (xinput*): the probe bridges the game's XInput imports
  F_MODNAME = 16,     // the name says mod / patch / deluxe / reshade ...
  F_OURS = 32,        // the probe's own files
  F_EXE = 64,
  F_DLL = 128,
  F_TEXT = 256        // ini / cfg / txt / log / json / xml / lua / readme ...
};

inline const char* ext_of(const char* name) {
  const char* dot = nullptr;
  for (const char* p = name; p && *p; ++p) { if (*p == '.') dot = p; if (*p == '\\' || *p == '/') dot = nullptr; }
  return dot ? dot : "";
}
inline int in_list(const char* name, const char* const* list, int n) {
  for (int i = 0; i < n; ++i) if (ieq(name, list[i])) return 1;
  return 0;
}

inline unsigned classify(const char* nameOrPath) {
  const char* name = base_of(nameOrPath);
  const char* ext = ext_of(name);
  unsigned f = 0;
  if (istarts(name, "gbvr_") || istarts(name, "d3d11.dll.gbvr_backup") || ieq(name, "d3d11.dll")) f |= F_OURS;
  if (ieq(ext, ".exe")) f |= F_EXE;
  if (ieq(ext, ".dll")) f |= F_DLL;
  if (ieq(ext, ".asi")) f |= F_ASI;
  static const char* const kLoader[] = {"winmm.dll", "version.dll", "dsound.dll", "dinput8.dll", "dinput.dll", "wininet.dll", "msacm32.dll", "msvfw32.dll",
                                         "xlive.dll", "vorbisfile.dll", "ijl15.dll", "wsock32.dll", "ws2_32.dll", "iphlpapi.dll", "msimg32.dll", "d3d8.dll"};
  static const char* const kGfx[] = {"dxgi.dll", "d3d9.dll", "d3d10.dll", "d3d10_1.dll", "d3d12.dll", "opengl32.dll", "ddraw.dll", "dxgi_hook.dll"};
  static const char* const kInput[] = {"xinput1_3.dll", "xinput1_4.dll", "xinput9_1_0.dll", "xinput1_2.dll", "xinput1_1.dll"};
  if (in_list(name, kLoader, (int)(sizeof(kLoader) / sizeof(kLoader[0])))) f |= F_LOADER;
  if (in_list(name, kGfx, (int)(sizeof(kGfx) / sizeof(kGfx[0])))) f |= F_GFX;
  if (in_list(name, kInput, (int)(sizeof(kInput) / sizeof(kInput[0])))) f |= F_INPUT;
  static const char* const kWords[] = {"mod", "mods", "patch", "fix", "deluxe", "censor", "uncensored", "loader", "plugins", "scripts", "unlocker", "trainer", "hd", "retex"};
  for (const char* w : kWords) if (has_word(name, w)) { f |= F_MODNAME; break; }
  static const char* const kParts[] = {"reshade", "sweetfx", "dxvk", "specialk", "special_k", "enbseries", "deluxe", "censor", "asiloader", "dinput8hook", "3dmigoto"};
  for (const char* w : kParts) if (icontains(name, w)) { f |= F_MODNAME; break; }
  static const char* const kText[] = {".ini", ".cfg", ".conf", ".txt", ".log", ".json", ".xml", ".lua", ".md", ".nfo", ".toml", ".yaml", ".yml", ".bat", ".cmd", ".ps1"};
  for (const char* e : kText) if (ieq(ext, e)) { f |= F_TEXT; break; }
  return f;
}

// 0 nothing to say, 1 worth a note, 2 the probe should be told about it (a report line says WATCH), 3 likely conflict
inline int level_of(unsigned f, int topLevel) {
  if (f & F_OURS) return 0;
  if (topLevel && (f & F_GFX)) return 3;      // a dxgi.dll / d3d9.dll next to ghost.exe replaces the Windows one for the game: ReShade, DXVK, Special K ...
  if (topLevel && (f & F_INPUT)) return 3;    // the probe patches the game's XInput imports
  if (topLevel && (f & F_LOADER)) return 2;   // ASI loader style: fine, the intro-skip mod uses winmm.dll, but it decides who else can hook
  if (f & F_ASI) return 2;
  if (f & F_MODNAME) return 1;
  return 0;
}
inline const char* what_is(unsigned f) {
  if (f & F_OURS) return "probe";
  if (f & F_GFX) return "graphics DLL (ReShade / DXVK / Special K style)";
  if (f & F_INPUT) return "XInput DLL (the probe bridges the game's XInput imports)";
  if (f & F_LOADER) return "loader-style DLL (ASI loader / proxy)";
  if (f & F_ASI) return "ASI plugin";
  if (f & F_MODNAME) return "named like a mod / patch";
  if (f & F_EXE) return "program";
  if (f & F_DLL) return "DLL";
  if (f & F_TEXT) return "text / settings file";
  return "";
}

// Programs that draw over a game or capture it do that by hooking Present, as the probe does. Worth a word in the report.
inline int overlay_hint(const char* name) {
  static const char* const k[] = {"gameoverlay", "rtss", "overlay", "graphics-hook", "obs-", "discordhook", "discord_hook", "overwolf", "afterburner",
                                  "reshade", "specialk", "dxvk", "nvspcap", "capture", "hook64", "fraps", "action_", "mirillis", "bandicam", "shadowplay"};
  for (const char* w : k) if (icontains(name, w)) return 1;
  return 0;
}

// ---- where a loaded module lives -------------------------------------------------------------------------------------------
enum PathKind { P_SYSTEM = 0, P_GAME = 1, P_STEAM = 2, P_DRIVER = 3, P_OTHER = 4 };
// Prefix test, case-insensitive, '/' == '\\'.
inline int under(const char* path, const char* dir) {
  if (!path || !dir) return 0;
  size_t n = slen(dir);
  while (n > 0 && (dir[n - 1] == '\\' || dir[n - 1] == '/')) --n;
  if (!n) return 0;
  for (size_t i = 0; i < n; ++i) {
    char a = lower(path[i]), b = lower(dir[i]);
    if (a == '/') a = '\\';
    if (b == '/') b = '\\';
    if (!path[i] || a != b) return 0;
  }
  return path[n] == '\\' || path[n] == '/';
}
inline PathKind path_kind(const char* path, const char* gameDir, const char* windowsDir) {
  if (gameDir && under(path, gameDir)) return P_GAME;
  if (windowsDir && under(path, windowsDir)) {
    // the driver store lives under the Windows folder
    if (icontains(path, "\\DriverStore\\") || icontains(path, "\\DriverStore/")) return P_DRIVER;
    return P_SYSTEM;
  }
  if (icontains(path, "\\steamapps\\common\\steamvr\\") || icontains(path, "\\steam\\") || icontains(path, "\\steamvr\\")) return P_STEAM;
  if (icontains(path, "\\nvidia corporation\\") || icontains(path, "\\nvidia\\") || icontains(path, "\\amd\\") || icontains(path, "\\intel\\")) return P_DRIVER;
  return P_OTHER;
}

// ---- file dates ---------------------------------------------------------------------------------------------------------------
// 100-ns FILETIME ticks since 1601 -> whole days since 1601-01-01. 134774 days = 1970-01-01.
inline int32_t day_of(uint64_t filetime) { return (int32_t)(filetime / 864000000000ull); }
inline void ymd_from_day(int32_t day, int* y, int* m, int* d) {
  // civil-from-days (H. Hinnant), days counted from 1970-01-01
  int64_t z = (int64_t)day - 134774 + 719468;
  const int64_t era = (z >= 0 ? z : z - 146096) / 146097;
  const unsigned doe = (unsigned)(z - era * 146097);
  const unsigned yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
  const int64_t yy = (int64_t)yoe + era * 400;
  const unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
  const unsigned mp = (5 * doy + 2) / 153;
  const unsigned dd = doy - (153 * mp + 2) / 5 + 1;
  const unsigned mm = mp < 10 ? mp + 3 : mp - 9;
  *y = (int)(yy + (mm <= 2)); *m = (int)mm; *d = (int)dd;
}

// A small table of "how many files / bytes were last written on which day". A burst of files on one day that is not the Steam install day is
// where a mod was unpacked.
struct DayTable {
  enum { kMax = 96 };
  int32_t day[kMax];
  int32_t files[kMax];
  uint64_t bytes[kMax];
  int n;
  int overflow;
  void clear() { n = 0; overflow = 0; }
  void add(int32_t d, uint64_t size) {
    for (int i = 0; i < n; ++i) if (day[i] == d) { files[i]++; bytes[i] += size; return; }
    if (n >= kMax) { ++overflow; return; }
    day[n] = d; files[n] = 1; bytes[n] = size; ++n;
  }
  // index of the k-th busiest day (k = 0 is the busiest); -1 if there is none
  int rank(int k) const {
    int used[kMax] = {0};
    int best = -1;
    for (int r = 0; r <= k; ++r) {
      best = -1;
      for (int i = 0; i < n; ++i) if (!used[i] && (best < 0 || files[i] > files[best] || (files[i] == files[best] && day[i] > day[best]))) best = i;
      if (best < 0) return -1;
      used[best] = 1;
    }
    return best;
  }
};

// 0.97 which file opens the game does are interesting for "did the Deluxe mod load": anything under a MODS folder (1), or a tweak.txt wherever it is (2). 0 = not interesting.
// Works on narrow and wide strings (only ASCII letters are compared).
template <class C> inline int ci_eq(C c, char lc) { return (c >= (C)'A' && c <= (C)'Z') ? (char)(c + 32) == lc : ((char)c == lc && ((unsigned long)c) < 128ul); }
template <class C> inline int mod_path_hit(const C* p) {
  if (!p) return 0;
  int n = 0;
  while (n < 520 && p[n]) ++n;
  if (n >= 520) return 0;
  static const char kMods[] = "mods";
  for (int i = 0; i + 6 <= n; ++i) {   // \mods\ or /mods/ (also at the very start: "mods\")
    const C a = p[i];
    if ((a != (C)'\\' && a != (C)'/')) continue;
    int k = 0;
    while (k < 4 && ci_eq(p[i + 1 + k], kMods[k])) ++k;
    if (k == 4 && (p[i + 5] == (C)'\\' || p[i + 5] == (C)'/')) return 1;
  }
  { // trailing ...\mods (the folder itself)
    if (n >= 5 && (p[n - 5] == (C)'\\' || p[n - 5] == (C)'/')) { int k = 0; while (k < 4 && ci_eq(p[n - 4 + k], kMods[k])) ++k; if (k == 4) return 1; }
  }
  static const char kTw[] = "tweak.txt";
  if (n >= 9) {
    int k = 0;
    while (k < 9 && ci_eq(p[n - 9 + k], kTw[k])) ++k;
    if (k == 9 && (n == 9 || p[n - 10] == (C)'\\' || p[n - 10] == (C)'/')) return 2;
  }
  return 0;
}

}  // namespace modscan
