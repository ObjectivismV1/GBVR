// 1.2 monitor view: the pure math (tests/test_monitor.cpp).
//
// The "monitor" is the game window on the PC screen while you play in the headset. In pair mode every Present of the
// game is ONE eye (left, right, left, ...), so the window flickered between two slightly different pictures, stretched
// from 4:3 to the window's shape, and it rolled with your head. The monitor view draws ONE finished eye picture
// (always the same eye) into the window instead: not stretched, optionally with the horizon kept level.
//
// The eye picture is 3840 x 2880 with a very wide field of view (about 125 x 110 degrees); the headset only uses part of
// it, the monitor can show all of it.
//
// How the picture is placed: the output rectangle (the window or the part of it that is used) has the coordinates
// (u, v) in 0..1, v pointing down. A source window of size (sw, sh) around (cx, cy) in the eye picture (also 0..1,
// v down) is rotated by the head's roll and stretched onto it:
//     src = (cx, cy) + M * (u - 0.5, v - 0.5)
#pragma once
#include "vmath.h"   // the probe has no C runtime: its own sqrt / atan2 / sincos

namespace monitor {

static const double kPi = 3.14159265358979323846;

struct Window { double cx, cy, sw, sh; };   // source window, as parts of the eye picture; before the roll

// Roll of the head about the way it looks, from an OpenVR 3x4 pose (row-major, columns = device axes): the angle the
// world's "up" has in the picture (positive = head tilted to the left, left ear down - the sign the log's roll= uses).
// Looking almost straight up or down the roll is not defined, so it fades out there.
inline double roll_from_pose34(const float* p) {
  double ry = (double)p[4], uy = (double)p[5];     // world-up component of the device's right and up axes
  double mag = vm::dsqrt(ry * ry + uy * uy);           // = cos(pitch)
  if (!(mag > 0.12)) return 0.0;
  double w = (mag - 0.12) / 0.23;
  if (w > 1.0) w = 1.0;
  w = w * w * (3.0 - 2.0 * w);
  double r = vm::datan2(ry, uy);
  if (r > kPi * 0.5) r = kPi * 0.5;
  if (r < -kPi * 0.5) r = -kPi * 0.5;
  return r * w;
}

// Largest scale (at most 1) at which a rectangle with the half sizes (a, b), turned by `roll`, still fits inside a
// rectangle with the half sizes (A, B), both centred on the same point.
inline double inscribed_scale(double a, double b, double A, double B, double roll) {
  double s0, c0;
  vm::dsincos(roll, &s0, &c0);
  double c = vm::dabs(c0), s = vm::dabs(s0);
  double needW = a * c + b * s, needH = a * s + b * c;
  double k = 1.0;
  if (needW > 1e-9 && A / needW < k) k = A / needW;
  if (needH > 1e-9 && B / needH < k) k = B / needH;
  return k < 0.05 ? 0.05 : k;
}

// fit 0: the whole picture (black bars where the window's shape differs); fit 1: the picture fills the window and the
// parts that do not fit are cut off (the full width is kept as far as the window's shape allows).
// viewAspect = width / height of the rectangle the picture is drawn into (client pixels).
// zoomPct 50..100: part of that window that is shown (100 = all of it).
// Returns 1 when the window was made smaller so that the turned window stays inside the picture.
inline int make_window(int fit, int zoomPct, int texW, int texH, double viewAspect, double roll, Window* w) {
  double z = (double)(zoomPct < 30 ? 30 : (zoomPct > 100 ? 100 : zoomPct)) / 100.0;   // 1.7.28: down to 30 (a tight crop; the field of view setting needs it)
  double sw = 1.0, sh = 1.0;
  if (fit != 0 && texW > 0 && texH > 0 && viewAspect > 0.1) {
    double pa = (double)texW / (double)texH;
    if (viewAspect >= pa) sh = pa / viewAspect;                 // the window is wider than the picture: keep the width
    else sw = viewAspect / pa;                                  // narrower: keep the height
  }
  sw *= z; sh *= z;
  int shrunk = 0;
  if (fit != 0 && texW > 0 && texH > 0) {
    // half sizes in picture pixels
    double a = 0.5 * sw * texW, b = 0.5 * sh * texH;
    double k = inscribed_scale(a, b, 0.5 * texW, 0.5 * texH, roll);
    if (k < 0.9999) { sw *= k; sh *= k; shrunk = 1; }
  }
  w->cx = 0.5; w->cy = 0.5; w->sw = sw; w->sh = sh;
  return shrunk;
}

// 1.7.28: zoom percent (30..100) that makes the window show `hfovDeg` degrees across. The picture's half-width tangent is tanHalf (the engine's tan of half the field of view), baseSw is the part of the
// picture width the window shows at zoom 100 (make_window with zoomPct 100, no roll). Pixel position in a perspective picture is proportional to the tangent, so the part of the width is tan(fov/2) / tanHalf.
// Returns 100 when the wish is wider than the picture (cannot show more than was drawn) and 0 when an input is unusable (the caller keeps the zoom setting).
inline int zoom_for_hfov(double hfovDeg, double tanHalf, double baseSw) {
  if (!(hfovDeg >= 30.0) || hfovDeg > 170.0 || !(tanHalf > 0.05) || !(baseSw > 0.01) || baseSw > 1.0001) return 0;
  double s, c;
  vm::dsincos(hfovDeg * 0.5 * kPi / 180.0, &s, &c);
  if (!(c > 1e-6)) return 0;
  double z = (s / c) / (tanHalf * baseSw);
  if (z >= 1.0) return 100;
  int pct = (int)(z * 100.0 + 0.5);
  return pct < 30 ? 30 : pct;
}

// src - centre = M * (u - 0.5, v - 0.5), M = {m00, m01, m10, m11}. The turn makes a line that is vertical in the world
// vertical in the output (see test_monitor.cpp).
inline void make_matrix(const Window& w, int texW, int texH, double roll, double* m) {
  double k = (texW > 0) ? (double)texH / (double)texW : 0.75;
  double s, c;
  vm::dsincos(roll, &s, &c);
  m[0] = w.sw * c;      m[1] = -w.sh * k * s;
  m[2] = w.sw / k * s;  m[3] = w.sh * c;
}

// Where an output point (u, v) comes from in the eye picture (u, v in 0..1). Returns 1 when that is inside the picture.
inline int map_point(const Window& w, const double* m, double u, double v, double* su, double* sv) {
  double du = u - 0.5, dv = v - 0.5;
  *su = w.cx + m[0] * du + m[1] * dv;
  *sv = w.cy + m[2] * du + m[3] * dv;
  return *su >= 0.0 && *su <= 1.0 && *sv >= 0.0 && *sv <= 1.0;
}

// Use camera tangents rather than texture pixels. Sharp-mode eye textures can be
// anamorphic: preserving their pixel aspect squeezes the world on the monitor.
inline int projection_window(int fit, int zoomPct, double tanH, double tanV, double aspect, double roll, Window* w, double* m) {
  if (!(tanH > 0.05 && tanH < 20.0 && tanV > 0.05 && tanV < 20.0 && aspect > 0.05 && aspect < 30.0)) return -1;
  const double pa = tanH / tanV;
  double sw = 1.0, sh = 1.0;
  if (fit) { if (aspect >= pa) sh = pa / aspect; else sw = aspect / pa; }
  const double z = (zoomPct < 30 ? 30 : zoomPct > 100 ? 100 : zoomPct) * 0.01;
  w->cx = w->cy = 0.5; w->sw = sw * z; w->sh = sh * z;
  double s, c; vm::dsincos(roll, &s, &c);
  m[0] = w->sw * c; m[1] = -w->sh / pa * s;
  m[2] = w->sw * pa * s; m[3] = w->sh * c;
  double k = 1.0;
  if (fit) {
    const double x = vm::dabs(m[0]) + vm::dabs(m[1]), y = vm::dabs(m[2]) + vm::dabs(m[3]);
    if (x > 1.0) k = 1.0 / x;
    if (y > 1.0 && 1.0 / y < k) k = 1.0 / y;
    w->sw *= k; w->sh *= k;
    for (int i = 0; i < 4; ++i) m[i] *= k;
  }
  return k < 0.9999 ? 1 : 0;
}

inline double down_shift(double degrees, double tanV, const Window& w) {
  if (!(degrees >= 0.0 && degrees <= 25.0 && tanV > 0.05 && w.sh > 0.01)) return 0.0;
  double s, c; vm::dsincos(degrees * kPi / 180.0, &s, &c);
  return s / c / (2.0 * tanV * w.sh);
}

// Lower the crop along the level monitor's vertical. Clamp its whole rotated
// rectangle to the available source so no missing pixels or black wedges appear.
inline void lower_window(Window* w, const double* m, double shift) {
  if (!(shift >= 0.0 && shift < 4.0)) shift = 0.0;
  double dx = m[1] * shift, dy = m[3] * shift;
  const double hx = 0.5 * (vm::dabs(m[0]) + vm::dabs(m[1]));
  const double hy = 0.5 * (vm::dabs(m[2]) + vm::dabs(m[3]));
  const double ax = hx < 0.5 ? 0.5 - hx : 0.0, ay = hy < 0.5 ? 0.5 - hy : 0.0;
  if (dx > ax) dx = ax; if (dx < -ax) dx = -ax;
  if (dy > ay) dy = ay; if (dy < -ay) dy = -ay;
  w->cx = 0.5 + dx; w->cy = 0.5 + dy;
}

// Project a tracking-space hand/weapon point into this exact eye's source image.
// OpenVR's third pose column points backwards. Reject behind-head and invalid points.
inline int project_point(const float* head, const float* point, double eyeX, double tanH, double tanV, double* u, double* v) {
  if (!(tanH > 0.05 && tanV > 0.05)) return 0;
  double x = 0.0, y = 0.0, z = 0.0;
  for (int i = 0; i < 3; ++i) {
    if (!vm::is_finite_f(point[i]) || !vm::is_finite_f(head[i * 4 + 3])) return 0;
    const double d = (double)point[i] - head[i * 4 + 3];
    x += head[i * 4] * d; y += head[i * 4 + 1] * d; z -= head[i * 4 + 2] * d;
  }
  if (!(z >= 0.12 && z <= 3.0)) return 0;
  *u = 0.5 + (x - eyeX) / (2.0 * z * tanH); *v = 0.5 - y / (2.0 * z * tanV);
  return *u >= 0.0 && *u <= 1.0 && *v >= 0.0 && *v <= 1.0;
}

// How far to move the crop down to leave a margin beneath a projected point.
inline double hand_shift(const double* m, double u, double v, double current) {
  const double det = m[0] * m[3] - m[1] * m[2];
  if (!(det > 1e-6)) return current;
  const double x = 0.5 + (m[3] * (u - 0.5) - m[1] * (v - 0.5)) / det;
  const double y = 0.5 + (m[0] * (v - 0.5) - m[2] * (u - 0.5)) / det;
  if (x < 0.05 || x > 0.95) return current; // don't chase hands outside the horizontal view
  const double need = y - 0.85;
  return need > current ? need : current;
}

struct Framing { double down; int have; };
inline double smooth_down(Framing* f, double target, double dt) {
  if (!f->have || !(dt > 0.0) || dt > 0.5) { f->down = target; f->have = 1; }
  else f->down += (target - f->down) * dt / (0.18 + dt);
  return f->down;
}


// 1.4: the horizon follow, calmer. Head tilts under 2.5 degrees are ignored (1.3 turned the picture by the exact roll: the head's resting tilt of about 1.4 degrees left black wedges
// in the corners on 73991 of 79916 frames), the rest follows through a short low-pass (time constant 0.15 s) and never turns more than 30 degrees.
struct Calm { double sm; int started; };
inline double calm_roll(Calm* c, double raw, double dt) {
  const double dz = 2.5 * kPi / 180.0, lim = 30.0 * kPi / 180.0;
  const double a = raw < 0 ? -raw : raw;
  double eff = a > dz ? a - dz : 0.0;
  if (eff > lim) eff = lim;
  if (raw < 0) eff = -eff;
  if (dt < 0.0) dt = 0.0;
  if (!c->started || dt > 0.5) { c->sm = eff; c->started = 1; return c->sm; }   // first value / after a pause: no slow swing
  c->sm += (eff - c->sm) * (dt / (0.15 + dt));
  return c->sm;
}

}  // namespace monitor
