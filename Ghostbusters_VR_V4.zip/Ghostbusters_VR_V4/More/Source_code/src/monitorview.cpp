// 1.2 monitor view: what the game window on the PC screen shows while you play in the headset.
//
// Before 1.2 the window showed whatever the game's back buffer held at each Present. In eye-pair mode that is ONE eye per
// Present, left, right, left, ... so the window flickered between two slightly different pictures (the body, the
// gun and the effects are not always the same in both eyes), it was stretched from 4:3 to the window's shape, and it
// rolled with your head.
//
// Now, right before the game's own Present (and after the eye picture was copied for the headset), this pass draws ONE
// finished eye picture into the back buffer instead:
//   - always the same eye (default: the left one; the picture is the probe's own copy, the gun, hands and wand drawn
//     into it, the game's health ring and HUD in it),
//   - in its own shape (4:3 whole picture with black bars, or filling the window), so nothing is stretched,
//   - the whole wide field of view the game drew (110 x 110 degrees, 1.7.9: 121 x 121 with monitor_wide_pct 125, more than the headset shows),
//   - with the horizon kept level when you tilt your head (optional),
//   - with a four-tap average, so the 3840 x 2880 picture shrunk into the window does not shimmer.
// What the headset gets is not touched: the eye pictures are separate textures that were filled before this runs.
// All Direct3D state that is changed is saved and put back; no reference to the back buffer is kept; the shader is
// compiled at first use with d3dcompiler_47.dll; if anything fails three times the pass switches itself off and the window
// shows the raw back buffer as before (log MONITORVIEW).
#include "gbvr.h"

#if GBVR_HEADTRACK
#include <d3d11.h>
#include <d3dcompiler.h>
#include "picturemath.h"
#include "monitormath.h"

namespace {
const char* kShader =
  "cbuffer C : register(b0) { float4 M; float4 P; };\n"        // M = m00 m01 m10 m11; P = centre u, centre v
  "Texture2D T : register(t0);\n"
  "SamplerState S : register(s0);\n"
  "struct VO { float4 pos : SV_Position; float2 uv : TEXCOORD0; };\n"
  "VO VSMain(uint id : SV_VertexID) {\n"
  "  VO o;\n"
  "  float2 p = float2((id << 1) & 2, id & 2);\n"
  "  float2 d = p - 0.5;\n"
  "  o.uv = float2(P.x + M.x * d.x + M.y * d.y, P.y + M.z * d.x + M.w * d.y);\n"
  "  o.pos = float4(p.x * 2.0 - 1.0, 1.0 - p.y * 2.0, 0.0, 1.0);\n"
  "  return o;\n"
  "}\n"
  "float3 tap(float2 uv) {\n"
  "  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return float3(0.0, 0.0, 0.0);\n"
  "  return T.SampleLevel(S, uv, 0).rgb;\n"
  "}\n"
  "float4 PSMain(VO i) : SV_Target {\n"
  "  float2 dx = ddx(i.uv) * 0.25;\n"
  "  float2 dy = ddy(i.uv) * 0.25;\n"
  "  float3 c = tap(i.uv - dx - dy) + tap(i.uv + dx - dy) + tap(i.uv - dx + dy) + tap(i.uv + dx + dy);\n"
  "  return float4(c * 0.25, 1.0);\n"
  "}\n";

struct Cb { float m[4]; float p[4]; };

ID3D11Device* g_dev;                        // device the resources below belong to (no reference kept)
ID3D11VertexShader* g_vs;
ID3D11PixelShader* g_ps;
ID3D11SamplerState* g_smp;
ID3D11RasterizerState* g_rs;
ID3D11DepthStencilState* g_ds;
ID3D11BlendState* g_bs;
ID3D11Buffer* g_cb;
ID3D11Texture2D* g_menuTex;
ID3D11Texture2D* g_dotTex;                  // 1.7.145: the pointer dot drawn on the PC window's menu                 // 1.7.90: the settings pages' picture for the PC window
long g_menuSerial;
int g_state;                                // 0 not tried, 1 ready, <0 failed (why)
int g_failures, g_logged, g_layoutLogged;

struct Stats {
  volatile LONG draws, noSource, skipped, mismatch, failed;
  LONG used[2];                             // draws per eye picture
  LONG eyeChanges;                          // the eye shown differed from the one before: 0 once running means no flicker from alternating eyes
  LONG ageHist[4];                          // age of the picture drawn, in real frames: 0, 1, 2, 3 or more
  LONG ageMax;
  LONG shrunk, wedge;                       // window made smaller for the turn (fill mode) / whole picture with black corners from the turn
  int lastEye, started;
  // since the last report
  double rollMin, rollMax, rollAbsSum; LONG rollN;
  double gapSum, gapMax; LONG gapN;
  int64_t lastDrawQpc;
} g_s;

// 1.4: the horizon follow (monitor::calm_roll): tilts under 2.5 degrees are ignored, the rest follows through a short low-pass.
monitor::Calm g_calm; int64_t g_rollQ; double g_rollRawMax, g_rollOutMax;
monitor::Framing g_framing; int64_t g_frameQ;
double calm_roll(double raw, int64_t now) {
  const double dt = g_rollQ ? (double)(now - g_rollQ) / (double)qpc_freq() : 0.0;
  g_rollQ = now;
  const double r = monitor::calm_roll(&g_calm, raw, dt);
  const double a = raw < 0 ? -raw : raw, o = r < 0 ? -r : r;
  if (a > g_rollRawMax) g_rollRawMax = a;
  if (o > g_rollOutMax) g_rollOutMax = o;
  return r;
}

struct Last { double vx, vy, vw, vh; int cw, ch; UINT bw, bh; double sw, sh, roll, tanH, tanV; int fit, zoom, level, eye, down, hands; } g_last;

double point_shift(const float* pose, const float* point, const float* projection, const double* m, double shift) {
  double u, v;
  if (monitor::project_point(pose, point, projection[2], projection[0], projection[1], &u, &v)) return monitor::hand_shift(m, u, v, shift);
  return shift;
}

template <class T> void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

void release_all() {
  rel(g_vs); rel(g_ps); rel(g_smp); rel(g_rs); rel(g_ds); rel(g_bs); rel(g_cb); rel(g_menuTex); rel(g_dotTex); g_menuSerial = 0;
  g_dev = nullptr; g_state = 0;
}

int create_resources(ID3D11Device* dev) {
  HMODULE lib = LoadLibraryW(L"d3dcompiler_47.dll");
  if (!lib) return -1;
  pD3DCompile compile = (pD3DCompile)GetProcAddress(lib, "D3DCompile");
  if (!compile) return -2;
  ID3DBlob *vsb = nullptr, *psb = nullptr, *err = nullptr;
  HRESULT h = compile(kShader, lstrlenA(kShader), "gbvr_monitor", nullptr, nullptr, "VSMain", "vs_4_0", 0, 0, &vsb, &err);
  if (FAILED(h) || !vsb) {
    if (err) { log_line("MONITORVIEW vertex shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    return -3;
  }
  h = compile(kShader, lstrlenA(kShader), "gbvr_monitor", nullptr, nullptr, "PSMain", "ps_4_0", 0, 0, &psb, &err);
  if (FAILED(h) || !psb) {
    if (err) { log_line("MONITORVIEW pixel shader error: %s", (const char*)err->GetBufferPointer()); err->Release(); }
    vsb->Release();
    return -4;
  }
  int rc = 0;
  if (FAILED(dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs))) rc = -5;
  else if (FAILED(dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps))) rc = -6;
  vsb->Release(); psb->Release();
  if (rc) return rc;
  D3D11_SAMPLER_DESC sd;
  ZeroMemory(&sd, sizeof(sd));
  sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
  sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
  sd.ComparisonFunc = D3D11_COMPARISON_NEVER; sd.MaxLOD = D3D11_FLOAT32_MAX;
  if (FAILED(dev->CreateSamplerState(&sd, &g_smp))) return -7;
  D3D11_RASTERIZER_DESC rd;
  ZeroMemory(&rd, sizeof(rd));
  rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
  if (FAILED(dev->CreateRasterizerState(&rd, &g_rs))) return -8;
  D3D11_DEPTH_STENCIL_DESC dd;
  ZeroMemory(&dd, sizeof(dd));
  dd.DepthEnable = FALSE; dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO; dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
  dd.StencilEnable = FALSE; dd.StencilReadMask = 0xff; dd.StencilWriteMask = 0xff;
  dd.FrontFace.StencilFailOp = dd.FrontFace.StencilDepthFailOp = dd.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
  dd.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
  dd.BackFace = dd.FrontFace;
  if (FAILED(dev->CreateDepthStencilState(&dd, &g_ds))) return -9;
  D3D11_BLEND_DESC bl;
  ZeroMemory(&bl, sizeof(bl));
  bl.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
  if (FAILED(dev->CreateBlendState(&bl, &g_bs))) return -10;
  D3D11_BUFFER_DESC bd;
  ZeroMemory(&bd, sizeof(bd));
  bd.ByteWidth = sizeof(Cb); bd.Usage = D3D11_USAGE_DEFAULT; bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
  if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_cb))) return -11;
  return 1;
}

struct Saved {
  ID3D11RenderTargetView* rtv[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT]; ID3D11DepthStencilView* dsv;
  D3D11_VIEWPORT vp[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE]; UINT nvp;
  ID3D11RasterizerState* rs; ID3D11BlendState* bs; float bf[4]; UINT mask; ID3D11DepthStencilState* ds; UINT sref;
  ID3D11InputLayout* il; D3D11_PRIMITIVE_TOPOLOGY topo;
  ID3D11VertexShader* vs; ID3D11PixelShader* ps; ID3D11GeometryShader* gs; ID3D11HullShader* hs; ID3D11DomainShader* dsh;
  ID3D11ShaderResourceView* srv; ID3D11SamplerState* smp; ID3D11Buffer* vcb;
};

void save(ID3D11DeviceContext* c, Saved* s) {
  ZeroMemory(s, sizeof(*s));
  c->OMGetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, s->rtv, &s->dsv);
  s->nvp = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
  c->RSGetViewports(&s->nvp, s->vp);
  c->RSGetState(&s->rs);
  c->OMGetBlendState(&s->bs, s->bf, &s->mask);
  c->OMGetDepthStencilState(&s->ds, &s->sref);
  c->IAGetInputLayout(&s->il);
  c->IAGetPrimitiveTopology(&s->topo);
  c->VSGetShader(&s->vs, nullptr, nullptr);
  c->PSGetShader(&s->ps, nullptr, nullptr);
  c->GSGetShader(&s->gs, nullptr, nullptr);
  c->HSGetShader(&s->hs, nullptr, nullptr);
  c->DSGetShader(&s->dsh, nullptr, nullptr);
  c->PSGetShaderResources(0, 1, &s->srv);
  c->PSGetSamplers(0, 1, &s->smp);
  c->VSGetConstantBuffers(0, 1, &s->vcb);
}

void restore(ID3D11DeviceContext* c, Saved* s) {
  c->OMSetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, s->rtv, s->dsv);
  c->RSSetViewports(s->nvp, s->vp);
  c->RSSetState(s->rs);
  c->OMSetBlendState(s->bs, s->bf, s->mask);
  c->OMSetDepthStencilState(s->ds, s->sref);
  c->IASetInputLayout(s->il);
  c->IASetPrimitiveTopology(s->topo);
  c->VSSetShader(s->vs, nullptr, 0);
  c->PSSetShader(s->ps, nullptr, 0);
  c->GSSetShader(s->gs, nullptr, 0);
  c->HSSetShader(s->hs, nullptr, 0);
  c->DSSetShader(s->dsh, nullptr, 0);
  c->PSSetShaderResources(0, 1, &s->srv);
  c->PSSetSamplers(0, 1, &s->smp);
  c->VSSetConstantBuffers(0, 1, &s->vcb);
  for (int i = 0; i < D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT; ++i) rel(s->rtv[i]);
  rel(s->dsv); rel(s->rs); rel(s->bs); rel(s->ds); rel(s->il);
  rel(s->vs); rel(s->ps); rel(s->gs); rel(s->hs); rel(s->dsh); rel(s->srv); rel(s->smp); rel(s->vcb);
}

void fail(const char* why, int code) {
  InterlockedIncrement(&g_s.failed);
  ++g_failures;
  if (g_logged < 8) { ++g_logged; log_line("MONITORVIEW problem: %s (%d), failure %d of 3", why, code, g_failures); }
  if (g_failures >= 3) {
    InterlockedExchange(&g_ctl.monitorView, 0);
    log_line("MONITORVIEW switched OFF after three problems: the window shows the game's back buffer as before (one eye per Present)");
    settings_changed();
  }
}
}  // namespace

static volatile LONG g_sizeDiff, g_fmtDiff;   // 1.6: Presents where the back buffer and the eye picture differed in size / format (drawn anyway)
static int g_fovZoom;   // 1.7.28: the zoom the field-of-view wish came to (0 = not used / not computable)

void monitorview_release() { release_all(); g_s.started = 0; g_s.lastDrawQpc = 0; g_calm.started = 0; g_calm.sm = 0; g_rollQ = 0; g_framing.have = 0; g_frameQ = 0; }

// 1.7.90: while the VR settings pages are open they were only in the headset; the PC window kept the frozen world (or the game's own menu).
// Now the same finished picture (1280 x 800) is drawn into the window, whole and centred, with the same shader. Returns 1 when it was drawn.
// 1.7.145: inset = 1: the world view the PC window already shows stays (no black clear) and the menu is drawn on top as a panel in the middle
// (62 % of the window), so people watching the monitor see the game and the menu together, the way the player sees it. inset = 0: the 1.7.90 whole-window menu.
int monitorview_menu_present(void* swapChain, int inset) {
  IDXGISwapChain* sc = (IDXGISwapChain*)swapChain;
  if (!sc || !g_ctl.stereoActive || !g_ctl.gameHwnd || g_failures >= 3) return 0;
  int pw = 0, ph = 0; long serial = 0;
  const uint8_t* px = vrmenu_picture(&pw, &ph, &serial);
  if (!px || pw < 16 || ph < 16) return 0;
  RECT rc;
  if (!GetClientRect(g_ctl.gameHwnd, &rc) || rc.right < 64 || rc.bottom < 64) return 0;
  ID3D11Texture2D* bb = nullptr;
  if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb)) || !bb) return 0;
  D3D11_TEXTURE2D_DESC d;
  bb->GetDesc(&d);
  if (d.SampleDesc.Count != 1 || d.Format == DXGI_FORMAT_UNKNOWN || !(d.BindFlags & D3D11_BIND_RENDER_TARGET)) { bb->Release(); return 0; }
  ID3D11Device* dev = nullptr;
  bb->GetDevice(&dev);
  if (!dev) { bb->Release(); return 0; }
  if (dev != g_dev) { release_all(); g_dev = dev; }
  if (g_state == 0) {
    g_state = create_resources(dev);
    if (g_state < 0) { int code = g_state; release_all(); g_dev = dev; fail("shaders / states could not be created (settings pages)", code); }
  }
  int ok = 0;
  if (g_state == 1) {
    if (!g_menuTex) {
      D3D11_TEXTURE2D_DESC td = {};
      td.Width = (UINT)pw; td.Height = (UINT)ph; td.MipLevels = 1; td.ArraySize = 1;
      td.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count = 1;
      td.Usage = D3D11_USAGE_DEFAULT; td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
      D3D11_SUBRESOURCE_DATA sd = {}; sd.pSysMem = px; sd.SysMemPitch = (UINT)pw * 4;
      if (SUCCEEDED(dev->CreateTexture2D(&td, &sd, &g_menuTex))) { g_menuSerial = serial; static int s_once; if (!s_once++) log_line("MONITORVIEW the VR settings pages are now drawn in the PC window too (1.7.90), window %dx%d, %s", (int)rc.right, (int)rc.bottom, inset ? "as a panel over the game view (1.7.145)" : "filling the window (no game view to show)"); }
    }
    ID3D11DeviceContext* ctx = nullptr;
    ID3D11RenderTargetView* rtv = nullptr;
    ID3D11ShaderResourceView* srv = nullptr;
    dev->GetImmediateContext(&ctx);
    if (g_menuTex && ctx) {
      if (g_menuSerial != serial) { ctx->UpdateSubresource(g_menuTex, 0, nullptr, px, (UINT)pw * 4, 0); g_menuSerial = serial; }
      if (SUCCEEDED(dev->CreateRenderTargetView(bb, nullptr, &rtv)) && rtv && SUCCEEDED(dev->CreateShaderResourceView(g_menuTex, nullptr, &srv)) && srv) {
        picture::View v;
        if (inset) {
          const int bw = (int)(rc.right * 0.62), bh = (int)(rc.bottom * 0.62);
          picture::fit_view(pw * 10, ph * 10, bw, bh, &v);
          v.x += (rc.right - bw) / 2; v.y += (rc.bottom - bh) / 2;
        } else picture::fit_view(pw * 10, ph * 10, rc.right, rc.bottom, &v);
        Cb cb;
        cb.m[0] = 1.f; cb.m[1] = 0.f; cb.m[2] = 0.f; cb.m[3] = 1.f;
        cb.p[0] = 0.5f; cb.p[1] = 0.5f; cb.p[2] = 0.f; cb.p[3] = 0.f;
        ctx->UpdateSubresource(g_cb, 0, nullptr, &cb, 0, 0);
        Saved sv;
        save(ctx, &sv);
        const float black[4] = {0, 0, 0, 1};
        ctx->OMSetRenderTargets(1, &rtv, nullptr);
        if (!inset) ctx->ClearRenderTargetView(rtv, black);
        D3D11_VIEWPORT vp;
        vp.TopLeftX = (float)(v.x * (double)d.Width / (double)rc.right);
        vp.TopLeftY = (float)(v.y * (double)d.Height / (double)rc.bottom);
        vp.Width = (float)(v.w * (double)d.Width / (double)rc.right);
        vp.Height = (float)(v.h * (double)d.Height / (double)rc.bottom);
        vp.MinDepth = 0; vp.MaxDepth = 1;
        ctx->RSSetViewports(1, &vp);
        ctx->RSSetState(g_rs);
        ctx->OMSetBlendState(g_bs, nullptr, 0xffffffffu);
        ctx->OMSetDepthStencilState(g_ds, 0);
        ctx->IASetInputLayout(nullptr);
        ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        ctx->VSSetShader(g_vs, nullptr, 0);
        ctx->VSSetConstantBuffers(0, 1, &g_cb);
        ctx->GSSetShader(nullptr, nullptr, 0);
        ctx->HSSetShader(nullptr, nullptr, 0);
        ctx->DSSetShader(nullptr, nullptr, 0);
        ctx->PSSetShader(g_ps, nullptr, 0);
        ctx->PSSetShaderResources(0, 1, &srv);
        ctx->PSSetSamplers(0, 1, &g_smp);
        ctx->Draw(3, 0);
        int px2 = 0, py2 = 0;
        if (vrmenu_pointer(&px2, &py2)) {   // 1.7.145: the pointer, so people watching see what is being pointed at (in the headset it is its own overlay)
          if (!g_dotTex) {
            uint32_t dot[10 * 10];
            for (int yy = 0; yy < 10; ++yy) for (int xx = 0; xx < 10; ++xx) dot[yy * 10 + xx] = (xx == 0 || yy == 0 || xx == 9 || yy == 9) ? 0xff000000u : 0xff00e0ffu;   // yellow, black edge (RGBA bytes)
            D3D11_TEXTURE2D_DESC td2 = {};
            td2.Width = 10; td2.Height = 10; td2.MipLevels = 1; td2.ArraySize = 1; td2.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td2.SampleDesc.Count = 1;
            td2.Usage = D3D11_USAGE_DEFAULT; td2.BindFlags = D3D11_BIND_SHADER_RESOURCE;
            D3D11_SUBRESOURCE_DATA sd2 = {}; sd2.pSysMem = dot; sd2.SysMemPitch = 40;
            dev->CreateTexture2D(&td2, &sd2, &g_dotTex);
          }
          ID3D11ShaderResourceView* dsrv = nullptr;
          if (g_dotTex && SUCCEEDED(dev->CreateShaderResourceView(g_dotTex, nullptr, &dsrv)) && dsrv) {
            const double cx = vp.TopLeftX + vp.Width * ((double)px2 / (double)pw), cy = vp.TopLeftY + vp.Height * ((double)py2 / (double)ph);
            const float sz = (float)(d.Height / 90.0 < 8.0 ? 8.0 : d.Height / 90.0);
            D3D11_VIEWPORT dv;
            dv.TopLeftX = (float)(cx - sz * 0.5); dv.TopLeftY = (float)(cy - sz * 0.5); dv.Width = sz; dv.Height = sz; dv.MinDepth = 0; dv.MaxDepth = 1;
            ctx->RSSetViewports(1, &dv);
            ctx->PSSetShaderResources(0, 1, &dsrv);
            ctx->Draw(3, 0);
            dsrv->Release();
          }
        }
        ID3D11ShaderResourceView* none = nullptr;
        ctx->PSSetShaderResources(0, 1, &none);
        restore(ctx, &sv);
        ok = 1;
      }
    }
    if (srv) srv->Release();
    if (rtv) rtv->Release();
    if (ctx) ctx->Release();
  }
  dev->Release();
  bb->Release();
  return ok;
}

int monitorview_present(void* swapChain) {
  IDXGISwapChain* sc = (IDXGISwapChain*)swapChain;
  if (!g_ctl.monitorView || !g_ctl.stereoActive || !sc || !g_ctl.gameHwnd) return 0;
  void* tex = nullptr;
  float pose[12];
  int eyeUsed = 0, age = 0, spectator = 0; float projection[3] = {};
  if (!stereo_monitor_source((int)g_ctl.monitorEye, &tex, pose, &eyeUsed, &age, projection, &spectator) || !tex) { InterlockedIncrement(&g_s.noSource); return 0; }
  const double tanH = projection[0], tanV = projection[1];
  if (!(tanH > 0.05 && tanH < 20.0 && tanV > 0.05 && tanV < 20.0)) return 0;
  RECT rc;
  if (!GetClientRect(g_ctl.gameHwnd, &rc) || rc.right < 64 || rc.bottom < 64) { InterlockedIncrement(&g_s.skipped); return 0; }
  ID3D11Texture2D* bb = nullptr;
  if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb)) || !bb) { InterlockedIncrement(&g_s.skipped); return 0; }
  ID3D11Texture2D* src = (ID3D11Texture2D*)tex;
  D3D11_TEXTURE2D_DESC d, sd;
  bb->GetDesc(&d);
  src->GetDesc(&sd);
  // 1.6: the back buffer and the eye picture no longer have to be the same size or format (the game's window can be any size and the picture level changes the eye picture):
  // the shader samples the eye picture at any scale, so the window is always filled. Only what cannot work at all is refused.
  if (d.Width != sd.Width || d.Height != sd.Height) { InterlockedIncrement(&g_sizeDiff); if (g_sizeDiff == 1) log_line("MONITORVIEW the back buffer (%ux%u) and the eye picture (%ux%u) differ in size: the picture is scaled to fill the window anyway", d.Width, d.Height, sd.Width, sd.Height); }
  if (d.Format != sd.Format) { InterlockedIncrement(&g_fmtDiff); if (g_fmtDiff == 1) log_line("MONITORVIEW the back buffer (format %d) and the eye picture (format %d) differ in format: drawn anyway", (int)d.Format, (int)sd.Format); }
  if (d.SampleDesc.Count != 1 || sd.SampleDesc.Count != 1 ||
      d.Format == DXGI_FORMAT_UNKNOWN || !(d.BindFlags & D3D11_BIND_RENDER_TARGET) || !(sd.BindFlags & D3D11_BIND_SHADER_RESOURCE)) {
    InterlockedIncrement(&g_s.mismatch);
    if (g_logged < 8) {
      ++g_logged;
      log_line("MONITORVIEW not possible now: back buffer %ux%u format=%d samples=%u bind=%x, eye picture %ux%u format=%d bind=%x", d.Width, d.Height,
               (int)d.Format, d.SampleDesc.Count, (unsigned)d.BindFlags, sd.Width, sd.Height, (int)sd.Format, (unsigned)sd.BindFlags);
    }
    bb->Release();
    return 0;
  }
  ID3D11Device* dev = nullptr;
  bb->GetDevice(&dev);
  if (!dev) { bb->Release(); return 0; }
  if (dev != g_dev) { release_all(); g_dev = dev; }   // another device (the game rebuilt it): start again

  // ---- where the picture goes and which part of the eye picture it shows
  const int fit = g_ctl.monitorFit ? 1 : 0, level = g_ctl.monitorLevel ? 1 : 0;
  int zoom = (int)g_ctl.monitorZoomPct;
  g_fovZoom = 0;
  picture::View v;
  if (fit) { v.x = 0; v.y = 0; v.w = rc.right; v.h = rc.bottom; v.active = 0; }
  else picture::fit_view((int)(10000.0 * tanH / tanV), 10000, rc.right, rc.bottom, &v);
  {   // 1.7.28: the window shows a wanted number of degrees across (the picture is cropped here, in the PC window only: the headset's eye pictures are separate textures and are not touched)
    const int want = (int)g_ctl.monitorHfovDeg;
    if (want > 0) {
      monitor::Window w0;
      double m0[4];
      monitor::projection_window(fit, 100, tanH, tanV, v.w / v.h, 0.0, &w0, m0);
      const int z = monitor::zoom_for_hfov((double)want, tanH, w0.sw);
      if (z > 0) zoom = z;
      g_fovZoom = z;
    }
  }
  double roll = level ? calm_roll(monitor::roll_from_pose34(pose), qpc_now()) : 0.0;
  monitor::Window win;
  double m[4];
  int shrunk = monitor::projection_window(fit, zoom, tanH, tanV, v.w / v.h, roll, &win, m);
  const int down = spectator ? 0 : (int)g_ctl.monitorDownDeg;
  const int hands = !spectator && g_ctl.monitorHandFrame;
  double shift = monitor::down_shift(down, tanV, win);
  if (hands && !vrmenu_is_open()) {
    HandsRaw h;
    if (controllers_raw(&h)) {
      const float* poses[2] = {h.poseL, h.poseR}; const int valid[2] = {h.validL, h.validR && !h.holstered};
      for (int j = 0; j < 2; ++j) if (valid[j]) {
        float point[3]; for (int i = 0; i < 3; ++i) point[i] = poses[j][i * 4 + 3];
        shift = point_shift(pose, point, projection, m, shift);
      }
      if (h.wandValid && !h.holstered) {
        float tip[3]; for (int i = 0; i < 3; ++i) tip[i] = h.wandPose[i * 4 + 3] - 0.35f * h.wandPose[i * 4 + 2];
        shift = point_shift(pose, tip, projection, m, shift);
      }
    }
    const double maxShift = monitor::down_shift(down > 20 ? down : 20, tanV, win);
    if (shift > maxShift) shift = maxShift;
  }
  const int64_t nowFrame = qpc_now();
  const double frameDt = g_frameQ ? (double)(nowFrame - g_frameQ) / (double)qpc_freq() : 1.0;
  g_frameQ = nowFrame;
  monitor::lower_window(&win, m, monitor::smooth_down(&g_framing, shift, frameDt));

  int ok = 0;
  ID3D11DeviceContext* ctx = nullptr;
  ID3D11RenderTargetView* rtv = nullptr;
  ID3D11ShaderResourceView* srv = nullptr;
  if (g_state == 0) {
    g_state = create_resources(dev);
    if (g_state < 0) {
      int code = g_state;
      release_all();          // partly made objects go; the next frame tries again (three failures switch the feature off)
      g_dev = dev;
      fail("shaders / states could not be created", code);
    } else {
      log_line("MONITORVIEW ready: back buffer %u x %u format=%d, window %d x %d, eye=%s fit=%s level=%d zoom=%d%%, picture shown %.0f x %.0f at %.0f,%.0f",
               d.Width, d.Height, (int)d.Format, (int)rc.right, (int)rc.bottom, g_ctl.monitorEye ? "right" : "left", fit ? "fill" : "whole", level, zoom,
               v.w, v.h, v.x, v.y);
    }
  }
  if (g_state == 1) {
    dev->GetImmediateContext(&ctx);
    if (ctx && SUCCEEDED(dev->CreateRenderTargetView(bb, nullptr, &rtv)) && rtv &&
        SUCCEEDED(dev->CreateShaderResourceView(src, nullptr, &srv)) && srv) {
      Cb cb;
      for (int i = 0; i < 4; ++i) { cb.m[i] = (float)m[i]; cb.p[i] = 0.f; }
      cb.p[0] = (float)win.cx; cb.p[1] = (float)win.cy;
      ctx->UpdateSubresource(g_cb, 0, nullptr, &cb, 0, 0);
      Saved sv;
      save(ctx, &sv);
      const float black[4] = {0, 0, 0, 1};
      ctx->OMSetRenderTargets(1, &rtv, nullptr);   // before the eye picture is bound as an input: it is never an input and an output at once
      ctx->ClearRenderTargetView(rtv, black);
      D3D11_VIEWPORT vp;
      // client pixels -> back buffer pixels: Windows stretches the back buffer over the whole client area
      vp.TopLeftX = (float)(v.x * (double)d.Width / (double)rc.right);
      vp.TopLeftY = (float)(v.y * (double)d.Height / (double)rc.bottom);
      vp.Width = (float)(v.w * (double)d.Width / (double)rc.right);
      vp.Height = (float)(v.h * (double)d.Height / (double)rc.bottom);
      vp.MinDepth = 0; vp.MaxDepth = 1;
      ctx->RSSetViewports(1, &vp);
      ctx->RSSetState(g_rs);
      ctx->OMSetBlendState(g_bs, nullptr, 0xffffffffu);
      ctx->OMSetDepthStencilState(g_ds, 0);
      ctx->IASetInputLayout(nullptr);
      ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
      ctx->VSSetShader(g_vs, nullptr, 0);
      ctx->VSSetConstantBuffers(0, 1, &g_cb);
      ctx->GSSetShader(nullptr, nullptr, 0);
      ctx->HSSetShader(nullptr, nullptr, 0);
      ctx->DSSetShader(nullptr, nullptr, 0);
      ctx->PSSetShader(g_ps, nullptr, 0);
      ctx->PSSetShaderResources(0, 1, &srv);
      ctx->PSSetSamplers(0, 1, &g_smp);
      ctx->Draw(3, 0);
      ID3D11ShaderResourceView* none = nullptr;
      ctx->PSSetShaderResources(0, 1, &none);   // the eye picture must not stay bound as an input
      restore(ctx, &sv);
      ok = 1;
      g_failures = 0;
    } else {
      fail("render target view / shader view could not be made", 0);
    }
  }
  if (srv) srv->Release();
  if (rtv) rtv->Release();
  if (ctx) ctx->Release();
  dev->Release();
  bb->Release();

  if (ok) {
    InterlockedIncrement(&g_s.draws);
    ++g_s.used[eyeUsed & 1];
    if (g_s.started && g_s.lastEye != eyeUsed) ++g_s.eyeChanges;
    g_s.started = 1;
    g_s.lastEye = eyeUsed;
    ++g_s.ageHist[age < 0 ? 0 : (age > 3 ? 3 : age)];
    if (age > g_s.ageMax) g_s.ageMax = age;
    if (shrunk) ++g_s.shrunk;
    if (!fit && (roll > 0.0087 || roll < -0.0087)) ++g_s.wedge;
    double deg = roll * 180.0 / monitor::kPi;
    if (!g_s.rollN) { g_s.rollMin = g_s.rollMax = deg; g_s.rollAbsSum = 0; }
    if (deg < g_s.rollMin) g_s.rollMin = deg;
    if (deg > g_s.rollMax) g_s.rollMax = deg;
    g_s.rollAbsSum += deg < 0 ? -deg : deg; ++g_s.rollN;
    int64_t now = qpc_now();
    if (g_s.lastDrawQpc) {
      double gap = (double)(now - g_s.lastDrawQpc) * 1000.0 / (double)qpc_freq();
      g_s.gapSum += gap; ++g_s.gapN;
      if (gap > g_s.gapMax) g_s.gapMax = gap;
    }
    g_s.lastDrawQpc = now;
    // what changed in the layout is logged (a few times), so that the log says what the window looked like
    if (g_last.bw != d.Width || g_last.bh != d.Height || g_last.cw != rc.right || g_last.ch != rc.bottom || g_last.fit != fit ||
        g_last.zoom != zoom || g_last.level != level || g_last.eye != eyeUsed || g_last.down != down || g_last.hands != hands) {
      if (g_layoutLogged < 14) {
        ++g_layoutLogged;
        log_line("MONITORVIEW layout: eye=%s fit=%s level=%d zoom=%d%% back buffer %ux%u, window %dx%d, picture drawn %.0fx%.0f at %.0f,%.0f, "
                 "source window %.3f x %.3f of the eye picture (about %.0f x %.0f degrees at the middle), roll now %.1f deg",
                 eyeUsed ? "right" : "left", fit ? "fill" : "whole", level, zoom, d.Width, d.Height, (int)rc.right, (int)rc.bottom, v.w, v.h, v.x, v.y,
                 win.sw, win.sh, 2.0 * vm::datan2(win.sw * tanH, 1.0) * 180.0 / monitor::kPi, 2.0 * vm::datan2(win.sh * tanV, 1.0) * 180.0 / monitor::kPi, roll * 180.0 / monitor::kPi);
        log_line("MONITOR framing: wanted=%ddeg source=%.1fx%.1fdeg down=%ddeg hands=%d sourceCentre=%.3f,%.3f extraRender=%d", (int)g_ctl.monitorHfovDeg, 2.0 * vm::datan2(tanH, 1.0) * 180.0 / monitor::kPi, 2.0 * vm::datan2(tanV, 1.0) * 180.0 / monitor::kPi, down, hands, win.cx, win.cy, spectator);
      }
      g_last.bw = d.Width; g_last.bh = d.Height; g_last.cw = rc.right; g_last.ch = rc.bottom;
      g_last.fit = fit; g_last.zoom = zoom; g_last.level = level; g_last.eye = eyeUsed;
      g_last.down = down; g_last.hands = hands;
    }
    g_last.vx = v.x; g_last.vy = v.y; g_last.vw = v.w; g_last.vh = v.h; g_last.sw = win.sw; g_last.sh = win.sh; g_last.roll = roll;
    g_last.tanH = tanH; g_last.tanV = tanV;
  }
  return ok;
}

void monitorview_report(LONG frame) {
  double n = (double)(g_s.rollN ? g_s.rollN : 1), gn = (double)(g_s.gapN ? g_s.gapN : 1);
  log_line("MONITORVIEW frame=%d on=%d eye=%s fit=%s level=%d zoom=%d%% state=%d draws=%d noPicture=%d skipped=%d mismatch=%d failed=%d "
           "eyeShown left/right=%d/%d eyeChanges=%d pictureAge 0/1/2/3+=%d/%d/%d/%d oldest=%d turnedSmaller=%d blackCorners=%d "
           "roll(deg, after the 1.4 dead zone and smoothing) min=%.1f max=%.1f avgAbs=%.1f rawHeadRollMax=%.1f followedMax=%.1f drawGapMs avg=%.1f max=%.1f drawn=%.0fx%.0f at %.0f,%.0f window=%dx%d | 1.6: sizes differed %ld times, formats differed %ld times (drawn anyway)",
           (int)frame, (int)g_ctl.monitorView, g_ctl.monitorEye ? "right" : "left", g_ctl.monitorFit ? "fill" : "whole", (int)g_ctl.monitorLevel,
           (int)g_ctl.monitorZoomPct, g_state, (int)g_s.draws, (int)g_s.noSource, (int)g_s.skipped, (int)g_s.mismatch, (int)g_s.failed,
           (int)g_s.used[0], (int)g_s.used[1], (int)g_s.eyeChanges, (int)g_s.ageHist[0], (int)g_s.ageHist[1], (int)g_s.ageHist[2], (int)g_s.ageHist[3],
           (int)g_s.ageMax, (int)g_s.shrunk, (int)g_s.wedge, g_s.rollN ? g_s.rollMin : 0.0, g_s.rollN ? g_s.rollMax : 0.0, g_s.rollAbsSum / n, g_rollRawMax * 180.0 / monitor::kPi, g_rollOutMax * 180.0 / monitor::kPi,
           g_s.gapSum / gn, g_s.gapMax, g_last.vw, g_last.vh, g_last.vx, g_last.vy, g_last.cw, g_last.ch, (long)g_sizeDiff, (long)g_fmtDiff);
  log_line("MONITORFOV frame=%d wish=%d deg across (0 = use monitor_zoom_pct %d%%) -> zoom used %d%% (0 = wish not usable), the engine draws %.0f deg across (tan %.3f), window shows %.0f x %.0f deg, menu_fill=%d (1.7.28: the PC window is cropped, the headset is not touched)",
           (int)frame, (int)g_ctl.monitorHfovDeg, (int)g_ctl.monitorZoomPct, g_fovZoom, 2.0 * vm::datan2(g_last.tanH, 1.0) * 180.0 / monitor::kPi,
           g_last.tanH,
           2.0 * vm::datan2(g_last.sw * g_last.tanH, 1.0) * 180.0 / monitor::kPi, 2.0 * vm::datan2(g_last.sh * g_last.tanV, 1.0) * 180.0 / monitor::kPi,
           (int)g_ctl.monitorMenuFill);
  g_rollRawMax = 0; g_rollOutMax = 0;
  g_s.rollN = 0; g_s.rollAbsSum = 0; g_s.gapSum = 0; g_s.gapMax = 0; g_s.gapN = 0;   // roll and gap are per report; the counters keep counting
}

#endif
