// 0.26 mouse pointer with a picture that is bigger than the window.
//
// The game takes the pointer position of mouse messages (window pixels) and
// uses it unchanged as a position in its picture: the pointer sprite is drawn
// there and the menus test it against their buttons (see layout.h "Mouse").
// That is only right when picture and window have the same size. With a
// picture level above 1 the picture is bigger than the window, and without a
// correction the pointer would reach only the upper-left part of the screen.
//
// Two small corrections, both only while the two sizes differ:
//   - the game's own message handler (HandleMessage 0x4586A0, called from the
//     game's WH_GETMESSAGE hook) gets a COPY of each mouse message with the
//     position scaled from window pixels to picture pixels. The real message
//     is not changed; Windows and other hooks see it as it was.
//   - when the game moves the pointer itself (SetCursor 0x45CB50: stores the
//     position, then ClientToScreen + SetCursorPos) the position is scaled the
//     other way for that one ClientToScreen call (import slot, call site
//     checked by return address), so the Windows pointer ends up where the
//     game believes it is.
// Looking around with the mouse is not affected either way: the game reads
// mouse movement through DirectInput (GetDeviceState at 0x45EF92), not from
// pointer positions.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include "layout.h"
#include "picturemath.h"
#include "MinHook.h"

typedef uintptr_t (*PFN_HandleMessage)(MSG*);  // result (if any) is passed through untouched
typedef BOOL(WINAPI* PFN_ClientToScreen)(HWND, POINT*);
static PFN_HandleMessage o_handleMessage;
static PFN_ClientToScreen g_clientToScreen;   // what the game's import slot held (user32!ClientToScreen)
static int g_msgHook, g_c2sHook;              // 1 installed, <0 why not
static volatile LONG g_scaledMsgs, g_scaledWarps;
static int g_lastW, g_lastH, g_lastCw, g_lastCh;

// Picture size as the game uses it for the pointer (its own width/height
// variables) and the window's client size. Returns 1 when they differ.
static int sizes(HWND hwnd, int* W, int* H, int* cw, int* ch) {
  RECT rc;
  if (!hwnd || !GetClientRect(hwnd, &rc)) return 0;
  *W = *(const volatile int*)rva(layout::kRvaWantedWidth);
  *H = *(const volatile int*)rva(layout::kRvaWantedHeight);
  *cw = rc.right;
  *ch = rc.bottom;
  if (*W < 640 || *H < 480 || *W > 16384 || *H > 16384 || *cw < 320 || *ch < 200) return 0;
  g_lastW = *W; g_lastH = *H; g_lastCw = *cw; g_lastCh = *ch;
  return *W != *cw || *H != *ch;
}

// 0.45: while the flat view draws the picture in its own shape (black bars), pointer positions go through that
// view instead of a plain stretch. Outside the headset only, and only while the pass really drew the last frame.
static int flat_view(double* vx, double* vy, double* vw, double* vh) { return g_ctl.flatView && flatview_get_view(vx, vy, vw, vh); }
static void window_to_picture(int x, int y, int cw, int ch, int W, int H, int* ox, int* oy) {
  double vx, vy, vw, vh;
  if (flat_view(&vx, &vy, &vw, &vh)) {
    *ox = picture::view_to_picture(x, vx, vw, W);
    *oy = picture::view_to_picture(y, vy, vh, H);
  } else {
    *ox = picture::scale_coord(x, cw, W);
    *oy = picture::scale_coord(y, ch, H);
  }
}
static void picture_to_window(int x, int y, int W, int H, int cw, int ch, int* ox, int* oy) {
  double vx, vy, vw, vh;
  if (flat_view(&vx, &vy, &vw, &vh)) {
    *ox = picture::picture_to_view(x, vx, vw, W);
    *oy = picture::picture_to_view(y, vy, vh, H);
  } else {
    *ox = picture::scale_coord_back(x, W, cw);
    *oy = picture::scale_coord_back(y, H, ch);
  }
}

static LPARAM pack(int x, int y) { return (LPARAM)(uint32_t)(((uint32_t)(uint16_t)y << 16) | (uint32_t)(uint16_t)x); }

static uintptr_t hk_handleMessage(MSG* msg) {
  int W, H, cw, ch;
  UINT m = msg ? msg->message : 0;
  if (m >= WM_MOUSEMOVE && m <= WM_XBUTTONDBLCLK && sizes(msg->hwnd, &W, &H, &cw, &ch)) {
    MSG c = *msg;
    int x = (short)LOWORD(c.lParam), y = (short)HIWORD(c.lParam);
    if (m == WM_MOUSEWHEEL) {
      // Wheel messages carry a screen position; the game converts it with
      // ScreenToClient itself. Hand it the screen position whose conversion
      // gives the scaled point.
      POINT p = {x, y};
      if (ScreenToClient(c.hwnd, &p)) {
        int qx, qy;
        window_to_picture(p.x, p.y, cw, ch, W, H, &qx, &qy);
        p.x = qx; p.y = qy;
        if (g_clientToScreen(c.hwnd, &p) && p.x >= 0 && p.y >= 0 && p.x < 65536 && p.y < 65536) c.lParam = pack(p.x, p.y);
      }
    } else {
      int px, py;
      window_to_picture(x, y, cw, ch, W, H, &px, &py);
      c.lParam = pack(px, py);
    }
    InterlockedIncrement(&g_scaledMsgs);
    return o_handleMessage(&c);
  }
  return o_handleMessage(msg);
}

static BOOL WINAPI hk_ClientToScreen(HWND hwnd, POINT* pt) {
  int W, H, cw, ch;
  if ((uintptr_t)GBVR_RETURN_ADDRESS() == rva(layout::kRvaSetCursorC2SReturn) && pt && sizes(hwnd, &W, &H, &cw, &ch)) {
    POINT p = *pt;  // picture pixels -> window pixels
    int qx, qy;
    picture_to_window(p.x, p.y, W, H, cw, ch, &qx, &qy);
    p.x = qx; p.y = qy;
    BOOL r = g_clientToScreen(hwnd, &p);
    *pt = p;
    InterlockedIncrement(&g_scaledWarps);
    return r;
  }
  return g_clientToScreen(hwnd, pt);
}

void mouse_install() {
  if (g_msgHook || g_c2sHook) return;
  if (!g_game.identityOK) { g_msgHook = g_c2sHook = -1; return; }
  // the game's ClientToScreen import slot and the call site that uses it
  void** slot = (void**)rva(layout::kRvaIatClientToScreen);
  HMODULE u32 = GetModuleHandleW(L"user32.dll");
  void* real = u32 ? (void*)GetProcAddress(u32, "ClientToScreen") : nullptr;
  const uint8_t* site = (const uint8_t*)rva(layout::kRvaSetCursorC2SReturn - 6);
  int siteOK = site[0] == 0xff && site[1] == 0x15 &&
               (uintptr_t)(site + 6 + *(const int32_t*)(site + 2)) == (uintptr_t)slot;
  const uint8_t* fn = (const uint8_t*)rva(layout::kRvaHandleMessage);
  int fnOK = 1;
  for (int i = 0; i < 16; ++i) if (fn[i] != layout::kBytesHandleMessage[i]) fnOK = 0;
  // The slot must hold a real code address (normally user32's function; a
  // compatibility layer may have put its own there - that one is then called).
  void* cur = *slot;
  MEMORY_BASIC_INFORMATION mbi;
  int slotOK = cur && VirtualQuery(cur, &mbi, sizeof(mbi)) == sizeof(mbi) && mbi.State == MEM_COMMIT &&
               (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY));
  if (!slotOK || !siteOK || !fnOK) {
    g_msgHook = g_c2sHook = -2;
    log_line("MOUSE scaling not installed (slot=%d callSite=%d handler=%d): with a bigger picture the mouse "
             "pointer reaches only part of the menus; keyboard and controller are not affected", slotOK, siteOK, fnOK);
    return;
  }
  g_clientToScreen = (PFN_ClientToScreen)cur;
  int plain = cur == real;
  // Both corrections or none: the import slot first (it does nothing until
  // its call site is reached), then the message hook; if that fails the slot
  // gets its old value back.
  DWORD old = 0;
  if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &old)) {
    g_msgHook = g_c2sHook = -4;
    log_line("MOUSE scaling not installed (import slot could not be changed)");
    return;
  }
  *slot = (void*)hk_ClientToScreen;
  void* target = (void*)rva(layout::kRvaHandleMessage);
  MH_STATUS s = MH_CreateHook(target, (void*)hk_handleMessage, (void**)&o_handleMessage);
  if (s == MH_OK) s = MH_EnableHook(target);
  if (s == MH_OK) {
    g_msgHook = g_c2sHook = 1;
  } else {
    *slot = cur;
    g_msgHook = g_c2sHook = -3;
  }
  VirtualProtect(slot, sizeof(void*), old, &old);
  log_line("HOOK mouse-message status=%d target=%p; pointer import slot=%d (slot held user32's function: %d)", (int)s,
           target, g_c2sHook, plain);
}

void mouse_report() {
  log_line("MOUSE hooks=%d/%d scaledMessages=%d scaledPointerMoves=%d picture=%dx%d window=%dx%d", g_msgHook, g_c2sHook,
           (int)g_scaledMsgs, (int)g_scaledWarps, g_lastW, g_lastH, g_lastCw, g_lastCh);
}

#endif
