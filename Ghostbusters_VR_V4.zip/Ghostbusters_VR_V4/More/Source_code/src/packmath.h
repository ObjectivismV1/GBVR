// 0.68 the pack follows the torso (0.69: and the eye-match shift of the whole body, applied last). The pack (and the other "extras") is drawn from a world matrix of its own, not from the body's
// bones, so when the full-body layer drops the hips (crouch) and bends the spine (lean) the pack stayed where the standing body was.
// armcore.h records what the torso pass did (a drop, then two rotations about pivots, all in game world feet); this applies the same
// motion to a world matrix (16 floats, row-vector form: p_world = p_local * A + t, the translation in row 3).
// The pack hangs from the second spine bone, so only the first rotation (about the lower spine) carries it; the second (upper back,
// shoulders, head) does not.
#pragma once
#include "armmath.h"

namespace bpack {

struct Motion {
  int have;
  double drop;          // world feet, negative = down
  double shift[3];      // 0.69: the whole body moved by this much last (the eye match), world feet
  double pv[2][3];      // pivots of the two rotations
  double Q[2][9];       // the rotations (column form, world)
};

// stages: bit 0 = the lower spine rotation, bit 1 = the upper one. Returns 1 if the matrix was changed.
inline int apply(const Motion& m, float* M, int stages) {
  if (!m.have) return 0;
  double t[3] = {M[12], M[13] + m.drop, M[14]};
  double rows[3][3];
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) rows[r][c] = M[r * 4 + c];
  int changed = m.drop != 0.0;
  for (int s = 0; s < 2; ++s) {
    if (!(stages & (1 << s))) continue;
    double rel[3], rr[3];
    arm::sub(t, m.pv[s], rel);
    arm::apply3(m.Q[s], rel, rr);
    for (int i = 0; i < 3; ++i) t[i] = m.pv[s][i] + rr[i];
    for (int r = 0; r < 3; ++r) { double o[3]; arm::apply3(m.Q[s], rows[r], o); for (int c = 0; c < 3; ++c) rows[r][c] = o[c]; }
    changed = 1;
  }
  for (int i = 0; i < 3; ++i) t[i] += m.shift[i];
  if (m.shift[0] != 0.0 || m.shift[1] != 0.0 || m.shift[2] != 0.0) changed = 1;
  for (int i = 0; i < 3; ++i) if (!vm::is_finite_f((float)t[i])) return 0;
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) if (!vm::is_finite_f((float)rows[r][c])) return 0;
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) M[r * 4 + c] = (float)rows[r][c];
  M[12] = (float)t[0]; M[13] = (float)t[1]; M[14] = (float)t[2];
  return changed;
}

}  // namespace bpack
