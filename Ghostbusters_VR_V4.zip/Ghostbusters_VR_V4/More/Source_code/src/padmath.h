// Controller -> Xbox pad math (0.33). Pure functions, no Windows dependency;
// unit-tested in tests/test_pad.cpp.
//
// The game reads its input from an Xbox pad through XInput (verified in
// ghost.exe: it imports XInputGetState / XInputSetState / XInputGetCapabilities
// from XINPUT1_3.dll by ordinal 2 / 3 / 4 and maps wButtons bit 12 = A (control
// 2), 13 = B (1), 14 = X (3), 15 = Y (0), 8 = LB (6), 9 = RB (7), 4 = Start (8),
// 5 = Back (9); see layout.h "Gamepad"). The Quest controllers are therefore
// turned into the pad state the game already understands; the game decides what
// every button does.
#pragma once
#include <stdint.h>
#include "vmath.h"

namespace pad {

// XInput button masks
enum : uint16_t {
  kDpadUp = 0x0001, kDpadDown = 0x0002, kDpadLeft = 0x0004, kDpadRight = 0x0008,
  kStart = 0x0010, kBack = 0x0020, kLeftThumb = 0x0040, kRightThumb = 0x0080,
  kLeftShoulder = 0x0100, kRightShoulder = 0x0200,
  kA = 0x1000, kB = 0x2000, kX = 0x4000, kY = 0x8000,
};

// OpenVR EVRButtonId numbers (bit positions in ulButtonPressed) as SteamVR
// reports Oculus Touch / Quest controllers.
enum { kVrMenu = 1, kVrGrip = 2, kVrA = 7, kVrStick = 32, kVrTrigger = 33 };

inline int vr_pressed(uint64_t mask, int bit) { return (int)((mask >> bit) & 1u); }

struct Hand {            // one controller as read from OpenVR
  int valid;
  float stickX, stickY;  // thumbstick, -1..1 (x right, y up)
  float trigger;         // 0..1
  uint64_t pressed;      // ulButtonPressed
  int away;              // 0.50: 1 = this (left) hand is more than 0.8 m from the other hand, i.e. not on the wand
  int layer;             // 0.98: (left hand) 1 = the Y button is held long enough to be the D layer: right stick = D-pad, right stick click = Vent, right B = HUD, right A = Select
};

struct State {           // what XINPUT_GAMEPAD holds
  uint16_t buttons;
  uint8_t lt, rt;
  int16_t lx, ly, rx, ry;
};

struct Config {
  int deadzonePct;       // thumbstick dead zone, percent (5..50)
  int twoHandFire;       // 1: the triggers only count while both grips are held
  int dpadWithGrip;      // 1: right grip held + right stick = D-pad (gadget select) instead of turning
  int ltCapture;         // legacy setting kept for config compatibility; 1.7.57 always keeps the physical left trigger on the game's LT (alternate fire)
  int sprintClick;       // 1 = LEFT stick click is Sprint (L3); normal RIGHT stick click is Capture (LB), and Vent (RB) stays in the D layer
};

// Trigger normalization. In 1.7.57 the physical left trigger always stays the game's LT / native alternate-fire axis; Capture is a button on right-stick click.
inline int trigger_held(float t) { return t == t && t >= 0.30f; }

inline int same(const State& a, const State& b) {
  return a.buttons == b.buttons && a.lt == b.lt && a.rt == b.rt && a.lx == b.lx && a.ly == b.ly && a.rx == b.rx && a.ry == b.ry;
}

inline int16_t axis16(double v) {
  if (!(v == v)) return 0;
  if (v > 1.0) v = 1.0;
  if (v < -1.0) v = -1.0;
  return (int16_t)(v * (v < 0 ? 32768.0 : 32767.0));
}

// Radial dead zone with a linear rescale of the rest: 0 inside the dead zone,
// full deflection stays full deflection.
inline void shape_stick(float x, float y, double dz, int16_t* ox, int16_t* oy) {
  *ox = *oy = 0;
  if (!(x == x) || !(y == y)) return;
  double mag = vm::dsqrt((double)x * x + (double)y * y);
  if (!(mag > dz) || mag < 1e-9) return;
  if (mag > 1.0) mag = 1.0;
  double t = (mag - dz) / (1.0 - dz);
  double inv = t / vm::dsqrt((double)x * x + (double)y * y);
  *ox = axis16((double)x * inv);
  *oy = axis16((double)y * inv);
}

inline uint8_t trigger8(float t) {
  if (!(t == t) || t < 0.05f) return 0;   // below 5 %: noise, not a pull
  if (t > 1.0f) t = 1.0f;
  return (uint8_t)(t * 255.0f);
}

// Layout used by 0.33 (Quest / Touch):
//   left stick = move                 right stick = turn (left / right)
//   right trigger = fire (primary)    left trigger = secondary fire
//   right A = A (interact)            right B = B (jump / evade / sprint)
//   left X  = X (deploy trap)         left Y  = Y (PKE meter)
//   left stick click = L3 (sprint)          right stick click = LB (capture / wrangle)
//   hold left Y for D-layer: right stick = D-pad and right stick click = RB (vent)
//   left menu = Start (pause)
//   left grip held with the left hand AWAY from the wand (more than 0.8 m from the right hand) + right stick = D-pad (choose gadget)
//   gripping with either hand never stops the right stick from turning; the left grip near the right hand = two-hand hold
// SteamVR reports the face buttons of both Touch controllers as the same two
// ids (k_EButton_A = X or A, ApplicationMenu = Y or B), so the hand decides.
inline State build(const Hand& left, const Hand& right, const Config& c) {
  State s = {};
  double dz = c.deadzonePct / 100.0;
  if (dz < 0.05) dz = 0.05;
  if (dz > 0.5) dz = 0.5;
  if (left.valid) {
    shape_stick(left.stickX, left.stickY, dz, &s.lx, &s.ly);
    if (vr_pressed(left.pressed, kVrA)) s.buttons |= kX;
    if (vr_pressed(left.pressed, kVrMenu)) s.buttons |= kY;
    if (!c.sprintClick && vr_pressed(left.pressed, kVrStick)) s.buttons |= kLeftShoulder;   // legacy layout: left click = Capture
    if (c.sprintClick && vr_pressed(left.pressed, kVrStick)) s.buttons |= kLeftThumb;   // 0.98: pressing the left thumbstick down = Sprint (the game's L3)
  }
  const int layer = c.sprintClick && left.valid && left.layer;   // 0.98: Y held = the D layer
  if (right.valid && layer) {
    // the D layer: no turning, no jump, no interact while it is held; the right hand's buttons are the rarely used ones
    double ax = right.stickX, ay = right.stickY;
    double mag = vm::dsqrt(ax * ax + ay * ay);
    if (mag > 0.6) {
      if (vm::dabs(ax) >= vm::dabs(ay)) s.buttons |= ax > 0 ? kDpadRight : kDpadLeft;
      else s.buttons |= ay > 0 ? kDpadUp : kDpadDown;
    }
    if (vr_pressed(right.pressed, kVrStick)) s.buttons |= kRightShoulder;   // Vent (the game's RB)
    if (vr_pressed(right.pressed, kVrMenu)) s.buttons |= kRightThumb;       // B = HUD on / off (the game's R3)
    if (vr_pressed(right.pressed, kVrA)) s.buttons |= kBack;                 // A = Select / Back
  } else if (right.valid) {
    if (c.dpadWithGrip && left.valid && left.away && vr_pressed(left.pressed, kVrGrip)) {
      double ax = right.stickX, ay = right.stickY;
      double mag = vm::dsqrt(ax * ax + ay * ay);
      if (mag > 0.6) {
        if (vm::dabs(ax) >= vm::dabs(ay)) s.buttons |= ax > 0 ? kDpadRight : kDpadLeft;
        else s.buttons |= ay > 0 ? kDpadUp : kDpadDown;
      }
    } else {
      shape_stick(right.stickX, right.stickY, dz, &s.rx, &s.ry);
    }
    if (vr_pressed(right.pressed, kVrA)) s.buttons |= kA;
    if (vr_pressed(right.pressed, kVrMenu)) s.buttons |= kB;
    if (vr_pressed(right.pressed, kVrStick)) {
      if (c.sprintClick) s.buttons |= kLeftShoulder;        // 1.7.57: normal right click = Capture / wrangle (LB)
      else s.buttons |= kRightShoulder;                     // legacy layout: right click = Vent (RB)
    }
  }
  int bothGrips = left.valid && right.valid && vr_pressed(left.pressed, kVrGrip);   // 0.50: the off-hand grip alone makes the two-hand hold
  // 1.7.57: alternate fire must never be swallowed by a probe mode. Even when
  // two_hand_fire requires an off-hand grip for PRIMARY fire, the physical
  // LEFT TRIGGER still reaches the game's LT for every equipped beam/weapon.
  if (left.valid) s.lt = trigger8(left.trigger);
  if ((!c.twoHandFire || bothGrips) && right.valid) s.rt = trigger8(right.trigger);
  return s;
}

// Menu button of the left controller opens the pause menu. Kept separate so it
// can be switched off by a test (the same id is Y on that hand).
inline State with_start(State s, const Hand& left) {
  if (left.valid && vr_pressed(left.pressed, kVrMenu) && vr_pressed(left.pressed, kVrGrip)) s.buttons |= kStart;
  return s;
}

// A real pad (if any) and the controllers at the same time.
inline State merge(State real, const State& vr) {
  real.buttons |= vr.buttons;
  if (vr.lt > real.lt) real.lt = vr.lt;
  if (vr.rt > real.rt) real.rt = vr.rt;
  if ((vr.lx > 64 || vr.lx < -64) || (vr.ly > 64 || vr.ly < -64)) { real.lx = vr.lx; real.ly = vr.ly; }
  if ((vr.rx > 64 || vr.rx < -64) || (vr.ry > 64 || vr.ry < -64)) { real.rx = vr.rx; real.ry = vr.ry; }
  return real;
}

// XINPUT_STATE.dwPacketNumber: changes exactly when the delivered state does.
struct PacketTracker {
  State prev;
  uint32_t seq;
  int have;
  uint32_t next(const State& s) {
    if (!have || !same(s, prev)) { ++seq; prev = s; have = 1; }
    return seq ? seq : 1;
  }
};

// XINPUT_CAPABILITIES for a plain Xbox 360 pad (20 bytes): Type = 1 (gamepad),
// SubType = 1 (gamepad), Flags = 0, Gamepad = every button, full triggers,
// stick masks -64, Vibration = both motors.
inline void fake_capabilities(uint8_t* c20) {
  static const uint8_t k[20] = {0x01, 0x01, 0x00, 0x00, 0xFF, 0xF3, 0xFF, 0xFF, 0xC0, 0xFF, 0xC0, 0xFF,
                                0xC0, 0xFF, 0xC0, 0xFF, 0xFF, 0x00, 0xFF, 0x00};
  for (int i = 0; i < 20; ++i) c20[i] = k[i];
}

// Rumble: the game's two motor speeds (0..65535) -> one haptic pulse length in
// microseconds (OpenVR allows up to 3999 per call).
inline unsigned rumble_to_pulse_us(unsigned left, unsigned right) {
  unsigned m = left > right ? left : right;
  if (m < 2000) return 0;
  unsigned us = 400 + (unsigned)((double)m / 65535.0 * 3599.0);
  return us > 3999 ? 3999 : us;
}

// ---- Hand aim -----------------------------------------------------------------
// engine-local controller rotation (row-major, columns right/up/forward, see
// headtrack.cpp) and the level basis of the camera yaw -> world pointing vector.
// pitchDeg tilts the pointing direction up (+) / down (-) around the controller's
// own right axis (controllers rest at an angle in the hand).
inline int hand_forward_world(const float* level, const float* handLocal, double pitchDeg, float* out) {
  float R[9];
  vm::mul(level, handLocal, R);
  double fx = R[2], fy = R[5], fz = R[8];   // forward column
  double ux = R[1], uy = R[4], uz = R[7];   // up column
  double s, c;
  vm::dsincos(pitchDeg * vm::kPi / 180.0, &s, &c);
  double x = fx * c + ux * s, y = fy * c + uy * s, z = fz * c + uz * s;
  double l2 = x * x + y * y + z * z;
  if (!(l2 > 0.25) || !(l2 < 4.0)) return 0;
  double inv = 1.0 / vm::dsqrt(l2);
  out[0] = (float)(x * inv); out[1] = (float)(y * inv); out[2] = (float)(z * inv);
  return 1;
}

// Direction from the rear hand (right, on the trigger grip) to the front hand
// (left, on the support grip), both in engine-local metres, rotated into the
// world by the level basis. Returns 0 if the hands are closer than minDist.
inline int two_hand_line_world(const float* level, const float* rearLocal, const float* frontLocal, double minDist, float* out) {
  double d[3] = {(double)frontLocal[0] - rearLocal[0], (double)frontLocal[1] - rearLocal[1], (double)frontLocal[2] - rearLocal[2]};
  double l2 = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];
  if (!(l2 >= minDist * minDist) || !(l2 < 0.64)) return 0;
  double inv = 1.0 / vm::dsqrt(l2);
  for (int i = 0; i < 3; ++i) d[i] *= inv;
  for (int r = 0; r < 3; ++r) out[r] = (float)((double)level[r * 3] * d[0] + (double)level[r * 3 + 1] * d[1] + (double)level[r * 3 + 2] * d[2]);
  return 1;
}

// 0.50: distance between two OpenVR 3x4 poses greater than maxM metres.
inline int hands_apart(const float* a34, const float* b34, double maxM) {
  double d0 = (double)a34[3] - b34[3], d1 = (double)a34[7] - b34[7], d2 = (double)a34[11] - b34[11];
  return d0 * d0 + d1 * d1 + d2 * d2 > maxM * maxM;
}

// ---- Holster (0.38) ------------------------------------------------------------
// head34 / hand34: OpenVR 3x4 poses (standing space). True if the hand is within radiusM of the hip
// point: sideM to the right of the head and dropM below it, in the head's yaw-aligned frame.
inline int holster_hit(const float* head34, const float* hand34, double sideM, double dropM, double radiusM) {
  double fx = -(double)head34[2], fz = -(double)head34[10];            // head forward (-z column), horizontal part
  double fl = vm::dsqrt(fx * fx + fz * fz);
  if (!(fl > 1e-3)) return 0;                                          // looking straight up/down: no yaw
  fx /= fl; fz /= fl;
  double rx = -fz, rz = fx;                                            // right = forward rotated -90 deg about up
  double dx = (double)hand34[3] - head34[3], dy = (double)hand34[7] - head34[7], dz = (double)hand34[11] - head34[11];
  double x = dx * rx + dz * rz - sideM, z = dx * fx + dz * fz, y = dy + dropM;
  return x * x + y * y + z * z <= radiusM * radiusM;
}

// 0.77: distance (metres) of the hand from the hip point (same frame as holster_hit; sideM < 0 is the left hip). -1 when the head looks straight up / down.
inline double hip_dist(const float* head34, const float* hand34, double sideM, double dropM) {
  double fx = -(double)head34[2], fz = -(double)head34[10];
  double fl = vm::dsqrt(fx * fx + fz * fz);
  if (!(fl > 1e-3)) return -1.0;
  fx /= fl; fz /= fl;
  double rx = -fz, rz = fx;
  double dx = (double)hand34[3] - head34[3], dy = (double)hand34[7] - head34[7], dz = (double)hand34[11] - head34[11];
  double x = dx * rx + dz * rz - sideM, z = dx * fx + dz * fz, y = dy + dropM;
  return vm::dsqrt(x * x + y * y + z * z);
}

// 0.45 pack vent: the proton pack sits on the player's back. A hand reaching over a shoulder (behind and a little
// below the head, in the head's yaw-aligned frame, either side) is "on the pack". backM = how far behind the head
// the zone centre is, dropM = how far below, radiusM = zone radius. Squeezing a grip there vents the pack.
inline int pack_hit(const float* head34, const float* hand34, double backM, double dropM, double radiusM) {
  double fx = -(double)head34[2], fz = -(double)head34[10];
  double fl = vm::dsqrt(fx * fx + fz * fz);
  if (!(fl > 1e-3)) return 0;
  fx /= fl; fz /= fl;
  double rx = -fz, rz = fx;
  double dx = (double)hand34[3] - head34[3], dy = (double)hand34[7] - head34[7], dz = (double)hand34[11] - head34[11];
  double x = dx * rx + dz * rz, z = dx * fx + dz * fz + backM, y = dy + dropM;
  return x * x + y * y + z * z <= radiusM * radiusM;
}

// Squeezing the right grip while the right hand is in the holster zone toggles holstered.
struct Holster {
  int holstered;
  int prevGrip;
  void update(int gripNow, int inZone) {
    if (gripNow && !prevGrip && inZone) holstered = !holstered;
    prevGrip = gripNow;
  }
};


// 0.46: the game's own button numbers (bit i = button i of its per-pad arrays at +0x138 / +0xA4, see
// layout.h "Gamepad" and the XInput poll at 0x45FA90): 0 Y, 1 B, 2 A, 3 X, 4 LT, 5 RT, 6 LB, 7 RB, 8 Start, 9 Back,
// 10 left stick click, 11 right stick click, 28 D-pad left, 29 right, 30 up, 31 down. Triggers count above 60/255.
inline uint32_t game_button_mask(unsigned xbuttons, int lt, int rt) {
  static const struct { unsigned x; int idx; } map[] = {
    {kY, 0}, {kB, 1}, {kA, 2}, {kX, 3}, {kRightShoulder, 7}, {kLeftShoulder, 6}, {kStart, 8}, {kBack, 9},
    {kRightThumb, 11}, {kLeftThumb, 10}, {kDpadLeft, 28}, {kDpadRight, 29}, {kDpadUp, 30}, {kDpadDown, 31}};
  uint32_t m = 0;
  for (const auto& e : map) if (xbuttons & e.x) m |= 1u << e.idx;
  if (lt > 60) m |= 1u << 4;
  if (rt > 60) m |= 1u << 5;
  return m;
}

// 1.7.91 import-slot guard (xinput_bridge.cpp): the game's three XInput import slots are checked again every few seconds. A slot that no longer holds our function is
// patched again only when ALL of these hold: it holds code (some other program's function), our hook was not called since the last check (so the other program's
// function does not lead back to ours: no loop), the game is in play and fewer than 8 repairs were made (it never fights another program for ever).
// lastCalls < 0 = no earlier check yet (the first check only takes the baseline).
inline int guard_should_repatch(int slotIsOurs, int slotHoldsCode, long callsNow, long lastCalls, int inPlay, int repairsSoFar) {
  if (slotIsOurs || !slotHoldsCode || !inPlay || repairsSoFar >= 8 || lastCalls < 0) return 0;
  return callsNow == lastCalls ? 1 : 0;
}

// 1.7.92 DirectInput takeover. Some PCs give the game a DirectInput gamepad of its own (Steam's virtual pad, a streamer's or a remapper's virtual pad): the game then reads THAT device
// for its slot and never asks XInput for it (the log shows "the game read the pad 0 times" and four non-zero DirectInput device pointers), so the VR controllers - which reach the
// game as the XInput pad - do not move the character (right stick turns because the mod handles it itself, left stick does not walk). The fix runs on the game's own thread: it
// closes the game's DirectInput pads and lets the game's normal XInput detection take the slot. It is armed only when ALL of these hold: the VR controllers made the pad at
// this check and at the one before (liveChecks >= 2), the game has a DirectInput pad open, the game did not call XInput even once since the last check (it would, if the
// slot were an XInput pad), there is a baseline (lastReads >= 0) and it was tried fewer than 6 times. A PC without DirectInput pads, or where the game does read XInput, is never touched.
inline int di_takeover_should_arm(int padLive, int liveChecks, int diOpen, long readsNow, long lastReads, int triesSoFar) {
  if (!padLive || liveChecks < 2 || !diOpen || lastReads < 0 || triesSoFar >= 6) return 0;
  return readsNow == lastReads ? 1 : 0;
}
// 1.7.141: a joystick / HOTAS / wheel / other DirectInput device in the game's FIRST pad slot. The game reads slot 0 (player 1) through that device and never asks
// XInput for slot 0, so the VR controllers (which answer as XInput pad 0) cannot move the character, while it still asks XInput for slots 1-3 (so the rule above,
// "no XInput reads at all", never fired). Players fixed it by unplugging the HOTAS / every USB device. Same safety as above, but looking only at XInput calls for slot 0.
inline int di_takeover_should_arm_slot0(int padLive, int liveChecks, int diSlot0, long reads0Now, long reads0Last, int triesSoFar) {
  if (!padLive || liveChecks < 2 || !diSlot0 || reads0Last < 0 || triesSoFar >= 6) return 0;
  return reads0Now == reads0Last ? 1 : 0;
}
}  // namespace pad
