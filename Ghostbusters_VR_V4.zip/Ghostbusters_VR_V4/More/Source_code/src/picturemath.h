// 0.26 picture levels: how big the game's picture is. Pure functions
// (tests/test_picture.cpp).
//
// Why the size matters: one eye of the headset sees about 132 x 135 degrees.
// The engine can only draw a view that is symmetric around its middle and
// (unless F7 is on) as wide as the picture's shape dictates, so each eye is
// cut out of the game's picture:
//   - height: always 83.8 % of the picture's lines (Quest 3);
//   - width:  43.6 % of a 16:9 picture, 77.6 % of a square one, about 80 %
//             with F7 (separate horizontal / vertical field of view).
// The vertical sharpness therefore depends only on the number of lines:
//   1440 lines -> 1206 per eye  (0.25 and before: about 9 pixels per degree)
//   2160 lines -> 1810 per eye
//   2880 lines -> 2413 per eye  (the headset's own panel has 2208)
// A picture that is less wide needs far fewer pixels for the same number of
// lines, but on the monitor it is stretched to the window, and a square one is
// not a shape the game's menus were made for - so that one is a test level.
//
// Limits taken from the game (see layout.h "Display modes"):
//   - never more than 2880 lines: the engine keeps two 1440-entry per-line
//     tables back to back (0x251E090, 0x2520D90) and 0x2FD160 writes one entry
//     per picture line into them. Up to 2880 lines stay inside the two tables
//     (2160 lines is what the game does on a 4K monitor); one line more would
//     overwrite other engine variables.
//   - never wider than 3840: the widest picture the game was sold for (4K).
#pragma once
#include <stdint.h>

namespace picture {

static const int kLevelMin = 1, kLevelMax = 4;
static const uint32_t kMaxLines = 2880, kMaxWidth = 3840;
static_assert(kMaxLines <= 2 * 1440, "the engine's per-line tables hold 2 x 1440 entries");

inline uint32_t even_u(double v) { uint32_t n = (uint32_t)(v + 0.5); return n & ~1u; }

// Level 1: the monitor's own resolution (the probe changes nothing).
// Level 2: 2160 lines, monitor shape (3840 x 2160 on a 16:9 monitor).
// Level 3: 2880 lines, monitor shape but at most 3840 wide (3840 x 2880).
// Level 4: 2880 x 2880, headset shape (test).
// Returns 1 and the size, or 0 when the level leaves the game alone.
inline int level_size(int level, uint32_t deskW, uint32_t deskH, uint32_t* w, uint32_t* h) {
  if (level <= 1 || level > kLevelMax || deskW < 640 || deskH < 480) return 0;
  double aspect = (double)deskW / (double)deskH;
  if (aspect < 1.0 || aspect > 4.0) return 0;  // portrait or absurd: leave it alone
  uint32_t lines = level == 2 ? 2160u : kMaxLines;
  double width = level == 4 ? (double)lines : (double)lines * aspect;
  if (width > kMaxWidth) width = kMaxWidth;
  *w = even_u(width);
  *h = lines;
  if (*w < 640 || *h < 480 || *w > kMaxWidth || *h > kMaxLines) return 0;
  return 1;
}

// 1.7.117 explicit size by lines (picture_lines in the settings, the VR menu's Resolution row): 720..2880 lines at the monitor's shape (width at most 3840).
// For laptops and weaker cards that cannot draw 2160 lines. Returns 1 and the size, or 0 when the desktop shape is unusable.
static const uint32_t kMinLines = 720;
inline int lines_size(uint32_t lines, uint32_t deskW, uint32_t deskH, uint32_t* w, uint32_t* h) {
  if (lines < kMinLines || lines > kMaxLines || deskW < 640 || deskH < 480) return 0;
  double aspect = (double)deskW / (double)deskH;
  if (aspect < 1.0 || aspect > 4.0) return 0;
  double width = (double)lines * aspect;
  if (width > kMaxWidth) width = kMaxWidth;
  *w = even_u(width);
  *h = lines & ~1u;
  if (*w < 640 || *h < 480) return 0;
  return 1;
}
// The menu's ladder of sizes (lines), smallest first. 2160 and 2880 are the old levels 2 and 3.
static const uint32_t kLadder[5] = {1080, 1440, 1800, 2160, 2880};
// Next ladder entry above / below `lines` (stays put at the ends).
inline uint32_t ladder_step(uint32_t lines, int dir) {
  if (dir > 0) { for (int i = 0; i < 5; ++i) if (kLadder[i] > lines) return kLadder[i]; return kLadder[4]; }
  for (int i = 4; i >= 0; --i) if (kLadder[i] < lines) return kLadder[i];
  return lines < kLadder[0] ? lines : kLadder[0];
}

// What the settings become for a chosen ladder size: 2160 / 2880 are the old levels 2 / 3 (picture_lines 0), anything else is picture_lines with level 2.
inline void ladder_apply(uint32_t lines, long* picLines, long* picLevel) {
  if (lines == 2160) { *picLines = 0; *picLevel = 2; }
  else if (lines == 2880) { *picLines = 0; *picLevel = 3; }
  else { *picLines = (long)lines; *picLevel = 2; }
}

// Mouse: the game takes the pointer position in window pixels and uses it as
// a position in its picture (pointer sprite, menu hit tests). When the picture
// is bigger than the window the position has to be scaled (mouse.cpp).
// from/to are the two sizes along one axis; a position inside [0, from) lands
// inside [0, to).
inline int scale_coord(int v, int from, int to) {
  if (from <= 0 || to <= 0) return v;
  int64_t r = (int64_t)v * to;
  return (int)(r >= 0 ? r / from : -((-r) / from));
}

// The other direction (picture pixels -> window pixels, used when the game
// moves the pointer itself) rounds up, so that a window position that went
// through scale_coord comes back as exactly the same window position.
inline int scale_coord_back(int v, int from, int to) {
  if (from <= 0 || to <= 0) return v;
  int64_t r = (int64_t)v * to;
  return (int)(r >= 0 ? (r + from - 1) / from : -((-r) / from));
}

inline const char* level_name(int level) {
  switch (level) {
    case 2: return "sharp (2160 lines)";
    case 3: return "sharper (2880 lines, at most 3840 wide)";
    case 4: return "headset-shaped test (2880 x 2880)";
    default: return "normal (monitor resolution)";
  }
}

// Flat screen in the headset: 3 m wide for a 16:9 picture, never taller than
// maxHeightM (a square picture would otherwise be 3 m tall).
inline float flat_screen_width(uint32_t texW, uint32_t texH, float wideM, float maxHeightM) {
  if (!texW || !texH) return wideM;
  float aspect = (float)texW / (float)texH;
  float w = wideM;
  if (w / aspect > maxHeightM) w = maxHeightM * aspect;
  return w;
}

// ---- 0.45 flat view ------------------------------------------------------------------
// With the bigger picture of level 3 (at most 3840 wide, so 3840 x 2880 = 4:3) the game's picture has another
// shape than the monitor / window (16:9), and Windows stretches it to fill the window: everything looks wide.
// The flat view (flatview.cpp) draws the picture back into the swap chain with the right proportions before
// Present (black bars left and right); this is where the picture then appears inside the window's client area.
struct View { double x, y, w, h; int active; };   // client pixels; active = 0: the picture fills the window as it is

// Largest rectangle of the picture's shape that fits the client area, centred. Returns 1 (active) when the two
// shapes differ by more than 1 %.
inline int fit_view(int pw, int ph, int cw, int ch, View* v) {
  v->x = 0; v->y = 0; v->w = cw; v->h = ch; v->active = 0;
  if (pw < 64 || ph < 64 || cw < 64 || ch < 64 || pw > 65536 || ph > 65536 || cw > 65536 || ch > 65536) return 0;
  double pa = (double)pw / (double)ph, ca = (double)cw / (double)ch;
  if (pa > ca * 0.99 && pa < ca * 1.01) return 0;
  double s = ca > pa ? (double)ch / (double)ph : (double)cw / (double)pw;
  v->w = (double)pw * s; v->h = (double)ph * s;
  v->x = ((double)cw - v->w) / 2.0; v->y = ((double)ch - v->h) / 2.0;
  v->active = 1;
  return 1;
}

// One axis: client pixel -> picture pixel (inside the black bars it lands on the picture's edge) and back.
inline int view_to_picture(int c, double off, double len, int plen) {
  if (!(len > 0.5) || plen <= 0) return c;
  double p = ((double)c - off) * (double)plen / len;
  if (p < 0) p = 0;
  if (p > plen - 1) p = plen - 1;
  return (int)p;
}
inline int picture_to_view(int p, double off, double len, int plen) {
  if (!(len > 0.5) || plen <= 0) return p;
  double c = off + (double)p * len / (double)plen;
  int i = (int)c;
  return (double)i < c ? i + 1 : i;   // rounds up, like scale_coord_back
}

}  // namespace picture
