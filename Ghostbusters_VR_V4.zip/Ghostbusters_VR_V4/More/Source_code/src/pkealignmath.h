// 1.7.104 PKE alignment. Pure math, no Windows dependency; unit-tested in tests/test_pkealign.cpp.
//
// With the PKE out, the right hand turns with the controller by a fixed relation K0 (hand frame <-> controller frame) that was captured from the pose the
// arm solve happened to have at that moment. The PKE sits in the hand by the game's own hold, so the PKE's angle to the controller was whatever that
// capture gave: the 1.7.103 report said the meter "is pulled to the right of the controller".
//
// What is done here: the PKE's long axis is turned (the smallest turn there is, about the hand) until it lies in the controller's centre plane (forward /
// up), so it no longer leans or points to the side; its roll about its own axis and its pitch in that plane are kept as they were. Then the meter's
// centre is checked sideways against the controller: what is left of a sideways offset is returned so the arm code can move the hand by that much.
//
// Frames: K is a row-major 3x3 that maps coordinates in the HAND's own axes (the bone matrix rows, as handprop / armcore use them) to the CONTROLLER's
// axes (forward, up, left; left = forward x up, the third column of the controller frame the arm code builds).
#pragma once
#include "weightmath.h"

namespace pkealign {

struct Result {
  int ok;                         // 1 = a turn was computed (or none was needed); 0 = the data did not allow it, K = K0
  double leanBeforeDeg, leanAfterDeg;   // the long axis's sideways angle to the controller's centre plane (+ = left), degrees
  double pitchDeg;                // the long axis's angle above the controller's forward, inside the centre plane (unchanged by the turn)
  double swingDeg;                // how far the hand was turned
  double latBeforeFt, latAfterFt; // the meter centre's sideways offset to the controller (+ = left), feet, before / after the turn
  double fwdFt, upFt;             // the meter centre's forward / up offset to the controller after the turn (feet), for the log
  double pitchAfterDeg;           // 1.7.111: the long axis's angle above the controller's forward after the pitch step (= pitchDeg if no pitch step was asked)
  double shiftFwdFt, shiftUpFt;   // 1.7.111: how far the hand moves forward / up so the meter's centre stays where it was while the pitch turns it (feet)
};

inline void mulv(const double* M, const double* v, double* o) {
  for (int r = 0; r < 3; ++r) o[r] = M[r * 3] * v[0] + M[r * 3 + 1] * v[1] + M[r * 3 + 2] * v[2];
}

// K0: the captured relation. vh: the PKE's long axis in the hand's own axes (unit). ph: the PKE's centre in the hand's own axes (feet, world scale).
// maxSwingDeg: turns bigger than this are not made (the axis is probably not the long one). K receives the result (9 values).
inline Result solve_ex(const double* K0, const double* vh, const double* ph, double maxSwingDeg, double targetPitchDeg, double* K, double maxPitchTurnDeg = 1.0e9);
// the pitch step: K (already in the centre plane) is turned about the controller's sideways axis so the long axis lies targetPitchDeg above forward.
// the hand moves by (centre before the pitch turn - centre after it) forward / up so the centre stays where the lean turn left it; sideways stays with latAfterFt.
inline void pitch_step(double* K, const double* vh, const double* ph, double targetPitchDeg, const double* p00, Result* r, double maxPitchTurnDeg = 1.0e9) {
  double c2[3], p1[3];
  mulv(K, vh, c2);
  mulv(K, ph, p1);
  r->latAfterFt = p1[2]; r->fwdFt = p1[0]; r->upFt = p1[1];
  const double pb[3] = {p1[0], p1[1], p1[2]};
  if (!(targetPitchDeg < 900.0)) return;
  const double kDeg = 180.0 / vm::kPi;
  const double cur = vm::datan2(c2[1], c2[0]) * kDeg;
  double d = targetPitchDeg - cur;
  while (d > 180.0) d -= 360.0;
  while (d < -180.0) d += 360.0;
  if (vm::dabs(d) > 100.0 || vm::dabs(d) < 0.05) return;
  // 1.7.224: the hand is turned by at most maxPitchTurnDeg for this step (the report: the meter sat 57 deg above the controller's forward, the pitch step turned the hand 57 deg, so the glove looked bent and locked);
  // the meter then keeps the rest of its lean above the controller's forward, like a phone tilted toward you
  if (maxPitchTurnDeg < 180.0) { if (d > maxPitchTurnDeg) d = maxPitchTurnDeg; if (d < -maxPitchTurnDeg) d = -maxPitchTurnDeg; }   // upright native holds can need nearly 90 degrees; keep the reverse-axis guard
  double s, c; vm::dsincos(d * vm::kPi / 180.0, &s, &c);
  const double R[9] = {c, -s, 0.0, s, c, 0.0, 0.0, 0.0, 1.0};   // about the sideways axis: x (forward) toward y (up) by d
  double K2[9];
  weight::mul3(R, K, K2);
  for (int i = 0; i < 9; ++i) K[i] = K2[i];
  mulv(K, vh, c2);
  mulv(K, ph, p1);
  r->pitchAfterDeg = vm::datan2(c2[1], c2[0]) * kDeg;
  r->latAfterFt = p1[2]; r->fwdFt = p1[0]; r->upFt = p1[1];
  r->shiftFwdFt = pb[0] - p1[0]; r->shiftUpFt = pb[1] - p1[1];
  r->swingDeg += vm::dabs(d);
}
inline Result solve(const double* K0, const double* vh, const double* ph, double maxSwingDeg, double* K) {
  return solve_ex(K0, vh, ph, maxSwingDeg, 1.0e9, K);
}
// 1.7.111: targetPitchDeg < 900 also turns the long axis, inside the centre plane, to that angle above the controller's forward (0 = straight along it),
// about the controller's sideways axis; shiftFwdFt / shiftUpFt say how far the hand must move so the meter's centre stays put.
inline Result solve_ex(const double* K0, const double* vh, const double* ph, double maxSwingDeg, double targetPitchDeg, double* K, double maxPitchTurnDeg) {
  Result r;
  r.pitchAfterDeg = 0.0; r.shiftFwdFt = r.shiftUpFt = 0.0;
  r.ok = 0; r.leanBeforeDeg = r.leanAfterDeg = r.pitchDeg = r.swingDeg = 0.0; r.latBeforeFt = r.latAfterFt = r.fwdFt = r.upFt = 0.0;
  for (int i = 0; i < 9; ++i) K[i] = K0[i];
  double cf[3], p0[3];
  mulv(K0, vh, cf);
  mulv(K0, ph, p0);
  r.latBeforeFt = r.latAfterFt = p0[2]; r.fwdFt = p0[0]; r.upFt = p0[1];
  double n = vm::dsqrt(cf[0] * cf[0] + cf[1] * cf[1] + cf[2] * cf[2]);
  if (!(n > 0.5 && n < 1.5)) return r;
  for (int i = 0; i < 3; ++i) cf[i] /= n;
  const double kDeg = 180.0 / vm::kPi;
  double lean = cf[2]; if (lean > 1.0) lean = 1.0; if (lean < -1.0) lean = -1.0;
  r.leanBeforeDeg = r.leanAfterDeg = vm::dasin(lean) * kDeg;
  const double planar = vm::dsqrt(cf[0] * cf[0] + cf[1] * cf[1]);
  r.pitchDeg = vm::datan2(cf[1], cf[0]) * kDeg;
  r.pitchAfterDeg = r.pitchDeg;
  if (!(planar > 0.3)) return r;               // the axis lies almost across the controller: not the long axis, leave it
  r.ok = 1;
  const double p00[3] = {p0[0], p0[1], p0[2]};
  if (vm::dabs(r.leanBeforeDeg) < 0.25) {      // already in the centre plane: only the pitch step may be left
    for (int i = 0; i < 9; ++i) K[i] = K0[i];
    pitch_step(K, vh, ph, targetPitchDeg, p00, &r, maxPitchTurnDeg);
    return r;
  }
  const double pf[3] = {cf[0] / planar, cf[1] / planar, 0.0};
  double ax[3] = {cf[1] * pf[2] - cf[2] * pf[1], cf[2] * pf[0] - cf[0] * pf[2], cf[0] * pf[1] - cf[1] * pf[0]};
  const double sn = vm::dsqrt(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]);
  const double cs = cf[0] * pf[0] + cf[1] * pf[1] + cf[2] * pf[2];
  if (!(sn > 1e-9)) return r;
  const double ang = vm::datan2(sn, cs);
  if (ang * kDeg > maxSwingDeg) { r.ok = 0; return r; }
  for (int i = 0; i < 3; ++i) ax[i] /= sn;
  double S[9];
  weight::axis_angle(ax, ang, S);
  weight::mul3(S, K0, K);
  r.swingDeg = ang * kDeg;
  double c2[3], p1[3];
  mulv(K, vh, c2);
  mulv(K, ph, p1);
  double l2 = c2[2]; if (l2 > 1.0) l2 = 1.0; if (l2 < -1.0) l2 = -1.0;
  r.leanAfterDeg = vm::dasin(l2) * kDeg;
  r.latAfterFt = p1[2]; r.fwdFt = p1[0]; r.upFt = p1[1];
  r.pitchAfterDeg = vm::datan2(c2[1], c2[0]) * kDeg;
  pitch_step(K, vh, ph, targetPitchDeg, p00, &r, maxPitchTurnDeg);
  return r;
}

}  // namespace pkealign
