// 1.7.71 the PKE is moved where it is DRAWN (pure math, tested in tests/test_pkedraw.cpp).
//
// The 1.7.69 and 1.7.70 videos showed the meter drawn at the game's own scan pose (40-60 cm in front of the fist, fixed in front
// of the view) while every field the probe wrote said "in the hand". The gun has never had that problem because it is moved at
// the moment it is drawn: the render pass multiplies the gun's world matrix with the view (matrix product 0x17210) and the probe
// hands the product the in-hand matrix instead. 1.7.71 does the same for the PKE: a world matrix that goes into that product
// and IS the game's own PKE pose (same place within 4 cm, same axes) is replaced by the in-hand pose. A matrix of a part of the
// meter (same caller, within 2.5 ft) is carried with it: part x inverse(game pose) x in-hand pose.
// Matrices are the game's row-vector affine layout (translation at 12..14), as in handprop.h.
#pragma once
#include "handprop.h"

namespace pkedraw {

// 1 = the matrix is the game's own pose of the meter (position within posTolFt, each axis direction within axTol of 1-dot,
// each axis length within 5 %)
inline int is_game_pose(const float* a, const float* gameM, double posTolFt, double axTol) {
  if (!handprop::finite16(a) || !handprop::finite16(gameM)) return 0;
  if (handprop::rel_pos_delta(a, gameM) > posTolFt) return 0;
  for (int r = 0; r < 3; ++r) {
    const double la = handprop::row_len(a, r), lg = handprop::row_len(gameM, r);
    if (!(lg > 1e-6) || vm::dabs(la / lg - 1.0) > 0.05) return 0;
  }
  return handprop::rel_axis_delta(a, gameM) <= axTol;
}

// part of the meter: carried from the game's pose to the in-hand pose
inline int carry(const float* a, const float* gameM, const float* handM, float* out) {
  return handprop::map_part(a, gameM, handM, out);
}

// per caller (return address) census: which call site draws the meter
struct Site { uintptr_t rva; long exact, parts, nearN; double minFt; };
const int kSites = 16;
struct Census {
  Site s[kSites];
  int n;
  long full;
};
inline Site* site(Census& c, uintptr_t rva) {
  for (int i = 0; i < c.n; ++i) if (c.s[i].rva == rva) return &c.s[i];
  if (c.n >= kSites) { ++c.full; return nullptr; }
  Site& s = c.s[c.n++];
  s.rva = rva; s.exact = 0; s.parts = 0; s.nearN = 0; s.minFt = 1e9;
  return &s;
}
// a call site counts as "the PKE's draw" after this many exact matches
const long kLearn = 12;
inline int learned(const Site* s) { return s && s->exact >= kLearn; }

}  // namespace pkedraw
