// 1.4 forgiving PKE scan: the decisions, without the game (tests/test_pkeeasy.cpp).
//
// The game's own rules (read from its code, layout.h): a scan runs only while the PKE is equipped, a target is locked, the cooldown is over, the target is visible,
// the target is within 15 ft (squared ground distance <= 225) and the cosine of the angle between where the PKE points and the target is above cos 18 deg = 0.951.
// 1.4 widens the two limits (range and cone), and can start the scan by itself when the PKE points at something scannable, so nobody has to hold a trigger while aiming a hand-held device.
#pragma once
#include "vmath.h"

namespace pkeasy {

static const double kPi = 3.14159265358979323846;
static const double kGameFt = 15.0, kGameConeDeg = 18.0;

struct Cfg {
  int easy;          // pke_easy
  int autoScan;      // pke_auto
  double rangeFt;    // pke_easy_ft
  double coneDeg;    // pke_cone_deg
};

struct Rec {         // what the game's record says (this frame)
  int hasTarget;     // a target actor is locked
  int visible;       // the game's own flag at +0x4FC (clear line)
  double dist2;      // ground distance squared (game units, feet)
  double align;      // cosine of the angle off the PKE's line
  double cooldown;   // seconds left (<= 0 = ready)
  int equipped;      // state at +0x53C
};

inline double cone_cos(double deg) {
  if (deg < 1.0) deg = 1.0;
  if (deg > 80.0) deg = 80.0;
  double s, c;
  vm::dsincos(deg * kPi / 180.0, &s, &c);
  return c;
}
inline double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Scan assistance must not reject the game's own aim at an offset scan point.
inline float assisted_alignment(float native, float tracked) {
  if (!vm::is_finite_f(tracked)) return native;
  if (!vm::is_finite_f(native)) return tracked;
  return native > tracked ? native : tracked;
}

// Use one origin and direction for the hand-held meter's locked-target angle.
// At close range a translation between the animation and tracked grip causes
// large errors; no minimum scan distance is added here.
inline int controller_alignment(const float* origin, const float* forward, const float* target, float* alignment) {
  double v[3], f2 = 0, v2 = 0, dot = 0;
  for (int i = 0; i < 3; ++i) {
    if (!vm::is_finite_f(origin[i]) || !vm::is_finite_f(forward[i]) || !vm::is_finite_f(target[i])) return 0;
    v[i] = (double)target[i] - origin[i];
    v2 += v[i] * v[i]; f2 += (double)forward[i] * forward[i]; dot += v[i] * forward[i];
  }
  if (!(v2 > 1e-8) || !(f2 > 0.25 && f2 < 2.25)) return 0;
  *alignment = (float)clampd(dot / vm::dsqrt(v2 * f2), -1.0, 1.0);
  return 1;
}

// Close targets under the headset reticle are difficult to line up from the
// offset hand. Accept the looked-at target only while it is also in front of
// the meter; the game's locked-target/line-of-sight checks still apply.
inline float close_alignment(float handCos, float gazeCos, double distanceFt, int enabled) {
  return enabled && distanceFt > 0.0 && distanceFt <= 8.0 && handCos >= 0.0f && gazeCos >= 0.9781476f
    ? (gazeCos > handCos ? gazeCos : handCos) : handCos;
}

// the cone the game should use (its global threshold): the game's own 18 degrees when the easy scan is off
inline double game_cone_deg(const Cfg& c) { return c.easy ? clampd(c.coneDeg, kGameConeDeg, 70.0) : kGameConeDeg; }
// the range the game should use for a scan
inline double game_range_ft(const Cfg& c) { return c.easy ? clampd(c.rangeFt, kGameFt, 80.0) : kGameFt; }

// is this record inside the widened limits? (the game's other conditions stay the game's)
inline int in_window(const Rec& r, const Cfg& c) {
  if (!r.hasTarget) return 0;
  const double R = game_range_ft(c);
  return r.dist2 <= R * R && r.align >= cone_cos(game_cone_deg(c)) ? 1 : 0;
}

// should the scan start by itself? Starting is a little stricter than keeping (3/4 of the cone, 90 % of the range) so it does not hunt at the edge;
// once it runs, the game's own cancel rules and the widened limits keep it going
inline int want_input(const Rec& r, const Cfg& c, int scanning) {
  if (!c.easy || !c.autoScan || !r.equipped || !r.hasTarget || !r.visible || r.cooldown > 0.0) return 0;
  const double R = game_range_ft(c);
  if (scanning) return in_window(r, c);
  const double startCone = clampd(game_cone_deg(c) * 0.75, kGameConeDeg, 70.0);
  const double startR = R * 0.9;
  return r.dist2 <= startR * startR && r.align >= cone_cos(startCone) ? 1 : 0;
}

// angle off the line, degrees, from the cosine
inline double align_deg(double a) {
  a = clampd(a, -1.0, 1.0);
  const double s = vm::dsqrt(1.0 - a * a);
  return vm::datan2(s, a) * 180.0 / kPi;
}

// rumble while a scan runs / a ghost is in the window; level 0..1, 0 = none
inline double scan_rumble(int scanning, double bar, int inWindow) {
  if (scanning) return 0.14 + 0.30 * clampd(bar, 0.0, 1.0);
  return inWindow ? 0.05 : 0.0;
}

// ---- 1.6 -----------------------------------------------------------------------------------------------------------------------------------------------------------------
// The 1.5 log: the widened window was often "in", yet no scan finished. Reading the game's code (layout.h, 1.6 block) showed why: the scan "ping" (once per 2 s while the button is held and
// scan_ok is true) adds `rate` to the target's progress, and the rate is 0.0 when the meter is not lined up well enough (level -1) - the ping still burns the 2 s cooldown. 1.6 puts a floor under it.
static const double kPingFloor = 0.5;   // two pings (about 4 s) finish a scan at the very least

inline double ping_rate(double gameRate, int help) {
  if (!help) return gameRate;
  return gameRate < kPingFloor ? kPingFloor : gameRate;
}
// the rate the game's level table gives (level 0/1/2/-1), for the log
inline double level_rate(int level) { return level == 0 ? 1.0 : (level == 1 ? 0.5 : (level == 2 ? 0.25 : 0.0)); }
inline int rate_level(double rate) { return rate >= 0.99 ? 0 : (rate >= 0.49 ? 1 : (rate >= 0.24 ? 2 : -1)); }

// why scan_ok says no, in the order the game asks (the first failing one is the reason); 0 = it would say yes
enum Why { kWhyOk = 0, kWhyNotEquipped, kWhyOwnerBusy, kWhyNoTarget, kWhyCooldown, kWhyNotScannable, kWhyBlocked, kWhyNoLine, kWhyRange, kWhyCone, kWhyCount };
struct WhyIn {
  int equipped, ownerState, hasTarget;
  double cooldown;
  int scannable, blocked, visible;
  double dist2, range2;     // squared ground distance; the squared range in force (the record's, or the widened one)
  double align, coneCos;    // cosine of the angle off the line; the cone in force
};
inline int why_not(const WhyIn& w) {
  if (!w.equipped) return kWhyNotEquipped;
  if (w.ownerState != 0) return kWhyOwnerBusy;
  if (!w.hasTarget) return kWhyNoTarget;
  if (w.cooldown > 0.0) return kWhyCooldown;
  if (!w.scannable) return kWhyNotScannable;
  if (w.blocked) return kWhyBlocked;
  if (!w.visible) return kWhyNoLine;
  if (!(w.dist2 <= w.range2)) return kWhyRange;
  if (!(w.align > w.coneCos)) return kWhyCone;
  return kWhyOk;
}
inline const char* why_name(int w) {
  static const char* const n[kWhyCount] = {"would scan", "PKE not equipped", "player busy (state not 0)", "no target locked", "cooldown running", "target not scannable", "target blocked", "no clear line", "too far", "too far off the line"};
  return (w >= 0 && w < kWhyCount) ? n[w] : "?";
}

// ---- 1.7.83 close range ---------------------------------------------------------------------------------------------------------------------------------------------------
// The YouTuber's video (8:19, 9:16, 9:35): the meter held right next to a thing on the floor or a wall splat, the ring on it, and the scan does nothing. The game measures the angle between the
// meter's own line and the thing. A hand-held meter sits about 2 ft beside / below where you look, so at arm's length that angle is big (45-60 degrees) even when you look straight at the
// thing, and the 30 degree cone misses it; the farther away, the less this matters. So the cone grows as the nearest scannable thing gets close to the meter: atan(slack / distance).
static const double kCloseSlackFt = 2.0;    // how far beside the line a thing may be when it is right at the meter (about 60 cm)
static const double kCloseMaxDeg = 70.0;    // never wider than the setting's own limit

inline double close_cone_deg(double distFt, double slackFt) {
  if (distFt != distFt || slackFt != slackFt) return 0.0;              // NaN: no help
  if (distFt <= 0.0) return kCloseMaxDeg;
  const double a = vm::datan2(slackFt, distFt) * 180.0 / kPi;
  return a > kCloseMaxDeg ? kCloseMaxDeg : (a < 0.0 ? 0.0 : a);
}
// the cone to give the game now: the setting's (or the game's own when the easy scan is off), made wider when the nearest scannable thing is close to the meter
inline double effective_cone_deg(const Cfg& c, double nearestFt, int closeHelp) {
  const double base = game_cone_deg(c);
  if (!c.easy || !closeHelp || !(nearestFt < 1.0e6)) return base;
  const double cl = close_cone_deg(nearestFt, kCloseSlackFt);
  return cl > base ? cl : base;
}

}  // namespace pkeasy
