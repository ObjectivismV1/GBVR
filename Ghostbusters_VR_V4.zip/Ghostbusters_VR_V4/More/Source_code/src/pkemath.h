// 0.94 the game's own PKE meter at the controller. Pure math, no Windows dependency; unit-tested in tests/test_pke.cpp.
//
// The game keeps the PKE's world rotation as three local axes (unit vectors in game world) and writes them every frame so that the model's front points along the
// player's aim, with the roll of a level hold (its up is the world's up) - see layout.h. This turns that pose onto the controller:
//   1. the pointing axis is found once (the local axis that agrees most with the aim, when it clearly does) and kept,
//   2. the whole pose is swung so that axis points exactly along the controller direction,
//   3. the roll is carried over from the controller (the angle between a level up and the controller's up, seen along the pointing direction),
//   4. an optional tilt tips the front down about the hand.
// Rotations are rigid turns of the three axes, so lengths (a model scale) and handedness stay what the game wrote.
#pragma once
#include "vmath.h"

namespace pke {

inline double dot(const double* a, const double* b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
inline void cross(const double* a, const double* b, double* o) { o[0] = a[1] * b[2] - a[2] * b[1]; o[1] = a[2] * b[0] - a[0] * b[2]; o[2] = a[0] * b[1] - a[1] * b[0]; }
inline double len(const double* a) { return vm::dsqrt(dot(a, a)); }
inline int unit(double* a) { const double l = len(a); if (!(l > 1e-9)) return 0; a[0] /= l; a[1] /= l; a[2] /= l; return 1; }
// Rodrigues: v turned about the unit axis k by angle a (radians)
inline void rot(const double* k, double a, double* v) {
  double s, c; vm::dsincos(a, &s, &c);
  double kx[3]; cross(k, v, kx);
  const double kd = dot(k, v) * (1.0 - c);
  for (int i = 0; i < 3; ++i) v[i] = v[i] * c + kx[i] * s + k[i] * kd;
}

struct Axis { int axis, sign, have; };   // which local axis points forward (sign -1 = the reversed axis); have = found
struct Info { double dots[3]; double swingDeg, rollDeg; int found, rolled; };

// u: the three local axes in world (unit, rows of the model matrix); turned in place.
// dir: unit controller direction. wup: the controller's up (any length; null / zero = unknown). rollOff: extra roll (radians). tiltRad: front down (radians).
// upOut (optional): the pose's "up" after roll and tilt (unit, across the pointing direction). Returns 1 on success.
inline int orient(double u[3][3], const double* dirIn, const double* wup, double rollOff, double tiltRad, Axis* ax, Info* info, double* upOut) {
  double dir[3] = {dirIn[0], dirIn[1], dirIn[2]};
  if (!unit(dir)) return 0;
  Info local; Info* I = info ? info : &local;
  I->swingDeg = I->rollDeg = 0.0; I->found = 0; I->rolled = 0;
  for (int j = 0; j < 3; ++j) I->dots[j] = dot(u[j], dir);
  // the model's front is found once, from a pose that clearly points along the aim (|dot| >= 0.9), and then kept for good; until then local +Z (row 2, the game's forward) is assumed
  if (!ax->have) {
    int best = 0;
    for (int j = 1; j < 3; ++j) if (vm::dabs(I->dots[j]) > vm::dabs(I->dots[best])) best = j;
    if (vm::dabs(I->dots[best]) >= 0.9) { ax->axis = best; ax->sign = I->dots[best] < 0 ? -1 : 1; ax->have = 1; I->found = 1; }
    else { ax->axis = 2; ax->sign = 1; }
  }
  double fwd[3] = {u[ax->axis][0] * ax->sign, u[ax->axis][1] * ax->sign, u[ax->axis][2] * ax->sign};
  double c = dot(fwd, dir);
  if (c > 1.0) c = 1.0;
  if (c < -1.0) c = -1.0;
  if (c < 0.999999) {
    double k[3]; cross(fwd, dir, k);
    const double kl = len(k);
    const double ang = vm::datan2(kl, c);
    if (kl < 1e-6) { const double* o = u[(ax->axis + 1) % 3]; k[0] = o[0]; k[1] = o[1]; k[2] = o[2]; }
    else { k[0] /= kl; k[1] /= kl; k[2] /= kl; }
    for (int j = 0; j < 3; ++j) rot(k, ang, u[j]);
    I->swingDeg = ang * 180.0 / vm::kPi;
  }
  // the game's pose is level: its up is the world up across the pointing direction
  double ref[3] = {0.0, 1.0, 0.0};
  const double rd = dot(ref, dir);
  for (int i = 0; i < 3; ++i) ref[i] -= rd * dir[i];
  const int refOk = vm::dabs(rd) < 0.985 && unit(ref);   // pointing nearly straight up / down: no roll reference
  double up[3] = {0, 1, 0};
  if (refOk) { up[0] = ref[0]; up[1] = ref[1]; up[2] = ref[2]; }
  else { const double d = dot(up, dir); for (int i = 0; i < 3; ++i) up[i] -= d * dir[i]; if (!unit(up)) { up[0] = 1; up[1] = 0; up[2] = 0; } }
  double wv[3] = {0, 0, 0};
  int wOk = 0;
  if (wup) { wv[0] = wup[0]; wv[1] = wup[1]; wv[2] = wup[2]; const double wd = dot(wv, dir); for (int i = 0; i < 3; ++i) wv[i] -= wd * dir[i]; wOk = unit(wv); }
  if (refOk && wOk) {
    double cr[3]; cross(ref, wv, cr);
    const double roll = vm::datan2(dot(dir, cr), dot(ref, wv)) + rollOff;
    for (int j = 0; j < 3; ++j) rot(dir, roll, u[j]);
    rot(dir, roll, up);
    I->rollDeg = roll * 180.0 / vm::kPi; I->rolled = 1;
  } else if (refOk && rollOff != 0.0) {
    for (int j = 0; j < 3; ++j) rot(dir, rollOff, u[j]);
    rot(dir, rollOff, up);
  }
  if (tiltRad != 0.0) {
    double k[3]; cross(up, dir, k);
    if (unit(k)) { for (int j = 0; j < 3; ++j) rot(k, tiltRad, u[j]); rot(k, tiltRad, up); }
  }
  if (upOut) { upOut[0] = up[0]; upOut[1] = up[1]; upOut[2] = up[2]; }
  return 1;
}

// ---- 0.97 look-at: the front and the up of the model are both set from the controller ----------------------------------------------------------
// 0.94-0.96 swung the pose by the smallest turn and only guessed the front axis (it fell back to local +Z; the PKE's front is local +Y - its tip attachment
// is at (0, 1.07, 0.03) in the model's own axes - so the PKE was held 90 degrees off, pointing up). This builds the pose directly:
//   - the front axis (found from the model's tip attachment, default local +Y) is set to the controller direction,
//   - the up axis (the local axis that points up in the game's level hold, found once) is set to the controller's up (rolled / tilted like the controller),
//   - the third axis completes the frame with the handedness the game's matrix had (a mirrored model stays mirrored).
struct Frame { int front, fsign, up, usign, have; double prevUp[3]; int prevOk; };
struct LookInfo { double dotsUp[3], dotsDir[3]; double swingDeg, rollDeg; int rolled, upFound; };

inline double det3(const double u[3][3]) { double c[3]; cross(u[1], u[2], c); return dot(u[0], c); }

// u: the three local axes in world (unit, rows), turned in place. dir: the controller direction. wup: the controller's up (null / zero = keep the pose level).
// rollOff: extra roll (radians). tiltRad: front down (radians). upOut (optional): the pose's up after roll and tilt. Returns 1 on success.
inline int look(double u[3][3], const double* dirIn, const double* wup, double rollOff, double tiltRad, Frame* fr, LookInfo* info, double* upOut) {
  double dir[3] = {dirIn[0], dirIn[1], dirIn[2]};
  if (!unit(dir)) return 0;
  LookInfo local; LookInfo* I = info ? info : &local;
  I->swingDeg = I->rollDeg = 0.0; I->rolled = 0; I->upFound = 0;
  const double W[3] = {0.0, 1.0, 0.0};
  for (int j = 0; j < 3; ++j) { I->dotsUp[j] = dot(u[j], W); I->dotsDir[j] = dot(u[j], dir); }
  if (fr->front < 0 || fr->front > 2 || (fr->fsign != 1 && fr->fsign != -1)) { fr->front = 1; fr->fsign = 1; fr->have = 0; }
  if (fr->up == fr->front || fr->up < 0 || fr->up > 2) fr->have = 0;
  if (!fr->have) {   // the up axis: of the two others, the one that points up (or down) in the game's level hold; kept once the reading is clear
    const int a = (fr->front + 1) % 3, b = (fr->front + 2) % 3;
    const int best = vm::dabs(I->dotsUp[a]) >= vm::dabs(I->dotsUp[b]) ? a : b;
    fr->up = best; fr->usign = I->dotsUp[best] < 0.0 ? -1 : 1;
    if (vm::dabs(I->dotsUp[best]) >= 0.6) { fr->have = 1; I->upFound = 1; }
  }
  const double oldDet = det3(u);
  double oldFront[3] = {u[fr->front][0] * fr->fsign, u[fr->front][1] * fr->fsign, u[fr->front][2] * fr->fsign};
  { double c = dot(oldFront, dir); if (c > 1.0) c = 1.0; if (c < -1.0) c = -1.0; I->swingDeg = vm::datan2(vm::dsqrt(1.0 - c * c), c) * 180.0 / vm::kPi; }
  // the wanted up: the controller's up across the pointing direction; else the world's up (a level hold); else last frame's up
  double ref[3] = {0.0, 1.0, 0.0};
  { const double rd = dot(ref, dir); for (int i = 0; i < 3; ++i) ref[i] -= rd * dir[i]; }
  const int refOk = unit(ref);
  double wv[3] = {0, 0, 0}; int wOk = 0;
  if (wup) { wv[0] = wup[0]; wv[1] = wup[1]; wv[2] = wup[2]; const double wd = dot(wv, dir); for (int i = 0; i < 3; ++i) wv[i] -= wd * dir[i]; wOk = len(wv) > 0.2 && unit(wv); }
  double upN[3];
  if (wOk) { for (int i = 0; i < 3; ++i) upN[i] = wv[i]; I->rolled = 1; }
  else if (refOk && vm::dabs(dot(W, dir)) < 0.985) { for (int i = 0; i < 3; ++i) upN[i] = ref[i]; }
  else if (fr->prevOk) { for (int i = 0; i < 3; ++i) upN[i] = fr->prevUp[i]; const double d = dot(upN, dir); for (int i = 0; i < 3; ++i) upN[i] -= d * dir[i]; if (!unit(upN)) { upN[0] = 1; upN[1] = 0; upN[2] = 0; const double e = dot(upN, dir); for (int i = 0; i < 3; ++i) upN[i] -= e * dir[i]; unit(upN); } }
  else { upN[0] = 1; upN[1] = 0; upN[2] = 0; const double e = dot(upN, dir); for (int i = 0; i < 3; ++i) upN[i] -= e * dir[i]; if (!unit(upN)) { upN[0] = 0; upN[1] = 0; upN[2] = 1; const double f = dot(upN, dir); for (int i = 0; i < 3; ++i) upN[i] -= f * dir[i]; unit(upN); } }
  if (rollOff != 0.0) rot(dir, rollOff, upN);
  if (refOk) { double cr[3]; cross(ref, upN, cr); I->rollDeg = vm::datan2(dot(dir, cr), dot(ref, upN)) * 180.0 / vm::kPi; }
  if (tiltRad != 0.0) {   // the front goes down about the side axis
    double k[3]; cross(upN, dir, k);
    if (unit(k)) { rot(k, tiltRad, dir); rot(k, tiltRad, upN); }
  }
  // build the frame: u[front] = fsign * dir, u[up] = usign * upN, the third completes it with the old handedness
  const int s = 3 - fr->front - fr->up;
  for (int i = 0; i < 3; ++i) { u[fr->front][i] = dir[i] * fr->fsign; u[fr->up][i] = upN[i] * fr->usign; }
  double c3[3]; cross(u[fr->front], u[fr->up], c3);
  for (int i = 0; i < 3; ++i) u[s][i] = c3[i];
  if (oldDet * det3(u) < 0.0) for (int i = 0; i < 3; ++i) u[s][i] = -u[s][i];
  for (int i = 0; i < 3; ++i) { fr->prevUp[i] = upN[i]; }
  fr->prevOk = 1;
  if (upOut) { upOut[0] = upN[0]; upOut[1] = upN[1]; upOut[2] = upN[2]; }
  return 1;
}

// the rigid turn that takes the old frame onto the new one (3x3 row-major, applied to column vectors): R = sum_j new[j] (x) old[j]. Axes are unit.
inline void rigid(const double a[3][3], const double b[3][3], double* R) {
  for (int i = 0; i < 3; ++i) for (int k = 0; k < 3; ++k) R[i * 3 + k] = b[0][i] * a[0][k] + b[1][i] * a[1][k] + b[2][i] * a[2][k];
}

// 0.98 the slide that puts the PKE's handle in the avatar's hand. The 0.97 probe added the arm code's shift of the moment (a fresh value lives only 40 ms): when it was
// missing for a frame the meter jumped 12-22 cm (log: GRIPFIT mean 11.7 cm, max 21.6 cm) - "too far from the controller, very disorienting". Now
//   - a share of it is used (the setting: 100 % = all of it, 0 = the meter sits exactly on the controller's grip point),
//   - the last good value is held through short gaps (holdSec), then it fades to nothing,
//   - and the value used is eased in TIME (tau), so every call in the same instant (draw, scan, both eyes of a pair) gets the same place.
struct ShiftState { double cur[3], last[3]; double lastGoodAt, lastAt; int have, init; };
inline void shift_reset(ShiftState* s) { for (int i = 0; i < 3; ++i) s->cur[i] = s->last[i] = 0.0; s->lastGoodAt = s->lastAt = 0.0; s->have = s->init = 0; }
// fresh = the shift of this moment or null; now in seconds; returns the shift to add (3 values in out)
inline void shift_step(ShiftState* s, const double* fresh, double now, double share, double holdSec, double tauSec, double* out) {
  if (share < 0.0) share = 0.0; if (share > 1.0) share = 1.0;
  if (fresh) { for (int i = 0; i < 3; ++i) s->last[i] = fresh[i]; s->lastGoodAt = now; s->have = 1; }
  double tgt[3] = {0.0, 0.0, 0.0};
  if (s->have) {
    const double age = now - s->lastGoodAt;
    double w = 1.0;
    if (!fresh) { if (age > holdSec + 0.3) w = 0.0; else if (age > holdSec) w = 1.0 - (age - holdSec) / 0.3; }   // held, then faded out over 0.3 s
    for (int i = 0; i < 3; ++i) tgt[i] = s->last[i] * w * share;
  }
  if (!s->init) { for (int i = 0; i < 3; ++i) s->cur[i] = tgt[i]; s->init = 1; s->lastAt = now; }
  else {
    double dt = now - s->lastAt;
    if (dt < 0.0) dt = 0.0; if (dt > 0.25) dt = 0.25;
    const double k = tauSec > 0.0 ? dt / (tauSec + dt) : 1.0;
    for (int i = 0; i < 3; ++i) s->cur[i] += (tgt[i] - s->cur[i]) * k;
    s->lastAt = now;
  }
  for (int i = 0; i < 3; ++i) out[i] = s->cur[i];
}

// 1.6 the weapon is RIGID with the hand. The 1.5 log showed the game's own hand-to-weapon offset (what the arm code reports as the "handle in the hand" slide) is not steady: 3 to 21 cm,
// 15 cm from one frame to the next, and 0.98-1.5 used only half of it for the PKE (about 6 cm of daylight between the glove and the PKE's handle - "the PKE floats"). The offset is now
//   - measured in the weapon's OWN axes (so turning the wrist carries it along instantly instead of dragging it behind in the world),
//   - followed slowly (fast for the first second after the weapon comes out, then tau = 0.6 s), so the animation's wobble does not move the weapon under your hand,
//   - held through short gaps and faded out after a longer one,
//   - and used in full (share 1.0).
// axes: the weapon's three axes in the world (unit rows). fresh: the arm code's slide of this moment (world) or null.
// Calibrate once in device/model axes. Animation changes and missing samples
// must not move a held prop relative to the controller; callers may keep one lock per item so switching away/back preserves the fit.
struct GripLock { double local[3]; int have; };
inline void grip_step(GripLock* s, const double* fresh, const double axes[3][3], double share, double* out) {
  if (!s->have && fresh) {
    for (int j = 0; j < 3; ++j) s->local[j] = dot(fresh, axes[j]);
    s->have = 1;
  }
  if (share < 0) share = 0; if (share > 1) share = 1;
  for (int i = 0; i < 3; ++i)
    out[i] = s->have ? share * (s->local[0] * axes[0][i] + s->local[1] * axes[1][i] + s->local[2] * axes[2][i]) : 0;
}
struct RigidShift { double loc[3]; double lastFreshAt, startAt, lastAt; int have; long n; double devSum, devMax; };
inline void rigid_reset(RigidShift* s) { for (int i = 0; i < 3; ++i) s->loc[i] = 0.0; s->lastFreshAt = s->startAt = s->lastAt = 0.0; s->have = 0; }
inline void rigid_step(RigidShift* s, const double* fresh, const double axes[3][3], double now, double share, double holdSec, double tauFast, double tauSlow, double* out) {
  if (share < 0.0) share = 0.0;
  if (share > 1.0) share = 1.0;
  if (s->have && now - s->lastFreshAt > 2.0) s->have = 0;   // long gap: the next value starts a new hold
  double dt = now - s->lastAt;
  if (dt < 0.0) dt = 0.0;
  if (dt > 0.25) dt = 0.25;
  s->lastAt = now;
  if (fresh) {
    double l[3];
    for (int j = 0; j < 3; ++j) l[j] = dot(fresh, axes[j]);
    if (!s->have) { for (int j = 0; j < 3; ++j) s->loc[j] = l[j]; s->have = 1; s->startAt = now; }
    else {
      double d[3] = {l[0] - s->loc[0], l[1] - s->loc[1], l[2] - s->loc[2]};
      const double dv = len(d);
      s->devSum += dv; ++s->n; if (dv > s->devMax) s->devMax = dv;
      const double tau = (now - s->startAt < 1.0) ? tauFast : tauSlow;
      const double k = tau > 0.0 ? dt / (tau + dt) : 1.0;
      for (int j = 0; j < 3; ++j) s->loc[j] += d[j] * k;
    }
    s->lastFreshAt = now;
  }
  double w = 1.0;
  if (!s->have) w = 0.0;
  else if (!fresh) {
    const double age = now - s->lastFreshAt;
    if (age > holdSec + 0.3) w = 0.0; else if (age > holdSec) w = 1.0 - (age - holdSec) / 0.3;
  }
  for (int i = 0; i < 3; ++i) out[i] = share * w * (s->loc[0] * axes[0][i] + s->loc[1] * axes[1][i] + s->loc[2] * axes[2][i]);
}

}  // namespace pke
