// 1.7.170 / 1.7.172 the PKE's hold on the controller: the last in-hand pose kept RELATIVE TO THE CONTROLLER (position and turn), used when the game's
// hand pair is not ready, so the PKE stays in the hand instead of at the game's own spot. Pure math; tests/test_pkerel.cpp.
// M: 16 floats, rows 0..2 = the meter's axes (with its scale), M[12..14] = position (game world, feet). grip / dir / up: the controller in game world.
#pragma once
#include "vmath.h"
namespace pkerel {
struct Rel { int ok; float pos[3], ax[9]; };
inline int finite3(const float* a) { return vm::is_finite_f(a[0]) && vm::is_finite_f(a[1]) && vm::is_finite_f(a[2]); }
// rows of B: right, up, forward (orthonormal). 0 = the controller's directions are unusable (zero, not finite, up along forward)
inline int basis(const float* dirf, const float* wupf, double* B) {
  if (!dirf || !wupf || !finite3(dirf) || !finite3(wupf)) return 0;
  double f[3] = {dirf[0], dirf[1], dirf[2]}, u[3] = {wupf[0], wupf[1], wupf[2]};
  const double fl = vm::dsqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2]);
  if (!(fl > 1e-6)) return 0;
  for (int i = 0; i < 3; ++i) f[i] /= fl;
  const double ul0 = vm::dsqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]);
  if (!(ul0 > 1e-6)) return 0;
  for (int i = 0; i < 3; ++i) u[i] /= ul0;
  const double d = u[0] * f[0] + u[1] * f[1] + u[2] * f[2];
  for (int i = 0; i < 3; ++i) u[i] -= d * f[i];
  const double ul = vm::dsqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]);
  if (!(ul > 0.05)) return 0;   // up within 3 degrees of forward: no stable roll
  for (int i = 0; i < 3; ++i) u[i] /= ul;
  const double r[3] = {u[1] * f[2] - u[2] * f[1], u[2] * f[0] - u[0] * f[2], u[0] * f[1] - u[1] * f[0]};
  for (int i = 0; i < 3; ++i) { B[i] = r[i]; B[3 + i] = u[i]; B[6 + i] = f[i]; }
  return 1;
}
// Remember M's place on the controller. A pose that is not a real hold (not finite, 2 ft or more from the grip, a flat or huge axis) changes NOTHING:
// the last good hold stays. Returns 1 when taken.
inline int store(Rel& rel, const float* M, const float* gripf, const float* dirf, const float* wupf) {
  double B[9];
  if (!M || !gripf || !finite3(gripf) || !basis(dirf, wupf, B)) return 0;
  for (int i = 0; i < 15; ++i) if (i % 4 != 3 && !vm::is_finite_f(M[i])) return 0;
  Rel n; n.ok = 1;
  const double dp[3] = {(double)M[12] - gripf[0], (double)M[13] - gripf[1], (double)M[14] - gripf[2]};
  if (!(dp[0] * dp[0] + dp[1] * dp[1] + dp[2] * dp[2] < 4.0)) return 0;
  for (int a = 0; a < 3; ++a) n.pos[a] = (float)(B[a * 3] * dp[0] + B[a * 3 + 1] * dp[1] + B[a * 3 + 2] * dp[2]);
  for (int j = 0; j < 3; ++j) {
    const double l2 = (double)M[j * 4] * M[j * 4] + (double)M[j * 4 + 1] * M[j * 4 + 1] + (double)M[j * 4 + 2] * M[j * 4 + 2];
    if (!(l2 > 1e-4 && l2 < 1e4)) return 0;   // an axis shorter than 0.01 or longer than 100: not a drawn meter (the hidden one is 1e-4)
    for (int a = 0; a < 3; ++a) n.ax[j * 3 + a] = (float)(B[a * 3] * M[j * 4] + B[a * 3 + 1] * M[j * 4 + 1] + B[a * 3 + 2] * M[j * 4 + 2]);
  }
  if (!finite3(n.pos) || !finite3(n.ax) || !finite3(n.ax + 3) || !finite3(n.ax + 6)) return 0;
  rel = n;
  return 1;
}
// The remembered hold on the controller as it is now. 0 = none (M untouched).
inline int pose(const Rel& rel, const float* gripf, const float* dirf, const float* wupf, float* M) {
  double B[9];
  if (!rel.ok || !gripf || !finite3(gripf) || !basis(dirf, wupf, B)) return 0;
  float o[16];
  for (int i = 0; i < 16; ++i) o[i] = 0.0f;
  for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) o[j * 4 + i] = (float)(rel.ax[j * 3] * B[i] + rel.ax[j * 3 + 1] * B[3 + i] + rel.ax[j * 3 + 2] * B[6 + i]);
  for (int i = 0; i < 3; ++i) o[12 + i] = (float)(gripf[i] + rel.pos[0] * B[i] + rel.pos[1] * B[3 + i] + rel.pos[2] * B[6 + i]);
  o[15] = 1.0f;
  for (int i = 0; i < 16; ++i) if (!vm::is_finite_f(o[i])) return 0;
  for (int i = 0; i < 16; ++i) M[i] = o[i];
  return 1;
}
}  // namespace pkerel
