// d3d11.dll proxy: loads the real system d3d11.dll, forwards every export,
// and installs the probe on the game's first D3D11CreateDevice call
// (outside the loader lock, before any rendering).
#include "gbvr.h"
#include "layout.h"
#include "sigcheck.h"
#include "MinHook.h"
#include <d3d11.h>

GameModule g_game;
HMODULE g_selfModule;
wchar_t g_selfDir[MAX_PATH];

static HMODULE g_realD3D11;
static INIT_ONCE g_initOnce = INIT_ONCE_STATIC_INIT;

#if GBVR_HEADTRACK
// ---- DXGI 1.1 factory for the game (0.21.1, see layout.h) ----------------------
// Installed from DllMain (the game asks for its factory before its first
// Direct3D call, so the usual first-call initialisation would be too late).
// DllMain only checks two marker files, reads two export addresses of the
// already loaded dxgi.dll and rewrites one pointer in the game's import
// table; nothing is loaded or logged there. Logging starts when the game
// calls the wrapper below.
static void ensure_init();
static void write_start_marker();
typedef HRESULT(WINAPI* PFN_CreateDXGIFactory)(REFIID, void**);
static PFN_CreateDXGIFactory g_dxgiFactory1;   // dxgi.dll!CreateDXGIFactory1
static PFN_CreateDXGIFactory g_dxgiSlotOrig;   // what the game's import slot held (dxgi.dll!CreateDXGIFactory)
static int g_dxgiPatch;                        // 1 installed, <0 reason it was not
static int g_dxgiSlotWasPlain;                 // slot pointed straight at dxgi.dll!CreateDXGIFactory
static volatile LONG g_dxgiCalls, g_dxgiUpgraded;
static HRESULT g_dxgiLastHr;

static HRESULT WINAPI hk_CreateDXGIFactory(REFIID riid, void** out) {
  // The game calls this from its normal start-up code (not from a DLL entry
  // point), so the probe can initialise and open its log here. Every step is
  // logged and flushed: if the game stops during start-up, the log shows
  // how far it got.
  ensure_init();
  LONG call = InterlockedIncrement(&g_dxgiCalls);
  log_line("DXGIFACTORY the game asks for its DXGI factory (call %d)", (int)call);
  log_flush();
  if (g_dxgiFactory1 && out) {
    write_start_marker();
    IDXGIFactory1* f1 = nullptr;
    HRESULT hr = g_dxgiFactory1(__uuidof(IDXGIFactory1), (void**)&f1);
    if (SUCCEEDED(hr) && f1) {
      hr = f1->QueryInterface(riid, out);  // the interface the game asked for, on the 1.1 factory
      f1->Release();
      if (SUCCEEDED(hr)) {
        InterlockedIncrement(&g_dxgiUpgraded);
        log_line("DXGIFACTORY gave the game a DXGI 1.1 factory %p", *out);
        modes_install(*out);
        log_flush();
        return hr;
      }
    }
    g_dxgiLastHr = hr;
    log_line("DXGIFACTORY DXGI 1.1 factory not available (0x%08x); using the game's normal one", (unsigned)hr);
  }
  HRESULT hr0 = g_dxgiSlotOrig(riid, out);  // anything unexpected: exactly what the game would have got
  log_line("DXGIFACTORY normal DXGI 1.0 factory result 0x%08x", (unsigned)hr0);
  if (SUCCEEDED(hr0) && out && *out) modes_install(*out);
  log_flush();
  return hr0;
}

// ---- Start-up safety net (0.23) -------------------------------------------------------
// The DXGI 1.1 switch is the only thing the probe changes while the game
// starts. To make sure it can never keep the game from starting twice:
//   gbvr_start_pending.txt  is written when the game asks for its DXGI
//                           factory and deleted when the first frame has been
//                           presented (so a process that exits before it
//                           starts its graphics, e.g. a relaunch through
//                           Steam, leaves nothing behind);
//   if it is still there at the next start, the previous start did not get
//   that far: it is renamed to gbvr_dxgi11_off.txt and, while that file
//   exists, the game starts exactly as it did with 0.21 (no DXGI switch, so
//   no headset picture). The installer deletes both files.
// Only plain kernel32 file calls are used here (this runs from DllMain).
static wchar_t g_pendingPath[MAX_PATH + 40], g_offPath[MAX_PATH + 40];
static int g_startMode;        // 1 = DXGI 1.1 switch requested, 0 = off
static int g_prevStartFailed;  // pending marker found at start
static int g_offFileSeen, g_pendingWritten;

static int file_exists(const wchar_t* p) { return GetFileAttributesW(p) != INVALID_FILE_ATTRIBUTES; }

static int write_small_file(const wchar_t* path, const char* text) {
  HANDLE f = CreateFileW(path, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f == INVALID_HANDLE_VALUE) return 0;
  DWORD w = 0;
  WriteFile(f, text, (DWORD)lstrlenA(text), &w, nullptr);
  CloseHandle(f);
  return 1;
}

// 0.26: the bigger picture (modes.cpp) is the second thing that changes the
// game's start-up. When it is in use the marker says so ("picture=1"); if
// that start does not reach its first frame, only the bigger picture is
// switched off for the following starts (gbvr_picture_off.txt) and the
// headset picture keeps working at the monitor's resolution.
static wchar_t g_pictureOffPath[MAX_PATH + 40];
int g_pictureOff;
static int g_prevPictureFailed;
static int g_markerForeign;   // a marker of another, still running game process was found: it is left alone

static int file_contains(const wchar_t* path, const char* word) {
  HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (f == INVALID_HANDLE_VALUE) return 0;
  char buf[512];
  DWORD got = 0;
  ReadFile(f, buf, sizeof(buf) - 1, &got, nullptr);
  CloseHandle(f);
  int n = lstrlenA(word);
  for (DWORD i = 0; i + (DWORD)n <= got; ++i) {
    int j = 0;
    while (j < n && buf[i + j] == word[j]) ++j;
    if (j == n) return 1;
  }
  return 0;
}

// 0.26: the marker carries the process id of its writer ("pid=1234;"). A
// marker that is less than 30 seconds old and whose writer is still running
// belongs to a game that is starting right now (a second process that loads
// this DLL meanwhile must not read it as a failed start). An older marker
// counts as a failed start even if its writer still exists (a game that hangs
// while starting stays in the background).
static int marker_owner_alive(const wchar_t* path) {
  WIN32_FILE_ATTRIBUTE_DATA fa;
  FILETIME nowFt;
  if (!GetFileAttributesExW(path, GetFileExInfoStandard, &fa)) return 0;
  GetSystemTimeAsFileTime(&nowFt);
  uint64_t written = ((uint64_t)fa.ftLastWriteTime.dwHighDateTime << 32) | fa.ftLastWriteTime.dwLowDateTime;
  uint64_t now = ((uint64_t)nowFt.dwHighDateTime << 32) | nowFt.dwLowDateTime;
  if (now < written || now - written > 30ull * 10000000ull) return 0;
  HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (f == INVALID_HANDLE_VALUE) return 0;
  char buf[512];
  DWORD got = 0;
  ReadFile(f, buf, sizeof(buf) - 1, &got, nullptr);
  CloseHandle(f);
  DWORD pid = 0;
  for (DWORD i = 0; i + 4 < got; ++i) {
    if (buf[i] == 'p' && buf[i + 1] == 'i' && buf[i + 2] == 'd' && buf[i + 3] == '=') {
      for (DWORD k = i + 4; k < got && buf[k] >= '0' && buf[k] <= '9' && pid < 100000000u; ++k) pid = pid * 10 + (DWORD)(buf[k] - '0');
      break;
    }
  }
  if (!pid || pid == GetCurrentProcessId()) return 0;
  HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
  if (!h) return 0;
  DWORD code = 0;
  int alive = GetExitCodeProcess(h, &code) && code == STILL_ACTIVE;
  CloseHandle(h);
  return alive;
}

static void early_startup_guard() {
  lstrcpynW(g_pendingPath, g_selfDir, MAX_PATH);
  lstrcatW(g_pendingPath, L"gbvr_start_pending.txt");
  lstrcpynW(g_offPath, g_selfDir, MAX_PATH);
  lstrcatW(g_offPath, L"gbvr_dxgi11_off.txt");
  lstrcpynW(g_pictureOffPath, g_selfDir, MAX_PATH);
  lstrcatW(g_pictureOffPath, L"gbvr_picture_off.txt");
  g_pictureOff = file_exists(g_pictureOffPath);
  if (file_exists(g_pendingPath) && marker_owner_alive(g_pendingPath)) {
    // another copy of the game is starting right now: its marker is not ours to judge
    g_startMode = file_exists(g_offPath) ? 0 : 1;
    g_offFileSeen = !g_startMode;
    g_markerForeign = 1;
    return;
  }
  if (file_exists(g_pendingPath) && !file_exists(g_offPath) && file_contains(g_pendingPath, "picture=1")) {
    g_prevPictureFailed = 1;
    write_small_file(g_pictureOffPath, "The previous start of the game with the VR probe's bigger picture did not reach its first picture.\r\n"
                                       "While this file exists the game draws at the monitor's resolution again.\r\n"
                                       "Pressing Insert in the game, or installing a probe version, deletes it.\r\n");
    DeleteFileW(g_pendingPath);
  }
  g_pictureOff = g_prevPictureFailed || file_exists(g_pictureOffPath);
  if (file_exists(g_offPath)) { g_offFileSeen = 1; g_startMode = 0; DeleteFileW(g_pendingPath); return; }
  if (file_exists(g_pendingPath)) {
    g_prevStartFailed = 1;
    g_startMode = 0;
    write_small_file(g_offPath, "The previous start of the game with the VR probe did not reach its first picture.\r\n"
                                "While this file exists the probe leaves the game's graphics start-up unchanged\r\n"
                                "(the headset picture, F4, cannot work). Installing a probe version deletes it.\r\n");
    DeleteFileW(g_pendingPath);
    return;
  }
  g_startMode = 1;  // the marker itself is written when the game actually asks for its factory
}

static void write_marker_text(const char* what) {
  char text[256];
  log_fmt(text, (int)sizeof(text), "pid=%u; VR probe: the game is starting its graphics%s. This file is deleted when the "
          "first picture is shown.\r\n", (unsigned)GetCurrentProcessId(), what);
  int ok = write_small_file(g_pendingPath, text);
  if (!g_pendingWritten) g_pendingWritten = ok;
}

static void write_start_marker() {
  if (!g_pendingWritten && !g_markerForeign) write_marker_text("");
}

void startup_mark_picture() {
  if (g_pendingWritten) write_marker_text(" with the bigger picture (picture=1)");
}

void startup_picture_retry() {
  if (g_pictureOff && DeleteFileW(g_pictureOffPath)) log_line("PICTURE gbvr_picture_off.txt deleted: the bigger picture is tried again at the next start");
  g_pictureOff = 0;
}

void startup_confirmed() {
  if (g_pendingWritten) {
    int ok = DeleteFileW(g_pendingPath) != 0;
    g_pendingWritten = 0;
    log_line("STARTUP first frame presented; start-up marker removed=%d", ok);
  }
}

// ---- Crash notes (0.23) -----------------------------------------------------------------
// If the game hits a fatal error while the probe is loaded, write where it
// happened (module + offset, and code addresses found on the stack) to the
// log. The error is passed on untouched. No locks other than the log's own.
static volatile LONG g_crashNotes;
static uintptr_t g_selfBase, g_selfSize, g_dxgiBase, g_d3d11Base;

static const char* module_of(uintptr_t a, uintptr_t* off) {
  MEMORY_BASIC_INFORMATION mbi;
  *off = a;
  if (!a || VirtualQuery((void*)a, &mbi, sizeof(mbi)) != sizeof(mbi) || !mbi.AllocationBase) return "?";
  uintptr_t b = (uintptr_t)mbi.AllocationBase;
  *off = a - b;
  if (b == g_game.base) return "ghost.exe";
  if (b == g_selfBase) return "probe";
  if (b == g_dxgiBase) return "dxgi.dll";
  if (b == g_d3d11Base) return "system-d3d11.dll";
  *off = a;
  return "other";
}

static int strcmp_probe(const char* m) { return m && m[0] == 'p' && m[1] == 'r' && m[2] == 'o' && m[3] == 'b' && m[4] == 'e' && !m[5]; }

static LONG CALLBACK crash_note(EXCEPTION_POINTERS* ep) {
  DWORD code = ep->ExceptionRecord->ExceptionCode;
  if (code != EXCEPTION_ACCESS_VIOLATION && code != EXCEPTION_ILLEGAL_INSTRUCTION &&
      code != EXCEPTION_INT_DIVIDE_BY_ZERO && code != EXCEPTION_PRIV_INSTRUCTION &&
      code != EXCEPTION_ARRAY_BOUNDS_EXCEEDED && code != EXCEPTION_IN_PAGE_ERROR &&
      code != EXCEPTION_STACK_OVERFLOW && code != 0xC0000409 /* fast fail */ && code != 0xC0000374 /* heap corruption */ && code != 0xC0000420 /* assertion */ &&
      code != 0xC000001D && code != EXCEPTION_FLT_INVALID_OPERATION && code != EXCEPTION_NONCONTINUABLE_EXCEPTION)
    return EXCEPTION_CONTINUE_SEARCH;
  if (InterlockedIncrement(&g_crashNotes) > 4) return EXCEPTION_CONTINUE_SEARCH;
  uintptr_t off = 0;
  uintptr_t ip = (uintptr_t)ep->ExceptionRecord->ExceptionAddress;
  const char* mod = module_of(ip, &off);
  uintptr_t kind = ep->ExceptionRecord->NumberParameters >= 2 ? ep->ExceptionRecord->ExceptionInformation[0] : 0;
  uintptr_t target = ep->ExceptionRecord->NumberParameters >= 2 ? ep->ExceptionRecord->ExceptionInformation[1] : 0;
  log_line("CRASHNOTE code=%08x at %s+0x%llx thread=%u access=%u address=%p present=%d dxgiCalls=%d dxgiUpgraded=%d",
           (unsigned)code, mod, (unsigned long long)off, GetCurrentThreadId(), (unsigned)kind, (void*)target,
           (int)render_present_count(), (int)g_dxgiCalls, (int)g_dxgiUpgraded);
  // 0.44: where the probe's own code was, and a few registers (a null or small value in a register next to the failing
  // address tells which pointer was bad)
  log_line("CRASHWHERE renderThread=%s gameMainLoop=%s inProbe=%d rip=%p rsp=%p rax=%p rbx=%p rcx=%p rdx=%p rsi=%p rdi=%p r8=%p r9=%p",
           stage_name(g_stageR), stage_name(g_stageG), (int)(strcmp_probe(mod)), (void*)ep->ContextRecord->Rip, (void*)ep->ContextRecord->Rsp,
           (void*)ep->ContextRecord->Rax, (void*)ep->ContextRecord->Rbx, (void*)ep->ContextRecord->Rcx, (void*)ep->ContextRecord->Rdx,
           (void*)ep->ContextRecord->Rsi, (void*)ep->ContextRecord->Rdi, (void*)ep->ContextRecord->R8, (void*)ep->ContextRecord->R9);
  {
    char sum[300];
    log_fmt(sum, (int)sizeof(sum), "code=%08x at %s+0x%llx thread=%u access=%u address=%p", (unsigned)code, mod,
            (unsigned long long)off, GetCurrentThreadId(), (unsigned)kind, (void*)target);
    safety_on_fault(sum);
  }
  // Code addresses on the stack (likely callers), game and probe only.
  uintptr_t sp = (uintptr_t)ep->ContextRecord->Rsp;
  MEMORY_BASIC_INFORMATION mbi;
  if (sp && !(sp & 7) && VirtualQuery((void*)sp, &mbi, sizeof(mbi)) == sizeof(mbi) && mbi.State == MEM_COMMIT &&
      !(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS))) {
    uintptr_t end = (uintptr_t)mbi.BaseAddress + mbi.RegionSize;
    char buf[400];
    int len = 0, found = 0;
    for (uintptr_t p = sp; p + 8 <= end && p < sp + 0x600 && found < 12; p += 8) {
      uintptr_t v = *(const uintptr_t*)p;
      if (v >= g_game.base + 0x1000 && v < g_game.base + 0x732000)
        len += log_fmt(buf + len, (int)sizeof(buf) - len, " ghost+0x%llx", (unsigned long long)(v - g_game.base)), ++found;
      else if (g_selfBase && v >= g_selfBase && v < g_selfBase + g_selfSize)
        len += log_fmt(buf + len, (int)sizeof(buf) - len, " probe+0x%llx", (unsigned long long)(v - g_selfBase)), ++found;
    }
    buf[len < (int)sizeof(buf) ? len : (int)sizeof(buf) - 1] = 0;
    log_line("CRASHSTACK%s", found ? buf : " (no game addresses found)");
  }
  log_flush();
  return EXCEPTION_CONTINUE_SEARCH;
}

// 0.86: the last word of the process: whatever the system is about to kill it for is written down first (the 0.85 crash left nothing)
static LONG WINAPI last_word(EXCEPTION_POINTERS* ep) {
  static volatile LONG once;
  if (InterlockedCompareExchange(&once, 1, 0) == 0 && ep && ep->ExceptionRecord) {
    uintptr_t off = 0;
    const char* mod = module_of((uintptr_t)ep->ExceptionRecord->ExceptionAddress, &off);
    crumb("LASTWORD", (int)ep->ExceptionRecord->ExceptionCode);
    log_line("LASTWORD unhandled exception code=%08x at %s+0x%llx thread=%u (the process is ending)", (unsigned)ep->ExceptionRecord->ExceptionCode, mod, (unsigned long long)off, GetCurrentThreadId());
    log_flush();
  }
  return EXCEPTION_CONTINUE_SEARCH;
}
static void install_crash_notes() {
  SetUnhandledExceptionFilter(last_word);
  g_selfBase = (uintptr_t)g_selfModule;
  const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)g_selfBase;
  g_selfSize = ((const IMAGE_NT_HEADERS64*)(g_selfBase + dos->e_lfanew))->OptionalHeader.SizeOfImage;
  g_dxgiBase = (uintptr_t)GetModuleHandleW(L"dxgi.dll");
  void* h = AddVectoredExceptionHandler(0, crash_note);
  log_line("CRASHNOTES handler=%d probeBase=%p probeSize=0x%x", h != nullptr, (void*)g_selfBase, (unsigned)g_selfSize);
}

static void early_install_dxgi_factory() {
  HMODULE exe = GetModuleHandleW(nullptr);
  uintptr_t base = (uintptr_t)exe;
  const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)exe;
  if (!exe || dos->e_magic != IMAGE_DOS_SIGNATURE) { g_dxgiPatch = -1; return; }
  const IMAGE_NT_HEADERS64* nt = (const IMAGE_NT_HEADERS64*)(base + dos->e_lfanew);
  if (nt->OptionalHeader.SizeOfImage != layout::kExpectedSizeOfImage ||
      nt->FileHeader.TimeDateStamp != layout::kExpectedTimeDateStamp) { g_dxgiPatch = -1; return; }  // not our game build
  HMODULE dxgi = GetModuleHandleW(L"dxgi.dll");
  if (!dxgi) { g_dxgiPatch = -2; return; }
  FARPROC f0 = GetProcAddress(dxgi, "CreateDXGIFactory");
  FARPROC f1 = GetProcAddress(dxgi, "CreateDXGIFactory1");
  if (!f0 || !f1) { g_dxgiPatch = -3; return; }
  void** slot = (void**)(base + layout::kRvaIatCreateDXGIFactory);
  void* cur = *slot;
  g_dxgiSlotWasPlain = cur == (void*)f0;
  // The slot must already hold a real code address (imports resolved).
  MEMORY_BASIC_INFORMATION mbi;
  if (!cur || VirtualQuery(cur, &mbi, sizeof(mbi)) != sizeof(mbi) || mbi.State != MEM_COMMIT ||
      !(mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY))) {
    g_dxgiPatch = -4;
    return;
  }
  DWORD old = 0;
  if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &old)) { g_dxgiPatch = -5; return; }
  g_dxgiFactory1 = (PFN_CreateDXGIFactory)f1;
  g_dxgiSlotOrig = (PFN_CreateDXGIFactory)cur;
  *slot = (void*)hk_CreateDXGIFactory;
  VirtualProtect(slot, sizeof(void*), old, &old);
  g_dxgiPatch = 1;
}

// 0.88: the game's cutscene video (class WinVideo) needs NV12 pictures on a video-capable device. Logged for every device the
// game creates: NV12 / P010 format support, the video device interface and the hardware decoder profiles (H.264 among them).
static void log_device_video(ID3D11Device* dev) {
  UINT nv12 = 0, p010 = 0, yuy2 = 0, bgra = 0;
  HRESULT h1 = dev->CheckFormatSupport(DXGI_FORMAT_NV12, &nv12);
  HRESULT h2 = dev->CheckFormatSupport(DXGI_FORMAT_P010, &p010);
  HRESULT h3 = dev->CheckFormatSupport(DXGI_FORMAT_YUY2, &yuy2);
  HRESULT h4 = dev->CheckFormatSupport(DXGI_FORMAT_B8G8R8A8_UNORM, &bgra);
  log_line("VIDEODEV device=%p featureLevel=0x%x NV12=0x%08x(hr %08x) P010=0x%08x(hr %08x) YUY2=0x%08x(hr %08x) BGRA=0x%08x(hr %08x) creationFlags=0x%x",
           (void*)dev, (unsigned)dev->GetFeatureLevel(), nv12, (unsigned)h1, p010, (unsigned)h2, yuy2, (unsigned)h3, bgra, (unsigned)h4,
           (unsigned)dev->GetCreationFlags());
  static const GUID kIidVideoDevice = {0x10EC4D5B, 0x975A, 0x4689, {0xB9, 0xE4, 0xD0, 0xAA, 0xC3, 0x0F, 0xE3, 0x33}};
  static const GUID kH264 = {0x1B81BE68, 0xA0C7, 0x11D3, {0xB9, 0x84, 0x00, 0xC0, 0x4F, 0x2E, 0x73, 0xC5}};
  void* vd = nullptr;
  HRESULT hq = dev->QueryInterface(kIidVideoDevice, &vd);
  if (FAILED(hq) || !vd) { log_line("VIDEODEV device=%p has no video device interface (hr 0x%08x)", (void*)dev, (unsigned)hq); return; }
  void** vt = *(void***)vd;
  typedef UINT(STDMETHODCALLTYPE * PFN_Count)(void*);
  typedef HRESULT(STDMETHODCALLTYPE * PFN_Profile)(void*, UINT, GUID*);
  UINT n = ((PFN_Count)vt[11])(vd);
  int h264 = 0;
  for (UINT i = 0; i < n && i < 64; ++i) {
    GUID g;
    if (SUCCEEDED(((PFN_Profile)vt[12])(vd, i, &g)) && g.Data1 == kH264.Data1 && g.Data2 == kH264.Data2 && g.Data3 == kH264.Data3) h264 = 1;
  }
  log_line("VIDEODEV device=%p video device ok: %u hardware decoder profiles, H.264 %s", (void*)dev, (unsigned)n, h264 ? "yes" : "NO");
  ((IUnknown*)vd)->Release();
}

// Logged for every device the game creates: can it hand pictures to SteamVR?
static void log_device_sharing(ID3D11Device* dev) {
  log_line("DXGIFACTORY startMode=%d install=%d slotWasPlain=%d calls=%d upgradedTo11=%d lastError=0x%08x",
           g_startMode, g_dxgiPatch, g_dxgiSlotWasPlain, (int)g_dxgiCalls, (int)g_dxgiUpgraded,
           (unsigned)g_dxgiLastHr);
  if (g_startMode == 0) return;  // off: start exactly like 0.21, no test texture either
  D3D11_TEXTURE2D_DESC t;
  ZeroMemory(&t, sizeof(t));
  t.Width = 16; t.Height = 16; t.MipLevels = 1; t.ArraySize = 1; t.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
  t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT;
  t.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
  HRESULT hr[2];
  const UINT misc[2] = {D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX, D3D11_RESOURCE_MISC_SHARED};
  for (int i = 0; i < 2; ++i) {
    ID3D11Texture2D* tex = nullptr;
    t.MiscFlags = misc[i];
    hr[i] = dev->CreateTexture2D(&t, nullptr, &tex);
    if (tex) tex->Release();
  }
  log_line("SHARETEST device=%p keyedMutexSharedTexture=0x%08x plainSharedTexture=0x%08x (%s)", (void*)dev,
           (unsigned)hr[0], (unsigned)hr[1],
           SUCCEEDED(hr[0]) ? "OK: this device can give pictures to the headset"
                            : "FAILED: the headset picture will not work on this device");
}
#endif

// 1.7.187: when the game build is not the verified one, where did the hook sites go? (so a port to that build can be made from the report). Scans the code for each site's 16 bytes; only runs on a mismatch.
static void site_scan() {
  const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)g_game.base;
  const IMAGE_NT_HEADERS64* nt = (const IMAGE_NT_HEADERS64*)(g_game.base + dos->e_lfanew);
  const IMAGE_SECTION_HEADER* sh = IMAGE_FIRST_SECTION(nt);
  uint32_t tva = 0, tsz = 0;
  for (int i = 0; i < nt->FileHeader.NumberOfSections; ++i) if (sh[i].Name[0] == '.' && sh[i].Name[1] == 't' && sh[i].Name[2] == 'e' && sh[i].Name[3] == 'x' && sh[i].Name[4] == 't') { tva = sh[i].VirtualAddress; tsz = sh[i].Misc.VirtualSize; }
  log_line("GAMEBUILD sections: %d, code at rva %x size %x, image size %x, entry %x", (int)nt->FileHeader.NumberOfSections, tva, tsz, g_game.sizeOfImage, (unsigned)nt->OptionalHeader.AddressOfEntryPoint);
  if (!tva || tsz < 0x1000 || tsz > 0x6000000) return;
  struct S { uint32_t r; const uint8_t* b; const char* n; } sites[] = {
    {layout::kRvaCameraPrepare, layout::kBytesCameraPrepare, "camera-prepare"}, {layout::kRvaBasisSetter, layout::kBytesBasisSetter, "basis"},
    {layout::kRvaVisibilityStage, layout::kBytesVisibilityStage, "visibility-stage"}, {layout::kRvaSetEye, layout::kBytesSetEye, "set-eye"},
    {layout::kRvaMainSpatial, layout::kBytesMainSpatial, "main-spatial"}, {layout::kRvaSetNearFar, layout::kBytesSetNearFar, "set-near-far"},
    {layout::kRvaSetProjection, layout::kBytesSetProjection, "set-projection"}, {layout::kRvaSetScales, layout::kBytesSetScales, "set-scales"},
    {layout::kRvaAppTick, layout::kBytesAppTick, "app-tick"}, {layout::kRvaAppSimulate, layout::kBytesAppSimulate, "app-simulate"},
    {layout::kRvaStreamUpdate, layout::kBytesStreamUpdate, "stream-update"}, {layout::kRvaKnockBack, layout::kBytesKnockBack, "knock-back"},
  };
  const uint8_t* code = (const uint8_t*)(g_game.base + tva);
  for (auto& s : sites) {
    int hits = 0; uint32_t at[3] = {0, 0, 0};
    for (uint32_t o = 0; o + 16 <= tsz && hits < 3; ++o) {
      if (code[o] != s.b[0] || code[o + 1] != s.b[1]) continue;
      int same = 1; for (int k = 2; k < 16; ++k) if (code[o + k] != s.b[k]) { same = 0; break; }
      if (same) at[hits++] = tva + o;
    }
    if (hits) log_line("GAMEBUILD site %s: Steam rva %x -> found %d x, first at rva %x (moved by %d bytes)", s.n, s.r, hits, at[0], (int)((int64_t)at[0] - (int64_t)s.r));
    else log_line("GAMEBUILD site %s: Steam rva %x -> not found (the code differs)", s.n, s.r);
  }
}

static void check_game_module() {
  HMODULE exe = GetModuleHandleW(nullptr);
  g_game.base = (uintptr_t)exe;
  const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)exe;
  const IMAGE_NT_HEADERS64* nt = (const IMAGE_NT_HEADERS64*)(g_game.base + dos->e_lfanew);
  g_game.sizeOfImage = nt->OptionalHeader.SizeOfImage;
  g_game.timeDateStamp = nt->FileHeader.TimeDateStamp;
  g_game.identityOK = g_game.sizeOfImage == layout::kExpectedSizeOfImage &&
                      g_game.timeDateStamp == layout::kExpectedTimeDateStamp;
  g_game.altBuild = 0; g_game.sampleMiss = -1;
  if (!g_game.identityOK) {
    // 1.7.187 EPIC GAMES SUPPORT: the Epic Games Store build of the game has another PE header (timestamp / size / wrapper) but may hold the very same code. Every code sample of the
    // analysed Steam build (sigtable.h: 16 bytes at each of ~500 places, spread over the whole code) must be identical; a single difference keeps the mod off, as before.
    int first = -1;
    const int miss = sigcheck::misses((const uint8_t*)g_game.base, [](const void* p) -> int { return IsBadReadPtr(p, 16) ? 0 : 1; }, &first);
    g_game.sampleMiss = miss;
    if (miss == 0) { g_game.identityOK = 1; g_game.altBuild = 1; log_line("GAMEBUILD another build of the game (timestamp %08x, size %08x; the Steam build is %08x / %08x) holds the SAME code at all %d checked places: running as the verified build (Epic Games Store?)", g_game.timeDateStamp, g_game.sizeOfImage, (unsigned)layout::kExpectedTimeDateStamp, (unsigned)layout::kExpectedSizeOfImage, sigtable::kCount); }
    else { log_line("GAMEBUILD another build of the game (timestamp %08x, size %08x): %d of %d checked code places differ (first at rva %x): the mod stays off", g_game.timeDateStamp, g_game.sizeOfImage, miss, sigtable::kCount, first >= 0 ? sigtable::kSamples[first].rva : 0u); site_scan(); }
  }
  int ok = g_game.identityOK;
  if (ok) {
    struct Site { uint32_t r; const uint8_t* b; const char* name; } sites[] = {
      {layout::kRvaCameraPrepare, layout::kBytesCameraPrepare, "camera-prepare"},
      {layout::kRvaBasisSetter, layout::kBytesBasisSetter, "basis"},
      {layout::kRvaVisibilityStage, layout::kBytesVisibilityStage, "visibility-stage"},
      {layout::kRvaSetEye, layout::kBytesSetEye, "set-eye"},
      {layout::kRvaMainSpatial, layout::kBytesMainSpatial, "main-spatial"},
      {layout::kRvaSetNearFar, layout::kBytesSetNearFar, "set-near-far"},
#if GBVR_HEADTRACK
      {layout::kRvaSetProjection, layout::kBytesSetProjection, "set-projection"},
      {layout::kRvaSetScales, layout::kBytesSetScales, "set-scales"},
      {layout::kRvaAppTick, layout::kBytesAppTick, "app-tick"},
      {layout::kRvaAppSimulate, layout::kBytesAppSimulate, "app-simulate"},
#endif
    };
    for (auto& s : sites) {
      const uint8_t* p = (const uint8_t*)rva(s.r);
      int same = 1;
      for (int i = 0; i < 16; ++i) if (p[i] != s.b[i]) same = 0;
      if (!same) { ok = 0; log_line("SITECHECK %s rva=%x MISMATCH (another mod or a different game build?)", s.name, s.r); }
    }
  }
  g_game.hookBytesOK = ok;
  log_line("GAME base=%p timestamp=%08x sizeOfImage=%08x identityOK=%d hookBytesOK=%d", (void*)g_game.base,
           g_game.timeDateStamp, g_game.sizeOfImage, g_game.identityOK, g_game.hookBytesOK);
}

// Diagnostic: report the frame-limit keys in the game's settings file
// (%LOCALAPPDATA%\GHOSTBUSTERS\settings.ini, see layout.h). Read-only.
static void log_settings_ini() {
  wchar_t path[MAX_PATH + 64];
  DWORD n = GetEnvironmentVariableW(L"LOCALAPPDATA", path, MAX_PATH);
  if (n == 0 || n >= MAX_PATH) return;
  lstrcatW(path, L"\\GHOSTBUSTERS\\settings.ini");
  HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (f == INVALID_HANDLE_VALUE) { log_line("SETTINGSINI %%LOCALAPPDATA%%\\GHOSTBUSTERS\\settings.ini not found"); return; }
  static char buf[32768];
  DWORD got = 0;
  ReadFile(f, buf, sizeof(buf) - 2, &got, nullptr);
  CloseHandle(f);
  // UTF-16 files (BOM FF FE): keep the low byte of each character.
  if (got >= 2 && (uint8_t)buf[0] == 0xFF && (uint8_t)buf[1] == 0xFE) {
    DWORD j = 0;
    for (DWORD i = 2; i + 1 < got; i += 2) buf[j++] = buf[i];
    got = j;
  }
  buf[got] = 0;
  const char* keys[] = {"lockTo30Hz", "lockTo60Hz"};
  for (const char* key : keys) {
    const char* hit = nullptr;
    int klen = lstrlenA(key);
    for (DWORD i = 0; i + klen < got && !hit; ++i)
      if ((i == 0 || buf[i - 1] == '\n') && CompareStringA(LOCALE_INVARIANT, NORM_IGNORECASE, buf + i, klen, key, klen) == CSTR_EQUAL)
        hit = buf + i;
    if (!hit) { log_line("SETTINGSINI %s missing", key); continue; }
    char line[96]; int k = 0;
    while (hit[k] && hit[k] != '\r' && hit[k] != '\n' && k < 95) { line[k] = hit[k]; ++k; }
    line[k] = 0;
    log_line("SETTINGSINI %s", line);
  }
}

static BOOL CALLBACK init_once_cb(PINIT_ONCE, PVOID, PVOID*) {
  log_open();
  log_line("GBVR Render Probe %s - %s", GBVR_VERSION, GBVR_DESCRIPTION);
  log_line("BUILD source=%s headtrack=%d", GBVR_SOURCE_DATE, GBVR_HEADTRACK);

  wchar_t sys[MAX_PATH];
  UINT n = GetSystemDirectoryW(sys, MAX_PATH);
  if (n > 0 && n < MAX_PATH - 12) {
    lstrcatW(sys, L"\\d3d11.dll");
    g_realD3D11 = LoadLibraryW(sys);
  }
  MH_STATUS mh = MH_Initialize();
  log_line("MinHook initialization=%d; system D3D11 %s", (int)mh, g_realD3D11 ? "loaded" : "NOT LOADED");

  check_game_module();
#if GBVR_HEADTRACK
  g_d3d11Base = (uintptr_t)g_realD3D11;
  sysinfo_log();   // 0.51
  modscan_start();   // 0.96: what else is in the game folder / process (other mods); runs on its own thread a few seconds later
  install_crash_notes();
  log_line("STARTUP dxgi11Switch=%s%s%s install=%d", g_startMode ? "on" : "OFF",
           g_prevStartFailed ? " (the previous start did not reach its first frame - switched off, gbvr_dxgi11_off.txt written)" : "",
           g_offFileSeen ? " (gbvr_dxgi11_off.txt is present)" : "", g_dxgiPatch);
  if (!g_startMode)
    log_line("STARTUP note: without the DXGI 1.1 switch the headset picture (F4) cannot work in this run.");
  if (g_markerForeign) log_line("STARTUP note: another copy of the game is starting at the same time (its start-up marker was left alone)");
  if (g_pictureOff)
    log_line("STARTUP bigger picture OFF%s: gbvr_picture_off.txt is present (press Insert in the game to try it again)",
             g_prevPictureFailed ? " (the previous start with it did not reach its first frame)" : "");
#endif
  log_settings_ini();
  g_ctl.eyeHeightCenti = 550;   // Standard Pivot Height default (5.5 ft)
  g_ctl.eyeForwardCenti = 30;
  g_ctl.nearCenti = 18;         // first-person near plane 0.18 ft = 5.5 cm (0.77; 0.20-0.76 used 0.55 ft = 17 cm, which cut the chest away when looking down; game default 0.25)
  g_ctl.hbarGate = 0; g_ctl.weaponWheel = 1; g_ctl.wheelScalePct = 100; g_ctl.trapThrow = 1; g_ctl.slamFlickPct = 60; g_ctl.ltCapture = 0; g_ctl.slamSpeedDeci = 12; g_ctl.viewModelPct = 100; g_ctl.forearmTwistPct = 50; g_ctl.chestShield = 1; g_ctl.twoHandPitchDeci = 70; g_ctl.twoHandRefCm = 40; g_ctl.dpadAwayCm = 45; g_ctl.twoHandLine = 1;   // 1.7.127: a held support hand steers the beam again (two_hand_line=0 opts out)
  g_ctl.hoseOff = 0; g_ctl.pkeLikeGun = 1; g_ctl.bodyWhole = 1; g_ctl.trapHipDropCm = 70; g_ctl.trapHipRadiusCm = 28;   // 0.90
  g_ctl.hoseFromGame = 0;   // 0.78; off since 0.89 (its memory walk crashed the game in 0.88; plain black hose until it is made safe)
  g_ctl.trapOwnModel = 0;   // 0.79: the game's own trap goes into the hand
  g_ctl.stereoStrengthPct = 100;
  g_ctl.stereoPair = 1;
  g_ctl.stereoWide = 0;         // 0.25: off by default (tester preferred the picture without it)
  g_ctl.sizePct = 100;          // 0.76: 100 % (0.25-0.75 used 110 %: with it the equipment faded in and out)
  g_ctl.worldPct = 115;         // 0.31: world looks 15 % bigger (0.25 was 91 %, 0.26-0.30 100 %; tester: "scale world larger")
  g_ctl.pictureLines = 0; g_ctl.pictureLevel = 2;       // 1.7.65: 2160 lines, the level the author plays at (level 3 = 2880 lines, sharper, needs a strong PC; 0.43-1.7.64 defaulted to 3)
  g_ctl.hudMode = 1;            // 0.29: 2D overlay placed in front of the player
  g_ctl.hudSizePct = 100;
  g_ctl.hudDistanceCm = 250;
  g_ctl.hideBody = 1;           // 0.28: own body hidden in first person
  g_ctl.hideWand = 1;           // 0.30: the wand too (tester: "body did not fully disappear")
  g_ctl.hideShadow = 1;         // 0.30: and no shadow of the invisible body
  g_ctl.headAim = 2;            // 0.32/0.33: the beam follows the right hand, else the head (Shift+F2)
  g_ctl.padEnabled = 1;         // 0.33: Quest controllers act as the Xbox pad
  g_ctl.twoHandFire = 0;
  g_ctl.handPitchDeci = 0;
  g_ctl.stickDeadzonePct = 18;
  g_ctl.holster = 1;            // 0.38 (0.83: on)
  g_ctl.ventGesture = 1;        // 0.45: grip squeezed with a hand on the pack (over the shoulder) vents
  g_ctl.headMove = 1;           // 0.47: the headset position (leaning, stepping, crouching up to 1 m from the start point) moves the eye
  g_ctl.flatView = 1;           // 0.45: flat mode keeps the picture's 4:3 shape (black bars)
  g_ctl.flatVsyncOff = 1;       // 0.45: flat mode is not held to the monitor / SteamVR refresh
  g_ctl.menuFlip = 0;           // 0.42
  g_ctl.menuFast = 1;           // 0.43: menus run at the headset rate, not the game's 30 FPS menu cap
  g_ctl.autoQuality = 1;        // 0.44: the tool may lower the picture level by itself when a start fails / the PC cannot keep up
  g_ctl.handPredictMs = 10;     // 0.50
  g_ctl.probeData = 0;          // 0.49: player snapshots for later versions (probe_data=0 turns them off)
  g_ctl.diagTiming = 0;         // 0.44: COMPOSITOR line (compositor frame timings)
  g_ctl.handModel = 1;          // 0.34: gloved hands and a wand at the controllers (only drawn while the game's own models are hidden)
  g_ctl.bodyFollow = 1;        // 0.52: the game's body follows the real head
  g_ctl.bodyScale = 1;
  g_ctl.bodyEyeCenti = 550;
  g_ctl.torsoDeadDeg = 8; g_ctl.bodyCalmSlam = 1; g_ctl.trapHangPct = -30; g_ctl.downVignette = 1;
  g_ctl.torsoLagMs = 140;
  g_ctl.menuOnStart = 0;       // 0.53; 0.61: off (it froze the game)
  g_ctl.menuFreeze = 1;        // 0.54; 0.61: off; 0.68: ON again - the menu pauses the game (the 0.61 trouble was the old Resume button tapping Start, which opened the game's pause menu; that button is gone)
  g_ctl.noPauseMenu = 1;       // 0.61
  g_ctl.menuOwnPointer = 1;    // 0.61
  g_ctl.fullBody = 1; g_ctl.bodyLeanCm = 27; g_ctl.bodyLeanDeg = 55; g_ctl.bodyHeadDeg = 95; g_ctl.bodyDropCm = 65; g_ctl.bodyCrouch = 1; g_ctl.armStretchPct = 220; g_ctl.gunGlue = 0;   // 0.61 (170); 0.66: 260 + the gun stays in the hand; 0.68: 150 (eyes at the camera, shoulder reach)
  g_ctl.bodyEyeAlign = 1; g_ctl.eyeShiftCapCm = 30; g_ctl.forcedDetect = 1; g_ctl.eyeBackCm = 4; g_ctl.packFollow = 1; g_ctl.shoulderPullDeg = 45; g_ctl.crouchDeadCm = 8;   // 0.68
  g_ctl.aimAssistPct = 100; g_ctl.aimAssistDeg = 10;   // 0.68 / 0.69 (cone 6 -> 10)
  g_ctl.beamStraight = 1; g_ctl.menuMusic = 1; g_ctl.menuMusicPct = 55; g_ctl.armsOnly = 1; g_ctl.armsShoulders = 1; g_ctl.armsStraps = 1; g_ctl.pkeBody = 0; g_ctl.glovesOnly = 0; g_ctl.fingers = 1; g_ctl.realAnchor = 1; g_ctl.pkeAttach = 1; g_ctl.pkeBones = 0; g_ctl.skipVideos = 0; g_ctl.watchGame = 0; g_ctl.bodyHeightCm = 0; g_ctl.solidBody = 1; g_ctl.leftGripPct = 0; g_ctl.cordPhysics = 0; g_ctl.simStepCapMs = 33; g_ctl.simEveryN = 1; g_ctl.rigView = 0; g_ctl.shoulderSlideCm = 30; g_ctl.rigAutoShots = 0; g_ctl.viewUpCm = 8; g_ctl.bodyOutCm = 10; g_ctl.wallDiag = 0; g_ctl.beamDamagePct = 100; g_ctl.hbar = 1; g_ctl.hbarSizePct = 100; g_ctl.hbarDigits = 1; g_ctl.slamGesture = 1;   // 0.71 (0.76: +15 % beam damage, health bars inside the enemies, slam swing) (0.73: shoulders + physics hose, longest game time step 33 ms) (1.7.186: full body again everywhere; the Stay Puft roof fight alone squashes all but the arms)
  g_ctl.menuMuteGame = 1; g_ctl.menuBg = 1; g_ctl.menuBgPct = 70;   // 0.69 (0.71/0.72 had this line inside a comment by mistake; fixed in 0.73)
  g_ctl.armIk = 1;             // 0.57: arms follow the hands
  g_ctl.armWristCm = 7;
  g_ctl.armElbowDown = 100;
  g_ctl.autoPause = 0;         // 0.52 (on); 0.61: off - it opened the game's pause menu
  g_ctl.realModels = 1;         // 0.51: the game's own body, pack, hose and wand are shown
  g_ctl.wandToHand = 1;         // 0.51: and its wand is moved to the right controller
  g_ctl.wandBackCm = 0;
  g_ctl.gripAtHand = 1; g_ctl.pkeOwn = 0; g_ctl.pkeTiltDeg = 0;   // 0.94: the probe's own PKE is gone
  g_ctl.pkeGame = 1; g_ctl.pkeFwdCm = 0; g_ctl.pkeUpCm = 0; g_ctl.pkeAssistDeg = 18; g_ctl.pkeAssistPct = 100; g_ctl.pkeEasy = 1; g_ctl.pkeEasyFt = 50; g_ctl.gamePlace = 0; g_ctl.holdView = 1; g_ctl.fingerRestPct = 25; g_ctl.slamFlickPct = 0; g_ctl.pkeProxBuzz = 1; g_ctl.pkeConeDeg = 30; g_ctl.pkeAuto = 0; g_ctl.pkeFrame = 1; g_ctl.gunTwistPct = 90;   // 0.94 (1.4: the line had swallowed this default in a comment)
  g_ctl.ringMode = 1; g_ctl.hbar = 1; g_ctl.ringAssist = 1; g_ctl.ringConeDeg = 35; g_ctl.ringHoldDs = 4; g_ctl.turnFollow = 1; g_ctl.turnFollowDeg = 75; g_ctl.turnSnap = 1; g_ctl.turnSnapDeg = 30; g_ctl.turnSmoothDps = 120; g_ctl.turnSmoothOwn = 1; g_ctl.pkeCloseHelp = 1; g_ctl.heldLive = 1;   // 1.5 (+1.7.81 smooth turn, +1.7.83 close-range PKE cone)
  g_ctl.pkeWeightPct = 30; g_ctl.gunPunishPct = 150; g_ctl.flatVoid = 1; g_ctl.flatGlowPct = 70;   // 1.7.35
  g_ctl.pkeEntity = 1;   // 0.97
  g_ctl.flatBlack = 1; g_ctl.flatGlowSteady = 1; g_ctl.pkeShowBody = 1; g_ctl.pkePairCache = 1; g_ctl.pkeShiftPct = 100; g_ctl.sprintClick = 1;   // 0.98 (1.6: 100 = the whole slide, kept rigid)
  g_ctl.handLock = 1;
  g_ctl.vrFpsCap = 0;
  g_ctl.pkeRigid = 1; g_ctl.gunRigid = 1; g_ctl.wheelAlphaPct = 60; g_ctl.hudRetry = 1; g_ctl.pkeScanHelp = 1; g_ctl.ringClearGone = 1; g_ctl.healthAny = 1; g_ctl.foreNearCm = 18;   // 1.6 (1.7.113: healthAny)
  g_ctl.gunWrapPct = 100; g_ctl.gunFwdCm = 0; g_ctl.gunUpCm = 0; g_ctl.aimGhostOnly = 1; g_ctl.pkeTrigScan = 1; g_ctl.easySprint = 0; g_ctl.sprintLatch = 1; g_ctl.sprintTurnFree = 1; g_ctl.slamTrigger = 1; g_ctl.slamTrigPct = 90; g_ctl.slamBuzzPct = 100; g_ctl.itemGlowPct = 50; g_ctl.slamGesture = 0;   // 1.7
  g_ctl.slamAssist = 1; g_ctl.holsterOnBack = 1; g_ctl.cineGuard = 1; g_ctl.eyeAa = 0; g_ctl.eyeAaSharpPct = 25; g_ctl.cutHoldMs = 2000; g_ctl.cutFade = 1; g_ctl.flatGlowCorners = 1; g_ctl.keepControl = 1; g_ctl.pairSame = 1; g_ctl.hbarWallHide = 1; g_ctl.texAniso = 16; g_ctl.leftUnder = 1; g_ctl.leftUnderCm = 6; g_ctl.leftHanded = 0; g_ctl.controllerLayout = 0; g_ctl.stickAxisForce = -1; g_ctl.seated = 0; g_ctl.seatCm = 0; g_ctl.profileSlot = 1; g_ctl.hbarSizePct = 60; g_ctl.hbarAlphaPct = 45; g_ctl.gunFireFx = 0; g_ctl.trapNoAnim = 1; g_ctl.leftHandDraw = 1; g_ctl.hbarGate = 1; g_ctl.beamDamagePct = 100; g_ctl.damageWatch = 0; g_ctl.aimLive = 1; g_ctl.aimAssistPct = 0; g_ctl.vignettePct = 0; g_ctl.blinkDash = 0; g_ctl.bodyBendPct = 60; g_ctl.bodyBendMaxDeg = 40; g_ctl.leftThumbAnim = 1;   // 1.7.19
  g_ctl.lockGhostOnly = 1; g_ctl.gunFwdCm = 0; g_ctl.pkeFwdCm = 0;   // 1.7.58: exact game-hand anchoring; no guessed fit offset
  g_ctl.collectMarkers = 0; g_ctl.collectMarkerAlways = 0; g_ctl.collectMarkerPct = 100; g_ctl.sprintViaJump = 0; g_ctl.sprintToggle = 1; g_ctl.turnFollowWalk = 1; g_ctl.sprintForce = 0; g_ctl.sprintSpeedPct = 170; g_ctl.sprintSpeedMethod = 3; g_ctl.walkHead = 1; g_ctl.walkCapPct = 100; g_ctl.menuStrict = 1; g_ctl.gunWristCm = 0;   // 1.7.58: reliable nudge speed + exact hand anchor
  g_ctl.startInVr = 1; g_ctl.fadeInMs = 450; g_ctl.sceneFadeMs = 3000; g_ctl.flatCursor = 1; g_ctl.flatCursorPct = 100; g_ctl.menuDimFlat = 1;   // 1.3
  g_ctl.sprintGame = 0; g_ctl.bosonGrip = 0; g_ctl.chestCam = 0; g_ctl.chestCamEvery = 4; g_ctl.chestCamDownCm = 25; g_ctl.chestCamBackCm = 18; g_ctl.chestCamNearCm = 14;   // 1.7.38
  g_ctl.roofAutoCenter = 1; g_ctl.dartPauseStream = 1; g_ctl.gunHandNoAnim = 1; g_ctl.pkeTurnMaxDeg = 25; g_ctl.pkeEaseMs = 450; g_ctl.gameFingers = 1; g_ctl.ghostRing = 1; g_ctl.ogHealth = 1; g_ctl.ringWall = 1; g_ctl.ringFollow = 1; g_ctl.trapHold = 1; g_ctl.pkeAlign = 1; g_ctl.gunFingerOpenPct = 0; g_ctl.pkeAlignPitch = 1; g_ctl.pkeCentre = 1; g_ctl.gunHpPhysics = 1; g_ctl.trapHang = 1; g_ctl.gunHpOnGun = 1; g_ctl.bodyDownBackCm = 12; g_ctl.stationBeamFree = 1; g_ctl.stationBackCm = 18; g_ctl.gunHpHandCut = 0; g_ctl.gunHpRigid = 1; g_ctl.bodyHandsYaw = 1; g_ctl.pkePitchDeg = 0; g_ctl.foreSteady = 1; g_ctl.foreGrab = 1; g_ctl.trigFingerDeg = 40; g_ctl.grabWrap = 1; g_ctl.fingerAnalog = 1; g_ctl.grabOrbitDeg = 110; g_ctl.grabOrbitFollowPct = 10; g_ctl.grabWrapDeg = 30; g_ctl.emptyFingers = 1;
  g_ctl.trapFree = 1; g_ctl.trapFromHand = 1; g_ctl.trapGravity = 1; g_ctl.gunHpBar = 1; g_ctl.gunHpLiquid = 1; g_ctl.ghostHpLiquid = 1; g_ctl.gunHpFwdCm = 25; g_ctl.gunHpUpCm = 2; g_ctl.gunHpSideCm = 0;   /* 1.7.167: on top of the drawn gun, about 24 cm behind its muzzle (was 13 / -4 / -5: below and left of the controller) */ g_ctl.hideBeltPke = 1; g_ctl.pkeGripHeal = 0; g_ctl.pkeLiveGrip = 0; g_ctl.pkeRigidHand = 1; g_ctl.gunLiveGrip = 0; g_ctl.pkeSteadyOnly = 0; g_ctl.pkeSetMatrix = 1; g_ctl.handClean = 1; g_ctl.armReachPct = 120; g_ctl.stairsSmoothMs = 120; g_ctl.stairsRamp = 1; g_ctl.stairsLift = 1; g_ctl.pkeDrawSwap = 1; g_ctl.slimeMuzzle = 1; g_ctl.gunHoldSmoothMs = 0; g_ctl.pkeHoldRpke = 1; g_ctl.slimeLtEdge = 1; g_ctl.slimeRopeFix = 1; g_ctl.pkeCtlRigid = 1; g_ctl.gunFreshHand = 1; g_ctl.gunCtlFollow = 0; g_ctl.pkeFingersAnim = 1;   /* 1.7.71; 1.7.73/1.7.74 values */ g_ctl.gunGripHeal = 0; g_ctl.hideGunGap = 0;   // 1.7.37
  g_ctl.drawAnim = 0;   // 1.7.98 (1.7.99: off - the game has no draw animation in this build, the report showed one stray 70 cm flash)
  g_ctl.gunWaitDraw = 1;   // 1.7.99
  g_ctl.knockComfort = 1; g_ctl.knockMs = 4000; g_ctl.knockWalkPct = 45; g_ctl.knockAimDeg = 4; g_ctl.knockDarkPct = 100;   // 1.7.36
  g_ctl.monitorView = 1; g_ctl.monitorEye = 0; g_ctl.monitorFit = 1; g_ctl.monitorLevel = 1; g_ctl.monitorZoomPct = 100; g_ctl.monitorWidePct = 100; g_ctl.monitorHfovDeg = 115; g_ctl.monitorDownDeg = 10; g_ctl.monitorHandFrame = 1; g_ctl.monitorMenuFill = 1; g_ctl.heldMenu = 1; g_ctl.heldMenuCm = 36; g_ctl.bodyCalmMs = 140; g_ctl.mirrorVr = 1; g_ctl.hbarSmart = 1; g_ctl.pairHands = 1; g_ctl.heldMenuFollow = 1; g_ctl.heldMenuMinCm = 55; g_ctl.pkeGoggles = 1; g_ctl.streamAimGun = 1; g_ctl.pictureTanX1000 = 1428;   // 1.7.48: wider, lower framing on the monitor
  g_ctl.switchHelp = 1; g_ctl.flatSizePct = 100; g_ctl.flatDistCm = 280; g_ctl.flatDropCm = 10; g_ctl.flatCurvePct = 40;   // 1.1
  g_ctl.wandRollDeg = 0;        // 0.58
  g_ctl.gunWeightPct = 150;     // 0.51 (100), 0.58: heavier by default (150), 0.94: back to 100 (the gun has to follow the hand's turn)
  g_ctl.hapticPct = 100;        // 0.51
  g_ctl.hapticPeriodMs = 6;     // 0.51
  g_ctl.stereoSameMoment = 1;   // 0.27: both eyes of a pair show the same game moment
#if GBVR_HEADTRACK
  settings_load();
  audio_boot();                 // 0.69: if the last run ended while the game sound was muted, it is given back
  if (!g_ctl.bodyFollow || !g_ctl.armIk || !g_ctl.realModels || !g_ctl.fullBody)
    log_line("0.61 BODYFIX saved settings had body_follow=%d arm_ik=%d real_models=%d full_body=%d (the 0.60 speed guard saved 'off'): switched back on", (int)g_ctl.bodyFollow, (int)g_ctl.armIk, (int)g_ctl.realModels, (int)g_ctl.fullBody);
  g_ctl.bodyFollow = 1; g_ctl.realModels = 1; g_ctl.fullBody = 1; if (!g_ctl.armIk) g_ctl.armIk = 1;
  g_ctl.autoPause = 0;   // 0.61: forced off even if an older saved file has it on (it opened the game's pause menu). 0.69: menu_on_start is honoured again (settings.cpp resets old saved values once)
  // (0.68: menu_freeze is no longer forced off; settings.cpp turns an old saved 0 on once - the menu pauses the game again)
  crumbs_init();                // 0.86: black box (and the last run's steps into the log)
  safety_after_settings();      // 0.44: did the last run end badly? then step back (SAFETY lines)
  {   // 0.60: memory headroom. 0.58/0.59 logs: pageFileFreeMB 1106 / 1059 (2421 on the run that worked): the game crashed, then hung while a level loaded
    MEMORYSTATUSEX ms; ZeroMemory(&ms, sizeof(ms)); ms.dwLength = sizeof(ms);
    if (GlobalMemoryStatusEx(&ms)) {
      const unsigned commitMB = (unsigned)(ms.ullAvailPageFile >> 20);
      log_line("MEM at start: Windows commit limit %u MB (RAM + page file), commit free %u MB, RAM %u MB, RAM free %u MB - a small page file is why 'commit free' is low", (unsigned)(ms.ullTotalPageFile >> 20), commitMB, (unsigned)(ms.ullTotalPhys >> 20), (unsigned)(ms.ullAvailPhys >> 20));
      const int want = commitMB < 600 ? 1 : commitMB < 900 ? 2 : 4;   // 0.84: the freezes and the crash of 0.80-0.83 happened with 2.6 - 3.6 GB free, so memory was never their cause (was 700 / 1500)
      if (g_ctl.autoQuality && g_ctl.pictureLevel > want) {
        log_line("MEMGUARD only %u MB of Windows commit memory is free (the game needs a lot while a level loads): picture level %d -> %d for this run "
                 "(not saved). Restart the PC / close other programs / let Windows manage the page file for the sharp picture.", commitMB, (int)g_ctl.pictureLevel, want);
        g_guardKeepLevel = g_ctl.pictureLevel; g_guardLoweredTo = want;
        g_ctl.pictureLevel = want;
      } else log_line("MEMGUARD commit memory free %u MB: ok for picture level %d", commitMB, (int)g_ctl.pictureLevel);
    }
  }
  if (mh == MH_OK) { exit_spy_arm(); videoguard_arm(); }   // 0.85 / 0.87
#endif
  if (mh == MH_OK && g_game.hookBytesOK) {
    if (!engine_install_hooks()) g_game.hookBytesOK = 0;  // engine path unavailable: keys ignored
  } else {
    g_game.hookBytesOK = 0;
    log_line("ENGINE hooks NOT installed: game identity/bytes check failed. Camera control disabled; the game runs unmodified.");
  }
#if GBVR_HEADTRACK
  safety_start_heartbeat();
#endif
  log_flush();
  return TRUE;
}

static void ensure_init() { InitOnceExecuteOnce(&g_initOnce, init_once_cb, nullptr, nullptr); }

static FARPROC real(const char* name) {
  ensure_init();
  return g_realD3D11 ? GetProcAddress(g_realD3D11, name) : nullptr;
}

extern "C" BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID) {
  if (reason == DLL_PROCESS_ATTACH) {
    g_selfModule = inst;
    DisableThreadLibraryCalls(inst);
    DWORD n = GetModuleFileNameW(inst, g_selfDir, MAX_PATH);
    while (n > 0 && g_selfDir[n - 1] != L'\\') --n;
    g_selfDir[n] = 0;
#if GBVR_HEADTRACK
    early_startup_guard();
    if (g_startMode) early_install_dxgi_factory();
#endif
  }
  return TRUE;
}

// ---- Typed exports ---------------------------------------------------------
typedef HRESULT(WINAPI* PFN_CreateDevice)(IDXGIAdapter*, D3D_DRIVER_TYPE, HMODULE, UINT, const D3D_FEATURE_LEVEL*,
                                          UINT, UINT, ID3D11Device**, D3D_FEATURE_LEVEL*, ID3D11DeviceContext**);
typedef HRESULT(WINAPI* PFN_CreateDeviceAndSwapChain)(IDXGIAdapter*, D3D_DRIVER_TYPE, HMODULE, UINT,
                                                      const D3D_FEATURE_LEVEL*, UINT, UINT, const DXGI_SWAP_CHAIN_DESC*,
                                                      IDXGISwapChain**, ID3D11Device**, D3D_FEATURE_LEVEL*,
                                                      ID3D11DeviceContext**);

extern "C" HRESULT WINAPI GBVR_D3D11CreateDevice(IDXGIAdapter* a, D3D_DRIVER_TYPE t, HMODULE s, UINT f,
                                                 const D3D_FEATURE_LEVEL* fl, UINT n, UINT sdk, ID3D11Device** dev,
                                                 D3D_FEATURE_LEVEL* outFl, ID3D11DeviceContext** ctx) {
  PFN_CreateDevice fn = (PFN_CreateDevice)real("D3D11CreateDevice");
  if (!fn) return E_FAIL;
  HRESULT hr = fn(a, t, s, f, fl, n, sdk, dev, outFl, ctx);
  log_line("D3D11CreateDevice HRESULT=0x%08x device=%p adapter=%p flags=0x%x", (unsigned)hr,
           dev ? (void*)*dev : nullptr, (void*)a, f);
#if GBVR_HEADTRACK
  if (SUCCEEDED(hr) && dev && *dev) { log_device_video(*dev); log_device_sharing(*dev); }
#endif
  if (SUCCEEDED(hr) && dev && *dev) render_install_factory_hooks(*dev);
  return hr;
}

extern "C" HRESULT WINAPI GBVR_D3D11CreateDeviceAndSwapChain(IDXGIAdapter* a, D3D_DRIVER_TYPE t, HMODULE s, UINT f,
                                                             const D3D_FEATURE_LEVEL* fl, UINT n, UINT sdk,
                                                             const DXGI_SWAP_CHAIN_DESC* sd, IDXGISwapChain** sc,
                                                             ID3D11Device** dev, D3D_FEATURE_LEVEL* outFl,
                                                             ID3D11DeviceContext** ctx) {
  PFN_CreateDeviceAndSwapChain fn = (PFN_CreateDeviceAndSwapChain)real("D3D11CreateDeviceAndSwapChain");
  if (!fn) return E_FAIL;
  HRESULT hr = fn(a, t, s, f, fl, n, sdk, sd, sc, dev, outFl, ctx);
  log_line("D3D11CreateDeviceAndSwapChain HRESULT=0x%08x flags=0x%x", (unsigned)hr, f);
#if GBVR_HEADTRACK
  if (SUCCEEDED(hr) && dev && *dev) log_device_video(*dev);
#endif
  if (SUCCEEDED(hr) && dev && *dev) render_install_factory_hooks(*dev);
  return hr;
}

// ---- Pass-through exports (no float arguments in any of these APIs) ---------
typedef uintptr_t(WINAPI* PFN_Generic)(uintptr_t, uintptr_t, uintptr_t, uintptr_t, uintptr_t, uintptr_t, uintptr_t,
                                       uintptr_t, uintptr_t, uintptr_t, uintptr_t, uintptr_t);
#define GBVR_FORWARD(name)                                                                                     \
  extern "C" uintptr_t WINAPI GBVR_##name(uintptr_t a, uintptr_t b, uintptr_t c, uintptr_t d, uintptr_t e,    \
                                          uintptr_t f, uintptr_t g, uintptr_t h, uintptr_t i, uintptr_t j,    \
                                          uintptr_t k, uintptr_t l) {                                         \
    PFN_Generic fn = (PFN_Generic)real(#name);                                                                \
    return fn ? fn(a, b, c, d, e, f, g, h, i, j, k, l) : (uintptr_t)E_NOTIMPL;                                 \
  }
GBVR_FORWARD(D3D11On12CreateDevice)
GBVR_FORWARD(D3D11CreateDeviceForD3D12)
GBVR_FORWARD(CreateDirect3D11DeviceFromDXGIDevice)
GBVR_FORWARD(CreateDirect3D11SurfaceFromDXGISurface)
GBVR_FORWARD(D3D11CoreCreateDevice)
GBVR_FORWARD(D3D11CoreCreateLayeredDevice)
GBVR_FORWARD(D3D11CoreGetLayeredDeviceSize)
GBVR_FORWARD(D3D11CoreRegisterLayers)
GBVR_FORWARD(EnableFeatureLevelUpgrade)
GBVR_FORWARD(OpenAdapter10)
GBVR_FORWARD(OpenAdapter10_2)
GBVR_FORWARD(D3DPerformance_BeginEvent)
GBVR_FORWARD(D3DPerformance_EndEvent)
GBVR_FORWARD(D3DPerformance_GetStatus)
GBVR_FORWARD(D3DPerformance_SetMarker)
GBVR_FORWARD(D3DKMTCloseAdapter)
GBVR_FORWARD(D3DKMTCreateAllocation)
GBVR_FORWARD(D3DKMTCreateContext)
GBVR_FORWARD(D3DKMTCreateDevice)
GBVR_FORWARD(D3DKMTCreateSynchronizationObject)
GBVR_FORWARD(D3DKMTDestroyAllocation)
GBVR_FORWARD(D3DKMTDestroyContext)
GBVR_FORWARD(D3DKMTDestroyDevice)
GBVR_FORWARD(D3DKMTDestroySynchronizationObject)
GBVR_FORWARD(D3DKMTEscape)
GBVR_FORWARD(D3DKMTGetContextSchedulingPriority)
GBVR_FORWARD(D3DKMTGetDeviceState)
GBVR_FORWARD(D3DKMTGetDisplayModeList)
GBVR_FORWARD(D3DKMTGetMultisampleMethodList)
GBVR_FORWARD(D3DKMTGetRuntimeData)
GBVR_FORWARD(D3DKMTGetSharedPrimaryHandle)
GBVR_FORWARD(D3DKMTLock)
GBVR_FORWARD(D3DKMTOpenAdapterFromHdc)
GBVR_FORWARD(D3DKMTOpenResource)
GBVR_FORWARD(D3DKMTPresent)
GBVR_FORWARD(D3DKMTQueryAdapterInfo)
GBVR_FORWARD(D3DKMTQueryAllocationResidency)
GBVR_FORWARD(D3DKMTQueryResourceInfo)
GBVR_FORWARD(D3DKMTRender)
GBVR_FORWARD(D3DKMTSetAllocationPriority)
GBVR_FORWARD(D3DKMTSetContextSchedulingPriority)
GBVR_FORWARD(D3DKMTSetDisplayMode)
GBVR_FORWARD(D3DKMTSetDisplayPrivateDriverFormat)
GBVR_FORWARD(D3DKMTSetGammaRamp)
GBVR_FORWARD(D3DKMTSetVidPnSourceOwner)
GBVR_FORWARD(D3DKMTSignalSynchronizationObject)
GBVR_FORWARD(D3DKMTUnlock)
GBVR_FORWARD(D3DKMTWaitForSynchronizationObject)
GBVR_FORWARD(D3DKMTWaitForVerticalBlankEvent)
