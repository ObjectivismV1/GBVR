// The VR FPS limit (vr_fps_cap). 1.7.153: any limit at or below the headset's rate now works, and it is locked to the headset's own frames.
//
// The headset shows `displayHz` frames a second; the game can only finish a picture pair on one of them. So a limit means: show a new pair on every
// Nth headset frame (N = divisor). 45 on a 90 Hz headset = every 2nd frame; SteamVR / Virtual Desktop fill the frames in between (reprojection).
// That is the useful case: a game that manages 55..75 of 90 arrives unevenly; held at a steady 45 it is even.
// A limit that does not divide the headset's rate is rounded DOWN to the next rate that does (60 on 90 Hz -> 45), never up.
// How: the wait for the next headset frame (WaitGetPoses) already ends exactly on a headset frame. The limiter only sleeps until just after the
// (N-1)th headset frame since the last pair's wait ended; the normal wait then ends on the Nth. The reference is the wait itself, so nothing drifts.
// Pure math; tests/test_capture.cpp, tests/test_ratecap_stress.cpp.
#pragma once
namespace ratecap {
// 1.7.154: two choices that fit EVERY headset whatever its rate: kHalf = every 2nd headset frame, kThird = every 3rd (stored as 2 and 3).
static const int kHalf = 2, kThird = 3;
// 1.7.158: the menu offers Off and plain numbers 45..120. kHalf / kThird are still understood (an older settings file), just not offered.
static const int kOptions[] = {0, 45, 50, 60, 72, 80, 90, 100, 120};
static const int kOptionCount = (int)(sizeof(kOptions) / sizeof(kOptions[0]));
inline int valid(int fps) { if (fps == kHalf || fps == kThird || fps == 30 || fps == 36 || fps == 40) return fps;   // older numbers still work, they are just not offered
  for (int i = 1; i < kOptionCount; ++i) if (kOptions[i] == fps) return fps; return 0; }
inline int next(int fps, int direction) {
  fps = valid(fps);
  int i = 0;
  while (i < kOptionCount && kOptions[i] != fps) ++i;
  if (i >= kOptionCount) i = 0;   // a legacy half / third value: the step starts from Off
  i += direction < 0 ? -1 : 1;
  if (i < 0) i = 0;
  if (i > kOptionCount - 1) i = kOptionCount - 1;
  return kOptions[i];
}
inline long long interval_ticks(long long frequency, int fps) {
  fps = valid(fps);
  return fps > kThird && frequency > 0 ? (frequency + fps / 2) / fps : 0;
}
// the headset told us a rate we can use (60 Hz Windows MR ... 144 Hz Index and beyond)
inline int rate_known(double displayHz) { return displayHz > 20.0 && displayHz < 400.0; }
// A new pair on every Nth headset frame. 1 = no limit (off, unknown headset rate, or the limit is not below the headset's rate). At most 6.
// A number is rounded to the nearest whole divisor that does not go more than 10 % over it: on a 75 Hz headset "36" means every 2nd frame (37.5),
// on 90 Hz "60" means every 2nd (45), on 144 Hz "72" every 2nd, "45" every 3rd (48).
inline int divisor(double displayHz, int fps) {
  fps = valid(fps);
  if (!fps || !rate_known(displayHz)) return 1;
  if (fps == kHalf || fps == kThird) return fps;
  const double ratio = displayHz / (double)fps;
  int n = (int)ratio;
  if (ratio - (double)n > 0.10 * (double)n) ++n;   // with n frames the rate would be more than 10 % over the limit: one more
  if (n < 1) n = 1;
  if (n > 6) n = 6;
  return n;
}
// 1.7.170 "the FPS option is not working": on a 90 Hz headset only Off and 45 did anything (60, 72, 80 all rounded to 45 or to no limit).
// Now a number that is not a whole share of the headset's rate is PACED: each pair is shown for 1 or 2 (or more) headset frames so the average is the
// number (60 on 90 Hz = 1, 2, 1, 2 ... frames). Whole shares (45 on 90, 60 on 120, 72 on 144) stay perfectly even and are the smoothest choice.
inline double absd_(double x) { return x < 0.0 ? -x : x; }
inline int fractional(double displayHz, int fps) {
  fps = valid(fps);
  if (fps <= kThird || !rate_known(displayHz)) return 0;
  if (displayHz / (double)fps <= 1.10) return 0;              // 1.7.172: at, over or within 10 % of the headset's rate: no limit (72 on a 75 Hz headset would only add a stutter three times a second)
  const int n = divisor(displayHz, fps);
  return absd_(displayHz / (double)n - (double)fps) > 0.03 * (double)fps;   // the whole share is not close to the number: pace it
}
inline double effective_fps(double displayHz, int fps) {
  if (fractional(displayHz, fps)) return (double)valid(fps);
  const int n = divisor(displayHz, fps); return displayHz > 0.0 ? displayHz / (double)n : 0.0; }
// 1.7.172 recheck: the pacer keeps a SCHEDULE (when the next pair is due), not a fixed 1, 2, 1, 2 pattern. The 1.7.170 pattern never made up a missed
// frame: a PC that sometimes needs two headset frames for a pair (the report: 71 of 90 Hz) got about 54 FPS from the "60" limit, unevenly. With a
// schedule a late pair is followed by one without a sleep, so the average is the limit whenever the PC can do it, and never above it.
// frames_for(): headset frames this pair should last, counted from lastWaitEnd (when the last pair's wait for the headset ended). Call once per pair.
struct Pacer {
  double next; int have;   // when this pair's wait should end (ticks)
  void reset() { next = 0.0; have = 0; }
};
inline int frames_for(Pacer& p, long long lastWaitEnd, long long frequency, double displayHz, int fps) {
  if (!fractional(displayHz, fps)) { p.have = 0; return divisor(displayHz, fps); }
  if (frequency <= 0 || lastWaitEnd <= 0) { p.have = 0; return 1; }
  const double period = (double)frequency / displayHz, step = (double)frequency / (double)valid(fps);
  if (!p.have || !(p.next == p.next)) { p.next = (double)lastWaitEnd; p.have = 1; }
  p.next += step;
  double g = (p.next - (double)lastWaitEnd) / period;       // headset frames from the last pair to where the schedule wants this one
  const double gMax = step / period + 1.0;
  if (!(g == g)) { g = step / period; p.next = (double)lastWaitEnd + step; }
  if (g < -1.0) { g = -1.0; p.next = (double)lastWaitEnd - period; }            // at most one headset frame is ever made up (a long slow stretch or a pause is forgotten)
  if (g > gMax) { g = gMax; p.next = (double)lastWaitEnd + gMax * period; }     // the clock jumped or the limiter was idle: never a longer wait than one pair + one frame
  int n = (int)(g + 0.5);
  if (n < 1) n = 1;
  if (n > 6) n = 6;
  return n;
}
// How many ticks to sleep now. lastWaitEnd: when the last pair's wait for the headset ended (0 = none yet). Never more than (N-1) headset frames:
// a wrong clock, a long pause or a changed rate can only ever cost that much once.
inline long long sleep_ticks_n(long long now, long long lastWaitEnd, long long frequency, double displayHz, int n) {
  if (!rate_known(displayHz)) return 0;
  if (n <= 1 || frequency <= 0 || lastWaitEnd <= 0 || now < lastWaitEnd) return 0;
  const double period = (double)frequency / displayHz;
  const long long target = lastWaitEnd + (long long)(period * ((double)(n - 1) + 0.15));   // just past the (N-1)th headset frame
  if (now >= target) return 0;                       // the game was slow enough by itself
  const long long d = target - now, most = (long long)(period * (double)(n - 1) + period * 0.15);
  return d > most ? 0 : d;
}
inline long long sleep_ticks(long long now, long long lastWaitEnd, long long frequency, double displayHz, int fps) {
  return sleep_ticks_n(now, lastWaitEnd, frequency, displayHz, divisor(displayHz, fps));
}
// The headset's rate is not known (a driver that does not report it): a plain timer, one pair per 1/fps seconds since the last one was let through.
// Never sleeps longer than one interval. Half / third need the rate and do nothing here.
inline long long sleep_ticks_free(long long now, long long lastLetThrough, long long frequency, int fps) {
  const long long iv = interval_ticks(frequency, fps);
  if (iv <= 0 || lastLetThrough <= 0 || now < lastLetThrough) return 0;
  const long long target = lastLetThrough + iv;
  if (now >= target) return 0;
  return target - now > iv ? 0 : target - now;
}
}

namespace ratecap {
// 1.7.158: the divisor for a menu number (declared after next so the menu can use both)
inline int divisor(double displayHz, int fps);
// The menu step on THIS headset: skips every number that would give the same result as the one shown (or no limit at all), so each click changes the real rate.
// Unknown headset rate: plain next(). Never leaves the list; at the ends it stays.
inline int next_for(double displayHz, int fps, int direction) {
  if (!rate_known(displayHz)) return next(fps, direction);
  const int cur = valid(fps);
  // 1.7.170: steps by what you really get: every number below the headset's rate is offered (paced when it is not a whole share)
  const int curEff = cur ? (int)(effective_fps(displayHz, cur) + 0.5) : 0;
  int v = cur;
  for (int guard = 0; guard < kOptionCount + 2; ++guard) {
    const int nx = next(v, direction);
    if (nx == v) return cur;                       // end of the list: stay
    v = nx;
    if (v == 0) return 0;                          // Off is always a real change
    const int limits = divisor(displayHz, v) > 1 || fractional(displayHz, v);
    if (limits && (int)(effective_fps(displayHz, v) + 0.5) != curEff) return v;
  }
  return cur;
}
}
