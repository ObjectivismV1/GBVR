// 0.98 refresh-rate and sharpness arithmetic for the log (no Windows dependency; unit-tested in tests/test_rate.cpp).
//
// The Quest 3 can run at 72, 80, 90 and 120 Hz in Virtual Desktop. The game must finish a pair of eye pictures (the PC's work for one pair, plus the tail on the
// graphics card) inside one display period, or SteamVR fills the gap with guessed frames. These helpers tell, from the measured numbers, which of those rates
// would fit. Nothing here changes behaviour: it is the evidence for the next version.
#pragma once
#include "vmath.h"

namespace rate {

static const double kTailMs = 4.0;      // graphics-card time after the game's work (RATE ADVICE in 0.45 used 3-4 ms)
static const double kSpareMs = 0.5;     // some room so a normal hiccup does not break the frame

inline double period_ms(double hz) { return hz > 1.0 ? 1000.0 / hz : 0.0; }
inline double margin_ms(double hz, double workMs, double tailMs) { return period_ms(hz) - workMs - tailMs; }
inline int fits(double hz, double workMs, double tailMs) { return hz > 1.0 && margin_ms(hz, workMs, tailMs) >= kSpareMs; }

// the highest of the candidate rates (given high to low) that fits; 0 when none does
inline int best_fit(double workMs, double tailMs, const int* cand, int n) {
  for (int i = 0; i < n; ++i) if (fits((double)cand[i], workMs, tailMs)) return cand[i];
  return 0;
}

// how many pixels the eye picture has compared with what SteamVR recommends (area), and per side
inline double area_ratio(double w, double h, double rw, double rh) { return (rw > 0.5 && rh > 0.5 && w > 0.5 && h > 0.5) ? (w * h) / (rw * rh) : 0.0; }
inline double side_ratio(double w, double h, double rw, double rh) { const double a = area_ratio(w, h, rw, rh); return a > 0.0 ? vm::dsqrt(a) : 0.0; }

// the work budget for "work over budget" counts: one display period, never below 5 ms nor above 20 ms (an unknown rate keeps the 90 Hz period of 0.43)
inline double work_budget_ms(double hz) {
  if (!(hz > 30.0 && hz < 400.0)) return 11.1;
  double p = period_ms(hz);
  if (p < 5.0) p = 5.0;
  if (p > 20.0) p = 20.0;
  return p;
}

}  // namespace rate
