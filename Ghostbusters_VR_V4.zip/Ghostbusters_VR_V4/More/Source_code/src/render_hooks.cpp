// Render-thread side: swap-chain Present hook. Once per presented frame it
//  - polls hotkeys (only while the game window is focused),
//  - enforces focus / pause-menu-flag / capture gates,
//  - (0.17) samples the headset and publishes the pose snapshot,
//  - (0.21) runs the headset session: eye textures / flat screen before the
//    game's Present, compositor frame wait after it (stereo.cpp),
//  - writes periodic counters to the log.
#include "gbvr.h"
#include "layout.h"
#include "picturemath.h"
#include "MinHook.h"
#include <d3d11.h>
#include <dxgi1_2.h>

Control g_ctl;

typedef HRESULT(STDMETHODCALLTYPE* PFN_Present)(IDXGISwapChain*, UINT, UINT);
typedef HRESULT(STDMETHODCALLTYPE* PFN_CreateSwapChain)(IDXGIFactory*, IUnknown*, DXGI_SWAP_CHAIN_DESC*, IDXGISwapChain**);
typedef HRESULT(STDMETHODCALLTYPE* PFN_CreateSwapChainForHwnd)(IDXGIFactory2*, IUnknown*, HWND, const DXGI_SWAP_CHAIN_DESC1*,
                                                                const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*, IDXGIOutput*,
                                                                IDXGISwapChain1**);
static PFN_Present o_present;
static PFN_CreateSwapChain o_createSwapChain;
static PFN_CreateSwapChainForHwnd o_createSwapChainForHwnd;
static volatile LONG g_factoryHooked, g_presentHooked;

static const double kCaptureSeconds = 180.0;   // detailed capture window after first activation
volatile LONG g_reportNow;   // 1.7.25: set by the slam helper after a try: the next report tick writes a full dump
static const LONG kReportEvery = 180;          // presented frames between counter reports

// ---------------------------------------------------------------------------
LONG control_mode() { return g_ctl.mode; }
static LONG g_presentCount;
LONG render_present_count() { return g_presentCount; }

void control_reset(const char* reason) {
  LONG prev = InterlockedExchange(&g_ctl.mode, MODE_OFF);
  if (prev != MODE_OFF) log_line("ENGINEYAW reset: %s (frame=%d)", reason, (int)g_ctl.worldFrames);
  if (InterlockedExchange(&g_ctl.firstPerson, 0)) log_line("FIRSTPERSON off: %s (frame=%d)", reason, (int)g_ctl.worldFrames);
  InterlockedExchange(&g_ctl.stereoWanted, 0);
#if GBVR_HEADTRACK
  if (prev == MODE_HEAD) vr_invalidate_snapshot();
#endif
}

int game_window_focused() {
  HWND game = g_ctl.gameHwnd;
  if (!game) return 0;
  HWND fg = GetForegroundWindow();
  if (!fg) return 0;
  if (fg == game || GetAncestor(fg, GA_ROOTOWNER) == GetAncestor(game, GA_ROOTOWNER)) return 1;
  DWORD pid = 0;   // 0.55: any window of the game's own process counts (a child / helper window with the focus)
  GetWindowThreadProcessId(fg, &pid);
  return pid != 0 && pid == GetCurrentProcessId();
}

static void start_capture_if_needed() {
  if (!g_ctl.probeData) return;
  if (InterlockedCompareExchange(&g_ctl.captureStarted, 1, 0) == 0) {
    g_ctl.captureStartQpc = qpc_now();
    log_line("CAPTURE started frame=%d window=%d seconds", (int)g_ctl.worldFrames, (int)kCaptureSeconds);
  }
}

// ---- Hotkeys ----------------------------------------------------------------
static SHORT g_prevKeys[20];
static int key_pressed(int idx, int vk) {
  SHORT now = GetAsyncKeyState(vk);
  int down = (now & 0x8000) != 0, was = (g_prevKeys[idx] & 0x8000) != 0;
  g_prevKeys[idx] = now;
  return down && !was;
}

#if GBVR_HEADTRACK
static volatile LONG g_headPending;   // F9 pressed, waiting for SteamVR
static volatile LONG g_userVrOff;     // 1.3: the player switched the headset view off with F4 (the automatic start must not bring it back)

static void picture_level_key() {
  LONG v = g_ctl.pictureLevel;
  if (v < picture::kLevelMin || v > picture::kLevelMax) v = picture::kLevelMin;
  if (g_pictureOff) {
    // The bigger picture was switched off after a start that failed. The
    // first press only allows it again (same level); further presses step.
    startup_picture_retry();
    log_line("PICTURE level %d = %s will be tried again at the next start of the game (Insert).", (int)v,
             picture::level_name((int)v));
  } else {
    v = v >= picture::kLevelMax ? picture::kLevelMin : v + 1;
    log_line("PICTURE level %d = %s chosen (Insert). It is used from the next start of the game; this run stays at "
             "level %d.%s", (int)v, picture::level_name((int)v), modes_active_level(),
             modes_installed() ? "" : " NOTE: the picture hook is not installed in this run (see STARTUP / PICTURE lines).");
  }
  InterlockedExchange(&g_ctl.pictureLevel, v);
  InterlockedExchange(&g_ctl.pictureLines, 0);   // 1.7.117: the Insert key goes back to the plain levels
  safety_reset_health();       // 0.44: the player decides again: the series of bad runs starts over
  settings_changed();
  settings_save_if_changed();  // at once: the next thing the player does is close the game
}
#endif

#if GBVR_HEADTRACK
// 0.55 the game's window title says what the probe is doing, so a glance at the title bar shows whether it loaded and saw F4.
static void title_status(const wchar_t* what) {
  HWND w = g_ctl.gameHwnd;
  if (!w) return;
  static wchar_t base[160];
  static int haveBase;
  if (!haveBase) {
    DWORD_PTR r = 0;
    wchar_t t[160]; t[0] = 0;
    if (!SendMessageTimeoutW(w, WM_GETTEXT, 160, (LPARAM)t, SMTO_ABORTIFHUNG | SMTO_BLOCK, 100, &r)) return;
    t[159] = 0;
    if (lstrlenW(t) > 70) t[70] = 0;
    lstrcpyW(base, t);
    haveBase = 1;
  }
  wchar_t out[260];
  wsprintfW(out, L"%s   [VR mod " GBVR_WIDE_VERSION L": %s]", base, what);
  DWORD_PTR r = 0;
  SendMessageTimeoutW(w, WM_SETTEXT, 0, (LPARAM)out, SMTO_ABORTIFHUNG | SMTO_BLOCK, 100, &r);
}

static void title_update() {
  static int last = -1;
  int st = g_ctl.stereoActive ? 3 : g_ctl.stereoWanted ? 2 : 1;
  // 0.67: a start that SteamVR refused shows in the title in plain words (the full story is in the STEAMVR log lines)
  const char* vs = vr_capi_status();
  if (st == 1 && lstrlenA(vs) > 14) {
    char head[16];
    lstrcpynA(head, vs, 15);
    if (!lstrcmpA(head, "VR init failed")) st = 4;
  }
  if (st == last) return;
  last = st;
  if (st == 4) {
    char sb[111];
    lstrcpynA(sb, vs, (int)sizeof(sb));
    wchar_t what[200];
    wsprintfW(what, L"headset NOT started: %hs   (F4 = try again)", sb);
    title_status(what);
    return;
  }
  title_status(st == 3 ? L"headset ON  (F12 = menu)" : st == 2 ? L"starting the headset..." : L"loaded - press F4 for the headset");
}


// 1.3 start in VR: the headset view is asked for by itself (the same as pressing F4) a moment after the game's first frames, as soon as SteamVR
// sees a headset (or after 25 s anyway, which lets SteamVR start). A start that failed is tried once more after 20 s. F4 off keeps it off.
static void auto_start_vr(LONG frame) {
  static int s_state;               // 0 waiting for the first ask, 1 asked, 2 waiting to ask again, 4 asked the second time, 3 finished
  static ULONGLONG s_t0, s_askedAt, s_lastCheck;
  static int s_waitLogged, s_tries;
  if (s_state == 3 || !g_ctl.startInVr || !g_game.hookBytesOK) return;
  if (g_userVrOff) { if (s_state != 3) log_line("STARTVR the player switched the headset view off (F4): no automatic start"); s_state = 3; return; }
  if (g_ctl.stereoActive) { log_line("STARTVR the headset view is running (try %d)", s_tries); s_state = 3; return; }
  const ULONGLONG now = GetTickCount64();
  if (!s_t0) { if (frame < 20) return; s_t0 = now; }
  if (s_state == 0 || s_state == 2) {
    if (s_state == 2 && now - s_askedAt < 20000ull) return;
    if (now - s_lastCheck < 1000ull) return;
    s_lastCheck = now;
    const int hmd = vr_capi_hmd_present(g_selfDir);
    const double waited = (double)(now - s_t0) / 1000.0;
    if (s_state == 0 && hmd != 1 && waited < 25.0) {
      if (!s_waitLogged) { s_waitLogged = 1; log_line("STARTVR waiting for SteamVR to see the headset (VR_IsHmdPresent=%d); the headset view starts by itself when it does, or after 25 s", hmd); }
      return;
    }
    ++s_tries;
    start_capture_if_needed();
    InterlockedExchange(&g_headPending, 0);
    InterlockedExchange(&g_ctl.stereoWanted, 1);
    log_line("STEREO requested (start in VR). frame=%d", (int)g_ctl.worldFrames);
    log_line("STARTVR asked for the headset view by itself: try %d, headset present=%d, game running for %.1f s, present frame %d", s_tries, hmd, waited, (int)frame);
    title_update();
    s_askedAt = now;
    s_state = s_state == 0 ? 1 : 4;
    return;
  }
  // asked: did it start? (stereoWanted stays 1 while it starts and while it runs; it goes back to 0 when SteamVR refused)
  if (g_ctl.stereoWanted) return;
  if (s_state == 1) {
    s_state = 2; s_askedAt = now;
    log_line("STARTVR the first start did not work (%s): trying once more in 20 s", vr_capi_status());
  } else {
    s_state = 3;
    log_line("STARTVR gave up (%s): press F4 on the keyboard when SteamVR and the headset are ready", vr_capi_status());
  }
}

#else
static void title_update() {}
static void auto_start_vr(LONG) {}
#endif

static void poll_keys() {
  title_update();
  if (!game_window_focused()) {  // keep edge state clean while unfocused
    static int s_noFocusNotes;
    if ((GetAsyncKeyState(VK_F4) & 0x8000) && s_noFocusNotes < 5) {
      ++s_noFocusNotes;
      log_line("KEY F4 is down but the game window is not the active window (active=%p game=%p): click the game window first", (void*)GetForegroundWindow(), (void*)g_ctl.gameHwnd);
    }
    for (int i = 0; i < 20; ++i) g_prevKeys[i] = 0;
    return;
  }
  int f6 = key_pressed(0, VK_F6), f7 = key_pressed(1, VK_F7), f8 = key_pressed(2, VK_F8);
  int f10 = key_pressed(4, VK_F5), f11 = key_pressed(5, VK_F11);  // F5 toggle (F10 is a Windows menu key), F11 height
  // 1.7.65 player edition: only F4 (headset view on/off), F9 / Ctrl+F9 (recenter / measure height) and F12 (menu) work for players.
  // Every other test key is developer-only and needs probe_data=1 in gbvr_settings.txt.
  const int devKeys = g_ctl.probeData != 0;
  if (!devKeys) f6 = f7 = f8 = f10 = f11 = 0;
#if GBVR_HEADTRACK
  int f9 = key_pressed(3, VK_F9);
  int f4 = key_pressed(6, VK_F4), f3 = key_pressed(7, VK_F3);
  int pgUp = key_pressed(8, VK_PRIOR), pgDn = key_pressed(9, VK_NEXT);
  int home = key_pressed(10, VK_HOME), end = key_pressed(11, VK_END), ins = key_pressed(12, VK_INSERT);
  int f2 = key_pressed(13, VK_F2), del = key_pressed(14, VK_DELETE), f1 = key_pressed(15, VK_F1);
  if (!devKeys) f3 = pgUp = pgDn = home = end = ins = f2 = del = f1 = 0;
  if (shot_busy()) f7 = f8 = f4 = del = f2 = 0;  // a picture is being taken (about a third of a second)
  if (ins) picture_level_key();  // works everywhere (menus too); used at the next start of the game
  if (GetAsyncKeyState(VK_MENU) & 0x8000) f4 = 0;  // Alt+F4 belongs to Windows
#else
  int f4 = 0, f3 = 0;
#endif
  if (!g_game.hookBytesOK) {
    if (f6 || f7 || f8 || f10 || f4) log_line("KEY ignored: engine hooks are not installed (game identity check failed).");
    return;
  }
#if GBVR_HEADTRACK
  if (f4) {  // 0.21: headset 3D
    int ctrl = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0, shift = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
    if (!devKeys) ctrl = shift = 0;   // Ctrl+F4 / Shift+F4 (eye separation, eye swap) are developer-only
    if (ctrl) {  // eye separation: Ctrl+F4 +10 %, Ctrl+Shift+F4 -10 % (0 = no depth, 100 = real, 200 max)
      LONG v = g_ctl.stereoStrengthPct + (shift ? -10 : 10);
      if (v < 0) v = 0;
      if (v > 200) v = 200;
      InterlockedExchange(&g_ctl.stereoStrengthPct, v);
      settings_changed();
      log_line("STEREO eye separation %d %% (%sCtrl+F4) frame=%d", (int)v, shift ? "Shift+" : "", (int)g_ctl.worldFrames);
      engine_request_sample();
    } else if (shift) {  // diagnostic: exchange the two eye positions
      LONG v = g_ctl.swapEyes ? 0 : 1;
      InterlockedExchange(&g_ctl.swapEyes, v);
      log_line("STEREO eyes %s (Shift+F4) frame=%d", v ? "SWAPPED" : "normal", (int)g_ctl.worldFrames);
      engine_request_sample();
    } else if (g_ctl.stereoWanted) {
      InterlockedExchange(&g_ctl.stereoWanted, 0);
      InterlockedExchange(&g_userVrOff, 1);
      log_line("STEREO off requested (F4). frame=%d", (int)g_ctl.worldFrames);
    } else {
      InterlockedExchange(&g_userVrOff, 0);
      start_capture_if_needed();
      InterlockedExchange(&g_headPending, 0);
      InterlockedExchange(&g_ctl.stereoWanted, 1);
      log_line("STEREO requested (F4). frame=%d", (int)g_ctl.worldFrames);
      title_update();
    }

  }
  if (f2 && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {  // 0.33 Ctrl+F2: Quest controllers act as the Xbox pad (2 beeps) / off (1)
    f2 = 0;
    if (!xinput_bridge_available()) {
      log_line("CONTROLLERS bridge is not available in this run (see the HOOK xinput-bridge line at the start); Ctrl+F2 ignored");
    } else {
      LONG v = g_ctl.padEnabled ? 0 : 1;
      InterlockedExchange(&g_ctl.padEnabled, v);
      settings_changed();
      log_line("CONTROLLERS %s (Ctrl+F2) frame=%d", v ? "on: the controllers are the game's pad" : "off", (int)g_ctl.worldFrames);
    }
  }
  if (f2 && (GetAsyncKeyState(VK_SHIFT) & 0x8000)) {  // 0.32 Shift+F2: the beam follows the head (2 beeps) / the mouse (1)
    f2 = 0;
    if (!head_aim_available()) {
      log_line("HEADAIM is not available in this run (see the HOOK aim-direction-store line at the start); Shift+F2 ignored");
    } else {
      LONG v = (g_ctl.headAim + 1) % 3;   // mouse (1 beep) -> head (2) -> hand (3)
      InterlockedExchange(&g_ctl.headAim, v);
      settings_changed();
      log_line("HEADAIM source %d (Shift+F2): %s frame=%d", (int)v,
               v == 2 ? "the beam follows your right hand (both hands when both grips are held); the head while no controller is tracked"
                      : v == 1 ? "the beam and the aiming circle follow your head" : "the beam follows the mouse",
               (int)g_ctl.worldFrames);
    }
  }
  if (f2) {  // 0.27: picture of what each eye sees, for diagnosis
    if (g_ctl.stereoActive) { shot_request(); log_line("SHOT requested (F2). frame=%d", (int)g_ctl.worldFrames); engine_float_mark("F2"); }
    else log_line("SHOT ignored (F2): only in the headset view (F4)");
  }
  if (f1 && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {  // 0.29 Ctrl+F1: overlay placed for both eyes (2 beeps) / as the game draws it (1)
    f1 = 0;
    if (!hud_available()) {
      log_line("HUD placement is not available in this run (see the HOOK overlay line at the start); Ctrl+F1 ignored");
    } else {
      LONG v = g_ctl.hudMode ? 0 : 1;
      InterlockedExchange(&g_ctl.hudMode, v);
      settings_changed();
      log_line("HUD %s (Ctrl+F1) frame=%d", v ? "placed in front of you for both eyes" : "drawn as the game draws it",
               (int)g_ctl.worldFrames);
    }
  }
  if (f1 && !body_hiding_available()) {  // 0.28: the hooks did not match this game: say so instead of pretending
    log_line("BODY hiding is not available in this run (see the BODY / HOOK lines at the start); F1 ignored");
    f1 = 0;
  }
  if (f1 && (GetAsyncKeyState(VK_SHIFT) & 0x8000)) {  // 0.30 Shift+F1: wand hidden with the body (2 beeps) / shown (1)
    f1 = 0;
    LONG v = g_ctl.hideWand ? 0 : 1;
    InterlockedExchange(&g_ctl.hideWand, v);
    settings_changed();
    log_line("BODY wand %s while the body is hidden (Shift+F1) frame=%d", v ? "hidden" : "shown", (int)g_ctl.worldFrames);
  }
  if (f1) {  // 0.51: the game's own models (body, pack, hose, wand) shown (1 beep) <-> hidden with our placeholder hands and wand (2 beeps)
    LONG v = g_ctl.realModels ? 0 : 1;
    InterlockedExchange(&g_ctl.realModels, v);
    if (!v) { InterlockedExchange(&g_ctl.hideBody, 1); InterlockedExchange(&g_ctl.hideWand, 1); }
    settings_changed();
    log_line("BODY %s (F1) frame=%d (wand %s, shadow %s)", v ? "the game's own models shown" : "own body hidden, placeholder hands and wand",
             (int)g_ctl.worldFrames, v ? "moved to your hand" : g_ctl.hideWand ? "hidden too" : "shown",
             g_ctl.hideShadow && body_shadow_hiding_available() ? "hidden too" : g_ctl.hideShadow ? "kept (not available)" : "kept");
  }
  if (del && g_ctl.stereoWanted) {  // 0.27: both eyes from the same game moment on / off (for comparison)
    LONG v = g_ctl.stereoSameMoment ? 0 : 1;
    InterlockedExchange(&g_ctl.stereoSameMoment, v);
    settings_changed();
    log_line("STEREO same moment for both eyes %s (Delete) frame=%d", v ? "on" : "off", (int)g_ctl.worldFrames);
  }
  if ((home || end) && (GetAsyncKeyState(VK_SHIFT) & 0x8000)) {  // 0.33 Shift+Home / Shift+End: pointing direction tilted up / down, 2.5 degrees
    LONG v = g_ctl.handPitchDeci + (home ? 25 : -25);
    if (v > 600) v = 600;
    if (v < -600) v = -600;
    InterlockedExchange(&g_ctl.handPitchDeci, v);
    settings_changed();
    log_line("CONTROLLERS hand tilt %d.%d degrees (Shift+Home/End)", (int)(v / 10), (int)(v < 0 ? -v : v) % 10);
    home = end = 0;
  }
  if ((home || end) && g_ctl.stereoWanted) {  // 0.26: world size, 5 % steps (60 .. 160)
    LONG v = g_ctl.worldPct + (home ? 5 : -5);
    if (v < 60) v = 60;
    if (v > 160) v = 160;
    InterlockedExchange(&g_ctl.worldPct, v);
    settings_changed();
    log_line("STEREO world size %d %% (%s) frame=%d", (int)v, home ? "Home" : "End", (int)g_ctl.worldFrames);
    engine_request_sample();
  }
  if ((pgUp || pgDn) && g_ctl.stereoWanted && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {  // 0.29: overlay size, 10 % steps (50 .. 200)
    LONG v = g_ctl.hudSizePct + (pgUp ? 10 : -10);
    if (v < 50) v = 50;
    if (v > 200) v = 200;
    InterlockedExchange(&g_ctl.hudSizePct, v);
    settings_changed();
    log_line("HUD size %d %% (%sCtrl+%s) frame=%d", (int)v, "", pgUp ? "PageUp" : "PageDown", (int)g_ctl.worldFrames);
    pgUp = pgDn = 0;
  }
  if ((pgUp || pgDn) && g_ctl.stereoWanted) {  // 0.25: player height, 5 % steps (70 .. 150)
    LONG v = g_ctl.sizePct + (pgUp ? 5 : -5);
    if (v < 70) v = 70;
    if (v > 150) v = 150;
    InterlockedExchange(&g_ctl.sizePct, v);
    settings_changed();
    log_line("STEREO player height %d %% (%s) frame=%d", (int)v, pgUp ? "PageUp" : "PageDown", (int)g_ctl.worldFrames);
    engine_request_sample();
  }
  if (f3 && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {  // 0.34 Ctrl+F3: gloved hands and proton wand at the controllers on (2 beeps) / off (1)
    f3 = 0;
    LONG v = g_ctl.handModel ? 0 : 1;
    InterlockedExchange(&g_ctl.handModel, v);
    settings_changed();
    log_line("HANDS %s (Ctrl+F3) frame=%d", v ? "on" : "off", (int)g_ctl.worldFrames);
  }
  if (key_pressed(18, 'H') && (GetAsyncKeyState(VK_CONTROL) & 0x8000) && devKeys) {  // 0.51 Ctrl+H: motor test - right hand 4 strengths, left hand 4 strengths, both (log HAPTIC)
    haptics_test(1);
  }
  if (key_pressed(17, VK_PAUSE) && devKeys) {  // 0.48 Pause: mark this moment in the log (a snapshot of the player is written too)
    probe_mark("Pause key");
  }
  const int f12 = key_pressed(16, VK_F12);
  if (f12 && !(devKeys && (GetAsyncKeyState(VK_CONTROL) & 0x8000))) vrmenu_toggle("F12");   // 0.53 F12: the in-VR menu on/off
  if (f12 && devKeys && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {  // 0.42 Ctrl+F12: reverse the menu pointer's up/down (2 beeps) / normal (1)
    LONG v = g_ctl.menuFlip ? 0 : 1;
    InterlockedExchange(&g_ctl.menuFlip, v);
    settings_changed();
    log_line("MENU pointer vertical direction %s (Ctrl+F12) frame=%d", v ? "REVERSED" : "normal", (int)g_ctl.worldFrames);
  }
  if (f11 && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {  // 0.38 Ctrl+F11: holster feature on (2 beeps) / off (1)
    f11 = 0;
    LONG v = g_ctl.holster ? 0 : 1;
    InterlockedExchange(&g_ctl.holster, v);
    settings_changed();
    log_line("HOLSTER feature %s (Ctrl+F11) frame=%d", v ? "on" : "off", (int)g_ctl.worldFrames);
  }
  if (f3) {  // 0.21: head position (leaning) on/off, used in the headset view only
    LONG v = g_ctl.headMove ? 0 : 1;
    InterlockedExchange(&g_ctl.headMove, v);
    settings_changed();
    if (v && g_ctl.stereoActive) InterlockedExchange(&g_ctl.recenterRequest, 1);  // start from "no offset"
    log_line("STEREO head movement %s (F3) frame=%d", v ? "on" : "off", (int)g_ctl.worldFrames);
    engine_request_sample();
  }
#endif
  if (f10) {  // first-person eye test, independent of the orientation mode
    start_capture_if_needed();
    LONG was = g_ctl.firstPerson;
    InterlockedExchange(&g_ctl.firstPerson, was ? 0 : 1);
    log_line("FIRSTPERSON %s (F5) height=%.2f forward=%.2f near=%.2f frame=%d", was ? "off" : "on",
             g_ctl.eyeHeightCenti / 100.0, g_ctl.eyeForwardCenti / 100.0, g_ctl.nearCenti / 100.0,
             (int)g_ctl.worldFrames);
    engine_request_sample();
  }
  if (f11 && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {  // near plane: Ctrl+F11 +0.05, Ctrl+Shift+F11 -0.05
    int down = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
    LONG n = g_ctl.nearCenti + (down ? -5 : 5);
    if (n > 150) n = 150;
    if (n < 8) n = 8;
    InterlockedExchange(&g_ctl.nearCenti, n);
    settings_changed();
    log_line("FIRSTPERSON near plane %.2f (%sCtrl+F11) frame=%d", n / 100.0, down ? "Shift+" : "", (int)g_ctl.worldFrames);
    engine_request_sample();
    f11 = 0;
  }
  if (f11) {  // eye height: F11 +0.25 ft, Shift+F11 -0.25 ft (1.00 .. 8.00)
    int down = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
    LONG h = g_ctl.eyeHeightCenti + (down ? -25 : 25);
    if (h > 800) h = 800;
    if (h < 100) h = 100;
    InterlockedExchange(&g_ctl.eyeHeightCenti, h);
    settings_changed();
    log_line("FIRSTPERSON eye height %.2f (%sF11) frame=%d", h / 100.0, down ? "Shift+" : "", (int)g_ctl.worldFrames);
    engine_request_sample();
  }
  if (f6) {
#if GBVR_HEADTRACK
    InterlockedExchange(&g_headPending, 0);
#endif
    InterlockedExchange(&g_ctl.mode, MODE_OFF);
    InterlockedExchange(&g_ctl.firstPerson, 0);
    InterlockedExchange(&g_ctl.stereoWanted, 0);
    log_line("ENGINEYAW, HEADTRACK, FIRSTPERSON and STEREO disabled (F6). frame=%d", (int)g_ctl.worldFrames);
#if GBVR_HEADTRACK
    vr_invalidate_snapshot();
#endif
    return;
  }
  if ((f7 || f8) && g_ctl.stereoWanted) {  // 0.24: in the headset view these switch the two new features
    if (f7) {
      LONG v = g_ctl.stereoWide ? 0 : 1;
      InterlockedExchange(&g_ctl.stereoWide, v);
      settings_changed();
      log_line("STEREO sharp mode %s (F7) frame=%d", v ? "on" : "off", (int)g_ctl.worldFrames);
    }
    if (f8) {
      LONG v = g_ctl.stereoPair ? 0 : 1;
      InterlockedExchange(&g_ctl.stereoPair, v);
      settings_changed();
      log_line("STEREO smooth mode (both eyes every frame) %s (F8) frame=%d", v ? "on" : "off", (int)g_ctl.worldFrames);
    }
    engine_request_sample();
    f7 = f8 = 0;
  }
  if (f7 || f8) {
#if GBVR_HEADTRACK
    InterlockedExchange(&g_headPending, 0);
    vr_invalidate_snapshot();
#endif
    start_capture_if_needed();
    InterlockedExchange(&g_ctl.manualCentiDeg, f7 ? 1000 : -1000);
    InterlockedExchange(&g_ctl.mode, MODE_MANUAL);
    log_line("ENGINEYAW enabled: %s10 degrees (%s). frame=%d", f7 ? "+" : "-", f7 ? "F7" : "F8", (int)g_ctl.worldFrames);
    engine_request_sample();
    return;
  }
#if GBVR_HEADTRACK
  if (f9 && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {   // 0.52 Ctrl+F9: measure the real height now (stand straight)
    InterlockedExchange(&g_ctl.calibrateRequest, 1);
    log_line("CALIBRATE requested (Ctrl+F9): stand straight and look ahead, measuring for 1.5 seconds. frame=%d", (int)g_ctl.worldFrames);
    f9 = 0;
  }
  if (f9) {
    start_capture_if_needed();
    if (g_ctl.mode == MODE_HEAD || g_ctl.stereoWanted) {
      InterlockedExchange(&g_ctl.recenterRequest, 1);
      log_line("HEADTRACK recenter requested (F9). frame=%d", (int)g_ctl.worldFrames);
    } else {
      InterlockedExchange(&g_ctl.mode, MODE_OFF);  // leave manual mode first
      InterlockedExchange(&g_headPending, 1);
      InterlockedExchange(&g_ctl.recenterRequest, 1);
      exit_guard_arm();
      vr_capi_request_start(g_selfDir, GBVR_VR_BACKGROUND);
      log_line("HEADTRACK requested (F9): %s. frame=%d", vr_capi_status(), (int)g_ctl.worldFrames);
    }
  }
#endif
}

#if GBVR_HEADTRACK
// Head tracking without the headset picture (F9, background session). While
// the headset view (F4) is on, poses come from the compositor instead.
static void head_tracking_tick() {
  VrSection vr;
  if (!vr.ok()) return;
  if (g_ctl.stereoWanted || vr_capi_is_scene()) return;
  if (vr_capi_ready() && vr_capi_poll_quit()) {  // SteamVR is closing: let go of it, the game keeps running
    vr_capi_shutdown();
    vr_invalidate_snapshot();
    InterlockedExchange(&g_headPending, 0);
    if (InterlockedCompareExchange(&g_ctl.mode, MODE_OFF, MODE_HEAD) == MODE_HEAD)
      log_line("HEADTRACK off: SteamVR asked the application to quit. frame=%d", (int)g_ctl.worldFrames);
    return;
  }
  if (g_headPending) {
    if (vr_capi_failed()) {
      InterlockedExchange(&g_headPending, 0);
      log_line("HEADTRACK not started: %s", vr_capi_status());
    } else if (!vr_capi_ready()) {
      // idle (e.g. the headset session was just closed): start the background session
      if (!vr_capi_starting()) vr_capi_request_start(g_selfDir, GBVR_VR_BACKGROUND);
    } else {
      int ok = vr_sample_on_render_thread(1);
      if (ok) {
        InterlockedExchange(&g_ctl.recenterRequest, 0);
        InterlockedExchange(&g_headPending, 0);
        InterlockedExchange(&g_ctl.mode, MODE_HEAD);
        log_line("HEADTRACK enabled: %s. frame=%d", vr_capi_status(), (int)g_ctl.worldFrames);
        engine_request_sample();
      }
      // else: headset not tracking yet (asleep?) - keep waiting; logged by the counter report
    }
    return;
  }
  if (g_ctl.mode == MODE_HEAD && vr_capi_ready()) {
    int recenter = InterlockedExchange(&g_ctl.recenterRequest, 0);
    vr_sample_on_render_thread(recenter);  // camera thread applies the validity/freshness gates
  }
}
#endif

// ---- Present ------------------------------------------------------------------
static IDXGISwapChain* g_lastSwapChain;

// ---- Frame timing (0.18) ------------------------------------------------------
// Present-to-Present interval = real frame time as the player sees it.
// Time spent inside the original Present = waiting for vsync / GPU queue.
static const int kTimeWindow = 180;
static float g_frameMs[kTimeWindow];
static int g_frameCount;
static double g_presentWaitMsSum;
static int64_t g_lastPresentQpc;
static UINT g_lastSync, g_lastFlags;

static void log_monitor_refresh(HWND hwnd) {
  HMONITOR mon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
  MONITORINFOEXW mi; ZeroMemory(&mi, sizeof(mi)); mi.cbSize = sizeof(mi);
  if (!mon || !GetMonitorInfoW(mon, &mi)) return;
  DEVMODEW dm; ZeroMemory(&dm, sizeof(dm)); dm.dmSize = sizeof(dm);
  if (EnumDisplaySettingsW(mi.szDevice, ENUM_CURRENT_SETTINGS, &dm))
    log_line("MONITOR %u x %u refresh=%u Hz", (unsigned)dm.dmPelsWidth, (unsigned)dm.dmPelsHeight,
             (unsigned)dm.dmDisplayFrequency);
}

#if GBVR_HEADTRACK
// 0.26: size of the picture the game draws and of the window it is shown in.
static UINT g_bbW, g_bbH;
static LONG g_winW, g_winH;
static void picture_report(IDXGISwapChain* sc, LONG frame) {
  DXGI_SWAP_CHAIN_DESC d;
  if (FAILED(sc->GetDesc(&d))) return;
  RECT rc = {0, 0, 0, 0};
  if (d.OutputWindow) GetClientRect(d.OutputWindow, &rc);
  int changed = d.BufferDesc.Width != g_bbW || d.BufferDesc.Height != g_bbH || rc.right != g_winW || rc.bottom != g_winH;
  if (changed) {
    g_bbW = d.BufferDesc.Width; g_bbH = d.BufferDesc.Height; g_winW = rc.right; g_winH = rc.bottom;
    int ww = 0, wh = 0;
    if (g_game.identityOK) {
      ww = *(volatile int*)rva(layout::kRvaWantedWidth);
      wh = *(volatile int*)rva(layout::kRvaWantedHeight);
    }
    int rw = g_game.identityOK ? *(volatile int*)rva(layout::kRvaRunWindowed) : -1;
    log_line("PICTURESIZE the game draws %u x %u (its own setting says %d x %d, runWindowed=%d), window %d x %d, "
             "swapEffect=%d buffers=%u present=%d", g_bbW, g_bbH, ww, wh, rw, (int)g_winW, (int)g_winH,
             (int)d.SwapEffect, d.BufferCount, (int)frame);
    if (rw > 0 && modes_active_level() > 1)
      log_line("PICTURESIZE note: the game runs in its windowed mode (runWindowed=1 in its settings); it then sizes "
               "its picture from its own saved size, so the picture level may have no effect.");
  }
  if (changed || frame % 1800 == 0) modes_report();
}
#endif

static void frame_timing_report() {
  if (g_frameCount <= 0) return;
  int n = g_frameCount;
  float v[kTimeWindow];
  double sum = 0; int over11 = 0, over17 = 0, over34 = 0;
  for (int i = 0; i < n; ++i) {
    v[i] = g_frameMs[i]; sum += v[i];
    if (v[i] > 11.11f) ++over11;
    if (v[i] > 16.67f) ++over17;
    if (v[i] > 33.4f) ++over34;
  }
  for (int i = 1; i < n; ++i) {  // insertion sort (n <= 180)
    float x = v[i]; int j = i - 1;
    while (j >= 0 && v[j] > x) { v[j + 1] = v[j]; --j; }
    v[j + 1] = x;
  }
  double avg = sum / n;
  int lock30 = -1, lock60 = -1;
  if (g_game.hookBytesOK) {
    lock30 = *(volatile uint8_t*)rva(layout::kRvaLockTo30Hz);
    lock60 = *(volatile uint8_t*)rva(layout::kRvaLockTo60Hz);
  }
  log_line("FRAMETIME frames=%d fps=%.1f avgMs=%.2f minMs=%.2f p50Ms=%.2f p95Ms=%.2f p99Ms=%.2f maxMs=%.2f "
           "over11.1ms=%d over16.7ms=%d over33.3ms=%d presentWaitAvgMs=%.2f syncInterval=%u lockTo30Hz=%d "
           "lockTo60Hz=%d mode=%d", n, avg > 0 ? 1000.0 / avg : 0.0, avg, v[0], v[n / 2], v[(n * 95) / 100],
           v[(n * 99) / 100], v[n - 1], over11, over17, over34, g_presentWaitMsSum / n, g_lastSync, lock30, lock60,
           (int)g_ctl.mode);
  g_frameCount = 0;
  g_presentWaitMsSum = 0;
}

#if GBVR_HEADTRACK
// 0.44: a Present that fails is the first sign of a graphics driver reset (the display going black / the PC freezing for
// a few seconds). Log it with the device's own "removed reason", count it, and keep the evidence on disk.
static volatile LONG g_presentFailLogged;
static volatile LONG g_flatSyncOff;   // 0.45: flat-mode Presents whose wait for the monitor was removed
static void note_present_failure(IDXGISwapChain* sc, HRESULT hr, LONG frame) {
  safety_issue(IS_PRESENT_FAIL);
  if (InterlockedIncrement(&g_presentFailLogged) > 8) return;
  HRESULT reason = S_OK;
  ID3D11Device* dev = nullptr;
  if (SUCCEEDED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&dev)) && dev) {
    reason = dev->GetDeviceRemovedReason();
    dev->Release();
  }
  int removed = hr == DXGI_ERROR_DEVICE_REMOVED || hr == DXGI_ERROR_DEVICE_RESET || hr == DXGI_ERROR_DEVICE_HUNG ||
                (unsigned)hr == 0x887A0020u /* DXGI_ERROR_DRIVER_INTERNAL_ERROR */ || reason != S_OK;
  if (removed) safety_issue(IS_DEVICE_REMOVED);
  log_line("PRESENTFAIL frame=%d hr=0x%08x deviceRemovedReason=0x%08x%s renderStage=%s gameStage=%s", (int)frame, (unsigned)hr, (unsigned)reason,
           removed ? " (THE GRAPHICS DEVICE WAS REMOVED / RESET - driver reset or GPU hang; check gbvr_freeze_report.txt via CHECK_FREEZE.cmd)" : "",
           stage_name(g_stageR), stage_name(g_stageG));
  if (removed) { safety_on_fault("graphics device removed / reset (Present failed)"); }
  log_flush();
}
#endif

static HRESULT STDMETHODCALLTYPE hk_present_inner(IDXGISwapChain* sc, UINT sync, UINT flags);
static HRESULT STDMETHODCALLTYPE hk_present(IDXGISwapChain* sc, UINT sync, UINT flags) { ProfScope ps(PF_PRESENT); return hk_present_inner(sc, sync, flags); }
static HRESULT STDMETHODCALLTYPE hk_present_inner(IDXGISwapChain* sc, UINT sync, UINT flags) {
  stage_r(ST_PRESENT_ENTER);
  LONG frame = ++g_presentCount;
#if GBVR_HEADTRACK
  if ((frame & 15) == 0 || g_ctl.worldFrames < 400) crumb("present", (int)frame);
#endif
  int64_t t0 = qpc_now();
  if (g_lastPresentQpc && g_frameCount < kTimeWindow)
    g_frameMs[g_frameCount++] = (float)((double)(t0 - g_lastPresentQpc) * 1000.0 / (double)qpc_freq());
  g_lastPresentQpc = t0;
  g_lastSync = sync; g_lastFlags = flags;
  if (sc != g_lastSwapChain) {
    DXGI_SWAP_CHAIN_DESC d;
    if (SUCCEEDED(sc->GetDesc(&d)) && d.OutputWindow) {
      g_lastSwapChain = sc;
      if (g_ctl.gameHwnd != d.OutputWindow) {
        g_ctl.gameHwnd = d.OutputWindow;
        log_line("Swap chain: %u x %u format=%d windowed=%d hwnd=%p", d.BufferDesc.Width, d.BufferDesc.Height,
                 (int)d.BufferDesc.Format, (int)d.Windowed, (void*)d.OutputWindow);
        log_monitor_refresh(d.OutputWindow);
      }
    }
  }
  // Frames that followed a verified active-camera prepare = world frames.
  if (InterlockedExchange(&g_ctl.prepareSeen, 0)) {
    LONG wf = InterlockedIncrement(&g_ctl.worldFrames);
    LONG every = g_ctl.stereoActive ? 61 : (g_ctl.mode != MODE_OFF || g_ctl.firstPerson) ? 60 : 180;  // 61: samples alternate eyes
    if (g_ctl.probeData && !g_ctl.captureDone && wf % every == 0) engine_request_sample();
  }

  stage_r(ST_KEYS);
  poll_keys();
  auto_start_vr(frame);   // 1.3


  // 0.18.2: switch the game's own frame limiter off (the same bytes the
  // in-game graphics menu and settings.ini control). The game then caps at
  // 120 FPS. Re-applied if the game resets them (defaults are 30 Hz on).
  if (g_game.hookBytesOK) {
    volatile uint8_t* l30 = (volatile uint8_t*)rva(layout::kRvaLockTo30Hz);
    volatile uint8_t* l60 = (volatile uint8_t*)rva(layout::kRvaLockTo60Hz);
    uint8_t a = *l30, b = *l60;
    if (a || b) {
      *l30 = 0;
      *l60 = 0;
      log_line("FRAMELIMIT unlocked: lockTo30Hz %d->0 lockTo60Hz %d->0 (game cap now 120 FPS) present=%d", (int)a,
               (int)b, (int)frame);
    }
  }

  // Only read game memory when the executable identity was verified.
  LONG pause = g_game.hookBytesOK ? *(volatile uint8_t*)rva(layout::kRvaPauseMenuFlag) : 0;
  if (pause) { DWORD tk = GetTickCount(); InterlockedExchange(&g_ctl.pauseSeenTick, (LONG)(tk ? tk : 1)); }   // 1.7.151 (cutholdmath.h: no wait after the pause menu)
  if (pause != g_ctl.pauseFlag) {
    LONG old = InterlockedExchange(&g_ctl.pauseFlag, pause);
    log_line("PAUSEFLAG %d -> %d frame=%d", (int)old, (int)pause, (int)g_ctl.worldFrames);
    InterlockedExchange(&g_reportNow, 1);   // 1.7.25: a full dump when the game pauses (you are probably about to quit)
  }

  if (g_ctl.captureStarted && !g_ctl.captureDone) {
    double secs = (double)(qpc_now() - g_ctl.captureStartQpc) / (double)qpc_freq();
    if (secs >= kCaptureSeconds) {  // 0.20: only the detailed samples stop; keys and modes keep working
      InterlockedExchange(&g_ctl.captureDone, 1);
      if (g_ctl.probeData) engine_periodic_report(g_ctl.worldFrames);
      log_line("CAPTURE window ended: detailed samples stop, counters continue every 1800 frames.");
      log_flush();
    }
  }

#if GBVR_HEADTRACK
  stage_r(ST_SESSION);
  stereo_tick_session();
  stage_r(ST_HEADTRACK);
  head_tracking_tick();
#endif

  if (frame % kReportEvery == 0) {
    stage_r(ST_REPORT);
    // 1.7.25: the 1.7.24 log was 17 MB: a full status dump (about 200 lines) every 2.5 s. Now: the first 10 dumps (every 180 frames), then one about every 30 s, plus one right after a slam
    // try (g_reportNow). The small timing line and the settings save still run every 180 frames.
    static LONG s_dumps;
    const int requestedDump = InterlockedExchange(&g_reportNow, 0) != 0;
    const int fullDump = g_ctl.probeData && (s_dumps < 10 || frame % 2160 == 0 || requestedDump);
    if (fullDump) ++s_dumps;
    if (g_ctl.probeData) frame_timing_report();
#if GBVR_HEADTRACK
    {   // 1.7.90: the setup and sound checks ran only inside the full dump, which the download never does (diagnostics off): now they run in every build
      static int s_lateDone, s_audio2, s_audioA, s_audioB; static DWORD s_audioT0;
      // 1.7.96: the sound check also ran only after 900 3D frames; a player who sits in the game's start-up movies / menus (no sound in the intro movies) never got one. Now also 15 s and 45 s after start.
      if (!s_audioT0) s_audioT0 = GetTickCount() | 1;
      if (!s_audioA && GetTickCount() - s_audioT0 > 15000) { s_audioA = 1; audio_probe(); }
      if (!s_audioB && GetTickCount() - s_audioT0 > 45000) { s_audioB = 1; audio_probe(); }
      if (!s_lateDone && g_ctl.worldFrames > 900) { s_lateDone = 1; sysinfo_modules(); sysinfo_env(1); audio_probe(); }
      if (!s_audio2 && g_ctl.worldFrames > 7200) { s_audio2 = 1; audio_probe(); }
      if (g_ctl.stereoActive && !stereo_in_flat_mode()) xinput_bridge_guard(1); else xinput_bridge_guard(0);   // 1.7.91
      xinput_bridge_di_check(g_ctl.padEnabled && controllers_active() ? 1 : 0);   // 1.7.92
    }
#endif
    if (fullDump && (!g_ctl.captureDone || frame % 1800 == 0 || g_ctl.stereoWanted)) engine_periodic_report(g_ctl.worldFrames);
#if GBVR_HEADTRACK
    if (g_headPending) log_line("HEADTRACK waiting: %s", vr_capi_status());
    if (fullDump) {
      stereo_report(frame);
      menu_report();
      flatview_report(frame);
      monitorview_report(frame);   // 1.2
      held_menu_report((long)frame);   // 1.7.28
      flatglow_report(frame);   // 0.95
      eyeaa_report(frame);      // 1.7.153
    }
    if (g_ctl.probeData) picture_report(sc, frame);
    else {
      static int64_t lastSummary;
      const int64_t now = qpc_now();
      if (!lastSummary || now - lastSummary >= qpc_freq() * 30) {
        lastSummary = now;
        log_line("SESSION build=%s VR=%d speedIncrease=%d%% boostActive=%d nativeSprint=removed diagnostics=off", GBVR_VERSION, (int)g_ctl.stereoActive, (int)g_ctl.sprintSpeedPct, controllers_sprint_want());
        input_flow_report("30 s summary");   // 1.7.85
        stereo_perf_light();   // 1.7.102
        engine_issue_report();
      }
    }
    settings_save_if_changed();
#endif
#if GBVR_HEADTRACK
    log_line("STATE present=%d worldFrames=%d focused=%d pauseFlag=%d mode=%d firstPerson=%d stereo=%d gameStage=%s", (int)frame,
             (int)g_ctl.worldFrames, game_window_focused(), (int)g_ctl.pauseFlag, (int)g_ctl.mode,
             (int)g_ctl.firstPerson, (int)g_ctl.stereoActive, stage_name(g_stageG));
#else
    log_line("STATE present=%d worldFrames=%d focused=%d pauseFlag=%d mode=%d firstPerson=%d stereo=%d", (int)frame,
             (int)g_ctl.worldFrames, game_window_focused(), (int)g_ctl.pauseFlag, (int)g_ctl.mode,
             (int)g_ctl.firstPerson, (int)g_ctl.stereoActive);
#endif
  }
  if (frame % 1800 == 0) log_flush();
#if GBVR_HEADTRACK
  // Headset view: the compositor paces the frames (WaitGetPoses below), so the
  // desktop Present must not wait for the monitor as well.
  stage_r(ST_BEFORE_PRESENT);
  if (stereo_before_present(sc, flags)) sync = 0;
  // 0.45 flat mode (no headset view): the picture in its own shape, and no wait for the monitor / SteamVR refresh
  // (a fixed 60 / 72 FPS ceiling in flat mode: the game's own 120 FPS cap applies instead)
  if (!g_ctl.stereoActive) {
    stage_r(ST_FLATVIEW);
    flatview_present(sc, 0);
    if (g_ctl.flatVsyncOff && sync) { sync = 0; ++g_flatSyncOff; }
  } else {
    // 1.2: in the headset the window is not stretched alternating eyes any more: one steady eye picture (3D view),
    // or the 2D screen in its own shape (menus, videos)
    stage_r(ST_FLATVIEW);
    if (vrmenu_is_open()) {
      // 1.7.145: the PC window keeps showing the game (the headset view, or the flat screen) and the settings pages sit on top as a panel in the middle,
      // so people watching see how it looks in the game; only when there is no game picture to show does the menu fill the window (1.7.90)
      if (stereo_in_flat_mode()) flatview_present(sc, 1); else monitorview_present(sc);
      monitorview_menu_present(sc, 1);   // 1.7.150: always a panel over whatever the window shows (with monitor_view off that is the game's own picture; it used to fill the window then)
    }
    else if (stereo_in_flat_mode()) flatview_present(sc, 1);
    else monitorview_present(sc);
  }
  stage_r(ST_REAL_PRESENT);
#endif
  int64_t t1 = qpc_now();
  HRESULT hr = o_present(sc, sync, flags);
  g_presentWaitMsSum += (double)(qpc_now() - t1) * 1000.0 / (double)qpc_freq();
#if GBVR_HEADTRACK
  if (FAILED(hr)) note_present_failure(sc, hr, frame);
  stage_r(ST_AFTER_PRESENT);
  stereo_after_present();
  stage_r(ST_NONE);
  if (frame == 1) startup_confirmed();
#endif
  return hr;
}

static void hook_present_from(IDXGISwapChain* sc) {
  if (!sc || InterlockedCompareExchange(&g_presentHooked, 1, 0) != 0) return;
  void** vt = *(void***)sc;
  void* target = vt[8];  // IDXGISwapChain::Present
  MH_STATUS s = MH_CreateHook(target, (void*)hk_present, (void**)&o_present);
  if (s == MH_OK) s = MH_EnableHook(target);
  log_line("HOOK Present status=%d target=%p", (int)s, target);
}

static HRESULT STDMETHODCALLTYPE hk_createSwapChain(IDXGIFactory* f, IUnknown* dev, DXGI_SWAP_CHAIN_DESC* desc,
                                                    IDXGISwapChain** out) {
  HRESULT hr = o_createSwapChain(f, dev, desc, out);
  if (SUCCEEDED(hr) && out && *out) {
    if (desc) log_line("CreateSwapChain %u x %u windowed=%d hwnd=%p swapEffect=%d buffers=%u", desc->BufferDesc.Width,
                       desc->BufferDesc.Height, (int)desc->Windowed, (void*)desc->OutputWindow, (int)desc->SwapEffect,
                       desc->BufferCount);
    hook_present_from(*out);
  }
  return hr;
}

static HRESULT STDMETHODCALLTYPE hk_createSwapChainForHwnd(IDXGIFactory2* f, IUnknown* dev, HWND hwnd,
                                                           const DXGI_SWAP_CHAIN_DESC1* d,
                                                           const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* fs, IDXGIOutput* o,
                                                           IDXGISwapChain1** out) {
  HRESULT hr = o_createSwapChainForHwnd(f, dev, hwnd, d, fs, o, out);
  if (SUCCEEDED(hr) && out && *out) {
    log_line("CreateSwapChainForHwnd hwnd=%p", (void*)hwnd);
    hook_present_from(*out);
  }
  return hr;
}

// ---- 1.7.27 sharper textures: plain linear samplers become anisotropic ----------------------------------------------------------------------------------------------------------------------------
// "please make the resolution better": the 1.7.26 log says the headset gets 51 % of SteamVR's recommended pixels, and the game's textures are filtered bilinear / trilinear, which smears floors, walls and carpet seen at an angle.
// ID3D11Device::CreateSamplerState (vtable slot 23) is wrapped: a MIN_MAG_MIP_LINEAR sampler is made ANISOTROPIC with texture_aniso taps; point, comparison (shadow) and other filters are left alone.
typedef HRESULT(STDMETHODCALLTYPE* PFN_CreateSampler)(ID3D11Device*, const D3D11_SAMPLER_DESC*, ID3D11SamplerState**);
static PFN_CreateSampler o_createSampler;
static struct { volatile LONG made, upgraded, alreadyAniso, raisedAniso, otherFilter, failedRetry; volatile LONG byFilter[8]; LONG hooked; } g_smp;
static HRESULT STDMETHODCALLTYPE hk_create_sampler(ID3D11Device* d, const D3D11_SAMPLER_DESC* desc, ID3D11SamplerState** out) {
  InterlockedIncrement(&g_smp.made);
  const LONG taps = g_ctl.texAniso;
  if (desc && taps >= 2) {
    D3D11_SAMPLER_DESC sd = *desc;
    int changed = 0;
    if (sd.Filter == D3D11_FILTER_MIN_MAG_MIP_LINEAR) { sd.Filter = D3D11_FILTER_ANISOTROPIC; sd.MaxAnisotropy = (UINT)taps; changed = 1; InterlockedIncrement(&g_smp.upgraded); }
    else if (sd.Filter == D3D11_FILTER_ANISOTROPIC) {
      InterlockedIncrement(&g_smp.alreadyAniso);
      if (sd.MaxAnisotropy < (UINT)taps) { sd.MaxAnisotropy = (UINT)taps; changed = 1; InterlockedIncrement(&g_smp.raisedAniso); }
    } else {
      InterlockedIncrement(&g_smp.otherFilter);
      const int f = (int)sd.Filter; InterlockedIncrement(&g_smp.byFilter[f == 0 ? 0 : f == 0x14 ? 1 : f == 0x15 ? 2 : (f & 0x80) ? 3 : 4]);   // 0 point, 0x14 linear min/mag + point mip, 0x15 linear, comparison, other
    }
    if (changed) {
      HRESULT hr = o_createSampler(d, &sd, out);
      if (SUCCEEDED(hr)) return hr;
      InterlockedIncrement(&g_smp.failedRetry);   // the driver refused: the game's own description goes through
    }
  }
  return o_createSampler(d, desc, out);
}
void sampler_report(long frame) {
  log_line("SAMPLERS frame=%ld hook=%ld texture_aniso=%d | samplers made %ld: plain linear -> anisotropic %ld, already anisotropic %ld (raised %ld), other filters left alone %ld (point %ld, linear-min/mag+point-mip %ld, comparison %ld, other %ld), driver refused %ld (1.7.27; applies to samplers made after the game started)",
           frame, (long)g_smp.hooked, (int)g_ctl.texAniso, g_smp.made, g_smp.upgraded, g_smp.alreadyAniso, g_smp.raisedAniso, g_smp.otherFilter, g_smp.byFilter[0], g_smp.byFilter[1], g_smp.byFilter[3], g_smp.byFilter[4], g_smp.failedRetry);
}
static void install_sampler_hook(ID3D11Device* dev) {
  void** vt = *(void***)dev;
  void* t = vt[23];   // ID3D11Device::CreateSamplerState
  MH_STATUS s = MH_CreateHook(t, (void*)hk_create_sampler, (void**)&o_createSampler);
  if (s == MH_OK) s = MH_EnableHook(t);
  g_smp.hooked = s == MH_OK ? 1 : -(LONG)(s + 1);
  log_line("HOOK CreateSamplerState status=%d target=%p (1.7.27: texture_aniso %d)", (int)s, t, (int)g_ctl.texAniso);
}

void render_install_factory_hooks(void* devicePtr) {
  if (InterlockedCompareExchange(&g_factoryHooked, 1, 0) != 0) return;
  ID3D11Device* dev = (ID3D11Device*)devicePtr;
  install_sampler_hook(dev);   // 1.7.27
  IDXGIDevice* dxgiDev = nullptr;
  IDXGIAdapter* adapter = nullptr;
  IDXGIFactory* factory = nullptr;
  if (SUCCEEDED(dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDev)) &&
      SUCCEEDED(dxgiDev->GetAdapter(&adapter)) &&
      SUCCEEDED(adapter->GetParent(__uuidof(IDXGIFactory), (void**)&factory))) {
    DXGI_ADAPTER_DESC ad;
    if (SUCCEEDED(adapter->GetDesc(&ad)))
      log_line("Device GPU vendor=%04x device=%04x", (unsigned)ad.VendorId, (unsigned)ad.DeviceId);
    void** vt = *(void***)factory;
    void* t1 = vt[10];  // IDXGIFactory::CreateSwapChain
    MH_STATUS s = MH_CreateHook(t1, (void*)hk_createSwapChain, (void**)&o_createSwapChain);
    if (s == MH_OK) s = MH_EnableHook(t1);
    log_line("HOOK CreateSwapChain status=%d target=%p", (int)s, t1);
    IDXGIFactory2* f2 = nullptr;
    if (SUCCEEDED(factory->QueryInterface(__uuidof(IDXGIFactory2), (void**)&f2))) {
      void** vt2 = *(void***)f2;
      void* t2 = vt2[15];  // IDXGIFactory2::CreateSwapChainForHwnd
      s = MH_CreateHook(t2, (void*)hk_createSwapChainForHwnd, (void**)&o_createSwapChainForHwnd);
      if (s == MH_OK) s = MH_EnableHook(t2);
      log_line("HOOK CreateSwapChainForHwnd status=%d target=%p", (int)s, t2);
      f2->Release();
    }
  } else {
    log_line("HOOK CreateSwapChain skipped: could not reach the DXGI factory");
  }
  if (factory) factory->Release();
  if (adapter) adapter->Release();
  if (dxgiDev) dxgiDev->Release();
  log_flush();
}
