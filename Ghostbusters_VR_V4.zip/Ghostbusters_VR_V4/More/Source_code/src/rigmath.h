// 0.74 the rig view: a small floating copy of the player's body that you look at from the front (or side / back), with a red dot at your real eye.
// Pure math (no Windows), tested in tests/test_rig.cpp. The numbers come from the game's own skeleton (armcore.h publishes the joints in the
// headset's axes, feet) and from the pack / hose matrices (engine_hooks.cpp); handmodel.cpp draws the triangles this file builds.
//
// What it is for: nobody can see their own back or head in VR. This view shows where the game put the head, shoulders, elbows, hands and the
// pack relative to where the headset really is (the red dot), where the controllers really are, and where the physics hose runs.
#pragma once
#include "vmath.h"
#include "cordmath.h"

namespace rig {

enum Joint { J_HEAD, J_NECK, J_SPINE3, J_SPINE1, J_PELVIS, J_CLAVR, J_SHR, J_ELR, J_WRR, J_CLAVL, J_SHL, J_ELL, J_WRL,
             J_HIPL, J_KNL, J_FTL, J_HIPR, J_KNR, J_FTR, J_EYEL, J_EYER, kJ };

// Everything is in the headset's own axes (right, up, forward) in game feet, measured from the eye.
struct Snap {
  int have;                       // joints valid
  float fpm;                      // game feet per metre
  float j[kJ][3]; unsigned char ok[kJ];
  int packOk; float pack[3], packAx[3][3];   // the pack's matrix: origin and its three axes (unit vectors)
  int hoseOk; float hose[3], hoseAx[3][3];
  float stretch[2];               // arm stretch factor of the last pass (right, left)
  long seq;                       // changes whenever the numbers change (set by the reader)
  void clear() {
    have = 0; fpm = 3.28084f; packOk = hoseOk = 0; stretch[0] = stretch[1] = 1.0f; seq = 0;
    for (int i = 0; i < 3; ++i) { pack[i] = hose[i] = 0.0f; for (int k = 0; k < 3; ++k) packAx[i][k] = hoseAx[i][k] = 0.0f; }   // 1.7.8: no stale numbers when a matrix is flagged missing
    for (int i = 0; i < kJ; ++i) { ok[i] = 0; j[i][0] = j[i][1] = j[i][2] = 0.0f; }
  }
};

// a point / a direction in game world -> the headset's axes. view9: row-major 3x3, column k = headset axis k (right, up, forward) in game world.
inline void point_to_head(const double* view9, const double* eye3, const double* P, float* out) {
  for (int k = 0; k < 3; ++k) {
    double a = 0;
    for (int r = 0; r < 3; ++r) a += view9[r * 3 + k] * (P[r] - eye3[r]);
    out[k] = (float)a;
  }
}
inline void dir_to_head(const double* view9, const double* D, float* out) {
  double l = vm::dsqrt(D[0] * D[0] + D[1] * D[1] + D[2] * D[2]);
  if (l < 1e-12) l = 1.0;
  for (int k = 0; k < 3; ++k) {
    double a = 0;
    for (int r = 0; r < 3; ++r) a += view9[r * 3 + k] * D[r];
    out[k] = (float)(a / l);
  }
}

// ---- the picture ------------------------------------------------------------------------------------------------------------------
struct Frame {
  double head[3];                 // the head position (tracking space, metres)
  double Rh[9];                   // the head rotation: Rh[r*3+c], column c = right / up / back in tracking space
  double C[3];                    // where the miniature's eye point is
  double delta;                   // view turn about the vertical (radians): pi = from the front, +pi/2 = right side, 0 = from behind, -pi/2 = left side
  double k;                       // scale (0.4 = 40 percent)
  double fpm;                     // game feet per metre
  int haveR, haveL; double ctrlR[3], ctrlL[3];   // controller grips (tracking space)
  double ctrlRAim[3];                            // the way the right controller points (unit, tracking space)
  int haveCord; double cord[cord::kN][3];        // the physics hose
  double anchorA[3], anchorB[3];                 // the probe's own cord ends
  double floorY;
};

struct Buf { cord::V* v; int n, cap; int over; };

inline void put(Buf& b, const double* p, const double* n, const float* col, float em) {
  if (b.n >= b.cap) { b.over = 1; return; }
  cord::V& o = b.v[b.n++];
  for (int i = 0; i < 3; ++i) { o.p[i] = (float)p[i]; o.n[i] = (float)n[i]; }
  o.c[0] = col[0]; o.c[1] = col[1]; o.c[2] = col[2]; o.c[3] = em;
}
inline void cross3(const double* a, const double* b, double* o) { o[0] = a[1] * b[2] - a[2] * b[1]; o[1] = a[2] * b[0] - a[0] * b[2]; o[2] = a[0] * b[1] - a[1] * b[0]; }
inline void tri(Buf& b, const double* a, const double* bb, const double* c, const float* col, float em) {
  double e1[3] = {bb[0] - a[0], bb[1] - a[1], bb[2] - a[2]}, e2[3] = {c[0] - a[0], c[1] - a[1], c[2] - a[2]}, n[3];
  cross3(e1, e2, n);
  double l = cord::len3(n); if (l < 1e-18) return;
  for (int i = 0; i < 3; ++i) n[i] /= l;
  put(b, a, n, col, em); put(b, bb, n, col, em); put(b, c, n, col, em);
}

// 6 sides, no end caps (a sphere sits on every joint)
inline void add_tube(Buf& b, const double* p0, const double* p1, double r, const float* col, float em) {
  double ax[3] = {p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]};
  const double l = cord::len3(ax);
  if (l < 1e-9) return;
  for (int i = 0; i < 3; ++i) ax[i] /= l;
  double t[3] = {0, 1, 0};
  if (vm::dabs(ax[1]) > 0.9) { t[0] = 1; t[1] = 0; }
  double u[3], w[3];
  cross3(ax, t, u);
  const double ul = cord::len3(u);
  for (int i = 0; i < 3; ++i) u[i] /= ul;
  cross3(ax, u, w);
  enum { S = 6 };
  double q0[S][3], q1[S][3], nn[S][3];
  for (int s = 0; s < S; ++s) {
    double sn, cs;
    vm::dsincos(2.0 * vm::kPi * (double)s / (double)S, &sn, &cs);
    for (int i = 0; i < 3; ++i) {
      nn[s][i] = u[i] * cs + w[i] * sn;
      q0[s][i] = p0[i] + nn[s][i] * r; q1[s][i] = p1[i] + nn[s][i] * r;
    }
  }
  for (int s = 0; s < S; ++s) {
    const int s2 = (s + 1) % S;
    const double* P[6] = {q0[s], q1[s], q0[s2], q0[s2], q1[s], q1[s2]};
    const double* N[6] = {nn[s], nn[s], nn[s2], nn[s2], nn[s], nn[s2]};
    for (int v = 0; v < 6; ++v) put(b, P[v], N[v], col, em);
  }
}

// 8 slices x 4 rings
inline void add_sphere(Buf& b, const double* c, double r, const float* col, float em) {
  enum { S = 8, R = 4 };
  for (int j = 0; j < R; ++j) {
    const double a0 = vm::kPi * ((double)j / R - 0.5), a1 = vm::kPi * ((double)(j + 1) / R - 0.5);
    double s0, c0, s1, c1;
    vm::dsincos(a0, &s0, &c0); vm::dsincos(a1, &s1, &c1);
    for (int i = 0; i < S; ++i) {
      double st0, ct0, st1, ct1;
      vm::dsincos(2.0 * vm::kPi * (double)i / (double)S, &st0, &ct0);
      vm::dsincos(2.0 * vm::kPi * (double)(i + 1) / (double)S, &st1, &ct1);
      const double d00[3] = {c0 * ct0, s0, c0 * st0}, d01[3] = {c0 * ct1, s0, c0 * st1}, d10[3] = {c1 * ct0, s1, c1 * st0}, d11[3] = {c1 * ct1, s1, c1 * st1};
      const double* D[6] = {d00, d10, d01, d01, d10, d11};
      for (int v = 0; v < 6; ++v) {
        double p[3] = {c[0] + D[v][0] * r, c[1] + D[v][1] * r, c[2] + D[v][2] * r};
        put(b, p, D[v], col, em);
      }
    }
  }
}

// a box from its centre and three half-extent vectors
inline void add_box(Buf& b, const double* c, const double* hx, const double* hy, const double* hz, const float* col, float em) {
  const double* H[3] = {hx, hy, hz};
  for (int a = 0; a < 3; ++a) {
    const double* n = H[a]; const double* u = H[(a + 1) % 3]; const double* v = H[(a + 2) % 3];
    for (int sgn = -1; sgn <= 1; sgn += 2) {
      double ctr[3], p[4][3];
      for (int i = 0; i < 3; ++i) ctr[i] = c[i] + n[i] * sgn;
      for (int q = 0; q < 4; ++q) {
        const double su = (q == 0 || q == 3) ? -1.0 : 1.0, sv = (q < 2) ? -1.0 : 1.0;
        for (int i = 0; i < 3; ++i) p[q][i] = ctr[i] + u[i] * su + v[i] * sv;
      }
      tri(b, p[0], p[1], p[2], col, em); tri(b, p[0], p[2], p[3], col, em);
      tri(b, p[0], p[2], p[1], col, em); tri(b, p[0], p[3], p[2], col, em);   // both windings: the box is seen from either side
    }
  }
}

struct Mapper {
  const Frame* f;
  double cd, sd;
  explicit Mapper(const Frame& fr) : f(&fr) { vm::dsincos(fr.delta, &sd, &cd); }
  // an offset from the head in tracking space (metres) -> display
  void off(const double* v, double* out) const {
    const double x = v[0] * cd - v[2] * sd, z = v[0] * sd + v[2] * cd;
    out[0] = f->C[0] + f->k * x; out[1] = f->C[1] + f->k * v[1]; out[2] = f->C[2] + f->k * z;
  }
  void track(const double* p, double* out) const { double v[3] = {p[0] - f->head[0], p[1] - f->head[1], p[2] - f->head[2]}; off(v, out); }
  // a point in the headset's axes (feet right, up, forward) -> display
  void headax(const float* a, double* out) const {
    const double h[3] = {a[0] / f->fpm, a[1] / f->fpm, -a[2] / f->fpm};   // metres; forward is -z
    double v[3];
    for (int r = 0; r < 3; ++r) v[r] = f->Rh[r * 3] * h[0] + f->Rh[r * 3 + 1] * h[1] + f->Rh[r * 3 + 2] * h[2];
    off(v, out);
  }
  // a direction in the headset's axes (unit) -> display direction (unit)
  void headdir(const float* a, double* out) const {
    const double h[3] = {a[0], a[1], -a[2]};
    double v[3];
    for (int r = 0; r < 3; ++r) v[r] = f->Rh[r * 3] * h[0] + f->Rh[r * 3 + 1] * h[1] + f->Rh[r * 3 + 2] * h[2];
    out[0] = v[0] * cd - v[2] * sd; out[1] = v[1]; out[2] = v[0] * sd + v[2] * cd;
  }
};

// Builds the whole picture. Returns the number of vertices (0 = nothing to draw). Sizes are real-world metres times f.k.
// 0.80 PACK STRAPS. With the avatar's chest hidden (arms only), the game's own straps go with it (they are painted on the chest), so the probe draws
// two simple harness straps from joints it already has: pack top -> over the shoulder -> down the front -> under the arm -> pack bottom.
// head/Rh: the head position and rotation (tracking space, metres; Rh column c = right / up / back). Returns the vertex count (0 = joints missing).
inline int build_straps(const Snap& s, const double* head, const double* Rh, cord::V* out, int cap) {
  if (!s.have || !s.packOk || !s.ok[J_SHR] || !s.ok[J_SHL] || !s.ok[J_NECK] || !s.ok[J_SPINE3] || s.fpm < 0.5f) return 0;
  Buf b = {out, 0, cap, 0};
  const double fpm = s.fpm;
  double R[3], U[3], F[3], K[3];
  for (int i = 0; i < 3; ++i) { R[i] = (double)s.j[J_SHR][i] - (double)s.j[J_SHL][i]; U[i] = (double)s.j[J_NECK][i] - (double)s.j[J_SPINE3][i]; K[i] = s.pack[i]; }
  double rl = cord::len3(R);
  if (rl < 0.3 || rl > 4.0) return 0;                       // shoulders closer than 9 cm or wider than 1.2 m: not a real pose
  for (int i = 0; i < 3; ++i) R[i] /= rl;
  const double d = U[0] * R[0] + U[1] * R[1] + U[2] * R[2];
  for (int i = 0; i < 3; ++i) U[i] -= d * R[i];
  double ul = cord::len3(U);
  if (ul < 0.05) return 0;
  for (int i = 0; i < 3; ++i) U[i] /= ul;
  cross3(R, U, F);
  const double hw = 0.5 * rl;
  static const float col[3] = {0.075f, 0.072f, 0.066f};
  const double rad = 0.019;
  for (int side = 0; side < 2; ++side) {
    const double sg = side == 0 ? 1.0 : -1.0;
    const float* Sh = s.j[side == 0 ? J_SHR : J_SHL];
    double q[6][3];   // headset axes, feet
    for (int i = 0; i < 3; ++i) {
      const double T = Sh[i] - sg * R[i] * 0.5 * hw + U[i] * 0.12;
      q[0][i] = K[i] + U[i] * 0.55 + sg * R[i] * 0.30;                              // pack top
      q[1][i] = T;                                                                    // over the shoulder
      q[2][i] = T + F[i] * 0.30 - U[i] * 0.30;                                        // down the front
      q[3][i] = Sh[i] - sg * R[i] * 0.25 * hw + F[i] * 0.25 - U[i] * 0.95;            // low on the chest
      q[4][i] = Sh[i] - sg * R[i] * 0.10 * hw - F[i] * 0.05 - U[i] * 1.10;            // under the arm
      q[5][i] = K[i] - U[i] * 0.40 + sg * R[i] * 0.30;                                // pack bottom
    }
    double w[6][3];
    for (int k = 0; k < 6; ++k) {
      const double h[3] = {q[k][0] / fpm, q[k][1] / fpm, -q[k][2] / fpm};
      for (int r = 0; r < 3; ++r) w[k][r] = head[r] + Rh[r * 3] * h[0] + Rh[r * 3 + 1] * h[1] + Rh[r * 3 + 2] * h[2];
    }
    for (int k = 0; k < 5; ++k) add_tube(b, w[k], w[k + 1], rad, col, 0.0f);
  }
  return b.over ? 0 : b.n;
}

inline int build(const Snap& s, const Frame& f, cord::V* out, int cap) {
  Buf b = {out, 0, cap, 0};
  const Mapper M(f);
  const double k = f.k;
  static const float cWhite[3] = {0.92f, 0.92f, 0.92f}, cRight[3] = {0.25f, 0.95f, 0.35f}, cLeft[3] = {1.0f, 0.62f, 0.12f},
                     cRLeg[3] = {0.15f, 0.65f, 0.25f}, cLLeg[3] = {0.75f, 0.42f, 0.08f}, cHead[3] = {1.0f, 0.92f, 0.2f},
                     cRed[3] = {1.0f, 0.05f, 0.05f}, cEye[3] = {0.7f, 0.9f, 1.0f}, cPack[3] = {0.8f, 0.4f, 0.95f},
                     cHose[3] = {1.0f, 0.5f, 0.0f}, cAx[3][3] = {{1.0f, 0.2f, 0.2f}, {0.2f, 1.0f, 0.2f}, {0.3f, 0.5f, 1.0f}},
                     cCord[3] = {0.35f, 0.55f, 1.0f}, cAnch[3] = {1.0f, 0.2f, 0.9f}, cCtrl[3] = {1.0f, 1.0f, 1.0f},
                     cFloor[3] = {0.16f, 0.2f, 0.3f}, cGaze[3] = {1.0f, 0.2f, 0.2f};
  double P[kJ][3];
  for (int i = 0; i < kJ; ++i) if (s.have && s.ok[i]) M.headax(s.j[i], P[i]);
  // floor tile under the figure: the same size as 1.2 m square
  {
    double c[3], hx[3] = {0.6 * k, 0, 0}, hy[3] = {0, 0.004, 0}, hz[3] = {0, 0, 0.6 * k};
    double fl[3] = {f.head[0], f.floorY, f.head[2]};
    M.track(fl, c);
    add_box(b, c, hx, hy, hz, cFloor, 1.0f);
  }
  const double u = k / 0.4;                         // sizes below are for a 40 percent figure
  const double rt = 0.011 * u, rj = 0.019 * u;       // limb and joint
  if (s.have) {
    struct Seg { int a, b; const float* col; };
    const Seg segs[] = {{J_HEAD, J_NECK, cWhite}, {J_NECK, J_SPINE3, cWhite}, {J_SPINE3, J_SPINE1, cWhite}, {J_SPINE1, J_PELVIS, cWhite},
                        {J_SPINE3, J_CLAVR, cWhite}, {J_CLAVR, J_SHR, cRight}, {J_SHR, J_ELR, cRight}, {J_ELR, J_WRR, cRight},
                        {J_SPINE3, J_CLAVL, cWhite}, {J_CLAVL, J_SHL, cLeft}, {J_SHL, J_ELL, cLeft}, {J_ELL, J_WRL, cLeft},
                        {J_PELVIS, J_HIPL, cLLeg}, {J_HIPL, J_KNL, cLLeg}, {J_KNL, J_FTL, cLLeg},
                        {J_PELVIS, J_HIPR, cRLeg}, {J_HIPR, J_KNR, cRLeg}, {J_KNR, J_FTR, cRLeg}};
    for (unsigned i = 0; i < sizeof(segs) / sizeof(segs[0]); ++i) {
      int a = segs[i].a, c2 = segs[i].b;
      if (!s.ok[a] || !s.ok[c2]) continue;
      add_tube(b, P[a], P[c2], rt, segs[i].col, 1.0f);
    }
    for (int i = 0; i < kJ; ++i) {
      if (!s.ok[i] || i == J_HEAD || i == J_EYEL || i == J_EYER) continue;
      const float* col = (i == J_WRR || i == J_ELR || i == J_SHR) ? cRight : (i == J_WRL || i == J_ELL || i == J_SHL) ? cLeft : cWhite;
      add_sphere(b, P[i], rj * ((i == J_WRR || i == J_WRL) ? 1.3 : 1.0), col, 1.0f);
    }
    if (s.ok[J_HEAD]) add_sphere(b, P[J_HEAD], 0.09 * k, cHead, 1.0f);   // the game's head: a ball where the head bone is
    for (int e = J_EYEL; e <= J_EYER; ++e) if (s.ok[e]) add_sphere(b, P[e], 0.012 * u, cEye, 1.0f);
    if (s.packOk) {
      double c[3];
      M.headax(s.pack, c);
      add_sphere(b, c, 0.03 * u, cPack, 1.0f);
      for (int a = 0; a < 3; ++a) {
        double d[3], e[3];
        M.headdir(s.packAx[a], d);
        for (int i = 0; i < 3; ++i) e[i] = c[i] + d[i] * 0.2 * k;
        add_tube(b, c, e, 0.007 * u, cAx[a], 1.0f);
      }
    }
    if (s.hoseOk) {
      double c[3];
      M.headax(s.hose, c);
      add_sphere(b, c, 0.028 * u, cHose, 1.0f);
    }
  }
  // the player's real head: a red dot at the eye, a line along the way the headset looks and a small red ball one metre ahead
  {
    double c[3] = {f.C[0], f.C[1], f.C[2]}, fwd[3], e[3], g[3];
    fwd[0] = -f.Rh[2]; fwd[1] = -f.Rh[5]; fwd[2] = -f.Rh[8];   // forward = -z column, tracking space
    double v[3] = {fwd[0], fwd[1], fwd[2]};
    M.off(v, g);   // (C + k * turned forward): one metre ahead
    for (int i = 0; i < 3; ++i) e[i] = g[i];
    add_tube(b, c, e, 0.005 * u, cGaze, 1.0f);
    add_sphere(b, e, 0.014 * u, cGaze, 1.0f);
    add_sphere(b, c, 0.028 * u, cRed, 1.0f);
  }
  // the real controllers
  if (f.haveR) {
    double c[3], hx[3] = {0.02 * k, 0, 0}, hy[3] = {0, 0.02 * k, 0}, hz[3] = {0, 0, 0.03 * k};
    M.track(f.ctrlR, c);
    add_box(b, c, hx, hy, hz, cCtrl, 1.0f);
    double a[3] = {f.ctrlRAim[0], f.ctrlRAim[1], f.ctrlRAim[2]}, d[3], e[3];
    M.off(a, d);
    const double nul[3] = {0, 0, 0};
    double z0[3]; M.off(nul, z0);
    for (int i = 0; i < 3; ++i) e[i] = c[i] + (d[i] - z0[i]) * 0.35;   // 35 cm along the aim
    add_tube(b, c, e, 0.005 * u, cCtrl, 1.0f);
  }
  if (f.haveL) {
    double c[3], hx[3] = {0.02 * k, 0, 0}, hy[3] = {0, 0.02 * k, 0}, hz[3] = {0, 0, 0.03 * k};
    M.track(f.ctrlL, c);
    add_box(b, c, hx, hy, hz, cCtrl, 1.0f);
  }
  // the physics hose and its two ends
  if (f.haveCord) {
    double prev[3];
    M.track(f.cord[0], prev);
    for (int i = 1; i < cord::kN; ++i) {
      double cur[3];
      M.track(f.cord[i], cur);
      add_tube(b, prev, cur, 0.007 * u, cCord, 1.0f);
      for (int q = 0; q < 3; ++q) prev[q] = cur[q];
    }
    double c[3];
    M.track(f.anchorA, c); add_sphere(b, c, 0.022 * u, cAnch, 1.0f);
    M.track(f.anchorB, c); add_sphere(b, c, 0.016 * u, cAnch, 1.0f);
  }
  return b.over ? 0 : b.n;
}

}  // namespace rig
