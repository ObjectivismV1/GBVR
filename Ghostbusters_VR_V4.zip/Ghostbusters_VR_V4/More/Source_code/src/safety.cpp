// 0.44 fail-safes: find out what went wrong, keep the evidence, and step back by itself when something keeps failing.
//
//  1. Stages: every thread that matters writes what it is doing into a variable (plain store). A crash note, a stall
//     note or the HEALTH line says where the code was.
//  2. Run marker gbvr_run.txt: written when a headset session is requested, deleted at a clean exit. If it is still
//     there at the next start, the last run ended badly (crash, freeze, killed). The tool then steps back one
//     feature group at a time (safetymath.h plan): newest additions off, then a smaller picture, then no hand
//     drawing. One clean exit resets everything. All of it is logged (SAFETY lines) and the settings are saved.
//  3. gbvr_last_crash.txt: summary written when the game raises a fatal error (code, place, stages, last frame).
//  4. Heartbeat thread: flushes the log every 2 s (so a frozen PC leaves the log up to the last seconds) and writes
//     STALL lines when the game stops presenting frames, with the stage the render thread was in.
//  5. HEALTH line with the counters of everything that went wrong.
// Only plain kernel32 calls here: this code runs from the init path, the crash handler and a small thread.
#include "gbvr.h"
#include "safetymath.h"

#if GBVR_HEADTRACK

volatile LONG g_stageR, g_stageG;

static const char* kStageNames[ST_COUNT] = {
  "none", "present-enter", "keys", "session-tick", "head-tracking", "report", "stereo-before-present", "acquire-back-buffer",
  "copy-eye-picture", "hand-model", "submit-to-steamvr", "flat-screen", "menu-pointer", "game-present", "stereo-after-present",
  "wait-for-steamvr-frame", "controllers", "compositor-timing-report", "exit", "settings",
  "game-tick", "game-simulate", "game-camera-prepare", "game-aim", "game-wand-tip", "game-button-binding", "game-hud", "flat-view"};

const char* stage_name(LONG s) { return (s >= 0 && s < ST_COUNT) ? kStageNames[s] : "?"; }

static volatile LONG g_issues[IS_COUNT];
static const char* kIssueNames[IS_COUNT] = {"presentFail", "deviceRemoved", "textureFail", "submitFail", "overlayFail", "waitFail",
                                            "poseInvalid", "stalls", "faults", "menuFastOff", "perfFallback", "pictureFallback", "vramHigh"};
void safety_issue(Issue i) { if (i >= 0 && i < IS_COUNT) InterlockedIncrement(&g_issues[i]); }
int safety_issue_count(Issue i) { return (i >= 0 && i < IS_COUNT) ? (int)g_issues[i] : 0; }

// ---- small file helpers (no CRT) -------------------------------------------------------------------------------
static wchar_t g_runPath[MAX_PATH + 40], g_crashPath[MAX_PATH + 40], g_healthPath[MAX_PATH + 40];

static void make_paths() {
  if (g_runPath[0]) return;
  const wchar_t* dir = log_dir();
  lstrcpynW(g_runPath, dir, MAX_PATH);
  lstrcatW(g_runPath, L"gbvr_run.txt");
  lstrcpynW(g_crashPath, dir, MAX_PATH);
  lstrcatW(g_crashPath, L"gbvr_last_crash.txt");
  lstrcpynW(g_healthPath, dir, MAX_PATH);
  lstrcatW(g_healthPath, L"gbvr_health.txt");
}

static int write_file(const wchar_t* path, const char* text) {
  HANDLE f = CreateFileW(path, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f == INVALID_HANDLE_VALUE) return 0;
  DWORD w = 0;
  int ok = WriteFile(f, text, (DWORD)lstrlenA(text), &w, nullptr) && w == (DWORD)lstrlenA(text);
  FlushFileBuffers(f);
  CloseHandle(f);
  return ok;
}

static int read_file(const wchar_t* path, char* buf, int size) {
  HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (f == INVALID_HANDLE_VALUE) return -1;
  DWORD got = 0;
  ReadFile(f, buf, (DWORD)(size - 1), &got, nullptr);
  CloseHandle(f);
  buf[got] = 0;
  return (int)got;
}

static int find_number(const char* text, const char* name, int def) { return safety::find_number(text, name, def); }

static int pid_alive(DWORD pid) {
  if (!pid || pid == GetCurrentProcessId()) return 0;
  HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
  if (!h) return 0;
  DWORD code = 0;
  int alive = GetExitCodeProcess(h, &code) && code == STILL_ACTIVE;
  CloseHandle(h);
  return alive;
}

// ---- Run marker --------------------------------------------------------------------------------------------------
static int g_runCount, g_runExiting, g_runFault, g_runWritten, g_runForeign;
static volatile LONG g_runBusy;   // one writer of the marker at a time (render thread, heartbeat, crash handler)

// Problems serious enough to count as evidence that the run went wrong (see safetymath.h).
static int serious_issues() {
  return (int)(g_issues[IS_STALL] + g_issues[IS_PRESENT_FAIL] + g_issues[IS_DEVICE_REMOVED] + g_issues[IS_FAULT] + g_issues[IS_TEXTURE]);
}
static char g_runStageText[96];

static void run_rewrite() {
  if (!g_runWritten || g_runForeign) return;
  if (InterlockedCompareExchange(&g_runBusy, 1, 0) != 0) return;   // somebody else is writing it right now
  make_paths();
  char text[512];
  log_fmt(text, (int)sizeof(text), GBVR_RUN_MARKER_FMT
          "VR probe run marker. It is deleted when the game closes normally. If it is still here when the game is started "
          "the next time, the last run ended badly and the probe steps back by itself (see SAFETY lines in the log).\r\n",
          (unsigned)GetCurrentProcessId(), g_runCount, GBVR_VERSION, (int)g_ctl.pictureLevel, (int)g_ctl.menuFast, g_runExiting,
          g_runFault, serious_issues(), g_runStageText[0] ? g_runStageText : "-");
  write_file(g_runPath, text);
  InterlockedExchange(&g_runBusy, 0);
}

// Was the PC restarted after this file was last written? (Uptime counts from the last cold start; a freeze that ended with
// the power button leaves the marker older than the start of the current uptime.)
static int restarted_since(const wchar_t* path) {
  WIN32_FILE_ATTRIBUTE_DATA fa;
  if (!GetFileAttributesExW(path, GetFileExInfoStandard, &fa)) return 0;
  FILETIME nowFt;
  GetSystemTimeAsFileTime(&nowFt);
  uint64_t now = ((uint64_t)nowFt.dwHighDateTime << 32) | nowFt.dwLowDateTime;
  uint64_t written = ((uint64_t)fa.ftLastWriteTime.dwHighDateTime << 32) | fa.ftLastWriteTime.dwLowDateTime;
  uint64_t up = (uint64_t)GetTickCount64() * 10000ull;   // ms -> 100 ns
  if (up >= now) return 0;
  uint64_t boot = now - up;
  return written + 10ull * 10000000ull < boot;            // written more than 10 s before the PC started
}

// gbvr_health.txt: "count=N" = bad headset runs in a row since the last clean exit (or the last Insert). It lives apart from
// the run marker so that runs which never start the headset view neither add to it nor lose it.
static int read_health_count() {
  char b[128];
  if (read_file(g_healthPath, b, (int)sizeof(b)) < 0) return 0;
  return find_number(b, "count", 0);
}

static void write_health_count(int n) {
  char t[160];
  log_fmt(t, (int)sizeof(t), "count=%d; bad headset runs in a row since the last clean exit. Deleted by a clean exit or by Insert in the game.\r\n", n);
  write_file(g_healthPath, t);
}

void safety_reset_health() {
  make_paths();
  if (g_runCount || GetFileAttributesW(g_healthPath) != INVALID_FILE_ATTRIBUTES) {
    DeleteFileW(g_healthPath);
    log_line("SAFETY bad-run counter reset (was %d)", g_runCount);
  }
  g_runCount = 0;
}

// 1.7.117: a step-back is for THIS RUN ONLY. The saved settings keep the player's own values (the game itself can crash, in its own code, and that must never
// leave a player without hands / body / gun for good: a Quest 3 player lost his motion controls that way). settings.cpp asks safety_saved_value() when it writes the file.
struct RunOver { volatile LONG* v; LONG orig, over; };
static RunOver g_over[16];
static int g_overN;
static void set_run_only(volatile LONG* v, LONG nv) {
  if (g_overN < 16) { g_over[g_overN].v = v; g_over[g_overN].orig = *v; g_over[g_overN].over = nv; ++g_overN; }
  InterlockedExchange(v, nv);
}
LONG safety_saved_value(volatile LONG* v, LONG cur) {
  for (int i = 0; i < g_overN; ++i) if (g_over[i].v == v && g_over[i].over == cur) return g_over[i].orig;
  return cur;
}
void safety_forget_override(volatile LONG* v) {   // the player chose the value himself (VR menu): it is his now
  for (int i = 0; i < g_overN; ++i) if (g_over[i].v == v) g_over[i].v = nullptr;
}

static void apply_plan(const safety::Plan& plan) {
  int changed = 0;
  if (plan.disableMenuFast && g_ctl.menuFast) { set_run_only(&g_ctl.menuFast, 0); changed = 1; log_line("SAFETY step back (this run only): menu_fast OFF (menus held to the game's 30 FPS again)"); }
  if (plan.disableDiag && g_ctl.diagTiming) { set_run_only(&g_ctl.diagTiming, 0); changed = 1; log_line("SAFETY step back (this run only): diag_timing OFF (no compositor timing calls)"); }
  if (plan.pictureCap && g_ctl.autoQuality && g_ctl.pictureLevel > plan.pictureCap) {
    log_line("SAFETY step back (this run only): picture level %d -> %d", (int)g_ctl.pictureLevel, plan.pictureCap);
    set_run_only(&g_ctl.pictureLevel, plan.pictureCap);
    changed = 1;
  }
  if (plan.pictureCap == 1 && g_ctl.pictureLines > 0) { set_run_only(&g_ctl.pictureLines, 0); changed = 1; }   // 1.7.117: an explicit size would hide the cap
  if (plan.wandMoveOff && g_ctl.wandToHand) { set_run_only(&g_ctl.wandToHand, 0); changed = 1; log_line("SAFETY step back (this run only): wand_to_hand OFF (the game's wand stays where the game animates it)"); }
  if (plan.armIkOff && g_ctl.fullBody) { set_run_only(&g_ctl.fullBody, 0); changed = 1; log_line("SAFETY step back (this run only): full_body OFF"); }
  if (plan.armIkOff && g_ctl.armIk) { set_run_only(&g_ctl.armIk, 0); changed = 1; log_line("SAFETY step back (this run only): arm_ik OFF (the game's arms stay as the game animates them)"); }
  if (plan.bodyFollowOff && g_ctl.bodyFollow) { set_run_only(&g_ctl.bodyFollow, 0); changed = 1; log_line("SAFETY step back (this run only): body_follow OFF (the game's body stays where the game puts it)"); }
  if (plan.realModelsOff && g_ctl.realModels) { set_run_only(&g_ctl.realModels, 0); set_run_only(&g_ctl.hideBody, 1); set_run_only(&g_ctl.hideWand, 1); changed = 1; log_line("SAFETY step back (this run only): real_models OFF (own body hidden, placeholder hands and wand)"); }
  if (plan.handModelOff && g_ctl.handModel) { set_run_only(&g_ctl.handModel, 0); changed = 1; log_line("SAFETY step back (this run only): hand_model OFF (no hands / wand drawn)"); }
  if (changed)
    log_line("SAFETY these changes are for this run only: your saved settings are untouched, and after one clean exit everything is back at the next start.");
}

void safety_after_settings() {
  make_paths();
  char buf[600];
  int healthCount = read_health_count();
  safety::PrevRun prev = {0, healthCount, 0, 0, 0, 0, 0};
  int got = read_file(g_runPath, buf, (int)sizeof(buf));
  if (got < 0) {
    g_runCount = healthCount;
    if (healthCount > 0) {
      // No unfinished run, but earlier bad runs are still counted: the step-back is applied again (idempotent) in case
      // the saved settings were not written before that run ended.
      prev.present = 1;
      prev.count = healthCount - 1;
      safety::Plan again = safety::plan(prev);
      log_line("SAFETY earlier bad headset runs in a row: %d (reset by one clean exit of a headset session, or Insert) - step-back kept", healthCount);
      apply_plan(again);
    } else {
      log_line("SAFETY previous run: clean");
    }
    return;
  }
  prev.present = 1;
  prev.exiting = find_number(buf, "exiting", 0) != 0;
  prev.fault = find_number(buf, "fault", 0) != 0;
  prev.ownerAlive = pid_alive((DWORD)find_number(buf, "pid", 0));
  prev.issues = find_number(buf, "issues", 0);
  prev.rebooted = restarted_since(g_runPath);
  char stage[96];
  stage[0] = 0;
  for (const char* p = buf; *p; ++p)
    if ((p == buf || p[-1] == ' ' || p[-1] == ';') && p[0] == 's' && p[1] == 't' && p[2] == 'a' && p[3] == 'g' && p[4] == 'e' && p[5] == '=') {
      int k = 0;
      for (const char* q = p + 6; *q && *q != ';' && *q != '\r' && k < 90; ++q) stage[k++] = *q;
      stage[k] = 0;
      break;
    }
  safety::Plan plan = safety::plan(prev);
  g_runForeign = plan.foreign;
  if (plan.foreign) {
    g_runCount = healthCount;
    log_line("SAFETY gbvr_run.txt belongs to a copy of the game that is still running: left alone, nothing changed");
    return;
  }
  g_runCount = plan.newCount;
  DeleteFileW(g_runPath);   // consumed: this start is judged once
  write_health_count(plan.newCount);
  log_line("SAFETY PREVIOUS RUN DID NOT END CLEANLY: exiting=%d fatalError=%d problemsRecorded=%d pcRestartedAfterwards=%d lastStage=%s -> bad headset runs in a row now %d",
           prev.exiting, prev.fault, prev.issues, prev.rebooted, stage[0] ? stage : "-", plan.newCount);
  if (!prev.exiting && !prev.fault && !prev.issues && !prev.rebooted)
    log_line("SAFETY the run simply ended (closed from Steam / Task Manager, or the process was killed) with no error recorded: not counted, nothing changed.");
  if (prev.exiting && !prev.fault) {
    log_line("SAFETY it ended while the game was closing (a freeze or hang at exit, not while playing): no feature is switched off. "
             "If the PC froze, run CHECK_FREEZE.cmd and send gbvr_freeze_report.txt.");
    return;
  }
  apply_plan(plan);
}

void safety_run_begin() {
  if (g_runWritten || g_runForeign) return;
  make_paths();
  g_runWritten = 1;
  g_runStageText[0] = 0;
  run_rewrite();
  log_line("SAFETY run marker written (count=%d)", g_runCount);
}

void safety_run_note(const char* what) {
  if (!g_runWritten) return;
  if (what[0] == 'e') g_runExiting = 1;
  run_rewrite();
}

void safety_run_end() {
  if (!g_runWritten || g_runForeign) return;
  make_paths();
  int ok = DeleteFileW(g_runPath) != 0;
  g_runWritten = 0;
  DeleteFileW(g_healthPath);   // a clean exit ends the series of bad runs
  log_line("SAFETY clean exit: run marker removed=%d, bad-run counter reset (was %d)", ok, g_runCount);
}

// ---- Fatal error note ---------------------------------------------------------------------------------------------
void safety_on_fault(const char* summary) {
  safety_issue(IS_FAULT);
  make_paths();
  g_runFault = 1;
  lstrcpynA(g_runStageText, stage_name(g_stageR), (int)sizeof(g_runStageText));
  run_rewrite();
  SYSTEMTIME st;
  GetLocalTime(&st);
  char text[1400];
  log_fmt(text, (int)sizeof(text),
          "Ghostbusters VR probe %s - fatal error note\r\n%04u-%02u-%02u %02u:%02u:%02u\r\n%s\r\n"
          "render thread was in: %s\r\ngame main loop was in: %s\r\npresents so far: %d\r\n"
          "The full story is in the log gbvr_probe_*.log (lines CRASHNOTE / CRASHSTACK / SAFETY). Send both files.\r\n",
          GBVR_VERSION, st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, summary, stage_name(g_stageR),
          stage_name(g_stageG), (int)render_present_count());
  write_file(g_crashPath, text);
}

// ---- Fallback for the picture size --------------------------------------------------------------------------------
static int g_fallbackDone;
int safety_fallback_picture(int toLevel, const char* why) {
  if (!g_ctl.autoQuality) {
    log_line("SAFETY %s - picture level would go to %d but auto_quality is off", why, toLevel);
    return 0;
  }
  if (g_ctl.pictureLevel <= toLevel || g_fallbackDone) return 0;
  g_fallbackDone = 1;
  LONG old = InterlockedExchange(&g_ctl.pictureLevel, toLevel);
  settings_changed();
  safety_issue(IS_PICTURE_FALLBACK);
  log_line("SAFETY FALLBACK: %s -> picture level %d -> %d, saved; it applies at the next start of the game (Insert changes it again)", why, (int)old, toLevel);
  return 1;
}


// ---- 0.86 black box: a ring of the last steps, in a memory-mapped file ---------------------------------------------
// The 0.85 run died 4 s after its last log line with no error written anywhere. Memory-mapped pages are written out by Windows even when the process
// is killed, so this ring tells the NEXT start exactly which steps the dead run had reached last (CRUMBLAST lines + gbvr_crumbs_last.txt).
struct CrumbEntry { volatile LONG seq; DWORD tid; DWORD tick; LONG arg; char tag[28]; };   // 48 bytes
static const int kCrumbN = 512;
struct CrumbFile { char magic[8]; LONG pid; LONG pad; CrumbEntry e[kCrumbN]; };
static CrumbFile* g_cf;
static volatile LONG g_crumbSeq;
void crumb(const char* tag, int arg) {
  CrumbFile* f = g_cf;
  if (!f) return;
  const LONG s = InterlockedIncrement(&g_crumbSeq);
  CrumbEntry& e = f->e[s & (kCrumbN - 1)];
  e.seq = 0;
  e.tid = GetCurrentThreadId(); e.tick = GetTickCount(); e.arg = arg;
  int i = 0; for (; tag && tag[i] && i < 27; ++i) e.tag[i] = tag[i];
  e.tag[i] = 0;
  e.seq = s;
}
void crumbs_init() {
  if (!g_ctl.probeData) return;
  const wchar_t* dir = log_dir();
  wchar_t path[MAX_PATH + 40], lastPath[MAX_PATH + 40];
  lstrcpynW(path, dir, MAX_PATH); lstrcatW(path, L"gbvr_crumbs.bin");
  lstrcpynW(lastPath, dir, MAX_PATH); lstrcatW(lastPath, L"gbvr_crumbs_last.txt");
  static CrumbFile prev;   // the previous run's ring, read before it is overwritten
  int havePrev = 0;
  {
    HANDLE r = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
    if (r != INVALID_HANDLE_VALUE) {
      DWORD got = 0;
      if (ReadFile(r, &prev, (DWORD)sizeof(prev), &got, nullptr) && got == sizeof(prev) && prev.magic[0] == 'G' && prev.magic[1] == 'B' && prev.magic[2] == 'C' && prev.magic[3] == 'R') havePrev = 1;
      CloseHandle(r);
    }
  }
  if (havePrev) {
    char* txt = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 65536);
    int len = 0;
    if (txt) len += log_fmt(txt + len, 65536 - len, "Steps the previous run reached last (oldest first; pid %d). If that run ended badly, the LAST lines are where it stopped.\r\n", (int)prev.pid);
    // sort by seq (simple selection, 128 entries)
    LONG lo = 0, prevMax = 0;
    for (int i = 0; i < kCrumbN; ++i) if (prev.e[i].seq > prevMax) prevMax = prev.e[i].seq;
    for (int round = 0; round < kCrumbN; ++round) {
      LONG best = 0x7fffffff; int bi = -1;
      for (int i = 0; i < kCrumbN; ++i) if (prev.e[i].seq > lo && prev.e[i].seq < best) { best = prev.e[i].seq; bi = i; }
      if (bi < 0) break;
      lo = best;
      const CrumbEntry& e = prev.e[bi];
      char line[160];
      const int n = log_fmt(line, sizeof(line), "CRUMBLAST #%d thread=%u tick=%u %s %d", (int)e.seq, (unsigned)e.tid, (unsigned)e.tick, e.tag, (int)e.arg);
      if (best + 160 > prevMax) log_line("%s", line);   // the log gets the last 160, the text file all
      if (txt && len + n + 2 < 65536) { for (int k = 0; k < n; ++k) txt[len++] = line[k]; txt[len++] = '\r'; txt[len++] = '\n'; }
    }
    if (txt) { write_file(lastPath, txt); HeapFree(GetProcessHeap(), 0, txt); }
  } else log_line("CRUMBLAST none (first run with the black box, or the file is not readable)");
  HANDLE f = CreateFileW(path, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f == INVALID_HANDLE_VALUE) { log_line("CRUMBS black box file could not be created"); return; }
  HANDLE m = CreateFileMappingW(f, nullptr, PAGE_READWRITE, 0, (DWORD)sizeof(CrumbFile), nullptr);
  CloseHandle(f);
  if (!m) { log_line("CRUMBS mapping failed"); return; }
  CrumbFile* v = (CrumbFile*)MapViewOfFile(m, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(CrumbFile));
  CloseHandle(m);
  if (!v) { log_line("CRUMBS view failed"); return; }
  v->magic[0] = 'G'; v->magic[1] = 'B'; v->magic[2] = 'C'; v->magic[3] = 'R'; v->magic[4] = 0;
  v->pid = (LONG)GetCurrentProcessId();
  g_cf = v;
  crumb("start", 0);
  log_line("CRUMBS black box on: the last %d steps are kept in gbvr_crumbs.bin", kCrumbN);
}

// ---- Heartbeat: log flush + stall watchdog -------------------------------------------------------------------------
extern volatile LONG g_vrBusy;
extern volatile LONG g_vrStop;

// ---- 0.88: outside watcher (gbvr_watch.exe) and module-load log ----------------------------------------------------
// The watcher is a separate small program that attaches to the game as a debugger and only looks (see src/watch.c). It is
// the only thing that can see a "fast fail" (abort, stack cookie, invalid parameter), which kills a process before any
// handler inside the game runs. While it is attached the probe hides the debugger flag from the game, so the game cannot
// behave differently because of it.
static HANDLE g_watchEv, g_watchProc;
static volatile LONG g_watchState;   // 0 = not started, 1 = started, waiting for the attach, 2 = attached, 3 = gone

static void watcher_launch() {
  if (!g_ctl.watchGame) { log_line("WATCH off (setting watch_game=0)"); return; }
  if (IsDebuggerPresent()) { log_line("WATCH not started: a debugger is already attached to the game"); return; }
  wchar_t exe[MAX_PATH + 40];
  lstrcpynW(exe, g_selfDir, MAX_PATH);
  lstrcatW(exe, L"gbvr_watch.exe");
  if (GetFileAttributesW(exe) == INVALID_FILE_ATTRIBUTES) { log_line("WATCH gbvr_watch.exe is not next to the DLL: no outside watcher this run"); return; }
  wchar_t evName[64];
  wsprintfW(evName, L"gbvr_watch_attached_%lu", (unsigned long)GetCurrentProcessId());
  g_watchEv = CreateEventW(nullptr, TRUE, FALSE, evName);
  SYSTEMTIME st; GetLocalTime(&st);
  wchar_t logp[MAX_PATH + 80];
  wsprintfW(logp, L"%sgbvr_watch_%04u%02u%02u-%02u%02u%02u.log", log_dir(), st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
  wchar_t cmd[2 * MAX_PATH + 240];
  wsprintfW(cmd, L"\"%s\" %lu \"%s\" %s", exe, (unsigned long)GetCurrentProcessId(), logp, evName);
  STARTUPINFOW si; ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
  PROCESS_INFORMATION pi; ZeroMemory(&pi, sizeof(pi));
  if (CreateProcessW(exe, cmd, nullptr, nullptr, FALSE, CREATE_NO_WINDOW | DETACHED_PROCESS, nullptr, g_selfDir, &si, &pi)) {
    g_watchProc = pi.hProcess;
    CloseHandle(pi.hThread);
    g_watchState = 1;
    log_line("WATCH started gbvr_watch.exe (pid %lu); its log: %ls", (unsigned long)pi.dwProcessId, logp);
  } else {
    log_line("WATCH could not start gbvr_watch.exe (error %lu)", (unsigned long)GetLastError());
  }
}

static void watcher_poll(int tick) {
  if (g_watchState == 1) {
    if (g_watchEv && WaitForSingleObject(g_watchEv, 0) == WAIT_OBJECT_0) {
      g_watchState = 2;
      log_line("WATCH attached: the outside watcher is looking at the game (the debugger flag is hidden from the game)");
    } else if (g_watchProc && WaitForSingleObject(g_watchProc, 0) == WAIT_OBJECT_0) {
      DWORD code = 0; GetExitCodeProcess(g_watchProc, &code);
      g_watchState = 3;
      log_line("WATCH the watcher program ended before attaching (exit code %lu; 3 = could not attach, see gbvr_watch_*.log)", (unsigned long)code);
    } else if (tick == 15) {
      log_line("WATCH no sign of the watcher after 15 s");
    }
  }
  if (g_watchState == 2) {
    unsigned char* peb = nullptr;
    __asm__ volatile("movq %%gs:0x60, %0" : "=r"(peb));
    if (peb && peb[2]) peb[2] = 0;   // PEB.BeingDebugged
    if (g_watchProc && (tick % 5) == 0 && WaitForSingleObject(g_watchProc, 0) == WAIT_OBJECT_0) {
      g_watchState = 3;
      log_line("WATCH the watcher program has ended (the game runs on without it)");
    }
  }
}

typedef BOOL (WINAPI* PFN_EnumProcessModules)(HANDLE, HMODULE*, DWORD, LPDWORD);
static HMODULE g_knownMods[1024];
static int g_nKnownMods, g_modLines;

// New modules since the last second, by name: Media Foundation and the video decoders show up here when a video starts.
static void modules_poll() {
  static PFN_EnumProcessModules fn = nullptr;
  static int tried = 0;
  if (!tried) { tried = 1; HMODULE k = GetModuleHandleW(L"kernel32.dll"); fn = k ? (PFN_EnumProcessModules)GetProcAddress(k, "K32EnumProcessModules") : nullptr; }
  if (!fn) return;
  static HMODULE now[1024];
  DWORD need = 0;
  if (!fn(GetCurrentProcess(), now, sizeof(now), &need)) return;
  int n = (int)(need / sizeof(HMODULE)); if (n > 1024) n = 1024;
  for (int i = 0; i < n; ++i) {
    int known = 0;
    for (int k = 0; k < g_nKnownMods; ++k) if (g_knownMods[k] == now[i]) { known = 1; break; }
    if (known) continue;
    if (g_nKnownMods < 1024) g_knownMods[g_nKnownMods++] = now[i];
    if (g_modLines >= 700) continue;
    ++g_modLines;
    wchar_t nm[MAX_PATH]; nm[0] = 0;
    GetModuleFileNameW(now[i], nm, MAX_PATH);
    const wchar_t* base = nm; for (const wchar_t* p = nm; *p; ++p) if (*p == L'\\') base = p + 1;
    log_line("MODLOAD %ls base=%p", base, (void*)now[i]);
  }
}

// Which Media Foundation files does this Windows have? (A Windows "N" edition without the Media Feature Pack has none.)
static void media_files_note() {
  static const wchar_t* const names[] = {L"mfplat.dll", L"mfreadwrite.dll", L"mf.dll", L"mfmp4srcsnk.dll", L"msmpeg2vdec.dll", L"msmpeg2adec.dll", L"mfsrcsnk.dll", L"wmvcore.dll", L"mfcore.dll", L"mfperfhelper.dll"};
  char line[400]; int n = 0;
  n += wsprintfA(line + n, "MFFILES (Windows media files for video):");
  wchar_t dir[MAX_PATH]; UINT l = GetSystemDirectoryW(dir, MAX_PATH);
  for (const wchar_t* nm : names) {
    wchar_t p[MAX_PATH + 40];
    wsprintfW(p, L"%s\\%s", dir, nm);
    WIN32_FILE_ATTRIBUTE_DATA d;
    if (l && GetFileAttributesExW(p, GetFileExInfoStandard, &d)) n += wsprintfA(line + n, " %ls=%lu", nm, (unsigned long)d.nFileSizeLow);
    else n += wsprintfA(line + n, " %ls=MISSING", nm);
    if (n > 360) break;
  }
  log_line("%s", line);
}

static DWORD WINAPI heartbeat_thread(LPVOID) {
  watcher_launch();
  media_files_note();
  modules_poll();
  LONG last = render_present_count();
  DWORD progressTick = GetTickCount();
  int stallStage = 0;
  int ticks = 0;
  int issuesWritten = 0;
  for (;;) {
    Sleep(1000);
    watcher_poll(ticks);
    modules_poll();
    int si = serious_issues();
    if (si != issuesWritten) { issuesWritten = si; lstrcpynA(g_runStageText, stage_name(g_stageR), (int)sizeof(g_runStageText)); run_rewrite(); }
    ++ticks;
    LONG now = render_present_count();
    if (now != last) {
      if (stallStage > 0) log_line("STALL over: Presents are coming again after about %u s", (unsigned)((GetTickCount() - progressTick) / 1000));
      last = now;
      progressTick = GetTickCount();
      stallStage = 0;
    } else if (now > 0 && g_ctl.stereoWanted) {   // only after the first frame and only while the headset view is wanted
      int secs = (int)((GetTickCount() - progressTick) / 1000);
      if (safety::stall_due(secs, &stallStage)) {
        safety_issue(IS_STALL);
        log_line("STALL no Present for %d s: renderThread=%s gameMainLoop=%s insideSteamVR=%d exiting=%d (a loading screen can do this too; "
                 "if the headset froze, this line says where the code waits)", secs, stage_name(g_stageR), stage_name(g_stageG),
                 (int)g_vrBusy, (int)g_vrStop);
        log_flush_quiet();
      }
    }
#if GBVR_HEADTRACK
    engine_main_stall_check();   // 0.60
#endif
    log_flush_quiet();   // 0.86: every second
  }
  return 0;
}

void safety_start_heartbeat() {
  HANDLE t = CreateThread(nullptr, 0, heartbeat_thread, nullptr, 0, nullptr);
  log_line("SAFETY heartbeat thread %s (log flushed every second, stalls reported)", t ? "started" : "NOT started");
  if (t) CloseHandle(t);
}

// ---- Health line ---------------------------------------------------------------------------------------------------
void safety_health(LONG frame) {
  int total = 0;
  char buf[320];
  int len = 0;
  for (int i = 0; i < IS_COUNT; ++i) {
    if (g_issues[i]) {
      total += (int)g_issues[i];
      len += log_fmt(buf + len, (int)sizeof(buf) - len, " %s=%d", kIssueNames[i], (int)g_issues[i]);
    }
  }
  if (!len) buf[0] = 0;
  log_line("HEALTH frame=%d %s%s renderStage=%s gameStage=%s runCount=%d", (int)frame, total ? "ISSUES:" : "ok", buf, stage_name(g_stageR),
           stage_name(g_stageG), g_runCount);
}

#endif
