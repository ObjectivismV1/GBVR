// 0.44 fail-safe decisions as pure functions (tests/test_safety.cpp).
//
// Three small pieces of logic that must be right because they run when something has already gone wrong:
//  - plan(): what the tool does at start when the previous run did not end cleanly;
//  - PerfWatch: when the picture is too big for the PC to hold the headset's frame rate;
//  - stall_due(): when a "the game stopped presenting frames" line is written.
#pragma once
#include <stdint.h>

namespace safety {

// What the previous run's marker file (gbvr_run.txt) said. present = the file existed.
struct PrevRun {
  int present;     // 1 = a marker was found
  int count;       // abnormal ends in a row so far ("count=")
  int exiting;     // the run had already started closing ("exiting=1"): a hang or freeze at exit, not a failure while playing
  int fault;       // the crash note ran ("fault=1"): the game raised a fatal error
  int ownerAlive;  // the process that wrote it is still running (a second copy of the game): leave it alone
  int issues;      // how many serious problems the run had recorded (stalls, failed Presents, texture errors, fatal errors)
  int rebooted;    // the PC was restarted after the marker was last written (a freeze / power loss while playing)
};

struct Plan {
  int abnormal;         // the previous run ended badly
  int newCount;         // value for this run's marker
  int disableMenuFast;  // switch the 0.43 menu frame-rate change off
  int disableDiag;      // switch the 0.43 compositor timing calls off
  int pictureCap;       // 0 = leave; otherwise the highest picture level allowed (saved)
  int handModelOff;     // draw no hands / wand (own Direct3D pass) any more
  int foreign;          // marker belongs to a running copy: nothing is changed
  int wandMoveOff;      // 0.51: the game's wand model stays where the game animates it (no matrix hook use)
  int bodyFollowOff;    // 0.52: the player's models are not moved to the real body / height
  int realModelsOff;    // 0.51: own body hidden again, placeholder hands / wand
  int armIkOff;         // 0.57: the game's arms are not pulled to the hands (skeleton override)
};

// Evidence: a run that just disappears (the player ended it from Steam or Task Manager) says nothing about the tool;
// it is logged and not counted. Counted: a fatal error was noted, serious problems were recorded during the run, or the PC
// restarted after the run (a freeze).
// Ladder: every counted bad end in a row takes one more step away from the newest, riskiest features.
// 1.7.117: the steps are for THAT RUN ONLY (apply_plan in safety.cpp keeps the player's own values in the settings file), and the first crash only
// takes the two harmless extras away: a game crash must never leave a player without hands / body for good (a Quest 3 player lost his motion controls that way).
//   1st: menu frame rate and compositor timing calls off
//   2nd: + the game's wand moved to the hand, arms pulled to the hands, body follow, full body off
//   3rd: + picture level at most 2 (3840x2160)
//   4th+: + picture level 1 (monitor size), no hand / wand drawing and the game's own body hidden again
// An end during closing ("exiting") is logged but is not counted: it says nothing about playing.
// The count goes back to 0 by itself after one clean exit (the marker is deleted).
inline Plan plan(const PrevRun& p) {
  Plan r = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  if (!p.present) return r;
  if (p.ownerAlive) { r.foreign = 1; r.newCount = p.count; return r; }
  r.abnormal = 1;
  if (p.exiting && !p.fault) { r.newCount = p.count; return r; }
  if (!p.fault && !p.issues && !p.rebooted) { r.newCount = p.count; return r; }
  r.newCount = p.count + 1;
  if (r.newCount >= 1) { r.disableMenuFast = 1; r.disableDiag = 1; }
  if (r.newCount >= 2) { r.wandMoveOff = 1; r.bodyFollowOff = 1; r.armIkOff = 1; }
  if (r.newCount >= 3) r.pictureCap = 2;
  if (r.newCount >= 4) { r.pictureCap = 1; r.handModelOff = 1; r.realModelsOff = 1; }
  return r;
}

// Picture too big for the PC? Called once per report interval (about every 1.3 s).
//   works      frames timed in the interval (pairs of eye pictures); fewer than kMinWorks = no information
//   rate       pairs delivered per second in the interval
//   vsyncHzX10 compositor rate x 10 (0 = unknown)
//   flatFrames menu frames in the interval (an interval that includes a menu says nothing)
//   waitAvgMs  average time the game waited for the compositor's frame slot. A game that is the bottleneck hardly
//              waits (the slot is already there); a long wait means the compositor, the headset (taken off, asleep)
//              or the streaming slows things down - not the picture size - so that interval says nothing either.
// kBadReports in a row below 85 % of the compositor rate -> fires once.
struct PerfWatch {
  static const int kMinWorks = 6, kBadReports = 5;   // 0.56: was 100 - at 7 pairs per second a 1.3 s interval never had that many, so the check never ran
  static constexpr double kMaxWaitMs = 2.0;
  int bad, fired;
  inline void reset() { bad = 0; fired = 0; }
  static constexpr double kHotFraction = 0.82;
  inline int update(int works, double rate, int vsyncHzX10, int flatFrames, double waitAvgMs,
                    double workAvgMs, double workBudgetMs, int overBudgetFrames) {
    if (works < kMinWorks || vsyncHzX10 < 300 || flatFrames > 0 || waitAvgMs >= kMaxWaitMs) return 0;
    // Low delivered rate by itself can be SteamVR / Virtual Desktop / headset timing.
    // Only sacrifice picture resolution when the game's measured work is actually
    // close to or over one display period.
    const int renderHot = workBudgetMs > 2.0 &&
      (workAvgMs >= kHotFraction * workBudgetMs || overBudgetFrames * 4 >= works);
    if (!renderHot) { bad = 0; return 0; }
    if (rate < 0.85 * (double)vsyncHzX10 / 10.0) ++bad; else bad = 0;
    if (bad >= kBadReports && !fired) { fired = 1; return 1; }
    return 0;
  }
};

// Stall log schedule: seconds without a new Present at which a line is written (then none until it recovers).
inline int stall_due(int secondsStalled, int* stage /* in/out: next threshold index */) {
  static const int kAt[] = {5, 10, 20, 40, 80, 160, 320, 640};
  const int n = (int)(sizeof(kAt) / sizeof(kAt[0]));
  if (secondsStalled <= 0) { *stage = 0; return 0; }
  if (*stage < n && secondsStalled >= kAt[*stage]) { ++*stage; return 1; }
  return 0;
}

// Marker text. One format string for the writer (safety.cpp) and the test, so they cannot drift apart.
#define GBVR_RUN_MARKER_FMT "pid=%u; count=%d; version=%s; picture=%d; menufast=%d; exiting=%d; fault=%d; issues=%d; stage=%s;\r\n"

// "name=123;" somewhere in text: the number, or def when the name is missing / has no digits. The name must start a
// field (start of text, or after ';', ' ' or a line break) so that "count=" is not found inside "discount=".
inline int find_number(const char* text, const char* name, int def) {
  int n = 0;
  while (name[n]) ++n;
  for (const char* p = text; *p; ++p) {
    if (!(p == text || p[-1] == ';' || p[-1] == ' ' || p[-1] == '\n' || p[-1] == '\r')) continue;
    int i = 0;
    while (i < n && p[i] == name[i]) ++i;
    if (i != n || p[n] != '=') continue;
    int v = 0, any = 0;
    for (const char* q = p + n + 1; *q >= '0' && *q <= '9' && v < 100000000; ++q) { v = v * 10 + (*q - '0'); any = 1; }
    return any ? v : def;
  }
  return def;
}

// Menu frame-rate lift sanity: the frame time step (1/65536 s) the game measured for a lifted menu tick.
// Anything outside this range is not a believable menu frame (above 1/16 s the game clamps to 4096 anyway).
inline int menu_tick_sane(int32_t ticks) { return ticks >= 1 && ticks <= 70000; }

}  // namespace safety
