#pragma once
#include <stdint.h>
#include "vmath.h"
#include "stereomath.h"   // 1.7.220 (AutoCenter uses angle_diff)

namespace sceneview {
// Only a distant perspective camera following the already confirmed player
// may use the scripted view. Menus and unrelated cutscene cameras stay 2D.
inline int mode(double pivotFt, double eyeFt, int vr, int samePlayer, int actorClass) {
  if (!(pivotFt >= 0.0 && eyeFt >= 0.0)) return -1;
  if (pivotFt <= 8.0 && eyeFt <= 40.0) return 0;
  return vr && samePlayer && actorClass && pivotFt <= 2000.0 && eyeFt <= 2000.0 ? 1 : -1;
}

// 1.7.85: is the scripted camera's follow target still "the player"? The verified player (head) is only refreshed while VR frames run,
// so after a cut that re-creates the player the old pointer used to block the scene for good (a flat screen through the whole Stay Puft
// scene). Same player when nobody is verified yet, it is the verified object, or the old verified object is gone (headAlive 0).
// Another LIVE Ghostbuster (a teammate in a cutscene) is still refused.
inline int same_player(uintptr_t actor, uintptr_t head, int headAlive) {
  if (!actor) return 0;
  if (!head || actor == head) return 1;
  return headAlive ? 0 : 1;
}

struct Encounter {
  uintptr_t world = 0, player = 0, boss = 0;
  int active = 0, normalFrames = 0;
  int update(uintptr_t w, uintptr_t p, uintptr_t b, int alive, int enter) {
    // 1.7.57: once the rooftop fight has switched to floating tracked arms, keep that
    // view-model through Stay Puft's fall and the dialogue that follows. The boss pointer /
    // alive flag disappear before the scripted camera is finished; dropping to the normal
    // game model at that moment is the pop the player reported. Release only after the
    // SAME player has been back on the normal close camera for several consecutive frames.
    // A missing world sample is allowed while an already-active rooftop sequence
    // winds down: the shared boss scan can temporarily publish boss/world=0 on
    // the exact frame Stay Puft disappears. A real player change or a *different
    // nonzero* world still resets immediately.
    if (!p || (player && player != p) || (w && world && world != w)) {
      active = 0; normalFrames = 0; boss = 0; world = w; player = p; return 0;
    }
    if (w) world = w;
    player = p;
    if (!world && !active) { boss = b; normalFrames = 0; return 0; }
    if (alive < 0) return active; // pause / temporarily unreadable fight state: hold the last choice
    if (active) {
      if (b) boss = b;
      if (enter || (b && alive > 0)) { normalFrames = 0; return 1; }
      if (++normalFrames < 12) return 1; // camera transition hysteresis: no one-frame body-mode pop
      active = 0; normalFrames = 0; boss = 0;
      return 0;
    }
    boss = b; normalFrames = 0;
    if (b && alive > 0 && enter) active = 1;
    return active;
  }
};

// Rooftop station: stay at the player's height and angle the VR picture
// toward the boss without moving the game actor.
struct Station {
  int have = 0, stage = 0, suppressed = 0;
  uintptr_t boss = 0;
  float eye[3] = {}, delta[3] = {}, origin[3] = {}, mouth[3] = {};   // 1.7.216: mouth = the point the view was aimed at (for the centring log)
  double yaw = 0, yawDelta = 0, pitchDown = 0, facingYaw = 0;
  int place(uintptr_t b, int s, const float* normal, const float* mouth_in, double gameYaw, double headYaw) {
    if (suppressed) return 0; // do not pin the player again in this encounter
    if (!(gameYaw - gameYaw == 0.0) || !(headYaw - headYaw == 0.0)) return 0;   // 1.7.217: a lost pose (NaN / infinite yaw) never becomes the roof view
    for (int i = 0; i < 3; ++i) if (!vm::is_finite_f(normal[i]) || !vm::is_finite_f(mouth_in[i])) return 0;
    const double dx = normal[0] - mouth_in[0], dz = normal[2] - mouth_in[2];
    const double d = vm::dsqrt(dx * dx + dz * dz);
    if (!(d >= 20.0 && d <= 1000.0) || vm::dabs((double)normal[1] - mouth_in[1]) > 500.0) return 0;
    // Move only the VR view outward past the nearby spawn cable and building.
    // The game actor and the cable's physics stay untouched.
    eye[0] = (float)(normal[0] - dx / d * 10.0);
    eye[1] = normal[1] + 1.25f;
    eye[2] = (float)(normal[2] - dz / d * 10.0);
    const double fx = (double)mouth_in[0] - eye[0], fz = (double)mouth_in[2] - eye[2];
    facingYaw = vm::datan2(fx, fz);
    pitchDown = vm::datan2((double)eye[1] - mouth_in[1], vm::dsqrt(fx * fx + fz * fz));
    yaw = facingYaw - headYaw;
    yawDelta = yaw - gameYaw;
    boss = b; stage = s; have = 1;
    for (int i = 0; i < 3; ++i) { origin[i] = normal[i]; mouth[i] = mouth_in[i]; }
    return 1;
  }
  int release_if_walking(const float* normal, int moveStick) {
    if (!have || !moveStick || !vm::is_finite_f(normal[0]) || !vm::is_finite_f(normal[2])) return 0;
    const double dx = (double)normal[0] - origin[0], dz = (double)normal[2] - origin[2];
    if (dx * dx + dz * dz <= 9.0) return 0; // three feet from the view's anchor
    have = 0; suppressed = 1;
    return 1;
  }
  void offset(const float* normal, double gameYaw) {
    for (int i = 0; i < 3; ++i) delta[i] = eye[i] - normal[i];
    yawDelta = yaw - gameYaw;
  }
};

// Rotate the rendered view down around the horizontal axis toward the boss.
// Physical head movement still changes the final view; no game camera or
// headset tracking pose is rewritten.
inline void aim_down(float* view, double yaw, double pitchDown) {
  double sy, cy, sp, cp;
  vm::dsincos(yaw, &sy, &cy);
  vm::dsincos(pitchDown, &sp, &cp);
  const double right[3] = {cy, 0, -sy};
  for (int col = 0; col < 3; ++col) {
    const double x = view[col], y = view[3 + col], z = view[6 + col];
    const double along = right[0] * x + right[2] * z;
    view[col] = (float)(x * cp + (right[1] * z - right[2] * y) * sp + right[0] * along * (1 - cp));
    view[3 + col] = (float)(y * cp + (right[2] * x - right[0] * z) * sp);
    view[6 + col] = (float)(z * cp + (right[0] * y - right[1] * x) * sp + right[2] * along * (1 - cp));
  }
}

inline int nearby_rig(const float* grip, const float* origin, const float* delta) {
  double d = 0;
  for (int i = 0; i < 3; ++i) { const double x = (double)grip[i] - origin[i] - delta[i]; d += x * x; }
  return d <= 12.0 * 12.0;
}

// 1.7.220 ROOF AUTO-CENTRE: once per fight, 3 s after the roof view was placed, if the head rests 12+ deg off the boss
// direction (turning under 12 deg/s for 0.8 s) ask for the usual re-centre. Pure logic so it can be tested.
struct AutoCenter {
  double t0, lastT, hs, hsOld, hsOldT, steadyT, lastStationYaw; uintptr_t boss; int count, started, haveHs;
  void reset() { t0 = lastT = hs = hsOld = hsOldT = steadyT = 0; lastStationYaw = 1e9; boss = 0; count = 0; started = 0; haveHs = 0; lastRate = 999.0; }
  // returns 1 when the view should re-centre now; offDeg/rateDeg/ageS are filled for the log.
  // 1.7.221: the heading of a head that looks almost straight down jitters by several degrees from frame to frame, so a per-frame turning rate kept restarting the "resting" timer (the
  // re-centre came 29.8 s late in the 1.7.220 log). The heading is smoothed (about 0.2 s) and its turning is measured over 0.3 s; waiting after placement is 2 s.
  int step(double now, uintptr_t b, double stationYaw, double headYaw, double facingYaw, int enabled, double* offDeg, double* rateDeg, double* ageS) {
    if (!started) { reset(); started = 1; }
    // (an angle is within +-pi; anything wild is not a heading)
    if (!(headYaw - headYaw == 0.0) || !(facingYaw - facingYaw == 0.0) || headYaw > 100.0 || headYaw < -100.0 || facingYaw > 100.0 || facingYaw < -100.0) { if (offDeg) *offDeg = 0; if (rateDeg) *rateDeg = 0; if (ageS) *ageS = 0; return 0; }
    if (b != boss) { boss = b; count = 0; lastStationYaw = 1e9; }
    if (stationYaw != lastStationYaw) { lastStationYaw = stationYaw; t0 = now; steadyT = 0; haveHs = 0; }
    const double dt = lastT > 0 ? now - lastT : 0.0;
    lastT = now;
    if (!haveHs) { hs = headYaw; hsOld = headYaw; hsOldT = now; haveHs = 1; }
    else { const double a = dt > 0 ? dt / (0.2 + dt) : 0.0; double d = headYaw - hs; while (d > vm::kPi) d -= 2 * vm::kPi; while (d < -vm::kPi) d += 2 * vm::kPi; hs += d * a; }
    double rate = 0.0;
    if (now - hsOldT >= 0.3) { rate = stereo::angle_diff(hs, hsOld) / (now - hsOldT) * 57.29577951308232; hsOld = hs; hsOldT = now; lastRate = rate; } else rate = lastRate;
    const double off = stereo::angle_diff(hs, facingYaw) * 57.29577951308232;
    if (offDeg) *offDeg = off; if (rateDeg) *rateDeg = rate; if (ageS) *ageS = now - t0;
    if (!enabled || count >= 1 || !(off - off == 0.0)) return 0;
    if (now - t0 < 2.0) return 0;
    if (off >= 12.0 && rate < 15.0) {
      if (steadyT == 0) steadyT = now;
      if (now - steadyT >= 0.6) { ++count; steadyT = 0; return 1; }
    } else steadyT = 0;
    return 0;
  }
  double lastRate = 999.0;
};
}
