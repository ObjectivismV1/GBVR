// 0.25: remembers the player's tuning between runs.
// gbvr_settings.txt in the game folder, plain "name=number" lines. Loaded once
// when the probe starts, written (a moment after a key changed something) by
// the render thread. Unknown names are ignored, values are clamped, a missing
// or unreadable file simply means defaults.
#include "gbvr.h"
#include "memcache.h"

#if GBVR_HEADTRACK

struct Item { const char* name; volatile LONG* value; LONG lo, hi; };
volatile LONG g_guardKeepLevel = 0, g_guardLoweredTo = 0;   // 0.83
static const LONG kSettingsRev = 176;   // 146 = the 1.7.73 build (no source; its saved values are kept)  // bumped when a default changes and an old saved value should follow it
static volatile LONG g_settingsRev;
static Item g_items[] = {
  {"size_percent", &g_ctl.sizePct, 70, 150},          // player height (0.25 name kept so the saved value carries over)
  {"world_percent", &g_ctl.worldPct, 60, 160},        // 0.26
  {"picture_lines", &g_ctl.pictureLines, 0, 2880},    // 1.7.117: 0 = follow picture_level; else lines (720..2880)
  {"picture_level", &g_ctl.pictureLevel, 1, 4},       // 0.26
  {"same_moment", &g_ctl.stereoSameMoment, 0, 1},     // 0.27
  {"hide_body", &g_ctl.hideBody, 0, 2},               // 0.28 (a saved 2 = "wand too" is read as 1 from 0.30)
  {"hide_wand", &g_ctl.hideWand, 0, 1},               // 0.30
  {"hide_shadow", &g_ctl.hideShadow, 0, 1},           // 0.30
  {"aim_source", &g_ctl.headAim, 0, 2},               // 0.33: 0 mouse, 1 head, 2 hands (0.32 called it head_aim)
  {"pad_enabled", &g_ctl.padEnabled, 0, 1},           // 0.33
  {"two_hand_fire", &g_ctl.twoHandFire, 0, 1},        // 0.33
  {"hand_pitch_deci", &g_ctl.handPitchDeci, -600, 600},// 0.33
  {"stick_deadzone_pct", &g_ctl.stickDeadzonePct, 5, 50},// 0.33
  {"hand_model", &g_ctl.handModel, 0, 1},             // 0.34
  {"real_models", &g_ctl.realModels, 0, 1},           // 0.51
  {"full_body", &g_ctl.fullBody, 0, 1},               // 0.61
  {"body_lean_cm", &g_ctl.bodyLeanCm, 0, 80},         // 0.61: how far you can lean before the feet follow
  {"body_lean_deg", &g_ctl.bodyLeanDeg, 10, 90},      // 0.61
  {"body_head_deg", &g_ctl.bodyHeadDeg, 20, 150},     // 0.61
  {"body_drop_cm", &g_ctl.bodyDropCm, 10, 120},       // 0.61
  {"body_crouch", &g_ctl.bodyCrouch, 0, 1},           // 0.61
  {"arm_stretch_pct", &g_ctl.armStretchPct, 100, 400},// 0.61: longest arm stretch (100 = off); 0.66: up to 400, default 260
  {"gun_glue", &g_ctl.gunGlue, 0, 1},                 // 0.66
  {"body_eye_align", &g_ctl.bodyEyeAlign, 0, 1},      // 0.68: the avatar's eyes sit exactly at the camera's eye
  {"eye_shift_cap_cm", &g_ctl.eyeShiftCapCm, 5, 100},  // 0.69: the whole body may shift this far to put the avatar's eyes at the camera
  {"arms_only", &g_ctl.armsOnly, 0, 1},                // 0.71
  {"arms_shoulders", &g_ctl.armsShoulders, 0, 1},      // 0.73
  {"arms_straps", &g_ctl.armsStraps, 0, 1},            // 0.80
  {"pke_body", &g_ctl.pkeBody, 0, 1},
  {"gloves_only", &g_ctl.glovesOnly, 0, 1},          // 0.83
  {"fingers", &g_ctl.fingers, 0, 1},                  // 0.84
  {"real_anchor", &g_ctl.realAnchor, 0, 1},           // 0.84
  {"pke_bones", &g_ctl.pkeBones, 0, 1},               // 0.85
  {"skip_videos", &g_ctl.skipVideos, 0, 1},           // 0.85
  {"watch_game", &g_ctl.watchGame, 0, 1},             // 0.88: start gbvr_watch.exe (outside watcher that records how the game dies)
  {"body_height_cm", &g_ctl.bodyHeightCm, -30, 30},   // 0.85
  {"pke_attach", &g_ctl.pkeAttach, 0, 1},             // 0.84                  // 0.81
  {"solid_body", &g_ctl.solidBody, 0, 1},              // 0.81
  {"left_under", &g_ctl.leftUnder, 0, 1},             // 1.7.19
  {"aim_live", &g_ctl.aimLive, 0, 1},                   // 1.7.21
  {"damage_watch", &g_ctl.damageWatch, 0, 1},           // 1.7.21
  {"blink_dash", &g_ctl.blinkDash, 0, 1},              // 1.7.22
  {"vignette_pct", &g_ctl.vignettePct, 0, 100},        // 1.7.22
  {"body_bend_pct", &g_ctl.bodyBendPct, 0, 100},        // 1.7.21
  {"body_bend_max_deg", &g_ctl.bodyBendMaxDeg, 0, 80},  // 1.7.21
  {"left_thumb_anim", &g_ctl.leftThumbAnim, 0, 1},    // 1.7.23
  {"controller_layout", &g_ctl.controllerLayout, 0, 5},   // 1.7.117 (file only): 0 detect, 1 Touch, 2 Index, 3 Vive, 4 Windows MR, 5 other
  {"stick_axis", &g_ctl.stickAxisForce, -1, 4},            // 1.7.117 (file only): -1 detect, else the analog axis the stick is on
  {"left_handed", &g_ctl.leftHanded, 0, 1},           // 1.7.19
  {"seated", &g_ctl.seated, 0, 1},                    // 1.7.19
  {"seat_cm", &g_ctl.seatCm, -40, 40},                // 1.7.19
  {"profile_slot", &g_ctl.profileSlot, 1, 3},         // 1.7.19
  {"left_under_cm", &g_ctl.leftUnderCm, 0, 15},       // 1.7.19
  {"left_grip_pct", &g_ctl.leftGripPct, 0, 100},       // 0.81
  {"cord_physics", &g_ctl.cordPhysics, 0, 1},          // 0.73
  {"sim_step_cap_ms", &g_ctl.simStepCapMs, 0, 100},   // 0.73
  {"sim_every_n", &g_ctl.simEveryN, 1, 3},             // 0.74
  {"rig_view", &g_ctl.rigView, 0, 4},                  // 0.74
  {"shoulder_slide_cm", &g_ctl.shoulderSlideCm, 0, 30},// 0.74
  {"view_up_cm", &g_ctl.viewUpCm, 0, 30},              // 0.75
  {"body_out_cm", &g_ctl.bodyOutCm, 0, 30},            // 0.75
  {"wall_diag", &g_ctl.wallDiag, 0, 0},                // retired: no automatic wall probes
  {"rig_auto_shots", &g_ctl.rigAutoShots, 0, 0},       // retired: screenshots only when requested
  {"beam_damage_pct", &g_ctl.beamDamagePct, 100, 400}, // 0.76: beams do this percent of the game's damage to enemies (115 = +15 %)
  {"hbar", &g_ctl.hbar, 0, 1},                         // 0.76: small bold health bars inside the enemies
  {"hbar_size_pct", &g_ctl.hbarSizePct, 30, 300},      // 0.76
  {"hbar_alpha_pct", &g_ctl.hbarAlphaPct, 15, 100},   // 1.7.19
  {"hbar_digits", &g_ctl.hbarDigits, 0, 1},            // 0.76
  {"slam_gesture", &g_ctl.slamGesture, 0, 1},          // 0.76
  {"hbar_gate", &g_ctl.hbarGate, 0, 1},                // 0.77: bars only on ghosts that are drawn and not behind a wall
  {"weapon_wheel", &g_ctl.weaponWheel, 0, 1},          // 0.77: hold the right grip = weapon wheel
  {"wheel_scale_pct", &g_ctl.wheelScalePct, 50, 250},  // 0.77
  {"trap_throw", &g_ctl.trapThrow, 0, 1},              // 0.77: grab the trap at the left hip, throw it
  {"slam_flick_pct", &g_ctl.slamFlickPct, 0, 100},     // 0.77
  {"lt_capture", &g_ctl.ltCapture, 0, 1},              // legacy; 1.7.57 forces 0 so the left trigger remains the game's LT / alternate fire
  {"slam_speed_deci", &g_ctl.slamSpeedDeci, 10, 80},   // 0.77: slam swing speed, 1/10 m/s
  {"view_model_pct", &g_ctl.viewModelPct, 80, 200},    // 0.77: size of the gun / hands in view
  {"chest_shield", &g_ctl.chestShield, 0, 1},                  // 0.77
  {"pke_like_gun", &g_ctl.pkeLikeGun, 0, 1},
  {"pke_own", &g_ctl.pkeOwn, 0, 1},                  // 0.93 (the probe's own drawn PKE: rejected by the player, off since 0.94)
  {"pke_tilt_deg", &g_ctl.pkeTiltDeg, -60, 90},      // 0.93; 0.94: tips the game's PKE (front down) about your hand
  {"pke_game", &g_ctl.pkeGame, 0, 1},                // 0.94: the game's own PKE meter in your hand
  {"pke_entity", &g_ctl.pkeEntity, 0, 1},            // 0.97: ... moved by the matrix the game really draws and scans from
  {"pke_fwd_cm", &g_ctl.pkeFwdCm, -30, 30},          // 0.94
  {"pke_up_cm", &g_ctl.pkeUpCm, -30, 30},            // 0.94
  {"pke_assist_deg", &g_ctl.pkeAssistDeg, 0, 45},    // 0.94: scan help cone
  {"pke_assist_pct", &g_ctl.pkeAssistPct, 0, 200},   // 0.94
  {"pke_easy", &g_ctl.pkeEasy, 0, 1},                // 1.4: forgiving PKE scan (wider range and cone than the game's)
  {"pke_easy_ft", &g_ctl.pkeEasyFt, 15, 80},         // 1.4: scan range in feet (the game's own: 15)
  {"pke_close_help", &g_ctl.pkeCloseHelp, 0, 1},       // 1.7.83: wider scan cone when a scannable thing is close to the meter
  {"pke_cone_deg", &g_ctl.pkeConeDeg, 18, 70},       // 1.4: scan cone in degrees (the game's own: 18)
  {"pke_auto", &g_ctl.pkeAuto, 0, 1},                // 1.4: the scan starts by itself when the PKE points at something scannable
  {"pke_frame", &g_ctl.pkeFrame, 0, 1},              // 1.4: 1 = keep the game's green goggle frame
  {"ring_assist", &g_ctl.ringAssist, 0, 1},          // 1.5: the game's own health ring on the ghost you look at
  {"ring_cone_deg", &g_ctl.ringConeDeg, 8, 70},      // 1.5
  {"ring_hold_ds", &g_ctl.ringHoldDs, 0, 100},       // 1.5: tenths of a second the ring stays after you look away
  {"turn_follow", &g_ctl.turnFollow, 0, 1},          // 1.5: the body turns after your head
  {"turn_follow_deg", &g_ctl.turnFollowDeg, 15, 120},// 1.5
  {"turn_snap", &g_ctl.turnSnap, 0, 1},              // 1.5: right stick = snap turn (0 = the game's smooth turn)
  {"turn_snap_deg", &g_ctl.turnSnapDeg, 10, 90},     // 1.5
  {"turn_smooth_dps", &g_ctl.turnSmoothDps, 30, 360},   // 1.7.81
  {"turn_smooth_own", &g_ctl.turnSmoothOwn, 0, 1},      // 1.7.81
  {"gun_twist_pct", &g_ctl.gunTwistPct, 0, 100},     // 0.94: the gun follows the hand's twist at once
  {"pke_weight_pct", &g_ctl.pkeWeightPct, 0, 100},   // 0.95: a little weight for the PKE
  {"left_hand_draw", &g_ctl.leftHandDraw, 0, 1},       // 1.7.174
  {"gun_fire_fx", &g_ctl.gunFireFx, 0, 1},             // 1.7.173
  {"trap_no_anim", &g_ctl.trapNoAnim, 0, 1},            // 1.7.173
  {"gun_punish_pct", &g_ctl.gunPunishPct, 0, 200},   // 0.95: how hard a one-handed shot is
  {"flat_void", &g_ctl.flatVoid, 0, 1},              // 0.95: a black void around the flat 2D screen
  {"flat_glow_pct", &g_ctl.flatGlowPct, 0, 100},     // 0.95: the TV glow around the flat screen
  {"flat_black_frames", &g_ctl.flatBlack, 0, 1},    // 0.98: black frames behind the flat screen (no SteamVR Home)
  {"flat_glow_steady", &g_ctl.flatGlowSteady, 0, 1},// 0.98: calm TV glow
  {"switch_help", &g_ctl.switchHelp, 0, 1},          // 1.1: finish a stuck gear switch, queue the PKE / gun like the Y button
  {"flat_size_pct", &g_ctl.flatSizePct, 50, 200},    // 1.1: size of the flat 2D screen
  {"flat_dist_cm", &g_ctl.flatDistCm, 120, 500},     // 1.1: distance of the flat 2D screen
  {"flat_drop_cm", &g_ctl.flatDropCm, -40, 80},      // 1.1: how far below the eyes the screen's middle sits
  {"flat_curve_pct", &g_ctl.flatCurvePct, 0, 100},   // 1.1: how much the flat screen bends around you
  {"monitor_view", &g_ctl.monitorView, 0, 1},        // 1.2: the PC window shows one steady eye picture
  {"monitor_eye", &g_ctl.monitorEye, 0, 1},          // 1.2: 0 left, 1 right
  {"monitor_fit", &g_ctl.monitorFit, 0, 1},          // 1.2: 0 whole picture, 1 fill the window
  {"monitor_level", &g_ctl.monitorLevel, 0, 1},      // 1.2: keep the horizon level
  {"monitor_zoom_pct", &g_ctl.monitorZoomPct, 30, 100},   // 1.2: how much of the picture is shown
  {"monitor_hfov_deg", &g_ctl.monitorHfovDeg, 0, 130},    // 1.7.28: degrees across in the PC window (0 = use monitor_zoom_pct)
  {"monitor_down_deg", &g_ctl.monitorDownDeg, 0, 25},
  {"monitor_hand_frame", &g_ctl.monitorHandFrame, 0, 1},
  {"monitor_menu_fill", &g_ctl.monitorMenuFill, 0, 1},    // 1.7.28: the flat menu fills the PC window
  {"held_live", &g_ctl.heldLive, 0, 1},                   // 1.7.84: the menu shows the live world (frozen game), not a still picture
  {"held_menu", &g_ctl.heldMenu, 0, 1},                   // 1.7.28: the game's pause menu is held in the hand
  {"held_menu_cm", &g_ctl.heldMenuCm, 30, 90},            // 1.7.28: its width
  {"body_calm_ms", &g_ctl.bodyCalmMs, 0, 600},             // 1.7.29: calm walking (0 = off)
  {"mirror_vr", &g_ctl.mirrorVr, 0, 1},                   // 1.7.30: mirrors follow the headset eye and view
  {"hbar_smart", &g_ctl.hbarSmart, 0, 1},                 // 1.7.30: no health bar before the ghost was seen / while it is in the trap
  {"pair_hands", &g_ctl.pairHands, 0, 1},                 // 1.7.31: same hand poses for both eyes of a pair
  {"held_menu_follow", &g_ctl.heldMenuFollow, 0, 1},      // 1.7.31: the hand-held menu follows the hand from its own fast loop
  {"trap_free", &g_ctl.trapFree, 0, 1},                     // 1.7.37
  {"trap_from_hand", &g_ctl.trapFromHand, 0, 1},          // 1.7.37
  {"sprint_game", &g_ctl.sprintGame, 0, 0},               // legacy key; native run route removed
  {"boson_grip", &g_ctl.bosonGrip, 0, 1},                 // 1.7.41
  {"chest_cam", &g_ctl.chestCam, 0, 1},                   // 1.7.38
  {"chest_cam_every", &g_ctl.chestCamEvery, 1, 8},        // 1.7.38
  {"chest_cam_down_cm", &g_ctl.chestCamDownCm, 0, 60},    // 1.7.38
  {"chest_cam_back_cm", &g_ctl.chestCamBackCm, 0, 80},    // 1.7.38
  {"chest_cam_near_cm", &g_ctl.chestCamNearCm, 5, 80},    // 1.7.38
  {"ghost_hp_liquid", &g_ctl.ghostHpLiquid, 0, 1},        // 1.7.158
  {"gun_hp_liquid", &g_ctl.gunHpLiquid, 0, 1},            // 1.7.157
  {"gun_hp_bar", &g_ctl.gunHpBar, 0, 1},                  // 1.7.37
  {"gun_hp_fwd_cm", &g_ctl.gunHpFwdCm, 0, 40},            // 1.7.37
  {"gun_hp_up_cm", &g_ctl.gunHpUpCm, -10, 15},            // 1.7.37 (1.7.64: below the grip line too)
  {"gun_hp_side_cm", &g_ctl.gunHpSideCm, -20, 20},        // 1.7.64: left (-) / right (+) of the gun
  {"hide_belt_pke", &g_ctl.hideBeltPke, 0, 1},            // 1.7.64
  {"pke_grip_heal", &g_ctl.pkeGripHeal, 0, 1},            // 1.7.64
  {"pke_live_grip", &g_ctl.pkeLiveGrip, 0, 1},            // 1.7.66
  {"pke_rigid_hand", &g_ctl.pkeRigidHand, 0, 1},          // 1.7.67
  {"gun_live_grip", &g_ctl.gunLiveGrip, 0, 1},            // 1.7.68
  {"pke_steady_only", &g_ctl.pkeSteadyOnly, 0, 1},        // 1.7.69
  {"pke_set_matrix", &g_ctl.pkeSetMatrix, 0, 1},          // 1.7.70
  {"hand_clean", &g_ctl.handClean, 0, 1},                 // 1.7.70
  {"arm_reach_pct", &g_ctl.armReachPct, 100, 160},        // 1.7.69
  {"stairs_smooth_ms", &g_ctl.stairsSmoothMs, 0, 400},    // 1.7.69
  {"stairs_ramp", &g_ctl.stairsRamp, 0, 1},               // 1.7.71
  {"stairs_lift", &g_ctl.stairsLift, 0, 1},               // 1.7.71
  {"pke_draw_swap", &g_ctl.pkeDrawSwap, 0, 1},            // 1.7.71
  {"slime_muzzle", &g_ctl.slimeMuzzle, 0, 1},             // 1.7.71
  {"gun_hold_smooth_ms", &g_ctl.gunHoldSmoothMs, 0, 400}, // 1.7.71
  {"pke_hold_rpke", &g_ctl.pkeHoldRpke, 0, 1},            // 1.7.74
  {"slime_lt_edge", &g_ctl.slimeLtEdge, 0, 1},            // 1.7.74
  {"slime_rope_fix", &g_ctl.slimeRopeFix, 0, 1},          // 1.7.76
  {"pke_ctl_rigid", &g_ctl.pkeCtlRigid, 0, 1},            // 1.7.76
  {"gun_fresh_hand", &g_ctl.gunFreshHand, 0, 1},          // 1.7.77
  {"keep_control", &g_ctl.keepControl, 0, 1},             // 1.7.79
  {"gun_ctl_follow", &g_ctl.gunCtlFollow, 0, 1},          // 1.7.78
  {"gun_draw_anim", &g_ctl.drawAnim, 0, 1},
  {"gun_wait_draw", &g_ctl.gunWaitDraw, 0, 1},               // 1.7.98
  {"pke_fingers_anim", &g_ctl.pkeFingersAnim, 0, 1},      // 1.7.76
  {"game_fingers", &g_ctl.gameFingers, 0, 1},              // 1.7.103
  {"ghost_ring", &g_ctl.ghostRing, 0, 1},                // 1.7.103
  {"ring_follow", &g_ctl.ringFollow, 0, 1},              // 1.7.111
  {"health_style", &g_ctl.healthStyle, 0, 1},            // 1.7.111: 0 = round ring on the ghost you aim at, 1 = bars over the ghosts
  {"fore_near_cm", &g_ctl.foreNearCm, 0, 40},            // 1.7.114: the free hand within this many cm of the barrel takes hold of it (0 = only with the grip squeezed)
  {"health_any", &g_ctl.healthAny, 0, 1},                // 1.7.113: 1 = health on any ghost you can see, hit or hold (the game's can-lock test is not the only judge)
  {"two_hand_line", &g_ctl.twoHandLine, 0, 1},           // 1.7.127: 1 = aim along both hands (default); 0 = right controller only
  {"capture_tap", &g_ctl.captureTap, 0, 1},              // 1.7.111: 1 = right-stick click toggles the grab (tap to grab, tap again to let go)
  {"og_health", &g_ctl.ogHealth, 0, 1},                  // 1.7.106
  {"ring_wall", &g_ctl.ringWall, 0, 1},                  // 1.7.108
  {"gun_finger_open_pct", &g_ctl.gunFingerOpenPct, 0, 80},   // 1.7.111
  {"pke_centre", &g_ctl.pkeCentre, 0, 1},
  {"gun_hp_physics", &g_ctl.gunHpPhysics, 0, 1},
  {"trap_hang", &g_ctl.trapHang, 0, 1},
  {"trap_gravity", &g_ctl.trapGravity, 0, 1},
  {"body_down_back_cm", &g_ctl.bodyDownBackCm, 0, 30},
  {"station_beam_free", &g_ctl.stationBeamFree, 0, 1},     // 1.7.169
  {"station_back_cm", &g_ctl.stationBackCm, 0, 40},        // 1.7.169     // 1.7.168
  {"gun_hp_on_gun", &g_ctl.gunHpOnGun, 0, 1},             // 1.7.167
  {"gun_hp_hand_cut", &g_ctl.gunHpHandCut, 0, 1},         // 1.7.167
  {"gun_hp_rigid", &g_ctl.gunHpRigid, 0, 1},              // 1.7.185
  {"body_hands_yaw", &g_ctl.bodyHandsYaw, 0, 1},          // 1.7.167                   // 1.7.166          // 1.7.162                // 1.7.158
  {"pke_align_pitch", &g_ctl.pkeAlignPitch, 0, 1},       // 1.7.111
  {"pke_pitch_deg", &g_ctl.pkePitchDeg, -45, 60},         // 1.7.111
  {"pke_ease_ms", &g_ctl.pkeEaseMs, 0, 2000},            // 1.7.225
  {"pke_turn_max_deg", &g_ctl.pkeTurnMaxDeg, 0, 90},      // 1.7.224
  {"pke_align", &g_ctl.pkeAlign, 0, 1},                  // 1.7.104
  {"fore_steady", &g_ctl.foreSteady, 0, 1},              // 1.7.104
  {"trigger_finger_deg", &g_ctl.trigFingerDeg, 10, 70},  // 1.7.109
  {"finger_analog", &g_ctl.fingerAnalog, 0, 1},          // 1.7.111
  {"grab_orbit_deg", &g_ctl.grabOrbitDeg, -90, 180},      // 1.7.111
  {"grab_orbit_follow_pct", &g_ctl.grabOrbitFollowPct, 0, 100},   // 1.7.111
  {"grab_wrap", &g_ctl.grabWrap, 0, 1},                  // 1.7.109
  {"grab_wrap_deg", &g_ctl.grabWrapDeg, 0, 70},          // 1.7.109
  {"gun_hand_no_anim", &g_ctl.gunHandNoAnim, 0, 1},       // 1.7.226
  {"dart_pause_stream", &g_ctl.dartPauseStream, 0, 1},   // 1.7.224
  {"roof_auto_center", &g_ctl.roofAutoCenter, 0, 1},     // 1.7.220
  {"fore_grab", &g_ctl.foreGrab, 0, 1},                  // 1.7.105
  {"empty_fingers", &g_ctl.emptyFingers, 0, 1},          // 1.7.104
  {"trap_hold", &g_ctl.trapHold, 0, 1},                  // 1.7.103
  {"gun_grip_heal", &g_ctl.gunGripHeal, 0, 1},            // 1.7.66
  {"hide_gun_gap", &g_ctl.hideGunGap, 0, 1},              // 1.7.66
  {"knock_comfort", &g_ctl.knockComfort, 0, 1},           // 1.7.36
  {"body_calm_slam", &g_ctl.bodyCalmSlam, 0, 1},
  {"trap_hang_pct", &g_ctl.trapHangPct, -100, 200},          // 1.7.197
  {"down_vignette", &g_ctl.downVignette, 0, 1},           // 1.7.197         // 1.7.196
  {"knock_ms", &g_ctl.knockMs, 800, 8000},                // 1.7.36
  {"knock_walk_pct", &g_ctl.knockWalkPct, 10, 100},       // 1.7.36
  {"knock_aim_deg", &g_ctl.knockAimDeg, 0, 12},           // 1.7.36
  {"knock_dark_pct", &g_ctl.knockDarkPct, 0, 100},        // 1.7.36
  {"held_menu_min_cm", &g_ctl.heldMenuMinCm, 0, 120},     // 1.7.31: never closer than this to the eyes
  {"monitor_wide_pct", &g_ctl.monitorWidePct, 100, 150},  // 1.7.9: how much wider than the headset needs the game draws while the monitor view is on
  {"pke_prox_buzz", &g_ctl.pkeProxBuzz, 0, 1},       // 1.7.13
  {"hold_view", &g_ctl.holdView, 0, 1},                 // 1.7.17: no spin while capturing
  {"finger_rest_pct", &g_ctl.fingerRestPct, 0, 60},     // 1.7.17: relaxed open hand
  {"game_place", &g_ctl.gamePlace, 0, 1},             // 1.7.13: the game places the gun and the PKE
  {"stream_aim_gun", &g_ctl.streamAimGun, 0, 1},     // 1.7.10: the game's hit point for the stream is put on the line of the gun's barrel
  {"pke_goggles", &g_ctl.pkeGoggles, 0, 2},          // 1.7.9: the green PKE goggle view is on while the PKE is in the hand (2 = also the developer switch)
  {"start_in_vr", &g_ctl.startInVr, 0, 1},           // 1.3: the headset view starts by itself
  {"scene_fade_ms", &g_ctl.sceneFadeMs, 0, 6000},    // 1.7.186: the roof-fight fade-up
  {"fade_in_ms", &g_ctl.fadeInMs, 0, 1500},          // 1.3: fade from black when 3D takes over from a 2D screen
  {"flat_cursor", &g_ctl.flatCursor, 0, 1},          // 1.3: ring cursor on the 2D screen
  {"flat_cursor_pct", &g_ctl.flatCursorPct, 40, 250},// 1.3: its size
  {"menu_dim_flat", &g_ctl.menuDimFlat, 0, 1},       // 1.3: dim the 2D screen behind the VR menu
  {"pke_show_body", &g_ctl.pkeShowBody, 0, 1},      // 0.98: body stays visible with the PKE out
  {"pke_pair_cache", &g_ctl.pkePairCache, 0, 1},    // 0.98: PKE placed once per eye pair
  {"pke_shift_pct", &g_ctl.pkeShiftPct, 0, 100},      // 0.98: how much of the hand slide the PKE uses
  {"pke_rigid", &g_ctl.pkeRigid, 0, 1},             // 1.6: PKE keeps one fixed spot in the hand
  {"hand_lock", &g_ctl.handLock, 0, 1},              // 1.7.32: rigid hand attachment, no artificial lag
  {"vr_fps_cap", &g_ctl.vrFpsCap, 0, 120},           // 1.7.33: Off, 72, 80, 90, 120
  {"gun_rigid", &g_ctl.gunRigid, 0, 1},             // 1.6: same for the gun
  {"wheel_alpha_pct", &g_ctl.wheelAlphaPct, 25, 100},// 1.6: how solid the weapon wheel is
  {"hud_retry", &g_ctl.hudRetry, 0, 1},              // 1.6: redraw the game HUD for an eye that missed it
  {"pke_scan_help", &g_ctl.pkeScanHelp, 0, 1},       // 1.6: scan driven by the probe
  {"ring_clear_gone", &g_ctl.ringClearGone, 0, 1},   // 1.6: drop the ring when the ghost is gone
  {"gun_wrap_pct", &g_ctl.gunWrapPct, 0, 100},       // 1.7: weapon hand keeps its grip fingers wrapped
  {"gun_fwd_cm", &g_ctl.gunFwdCm, -30, 30},          // 1.7: gun fit forward / back
  {"gun_up_cm", &g_ctl.gunUpCm, -30, 30},            // 1.7: gun fit up / down
  {"aim_ghost_only", &g_ctl.aimGhostOnly, 0, 1},     // 1.7: aim assist only for ghosts
  {"pke_trigger_scan", &g_ctl.pkeTrigScan, 0, 1},    // 1.7: right trigger scans with the PKE out
  {"easy_sprint", &g_ctl.easySprint, 0, 0},          // legacy key; native sprint tuning removed
  {"sprint_latch", &g_ctl.sprintLatch, 0, 1},        // 1.7: tap the left stick click to keep sprinting
  {"sprint_turn_free", &g_ctl.sprintTurnFree, 0, 1}, // 1.7: no turn clamp while sprinting
  {"slam_trigger", &g_ctl.slamTrigger, 0, 1},        // 1.7: slam on the left trigger
  {"slam_assist", &g_ctl.slamAssist, 0, 1},
  {"eye_aa", &g_ctl.eyeAa, 0, 1},   // 1.7.153
  {"eye_aa_sharp_pct", &g_ctl.eyeAaSharpPct, 0, 100},   // 1.7.153
  {"cut_hold_ms", &g_ctl.cutHoldMs, 0, 6000},   // 1.7.151
  {"cut_fade", &g_ctl.cutFade, 0, 1},   // 1.7.151
  {"flat_glow_corners", &g_ctl.flatGlowCorners, 0, 1},   // 1.7.151
  {"cine_guard", &g_ctl.cineGuard, 0, 1},   // 1.7.26
  {"same_picture", &g_ctl.pairSame, 0, 1},   // 1.7.27
  {"texture_aniso", &g_ctl.texAniso, 0, 16},   // 1.7.27
  {"hbar_wall_hide", &g_ctl.hbarWallHide, 0, 1},   // 1.7.27
  {"holster_on_back", &g_ctl.holsterOnBack, 0, 1},   // 1.7.25          // 1.7.24: the probe starts the game's own slam step when the game did not
  {"slam_trig_pct", &g_ctl.slamTrigPct, 60, 100},    // 1.7: how far the left trigger must be squeezed
  {"slam_buzz_pct", &g_ctl.slamBuzzPct, 0, 100},     // 1.7: grab / slam vibration
  {"item_glow_pct", &g_ctl.itemGlowPct, 0, 100},     // 1.7: light on items on the ground
  {"collect_marker", &g_ctl.collectMarkers, 0, 1},   // 1.7.3: glowing markers on collectibles
  {"collect_marker_always", &g_ctl.collectMarkerAlways, 0, 1},   // 1.7.3
  {"sprint_via_jump", &g_ctl.sprintViaJump, 0, 0},   // legacy key; no injected jump/run
  {"sprint_force", &g_ctl.sprintForce, 0, 0},        // legacy key; no injected game run
  {"sprint_speed_pct", &g_ctl.sprintSpeedPct, 100, 300},   // 1.7.8
  {"sprint_speed_method", &g_ctl.sprintSpeedMethod, 0, 3}, // 1.7.8
  {"walk_head", &g_ctl.walkHead, 0, 1},              // 1.7.8
  {"menu_strict", &g_ctl.menuStrict, 0, 1},          // 1.7.7
  {"gun_wrist_cm", &g_ctl.gunWristCm, 0, 20},        // 1.7.7
  {"walk_cap_pct", &g_ctl.walkCapPct, 40, 100},      // 1.7.6
  {"sprint_toggle", &g_ctl.sprintToggle, 0, 1},      // 1.7.5: the left stick click toggles sprint
  {"turn_follow_walk", &g_ctl.turnFollowWalk, 0, 1}, // 1.7.5: the body follows the head sooner while you walk
  {"collect_marker_pct", &g_ctl.collectMarkerPct, 40, 300},   // 1.7.3
  {"lock_ghost_only", &g_ctl.lockGhostOnly, 0, 1},   // 1.7.2: the game's own lock lets go of tables and chairs
  {"sprint_click", &g_ctl.sprintClick, 0, 1},       // 0.98: left stick click = Sprint (L3)
  {"hose_off", &g_ctl.hoseOff, 0, 1},                          // 0.90
  {"body_whole", &g_ctl.bodyWhole, 0, 1},                      // 0.90
  {"trap_hip_drop_cm", &g_ctl.trapHipDropCm, 30, 110},         // 0.90
  {"trap_hip_radius_cm", &g_ctl.trapHipRadiusCm, 10, 50},      // 0.90
  {"hose_from_game", &g_ctl.hoseFromGame, 0, 1},               // 0.78
  {"trap_own_model", &g_ctl.trapOwnModel, 0, 1},               // 0.79
  {"forearm_twist_pct", &g_ctl.forearmTwistPct, 0, 100},   // 0.77
  {"two_hand_pitch_deci", &g_ctl.twoHandPitchDeci, -200, 300}, // 0.77
  {"two_hand_ref_cm", &g_ctl.twoHandRefCm, 0, 100},      // 1.7.111
  {"dpad_away_cm", &g_ctl.dpadAwayCm, 25, 100},        // 0.77: free hand this far from the gun hand + left grip + right stick = D-pad
  {"forced_detect", &g_ctl.forcedDetect, 0, 1},       // 0.69: cutscene / knock-back detector (body corrections ease out meanwhile)
  {"beam_straight", &g_ctl.beamStraight, 0, 1},       // 0.69: the stream leaves along the barrel
  {"menu_music", &g_ctl.menuMusic, 0, 1},             // 0.69
  {"menu_music_pct", &g_ctl.menuMusicPct, 0, 100},    // 0.69
  {"menu_mute_game", &g_ctl.menuMuteGame, 0, 1},      // 0.69
  {"menu_bg", &g_ctl.menuBg, 0, 1},                   // 0.69
  {"menu_bg_pct", &g_ctl.menuBgPct, 0, 100},          // 0.69
  {"eye_back_cm", &g_ctl.eyeBackCm, 0, 15},           // 0.68: the camera sits this far in front of the avatar's eyes
  {"pack_follow", &g_ctl.packFollow, 0, 1},           // 0.68: the pack drops and leans with the torso
  {"shoulder_pull_deg", &g_ctl.shoulderPullDeg, 0, 60},// 0.68: shoulder reach (0 = off)
  {"crouch_dead_cm", &g_ctl.crouchDeadCm, 0, 30},     // 0.68: a head drop smaller than this is a lean, not a crouch
  {"aim_assist_pct", &g_ctl.aimAssistPct, 0, 200},    // 0.68: the beam is pulled onto a ghost it nearly hits (0 = off)
  {"aim_assist_deg", &g_ctl.aimAssistDeg, 1, 20},     // 0.68: the cone in which a ghost pulls the beam
  {"mem_cache", &memcache::g_enabled, 0, 1},          // 0.66: cached memory checks (0 = the old way, a full Windows check every time)
  {"menu_own_pointer", &g_ctl.menuOwnPointer, 0, 1},   // 0.61
  {"no_pause_menu", &g_ctl.noPauseMenu, 0, 1},         // 0.61
  {"auto_pause", &g_ctl.autoPause, 0, 1},             // 0.52
  {"menu_on_start", &g_ctl.menuOnStart, 0, 1},        // 0.53
  {"menu_freeze", &g_ctl.menuFreeze, 0, 1},           // 0.54
  {"ring_mode", &g_ctl.ringMode, 0, 1},               // 0.54
  {"arm_ik", &g_ctl.armIk, 0, 2},                     // 0.57
  {"arm_wrist_cm", &g_ctl.armWristCm, 0, 20},         // 0.57
  {"arm_elbow_down_pct", &g_ctl.armElbowDown, 0, 300},// 0.57
  {"body_follow", &g_ctl.bodyFollow, 0, 1},           // 0.52
  {"body_scale", &g_ctl.bodyScale, 0, 1},             // 0.52
  {"body_eye_centifeet", &g_ctl.bodyEyeCenti, 300, 900},   // 0.52
  {"torso_dead_deg", &g_ctl.torsoDeadDeg, 0, 90},     // 0.52
  {"torso_lag_ms", &g_ctl.torsoLagMs, 40, 2000},      // 0.52
  {"wand_to_hand", &g_ctl.wandToHand, 0, 1},          // 0.51
  {"wand_back_cm", &g_ctl.wandBackCm, -40, 40},       // 0.51
  {"gun_heft_pct", &g_ctl.gunWeightPct, 0, 300},      // 0.51 gun_weight_pct (default 100); 0.58 new name so the new heavier default applies
  {"grip_at_hand", &g_ctl.gripAtHand, 0, 1},          // 0.93
  {"wand_roll_deg", &g_ctl.wandRollDeg, -180, 180},   // 0.58
  {"haptic_pct", &g_ctl.hapticPct, 0, 200},           // 0.51
  {"haptic_period_ms", &g_ctl.hapticPeriodMs, 3, 20}, // 0.51
  {"holster", &g_ctl.holster, 0, 1},                  // 0.38
  {"vent_gesture", &g_ctl.ventGesture, 0, 1},         // 0.45
  {"flat_view", &g_ctl.flatView, 0, 1},               // 0.45
  {"head_move", &g_ctl.headMove, 0, 1},               // 0.47: head position (room-scale leaning) on by default
  {"flat_vsync_off", &g_ctl.flatVsyncOff, 0, 1},      // 0.45
  {"menu_flip", &g_ctl.menuFlip, 0, 1},               // 0.42
  {"menu_fast", &g_ctl.menuFast, 0, 1},               // 0.43
  {"auto_quality", &g_ctl.autoQuality, 0, 1},         // 0.44
  {"hand_predict_ms", &g_ctl.handPredictMs, 0, 80},   // 0.50
  {"probe_data", &g_ctl.probeData, 0, 1},             // 0.49
  {"diag_timing", &g_ctl.diagTiming, 0, 1},           // 0.44
  {"settings_rev", &g_settingsRev, 0, 9999},          // 0.43: which version wrote the file (defaults that changed are migrated once)
  {"hud_mode", &g_ctl.hudMode, 0, 1},                 // 0.29
  {"hud_size_percent", &g_ctl.hudSizePct, 50, 200},   // 0.29
  {"hud_distance_cm", &g_ctl.hudDistanceCm, 50, 1000},// 0.29
  {"depth_percent", &g_ctl.stereoStrengthPct, 0, 200},
  {"eye_height_centifeet", &g_ctl.eyeHeightCenti, 100, 800},
  {"near_plane_centifeet", &g_ctl.nearCenti, 8, 150},   // 0.77: down to 8 (2.4 cm) so the chest is not cut away when you look down
  {"sharp_mode", &g_ctl.stereoWide, 0, 1},
  {"smooth_mode", &g_ctl.stereoPair, 0, 1},
};
static volatile LONG g_dirty;
static wchar_t g_path[MAX_PATH + 32];

static void make_path() {
  if (g_path[0]) return;
  lstrcpynW(g_path, g_selfDir, MAX_PATH);
  lstrcatW(g_path, L"gbvr_settings.txt");
}

// 1.7.65 player edition: the developer-only switches (outside watcher, rig view, chest camera, compositor timing, hurt-function watch)
// only work when probe_data=1 is in gbvr_settings.txt. A normal install (and every file a player has) keeps them off.
static void player_edition_gate() {
  if (g_ctl.probeData) return;
  InterlockedExchange(&g_ctl.watchGame, 0);
  InterlockedExchange(&g_ctl.rigView, 0);
  InterlockedExchange(&g_ctl.chestCam, 0);
  InterlockedExchange(&g_ctl.diagTiming, 0);
  InterlockedExchange(&g_ctl.damageWatch, 0);
}

void settings_load() {
  make_path();
  HANDLE f = CreateFileW(g_path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (f == INVALID_HANDLE_VALUE) {
    InterlockedExchange(&g_settingsRev, kSettingsRev);
    InterlockedExchange(&g_ctl.pictureLines, 1440);   // 1.7.117: a NEW install starts at 1440 lines (2560x1440) so laptops and mid-range cards run well; an existing settings file keeps its own size
    log_line("SETTINGS no gbvr_settings.txt yet: first start, using defaults (picture 1440 lines; raise it in the VR menu > View > Resolution) (height=%d world=%d hideBody=%d/wand %d/shadow %d headAim=%d)",
             (int)g_ctl.sizePct, (int)g_ctl.worldPct, (int)g_ctl.hideBody, (int)g_ctl.hideWand, (int)g_ctl.hideShadow, (int)g_ctl.headAim);
    return;
  }
  static char buf[16384];   // 1.7.19: 6144 was nearly full (about 220 settings)
  DWORD got = 0;
  ReadFile(f, buf, sizeof(buf) - 1, &got, nullptr);
  CloseHandle(f);
  buf[got] = 0;
  int applied = 0;
  for (DWORD i = 0; i < got;) {
    DWORD lineEnd = i;
    while (lineEnd < got && buf[lineEnd] != '\n' && buf[lineEnd] != '\r') ++lineEnd;
    for (Item& it : g_items) {
      int n = lstrlenA(it.name);
      if (i + (DWORD)n < lineEnd && buf[i + n] == '=' &&
          CompareStringA(LOCALE_INVARIANT, 0, buf + i, n, it.name, n) == CSTR_EQUAL) {
        DWORD p = i + n + 1;
        int neg = 0, digits = 0;
        LONG v = 0;
        if (p < lineEnd && buf[p] == '-') { neg = 1; ++p; }
        while (p < lineEnd && buf[p] >= '0' && buf[p] <= '9' && digits < 7) { v = v * 10 + (buf[p] - '0'); ++p; ++digits; }
        if (digits) {
          if (neg) v = -v;
          if (v < it.lo) v = it.lo;
          if (v > it.hi) v = it.hi;
          InterlockedExchange(it.value, v);
          ++applied;
        }
      }
    }
    i = lineEnd;
    while (i < got && (buf[i] == '\n' || buf[i] == '\r')) ++i;
  }
  // 0.28/0.29 saved hide_body=2 for "wand hidden too"; from 0.30 the wand has its
  // own switch (hide_wand, hidden by default), so 2 simply means hidden.
  if (g_ctl.hideBody > 1) InterlockedExchange(&g_ctl.hideBody, 1);
  // 0.43: the bigger default picture. A file written by 0.26-0.42 holds the old default (level 2) only because
  // it was the default; carry it over once. A level the player chose on purpose (1, 3, 4) is left alone.
  if (g_settingsRev < kSettingsRev) {
    if (g_settingsRev < 99) {   // 1.4
      // the PKE could never scan in 1.3: the game wants a ghost within 15 ft AND within 18 degrees of where the PKE points (and the log showed ghosts 37-65 ft away). The forgiving scan is on from the start.
      if (g_ctl.pkeAssistDeg == 14) { InterlockedExchange(&g_ctl.pkeAssistDeg, 24); log_line("SETTINGS pke_assist_deg 14 -> 24 (1.4: the scan help pulls from a wider cone)"); }
      // health bars: the game's own ring exists only for the ghost it targets and vanishes when you fire or look away; the small bars sit in every ghost you can see, all the time. The game's ring is hidden (it stays inside the aim help).
      if (!g_ctl.hbar) { InterlockedExchange(&g_ctl.hbar, 1); log_line("SETTINGS hbar 0 -> 1 (1.4: a health bar sits in every ghost you can see, all the time)"); }
      InterlockedExchange(&g_ctl.hbarGate, 0);
      if (!g_ctl.ringMode) { InterlockedExchange(&g_ctl.ringMode, 1); log_line("SETTINGS ring_mode 0 -> 1 (1.4: the game's own ring, which only shows on the ghost it targets and blinks away when you fire, is hidden; the bars replace it)"); }
      // monitor: 1.3 showed the whole wide picture with black bars at the sides and a constant black wedge from a 1.4 degree head tilt; 1.4 fills the window with a calmer zoom and ignores small tilts
      if (!g_ctl.monitorFit) { InterlockedExchange(&g_ctl.monitorFit, 1); log_line("SETTINGS monitor_fit 0 -> 1 (1.4: the monitor picture fills the window)"); }
      // (1.4 lowered monitor_zoom_pct 100 -> 72 here; 1.7.9 brings it back to 100 with a wider picture, so that step is gone)
      log_line("SETTINGS 1.4: new settings take their defaults: easy PKE scan on (35 ft, 40 degrees, starts by itself), the green PKE goggle frame hidden");
    }
    if (g_settingsRev < 115) {   // 1.7.17
      // the 1.7.16 report: the health ring never showed up (the bars were switched off since 1.5): bars on, the ring hidden. A lowered player height sank the view into the stomach: height back to 100 %.
      InterlockedExchange(&g_ctl.hbar, 1); InterlockedExchange(&g_ctl.hbarGate, 0); InterlockedExchange(&g_ctl.ringMode, 1);
      log_line("SETTINGS hbar = 1, ring_mode = 1 (1.7.17: the game's health ring never showed in the headset; a health bar sits in every ghost you can see instead)");
      if (g_ctl.sizePct != 100) { log_line("SETTINGS size_percent %d -> 100 (1.7.17: lowering the view sank it into the character's stomach; Measure my height now sets the world size instead)", (int)g_ctl.sizePct); InterlockedExchange(&g_ctl.sizePct, 100); }
      if (g_ctl.beamDamagePct < 150) { log_line("SETTINGS beam_damage_pct %d -> 150 (1.7.17)", (int)g_ctl.beamDamagePct); InterlockedExchange(&g_ctl.beamDamagePct, 150); }
      InterlockedExchange(&g_ctl.holdView, 1);
      InterlockedExchange(&g_ctl.fingerRestPct, 25);
      if (g_ctl.torsoDeadDeg == 20) { InterlockedExchange(&g_ctl.torsoDeadDeg, 12); log_line("SETTINGS torso_dead_deg 20 -> 12 (1.7.17: the body follows the head sooner, less stiff)"); }
      if (g_ctl.torsoLagMs == 250) { InterlockedExchange(&g_ctl.torsoLagMs, 170); log_line("SETTINGS torso_lag_ms 250 -> 170 (1.7.17: the body follows the head sooner, less stiff)"); }
    }
    if (g_settingsRev < 114) {   // 1.7.16
      // the 1.7.14 report: "no motion control or anything". game_place 1 (1.7.13) switched off every controller-driven move (wand, tip, arms, fingers, PKE). It is back to 0 for everybody.
      InterlockedExchange(&g_ctl.gamePlace, 0);
      log_line("SETTINGS game_place = 0 (1.7.16: motion control is back; the gun, the arms and the PKE follow your controllers again)");
    }
    if (g_settingsRev < 113) {   // 1.7.14
      // the 1.7.12 log: the health ring was drawn in every frame (also with no ghost, at stale spots: 355,3 for thousands of frames); now it is drawn only on a ghost you look at / hit.
      if (g_ctl.ringConeDeg == 28) { InterlockedExchange(&g_ctl.ringConeDeg, 35); log_line("SETTINGS ring_cone_deg 28 -> 35 (1.7.14: the ring finds the ghost you look at from a wider angle)"); }
      if (g_ctl.ringHoldDs == 15) { InterlockedExchange(&g_ctl.ringHoldDs, 4); log_line("SETTINGS ring_hold_ds 15 -> 4 (1.7.14: the ring leaves 0.4 s after you look away, was 1.5 s)"); }
    }
    if (g_settingsRev < 112) {   // 1.7.14
      InterlockedExchange(&g_ctl.pkeProxBuzz, 1);
      log_line("SETTINGS pke_prox_buzz = 1 (1.7.14: with the PKE out the right hand buzzes faster and stronger the closer the nearest unscanned thing is)");
    }
    if (g_settingsRev < 111) {   // 1.7.13
      // the 1.7.12 report: "the game loads, then your changes come in and make it worse": the game places the gun and the PKE now (game_place 1); the slam no longer flicks the aim stick (it turned the body: the 1.7.12 log shows the avatar's facing swinging 60-90 degrees during a slam)
      InterlockedExchange(&g_ctl.gamePlace, 1);
      if (g_ctl.slamFlickPct != 0) { log_line("SETTINGS slam_flick_pct %d -> 0 (1.7.13: no stick flick; the game slams down by itself, the body stays put)", (int)g_ctl.slamFlickPct); InterlockedExchange(&g_ctl.slamFlickPct, 0); }
      if (g_ctl.sizePct < 85 || g_ctl.sizePct > 120) { const LONG ns = g_ctl.sizePct < 85 ? 85 : 120; log_line("SETTINGS size_percent %d -> %d (1.7.13: heights outside 85-120 broke the model)", (int)g_ctl.sizePct, (int)ns); InterlockedExchange(&g_ctl.sizePct, ns); }
      log_line("SETTINGS game_place = 1 (1.7.13: the game's own animation places the gun and the PKE; Menu > Start > Game places gun and PKE)");
    }
    if (g_settingsRev < 110) {   // 1.7.12
      // the 1.7.8 log: the PKE found and scanned the one source near the player (PKEPING #1 FINISHED); the game then keeps a 2 s cooldown and the player had no cue when nothing was in reach. Reach 35 -> 50 ft.
      if (g_ctl.pkeEasyFt == 35) { InterlockedExchange(&g_ctl.pkeEasyFt, 50); log_line("SETTINGS pke_easy_ft 35 -> 50 (1.7.12: the PKE reaches sources farther away)"); }
    }
    if (g_settingsRev < 109) {   // 1.7.11
      // the 1.7.9 log: in 888 passes the controller was 170-220 % of an arm length from the shoulder and the arm stopped at 170 %, so the hand fell short by up to 21 cm (the gun / PKE "floated"). The arm may stretch to 220 % (rarely used).
      if (g_ctl.armStretchPct == 170) { InterlockedExchange(&g_ctl.armStretchPct, 220); log_line("SETTINGS arm_stretch_pct 170 -> 220 (1.7.11: the hand reaches the controller when you hold the gun far out)"); }
    }
    if (g_settingsRev < 108) {   // 1.7.10
      // the 1.7.9 report + video: the stream left the muzzle sideways (about 90 degrees from the barrel, always toward the same side) while the gun pointed where the hand pointed; the game's own hit point was 75 degrees off the barrel on average.
      // The game's hit point is now put on the barrel line (stream_aim_gun 1). The avatar's wrist fell short of the controller by up to 21 cm in 5 percent of the frames (controller 1.7-2.2 arm lengths from the shoulder): the shoulder may slide further.
      if (g_ctl.shoulderSlideCm == 12) { InterlockedExchange(&g_ctl.shoulderSlideCm, 30); log_line("SETTINGS shoulder_slide_cm 12 -> 30 (1.7.10: the shoulder slides further toward the hand before the arm stretches, so the gun stays in the hand)"); }
      // the 1.7.9 log: the game's damage function was called 0 times in the whole run (the stream never reached a ghost), so ghosts took far longer than in the game. The stream fix should bring the hits back; the beam boost goes 115 -> 135 % to make up for the harder aiming in VR.
      if (g_ctl.beamDamagePct == 115) { InterlockedExchange(&g_ctl.beamDamagePct, 135); log_line("SETTINGS beam_damage_pct 115 -> 135 (1.7.10: ghosts die faster)"); }
      log_line("SETTINGS 1.7.10: new settings take their defaults: stream_aim_gun 1 (the stream's end point is put on the line of the gun's barrel)");
    }
    if (g_settingsRev < 107) {   // 1.7.9
      // the 1.7.8 video: the PC window showed only about 92 x 60 degrees of the 110 x 110 the game draws (zoom 72 %, filled to the window's shape). Now the whole width (100 %) of a picture drawn 25 % wider.
      if (g_ctl.monitorZoomPct == 72) { InterlockedExchange(&g_ctl.monitorZoomPct, 100); log_line("SETTINGS monitor_zoom_pct 72 -> 100 (1.7.9: the PC window shows the whole width of the picture)"); }
      log_line("SETTINGS 1.7.9: new settings take their defaults: monitor_wide_pct 125 (the game draws 25 %% wider while the monitor view is on), pke_goggles 1 (the green PKE view is on while the PKE is in the hand)");
    }
    if (g_settingsRev < 106) {   // 1.7.8
      // the 1.7.7 log: the forced run bit started the game's real sprint (its run timer ran 4798 frames) but the character was not faster (6.7 ft/s against 7.5 walking) and the game's sprint walks only
      // along the facing direction with its run animation. Sprint is now a plain speed boost; the game's own sprint is never started or tuned.
      if (g_ctl.sprintForce) { InterlockedExchange(&g_ctl.sprintForce, 0); log_line("SETTINGS sprint_force 1 -> 0 (1.7.8: the game's run is never started; sprint is a plain speed boost)"); }
      if (g_ctl.easySprint) { InterlockedExchange(&g_ctl.easySprint, 0); log_line("SETTINGS easy_sprint 1 -> 0 (1.7.8: the game's sprint tuning is put back to the game's own values)"); }
      log_line("SETTINGS 1.7.8: new settings take their defaults: sprint_speed_pct 170, sprint_speed_method 0 (auto), walk_head 1 (the left stick walks where the headset points)");
    }
    if (g_settingsRev < 105) {   // 1.7.7
      // the 1.7.5 picture: the PKE's handle ended at the top of the closed fist (nothing of it inside the hand, the hand did not cover it). It sits 6 cm further back into the fist.
      if (g_ctl.pkeFwdCm == -9) { InterlockedExchange(&g_ctl.pkeFwdCm, -15); log_line("SETTINGS pke_fwd_cm -9 -> -15 (1.7.7: the PKE's handle goes 6 cm deeper into the fist, the hand covers it)"); }
      log_line("SETTINGS 1.7.7: new settings take their defaults: gun_wrist_cm 7 (the weapon hand's wrist sits back like the left hand's), menu_strict 1 (the menu opens only with the left hand beside the left ear)");
    }
    if (g_settingsRev < 104) {   // 1.7.6
      // the 1.7.5 log: holding the Jump/Evade button did not start the game's sprint in 194 polls (and a short Jump press is a dodge roll). The probe now sets the sprint itself (sprint_force).
      if (g_ctl.sprintViaJump) { InterlockedExchange(&g_ctl.sprintViaJump, 0); log_line("SETTINGS sprint_via_jump 1 -> 0 (1.7.6: the probe no longer holds Jump to sprint, it started no sprint and a short press is a dodge roll)"); }
      log_line("SETTINGS 1.7.6: new settings take their defaults: sprint_force 1 (the probe starts the game's run itself), walk_cap_pct 100 (off)");
    }
    if (g_settingsRev < 103) {   // 1.7.2
      // the 1.7.1 log: things still scanned by themselves (pke_auto was on by default since 1.4); you want the scan only when you press the trigger
      if (g_ctl.pkeAuto) { InterlockedExchange(&g_ctl.pkeAuto, 0); log_line("SETTINGS pke_auto 1 -> 0 (1.7.2: the PKE scans only when you squeeze the right trigger; it no longer starts by itself)"); }
      // the 1.7.1 PKE picture: a closed fist with the handle floating beyond it; the weapon sat about the length of the game's hand-to-weapon slide too far forward. Moved back toward the hand (Fit tab changes it).
      if (g_ctl.gunFwdCm == 0) { InterlockedExchange(&g_ctl.gunFwdCm, -3); log_line("SETTINGS gun_fwd_cm 0 -> -3 (1.7.2: the gun sits 3 cm closer to the hand along its barrel)"); }
      if (g_ctl.pkeFwdCm == 0) { InterlockedExchange(&g_ctl.pkeFwdCm, -9); log_line("SETTINGS pke_fwd_cm 0 -> -9 (1.7.2: the PKE sits 9 cm closer to the hand along its barrel)"); }
      log_line("SETTINGS 1.7.2: new settings take their defaults: the game's own lock lets go of tables and chairs (lock_ghost_only), the gun and the PKE sit closer to the hand (gun 3 cm, PKE 9 cm back along the barrel), no automatic scan");
    }
    if (g_settingsRev < 102) {   // 1.7
      // the 1.6 pictures: the weapon hand opened to 40 % once the (unused) grip button was let go, so the gun and the PKE sat in front of an open hand; the slam swing never matched what you pulled
      if (g_ctl.slamGesture) { InterlockedExchange(&g_ctl.slamGesture, 0); log_line("SETTINGS slam_gesture 1 -> 0 (1.7: the slam is on the left trigger now; the old swing can be switched back on in the menu)"); }
      log_line("SETTINGS 1.7: new settings take their defaults: fingers stay wrapped on the weapon, aim assist only for ghosts, right trigger scans with the PKE, quick sprint with a tap-to-keep, slam on the left trigger with vibration, light on items on the ground, no BEAM SWITCH slot on the wheel");
    }
    if (g_settingsRev < 101) {   // 1.6
      // the 1.5 log: the PKE slide was used at only 50 % and eased in world space; the gun slide was raw. Both floated away from the hand once the game's hand offset began to jump (3-21 cm, 15 cm frame jumps).
      if (g_ctl.pkeShiftPct == 50) { InterlockedExchange(&g_ctl.pkeShiftPct, 100); log_line("SETTINGS pke_shift_pct 50 -> 100 (1.6: the PKE sits where the hand holds it, kept steady in its own axes)"); }
      if (g_ctl.pkeWeightPct == 55) { InterlockedExchange(&g_ctl.pkeWeightPct, 30); log_line("SETTINGS pke_weight_pct 55 -> 30 (1.6: less lag, the PKE felt like floating)"); }
      if (g_ctl.ringHoldDs == 25) { InterlockedExchange(&g_ctl.ringHoldDs, 15); log_line("SETTINGS ring_hold_ds 25 -> 15 (1.6: the ring lets go of a ghost sooner after you look away)"); }
      if (!g_ctl.monitorFit) { InterlockedExchange(&g_ctl.monitorFit, 1); log_line("SETTINGS monitor_fit 0 -> 1 (1.6: the PC window is always filled, whatever its size)"); }
      log_line("SETTINGS 1.6: new settings take their defaults: rigid gun and PKE in the hand, weapon wheel 60 %% solid with a red outline, locked weapons show '?', HUD redraw for a missed eye, scan help, ring dropped when the ghost is gone");
    }
    if (g_settingsRev < 100) {   // 1.5
      // 1.4 hid the game's health ring and drew the probe's own bars instead. You asked for the game's bar: it is back, and now it is put on the ghost you look at (ring_assist)
      if (g_ctl.hbar) { InterlockedExchange(&g_ctl.hbar, 0); log_line("SETTINGS hbar 1 -> 0 (1.5: the game's own health bar is used, the probe's extra bars are off)"); }
      if (g_ctl.ringMode) { InterlockedExchange(&g_ctl.ringMode, 0); log_line("SETTINGS ring_mode 1 -> 0 (1.5: the game's own health ring is shown again)"); }
      log_line("SETTINGS 1.5: new settings take their defaults: the game's ring follows the ghost you look at (28 deg, stays 2.5 s), the body follows your head past 35 deg, the right stick snap-turns in 30 deg steps");
    }
    if (g_settingsRev < 82) {
      if (g_ctl.leftGripPct) { InterlockedExchange(&g_ctl.leftGripPct, 0); log_line("SETTINGS left_grip_pct -> 0 (0.82: the assisted left-hand grab is off; it felt wrong)"); }
      if (g_ctl.viewModelPct <= 125) { InterlockedExchange(&g_ctl.viewModelPct, 165); log_line("SETTINGS view_model_pct -> 165%% (0.82: the gun looked too small)"); }
    }
    if (g_settingsRev < 98) log_line("SETTINGS 1.3: new settings take their defaults: the headset view starts by itself, 0.45 s fade up from black into 3D, ring cursor on 2D screens, 2D screen dims behind the VR menu");
    if (g_settingsRev < 97) log_line("SETTINGS 1.2: new settings take their defaults: the PC window shows one steady wide picture of the left eye (whole picture, horizon level, no zoom), menus keep their shape on the window");
    if (g_settingsRev < 96) log_line("SETTINGS 1.1: new settings take their defaults: stuck gear switches are finished, the 2D screen is 100 %% size at 280 cm, a little below your eyes, slightly curved");
    if (g_settingsRev < 95) {   // 0.98
      if (g_ctl.pkeWeightPct == 40) { InterlockedExchange(&g_ctl.pkeWeightPct, 55); log_line("SETTINGS pke_weight_pct 40 -> 55 (0.98: a little more weight for the PKE, as you asked)"); }
      log_line("SETTINGS 0.98: new settings take their defaults: black frames behind the flat screen, calm TV glow, body stays visible with the PKE, PKE placed once per eye pair, left stick click = Sprint");
    }
    if (g_settingsRev < 94) log_line("SETTINGS 0.95: new settings take their defaults: PKE weight 40 %%, one-handed shot punishment 100 %%, black void and TV glow 70 %% around the flat screen");
    if (g_settingsRev < 93) {   // 0.94
      if (g_ctl.pkeOwn) { InterlockedExchange(&g_ctl.pkeOwn, 0); log_line("SETTINGS pke_own 1 -> 0 (0.94: the probe's own PKE model is gone; the game's real PKE is moved to your hand)"); }
      if (g_ctl.hbar) { InterlockedExchange(&g_ctl.hbar, 0); log_line("SETTINGS hbar 1 -> 0 (0.94: the probe's health bars are off; the game's own ring stays on the ghost)"); }
      if (g_ctl.pkeTiltDeg == 20) InterlockedExchange(&g_ctl.pkeTiltDeg, 0);
      if (g_ctl.gunWeightPct == 150) { InterlockedExchange(&g_ctl.gunWeightPct, 100); log_line("SETTINGS gun_heft_pct 150 -> 100 (0.94: the gun follows the hand's turn and twist more closely)"); }
    }
    if (g_settingsRev < 92) { InterlockedExchange(&g_ctl.handPredictMs, 10); log_line("SETTINGS 0.92: hand prediction 20 -> 10 ms (less overshoot and shake at 140 Hz)"); }
  if (g_settingsRev < 91) { InterlockedExchange(&g_ctl.hbarGate, 0); log_line("SETTINGS 0.91: bars no longer wait for the wall test (it blocked 587 of 981 checks while a ghost was in plain view)"); }
  if (g_settingsRev < 90) {
      InterlockedExchange(&g_ctl.viewModelPct, 100);   // the user found every view model good at 100 %
      InterlockedExchange(&g_ctl.armsShoulders, 1);    // ... and keeps the chest on
      InterlockedExchange(&g_ctl.rigView, 0);          // the debug skeleton / rig view is off (the user switched it off)
      InterlockedExchange(&g_ctl.solidBody, 1);        // the "hard lock" stays on
      InterlockedExchange(&g_ctl.hbar, 1);             // the small ghost health bars come back (off since 0.79)
      InterlockedExchange(&g_ctl.hbarGate, 0);
      InterlockedExchange(&g_ctl.hbarSizePct, 100);
      log_line("SETTINGS 0.90: gun size 100 %%, chest visible on, rig view off, solid body on, whole body (no head) on, hose removed, trap hip zone 70 cm / 28 cm");
    }
    if (g_settingsRev < 89 && g_ctl.hoseFromGame) { InterlockedExchange(&g_ctl.hoseFromGame, 0); log_line("SETTINGS hose_from_game 1 -> 0 (0.89: its walk through the game's memory crashed the game in 0.88)"); }
    if (g_settingsRev < 87 && g_ctl.skipVideos) { InterlockedExchange(&g_ctl.skipVideos, 0); log_line("SETTINGS skip_videos 1 -> 0 (0.87: the file hook of 0.85/0.86 is gone, it is the main suspect of the crash at the end of the hotel cutscene)"); }
    if (g_settingsRev < 84 && g_ctl.glovesOnly) {
      InterlockedExchange(&g_ctl.glovesOnly, 0);
      log_line("SETTINGS gloves_only 1 -> 0 (0.84: the probe's own block gloves looked wrong; the game's own gloves and arms are back, now with moving fingers)");
    }
    if (g_settingsRev < 83 && g_ctl.pictureLevel < 3) {
      log_line("SETTINGS picture level %d -> 3 once (0.83: the 0.82 memory guard had saved the lowest level; the guard no longer saves its choice)", (int)g_ctl.pictureLevel);
      InterlockedExchange(&g_ctl.pictureLevel, 3);
    }
    if (g_settingsRev < 83 && !g_ctl.holster) {
      InterlockedExchange(&g_ctl.holster, 1);
      log_line("SETTINGS holster 0 -> 1 (0.83: trigger + grip with the right hand over the shoulder puts the gun on your back)");
    }
    if (g_settingsRev < 83 && g_ctl.pkeBody) {
      InterlockedExchange(&g_ctl.pkeBody, 0);
      log_line("SETTINGS pke_body 1 -> 0 (0.83: the game's PKE walking animation looked wrong; no body is shown with the PKE any more)");
    }
    if (g_settingsRev < 80 && g_ctl.armsShoulders) {
      InterlockedExchange(&g_ctl.armsShoulders, 0);
      log_line("SETTINGS arms_shoulders 1 -> 0 (0.80: the chest is hidden; the probe draws its own pack straps instead)");
    }
    if (g_settingsRev < 43 && g_ctl.pictureLevel == 2) {
      InterlockedExchange(&g_ctl.pictureLevel, 3);
      log_line("SETTINGS picture level 2 -> 3 (0.43 default: 3840x2880, sharper headset view; Insert changes it)");
    }
    if (g_settingsRev < 66 && g_ctl.armStretchPct == 170) {
      InterlockedExchange(&g_ctl.armStretchPct, 260);
      log_line("SETTINGS arm stretch limit 170%% -> 260%% (0.66: the 0.64 log showed the controller often farther than 170%% of the avatar's arm, so the gun floated away from the hand)");
    }
    if (g_settingsRev < 68 && !g_ctl.menuFreeze) {
      InterlockedExchange(&g_ctl.menuFreeze, 1);
      log_line("SETTINGS menu_freeze 0 -> 1 once (0.68: the menu pauses the game again; 0.61-0.67 forced it off; switch it off on the menu's Start tab if you do not want that)");
    }
    if (g_settingsRev < 68 && g_ctl.armStretchPct == 260) {
      InterlockedExchange(&g_ctl.armStretchPct, 150);
      log_line("SETTINGS arm stretch limit 260%% -> 150%% (0.68: the avatar's eyes now sit at the camera, so the shoulders are where yours are and the arm needs far less stretch; shoulder reach does the rest)");
    }
    if (g_settingsRev < 66 && g_ctl.pictureLevel == 2) {
      InterlockedExchange(&g_ctl.pictureLevel, 3);
      log_line("SETTINGS picture level 2 -> 3 once (0.66 removes a big per-frame cost; the tool still lowers it by itself if the PC cannot keep up)");
    }
    if (g_settingsRev < 65 && g_ctl.sizePct < 100) {   // 0.69: only once, at 0.65 (0.65-0.68 repeated it at every version and threw away a measured height)
      log_line("SETTINGS player height %d%% -> 110%% (0.65: low values came from earlier height measurements and put the view at the stomach; use the menu's Player height to change it)", (int)g_ctl.sizePct);
      InterlockedExchange(&g_ctl.sizePct, 110);
    }
    if (g_settingsRev < 69 && g_ctl.menuOnStart) {
      InterlockedExchange(&g_ctl.menuOnStart, 0);
      log_line("SETTINGS menu_on_start 1 -> 0 once (0.69: the switch works again; an old saved 1 from before 0.61 would open the menu at every start)");
    }
    if (g_settingsRev < 69 && g_ctl.aimAssistDeg == 6) {
      InterlockedExchange(&g_ctl.aimAssistDeg, 10);
      log_line("SETTINGS aim assist cone 6 -> 10 degrees (0.69: the 0.68 log showed ghosts 17-19 degrees off the beam; the cone was too small to ever catch them)");
    }
    if (g_settingsRev < 70 && g_ctl.gunGlue) {
      InterlockedExchange(&g_ctl.gunGlue, 0);
      log_line("SETTINGS gun_glue 1 -> 0 (0.70: the gun now always sits at your controller; the avatar's hand reaches for it instead of the gun being pulled back to the hand)");
    }
    if (g_settingsRev < 70 && g_ctl.armStretchPct == 150) {
      InterlockedExchange(&g_ctl.armStretchPct, 250);
      log_line("SETTINGS arm stretch limit 150%% -> 250%% (0.70: with the gun no longer pulled back to the hand, the arm may reach further so the hand is on the gun)");
    }
    if (g_settingsRev < 70 && g_ctl.menuMusicPct == 65) {
      InterlockedExchange(&g_ctl.menuMusicPct, 55);
      log_line("SETTINGS menu song volume 65%% -> 55%% (0.70: 15%% quieter, as asked)");
    }
    if (g_settingsRev < 74 && g_ctl.armStretchPct == 250) {
      InterlockedExchange(&g_ctl.armStretchPct, 170);
      log_line("SETTINGS arm stretch limit 250%% -> 170%% (0.74: the shoulder now also slides toward the hand, so the arms need far less stretch; 250%% made long thin arms)");
    }
    if (g_settingsRev < 74 && g_ctl.shoulderPullDeg == 35) {
      InterlockedExchange(&g_ctl.shoulderPullDeg, 45);
      log_line("SETTINGS shoulder reach 35 -> 45 degrees (0.74)");
    }
    if (g_settingsRev < 79 && g_ctl.hbar) {
      InterlockedExchange(&g_ctl.hbar, 0);
      log_line("SETTINGS health bars of the probe 1 -> 0 (0.79: you saw both the game's ring and the probe's bars; the game's own ring is the one that stays)");
    }
    if (g_settingsRev < 79 && g_ctl.slamSpeedDeci >= 20) {
      InterlockedExchange(&g_ctl.slamSpeedDeci, 12);
      log_line("SETTINGS slam swing speed %d -> 12 (1.2 m/s): the 0.78 log showed your fastest swing with the capture stream held was 2.0 m/s, under the 2.2 needed", 22);
    }
    if (g_settingsRev < 76 && g_ctl.sizePct == 110) {
      InterlockedExchange(&g_ctl.sizePct, 100);
      log_line("SETTINGS player height 110%% -> 100%% (0.76: the view model looks right at 100%%; the old default 110%% made the equipment fade in and out; the menu's Player height still changes it)");
    }
    if (g_settingsRev < 76 && g_ctl.simEveryN > 1) {
      InterlockedExchange(&g_ctl.simEveryN, 1);
      log_line("SETTINGS game steps every 2nd picture -> every picture (0.76: the 0.74 ghost test halves how often the game moves its body; it can make everything judder)");
    }
    if (g_settingsRev < 77 && g_ctl.armStretchPct < 150) {
      log_line("SETTINGS arm stretch limit %d%% -> 200%% (0.77: your 0.76 log showed 100%% = the arms never stretched, so the hand fell off the gun when you turned the controller; 100 stays possible on the menu)", (int)g_ctl.armStretchPct);
      InterlockedExchange(&g_ctl.armStretchPct, 200);
    }
    if (g_settingsRev < 77 && g_ctl.viewModelPct == 100) InterlockedExchange(&g_ctl.viewModelPct, 125);
    if (g_settingsRev < 77 && g_ctl.nearCenti >= 40) {
      log_line("SETTINGS near plane %d -> 18 (0.77: 0.55 ft = 17 cm cut your own chest away when you look down - see-through / ragged / flickering; now 5 cm)", (int)g_ctl.nearCenti);
      InterlockedExchange(&g_ctl.nearCenti, 18);
    }
    if (g_settingsRev < 116) {   // 1.7.18 (placed LAST so no older step above can change these again)
      // "change it to 115 damage. That's what I wanted": beams hit for 115 % of the game's damage for everybody (the old 135 / 150 steps are gone).
      if (g_ctl.beamDamagePct != 115) { log_line("SETTINGS beam_damage_pct %d -> 115 (1.7.18: 115 %% is what you asked for)", (int)g_ctl.beamDamagePct); InterlockedExchange(&g_ctl.beamDamagePct, 115); }
      // the PKE scans what the meter points at: the scan cone 40 -> 30 degrees and the aim pull 24 -> 18 degrees (only when they still hold the old defaults)
      if (g_ctl.pkeConeDeg == 40) { InterlockedExchange(&g_ctl.pkeConeDeg, 30); log_line("SETTINGS pke_cone_deg 40 -> 30 (1.7.18: the PKE scans what it points at, not what is far off to the side)"); }
      if (g_ctl.pkeAssistDeg == 24) { InterlockedExchange(&g_ctl.pkeAssistDeg, 18); log_line("SETTINGS pke_assist_deg 24 -> 18 (1.7.18: the PKE's aim pull is smaller, so the scan line stays close to where the meter really points)"); }
    }
    if (g_settingsRev < 117) {   // 1.7.19 (placed LAST so no older step above can change these again)
      // "the ghost health bar is too big and needs to be more transparent, and also can see it before the ghost spawns and see it when a ghost is behind a wall"
      if (g_ctl.hbarSizePct == 100) { InterlockedExchange(&g_ctl.hbarSizePct, 60); log_line("SETTINGS hbar_size_pct 100 -> 60 (1.7.19: the health bar was too big)"); }
      InterlockedExchange(&g_ctl.hbarAlphaPct, 45);
      if (!g_ctl.hbarGate) { InterlockedExchange(&g_ctl.hbarGate, 1); log_line("SETTINGS hbar_gate 0 -> 1 (1.7.19: no bar for a ghost that has not spawned yet or stands behind a wall)"); }
      InterlockedExchange(&g_ctl.leftUnder, 1);
    }
    if (g_settingsRev < 118) {   // 1.7.21 (LAST)
      // "make the health bar fully solid", "make damage from everything the game base, don't affect any damage files, make sure you're not affecting anything else in a bad way"
      if (g_ctl.beamDamagePct != 100) { log_line("SETTINGS beam_damage_pct %d -> 100 (1.7.21: the game's own damage; nothing is patched)", (int)g_ctl.beamDamagePct); InterlockedExchange(&g_ctl.beamDamagePct, 100); }
      InterlockedExchange(&g_ctl.hbarAlphaPct, 100);
      if (g_ctl.aimAssistPct != 0) { log_line("SETTINGS aim_assist_pct %d -> 0 (1.7.21: the probe no longer bends your beam toward ghosts; the game's own targeting is left alone)", (int)g_ctl.aimAssistPct); InterlockedExchange(&g_ctl.aimAssistPct, 0); }
    }
    if (g_settingsRev < 119) {   // 1.7.23 (LAST): the body bend now tips toward the way you face (1.7.21 tipped backward); gentler defaults so the avatar never folds
      log_line("SETTINGS 1.7.23: body_bend_pct %d -> 60, body_bend_max_deg %d -> 40 (the bend is measured on the bones now)", (int)g_ctl.bodyBendPct, (int)g_ctl.bodyBendMaxDeg);
      InterlockedExchange(&g_ctl.bodyBendPct, 60); InterlockedExchange(&g_ctl.bodyBendMaxDeg, 40);
    }
    if (g_settingsRev < 120) {   // 1.7.25 (LAST)
      // "make rig track better, many times I was looking at my back or side before it snapped me back" and "the goggles are gone, I need them with the PKE"
      log_line("SETTINGS 1.7.25: turn_follow_deg %d -> 75 (the body waits for a long look before it follows), pke_frame %d -> 1 (the game's goggle frame comes back with the PKE; menu Sound page), holster_on_back 1, slam_assist 1",
               (int)g_ctl.turnFollowDeg, (int)g_ctl.pkeFrame);
      InterlockedExchange(&g_ctl.turnFollowDeg, 75);
      InterlockedExchange(&g_ctl.pkeFrame, 1);
      InterlockedExchange(&g_ctl.holsterOnBack, 1);
      InterlockedExchange(&g_ctl.slamAssist, 1);
    }
    if (g_settingsRev < 121) {   // 1.7.26 (LAST)
      // "make the body feel more connected and realistic" and "cutscenes mess up the rig": the cutscene guard is on; the torso follows the head a little sooner (only if it still has the old defaults)
      log_line("SETTINGS 1.7.26: cine_guard 1 (new), torso_dead_deg %d%s, torso_lag_ms %d%s", (int)g_ctl.torsoDeadDeg, g_ctl.torsoDeadDeg == 12 ? " -> 8" : " (kept)", (int)g_ctl.torsoLagMs, g_ctl.torsoLagMs == 170 ? " -> 140" : " (kept)");
      InterlockedExchange(&g_ctl.cineGuard, 1);
      if (g_ctl.torsoDeadDeg == 12) InterlockedExchange(&g_ctl.torsoDeadDeg, 8);
      if (g_ctl.torsoLagMs == 170) InterlockedExchange(&g_ctl.torsoLagMs, 140);
    }
    if (g_settingsRev < 122) {   // 1.7.27 (LAST)
      log_line("SETTINGS 1.7.27: same_picture 1 (new: both eyes always show the same player parts), hbar_wall_hide 0 (new: the ghost bar stays when the ghost is behind a wall), pke_frame 1, picture level kept");
      InterlockedExchange(&g_ctl.pairSame, 1);
      InterlockedExchange(&g_ctl.texAniso, 16);
      if (g_ctl.monitorWidePct == 125) InterlockedExchange(&g_ctl.monitorWidePct, 100);
      log_line("SETTINGS 1.7.27: texture_aniso 16 (new: sharper floors/walls at an angle, applies after a game restart), monitor_wide_pct -> %d (the game no longer draws a quarter wider for the PC window: the headset picture gets 25 %% more pixels per side)", (int)g_ctl.monitorWidePct);
      InterlockedExchange(&g_ctl.hbarWallHide, 0);
      InterlockedExchange(&g_ctl.pkeFrame, 1);
    }
    if (g_settingsRev < 123) {   // 1.7.28
      InterlockedExchange(&g_ctl.monitorHfovDeg, 100);
      InterlockedExchange(&g_ctl.monitorMenuFill, 1);
      InterlockedExchange(&g_ctl.heldMenu, 1);
      InterlockedExchange(&g_ctl.heldMenuCm, 46);
      if (g_ctl.monitorZoomPct < 100) InterlockedExchange(&g_ctl.monitorZoomPct, 100);   // the field of view setting decides now
      log_line("SETTINGS 1.7.28: monitor_hfov_deg 100 (new: the PC window shows 100 degrees across, cropped in the window only), monitor_menu_fill 1 (new: the flat menu fills the PC window), held_menu 1 (new: the game's pause menu is held in your hand, VR settings inside it), held_menu_cm 46");
    }
    if (g_settingsRev < 124) {   // 1.7.29
      InterlockedExchange(&g_ctl.bodyCalmMs, 140);
      if (g_ctl.heldMenuCm == 46) InterlockedExchange(&g_ctl.heldMenuCm, 36);   // the hand-held menu is a PKE-sized screen now, not a tablet
      log_line("SETTINGS 1.7.29: held_menu_cm %d (the menu in your hand is the size of the PKE's screen; the right hand points and clicks with its own smooth pointer), body_calm_ms %d (new: calm walking, the body no longer bobs and shakes with the walk animation; 0 = off)", (int)g_ctl.heldMenuCm, (int)g_ctl.bodyCalmMs);
    }
    if (g_settingsRev < 125) {   // 1.7.30
      InterlockedExchange(&g_ctl.mirrorVr, 1);
      InterlockedExchange(&g_ctl.hbarSmart, 1);
      log_line("SETTINGS 1.7.30: mirror_vr 1 (new: mirrors are built from your headset eye and view), hbar_smart 1 (new: no health bar before the ghost was seen, none once it is in the trap)");
    }
    if (g_settingsRev < 126) {   // 1.7.31 (LAST)
      InterlockedExchange(&g_ctl.pairHands, 1);
      InterlockedExchange(&g_ctl.heldMenuFollow, 1);
      InterlockedExchange(&g_ctl.heldMenuMinCm, 55);
      log_line("SETTINGS 1.7.31: pair_hands 1 (new: both eyes use the same hand poses), held_menu_follow 1 (new: the hand-held menu follows your hand from its own fast loop), held_menu_min_cm 55 (new: the menu never comes closer to your eyes than 55 cm)");
    }
    if (g_settingsRev < 127) {
      InterlockedExchange(&g_ctl.handLock, 1);
      InterlockedExchange(&g_ctl.pairHands, 1);
      InterlockedExchange(&g_ctl.ltCapture, 1);
      log_line("SETTINGS 1.7.32: hand_lock=1, pair_hands=1, lt_capture=1; previous weight tuning retained for hand_lock=0");
    }
    if (g_settingsRev < 128) {
      InterlockedExchange(&g_ctl.vrFpsCap, 0);
      log_line("SETTINGS 1.7.33: VR FPS cap defaults to Off; headset Hz is selected in Virtual Desktop");
    }
    if (g_settingsRev < 129 && g_ctl.gunPunishPct == 100) {
      InterlockedExchange(&g_ctl.gunPunishPct, 150);
      log_line("SETTINGS 1.7.35: one-handed firing penalty 150%% (previous default 100%%); other choices retained");
    }
    if (g_settingsRev < 130) {   // 1.7.36
      InterlockedExchange(&g_ctl.knockComfort, 1); InterlockedExchange(&g_ctl.knockMs, 3000); InterlockedExchange(&g_ctl.knockWalkPct, 45);
      InterlockedExchange(&g_ctl.knockAimDeg, 4); InterlockedExchange(&g_ctl.knockDarkPct, 85);
      InterlockedExchange(&g_ctl.trapFree, 1); InterlockedExchange(&g_ctl.trapFromHand, 1); InterlockedExchange(&g_ctl.gunHpBar, 1); InterlockedExchange(&g_ctl.gunHpFwdCm, 13); InterlockedExchange(&g_ctl.gunHpUpCm, 7);
      log_line("SETTINGS 1.7.36: knock_comfort 1 (new: a ghost's knock-down is not played; you walk slower, the edges go dark and the aim sways for 3 s), knock_walk_pct 45, knock_aim_deg 4, knock_dark_pct 85");
    }
    if (g_settingsRev < 131) {   // 1.7.38
      InterlockedExchange(&g_ctl.sprintGame, 1); InterlockedExchange(&g_ctl.chestCam, 0); InterlockedExchange(&g_ctl.chestCamEvery, 4);
      InterlockedExchange(&g_ctl.chestCamDownCm, 25); InterlockedExchange(&g_ctl.chestCamBackCm, 18); InterlockedExchange(&g_ctl.chestCamNearCm, 14);
      log_line("SETTINGS 1.7.38: sprint_game 1 (the sprint click starts the game's own run again), chest_cam 0 (new: a chest camera for the PC window, off until you switch it on), chest_cam_every 4, down 25 cm, back 18 cm, near 14 cm");
    }
    if (g_settingsRev < 132) {   // 1.7.41
      InterlockedExchange(&g_ctl.sprintGame, 0); InterlockedExchange(&g_ctl.bosonGrip, 1); InterlockedExchange(&g_ctl.collectMarkers, 0);
      log_line("SETTINGS 1.7.41: sprint_game 0 (sprint is only the speed increase now, not the game's run), boson_grip 1 (squeeze the gun hand's grip = Boson Dart)");
    }
    if (g_settingsRev < 133) {
      InterlockedExchange(&g_ctl.probeData, 0); InterlockedExchange(&g_ctl.diagTiming, 0);
      InterlockedExchange(&g_ctl.wallDiag, 0); InterlockedExchange(&g_ctl.rigAutoShots, 0);
    }
    if (g_settingsRev < 134) {
      InterlockedExchange(&g_ctl.watchGame, 0);
    }
    if (g_settingsRev < 135) {
      InterlockedExchange(&g_ctl.menuMusic, 1);
      if (g_ctl.menuMusicPct <= 0) InterlockedExchange(&g_ctl.menuMusicPct, 55);
      InterlockedExchange(&g_ctl.fullBody, 1); InterlockedExchange(&g_ctl.bodyWhole, 1);
      InterlockedExchange(&g_ctl.armsOnly, 1); InterlockedExchange(&g_ctl.armsShoulders, 1);
      InterlockedExchange(&g_ctl.armIk, 1);
    }
    if (g_settingsRev < 136) {
      InterlockedExchange(&g_ctl.monitorView, 1); InterlockedExchange(&g_ctl.monitorFit, 1);
      InterlockedExchange(&g_ctl.monitorHfovDeg, 115); InterlockedExchange(&g_ctl.monitorZoomPct, 100);
      InterlockedExchange(&g_ctl.monitorDownDeg, 10); InterlockedExchange(&g_ctl.monitorHandFrame, 1);
      InterlockedExchange(&g_ctl.monitorLevel, 1);
    }
    if (g_settingsRev < 137) {
      InterlockedExchange(&g_ctl.ltCapture, 0);
      InterlockedExchange(&g_ctl.sprintClick, 1);
      InterlockedExchange(&g_ctl.bosonGrip, 0);
      log_line("SETTINGS 1.7.57: left trigger is the game's LT / alternate fire for every weapon; left stick click = Sprint, right stick click = Capture / wrangle, D-layer right click = Vent; boson_grip defaults off");
    }
    if (g_settingsRev < 138) {
      InterlockedExchange(&g_ctl.gunFwdCm, 0); InterlockedExchange(&g_ctl.gunUpCm, 0);
      InterlockedExchange(&g_ctl.pkeFwdCm, 0); InterlockedExchange(&g_ctl.pkeUpCm, 0);
      InterlockedExchange(&g_ctl.gunWristCm, 0);
      InterlockedExchange(&g_ctl.sprintSpeedMethod, 3);
      InterlockedExchange(&g_ctl.sprintToggle, 1);
      log_line("SETTINGS 1.7.58: gun/PKE fit offsets and gun_wrist_cm -> 0 (the game's exact hand-to-prop transform is the grip); sprint uses the reliable nudge way and a true persistent toggle");
    }
    if (g_settingsRev < 139) {   // 1.7.64
      InterlockedExchange(&g_ctl.gunHpSideCm, -5); InterlockedExchange(&g_ctl.gunHpUpCm, 3);
      InterlockedExchange(&g_ctl.hideBeltPke, 1); InterlockedExchange(&g_ctl.pkeGripHeal, 1);
      log_line("SETTINGS 1.7.64: life bar on the gun moved 5 cm left and 4 cm lower (gun_hp_side_cm -5, gun_hp_up_cm 3), hide_belt_pke 1 (the belt copy of the PKE with its swinging cable is not drawn), pke_grip_heal 1");
    }
    if (g_settingsRev < 140) {   // 1.7.66
      InterlockedExchange(&g_ctl.gunHpUpCm, -4);
      InterlockedExchange(&g_ctl.pkeLiveGrip, 1); InterlockedExchange(&g_ctl.gunGripHeal, 1); InterlockedExchange(&g_ctl.hideGunGap, 1);
      log_line("SETTINGS 1.7.66: life bar on the gun 7 cm lower (gun_hp_up_cm -4), pke_live_grip 1, gun_grip_heal 1, hide_gun_gap 1");
    }
    if (g_settingsRev < 141) {   // 1.7.67: the gun is exactly as in 1.7.65 again; the PKE uses a clean hand
      InterlockedExchange(&g_ctl.gunGripHeal, 0); InterlockedExchange(&g_ctl.hideGunGap, 0); InterlockedExchange(&g_ctl.pkeRigidHand, 1);
      log_line("SETTINGS 1.7.67: gun_grip_heal 0 and hide_gun_gap 0 (the gun hand is left exactly as it was in 1.7.65), pke_rigid_hand 1 (the PKE is placed through a clean, unstretched hand)");
    }
    if (g_settingsRev < 142) {   // 1.7.68
      InterlockedExchange(&g_ctl.gunLiveGrip, 1);
      log_line("SETTINGS 1.7.68: gun_live_grip 1 (the hand on the gun follows the game's hold as at spawn, no early freeze)");
    }
    if (g_settingsRev < 143) {   // 1.7.69
      InterlockedExchange(&g_ctl.pkeSteadyOnly, 0); InterlockedExchange(&g_ctl.armReachPct, 120); InterlockedExchange(&g_ctl.stairsSmoothMs, 120);
      log_line("SETTINGS 1.7.69: pke_steady_only 0 (the PKE uses the gun's rule), arm_reach_pct 120 (elbow room), stairs_smooth_ms 120 (stairs do not jolt the view)");
    }
    if (g_settingsRev < 144) {   // 1.7.70
      InterlockedExchange(&g_ctl.pkeSetMatrix, 1); InterlockedExchange(&g_ctl.handClean, 1);
      log_line("SETTINGS 1.7.70: pke_set_matrix 1 (the PKE pose goes through the game's own setter), hand_clean 1 (no stretched hand)");
    }
    if (g_settingsRev < 145) {   // 1.7.71
      InterlockedExchange(&g_ctl.stairsRamp, 1); InterlockedExchange(&g_ctl.stairsLift, 1); InterlockedExchange(&g_ctl.pkeDrawSwap, 1); InterlockedExchange(&g_ctl.slimeMuzzle, 1); InterlockedExchange(&g_ctl.gunHoldSmoothMs, 150);
      log_line("SETTINGS 1.7.71: pke_draw_swap 1 (the PKE is moved where it is drawn, like the gun), slime_muzzle 1 (the slime comes out of the gun in your hand), stairs_ramp 1 (stairs are a smooth slope), stairs_lift 1 (sprint climbs stairs), gun_hold_smooth_ms 150 (no gun / hand tremble while walking)");
    }
    if (g_settingsRev < 147) {   // 1.7.74 (on top of the 1.7.73 values, which are kept: frozen gun / PKE grips, no hold smoothing)
      InterlockedExchange(&g_ctl.pkeHoldRpke, 1); InterlockedExchange(&g_ctl.slimeLtEdge, 1);
      log_line("SETTINGS 1.7.74: pke_hold_rpke 1 (the PKE grip comes from the animation's hand hold), slime_lt_edge 1 (one tether shot per squeeze)");
    }
    if (g_settingsRev < 148) {   // 1.7.76
      InterlockedExchange(&g_ctl.slimeRopeFix, 1); InterlockedExchange(&g_ctl.pkeCtlRigid, 1); InterlockedExchange(&g_ctl.pkeFingersAnim, 1);
      log_line("SETTINGS 1.7.76: slime_rope_fix 1 (one rope step per squeeze: two squeezes = the rope's two anchors), pke_ctl_rigid 1 (the hand and the PKE in it turn exactly with your controller), pke_fingers_anim 1 (the hand keeps the game's fingers around the PKE)");
    }
    if (g_settingsRev < 149) {   // 1.7.77
      InterlockedExchange(&g_ctl.gunFreshHand, 1);
      log_line("SETTINGS 1.7.77: gun_fresh_hand 1 (the gun follows the hand as it is now, so it does not trail behind fast hands)");
    }
    if (g_settingsRev < 150) {   // 1.7.78
      InterlockedExchange(&g_ctl.gunCtlFollow, 1);
      log_line("SETTINGS 1.7.78: gun_ctl_follow 1 (the gun sits on your controller through its locked hand relation, not on the arm solve's hand)");
    }
    if (g_settingsRev < 151) {   // 1.7.79
      InterlockedExchange(&g_ctl.keepControl, 1);
      log_line("SETTINGS 1.7.79: keep_control 1 (the game can no longer take the body, arms and gun back: stairs, moving platforms, portals, level loads)");
    }
    if (g_settingsRev < 152) {   // 1.7.81
      InterlockedExchange(&g_ctl.turnSmoothDps, 120); InterlockedExchange(&g_ctl.turnSmoothOwn, 1);
      log_line("SETTINGS 1.7.81: smooth turn: turn_smooth_own 1, turn_smooth_dps 120 (with Snap turn OFF the mod turns you smoothly; the speed is on the Play tab)");
    }
    if (g_settingsRev < 153) {   // 1.7.83
      InterlockedExchange(&g_ctl.pkeCloseHelp, 1);
      log_line("SETTINGS 1.7.83: pke_close_help 1 (the PKE scan cone gets wider while a scannable thing is close to the meter)");
    }
    if (g_settingsRev < 154) {   // 1.7.84
      InterlockedExchange(&g_ctl.heldLive, 1);
      log_line("SETTINGS 1.7.84: held_live 1 (the menu gesture opens the VR pages in your hand over the live, frozen 3D world: look all around, both eyes as in the game)");
    }
    if (g_settingsRev < 155) {   // 1.7.98
      InterlockedExchange(&g_ctl.drawAnim, 1);
      log_line("SETTINGS 1.7.98: gun_draw_anim 1 (after a weapon switch or the PKE coming out, the game's own draw animation is shown on your hand for the first moment: the gun / meter travels in from the back / belt, its own fingers close; view only)");
    }
    if (g_settingsRev < 156) {   // 1.7.99
      InterlockedExchange(&g_ctl.drawAnim, 0); InterlockedExchange(&g_ctl.gunWaitDraw, 1);
      log_line("SETTINGS 1.7.99: gun_draw_anim 0 (the game has no draw animation of its own in this build), gun_wait_draw 1 (a gun the game gives you stays holstered until you draw it; no gun in hand where the game does not allow one)");
    }
    if (g_settingsRev < 157) {   // 1.7.116
      // Defaults changed in 1.7.113-1.7.116 but never reached a saved settings file: the saved value wins over the code's default, and the file written by 1.7.110-1.7.112 holds the old ones. They are
      // followed once, only where the file still holds the old default (a value you chose yourself stays). Nothing of the Deluxe mod's is touched.
      if (g_ctl.gunFingerOpenPct == 35 || g_ctl.gunFingerOpenPct == 20) { const int was = (int)g_ctl.gunFingerOpenPct; InterlockedExchange(&g_ctl.gunFingerOpenPct, 0); log_line("SETTINGS 1.7.116: gun_finger_open_pct %d -> 0 (the gun hand keeps the game's grip on the handle whatever the right grip does: with the grip not squeezed the fingers used to open and the hand looked like it floated by the handle; the 1.7.114 default of 20 never reached your saved settings, it still held 35)", was); }
      if (g_ctl.grabOrbitFollowPct == 25) { InterlockedExchange(&g_ctl.grabOrbitFollowPct, 10); log_line("SETTINGS 1.7.116: grab_orbit_follow_pct 25 -> 10 (the held hand sits more on top of the barrel; the 1.7.113 default never reached your saved settings)"); }
      if (g_ctl.foreNearCm == 14) { InterlockedExchange(&g_ctl.foreNearCm, 18); log_line("SETTINGS 1.7.116: fore_near_cm 14 -> 18 (the free hand takes hold of the barrel from a little further away)"); }
    }
    if (g_settingsRev < 158) {   // 1.7.117
      // Before 1.7.117 the crash safety SAVED its step-back: after ONE game crash a player's file had the hands / body / gun features off for good (no motion controls, the
      // inside of the face visible). The four switched off together are that signature; they come back on once. Nothing of the Deluxe mod's is touched.
      // The signature is wand_to_hand OFF together with menu_fast OFF (the crash ladder switches both; a real report had exactly these two off, the rest already back on).
      if (!g_ctl.wandToHand && !g_ctl.menuFast) {
        InterlockedExchange(&g_ctl.wandToHand, 1); InterlockedExchange(&g_ctl.menuFast, 1);
        if (!g_ctl.fullBody) InterlockedExchange(&g_ctl.fullBody, 1);
        if (!g_ctl.armIk) InterlockedExchange(&g_ctl.armIk, 1);
        if (!g_ctl.bodyFollow) InterlockedExchange(&g_ctl.bodyFollow, 1);
        log_line("SETTINGS 1.7.117: wand_to_hand and menu_fast were both OFF in the saved file: an old crash step-back that was saved. Hands / body features switched back ON.");
      }
    }
    if (g_settingsRev < 159 && !g_ctl.twoHandLine) {   // 1.7.128: the old saved default 0 overrides the new code default 1
      InterlockedExchange(&g_ctl.twoHandLine, 1);
      log_line("SETTINGS 1.7.128: two_hand_line 0 -> 1 once (a confirmed left-hand barrel hold now steers the beam; set it back to 0 after this update for right-controller-only aim)");
    }
    if (g_settingsRev < 160) {
      InterlockedExchange(&g_ctl.hbarWallHide, 1);
      InterlockedExchange(&g_ctl.hbarGate, 1);
      InterlockedExchange(&g_ctl.ringWall, 1);
      log_line("SETTINGS health wall checks enabled once for existing installs (hbar_wall_hide=1, hbar_gate=1, ring_wall=1)");
    }
    if (g_settingsRev < 161 && g_ctl.gunCtlFollow) {   // 1.7.147: LOCK TO THE HAND
      InterlockedExchange(&g_ctl.gunCtlFollow, 0);
      log_line("SETTINGS 1.7.147: gun_ctl_follow 1 -> 0 once (the gun is drawn on the hand you see, not on the controller through a stored relation: players saw it float above the hand)");
    }
    if (g_settingsRev < 162) {   // 1.7.148: the game's own hose, bent to the gun in your hand, instead of no hose / the mod's own cord
      InterlockedExchange(&g_ctl.hoseOff, 0); InterlockedExchange(&g_ctl.cordPhysics, 0);
      log_line("SETTINGS 1.7.148: hose_off 0 and cord_physics 0 once (the game's own hose is shown, bent to the gun in your hand; it hides itself whenever it cannot be bent)");
    }
    if (g_settingsRev < 163 && g_ctl.gunHpFwdCm == 13 && g_ctl.gunHpUpCm == -4 && g_ctl.gunHpSideCm == -5) {   // 1.7.167: the old tube place (below and left of the controller)
      InterlockedExchange(&g_ctl.gunHpFwdCm, 25); InterlockedExchange(&g_ctl.gunHpUpCm, 6); InterlockedExchange(&g_ctl.gunHpSideCm, 0);
      log_line("SETTINGS 1.7.167: gun_hp_fwd_cm 13 -> 25, gun_hp_up_cm -4 -> 6, gun_hp_side_cm -5 -> 0 once (the health tube sits on top of the drawn gun)");
    }
    if (g_settingsRev < 164 && g_ctl.hbarAlphaPct == 100) {   // 1.7.171: "make circle and bar health more transparent, they cover the ghost"
      InterlockedExchange(&g_ctl.hbarAlphaPct, 55);
      log_line("SETTINGS 1.7.171: hbar_alpha_pct 100 -> 55 once (the ghost health ring / vial / bar are see-through; the ring is also thinner)");
    }
    if (g_settingsRev < 165) {   // 1.7.173
      if (g_ctl.hbarAlphaPct == 55) { InterlockedExchange(&g_ctl.hbarAlphaPct, 45); log_line("SETTINGS 1.7.173: hbar_alpha_pct 55 -> 45 once (ghost health a little more see-through)"); }
      InterlockedExchange(&g_ctl.gunFireFx, 0); InterlockedExchange(&g_ctl.trapNoAnim, 1);
      log_line("SETTINGS 1.7.173: gun_fire_fx 0 (firing no longer moves the gun in your hand: no recoil, climb, shake or kick; gun_fire_fx=1 brings it back), trap_no_anim 1 (the trap button throws from your off hand, no throw animation on the body)");
    }
    if (g_settingsRev < 166) InterlockedExchange(&g_ctl.leftHandDraw, 1);   // 1.7.174
    if (g_settingsRev < 168 && g_ctl.gunWeightPct == 100) { InterlockedExchange(&g_ctl.gunWeightPct, 150); log_line("SETTINGS 1.7.177: gun_heft_pct 100 -> 150 once (the gun feels heavier to turn; one-handed it is loose again)"); }
    if (g_settingsRev < 169) {   // 1.7.184: "just arms, no flashlight or anything else on the chest": only the arms (and the gun with its hose) are drawn
      InterlockedExchange(&g_ctl.armsShoulders, 0); InterlockedExchange(&g_ctl.armsStraps, 0); InterlockedExchange(&g_ctl.bodyWhole, 0);
      log_line("SETTINGS 1.7.184: arms_shoulders 0, arms_straps 0, body_whole 0 (only the arms are drawn: no chest, no gear on it)");
    }
    if (g_settingsRev < 170) {   // 1.7.186: "full body for the whole game but the Stay Puft roof fight": the whole body is drawn again (only the head hidden); the roof fight still squashes everything but the arms by itself
      InterlockedExchange(&g_ctl.armsShoulders, 1); InterlockedExchange(&g_ctl.armsStraps, 1); InterlockedExchange(&g_ctl.bodyWhole, 1);
      log_line("SETTINGS 1.7.186: arms_shoulders 1, arms_straps 1, body_whole 1 (the full body is drawn in the whole game again; only the Stay Puft roof fight shows just the arms)");
    }
    if (g_settingsRev < 167 && g_ctl.gunHpUpCm == 6) { InterlockedExchange(&g_ctl.gunHpUpCm, 2); log_line("SETTINGS 1.7.176: gun_hp_up_cm 6 -> 2 once (the health tube sits lower on the gun)"); }
    if (g_settingsRev < 171) { InterlockedExchange(&g_ctl.bodyCalmSlam, 1); if (g_ctl.knockMs == 3000) { InterlockedExchange(&g_ctl.knockMs, 4000); log_line("SETTINGS 1.7.196: knock_ms 3000 -> 4000 once (the slower walk, slower arms and dark edges last 4 s); body_calm_slam 1 (new: the body does not spin while a ghost is held in the beam or a slam plays)"); } }
    if (g_settingsRev < 173) { InterlockedExchange(&g_ctl.trapHangPct, -30); log_line("SETTINGS 1.7.198: trap_hang_pct -30 (the carried trap is raised so the handle, which sits below the trap's top end, is in the fist)"); }
    if (g_settingsRev < 172) { InterlockedExchange(&g_ctl.downVignette, 1); log_line("SETTINGS 1.7.197: down_vignette 1 (new: no dead body, a pulsing red edge when you are dying or knocked down), trap_hang_pct 40 (the carried trap sits higher in the hand)"); }
    if (g_settingsRev < 174 && g_ctl.knockMs < 4000) { InterlockedExchange(&g_ctl.knockMs, 4000); log_line("SETTINGS 1.7.200: knock_ms -> 4000 (slower walk, slower arms and dark edges last 4 s; the 1.7.196 change had skipped your file)"); }
    if (g_settingsRev < 175 && g_ctl.knockDarkPct < 100) { InterlockedExchange(&g_ctl.knockDarkPct, 100); log_line("SETTINGS 1.7.203: knock_dark_pct -> 100 (the knock-down edge is steady black at full strength)"); }
    if (g_settingsRev < 176 && g_ctl.gunHpHandCut) { InterlockedExchange(&g_ctl.gunHpHandCut, 0); log_line("SETTINGS 1.7.209: gun_hp_hand_cut 1 -> 0 once (the hands no longer cut the gun's life tube: it was hidden by the off hand on the foregrip)"); }
    InterlockedExchange(&g_settingsRev, kSettingsRev);
    settings_changed();
  }
  // 1.7.37: damage is the game's own, always ("make sure damage is set to the base game value; don't increase or affect it anymore"). beam_damage_pct is locked at 100 whatever the file says.
  InterlockedExchange(&g_ctl.sprintGame, 0); InterlockedExchange(&g_ctl.sprintViaJump, 0);
  InterlockedExchange(&g_ctl.sprintForce, 0); InterlockedExchange(&g_ctl.easySprint, 0);
  if (g_ctl.ltCapture != 0) { log_line("SETTINGS lt_capture %d -> 0 (1.7.57: left trigger is always alternate fire; Capture moved to right stick click)", (int)g_ctl.ltCapture); InterlockedExchange(&g_ctl.ltCapture, 0); }
  if (g_ctl.sprintClick != 1) { log_line("SETTINGS sprint_click %d -> 1 (1.7.57: fixed layout keeps left stick click = Sprint and right stick click = Capture / wrangle)", (int)g_ctl.sprintClick); InterlockedExchange(&g_ctl.sprintClick, 1); }
  // 1.7.58: these old fit knobs are intentionally neutralized.  The game hand decides the grip.
  if (g_ctl.gunFwdCm || g_ctl.gunUpCm || g_ctl.pkeFwdCm || g_ctl.pkeUpCm || g_ctl.gunWristCm) {
    log_line("SETTINGS 1.7.58 exact grip: legacy fit values gun=%d/%d pke=%d/%d wrist=%d -> all 0", (int)g_ctl.gunFwdCm, (int)g_ctl.gunUpCm, (int)g_ctl.pkeFwdCm, (int)g_ctl.pkeUpCm, (int)g_ctl.gunWristCm);
    InterlockedExchange(&g_ctl.gunFwdCm,0); InterlockedExchange(&g_ctl.gunUpCm,0); InterlockedExchange(&g_ctl.pkeFwdCm,0); InterlockedExchange(&g_ctl.pkeUpCm,0); InterlockedExchange(&g_ctl.gunWristCm,0);
  }
  if (g_ctl.sprintSpeedMethod != 3) { log_line("SETTINGS sprint_speed_method %d -> 3 (1.7.58: reliable nudge speed route)", (int)g_ctl.sprintSpeedMethod); InterlockedExchange(&g_ctl.sprintSpeedMethod,3); }
  if (g_ctl.gripAtHand != 1) { log_line("SETTINGS grip_at_hand %d -> 1 (1.7.58: exact game-hand anchoring is mandatory)", (int)g_ctl.gripAtHand); InterlockedExchange(&g_ctl.gripAtHand,1); }
  if (g_ctl.handLock != 1) { log_line("SETTINGS hand_lock %d -> 1 (1.7.58: weapon/PKE grip survives model reloads and holster/draw)", (int)g_ctl.handLock); InterlockedExchange(&g_ctl.handLock,1); }
  if (g_ctl.beamDamagePct != 100) { log_line("SETTINGS beam_damage_pct %d -> 100 (1.7.37: locked at the game's own damage)", (int)g_ctl.beamDamagePct); InterlockedExchange(&g_ctl.beamDamagePct, 100); }
  // 1.7.18: the PKE never scans by itself. pke_auto is locked at 0 whatever the settings file says (a scan starts only while you squeeze the right trigger with the PKE out).
  if (g_ctl.pkeAuto) { InterlockedExchange(&g_ctl.pkeAuto, 0); log_line("SETTINGS pke_auto %d -> 0 (1.7.18: the auto-scan is locked off; the PKE scans only while you squeeze the right trigger)", 1); }
  player_edition_gate();   // 1.7.65
  log_line("SETTINGS loaded %d values: height=%d world=%d picture=%d depth=%d eyeHeight=%d near=%d sharp=%d smooth=%d sameMoment=%d hideBody=%d/wand %d/shadow %d headAim=%d hud=%d/%d/%d", applied,
           (int)g_ctl.sizePct, (int)g_ctl.worldPct, (int)g_ctl.pictureLevel, (int)g_ctl.stereoStrengthPct,
           (int)g_ctl.eyeHeightCenti, (int)g_ctl.nearCenti, (int)g_ctl.stereoWide, (int)g_ctl.stereoPair,
           (int)g_ctl.stereoSameMoment, (int)g_ctl.hideBody, (int)g_ctl.hideWand, (int)g_ctl.hideShadow, (int)g_ctl.headAim, (int)g_ctl.hudMode, (int)g_ctl.hudSizePct, (int)g_ctl.hudDistanceCm);
}

// 0.53 the in-VR menu edits the same table
int settings_lookup(const char* name, volatile LONG** v, LONG* lo, LONG* hi) {
  for (Item& it : g_items) {
    if (lstrcmpA(it.name, name) == 0) { *v = it.value; *lo = it.lo; *hi = it.hi; return 1; }
  }
  return 0;
}

void settings_changed() { InterlockedExchange(&g_dirty, 1); }

void settings_save_if_changed() {
  if (shot_busy()) return;  // a picture sequence has two switches flipped for a moment: save afterwards
  if (!InterlockedExchange(&g_dirty, 0)) return;
  make_path();
  static char buf[16384];
  int len = log_fmt(buf, (int)sizeof(buf), "; Ghostbusters VR probe settings (written by the probe; delete this file to go back to defaults)\r\n");
  for (Item& it : g_items) {
    int v = (int)*it.value;
    // 0.83: the start-up memory guard lowers the level for ONE run only; never write that lowered value into the file
    if (it.value == &g_ctl.pictureLevel && g_guardKeepLevel > 0 && v == g_guardLoweredTo) v = (int)g_guardKeepLevel;
    v = (int)safety_saved_value(it.value, (LONG)v);   // 1.7.117: a step-back of the crash safety is for this run only; the file keeps your own value
    len += log_fmt(buf + len, (int)sizeof(buf) - len, "%s=%d\r\n", it.name, v);
  }
  HANDLE f = CreateFileW(g_path, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f == INVALID_HANDLE_VALUE) { log_line("SETTINGS could not write gbvr_settings.txt (error %u)", GetLastError()); return; }
  DWORD w = 0;
  WriteFile(f, buf, (DWORD)len, &w, nullptr);
  CloseHandle(f);
  log_line("SETTINGS saved: height=%d world=%d picture=%d depth=%d eyeHeight=%d near=%d sharp=%d smooth=%d sameMoment=%d hideBody=%d/wand %d/shadow %d headAim=%d hud=%d/%d/%d",
           (int)g_ctl.sizePct, (int)g_ctl.worldPct, (int)g_ctl.pictureLevel, (int)g_ctl.stereoStrengthPct,
           (int)g_ctl.eyeHeightCenti, (int)g_ctl.nearCenti, (int)g_ctl.stereoWide, (int)g_ctl.stereoPair,
           (int)g_ctl.stereoSameMoment, (int)g_ctl.hideBody, (int)g_ctl.hideWand, (int)g_ctl.hideShadow, (int)g_ctl.headAim, (int)g_ctl.hudMode, (int)g_ctl.hudSizePct, (int)g_ctl.hudDistanceCm);
}

// ---- 1.7.19 profiles: three people can share the headset ---------------------------------------------------------------------------------------------
// Everything except the machine-wide picture / quality keys belongs to the person: height and world size, handedness, seated play, gun fit, body, hands, bars, buzz ...
// gbvr_profile_N.txt holds profile N while another one is in use. Switching saves the one in use, then loads the other (a new profile starts from the settings in use).
static int machine_key(const char* n) {
  static const char* const k[] = {"profile_slot", "settings_rev", "picture_level", "picture_lines", "sharp_mode", "smooth_mode", "same_moment", "auto_quality", "diag_timing", "probe_data", "pad_enabled", "watch_game", "skip_videos", "flat_vsync_off", "mem_cache", "sim_step_cap_ms", "sim_every_n", "start_in_vr", "menu_on_start", "hud_retry"};
  for (const char* m : k) if (lstrcmpA(m, n) == 0) return 1;
  return 0;
}
static void profile_path(int slot, wchar_t* out) {
  lstrcpynW(out, g_selfDir, MAX_PATH);
  lstrcatW(out, slot == 2 ? L"gbvr_profile_2.txt" : (slot == 3 ? L"gbvr_profile_3.txt" : L"gbvr_profile_1.txt"));
}
static struct { long switches, saved, loaded, fresh; int lastFrom, lastTo; } g_prof;
void settings_profile_switch(int from, int to) {
  if (from == to || from < 1 || from > 3 || to < 1 || to > 3) return;
  wchar_t pf[MAX_PATH + 32], pt[MAX_PATH + 32];
  profile_path(from, pf); profile_path(to, pt);
  static char buf[16384];
  int len = log_fmt(buf, (int)sizeof(buf), "; Ghostbusters VR probe profile %d\r\n", from);
  for (Item& it : g_items) { if (machine_key(it.name)) continue; len += log_fmt(buf + len, (int)sizeof(buf) - len, "%s=%d\r\n", it.name, (int)*it.value); }
  HANDLE f = CreateFileW(pf, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f != INVALID_HANDLE_VALUE) { DWORD w = 0; WriteFile(f, buf, (DWORD)len, &w, nullptr); CloseHandle(f); ++g_prof.saved; }
  else log_line("USERPROFILE could not write profile %d (error %u): its settings are kept only until the game closes", from, GetLastError());
  HANDLE r = CreateFileW(pt, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
  int applied = 0;
  if (r != INVALID_HANDLE_VALUE) {
    DWORD got = 0; ReadFile(r, buf, sizeof(buf) - 1, &got, nullptr); CloseHandle(r); buf[got] = 0;
    for (DWORD i = 0; i < got;) {
      DWORD lineEnd = i;
      while (lineEnd < got && buf[lineEnd] != '\n' && buf[lineEnd] != '\r') ++lineEnd;
      for (Item& it : g_items) {
        if (machine_key(it.name)) continue;
        const int n = lstrlenA(it.name);
        if (i + (DWORD)n < lineEnd && buf[i + n] == '=' && CompareStringA(LOCALE_INVARIANT, 0, buf + i, n, it.name, n) == CSTR_EQUAL) {
          DWORD p = i + n + 1; int neg = 0, digits = 0; LONG v = 0;
          if (p < lineEnd && buf[p] == '-') { neg = 1; ++p; }
          while (p < lineEnd && buf[p] >= '0' && buf[p] <= '9' && digits < 7) { v = v * 10 + (buf[p] - '0'); ++p; ++digits; }
          if (digits) { if (neg) v = -v; if (v < it.lo) v = it.lo; if (v > it.hi) v = it.hi; InterlockedExchange(it.value, v); ++applied; }
        }
      }
      i = lineEnd; while (i < got && (buf[i] == '\n' || buf[i] == '\r')) ++i;
    }
    ++g_prof.loaded;
  } else ++g_prof.fresh;
  player_edition_gate();   // 1.7.65: a profile file cannot switch the developer-only features on
  ++g_prof.switches; g_prof.lastFrom = from; g_prof.lastTo = to;
  InterlockedExchange(&g_ctl.profileSlot, to);
  InterlockedExchange(&g_dirty, 1);
  log_line("USERPROFILE switched %d -> %d: profile %d saved; profile %d %s (%d settings applied: height %d%%, world %d%%, left-handed %d, seated %d, bars %d%%/%d%%)", from, to, from, to,
           r != INVALID_HANDLE_VALUE ? "loaded" : "is new (it starts from the settings in use)", applied, (int)g_ctl.sizePct, (int)g_ctl.worldPct, (int)g_ctl.leftHanded, (int)g_ctl.seated, (int)g_ctl.hbarSizePct, (int)g_ctl.hbarAlphaPct);
}
void settings_profile_report(LONG frame) {
  log_line("USERPROFILE frame=%d in use: %d of 3 | switches %ld (saved %ld, loaded %ld, new %ld), last %d -> %d | per person: everything except the picture / quality keys (profile files gbvr_profile_N.txt in the game folder)", (int)frame, (int)g_ctl.profileSlot, g_prof.switches, g_prof.saved, g_prof.loaded, g_prof.fresh, g_prof.lastFrom, g_prof.lastTo);
}

#endif
