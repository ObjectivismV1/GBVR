// 0.27 diagnostic picture (F2): what each eye is shown, saved as one JPEG
// file in the game folder, so that a description like "the beam looks odd"
// can be looked at.
//
// One key press takes three snapshots a few headset frames apart:
//   row 1  the settings as played
//   row 2  F7 (full picture width) switched the other way
//   row 3  "same moment" (Delete) switched the other way
// and puts them into one picture, 1920 pixels wide:
//   top band   the game's whole frame of the left eye in row 1 (with HUD)
//   then       three rows, left eye | right eye, each eye 960 pixels wide
//              and drawn with the same scale in both directions (what is
//              round for the eye is round in the tile).
// The two switches are put back afterwards and are not saved. The log gets a
// SHOT line per row with the settings that were in effect.
//
// Render thread: copies the two eye textures (the probe's own textures) into
// a CPU-readable texture and shrinks them into the picture. A worker thread
// encodes and writes the file. Nothing of the game's state is touched.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include "shotmath.h"
#include "jpegenc.h"
#include <d3d11.h>

static const int kTileW = 960, kTileHMax = 1088, kPicW = 1920, kBandHMax = 1440, kRows = 3;
static const int kSettlePairs = 8;   // headset frames to wait after a switch
static const int kQuality = 85;

static volatile LONG g_request;      // F2 pressed
static ULONGLONG g_requestAt;        // ... at this time (a request that cannot start within 1.5 s is dropped)
static volatile LONG g_saving;       // worker thread busy
static int g_row = -1;               // -1 idle, 0..2 the row to take next
static int g_wait;
static LONG g_savedWide, g_savedSame;
static uint8_t* g_pic;               // kPicW x g_picH x 3
static int g_picH, g_bandH, g_tileH;
static ID3D11Texture2D* g_staging;
static UINT g_stW, g_stH;
static DXGI_FORMAT g_stFmt;
static int g_xr[2 * shot::kMaxTile];
static LONG g_shots, g_failed;

void shot_request() { g_requestAt = GetTickCount64(); InterlockedExchange(&g_request, 1); }

static void restore_switches() {
  InterlockedExchange(&g_ctl.stereoWide, g_savedWide);
  InterlockedExchange(&g_ctl.stereoSameMoment, g_savedSame);
}

static void drop_picture() {
  if (g_pic) { HeapFree(GetProcessHeap(), 0, g_pic); g_pic = nullptr; }
}

// Every presented frame: a request that found no 3D picture (menu, flat
// screen) expires without interrupting play.
void shot_expire() {
  if (g_row < 0 && g_request && GetTickCount64() - g_requestAt > 1500 && InterlockedExchange(&g_request, 0)) {
    log_line("SHOT request dropped: no 3D picture within 1.5 s of the key");
  }
}

void shot_release() {  // device gone, headset view off, or no 3D frames any more (menu)
  InterlockedExchange(&g_request, 0);
  if (g_row >= 0) { restore_switches(); g_row = -1; drop_picture(); log_line("SHOT cancelled (no 3D picture any more)");  }
  if (g_staging) { g_staging->Release(); g_staging = nullptr; }
  g_stW = g_stH = 0;
}

struct SaveJob { uint8_t* rgb; int w, h; char name[64]; };
struct FileOut { HANDLE f; int failed; };

static void file_write(void* ctx, const uint8_t* data, uint32_t n) {
  FileOut* o = (FileOut*)ctx;
  DWORD w = 0;
  if (o->failed || !WriteFile(o->f, data, n, &w, nullptr) || w != n) o->failed = 1;
}

static HANDLE create_in(const wchar_t* dir, const char* name) {
  wchar_t path[MAX_PATH + 160];
  lstrcpynW(path, dir, MAX_PATH + 64);
  int n = lstrlenW(path);
  for (int i = 0; name[i] && n < MAX_PATH + 158; ++i) path[n++] = (wchar_t)name[i];
  path[n] = 0;
  return CreateFileW(path, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
}

static DWORD WINAPI save_thread(LPVOID p) {
  SaveJob* job = (SaveJob*)p;
  // next to the log: the game folder, or the log's Documents fallback if the game folder is not writable
  FileOut out;
  out.failed = 0;
  int fallback = 0;
  out.f = create_in(g_selfDir, job->name);
  if (out.f == INVALID_HANDLE_VALUE && lstrcmpiW(log_dir(), g_selfDir) != 0) { out.f = create_in(log_dir(), job->name); fallback = 1; }
  int ok = 0;
  LARGE_INTEGER size;
  size.QuadPart = 0;
  DWORD err = GetLastError();
  if (out.f != INVALID_HANDLE_VALUE) {
    ok = jpg::encode_rgb(job->rgb, job->w, job->h, job->w * 3, kQuality, file_write, &out) && !out.failed;
    err = GetLastError();
    GetFileSizeEx(out.f, &size);
    CloseHandle(out.f);
  }
  if (ok && size.QuadPart > 1024) {
    InterlockedIncrement(&g_shots);
    log_line("SHOT saved %s (%d x %d, %d KB) %s", job->name, job->w, job->h, (int)(size.QuadPart / 1024),
             fallback ? "in the log's folder (Documents\\GhostbustersVR_logs)" : "in the game folder");
  } else {
    InterlockedIncrement(&g_failed);
    log_line("SHOT could not write %s (error %u)", job->name, (unsigned)err);
  }
  log_flush();
  HeapFree(GetProcessHeap(), 0, job->rgb);
  HeapFree(GetProcessHeap(), 0, job);
  InterlockedExchange(&g_saving, 0);
  return 0;
}

static int ensure_staging(ID3D11Device* dev, UINT w, UINT h, DXGI_FORMAT fmt) {
  if (g_staging && g_stW == w && g_stH == h && g_stFmt == fmt) return 1;
  if (g_staging) { g_staging->Release(); g_staging = nullptr; }
  D3D11_TEXTURE2D_DESC t;
  ZeroMemory(&t, sizeof(t));
  t.Width = w; t.Height = h; t.MipLevels = 1; t.ArraySize = 1; t.Format = fmt;
  t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_STAGING; t.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
  HRESULT hr = dev->CreateTexture2D(&t, nullptr, &g_staging);
  if (FAILED(hr) || !g_staging) { g_staging = nullptr; log_line("SHOT staging texture failed 0x%08x", (unsigned)hr); return 0;}
  g_stW = w; g_stH = h; g_stFmt = fmt;
  return 1;
}

static int byte_order(DXGI_FORMAT f) {  // 0 = RGBA, 1 = BGRA, -1 = not supported
  switch (f) {
    case DXGI_FORMAT_R8G8B8A8_UNORM: case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: case DXGI_FORMAT_R8G8B8A8_TYPELESS: return 0;
    case DXGI_FORMAT_B8G8R8A8_UNORM: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: case DXGI_FORMAT_B8G8R8X8_UNORM:
    case DXGI_FORMAT_B8G8R8A8_TYPELESS: return 1;
    default: return -1;
  }
}

// Called right after a pair of eye pictures was handed to the headset.
void shot_on_pair(const ShotSource* s) {
  if (g_row < 0) {
    if (!InterlockedExchange(&g_request, 0)) return;
    if (GetTickCount64() - g_requestAt > 1500) { log_line("SHOT request dropped: no 3D picture within 1.5 s of the key");  return; }
    if (g_saving) { log_line("SHOT ignored: the previous picture is still being saved");  return; }
    int order = byte_order((DXGI_FORMAT)s->format);
    if (order < 0 || !s->dev || !s->ctx || !s->tex[0] || !s->tex[1] || s->w < 64 || s->h < 64) {
      log_line("SHOT not possible: picture format %d is not supported", (int)s->format);
      
      return;
    }
    g_tileH = shot::tile_height(kTileW, s->eyeTanW, s->eyeTanH, kTileHMax);
    g_bandH = (int)((double)kPicW * (double)s->h / (double)s->w + 0.5);
    if (g_bandH > kBandHMax) g_bandH = kBandHMax;
    if (g_bandH < 16) g_bandH = 16;
    g_picH = g_bandH + kRows * g_tileH;
    drop_picture();
    g_pic = (uint8_t*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, (SIZE_T)kPicW * (SIZE_T)g_picH * 3);
    if (!g_pic) { log_line("SHOT not possible: out of memory");  return; }
    g_savedWide = g_ctl.stereoWide;
    g_savedSame = g_ctl.stereoSameMoment;
    g_row = 0;
    g_wait = 0;
    log_line("SHOT started (F2): three snapshots, picture %d x %d, eye tiles %d x %d", kPicW, g_picH, kTileW, g_tileH);
  }
  if (g_wait > 0) { --g_wait; return; }
  if (!ensure_staging(s->dev, s->w, s->h, (DXGI_FORMAT)s->format)) { restore_switches(); g_row = -1; drop_picture();  return; }
  int order = byte_order((DXGI_FORMAT)s->format);
  int okEyes = 0;
  for (int e = 0; e < 2; ++e) {
    s->ctx->CopyResource(g_staging, s->tex[e]);
    D3D11_MAPPED_SUBRESOURCE m;
    if (FAILED(s->ctx->Map(g_staging, 0, D3D11_MAP_READ, 0, &m)) || !m.pData) continue;  // that tile stays black; see "eyes read" in the log
    const float* b = s->bounds[e];
    uint8_t* tile = g_pic + ((size_t)(g_bandH + g_row * g_tileH) * kPicW + (size_t)e * kTileW) * 3;
    shot::shrink((const uint8_t*)m.pData, (int)s->w, (int)s->h, (int)m.RowPitch, order, (double)b[0] * s->w, (double)b[1] * s->h,
                 (double)b[2] * s->w, (double)b[3] * s->h, tile, kTileW, g_tileH, kPicW * 3, g_xr);
    if (g_row == 0 && e == 0)  // the whole frame, as the game drew it
      shot::shrink((const uint8_t*)m.pData, (int)s->w, (int)s->h, (int)m.RowPitch, order, 0, 0, (double)s->w, (double)s->h,
                   g_pic, kPicW, g_bandH, kPicW * 3, g_xr);
    s->ctx->Unmap(g_staging, 0);
    ++okEyes;
  }
  log_line("SHOT row %d taken (eyes read: %d): fullWidth(F7)=%d sameMoment=%d pairMode=%d frame %ux%u left u %.4f..%.4f v %.4f..%.4f "
           "right u %.4f..%.4f frame=%d", g_row + 1, okEyes, (int)g_ctl.stereoWide, (int)g_ctl.stereoSameMoment,
           (int)g_ctl.stereoPair, s->w, s->h, s->bounds[0][0], s->bounds[0][2], s->bounds[0][1], s->bounds[0][3],
           s->bounds[1][0], s->bounds[1][2], (int)g_ctl.worldFrames);
  if (g_row == 0) {
    InterlockedExchange(&g_ctl.stereoWide, g_savedWide ? 0 : 1);
    g_row = 1; g_wait = kSettlePairs;
    return;
  }
  if (g_row == 1) {
    InterlockedExchange(&g_ctl.stereoWide, g_savedWide);
    InterlockedExchange(&g_ctl.stereoSameMoment, g_savedSame ? 0 : 1);
    g_row = 2; g_wait = kSettlePairs;
    return;
  }
  restore_switches();
  g_row = -1;
  SaveJob* job = (SaveJob*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(SaveJob));
  if (!job) { drop_picture();  return; }
  SYSTEMTIME t;
  GetLocalTime(&t);
  log_fmt(job->name, (int)sizeof(job->name), "gbvr_picture_%04d%02d%02d-%02d%02d%02d.jpg", t.wYear, t.wMonth, t.wDay, t.wHour,
          t.wMinute, t.wSecond);
  job->rgb = g_pic; job->w = kPicW; job->h = g_picH;
  g_pic = nullptr;
  InterlockedExchange(&g_saving, 1);
  HANDLE th = CreateThread(nullptr, 0, save_thread, job, 0, nullptr);
  if (th) CloseHandle(th);
  else { InterlockedExchange(&g_saving, 0); HeapFree(GetProcessHeap(), 0, job->rgb); HeapFree(GetProcessHeap(), 0, job);  }
}

int shot_busy() { return g_row >= 0; }

#endif
