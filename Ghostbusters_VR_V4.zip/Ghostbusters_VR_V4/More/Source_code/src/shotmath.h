// 0.27 diagnostic picture: shrinking a part of an eye texture into a tile.
// Pure functions (tests/test_shot.cpp).
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace shot {

static const int kMaxTile = 1920;  // widest tile (the whole-frame band)

inline int ifloor(double v) { int i = (int)v; return (double)i > v ? i - 1 : i; }
inline int iceil(double v) { int i = (int)v; return (double)i < v ? i + 1 : i; }

// Integer source range [lo, hi) covered by output cell i of n over [a, b),
// at least one pixel, inside [0, limit).
inline void cell_range(double a, double b, int i, int n, int limit, int* lo, int* hi) {
  double s0 = a + (b - a) * (double)i / (double)n;
  double s1 = a + (b - a) * (double)(i + 1) / (double)n;
  int l = ifloor(s0 + 1e-9), h = iceil(s1 - 1e-9);
  if (h <= l) h = l + 1;
  if (l < 0) l = 0;
  if (h > limit) h = limit;
  if (l >= h) { l = h - 1; if (l < 0) { l = 0; h = limit > 0 ? 1 : 0; } }
  *lo = l; *hi = h;
}

// Averages the source rectangle [x0,x1) x [y0,y1) (source pixels) of a picture
// with 4 bytes per pixel into a tw x th tile of 3 bytes per pixel (R, G, B).
// bgr = 1: source bytes are B, G, R, x; 0: R, G, B, x.
// xr: caller's scratch array of 2 * tw ints.
inline void shrink(const uint8_t* src, int srcW, int srcH, int srcPitch, int bgr, double x0, double y0, double x1, double y1,
                   uint8_t* dst, int tw, int th, int dstStride, int* xr) {
  if (!src || !dst || srcW < 1 || srcH < 1 || tw < 1 || th < 1) return;
  for (int i = 0; i < tw; ++i) cell_range(x0, x1, i, tw, srcW, &xr[2 * i], &xr[2 * i + 1]);
  const int r = bgr ? 2 : 0, b = bgr ? 0 : 2;
  for (int j = 0; j < th; ++j) {
    int ylo, yhi;
    cell_range(y0, y1, j, th, srcH, &ylo, &yhi);
    uint8_t* out = dst + (size_t)j * (size_t)dstStride;
    for (int i = 0; i < tw; ++i) {
      int xlo = xr[2 * i], xhi = xr[2 * i + 1];
      uint32_t sr = 0, sg = 0, sb = 0, n = 0;
      for (int y = ylo; y < yhi; ++y) {
        const uint8_t* p = src + (size_t)y * (size_t)srcPitch + (size_t)xlo * 4;
        for (int x = xlo; x < xhi; ++x, p += 4) { sr += p[r]; sg += p[1]; sb += p[b]; }
        n += (uint32_t)(xhi - xlo);
      }
      if (!n) n = 1;
      out[i * 3] = (uint8_t)((sr + n / 2) / n);
      out[i * 3 + 1] = (uint8_t)((sg + n / 2) / n);
      out[i * 3 + 2] = (uint8_t)((sb + n / 2) / n);
    }
  }
}

// Tile height for an eye whose view is tanW wide and tanH tall (tangent
// units): same scale in both directions, so round things stay round.
inline int tile_height(int tileW, double tanW, double tanH, int maxH) {
  if (!(tanW > 0.1) || !(tanH > 0.1)) return maxH;
  int h = (int)((double)tileW * tanH / tanW + 0.5);
  if (h < 16) h = 16;
  if (h > maxH) h = maxH;
  return h;
}

}  // namespace shot
