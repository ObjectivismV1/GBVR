// 1.7.187 "same code" check (see sigtable.h): how many of the recorded 16-byte code samples differ in a loaded image. `readable` tells whether 16 bytes can be read there.
#pragma once
#include "sigtable.h"
namespace sigcheck {
typedef int (*Readable)(const void* p);
inline int misses(const uint8_t* base, Readable readable, int* first) {
  int miss = 0; if (first) *first = -1;
  for (int i = 0; i < sigtable::kCount; ++i) {
    const uint8_t* p = base + sigtable::kSamples[i].rva;
    int same = readable(p);
    if (same) for (int k = 0; k < 16; ++k) if (p[k] != sigtable::kSamples[i].b[k]) { same = 0; break; }
    if (!same) { ++miss; if (first && *first < 0) *first = i; }
  }
  return miss;
}
}  // namespace sigcheck
