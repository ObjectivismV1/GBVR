// 0.81 SOLID BODY: the avatar's torso is an upright elliptic column under the camera's eye; the gun (and the hands that hold it) are pushed out of it,
// so the gun and other equipment cannot pass through the body. Game world feet. forward = (sin yaw, 0, cos yaw), right = (cos yaw, 0, -sin yaw).
#pragma once
#include "vmath.h"
namespace solid {
static const double kBack = 0.25, kHalfW = 0.62, kHalfD = 0.42, kTop = 0.35, kBot = 2.6, kTaper = 0.30;   // feet at body scale 1
// P: a point (game world). eye: the camera eye, yaw: the way the torso faces, s: body scale, margin: extra feet around the column (the gun's thickness).
// Returns 1 and the push (delta, game world) when P is inside the column, else 0.
inline int push_out(const double* eye, double yaw, double s, const double* P, double margin, double* delta) {
  delta[0] = delta[1] = delta[2] = 0;
  if (!(s > 0.3 && s < 3.0)) s = 1.0;
  double sy, cy;
  vm::dsincos(yaw, &sy, &cy);
  const double fw[2] = {sy, cy}, rt[2] = {cy, -sy};
  const double top = eye[1] - kTop * s, bot = eye[1] - kBot * s;
  if (P[1] > top || P[1] < bot) return 0;
  double taper = 1.0;
  const double dt = top - P[1], db = P[1] - bot, ed = (dt < db ? dt : db) / (kTaper * s);   // 0 at the ends of the column, 1 well inside it
  if (ed < 1.0) taper = ed;
  const double cx = eye[0] - fw[0] * kBack * s, cz = eye[2] - fw[1] * kBack * s;
  const double dx = P[0] - cx, dz = P[2] - cz;
  const double u = dx * rt[0] + dz * rt[1], v = dx * fw[0] + dz * fw[1];
  const double a = kHalfW * s + margin, b = kHalfD * s + margin;
  const double q = (u / a) * (u / a) + (v / b) * (v / b);
  if (q >= 1.0) return 0;
  double u2, v2;
  if (q < 1e-6) { u2 = 0; v2 = b; }   // dead centre: out the front
  else { const double k = 1.0 / vm::dsqrt(q); u2 = u * k; v2 = v * k; }
  const double du = (u2 - u) * taper, dv = (v2 - v) * taper;
  delta[0] = du * rt[0] + dv * fw[0];
  delta[2] = du * rt[1] + dv * fw[1];
  return 1;
}
}  // namespace solid
