// 0.58 speed guard: which of the probe's own parts slows the game down? (pure logic, tests/test_speed.cpp)
// Every report window (about 1.3 s) the profile gives the time each part used per second. When the headset gets clearly
// fewer frame pairs than it should AND one part of the probe used a large share of every second for several windows in
// a row, that part is switched off for this run (the game goes on without it) and the log says so.
#pragma once
namespace speed {
enum Part { P_NONE = 0, P_MENU, P_BODY, P_ARMS, P_HUD, P_CTRL, P_COUNT };
struct Guard {
  static const int kWindows = 3;             // windows in a row
  static constexpr double kSlowPairs = 55.0; // pairs per second below this = slow (the headset runs at 72 or more)
  static constexpr double kHeavyMs = 60.0;   // ms of every second (6 %) used by one part
  int bad[P_COUNT];
  int fired[P_COUNT];
  inline void reset() { for (int i = 0; i < P_COUNT; ++i) bad[i] = fired[i] = 0; }
  // load[P_*] = ms used per second; returns the part to switch off (P_NONE = nothing). At most one per call.
  inline int update(const double* load, double pairsPerSec, int measured) {
    if (!measured || pairsPerSec >= kSlowPairs) { for (int i = 0; i < P_COUNT; ++i) bad[i] = 0; return P_NONE; }
    int worst = P_NONE;
    for (int i = 1; i < P_COUNT; ++i) {
      if (load[i] >= kHeavyMs) ++bad[i]; else bad[i] = 0;
      if (bad[i] >= kWindows && !fired[i] && (worst == P_NONE || load[i] > load[worst])) worst = i;
    }
    if (worst != P_NONE) fired[worst] = 1;
    return worst;
  }
};
inline const char* part_name(int p) {
  static const char* const n[P_COUNT] = {"none", "the in-VR menu", "the body follow", "the arms", "the HUD in front of you", "the controller reading"};
  return (p >= 0 && p < P_COUNT) ? n[p] : "?";
}
}  // namespace speed
