// 1.7.71 stairs (pure math, tested in tests/test_stairs.cpp).
//
// The eye hangs on the character's feet, which jump up or down at every stair. 1.7.69 eased the height (120 ms): every stair was
// still a small lift. The ramp follower turns a flight of stairs into a smooth slope: the feet height of the last ~0.35 s is fitted
// with a straight line (height against time) and the eye follows that line, so a steady climb moves the eye at a steady speed and
// standing still gives the feet height exactly. A light ease (ms) is kept on top; the eye is never more than 1 ft from the feet and
// a jump of more than 3 ft (teleport, fall, level change) snaps.
#pragma once

namespace stairs {

const int kN = 48;   // samples kept (about 0.5 s at 90 per second)

struct Ramp {
  double t[kN], y[kN];
  int n, head;
  double out;
  int have;
  double lastT;
  double recent[2]; int recentN;
};

inline void reset(Ramp& r) { r.n = 0; r.head = 0; r.have = 0; r.out = 0.0; r.lastT = 0.0; r.recentN = 0; r.recent[0] = r.recent[1] = 0.0; }

// feed one sample (time in seconds, feet height in ft); returns the eye's feet height to use
inline double step(Ramp& r, double t, double y, double windowS, double easeS) {
  if (!r.have || y - r.out > 3.0 || r.out - y > 3.0 || t < r.lastT || t - r.lastT > 0.5) {
    reset(r); r.have = 1; r.out = y; r.lastT = t;
    r.t[0] = t; r.y[0] = y; r.n = 1; r.head = 1; r.recent[0] = y; r.recentN = 1;
    return y;
  }
  // Remove small alternating floor-seam bob from the camera ramp only.
  double sample = y;
  if (r.recentN >= 2) {
    const double a = r.recent[0], b = r.recent[1];
    const double lo = a < b ? a : b, hi = a > b ? a : b;
    if (hi - lo <= 0.30 && y >= lo - 0.30 && y <= hi + 0.30)
      sample = (a + b + y) / 3.0;
  }
  if (r.recentN == 1) { r.recent[1] = y; r.recentN = 2; }
  else { r.recent[0] = r.recent[1]; r.recent[1] = y; }
  r.t[r.head] = t; r.y[r.head] = sample; r.head = (r.head + 1) % kN; if (r.n < kN) ++r.n;
  // least-squares line through the samples inside the window
  double st = 0, sy = 0, stt = 0, sty = 0; int m = 0; double ymin = y, ymax = y;
  for (int i = 0; i < r.n; ++i) {
    const double ti = r.t[i];
    if (t - ti > windowS) continue;
    if (r.y[i] < ymin) ymin = r.y[i]; if (r.y[i] > ymax) ymax = r.y[i];
    const double dt = ti - t;   // relative to now (keeps numbers small)
    st += dt; sy += r.y[i]; stt += dt * dt; sty += dt * r.y[i]; ++m;
  }
  double target = y;
  if (m >= 3) {
    const double den = m * stt - st * st;
    if (den > 1e-12) {
      const double slope = (m * sty - st * sy) / den;
      const double icpt = (sy - slope * st) / m;   // value at dt = 0 (now)
      target = icpt;
    } else target = sy / m;
  }
  // 1.7.193 stress test (floor transitions): after a single step of the floor (a curb, a threshold) the fitted line ran past the new height by about a fifth of the step and came back (a small bob of the whole view
  // model). The target never leaves the range of the feet heights in the window, so a step is followed without overshoot; a steady climb is unaffected (its line stays inside the samples).
  if (target > ymax) target = ymax; if (target < ymin) target = ymin;
  const double dt = t - r.lastT; r.lastT = t;
  if (easeS > 0.001 && dt > 0.0) r.out += (target - r.out) * (dt / (easeS + dt));
  else r.out = target;
  if (y - r.out > 1.0) r.out = y - 1.0;
  if (r.out - y > 1.0) r.out = y + 1.0;
  return r.out;
}

// the speed boost's extra step on stairs: the game's own step climbed dy (ft) over md (ft along the floor). The extra step
// (len ft along the floor) gets the same climb, plus a small lift, so it lands on the stair instead of inside its riser.
// Only for going up; 0 when it is flat or going down.
inline double lift_for(double dy, double md, double len) {
  if (!(md > 1e-4) || !(len > 0.0) || !(dy > 0.01)) return 0.0;
  double slope = dy / md;
  if (slope < 0.15) return 0.0;
  if (slope > 1.5) slope = 1.5;
  double l = len * slope + 0.02;
  if (l > 0.6) l = 0.6;
  return l;
}

}  // namespace stairs
