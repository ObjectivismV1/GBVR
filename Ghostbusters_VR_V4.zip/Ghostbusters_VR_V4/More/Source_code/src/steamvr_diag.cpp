// 0.67 SteamVR health check. Everything here only READS (processes, a few SteamVR text files) and writes lines to the probe log.
// It runs on the VR start worker thread (vr_openvr.c), never on the render thread, and never changes any SteamVR setting.
//
// Why: the 0.66 run ended with "VR init failed (scene), error 1114" (VRInitError_VendorSpecific_OculusRuntimeBadInstall) and SteamVR
// itself said an add-on was blocked. Error 1114 is raised by SteamVR's own Oculus add-on, not by this probe, but the log could not say
// WHICH add-on was blocked or why. These lines answer that: SteamVR's settings file (blocked_by_safe_mode / enable flags), the add-on
// folder list, which VR programs are running, and the matching lines of SteamVR's own logs. Text handling: steamvrmath.h (tested).
//
// Freestanding like the rest of the probe: only kernel32 calls (plus version.dll looked up at run time by sysinfo.cpp).
#include "gbvr.h"
#include "vr_pose.h"

#if GBVR_HEADTRACK
#include <tlhelp32.h>
#include "steamvrmath.h"

namespace {

enum { kBuf = 262144 };
char g_buf[kBuf + 4];          // one reader at a time (the start worker thread)

bool starts_ci(const wchar_t* s, const wchar_t* prefix) {
  const int m = lstrlenW(prefix);
  if (lstrlenW(s) < m) return false;
  return CompareStringOrdinal(s, m, prefix, m, TRUE) == CSTR_EQUAL;
}

int to_utf8(const wchar_t* w, char* out, int n) {
  if (n <= 0) return 0;
  const int r = WideCharToMultiByte(CP_UTF8, 0, w, -1, out, n, nullptr, nullptr);
  if (r <= 0) { out[0] = 0; return 0; }
  return r - 1;
}

int to_wide(const char* s, wchar_t* out, int n) {
  if (n <= 0) return 0;
  const int r = MultiByteToWideChar(CP_UTF8, 0, s, -1, out, n);
  if (r <= 0) { out[0] = 0; return 0; }
  return r - 1;
}

// Reads up to kBuf bytes: the start of the file (tail 0) or its end (tail 1). Returns the byte count, or -1 if it cannot be opened.
// g_buf is NUL-terminated. *sizeOut = whole file size, *ageSec = seconds since it was last written (-1 unknown).
int read_file(const wchar_t* path, int tail, long long* sizeOut, long long* ageSec) {
  g_buf[0] = 0;
  if (sizeOut) *sizeOut = 0;
  if (ageSec) *ageSec = -1;
  HANDLE h = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (h == INVALID_HANDLE_VALUE) return -1;
  LARGE_INTEGER sz; sz.QuadPart = 0;
  GetFileSizeEx(h, &sz);
  if (sizeOut) *sizeOut = sz.QuadPart;
  FILETIME wt;
  if (ageSec && GetFileTime(h, nullptr, nullptr, &wt)) {
    FILETIME nowFt; GetSystemTimeAsFileTime(&nowFt);
    const unsigned long long a = ((unsigned long long)wt.dwHighDateTime << 32) | wt.dwLowDateTime;
    const unsigned long long b = ((unsigned long long)nowFt.dwHighDateTime << 32) | nowFt.dwLowDateTime;
    *ageSec = b > a ? (long long)((b - a) / 10000000ULL) : 0;
  }
  LARGE_INTEGER p; p.QuadPart = (tail && sz.QuadPart > kBuf) ? sz.QuadPart - kBuf : 0;
  SetFilePointerEx(h, p, nullptr, FILE_BEGIN);
  DWORD got = 0;
  if (!ReadFile(h, g_buf, kBuf, &got, nullptr)) got = 0;
  CloseHandle(h);
  g_buf[got] = 0;
  return (int)got;
}

bool file_exists(const wchar_t* path) { return GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES; }

struct ProcInfo {
  int vrserver, vrcompositor, vrmonitor, vrstartup, vrdashboard, vrwebhelper, steam, ovrserver, oculusclient, vdesktop;
  char others[220];
};

void add_other(ProcInfo* pi, const wchar_t* name) {
  char nb[80];
  to_utf8(name, nb, sizeof(nb));
  const int have = lstrlenA(pi->others);
  if (have + lstrlenA(nb) + 2 >= (int)sizeof(pi->others)) return;
  if (have) lstrcatA(pi->others, " ");
  lstrcatA(pi->others, nb);
}

void scan_processes(ProcInfo* pi) {
  ZeroMemory(pi, sizeof(*pi));
  HANDLE s = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if (s == INVALID_HANDLE_VALUE) return;
  PROCESSENTRY32W e;
  ZeroMemory(&e, sizeof(e));
  e.dwSize = sizeof(e);
  if (Process32FirstW(s, &e)) {
    do {
      const wchar_t* n = e.szExeFile;
      if (!lstrcmpiW(n, L"vrserver.exe")) pi->vrserver++;
      else if (!lstrcmpiW(n, L"vrcompositor.exe")) pi->vrcompositor++;
      else if (!lstrcmpiW(n, L"vrmonitor.exe")) pi->vrmonitor++;
      else if (!lstrcmpiW(n, L"vrstartup.exe")) pi->vrstartup++;
      else if (!lstrcmpiW(n, L"vrdashboard.exe")) pi->vrdashboard++;
      else if (!lstrcmpiW(n, L"vrwebhelper.exe")) pi->vrwebhelper++;
      else if (!lstrcmpiW(n, L"steam.exe")) pi->steam++;
      else if (!lstrcmpiW(n, L"OVRServer_x64.exe")) pi->ovrserver++;
      else if (!lstrcmpiW(n, L"OculusClient.exe")) pi->oculusclient++;
      else if (starts_ci(n, L"VirtualDesktop")) { pi->vdesktop++; add_other(pi, n); }
      else if (starts_ci(n, L"OVR") || starts_ci(n, L"Oculus") || starts_ci(n, L"ALVR") || starts_ci(n, L"Revive") ||
               starts_ci(n, L"OpenXR") || starts_ci(n, L"vrchat") || starts_ci(n, L"OpenComposite") || starts_ci(n, L"XRSDK")) add_other(pi, n);
    } while (Process32NextW(s, &e));
  }
  CloseHandle(s);
}

void log_processes(const char* when, ProcInfo* pi) {
  scan_processes(pi);
  log_line("STEAMVR processes (%s): vrserver=%d vrcompositor=%d vrmonitor=%d vrstartup=%d vrdashboard=%d vrwebhelper=%d steam=%d | OVRServer=%d OculusClient=%d | VirtualDesktop=%d | other VR software: %s",
           when, pi->vrserver, pi->vrcompositor, pi->vrmonitor, pi->vrstartup, pi->vrdashboard, pi->vrwebhelper, pi->steam,
           pi->ovrserver, pi->oculusclient, pi->vdesktop, pi->others[0] ? pi->others : "(none)");
}

struct Paths {
  wchar_t runtime[MAX_PATH], config[MAX_PATH], logs[MAX_PATH];
  int have;
};

// %LOCALAPPDATA%\openvr\openvrpaths.vrpath names the SteamVR runtime, config and log folders.
void find_paths(Paths* ps) {
  ZeroMemory(ps, sizeof(*ps));
  wchar_t f[MAX_PATH];
  if (!ExpandEnvironmentStringsW(L"%LOCALAPPDATA%\\openvr\\openvrpaths.vrpath", f, MAX_PATH)) return;
  long long sz = 0;
  if (read_file(f, 0, &sz, nullptr) <= 0) { log_line("STEAMVR openvrpaths.vrpath not readable (SteamVR never started on this account, or it is somewhere else)"); return; }
  char rt[300], cf[300], lg[300];
  svr::json_first_string(g_buf, "runtime", rt, sizeof(rt));
  svr::json_first_string(g_buf, "config", cf, sizeof(cf));
  svr::json_first_string(g_buf, "log", lg, sizeof(lg));
  to_wide(rt, ps->runtime, MAX_PATH);
  to_wide(cf, ps->config, MAX_PATH);
  to_wide(lg, ps->logs, MAX_PATH);
  ps->have = 1;
  log_line("STEAMVR paths: runtime=\"%s\" config=\"%s\" log=\"%s\"", rt, cf, lg);
}

void log_versions(const Paths* ps, const wchar_t* ourDll) {
  char a[80] = "?", b[80] = "?", c[80] = "?", p[MAX_PATH * 2];
  if (ps->have && ps->runtime[0]) {
    wchar_t w[MAX_PATH * 2];
    wsprintfW(w, L"%ls\\bin\\win64\\vrserver.exe", ps->runtime);
    to_utf8(w, p, sizeof(p)); sysinfo_file_version(p, a, sizeof(a));
    wsprintfW(w, L"%ls\\bin\\win64\\vrclient_x64.dll", ps->runtime);
    to_utf8(w, p, sizeof(p)); sysinfo_file_version(p, b, sizeof(b));
  }
  if (ourDll && ourDll[0]) { to_utf8(ourDll, p, sizeof(p)); sysinfo_file_version(p, c, sizeof(c)); }
  log_line("STEAMVR versions: vrserver.exe=%s vrclient_x64.dll=%s openvr_api.dll(ours, SDK 2.15.6)=%s", a, b, c);
}

// The add-on (driver) folders of the runtime, and whether an Oculus runtime is installed on this PC.
void log_addons(const Paths* ps) {
  if (ps->have && ps->runtime[0]) {
    wchar_t pat[MAX_PATH * 2];
    wsprintfW(pat, L"%ls\\drivers\\*", ps->runtime);
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(pat, &fd);
    char names[600]; names[0] = 0;
    int count = 0;
    if (h != INVALID_HANDLE_VALUE) {
      do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        if (fd.cFileName[0] == L'.') continue;
        char nb[80]; to_utf8(fd.cFileName, nb, sizeof(nb));
        ++count;
        if (lstrlenA(names) + lstrlenA(nb) + 2 < (int)sizeof(names)) { if (names[0]) lstrcatA(names, " "); lstrcatA(names, nb); }
      } while (FindNextFileW(h, &fd));
      FindClose(h);
    }
    log_line("STEAMVR add-on folders in SteamVR\\drivers (%d): %s", count, names[0] ? names : "(none found)");
  }
  wchar_t w[MAX_PATH * 2];
  int rtDir = 0, srv = 0, dll = 0;
  if (ExpandEnvironmentStringsW(L"%ProgramFiles%\\Oculus\\Support\\oculus-runtime", w, MAX_PATH)) {
    rtDir = file_exists(w);
    wchar_t q[MAX_PATH * 2];
    wsprintfW(q, L"%ls\\OVRServer_x64.exe", w); srv = file_exists(q);
    wsprintfW(q, L"%ls\\LibOVRRT64_1.dll", w); dll = file_exists(q);
  }
  log_line("STEAMVR Oculus software on this PC: oculus-runtime folder=%d OVRServer_x64.exe=%d LibOVRRT64_1.dll=%d (error 1114 comes from SteamVR's Oculus add-on looking for this)", rtDir, srv, dll);
}

void settings_sink(void*, const char* section, const char* line) { log_line("STEAMVRSET [%s] %s", section, line); }

// steamvr.vrsettings: which add-ons are switched off / blocked by safe mode, and the settings that choose the headset driver.
void scan_vrsettings(const Paths* ps) {
  if (!ps->have || !ps->config[0]) return;
  wchar_t f[MAX_PATH * 2];
  wsprintfW(f, L"%ls\\steamvr.vrsettings", ps->config);
  long long sz = 0, age = -1;
  const int got = read_file(f, 0, &sz, &age);
  if (got < 0) { log_line("STEAMVR steamvr.vrsettings not readable"); return; }
  log_line("STEAMVR steamvr.vrsettings: %d bytes, changed %d s ago", (int)sz, (int)age);
  svr::SettingsSummary sum;
  svr::scan_vrsettings(g_buf, got, 60, settings_sink, nullptr, &sum);
  log_line("STEAMVRSET summary: blockedBySafeMode=%d switchedOff=%d sections=%d | add-on settings sections: %s",
           sum.blocked, sum.off, sum.sectionCount, sum.driverSections[0] ? sum.driverSections : "(none)");
  if (sum.blocked > 0) log_line("STEAMVR NOTE: SteamVR has put add-ons in safe mode (blocked_by_safe_mode=true). That is SteamVR's crash protection, not this probe: turn them back on in SteamVR > Settings > Startup / Shutdown > Manage Add-Ons.");
}

// The newest matching lines of one SteamVR log (block / crash / error / Oculus / driver failures), with how old the file is.
void log_filtered_tail(const Paths* ps, const wchar_t* name, const char* tag, int maxLines) {
  if (!ps->have || !ps->logs[0]) return;
  wchar_t f[MAX_PATH * 2];
  wsprintfW(f, L"%ls\\%ls", ps->logs, name);
  long long sz = 0, age = -1;
  const int got = read_file(f, 1, &sz, &age);
  if (got < 0) { log_line("STEAMVRLOG %s: file not found", tag); return; }
  svr::Match keep[40];
  if (maxLines > 40) maxLines = 40;
  int kept = 0;
  const int total = svr::collect_matches(g_buf, got, svr::kLogWords, keep, maxLines, &kept);
  log_line("STEAMVRLOG %s: %d bytes, changed %d s ago, %d matching lines (newest %d shown)", tag, (int)sz, (int)age, total, kept);
  for (int i = 0; i < kept; ++i) {
    char cl[230];
    svr::clean_line(cl, keep[i].start, keep[i].len, (int)sizeof(cl));
    log_line("STEAMVRLOG %s: %s", tag, cl);
  }
}

}  // namespace

extern "C" {

void steamvr_diag_before(const char* mode, int hmdPresent, int runtimeInstalled, const char* runtimePath, const wchar_t* ourDll) {
  log_line("STEAMVR check before start: mode=%s VR_IsHmdPresent=%d VR_IsRuntimeInstalled=%d runtimePath=\"%s\"",
           mode, hmdPresent, runtimeInstalled, runtimePath && runtimePath[0] ? runtimePath : "?");
  ProcInfo pi;
  log_processes("before", &pi);
  if (!pi.vrserver) log_line("STEAMVR NOTE: vrserver.exe is not running, so the game itself will have to start SteamVR. Starting SteamVR from Virtual Desktop first (and waiting for SteamVR home) is safer.");
  Paths ps;
  find_paths(&ps);
  log_versions(&ps, ourDll);
  log_addons(&ps);
  scan_vrsettings(&ps);
  log_filtered_tail(&ps, L"vrserver.txt", "vrserver.txt (before)", 12);
  log_filtered_tail(&ps, L"vrstartup.txt", "vrstartup.txt (before)", 6);
}

void steamvr_diag_attempt(int attempt, int maxAttempts, int err, const char* symbol, const char* english, int elapsedMs) {
  if (err == 0) log_line("STEAMVR init attempt %d/%d: connected after %d ms", attempt, maxAttempts, elapsedMs);
  else log_line("STEAMVR init attempt %d/%d: error %d %s (\"%s\") after %d ms%s", attempt, maxAttempts, err, symbol ? symbol : "?", english ? english : "?",
                elapsedMs, attempt < maxAttempts && svr::retryable(err) ? " - trying again in a few seconds" : "");
}

void steamvr_diag_failed(int err, const char* symbol, const char* english, const wchar_t* ourDll) {
  (void)ourDll;
  log_line("STEAMVR init FAILED: error %d %s (\"%s\")", err, symbol ? symbol : "?", english ? english : "?");
  log_line("STEAMVR hint: %s", svr::hint_long(err));
  ProcInfo pi;
  log_processes("after failure", &pi);
  Paths ps;
  find_paths(&ps);
  scan_vrsettings(&ps);
  log_filtered_tail(&ps, L"vrserver.txt", "vrserver.txt", 30);
  log_filtered_tail(&ps, L"vrstartup.txt", "vrstartup.txt", 10);
  log_filtered_tail(&ps, L"vrcompositor.txt", "vrcompositor.txt", 10);
  log_filtered_tail(&ps, L"vrclient_ghost.txt", "vrclient_ghost.txt", 15);
}

int steamvr_diag_retryable(int err) { return svr::retryable(err); }
int steamvr_diag_max_attempts(int err) { return svr::max_attempts(err); }
const char* steamvr_diag_hint_short(int err) { return svr::hint_short(err); }
const char* steamvr_diag_hint_long(int err) { return svr::hint_long(err); }

}  // extern "C"

#endif  // GBVR_HEADTRACK
