// 0.67 the text handling of the SteamVR health check (steamvr_diag.cpp), kept free of Windows calls so tests/test_steamvr.cpp can run it.
#pragma once
#include <stddef.h>

namespace svr {

inline int slen(const char* s) { int n = 0; while (s[n]) ++n; return n; }
inline char lc(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }

// does [s, s+n) contain needle (ASCII, ignoring case)?
inline bool ci_has(const char* s, int n, const char* needle) {
  const int m = slen(needle);
  if (m <= 0) return true;
  for (int i = 0; i + m <= n; ++i) {
    int j = 0;
    while (j < m && lc(s[i + j]) == lc(needle[j])) ++j;
    if (j == m) return true;
  }
  return false;
}

// printable single-line copy of [s, s+n), leading blanks dropped, at most max-1 characters
inline void clean_line(char* dst, const char* s, int n, int max) {
  int k = 0;
  while (n > 0 && (*s == ' ' || *s == '\t')) { ++s; --n; }
  for (int i = 0; i < n && k < max - 1; ++i) {
    const unsigned char c = (unsigned char)s[i];
    if (c == '\r' || c == '\n') break;
    dst[k++] = (c < 0x20) ? ' ' : (char)c;
  }
  dst[k] = 0;
}

// First string of the array (or the plain string) after "key" in a small JSON text; '\\' and '\"' unescaped, '/' turned into '\'.
inline bool json_first_string(const char* text, const char* key, char* out, int n) {
  out[0] = 0;
  char pat[64];
  const int kl = slen(key);
  if (kl > 60 || n < 2) return false;
  pat[0] = '"';
  for (int i = 0; i < kl; ++i) pat[1 + i] = key[i];
  pat[1 + kl] = '"'; pat[2 + kl] = 0;
  const int pl = kl + 2;
  const char* p = text;
  for (; *p; ++p) {
    int j = 0;
    while (j < pl && p[j] == pat[j]) ++j;
    if (j == pl) break;
  }
  if (!*p) return false;
  p += pl;
  while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
  if (*p != ':') return false;
  ++p;
  while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
  if (*p == '[') { ++p; while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p; }
  if (*p != '"') return false;     // null, a number, an empty array ...
  ++p;
  int k = 0;
  while (*p && *p != '"' && k < n - 1) {
    char c = *p++;
    if (c == '\\' && *p) { c = *p++; if (c == 'n' || c == 't') c = ' '; }
    out[k++] = (c == '/') ? '\\' : c;
  }
  out[k] = 0;
  return k > 0;
}

// ---- steamvr.vrsettings -------------------------------------------------------------------------------------------------------
// SteamVR writes the file with three spaces per level:   "driver_xxx" : {   at three spaces opens a section.
// Reported: lines about safe mode / "enable" / the driver choice. The sink gets (section, trimmed line).
struct SettingsSummary { int blocked, off, shown, sectionCount; char driverSections[500]; };
typedef void (*LineSink)(void* ctx, const char* section, const char* line);

inline void scan_vrsettings(const char* buf, int n, int maxShown, LineSink sink, void* ctx, SettingsSummary* sum) {
  sum->blocked = sum->off = sum->shown = sum->sectionCount = 0;
  sum->driverSections[0] = 0;
  char section[80] = "";
  const char* p = buf;
  const char* end = buf + n;
  while (p < end) {
    const char* ls = p;
    while (p < end && *p != '\n') ++p;
    const int len = (int)(p - ls);
    if (p < end) ++p;
    int lead = 0;
    while (lead < len && ls[lead] == ' ') ++lead;
    if (lead == 3 && len > 6 && ls[lead] == '"') {
      const char* q = ls + lead + 1;
      int k = 0;
      while (q < ls + len && *q != '"' && k < (int)sizeof(section) - 1) section[k++] = *q++;
      section[k] = 0;
      ++sum->sectionCount;
      if (ci_has(section, k, "driver")) {
        const int have = slen(sum->driverSections);
        if (have + k + 2 < (int)sizeof(sum->driverSections)) {
          if (have) sum->driverSections[have] = ' ';
          const int at = have ? have + 1 : 0;
          for (int i = 0; i <= k; ++i) sum->driverSections[at + i] = section[i];
        }
      }
      continue;
    }
    const bool isBlocked = ci_has(ls, len, "blocked_by_safe_mode") || ci_has(ls, len, "safemode") || ci_has(ls, len, "safe_mode");
    const bool isEnable = ci_has(ls, len, "\"enable\"");
    const bool isChoice = ci_has(ls, len, "forcedDriver") || ci_has(ls, len, "forcedHmd") || ci_has(ls, len, "requireHmd") ||
                          ci_has(ls, len, "activateMultipleDrivers");
    if (!(isBlocked || isEnable || isChoice)) continue;
    if (isBlocked && ci_has(ls, len, "true")) ++sum->blocked;
    if (isEnable && ci_has(ls, len, "false")) ++sum->off;
    if (sum->shown < maxShown) {
      char cl[230];
      clean_line(cl, ls, len, (int)sizeof(cl));
      sink(ctx, section, cl);
      ++sum->shown;
    }
  }
}

// ---- SteamVR text logs ----------------------------------------------------------------------------------------------------------
struct Match { const char* start; int len; };
static const char* const kLogWords[] = { "block", "safe mode", "safemode", "crash", "exception", "oculus", "fail", "error", "disabled",
                                         "unable", "cannot", "could not", "not found", "bad install", "virtual desktop", "driver_", nullptr };

// The newest maxKeep lines of [buf, buf+n) that contain one of the words. Returns the number of matching lines in all.
inline int collect_matches(const char* buf, int n, const char* const* words, Match* keep, int maxKeep, int* keptOut) {
  int total = 0, kept = 0;
  const char* p = buf;
  const char* end = buf + n;
  while (p < end) {
    const char* ls = p;
    while (p < end && *p != '\n') ++p;
    const int len = (int)(p - ls);
    if (p < end) ++p;
    bool hit = false;
    for (int w = 0; words[w] && !hit; ++w) hit = ci_has(ls, len, words[w]);
    if (!hit) continue;
    ++total;
    if (kept < maxKeep) keep[kept++] = Match{ ls, len };
    else { for (int i = 1; i < maxKeep; ++i) keep[i - 1] = keep[i]; keep[maxKeep - 1] = Match{ ls, len }; }
  }
  *keptOut = kept;
  return total;
}

// ---- what to do about an init error ----------------------------------------------------------------------------------------------------
// Errors where waiting a few seconds and asking again can help (SteamVR still starting or closing); not for a broken install.
inline int retryable(int err) {
  if (err >= 100 && err <= 107) return 0;     // install / files / interfaces
  if (err >= 110 && err <= 114) return 0;     // path registry / config / log folders
  if (err == 130 || err == 168) return 0;     // wrong application type / installation too old
  return 1;
}
inline int max_attempts(int err) { return (err >= 1000 && err < 1200) ? 2 : 3; }   // Oculus add-on problems rarely change in 4 s

inline const char* hint_short(int err) {
  if (err >= 1000 && err < 1200) return "SteamVR's Oculus add-on failed; check SteamVR Manage Add-Ons";
  if (err >= 100 && err <= 107) return "SteamVR install problem; repair SteamVR in Steam";
  if (err == 108 || err == 126) return "SteamVR sees no headset; connect Virtual Desktop first";
  if (err == 121) return "SteamVR is not running";
  if (err == 115 || err == 117 || err == 119 || err == 143) return "SteamVR is busy starting or closing; wait and press F4 again";
  if (err >= 200 && err < 300) return "a SteamVR driver add-on failed; check Manage Add-Ons";
  if (err >= 300 && err < 400) return "SteamVR is busy or closing; wait and press F4 again";
  if (err >= 400 && err < 500) return "SteamVR compositor failed (graphics); restart SteamVR";
  return "see the STEAMVR lines in this log";
}

inline const char* hint_long(int err) {
  if (err >= 1000 && err < 1200)
    return "Codes 1000-1199 are Oculus errors raised inside SteamVR (its Oculus support), not by this probe. With Virtual Desktop the Oculus add-on is not needed: start SteamVR from Virtual Desktop, then in SteamVR > Settings > Startup / Shutdown > Manage Add-Ons switch the Oculus add-on OFF and any add-on that is blocked (safe mode) back ON, restart SteamVR, and press F4 again.";
  if (err == 108 || err == 126)
    return "SteamVR is running but has no headset. Connect Virtual Desktop to this PC first, wait until SteamVR home shows in the headset, then press F4.";
  if (err == 121)
    return "SteamVR was not running. Start it from Virtual Desktop and wait for SteamVR home before pressing F4.";
  if (err >= 300 && err < 400)
    return "SteamVR's compositor was busy or closing. Wait until SteamVR home is fully loaded in the headset, then press F4.";
  if (err >= 200 && err < 300)
    return "A SteamVR headset driver add-on failed to start. Check SteamVR > Settings > Startup / Shutdown > Manage Add-Ons for blocked add-ons.";
  if (err >= 400 && err < 500)
    return "The SteamVR compositor could not start (graphics). Restart SteamVR; if it repeats, update the graphics driver.";
  if (err >= 100 && err <= 107)
    return "SteamVR files are missing or damaged. In Steam, right-click SteamVR > Properties > Installed Files > Verify integrity.";
  return "See the STEAMVR and STEAMVRLOG lines above; they show what SteamVR itself reported.";
}

}  // namespace svr
