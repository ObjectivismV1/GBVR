// 0.21 alternate-eye stereo, render-thread side (runs inside the game's
// Present hook) plus the two small locked records shared with the camera
// thread.
//
// Per presented frame:
//   before Present:  if the camera thread marked this frame as an eye picture,
//                    copy the back buffer into that eye's texture and submit
//                    both eye textures to the SteamVR compositor (the other
//                    eye's picture is one frame older; each is submitted with
//                    the headset pose it was rendered for, so the compositor
//                    can correct the difference).
//                    Otherwise (menus, loading, videos, any suspended gate)
//                    the frame is shown on a flat screen floating in front of
//                    the player.
//   after Present:   WaitGetPoses - waits for the headset's next frame slot and
//                    returns the predicted head pose for it, which is published
//                    for the camera thread's next prepare.
// Nothing here touches the game's D3D pipeline state: only CopyResource /
// ResolveSubresource from the back buffer into textures owned by the probe.
#include "ratemath.h"
#include "gbvr.h"
static int64_t g_flowEpisodeQ; static LONG g_flowEpisodeN;   // 1.7.85: INPUTFLOW pacing while one flat screen stays up
#include "ratecap.h"
#include "vmath.h"
#include "headmath.h"
#include "stereomath.h"
#include "picturemath.h"
#include "glowmath.h"
#include "layout.h"
#include "envmath.h"
#include "safetymath.h"
#include <d3d11.h>
#include <dxgi1_4.h>

// ---- Shared with the camera thread -------------------------------------------------
static SRWLOCK g_lock = SRWLOCK_INIT;
static StereoParams g_params;
static StereoFrame g_frame;
static uint32_t g_frameSeq;
static volatile LONG g_consumedSeq;   // last frame sequence the render thread has taken
static volatile LONG g_comfortTransition;
void stereo_comfort_transition() { InterlockedExchange(&g_comfortTransition, 1); }
// 1.7.182 THE WALL BEFORE THE ROOF SPOT: when the Stay Puft roof fight starts the mod needs about 1.4 s to find where to put you (the log: fight at 35.29 s, station at 36.7 s) and the game's own
// camera shows a wall meanwhile. The picture now goes black as the fight starts and stays black until you are placed (or 2 s at most), then fades up as for any other jump.
static volatile LONG g_comfortHold; static volatile int64_t g_comfortHoldQ;
void stereo_comfort_hold(int on) { if (on) { if (!InterlockedExchange(&g_comfortHold, 1)) g_comfortHoldQ = qpc_now(); InterlockedExchange(&g_comfortTransition, 1); } else InterlockedExchange(&g_comfortHold, 0); }

int stereo_get_params(StereoParams* out) {
  AcquireSRWLockShared(&g_lock);
  *out = g_params;
  ReleaseSRWLockShared(&g_lock);
  return out->valid;
}

// The game prepares a frame on one thread and presents it on another
// (0.21 log: different thread ids), but strictly one after the other: the
// preparing thread waits until the previous frame's Present has finished
// (render command queue drain at 0x3DDAC0; pose age at prepare was 0 ms on
// every sample). This check counts any frame where that does not hold: a new
// frame being prepared while the previous eye picture is still unpresented.
int stereo_frame_pending() {
  AcquireSRWLockShared(&g_lock);
  int pending = (LONG)g_frameSeq != g_consumedSeq;
  ReleaseSRWLockShared(&g_lock);
  return pending;
}

// 0.29: during the game's own drawing of a frame (render job, before its
// Present): is this frame an eye picture, and for which eye? The job for frame
// N always runs after the prepare that published N and before the Present that
// consumes it, so an unconsumed frame is the one being drawn.
int stereo_drawing_eye(int* eye, float* tanH, float* tanV, float* eyeXm, float* limW, float* limH) {
  if (!g_ctl.stereoActive) return 0;
  AcquireSRWLockShared(&g_lock);
  StereoFrame f = g_frame;
  LONG consumed = g_consumedSeq;
  int valid = g_params.valid;
  float ex0 = g_params.eyeX[0], ex1 = g_params.eyeX[1];
  // smallest half-view over both eyes: what an overlay centred on each eye's axis can use
  float w = 1e9f, h = 1e9f;
  for (int e = 0; e < 2; ++e) {
    float in[2] = {-g_params.left[e], g_params.right[e]}, ud[2] = {g_params.bottom[e], -g_params.top[e]};
    for (float v : in) if (v < w) w = v;
    for (float v : ud) if (v < h) h = v;
  }
  ReleaseSRWLockShared(&g_lock);
  *limW = w; *limH = h;
  if (!valid || f.seq == 0 || (LONG)f.seq == consumed) return 0;
  if (f.spec) return 0;   // 1.7.38: the chest-camera picture has no eye to draw overlays for
  *eye = f.eye & 1;
  *tanH = f.tanH;
  *tanV = f.tanV;
  *eyeXm = *eye ? ex1 : ex0;
  return 1;
}

void stereo_publish_frame(const StereoFrame* f) {
  AcquireSRWLockExclusive(&g_lock);
  g_frame = *f;
  g_frame.seq = ++g_frameSeq;
  ReleaseSRWLockExclusive(&g_lock);
}

// ---- Render-thread state --------------------------------------------------------
static const int kFlatAfter = 12;          // frames without an eye picture before the flat screen appears
static const float kScreenWidthM = 4.2f;  // flat screen at 100 %: 4.2 m wide, 2.8 m away (0.80: a cinema, 3.6 wide; 1.1: a little bigger so all of it is easy to see)
static const float kScreenMaxHeightM = 2.4f;  // ... but never taller than this (0.26: pictures that are not 16:9; 1.1: 2.4 m, the 4:3 game picture is then 3.2 m wide)
static const double kScreenDistanceM = 2.8, kScreenDropM = 0.10;
static const double kScreenTurnDeg = 55.0, kScreenTurnSecs = 1.4;   // 0.80: looking this far away from the screen for this long brings it back in front of you
static double g_flatYaw, g_flatAwayStart;
static int64_t g_flatStartQ;                      // 1.1: when this flat screen appeared (it fades in)
static double g_placedDist = -1, g_placedDrop = -1;   // 1.1: the distance / drop it was placed with (a change in the menu places it again)
static struct { float widthM, heightM, distM, dropM, curve, fade, hDeg, vDeg; int looks, replaced; } g_look;   // 1.1: the last look of the flat screen (for the log)
static const double kScreenFadeSecs = 0.45;
static struct { int shown, recentered, placements; double secs; int64_t firstQ; int voidCalls, gridLogs; float gridAlphaMax, gridAlphaLast;
                LONG blackOK, blackFail, blackSwitches; int blackLogs; long frozenGeomLogs; } g_fl;   // 0.98: black frames kept flowing to the headset while the flat screen is up
// 1.3: fade up from black when the 3D picture takes over from a 2D screen (or shows the first time), the ring cursor on the 2D screen, the dim behind the VR menu
static struct { int state; uint32_t tick; int64_t startQ; int firstDone; LONG begun, cleared, forced; int logs; int lastMs; } g_fi;   // state: 0 idle, 1 black asked, 2 fading up
static struct { LONG cursorDraws, cursorNone, cursorHidden, dimFrames; } g_cu;
static float g_dimNow = 1.0f;
static int64_t g_dimQ;
static float g_screenXf[12];                  // 0.95: where the flat screen was placed (the TV glow sits behind it) ...
static int g_haveScreenXf, g_voidApplied = -1;   // ... and whether the black void (grid room faded out) is in force: -1 not yet this time, 0 off, 1 on

static ID3D11Device* g_dev;
static void gpu_match_check();   // 1.7.87
static ID3D11DeviceContext* g_ctx;
static ID3D11Texture2D* g_eyeTex[2];
static ID3D11Texture2D* g_flatTex;
static ID3D11Texture2D* g_specTex;            // 1.7.38: the chest-camera picture for the PC window (made when the option is on)
static int g_haveSpec, g_specNow, g_specCtr;   // ... and whether it has a picture / this Present is the chest camera's / eye pairs since the last one
static uint32_t g_specTick;
static float g_specTan[2];
static struct { long asked, taken, shown, noTex, texLogs; double gapSum, gapMax; int64_t lastQ; } g_sp;
static ID3D11Texture2D* g_blackTex;           // 0.98: a small all-black picture, handed to the headset as the 3D scene while the flat 2D screen is up (so SteamVR Home never comes back)
static int g_blackSubmitting;                 // ... and whether black frames are what the headset has last been given
static void* g_texSwapChain;
static UINT g_texW, g_texH, g_bbSamples;
static DXGI_FORMAT g_texFmt;
static int g_gamma;

static StereoParams g_rp;                 // render thread's copy of the eye data
static int g_haveEye[2];
static uint32_t g_monTick, g_eyeTick[2];   // 1.2: real frames so far / the frame each eye picture was taken in (the monitor view's staleness log)
static float g_eyePose[2][12], g_eyeBounds[2][4];
static float g_monitorProjection[2][3];
static int g_boundsInside[2];
static float g_lastTanH, g_lastTanV;
static uint32_t g_lastSeq;
static int g_flatRun, g_stereoRun, g_flatMode, g_flatPlaced;
static float g_lastPose[12];
static int g_haveLastPose;
static int g_threadsLogged;
static int g_stopLogged;
static int g_sceneRequested;              // this F4 asked for the session (a failure is then ours to report)
static int g_didFrame;                    // this Present was handled (so the frame wait follows it)
// 0.24 eye pairs (see engine_hooks.cpp): frame 1 = left eye, frame 2 = right
// eye, both submitted together, then one compositor frame wait.
static int g_freshEye[2];                 // eye pictures rendered since the last submit
static int g_lastFresh, g_submittedNow, g_skippedWaitLast;
static int64_t g_firstEyeQpc;
static int g_textureFailures;

static struct {
  LONG eyeFrames[2], flatFrames, repeatFrames, seqSkips, submitOK[2], submitFail[2], overlayOK, overlayFail;
  LONG waits, waitFail, poseInvalid, copyFail, paramChanges;
  LONG pairs, waitSkipped;
  double pairGapMsSum, pairGapMsMax;
  int lastSubmitErr, lastOverlayErr, lastWaitErr;
  double waitMsSum, waitMsMax;
  LONG works, workOver;               // 0.43: pairs / frames timed from the end of the frame wait to the submit; those over 11.1 ms
  double workMsSum, workMsMax;
} g_ss;
static int64_t g_waitDoneQpc, g_lastReportQpc;   // 0.43
static struct { LONG n, steady, late, hitch, over2s; double maxGap, sum; int64_t lastQ; LONG totN, totSteady, totLate, totHitch; double totMax; int logs; } g_sm;   // 0.98 SMOOTH: gaps between the pairs handed to the headset
static double g_capShare = 1.0;                     // 1.7.172: the share of the headset's frames the FPS limit asks for (1 = no limit, 0.5 = every 2nd, 60 on 90 Hz paced = 0.667): what the rate checks compare against
static int g_capDiv = 1;                            // 1.7.153: the FPS limit shows a new pair on every Nth headset frame (1 = no limit); the rate / budget checks below count against that
static double g_workBudgetMs = 11.1;               // 0.98: 'work over budget' counts against one display period (11.1 ms until the headset's rate is known)
static int g_sharpLogs, g_sharpTick;
static safety::PerfWatch g_perf;                   // 0.44
static LONG g_lastFlatFrames;
static int g_vramReports;
static int g_adviceReports;
static int g_noteVsyncHz = -1;                    // 0.43: compositor rate the log already commented on

static int g_frozenOk, g_frozenFrames;   // 1.7.28 (see submit_frozen): 1 once a whole pair reached the headset; the last pair is what a hand-held menu freezes
static void release_textures() {
  g_frozenOk = 0;
  eyeaa_release();   // 1.7.153: its views point at the eye pictures released below
  for (int i = 0; i < 2; ++i) if (g_eyeTex[i]) { g_eyeTex[i]->Release(); g_eyeTex[i] = nullptr; }
  if (g_flatTex) { g_flatTex->Release(); g_flatTex = nullptr; }
  if (g_specTex) { g_specTex->Release(); g_specTex = nullptr; }
  g_haveSpec = 0;
  if (g_blackTex) { g_blackTex->Release(); g_blackTex = nullptr; }
  g_blackSubmitting = 0;
  g_texW = g_texH = 0;
  g_haveEye[0] = g_haveEye[1] = 0;
}

static void release_device() {
  shot_release();
  handmodel_release();
  flatview_release();
  monitorview_release();   // 1.2
  flatcursor_release();    // 1.3
  flatglow_release();
  release_textures();
  if (g_ctx) { g_ctx->Release(); g_ctx = nullptr; }
  if (g_dev) { g_dev->Release(); g_dev = nullptr; }
  g_texSwapChain = nullptr;
}

// Back buffer of this swap chain (caller releases) and matching eye textures.
static ID3D11Texture2D* acquire_back_buffer(IDXGISwapChain* sc) {
  ID3D11Texture2D* bb = nullptr;
  if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb)) || !bb) return nullptr;
  // Our textures must live on the device that owns the back buffer (the game
  // may rebuild its device; a new swap chain can even reuse the old address).
  ID3D11Device* owner = nullptr;
  bb->GetDevice(&owner);
  if (!owner) { bb->Release(); return nullptr; }
  if (owner != g_dev || sc != g_texSwapChain) {
    release_device();
    g_dev = owner;  // keeps the reference
    g_dev->GetImmediateContext(&g_ctx);
    if (!g_ctx) { release_device(); bb->Release(); return nullptr; }
    g_texSwapChain = sc;
    gpu_match_check();   // 1.7.87: once the game's device is known (a no-op until the headset session exists)
  } else {
    owner->Release();
  }
  D3D11_TEXTURE2D_DESC d;
  bb->GetDesc(&d);
  if (d.Width != g_texW || d.Height != g_texH || d.Format != g_texFmt || !g_eyeTex[0]) {
    release_textures();
    D3D11_TEXTURE2D_DESC t;
    ZeroMemory(&t, sizeof(t));
    t.Width = d.Width; t.Height = d.Height; t.MipLevels = 1; t.ArraySize = 1; t.Format = d.Format;
    t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT;
    t.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    HRESULT h0 = g_dev->CreateTexture2D(&t, nullptr, &g_eyeTex[0]);
    HRESULT h1 = g_dev->CreateTexture2D(&t, nullptr, &g_eyeTex[1]);
    HRESULT h2 = g_dev->CreateTexture2D(&t, nullptr, &g_flatTex);
    // 0.98: the black scene picture (64 x 64, all zero = black in every format; the row step is generous so it fits up to 16 bytes a pixel)
    static unsigned char s_zero[64 * 64 * 16];
    D3D11_TEXTURE2D_DESC bt = t;
    bt.Width = 64; bt.Height = 64;
    D3D11_SUBRESOURCE_DATA bd;
    bd.pSysMem = s_zero; bd.SysMemPitch = 64 * 16; bd.SysMemSlicePitch = 0;
    HRESULT h3 = g_dev->CreateTexture2D(&bt, &bd, &g_blackTex);
    if (FAILED(h3)) g_blackTex = nullptr;   // not fatal: the flat screen then falls back to the old way (clear the last frame)
    log_line("STEREO textures %u x %u format=%d backBufferSamples=%u create=%08x,%08x,%08x black=%08x", d.Width, d.Height,
             (int)d.Format, d.SampleDesc.Count, (unsigned)h0, (unsigned)h1, (unsigned)h2, (unsigned)h3);
    if (FAILED(h0) || FAILED(h1) || FAILED(h2)) {
      release_textures();
      bb->Release();
      safety_issue(IS_TEXTURE);
      if (++g_textureFailures >= 3) {
        log_line("STEREO off: eye textures could not be created for this back-buffer format (or not enough graphics memory for %u x %u).", d.Width, d.Height);
        // 0.44: the big picture is the likely reason: the next start uses a smaller one
        if (modes_active_level() >= 3) safety_fallback_picture(2, "eye textures could not be created at this picture size");
        InterlockedExchange(&g_ctl.stereoWanted, 0);
      }
      return nullptr;
    }
    g_textureFailures = 0;
    g_texW = d.Width; g_texH = d.Height; g_texFmt = d.Format;
    // 8-bit UNORM back buffers hold display-ready (gamma) colours.
    g_gamma = d.Format == DXGI_FORMAT_R8G8B8A8_UNORM || d.Format == DXGI_FORMAT_B8G8R8A8_UNORM ||
              d.Format == DXGI_FORMAT_B8G8R8X8_UNORM;
  }
  g_bbSamples = d.SampleDesc.Count;
  return bb;
}

// 1.7.38: the chest-camera picture's texture (same size and format as the eye pictures); made the first time it is needed
static ID3D11Texture2D* spec_texture() {
  if (g_specTex) return g_specTex;
  if (!g_dev || !g_eyeTex[0]) return nullptr;
  D3D11_TEXTURE2D_DESC t;
  g_eyeTex[0]->GetDesc(&t);
  const HRESULT h = g_dev->CreateTexture2D(&t, nullptr, &g_specTex);
  if (FAILED(h)) { g_specTex = nullptr; ++g_sp.noTex; if (g_sp.texLogs++ < 3) log_line("CHESTCAMPIC the picture for the chest camera could not be created (%08x): the PC window keeps showing the eye picture", (unsigned)h); return nullptr; }
  log_line("CHESTCAMPIC picture made: %u x %u format=%d", t.Width, t.Height, (int)t.Format);
  return g_specTex;
}

static void copy_back_buffer(ID3D11Texture2D* dst, ID3D11Texture2D* bb) {
  if (g_bbSamples > 1) g_ctx->ResolveSubresource(dst, 0, bb, 0, g_texFmt);
  else g_ctx->CopyResource(dst, bb);
}

// 1.3 fade up from black. begin: the scene goes black at once (the 2D screen is gone, the first 3D frames are on their way), three frames later
// it fades to clear over fade_in_ms. clear: no fade is left (a flat screen must never be darkened). tick: every real frame; a fade that is somehow
// still in force 0.7 s after it should have ended is removed by force.
static void fade_in_clear(const char* why) {
  if (!g_fi.state) return;
  vr_capi_fade_color(0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
  g_fi.state = 0;
  ++g_fi.cleared;
  if (g_fi.logs < 12) { ++g_fi.logs; log_line("FADEIN cleared (%s)", why); }
}
static void fade_in_begin(const char* why, int overrideMs = 0) {
  const int ms = overrideMs > 0 ? overrideMs : (int)g_ctl.fadeInMs;
  if (ms < 50 || !g_ctl.stereoActive) return;
  vr_capi_fade_color(0.0f, 0.0f, 0.0f, 0.0f, 1.0f);
  g_fi.state = 1; g_fi.tick = g_monTick; g_fi.startQ = qpc_now(); g_fi.lastMs = ms;
  ++g_fi.begun;
  if (g_fi.logs < 12) { ++g_fi.logs; log_line("FADEIN begun (%s): black now, fades up over %d ms (frame %d)", why, ms, (int)g_ctl.worldFrames); }
}
static void fade_in_tick() {
  if (g_comfortHold) {
    if ((double)(qpc_now() - g_comfortHoldQ) / (double)qpc_freq() > 5.0) { InterlockedExchange(&g_comfortHold, 0); if (g_fi.logs < 12) { ++g_fi.logs; log_line("FADEIN the held black ended after 5 s (no roof spot yet)"); } }   // 1.7.185: was 2 s: the roof spot came about 2 s in, so the black ended just before it and the wall showed
    else if (g_fi.state == 1) { g_fi.tick = g_monTick; g_fi.startQ = qpc_now(); return; }   // stays black, the fade up has not started
  }
  if (!g_fi.state) return;
  const double el = (double)(qpc_now() - g_fi.startQ) * 1000.0 / (double)qpc_freq();
  if (g_fi.state == 1 && (g_monTick - g_fi.tick >= 3 || el > 250.0)) {
    vr_capi_fade_color((float)g_fi.lastMs / 1000.0f, 0.0f, 0.0f, 0.0f, 0.0f);
    g_fi.state = 2;
  } else if (g_fi.state == 2 && el > (double)g_fi.lastMs + 700.0) {
    vr_capi_fade_color(0.0f, 0.0f, 0.0f, 0.0f, 0.0f);   // belt and braces: nothing may stay dark
    g_fi.state = 0; ++g_fi.forced;
    if (g_fi.logs < 12) { ++g_fi.logs; log_line("FADEIN removed by force after %.0f ms", el); }
  } else if (g_fi.state == 1 && el > 1200.0) {
    fade_in_clear("took too long");
  }
}

static void enter_flat_mode() {
  fade_in_clear("a 2D screen is coming");
  shot_release();  // no 3D frames any more (menu): a picture in progress ends, a waiting F2 is forgotten
  g_flatMode = 1;
  g_flatPlaced = 0;
  g_stereoRun = 0;
  g_haveEye[0] = g_haveEye[1] = 0;
  // 0.98: the old way (ClearLastSubmittedFrame) leaves the headset with no 3D scene at all, and SteamVR then shows its own Home. Now black frames are
  // handed over every flat frame instead (show_flat); the old way stays as the fallback when the black picture cannot be made or the setting is off.
  if (!(g_ctl.flatBlack && g_blackTex)) { vr_capi_clear_last_frame(); g_blackSubmitting = 0; }
  g_voidApplied = -1;   // 0.95: the black void is put in force again (ClearLastSubmittedFrame brings SteamVR's grid room back)
  g_haveScreenXf = 0;
  g_sm.lastQ = 0;
  g_flatStartQ = qpc_now();
  log_line("STEREO flat screen shown (no 3D frame for %d frames) present-frame=%d", g_flatRun, (int)g_ctl.worldFrames);
  g_flowEpisodeN = 0; g_flowEpisodeQ = qpc_now();   // 1.7.85
  input_flow_report("flat screen began");
}

int stereo_in_flat_mode() { return g_flatMode; }

// 0.98: both eyes get the small black picture. The headset thus always has a 3D scene (black) behind the flat screen overlay, and SteamVR Home stays away.
static void submit_black() {
  if (!g_blackTex) return;
  static const float full[4] = {0.0f, 0.0f, 1.0f, 1.0f};
  float pose[12] = {1, 0, 0, 0, 0, 1, 0, 1.4f, 0, 0, 1, 0};
  if (g_haveLastPose) for (int i = 0; i < 12; ++i) pose[i] = g_lastPose[i];
  for (int e = 0; e < 2; ++e) {
    const int r = vr_capi_submit(e, g_blackTex, full, pose, g_gamma);
    if (r == 0) InterlockedIncrement(&g_fl.blackOK);
    else {
      const LONG n = InterlockedIncrement(&g_fl.blackFail);
      if (n <= 3) log_line("FLATBLACK submitting the black picture failed (%s eye, SteamVR code %d)", e ? "right" : "left", r);
    }
  }
  if (!g_blackSubmitting) {
    g_blackSubmitting = 1;
    ++g_fl.blackSwitches;
    if (g_fl.blackLogs < 6) {
      ++g_fl.blackLogs;
      log_line("FLATBLACK black frames now go to the headset behind the flat screen (so SteamVR Home cannot show): flat frame %d, ok=%ld fail=%ld", g_fl.shown, (long)g_fl.blackOK, (long)g_fl.blackFail);
    }
  }
}

// 1.7.28: with the hand-held game menu the world stays where it was: the last 3D pair is handed to the headset again every flat frame (with the pose it was drawn at, so the
// compositor keeps it fixed in the room while you move your head) instead of the black picture. 0 = no pair to show yet / the textures are gone.
static void submit_frozen() {
  if (!g_frozenOk || !g_eyeTex[0] || !g_eyeTex[1]) { submit_black(); return; }
  for (int e = 0; e < 2; ++e) {
    const int r = vr_capi_submit(e, eyeaa_tex(e, g_eyeTex[e]), g_eyeBounds[e], g_eyePose[e], g_gamma);
    if (r != 0) {
      const LONG n = InterlockedIncrement(&g_fl.blackFail);
      if (n <= 3) log_line("FLATFROZEN submitting the frozen picture failed (%s eye, SteamVR code %d): black pictures instead", e ? "right" : "left", r);
      g_frozenOk = 0;
      submit_black();
      return;
    }
  }
  ++g_frozenFrames;
  if ((g_frozenFrames <= 2 || (g_frozenFrames % 400) == 0) && g_fl.frozenGeomLogs < 24) {   // 1.7.31 FROZENEYES: the stored world pictures behind the menu: are the two eyes' sizes and poses alike?
    ++g_fl.frozenGeomLogs;
    const double wl = (double)((g_eyeBounds[0][2] - g_eyeBounds[0][0]) * g_texW), hl = (double)((g_eyeBounds[0][3] - g_eyeBounds[0][1]) * g_texH);
    const double wr = (double)((g_eyeBounds[1][2] - g_eyeBounds[1][0]) * g_texW), hr = (double)((g_eyeBounds[1][3] - g_eyeBounds[1][1]) * g_texH);
    const double dx = (double)g_eyePose[1][3] - g_eyePose[0][3], dy = (double)g_eyePose[1][7] - g_eyePose[0][7], dz = (double)g_eyePose[1][11] - g_eyePose[0][11];
    const double f0[3] = {-(double)g_eyePose[0][2], -(double)g_eyePose[0][6], -(double)g_eyePose[0][10]}, f1[3] = {-(double)g_eyePose[1][2], -(double)g_eyePose[1][6], -(double)g_eyePose[1][10]};
    const double cx = f0[1] * f1[2] - f0[2] * f1[1], cy = f0[2] * f1[0] - f0[0] * f1[2], cz = f0[0] * f1[1] - f0[1] * f1[0];
    const double turnDeg = vm::datan2(vm::dsqrt(cx * cx + cy * cy + cz * cz), f0[0] * f1[0] + f0[1] * f1[1] + f0[2] * f1[2]) * 180.0 / vm::kPi;
    log_line("FROZENEYES #%ld flat frame %d | stored world picture left %.0fx%.0f px (bounds %.3f,%.3f-%.3f,%.3f), right %.0fx%.0f px (bounds %.3f,%.3f-%.3f,%.3f) | the two stored head poses differ by %.1f cm and %.2f deg | texture %ux%u",
             (long)g_fl.frozenGeomLogs, g_fl.shown, wl, hl, (double)g_eyeBounds[0][0], (double)g_eyeBounds[0][1], (double)g_eyeBounds[0][2], (double)g_eyeBounds[0][3],
             wr, hr, (double)g_eyeBounds[1][0], (double)g_eyeBounds[1][1], (double)g_eyeBounds[1][2], (double)g_eyeBounds[1][3],
             vm::dsqrt(dx * dx + dy * dy + dz * dz) * 100.0, turnDeg, (unsigned)g_texW, (unsigned)g_texH);
  }
  if (!g_blackSubmitting) {   // the headset has a 3D scene behind the flat screen now (so SteamVR Home stays away, as with the black picture)
    g_blackSubmitting = 1;
    if (g_fl.blackLogs < 12) { ++g_fl.blackLogs; log_line("FLATFROZEN the last 3D picture stays behind the hand-held menu (the world stands still around you): flat frame %d", g_fl.shown); }
  }
}

static int g_heldPlaceWas;   // the flat screen was in the hand on the last flat frame

static void show_flat_impl(ID3D11Texture2D* bb);
static void show_flat(ID3D11Texture2D* bb) {   // 1.7.31: times a whole flat frame while the hand-held menu is up (HELDTIMING)
  const int held = held_menu_active();
  const int64_t t0 = held ? qpc_now() : 0;
  show_flat_impl(bb);
  if (held) held_menu_note_flat_cost((double)(qpc_now() - t0) * 1000.0 / (double)qpc_freq());
}
static void show_flat_impl(ID3D11Texture2D* bb) {
  stage_r(ST_FLAT_SCREEN);
  ++g_fl.shown;
  if (g_flatPlaced && g_haveLastPose) {   // 0.80: the screen follows you when you turn well away from it (a video can then be watched lying or turning in a chair)
    float H2[9];
    pose34_rotation(g_lastPose, H2);
    const double fx = -(double)H2[2], fz = -(double)H2[8];
    if (fx * fx + fz * fz > 0.2) {   // not looking straight up or down
      double d = vm::datan2(fx, -fz) - g_flatYaw;
      while (d > vm::kPi) d -= 2.0 * vm::kPi;
      while (d < -vm::kPi) d += 2.0 * vm::kPi;
      const double deg = (d < 0 ? -d : d) * 180.0 / vm::kPi;
      const double now = (double)qpc_now() / (double)qpc_freq();
      if (deg < kScreenTurnDeg) g_flatAwayStart = 0;
      else if (g_flatAwayStart == 0) g_flatAwayStart = now;
      else if (now - g_flatAwayStart > kScreenTurnSecs) {
        g_flatPlaced = 0; g_flatAwayStart = 0; ++g_fl.recentered;
        if (g_fl.recentered <= 8) log_line("FLATSCREEN you looked %.0f degrees away from the screen for %.1f s: it moves back in front of you", deg, kScreenTurnSecs);
      }
    }
  }
  copy_back_buffer(g_flatTex, bb);
  stage_r(ST_MENU_PUMP);
  menu_pump();
  {   // 1.7.85: while a flat screen stays up (a menu, the death screen) INPUTFLOW lines: every 3 s for the first 8, then every 15 s, 24 at most per flat screen (the count starts again at each new flat screen)
    const int64_t fq = qpc_now();
    const int64_t gap = qpc_freq() * (g_flowEpisodeN < 8 ? 3 : 15);
    if (g_flowEpisodeQ && fq - g_flowEpisodeQ >= gap && g_flowEpisodeN < 24) { g_flowEpisodeQ = fq; ++g_flowEpisodeN; input_flow_report("flat screen still up"); }
  }
  stage_r(ST_FLAT_SCREEN);   // 0.42: the controllers' pointer -> the game's mouse
  const int heldNow = held_menu_active();
  if (heldNow) held_menu_frame(g_texH ? (double)g_texW / (double)g_texH : 1.0);   // 1.7.29: the panel on the left hand and the right hand's own pointer (before the ring is painted)
  if (heldNow && vrmenu_is_open()) {   // 1.7.28: the settings pages are in the hand: the game's picture waits (hidden), the frozen world stays
    vr_capi_overlay_hide();
    flatglow_hide();
    submit_frozen();
    g_heldPlaceWas = 1;
    return;
  }
  if (heldNow) held_banner_paint(g_ctx, g_flatTex, g_texW, g_texH, (int)g_texFmt);   // 1.7.28: the VR SETTINGS button at the bottom of the game's menu picture
  if (g_ctl.flatCursor || heldNow) {    // 1.3: a ring where the laser touches the screen (1.7.29: always on the hand-held menu: the ring is the pointer), painted into the screen's own picture
    float cu = 0, cv = 0; int cd = 0;
    if (vrmenu_is_open()) ++g_cu.cursorHidden;
    else if (menu_pointer(&cu, &cv, &cd)) { if (flatcursor_draw(g_dev, g_ctx, g_flatTex, g_texW, g_texH, cu, cv, (int)g_ctl.flatCursorPct, cd)) ++g_cu.cursorDraws; }
    else ++g_cu.cursorNone;
  }
  // Put the screen in front of where the player is facing. Until a usable
  // pose exists (headset not on the head yet, or pointing at the floor) a
  // provisional place is used and the placement is tried again next frame.
  float xf[12];
  const float* place = nullptr;
  int settled = 0;
  float Y[9];
  // 1.1 the look of the screen from the menu: distance, how far below your eyes, size (as the angle it covers, so moving it away does not shrink it), bend, fade-in
  double distM = (double)g_ctl.flatDistCm / 100.0, dropM = (double)g_ctl.flatDropCm / 100.0;
  if (!(distM >= 1.2) || distM > 5.0) distM = kScreenDistanceM;
  if (!(dropM > -0.5) || dropM > 1.0) dropM = kScreenDropM;
  double sizeK = ((double)g_ctl.flatSizePct / 100.0) * (distM / kScreenDistanceM);
  if (!(sizeK > 0.2) || sizeK > 6.0) sizeK = 1.0;
  if (g_flatPlaced && (vm::dabs(distM - g_placedDist) > 0.005 || vm::dabs(dropM - g_placedDrop) > 0.005)) { g_flatPlaced = 0; ++g_look.replaced; }   // changed in the menu: the screen is put in front of you again
  if (!g_flatPlaced) {
    float H[9];
    if (g_haveLastPose) {
      pose34_rotation(g_lastPose, H);
      settled = make_yaw_reference(H, Y);
      if (!settled) vm::identity(Y);
      stereo::flat_screen_transform(g_lastPose, Y, distM, dropM, xf);
    } else {
      float p0[12] = {1, 0, 0, 0, 0, 1, 0, 1.4f, 0, 0, 1, 0};
      vm::identity(Y);
      stereo::flat_screen_transform(p0, Y, distM, dropM, xf);
    }
    place = xf;
    for (int i = 0; i < 12; ++i) g_screenXf[i] = xf[i];
    g_haveScreenXf = 1;
  }
  float screenWidthM = picture::flat_screen_width(g_texW, g_texH, kScreenWidthM * (float)sizeK, kScreenMaxHeightM * (float)sizeK);
  // 1.7.28: the hand-held game menu: the screen hangs above the left hand, facing the eyes, small, flat (no bend), no TV glow
  float heldXf[12];
  double heldW = 0.0;
  const int heldPlace = heldNow && held_menu_place(heldXf, &heldW);
  const int heldWasBefore = g_heldPlaceWas;   // 1.7.31
  if (heldPlace) {
    if (!g_heldPlaceWas) { vr_capi_overlay_hide(); flatglow_hide(); }   // the big screen and its TV glow go (the screen is shown again in the hand by the update below)
    place = heldXf; screenWidthM = (float)heldW; g_heldPlaceWas = 1;
  }
  else if (g_heldPlaceWas) { g_heldPlaceWas = 0; g_flatPlaced = 0; }   // back to the big screen: it is put in front of you again (next frame)
  {   // bend and fade-in go in before the screen is shown, so the first frame is already right
    const float curve = heldPlace ? 0.0f : glow::screen_curvature((double)g_ctl.flatCurvePct, (double)screenWidthM, distM);
    float fade = glow::fade_in(g_flatStartQ ? (double)(qpc_now() - g_flatStartQ) / (double)qpc_freq() : 1.0, kScreenFadeSecs);
    {   // 1.3: the VR menu is open in front of the screen: the screen dims (quickly) so the menu reads clearly in the black void, and comes back after
      const int64_t nq = qpc_now();
      double dt = g_dimQ ? (double)(nq - g_dimQ) / (double)qpc_freq() : 0.0;
      g_dimQ = nq;
      if (dt < 0.0) dt = 0.0; if (dt > 0.1) dt = 0.1;
      const float target = (g_ctl.menuDimFlat && vrmenu_is_open()) ? 0.28f : 1.0f;
      const float step = (float)(dt * 4.0);
      if (g_dimNow < target) { g_dimNow += step; if (g_dimNow > target) g_dimNow = target; }
      else if (g_dimNow > target) { g_dimNow -= step; if (g_dimNow < target) g_dimNow = target; }
      if (g_dimNow < 0.999f) { fade *= g_dimNow; ++g_cu.dimFrames; }
    }
    vr_capi_overlay_style(curve, fade);
    const double aspect = g_texH ? (double)g_texW / (double)g_texH : 1.0;
    g_look.widthM = screenWidthM; g_look.heightM = (float)(screenWidthM / aspect); g_look.distM = (float)distM; g_look.dropM = (float)dropM; g_look.curve = curve; g_look.fade = fade;
    g_look.hDeg = (float)(2.0 * vm::datan2((double)screenWidthM * 0.5, distM) * 180.0 / vm::kPi);
    g_look.vDeg = (float)(2.0 * vm::datan2((double)g_look.heightM * 0.5, distM) * 180.0 / vm::kPi);
  }
  // 1.7.31: with the follow loop the panel is moved by its own thread (about every 4 ms); this per-frame placement would only set it back to an older spot, so it is left out after the first one
  const int moverOwns = heldPlace && heldWasBefore && held_menu_mover_owns(0);
  int e = vr_capi_overlay_update(g_flatTex, moverOwns ? nullptr : place, screenWidthM, g_gamma);
  if (e == 0) {
    InterlockedIncrement(&g_ss.overlayOK);
    {   // 0.95 the black void: SteamVR's grid room (shown behind the flat screen after ClearLastSubmittedFrame) fades out; re-checked about every 1.5 s because it can come back
      const int wantVoid = g_ctl.flatVoid != 0;
      const int recheck = wantVoid && g_voidApplied == 1 && (g_fl.shown % 90) == 7;
      if (wantVoid != g_voidApplied || recheck) {
        const float before = vr_capi_grid_alpha();
        if (wantVoid) { if (g_voidApplied != 1 || before > 0.02f) { vr_capi_fade_grid(0.25f, 0); ++g_fl.voidCalls; } }
        else vr_capi_fade_grid(0.25f, 1);
        if (before > g_fl.gridAlphaMax) g_fl.gridAlphaMax = before;
        if (g_fl.gridLogs < 10 && (wantVoid != g_voidApplied || before > 0.02f)) {
          ++g_fl.gridLogs;
          log_line("FLATVOID %s: SteamVR grid room alpha was %.2f (1 = fully there, 0 = gone, -1 = no answer), asked it to fade %s (frame %d of the flat screen)", wantVoid ? "on" : "off", before, wantVoid ? "out" : "back in", g_fl.shown);
        }
        g_voidApplied = wantVoid;
      } else if (g_fl.gridLogs < 10 && wantVoid && (g_fl.shown == 60 || g_fl.shown == 240)) {   // did it work? (about 1 s and 4 s later)
        ++g_fl.gridLogs;
        g_fl.gridAlphaLast = vr_capi_grid_alpha();
        log_line("FLATVOID check after %d flat frames: grid room alpha %.2f (0 = gone: a black void)", g_fl.shown, g_fl.gridAlphaLast);
      }
    }
    if (heldPlace) flatglow_hide();
    else if (g_haveScreenXf) flatglow_frame(g_dev, g_ctx, g_flatTex, g_texW, g_texH, (int)g_texFmt, g_screenXf, screenWidthM, (float)g_texW / (float)g_texH);   // 0.95 the TV glow
    if (heldPlace) submit_frozen();   // 1.7.28
    else if (g_ctl.flatBlack && g_blackTex) submit_black();
    else if (g_blackSubmitting) { vr_capi_clear_last_frame(); g_blackSubmitting = 0; g_voidApplied = -1; }   // switched off in the menu while the flat screen is up
    if (settled) {
      g_flatPlaced = 1;
      ++g_fl.placements;
      g_flatYaw = vm::datan2(-(double)Y[2], (double)Y[8]);
      g_flatAwayStart = 0;
      g_placedDist = distM; g_placedDrop = dropM;
      log_line("STEREO flat screen placed at %.2f,%.2f,%.2f (metres, play space)", xf[3], xf[7], xf[11]);
      if (++g_look.looks <= 12) log_line("FLATLOOK the 2D screen: %.2f m wide x %.2f m high, %.2f m away, middle %.0f cm below your eyes, covers %.0f x %.0f degrees of your view, bend %.3f (setting %d %%), size %d %%, fades in over %.2f s",
                                        (double)g_look.widthM, (double)g_look.heightM, (double)g_look.distM, (double)g_look.dropM * 100.0, (double)g_look.hDeg, (double)g_look.vDeg, (double)g_look.curve, (int)g_ctl.flatCurvePct, (int)g_ctl.flatSizePct, kScreenFadeSecs);
    }
  } else {
    g_ss.lastOverlayErr = e;
    safety_issue(IS_OVERLAY);
    if (InterlockedIncrement(&g_ss.overlayFail) <= 5) log_line("STEREO flat screen error %d", e);
  }
}

// 0.27: after a pair was handed to the headset, the diagnostic picture (F2)
// may take a copy of the two eye textures.
static void offer_picture() {
  ShotSource s;
  ZeroMemory(&s, sizeof(s));
  s.dev = g_dev; s.ctx = g_ctx;
  for (int e = 0; e < 2; ++e) {
    s.tex[e] = g_eyeTex[e];
    for (int i = 0; i < 4; ++i) s.bounds[e][i] = g_eyeBounds[e][i];
  }
  s.w = g_texW; s.h = g_texH; s.format = (int)g_texFmt;
  s.eyeTanW = g_rp.right[0] - g_rp.left[0];
  s.eyeTanH = g_rp.bottom[0] - g_rp.top[0];
  shot_on_pair(&s);
}

static void submit_eyes() {
  ProfScope psSubmit(PF_SUBMIT);
  stage_r(ST_SUBMIT);
  {   // 1.7.192 EYEPAIR (the right eye was blank in the roof fight): every 30 s, how many pairs went out, how old each eye's picture was (in real frames), and how often one eye was older than the other by 3+ frames, split roof fight / elsewhere
    static int64_t s_q; static long s_n[2], s_skew[2], s_skewMax[2], s_old[2]; static int s_logs; static long s_ageMax[2][2];
    const int roof = engine_scene_arms(0) ? 1 : 0;
    const long a0 = (long)(g_monTick - g_eyeTick[0]), a1 = (long)(g_monTick - g_eyeTick[1]);
    ++s_n[roof]; const long d = a0 > a1 ? a0 - a1 : a1 - a0;
    if (d >= 3) ++s_skew[roof]; if (d > s_skewMax[roof]) s_skewMax[roof] = d;
    if (a0 > s_ageMax[roof][0]) s_ageMax[roof][0] = a0; if (a1 > s_ageMax[roof][1]) s_ageMax[roof][1] = a1;
    if (a0 >= 6 || a1 >= 6) ++s_old[roof];
    const int64_t nq = qpc_now(); if (!s_q) s_q = nq;
    if ((double)(nq - s_q) / (double)qpc_freq() >= 10.0 && s_logs < 120) { s_q = nq; ++s_logs;
      log_line("EYEPAIR 30 s: pairs sent elsewhere %ld / in the Stay Puft roof fight %ld | an eye picture 3+ frames older than the other: %ld / %ld (most %ld / %ld frames) | a picture 6+ frames old: %ld / %ld | oldest left / right eye picture: %ld / %ld frames elsewhere, %ld / %ld in the roof fight | eye pictures made in all: left %ld, right %ld",
               s_n[0], s_n[1], s_skew[0], s_skew[1], s_skewMax[0], s_skewMax[1], s_old[0], s_old[1], s_ageMax[0][0], s_ageMax[0][1], s_ageMax[1][0], s_ageMax[1][1], (long)g_ss.eyeFrames[0], (long)g_ss.eyeFrames[1]);
      s_n[0] = s_n[1] = s_skew[0] = s_skew[1] = s_skewMax[0] = s_skewMax[1] = s_old[0] = s_old[1] = 0; s_ageMax[0][0] = s_ageMax[0][1] = s_ageMax[1][0] = s_ageMax[1][1] = 0; }
  }
  if (g_waitDoneQpc) {   // 0.43: how long did the game need since the compositor released the frame
    double w = (double)(qpc_now() - g_waitDoneQpc) * 1000.0 / (double)qpc_freq();
    InterlockedIncrement(&g_ss.works);
    g_ss.workMsSum += w;
    if (w > g_ss.workMsMax) g_ss.workMsMax = w;
    if (w > g_workBudgetMs) InterlockedIncrement(&g_ss.workOver);
  }
  {   // 0.98 SMOOTH: how evenly the pairs reach the headset (one display period apart = smooth animation; a gap of two periods or more = a visible hitch)
    const int64_t nq = qpc_now();
    if (g_sm.lastQ) {
      const double gap = (double)(nq - g_sm.lastQ) * 1000.0 / (double)qpc_freq();
      if (gap > 2000.0) ++g_sm.over2s;   // a load, a menu, a pause: not a hitch of the animation
      else {
        ++g_sm.n; ++g_sm.totN; g_sm.sum += gap;
        if (gap > g_sm.maxGap) g_sm.maxGap = gap;
        if (gap > g_sm.totMax) g_sm.totMax = gap;
        const double per = g_workBudgetMs > 5.0 ? g_workBudgetMs : 11.1;
        if (gap <= 1.25 * per) { ++g_sm.steady; ++g_sm.totSteady; }
        else if (gap <= 2.25 * per) { ++g_sm.late; ++g_sm.totLate; }
        else { ++g_sm.hitch; ++g_sm.totHitch; }
      }
    }
    g_sm.lastQ = nq;
  }
  int bothOk = 1;
  for (int e = 0; e < 2; ++e) {
    int r = vr_capi_submit(e, eyeaa_tex(e, g_eyeTex[e]), g_eyeBounds[e], g_eyePose[e], g_gamma);
    if (r != 0) bothOk = 0;
    if (r == 0) InterlockedIncrement(&g_ss.submitOK[e]);
    else {
      g_ss.lastSubmitErr = r;
      safety_issue(IS_SUBMIT);
      LONG n = InterlockedIncrement(&g_ss.submitFail[e]);
      if (n <= 5) log_line("STEREO submit %s eye error %d", e ? "right" : "left", r);
      if (n == 1 && r == 106)
        log_line("STEREO: error 106 = SteamVR cannot share textures with the game's Direct3D device (DXGI 1.0 factory). "
                 "See the DXGIFACTORY / SHARETEST lines at the top of this log.");
    }
  }
  g_frozenOk = bothOk;
}

// ---- Session start / stop (render thread, once per Present) ---------------------
static void deactivate(const char* why) {
  shot_release();  // a running picture sequence ends; its two switches go back
  if (g_ctl.stereoActive) log_line("STEREO off: %s (frame=%d)", why, (int)g_ctl.worldFrames);
  if (g_fi.state) { vr_capi_fade_color(0.0f, 0.0f, 0.0f, 0.0f, 0.0f); ++g_fi.cleared; }   // 1.3: never leave a fade behind
  g_fi.state = 0;
  InterlockedExchange(&g_ctl.stereoActive, 0);
  AcquireSRWLockExclusive(&g_lock);
  g_params.valid = 0;
  ReleaseSRWLockExclusive(&g_lock);
}

// 1.7.87: is the game drawing on the graphics card the headset hangs on? SteamVR names that card (adapter LUID); a game on another card cannot hand its picture
// over (laptops with two cards, Windows' per-app graphics setting). Logged once, as soon as the game's device and the headset session both exist.
static void gpu_match_check() {
  static int s_done;
  if (s_done || !g_dev || !vr_capi_ready()) return;
  const unsigned long long vrLuid = vr_capi_output_luid();
  unsigned long long gameLuid = 0;
  char name[96] = "?";
  IDXGIDevice* dd = nullptr; IDXGIAdapter* ad = nullptr;
  if (SUCCEEDED(g_dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dd)) && dd && SUCCEEDED(dd->GetAdapter(&ad)) && ad) {
    DXGI_ADAPTER_DESC desc;
    ZeroMemory(&desc, sizeof(desc));
    if (SUCCEEDED(ad->GetDesc(&desc))) {
      gameLuid = env::luid_pack((uint32_t)desc.AdapterLuid.LowPart, (int32_t)desc.AdapterLuid.HighPart);
      WideCharToMultiByte(CP_ACP, 0, desc.Description, -1, name, (int)sizeof(name), nullptr, nullptr);
      name[sizeof(name) - 1] = 0;
    }
  }
  if (ad) ad->Release();
  if (dd) dd->Release();
  s_done = 1;
  const int rel = env::gpu_relation(gameLuid, vrLuid);
  log_line("ENVCHECK gpu: the game draws on \"%s\" (adapter %08x:%08x); SteamVR attaches the headset to adapter %08x:%08x -> %s",
           name, (unsigned)(gameLuid >> 32), (unsigned)(gameLuid & 0xffffffffu), (unsigned)(vrLuid >> 32), (unsigned)(vrLuid & 0xffffffffu),
           rel == env::kGpuSame ? "the same card (good)" : rel == env::kGpuDifferent ? "a DIFFERENT card (the headset will stay black)" : "SteamVR did not say");
  if (rel == env::kGpuDifferent) log_line("ENVHINT %s", env::gpu_hint(rel));
}

static int activate() {
  GbvrEyeParams ep[2];
  if (!vr_capi_eye_params(0, &ep[0]) || !vr_capi_eye_params(1, &ep[1])) return 0;
  char info[480];
  vr_capi_describe(info, (int)sizeof(info));
  log_line("HEADSET %s", info);
  gpu_match_check();   // 1.7.87 (if the game's device is not known yet, the periodic report asks again)
  StereoParams p;
  ZeroMemory(&p, sizeof(p));
  int ok = 1;
  for (int e = 0; e < 2; ++e) {
    p.left[e] = ep[e].left; p.right[e] = ep[e].right; p.top[e] = ep[e].top; p.bottom[e] = ep[e].bottom;
    p.eyeX[e] = ep[e].eyeToHead[3];
    log_line("STEREOPARAMS eye=%s rawLeft=%.5f rawRight=%.5f rawTop=%.5f rawBottom=%.5f eyeToHead=%.5f,%.5f,%.5f,%.5f,"
             "%.5f,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f", e ? "right" : "left", p.left[e], p.right[e], p.top[e],
             p.bottom[e], ep[e].eyeToHead[0], ep[e].eyeToHead[1], ep[e].eyeToHead[2], ep[e].eyeToHead[3],
             ep[e].eyeToHead[4], ep[e].eyeToHead[5], ep[e].eyeToHead[6], ep[e].eyeToHead[7], ep[e].eyeToHead[8],
             ep[e].eyeToHead[9], ep[e].eyeToHead[10], ep[e].eyeToHead[11]);
    float v[5] = {p.left[e], p.right[e], p.top[e], p.bottom[e], p.eyeX[e]};
    for (int i = 0; i < 5; ++i) if (!vm::is_finite_f(v[i])) ok = 0;
    if (!(p.left[e] < 0 && p.right[e] > 0 && p.top[e] < 0 && p.bottom[e] > 0)) ok = 0;
    if (p.left[e] < -5 || p.right[e] > 5 || p.top[e] < -5 || p.bottom[e] > 5) ok = 0;
    const float* m = ep[e].eyeToHead;
    if (vm::dabs(m[0] - 1) > 0.01 || vm::dabs(m[5] - 1) > 0.01 || vm::dabs(m[10] - 1) > 0.01 || vm::dabs(m[1]) > 0.01 ||
        vm::dabs(m[2]) > 0.01 || vm::dabs(m[4]) > 0.01 || vm::dabs(m[6]) > 0.01 || vm::dabs(m[8]) > 0.01 ||
        vm::dabs(m[9]) > 0.01)
      log_line("STEREO WARNING: this headset's %s eye is rotated against the head (canted displays). This prototype "
               "assumes parallel eyes; the picture will be slightly wrong. (Pimax: turn ON \"Parallel Projections\" in the Pimax software, then restart the game.)", e ? "right" : "left");
  }
  if (!ok) {
    log_line("STEREO not started: the headset reported an unexpected projection (see STEREOPARAMS).");
    return -1;
  }
  // Eye separation: if the runtime reports none (or something absurd), use 64 mm.
  if (!(p.eyeX[0] < -0.02f && p.eyeX[0] > -0.045f && p.eyeX[1] > 0.02f && p.eyeX[1] < 0.045f)) {
    log_line("STEREO eye offsets %.5f / %.5f m out of range, using -0.032 / +0.032", p.eyeX[0], p.eyeX[1]);
    p.eyeX[0] = -0.032f; p.eyeX[1] = 0.032f;
  }
  double needH, needV;
  stereo::required_fov(p.left, p.right, p.top, p.bottom, &needH, &needV);
  p.needTanH = (float)needH; p.needTanV = (float)needV;
  p.valid = 1;
  g_rp = p;
  AcquireSRWLockExclusive(&g_lock);
  g_params = p;
  g_lastSeq = g_frameSeq;
  InterlockedExchange(&g_consumedSeq, (LONG)g_lastSeq);
  ReleaseSRWLockExclusive(&g_lock);
  g_haveEye[0] = g_haveEye[1] = 0;
  g_flatRun = g_stereoRun = g_flatMode = g_flatPlaced = 0;
  g_haveLastPose = 0;
  g_textureFailures = 0;
  g_perf.reset();
  g_lastFlatFrames = 0;
  g_freshEye[0] = g_freshEye[1] = 0;
  g_lastFresh = g_submittedNow = g_skippedWaitLast = 0;
  ZeroMemory(&g_ss, sizeof(g_ss));
  InterlockedExchange(&g_ctl.stereoNextEye, 0);
  InterlockedExchange(&g_ctl.stereoPairPhase, 0);
  // The headset view is first person with head tracking.
  InterlockedExchange(&g_ctl.recenterRequest, 1);
  InterlockedExchange(&g_ctl.firstPerson, 1);
  InterlockedExchange(&g_ctl.mode, MODE_HEAD);
  InterlockedExchange(&g_ctl.stereoActive, 1);
  log_line("STEREO on: needTanH=%.5f needTanV=%.5f (covers both eyes), eye separation %.1f mm, first person + head "
           "tracking enabled. frame=%d", needH, needV, (double)(p.eyeX[1] - p.eyeX[0]) * 1000.0, (int)g_ctl.worldFrames);
  engine_request_sample();
  return 1;
}

void stereo_tick_session() {
  VrSection vr;
  if (!vr.ok()) return;
  if (g_ctl.stereoWanted) {
    g_stopLogged = 0;
    if (vr_capi_ready()) {
      if (!vr_capi_is_scene()) {
        // A head-tracking-only (background) session is running: replace it.
        // Its mode goes off with it, so a failed start leaves the plain game
        // (the headset view switches head tracking on again by itself).
        vr_invalidate_snapshot();
        InterlockedExchange(&g_ctl.mode, MODE_OFF);
        if (vr_capi_shutdown()) log_line("STEREO: head-tracking-only session closed, starting the headset session");
      } else if (!g_ctl.stereoActive) {
        if (activate() < 0) InterlockedExchange(&g_ctl.stereoWanted, 0);
      }
    } else if (vr_capi_failed()) {
      if (g_sceneRequested) {
        log_line("STEREO not started: %s", vr_capi_status());
        InterlockedExchange(&g_ctl.stereoWanted, 0);
      }
      // Clear the failed state (ours, or a stale one from an earlier F9) so a
      // start can be requested on the next frame / the next F4.
      g_sceneRequested = 0;
      InterlockedExchange(&g_ctl.mode, MODE_OFF);
      vr_capi_shutdown();
    } else if (!vr_capi_starting()) {
      g_sceneRequested = 1;
      exit_guard_arm();
      safety_run_begin();   // 0.44: from here a run that does not close cleanly is noticed at the next start
      vr_capi_start_black(g_ctl.flatVoid ? 1 : 0);   // 1.3: SteamVR's grid room fades out the moment the session is ready
      vr_capi_request_start(g_selfDir, GBVR_VR_SCENE);
      log_line("STEREO: starting the headset session (%s)", vr_capi_status());
    }
    return;
  }
  g_sceneRequested = 0;
  // Not wanted: make sure nothing of the headset session is left.
  if (g_ctl.stereoActive || vr_capi_is_scene()) {
    int wasActive = g_ctl.stereoActive != 0;
    deactivate("switched off");
    if (wasActive) {
      // Back to the normal game picture.
      InterlockedExchange(&g_ctl.mode, MODE_OFF);
      InterlockedExchange(&g_ctl.firstPerson, 0);
    }
    vr_invalidate_snapshot();
    vr_capi_overlay_hide();
    if (vr_capi_shutdown()) {
      release_device();
      if (!g_stopLogged) { g_stopLogged = 1; log_line("STEREO: headset session closed"); }
    }
  }
}

// ---- Per-frame work ------------------------------------------------------------------
// 0.30: a Present that does not get to the eye handling still ends the frame
// that was drawn for it: mark that frame as taken, so that stereo_drawing_eye
// (overlay placement) does not keep reporting it on the following flat frames.
static void mark_frame_taken() {
  AcquireSRWLockShared(&g_lock);
  LONG s = (LONG)g_frameSeq;
  ReleaseSRWLockShared(&g_lock);
  InterlockedExchange(&g_consumedSeq, s);
}

int stereo_before_present(void* swapChain, UINT flags) {
  g_didFrame = 0;
  g_specNow = 0;
  if (flags & DXGI_PRESENT_TEST) return 0;  // not a real frame (nothing is shown, nothing is ended)
  VrSection vr;
  if (!vr.ok()) { mark_frame_taken(); return 0; }
  if (!g_ctl.stereoWanted || !vr_capi_is_scene()) { mark_frame_taken(); return 0; }
  g_didFrame = 1;                           // the compositor's frame wait follows this Present
  g_lastFresh = 0;
  g_submittedNow = 0;
  if (!g_ctl.stereoActive) return 1;
  // 1.7.186: "change fade to 3 seconds": the Stay Puft roof-fight jumps (into the roof spot, back out) fade up over scene_fade_ms (3000); every other fade-in keeps fade_in_ms
  if (InterlockedExchange(&g_comfortTransition, 0)) fade_in_begin("the viewpoint jumped (Stay Puft station / a cut in 3D)", (int)g_ctl.sceneFadeMs);
  fade_in_tick();   // 1.3
  IDXGISwapChain* sc = (IDXGISwapChain*)swapChain;
  if (!g_threadsLogged && engine_last_prepare_tid()) {
    g_threadsLogged = 1;
    int same = GetCurrentThreadId() == engine_last_prepare_tid();
    log_line("THREADS present=%u cameraPrepare=%u same=%d (two threads are normal for this game; they take turns - "
             "see overlap= in STEREOCOUNTS, which must stay 0)", GetCurrentThreadId(), engine_last_prepare_tid(), same);
  }
  stage_r(ST_ACQUIRE_BB);
  ID3D11Texture2D* bb = acquire_back_buffer(sc);
  if (!bb) {
    safety_issue(IS_TEXTURE);
    if (InterlockedIncrement(&g_ss.copyFail) <= 3) log_line("STEREO: could not reach the back buffer / create textures");
    mark_frame_taken();
    return 1;
  }
  StereoFrame f;
  AcquireSRWLockShared(&g_lock);
  f = g_frame;
  ReleaseSRWLockShared(&g_lock);
  ++g_monTick;
  int fresh = f.seq != g_lastSeq;
  if (fresh && f.spec) {   // 1.7.38: this frame is the chest camera's picture: it goes to the PC window only, never to the headset, and nothing about the eye pair changes
    g_lastSeq = f.seq;
    InterlockedExchange(&g_consumedSeq, (LONG)f.seq);
    ID3D11Texture2D* st = (g_ctl.chestCam && g_ctl.monitorView) ? spec_texture() : nullptr;
    if (st) {
      copy_back_buffer(st, bb);
      g_haveSpec = 1;
      g_specTick = g_monTick;
      g_specTan[0] = f.tanH; g_specTan[1] = f.tanV;
      ++g_sp.taken;
      const int64_t nq = qpc_now();
      if (g_sp.lastQ) { const double gap = (double)(nq - g_sp.lastQ) * 1000.0 / (double)qpc_freq(); g_sp.gapSum += gap; if (gap > g_sp.gapMax) g_sp.gapMax = gap; }
      g_sp.lastQ = nq;
    }
    g_specNow = 1;          // stereo_after_present: no frame wait for this Present
    g_lastFresh = 0;
    g_submittedNow = 0;
    InterlockedExchange(&g_ctl.stereoNextEye, 0);
    InterlockedExchange(&g_ctl.stereoPairPhase, 0);
    bb->Release();
    return 1;
  }
  if (fresh) {
    if (f.seq - g_lastSeq > 1) InterlockedIncrement(&g_ss.seqSkips);  // more than one prepare per Present
    g_lastSeq = f.seq;
    InterlockedExchange(&g_consumedSeq, (LONG)f.seq);
    int e = f.eye & 1;
    stage_r(ST_COPY_EYE);
    copy_back_buffer(g_eyeTex[e], bb);
    stage_r(ST_HAND_MODEL);
    handmodel_draw(g_dev, g_ctx, g_eyeTex[e], e, f.pose34, g_rp.eyeX[e], f.tanH, f.tanV);   // 0.34: hands and wand
    for (int i = 0; i < 12; ++i) g_eyePose[e][i] = f.pose34[i];
    g_monitorProjection[e][0] = f.tanH; g_monitorProjection[e][1] = f.tanV; g_monitorProjection[e][2] = g_rp.eyeX[e];
    g_boundsInside[e] = stereo::texture_bounds(g_rp.left[e], g_rp.right[e], g_rp.top[e], g_rp.bottom[e], f.tanH,
                                               f.tanV, g_eyeBounds[e]);
    g_lastTanH = f.tanH; g_lastTanV = f.tanV;
    handmodel_vignette(g_dev, g_ctx, g_eyeTex[e], e, g_eyeBounds[e], f.tanH, f.tanV);   // 1.7.22: comfort vignette (off unless switched on)
    eyeaa_apply(g_dev, g_ctx, g_eyeTex[e], e, g_gamma);   // 1.7.153: smooth edges (off by default; off = nothing happens here). 1.7.155: after everything drawn into the eye picture (it ran before the comfort vignette, which was then missing with it on)
    if (g_ss.eyeFrames[e] < 2)
      log_line("STEREOBOUNDS eye=%s uMin=%.4f vMin=%.4f uMax=%.4f vMax=%.4f inside=%d tanH=%.5f tanV=%.5f pixels=%dx%d",
               e ? "right" : "left", g_eyeBounds[e][0], g_eyeBounds[e][1], g_eyeBounds[e][2], g_eyeBounds[e][3],
               g_boundsInside[e], f.tanH, f.tanV, (int)((g_eyeBounds[e][2] - g_eyeBounds[e][0]) * g_texW),
               (int)((g_eyeBounds[e][3] - g_eyeBounds[e][1]) * g_texH));
    g_haveEye[e] = 1;
    g_eyeTick[e] = g_monTick;
    g_freshEye[e] = 1;
    g_lastFresh = 1;
    g_flatRun = 0;
    ++g_stereoRun;
    InterlockedIncrement(&g_ss.eyeFrames[e]);
  } else {
    ++g_flatRun;
    g_freshEye[0] = g_freshEye[1] = 0;
    // Eye pictures older than this are never shown again.
    if (g_flatRun >= kFlatAfter) g_haveEye[0] = g_haveEye[1] = 0;
  }

  int pair = g_ctl.stereoPair != 0;
  int e = f.eye & 1;
  if (pair) {
    // Both eyes of a pair are submitted together once the second one is in.
    if (fresh && g_freshEye[0] && g_freshEye[1]) {
      if (g_flatMode) {
        g_flatMode = 0;
        g_blackSubmitting = 0;
        menu_release();
        vr_capi_overlay_hide();
        flatglow_hide();
        log_line("STEREO 3D picture shown, flat screen hidden. frame=%d (flat screen: %d frames, placed %d times, followed you %d times)", (int)g_ctl.worldFrames, g_fl.shown, g_fl.placements, g_fl.recentered);
        fade_in_begin("3D takes over from the 2D screen");
      }
      if (!g_fi.firstDone) { g_fi.firstDone = 1; if (!g_fi.begun) fade_in_begin("the first 3D picture"); }
      submit_eyes();
      offer_picture();
      g_submittedNow = 1;
      g_freshEye[0] = g_freshEye[1] = 0;
      InterlockedIncrement(&g_ss.pairs);
      if (g_ctl.chestCam && g_ctl.monitorView) {   // 1.7.38: every N pairs the next game picture is the chest camera's
        int every = (int)g_ctl.chestCamEvery; if (every < 1) every = 1; if (every > 8) every = 8;
        if (++g_specCtr >= every) { g_specCtr = 0; ++g_sp.asked; InterlockedExchange(&g_ctl.stereoSpecNext, 1); }
      } else { g_specCtr = 0; InterlockedExchange(&g_ctl.stereoSpecNext, 0); g_haveSpec = 0; }
      double gap = (double)(qpc_now() - g_firstEyeQpc) * 1000.0 / (double)qpc_freq();
      g_ss.pairGapMsSum += gap;
      if (gap > g_ss.pairGapMsMax) g_ss.pairGapMsMax = gap;
    } else if (!fresh && (g_flatMode || g_flatRun >= kFlatAfter)) {
      if (!g_flatMode) enter_flat_mode();
      show_flat(bb);
      InterlockedIncrement(&g_ss.flatFrames);
    }
    if (fresh && !g_submittedNow) {  // first eye done: the next game frame is the other eye, right away
      g_firstEyeQpc = qpc_now();
      InterlockedExchange(&g_ctl.stereoNextEye, 1 - e);
      InterlockedExchange(&g_ctl.stereoPairPhase, 1);
    } else {                         // pair finished (or no 3D frame): the next 3D frame starts a new pair
      InterlockedExchange(&g_ctl.stereoNextEye, 0);
      InterlockedExchange(&g_ctl.stereoPairPhase, 0);
    }
  } else {
    // 0.21-0.23 behaviour: one eye per headset frame, the other one frame older.
    InterlockedExchange(&g_ctl.stereoPairPhase, 0);
    if (fresh) InterlockedExchange(&g_ctl.stereoNextEye, 1 - e);
    if (g_haveEye[0] && g_haveEye[1] && g_flatRun < kFlatAfter) {
      if (g_flatMode) {
        g_flatMode = 0;
        g_blackSubmitting = 0;
        menu_release();
        vr_capi_overlay_hide();
        flatglow_hide();
        log_line("STEREO 3D picture shown, flat screen hidden. frame=%d (flat screen: %d frames, placed %d times, followed you %d times)", (int)g_ctl.worldFrames, g_fl.shown, g_fl.placements, g_fl.recentered);
        fade_in_begin("3D takes over from the 2D screen");
      }
      if (!fresh) InterlockedIncrement(&g_ss.repeatFrames);
      submit_eyes();
      if (fresh) offer_picture();
      g_submittedNow = 1;
    } else if (!fresh && (g_flatMode || g_flatRun >= kFlatAfter)) {
      if (!g_flatMode) enter_flat_mode();
      show_flat(bb);
      InterlockedIncrement(&g_ss.flatFrames);
    }
  }
  shot_expire();
  bb->Release();
  return 1;
}

// 1.2 monitor view: the finished eye picture for the PC window (the probe's own texture, hands and wand already drawn into it).
// Always the wanted eye; the other one only while the wanted one has no picture yet (start of the session).
// age = real frames since that picture was taken (0 or 1 in pair mode: a picture is refreshed every pair).
int stereo_monitor_source(int wantEye, void** tex, float* pose34, int* eyeUsed, int* age, float* projection, int* spectator) {
  if (g_ctl.chestCam && g_haveSpec && g_specTex && g_monTick - g_specTick < 60) {   // 1.7.38: the chest camera's picture (level, so no roll to follow)
    *tex = g_specTex;
    for (int i = 0; i < 12; ++i) pose34[i] = 0.0f;
    pose34[0] = pose34[5] = pose34[10] = 1.0f;
    *eyeUsed = 0;
    *age = (int)(g_monTick - g_specTick);
    projection[0] = g_specTan[0]; projection[1] = g_specTan[1]; projection[2] = 0;
    *spectator = 1;
    ++g_sp.shown;
    return 1;
  }
  int e = wantEye ? 1 : 0;
  if (!g_haveEye[e] || !g_eyeTex[e]) {
    e = 1 - e;
    if (!g_haveEye[e] || !g_eyeTex[e]) return 0;
  }
  *tex = g_eyeTex[e];
  for (int i = 0; i < 12; ++i) pose34[i] = g_eyePose[e][i];
  *eyeUsed = e;
  *age = (int)(g_monTick - g_eyeTick[e]);
  for (int i = 0; i < 3; ++i) projection[i] = g_monitorProjection[e][i];
  *spectator = 0;
  return 1;
}

void stereo_after_present() {
  VrSection vr;
  if (!vr.ok()) return;
  if (!g_didFrame || !g_ctl.stereoWanted || !vr_capi_is_scene()) return;
  if (g_specNow) return;   // 1.7.38: the chest-camera picture is not a headset frame: no wait, and the pair bookkeeping stays as it was
  // Eye pairs: after the first eye of a pair there is no frame wait - the
  // game goes straight on to the second eye. Never twice in a row.
  if (g_ctl.stereoActive && g_ctl.stereoPair && g_lastFresh && !g_submittedNow && !g_skippedWaitLast) {
    g_skippedWaitLast = 1;
    InterlockedIncrement(&g_ss.waitSkipped);
    return;
  }
  g_skippedWaitLast = 0;
  // 1.7.153 the FPS limit (ratecap.h): a new pair on every Nth headset frame. Only while a 3D pair is being shown (never on the 2D screen, never with the menu's frozen world).
  {
    static LONG s_capLastChoice = -1; static int s_capLastN = -1; static LONG s_capSleeps; static double s_capSleptMs;
    const int cap = ratecap::valid((int)g_ctl.vrFpsCap);
    const float display = vr_capi_display_hz();
    const int n = ratecap::divisor((double)display, cap);
    const int paced = ratecap::fractional((double)display, cap);   // 1.7.170: a number that is not a whole share is paced (1, 2, 1, 2 ... frames)
    g_capDiv = paced ? 1 : n;
    g_capShare = paced && display > 20.0f ? (double)cap / (double)display : 1.0 / (double)n;
    static ratecap::Pacer s_pacer; static LONG s_pacedPairs, s_pacedSleeps;
    const int nPair = paced ? ratecap::frames_for(s_pacer, g_waitDoneQpc, qpc_freq(), (double)display, cap) : n;   // 1.7.172: a schedule (a late pair is made up), was a fixed pattern
    if (paced) InterlockedIncrement(&s_pacedPairs);
    if (cap != s_capLastChoice || n != s_capLastN) {
      s_capLastChoice = cap; s_capLastN = n;
      if (paced) log_line("FPSCAP paced: %d is not a whole share of %.1f Hz: each pair is shown for %d or %d headset frames on a schedule that averages %d FPS and makes up a late pair (whole shares like %.0f are the most even) | paced pairs so far %ld, of them slept %ld", cap, (double)display, (int)((double)display / cap), (int)((double)display / cap) + 1, cap, (double)display / 2.0, (long)s_pacedPairs, (long)s_pacedSleeps);
      log_line("FPSCAP limit=%d%s headset=%.1f Hz -> %sa new picture pair on every %d%s headset frame = %.1f FPS (%s); sleeps so far %ld (%.0f ms)", cap, cap == ratecap::kHalf ? " (half rate)" : cap == ratecap::kThird ? " (a third)" : "", (double)display, paced ? "PACED (see the line above; the whole-share figures that follow do not apply) " : "", n, n == 1 ? "st" : n == 2 ? "nd" : n == 3 ? "rd" : "th",
               ratecap::effective_fps((double)display, cap), cap == 0 ? "off" : !ratecap::rate_known((double)display) ? (cap > ratecap::kThird ? "the headset does not report its rate: a plain timer holds the limit" : "the headset does not report its rate: half / a third cannot be used, pick a number") : n == 1 ? "the limit is not below the headset's rate: nothing to do" : "SteamVR / Virtual Desktop fill the frames in between", (long)s_capSleeps, s_capSleptMs);
    }
    static int64_t s_capFreeLast;   // 1.7.154: the headset's rate is unknown: when the last pair was let through
    const int freeRun = cap > ratecap::kThird && !ratecap::rate_known((double)display);
    if ((n > 1 || paced || freeRun) && g_ctl.stereoActive && g_ctl.stereoPair && !g_flatMode && g_waitDoneQpc) {
      const int64_t ticks = freeRun ? ratecap::sleep_ticks_free(qpc_now(), s_capFreeLast, qpc_freq(), cap) : ratecap::sleep_ticks_n(qpc_now(), g_waitDoneQpc, qpc_freq(), (double)display, nPair);
      if (paced && ticks > 0) InterlockedIncrement(&s_pacedSleeps);
      if (ticks > 0) {
        const int64_t target = qpc_now() + ticks;
        // Windows' plain Sleep can overshoot by up to 15 ms (its default timer step), which would miss the headset frame. So: a high-resolution timer
        // (Windows 10 1803 and later) for all but the last 1.5 ms, then yield until the deadline. Without that timer: yield only (exact, costs some CPU).
        // WaitGetPoses below still synchronizes to the compositor.
        static HANDLE s_tm; static int s_tmTried;
        if (!s_tmTried) {
          s_tmTried = 1;
          s_tm = CreateWaitableTimerExW(nullptr, nullptr, 0x00000002 /* CREATE_WAITABLE_TIMER_HIGH_RESOLUTION */, 0x1F0003 /* TIMER_ALL_ACCESS */);
          log_line("FPSCAP timer: %s", s_tm ? "high-resolution timer" : "no high-resolution timer on this Windows: the limiter yields instead of sleeping (exact, a little more CPU)");
        }
        const int64_t coarse = ticks - qpc_freq() * 15 / 10000;   // all but 1.5 ms
        if (s_tm && coarse > 0) {
          LARGE_INTEGER due; due.QuadPart = -(coarse * 10000000 / qpc_freq());   // relative, in 100 ns
          if (due.QuadPart < 0 && SetWaitableTimer(s_tm, &due, 0, nullptr, nullptr, FALSE)) WaitForSingleObject(s_tm, 60);
        }
        while (qpc_now() < target) SwitchToThread();
        ++s_capSleeps; s_capSleptMs += (double)ticks * 1000.0 / (double)qpc_freq();
      }
      s_capFreeLast = qpc_now();
    } else s_capFreeLast = 0;
  }
  float pose[12];
  int valid = 0;
  int64_t t0 = qpc_now();
  stage_r(ST_WAIT_POSES);
  int e = vr_capi_wait_get_poses(pose, &valid);
  stage_r(ST_AFTER_PRESENT);
  prof_add(PF_WAITPOSES, t0);
  double ms = (double)(qpc_now() - t0) * 1000.0 / (double)qpc_freq();
  g_waitDoneQpc = qpc_now();
  InterlockedIncrement(&g_ss.waits);
  g_ss.waitMsSum += ms;
  if (ms > g_ss.waitMsMax) g_ss.waitMsMax = ms;
  if (e != 0) {
    g_ss.lastWaitErr = e;
    safety_issue(IS_WAIT);
    if (InterlockedIncrement(&g_ss.waitFail) <= 5) log_line("STEREO WaitGetPoses error %d", e);
  }
  if (valid) {
    int recenter = InterlockedExchange(&g_ctl.recenterRequest, 0);
    vr_publish_pose(pose, recenter);
    stage_r(ST_CONTROLLERS);
    { ProfScope ps(PF_CTRL); controllers_poll(); }   // 0.33: Quest controllers -> pad state and hand poses
    { ProfScope ps(PF_MENU); vrmenu_tick(g_ctl.worldFrames); }   // 0.53: the in-VR menu (draws, reads its laser pointer)
    if (recenter) { g_flatPlaced = 0; engine_comfort_recenter(); }
    for (int i = 0; i < 12; ++i) g_lastPose[i] = pose[i];
    g_haveLastPose = 1;
  } else {
    InterlockedIncrement(&g_ss.poseInvalid);
    safety_issue(IS_POSE);
    vr_publish_pose(nullptr, 0);
  }
  if (vr_capi_poll_quit()) {
    log_line("STEREO: SteamVR asked the application to quit - closing the headset session (the game keeps running).");
    InterlockedExchange(&g_ctl.stereoWanted, 0);
  }
}

// The headset's eye data can change while playing (eye-distance wheel).
static void refresh_eye_params() {
  GbvrEyeParams ep[2];
  if (!g_ctl.stereoActive || !vr_capi_eye_params(0, &ep[0]) || !vr_capi_eye_params(1, &ep[1])) return;
  StereoParams p = g_rp;
  int changed = 0;
  for (int e = 0; e < 2; ++e) {
    float v[5] = {ep[e].left, ep[e].right, ep[e].top, ep[e].bottom, ep[e].eyeToHead[3]};
    float* dst[5] = {&p.left[e], &p.right[e], &p.top[e], &p.bottom[e], &p.eyeX[e]};
    for (int i = 0; i < 5; ++i) {
      if (!vm::is_finite_f(v[i])) return;
      if (vm::dabs((double)v[i] - *dst[i]) > 2e-4) changed = 1;
      *dst[i] = v[i];
    }
    if (!(p.left[e] < 0 && p.right[e] > 0 && p.top[e] < 0 && p.bottom[e] > 0)) return;
  }
  if (!changed || !(p.eyeX[0] < -0.02f && p.eyeX[0] > -0.045f && p.eyeX[1] > 0.02f && p.eyeX[1] < 0.045f)) return;
  double needH, needV;
  stereo::required_fov(p.left, p.right, p.top, p.bottom, &needH, &needV);
  p.needTanH = (float)needH; p.needTanV = (float)needV;
  g_rp = p;
  AcquireSRWLockExclusive(&g_lock);
  g_params = p;
  ReleaseSRWLockExclusive(&g_lock);
  InterlockedIncrement(&g_ss.paramChanges);
  log_line("STEREO headset eye data changed: eye separation %.1f mm needTanH=%.5f needTanV=%.5f",
           (double)(p.eyeX[1] - p.eyeX[0]) * 1000.0, needH, needV);
}

void stereo_report(LONG frame) {
  if (g_ctl.chestCam || g_sp.asked)
    log_line("CHESTCAMPIC frame=%d on=%d every=%d pairs | asked %ld, pictures taken %ld, drawn in the window %ld times, no texture %ld | gap between pictures avg %.1f ms max %.1f ms | picture ready %d",
             (int)frame, (int)g_ctl.chestCam, (int)g_ctl.chestCamEvery, g_sp.asked, g_sp.taken, g_sp.shown, g_sp.noTex, g_sp.taken > 1 ? g_sp.gapSum / (double)(g_sp.taken - 1) : 0.0, g_sp.gapMax, g_haveSpec);
  if (!g_ctl.stereoWanted && !g_ctl.stereoActive) return;
  VrSection vr;
  if (!vr.ok()) return;
  refresh_eye_params();
  // 0.95: the black void (SteamVR's grid room faded out behind the flat 2D screen). gridAlphaNow is -1 when no headset session answers.
  log_line("FLATVOIDSUM frame=%d void=%d applied=%d flatFrames=%d fadeCalls=%d gridAlphaWorstSeen=%.2f gridAlphaNow=%.2f lastCheck=%.2f flatMode=%d glow=%d%% steady=%d blackFrames=%d haveBlackTex=%d blackOK=%ld blackFail=%ld blackNow=%d", (int)frame, (int)g_ctl.flatVoid, g_voidApplied,
           g_fl.shown, g_fl.voidCalls, g_fl.gridAlphaMax, vr_capi_grid_alpha(), g_fl.gridAlphaLast, g_flatMode, (int)g_ctl.flatGlowPct, (int)g_ctl.flatGlowSteady,
           (int)g_ctl.flatBlack, g_blackTex ? 1 : 0, (long)g_fl.blackOK, (long)g_fl.blackFail, g_blackSubmitting);
  // 1.3: the fade up from black, the ring cursor on the 2D screen, the dim behind the VR menu, the grid room's state right at the start
  log_line("FADEINSUM frame=%d fadeInMs=%d begun=%d cleared=%d removedByForce=%d state=%d startGridAlpha=%.2f firstDone=%d",
           (int)frame, (int)g_ctl.fadeInMs, (int)g_fi.begun, (int)g_fi.cleared, (int)g_fi.forced, g_fi.state, (double)vr_capi_start_black_alpha(), g_fi.firstDone);
  log_line("FLATUISUM frame=%d cursorOn=%d size=%d%% cursorDrawn=%d noLaser=%d hiddenWhileVrMenu=%d dim=%d dimNow=%.2f dimFrames=%d",
           (int)frame, (int)g_ctl.flatCursor, (int)g_ctl.flatCursorPct, (int)g_cu.cursorDraws, (int)g_cu.cursorNone, (int)g_cu.cursorHidden, (int)g_ctl.menuDimFlat,
           (double)g_dimNow, (int)g_cu.dimFrames);
  flatcursor_report((long)frame);
  // 1.1: how the 2D screen looked last (size in metres and in degrees of your view, bend, how often it was put in front of you / moved back / re-placed from the menu)
  log_line("FLATLOOKSUM frame=%d width=%.2f m height=%.2f m distance=%.2f m drop=%.0f cm covers=%.0f x %.0f deg bend=%.3f (%d %%) size=%d %% fade=%.2f looksLogged=%d placedAgain(menu)=%d movedBack(looked away)=%d placements=%d",
           (int)frame, (double)g_look.widthM, (double)g_look.heightM, (double)g_look.distM, (double)g_look.dropM * 100.0, (double)g_look.hDeg, (double)g_look.vDeg, (double)g_look.curve, (int)g_ctl.flatCurvePct,
           (int)g_ctl.flatSizePct, (double)g_look.fade, g_look.looks, g_look.replaced, g_fl.recentered, g_fl.placements);
  float liveH = 0, liveV = 0;
  if (g_game.hookBytesOK) {
    liveH = *(const volatile float*)rva(layout::kRvaTanHalfFovH);
    liveV = *(const volatile float*)rva(layout::kRvaTanHalfFovV);
  }
  gpu_match_check();   // 1.7.87
  if (g_dev) {   // 0.81: graphics memory of this program (the 0.80 crash was inside Windows' own graphics code; this shows whether memory ran short)
    IDXGIDevice* dd = nullptr; IDXGIAdapter* ad = nullptr; IDXGIAdapter3* a3 = nullptr;
    if (SUCCEEDED(g_dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dd)) && dd) {
      if (SUCCEEDED(dd->GetAdapter(&ad)) && ad && SUCCEEDED(ad->QueryInterface(__uuidof(IDXGIAdapter3), (void**)&a3)) && a3) {
        DXGI_QUERY_VIDEO_MEMORY_INFO mi;
        ZeroMemory(&mi, sizeof(mi));
        if (SUCCEEDED(a3->QueryVideoMemoryInfo(0, DXGI_MEMORY_SEGMENT_GROUP_LOCAL, &mi)))
          log_line("VIDMEM used=%u MB of budget %u MB (available to reserve %u MB, reserved %u MB) picture=%ux%u", (unsigned)(mi.CurrentUsage >> 20), (unsigned)(mi.Budget >> 20), (unsigned)(mi.AvailableForReservation >> 20), (unsigned)(mi.CurrentReservation >> 20), (unsigned)g_texW, (unsigned)g_texH);
        a3->Release();
      }
      if (ad) ad->Release();
      dd->Release();
    }
  }
  log_line("STEREOSTATE present=%d wanted=%d active=%d session=\"%s\" flatMode=%d eyeFrames=%d/%d flatFrames=%d "
           "repeatFrames=%d seqSkips=%d submitOK=%d/%d submitFail=%d/%d lastSubmitErr=%d overlayOK=%d overlayFail=%d "
           "lastOverlayErr=%d waits=%d waitFail=%d lastWaitErr=%d waitAvgMs=%.2f waitMaxMs=%.2f poseInvalid=%d "
           "boundsInside=%d/%d tanH=%.4f tanV=%.4f engineTanNow=%.4f/%.4f strength=%d swap=%d headMove=%d "
           "pairMode=%d wide=%d pairs=%d waitSkipped=%d pairGapAvgMs=%.2f pairGapMaxMs=%.2f eyePixels=%dx%d "
           "picture=%ux%u height=%d world=%d pictureLevel=%d",
           (int)frame, (int)g_ctl.stereoWanted, (int)g_ctl.stereoActive, vr_capi_status(), g_flatMode,
           (int)g_ss.eyeFrames[0], (int)g_ss.eyeFrames[1], (int)g_ss.flatFrames, (int)g_ss.repeatFrames,
           (int)g_ss.seqSkips, (int)g_ss.submitOK[0], (int)g_ss.submitOK[1], (int)g_ss.submitFail[0],
           (int)g_ss.submitFail[1], g_ss.lastSubmitErr, (int)g_ss.overlayOK, (int)g_ss.overlayFail,
           g_ss.lastOverlayErr, (int)g_ss.waits, (int)g_ss.waitFail, g_ss.lastWaitErr,
           g_ss.waits ? g_ss.waitMsSum / g_ss.waits : 0.0, g_ss.waitMsMax, (int)g_ss.poseInvalid, g_boundsInside[0],
           g_boundsInside[1], g_lastTanH, g_lastTanV, liveH, liveV, (int)g_ctl.stereoStrengthPct,
           (int)g_ctl.swapEyes, (int)g_ctl.headMove, (int)g_ctl.stereoPair, (int)g_ctl.stereoWide, (int)g_ss.pairs,
           (int)g_ss.waitSkipped, g_ss.pairs ? g_ss.pairGapMsSum / g_ss.pairs : 0.0, g_ss.pairGapMsMax,
           (int)((g_eyeBounds[0][2] - g_eyeBounds[0][0]) * g_texW), (int)((g_eyeBounds[0][3] - g_eyeBounds[0][1]) * g_texH),
           g_texW, g_texH, (int)g_ctl.sizePct, (int)g_ctl.worldPct, modes_active_level());
  // 0.43: frame-rate evidence. pairs/s is what the player sees as frames per second per eye (a pair = both eyes);
  // workAvg is the game's own time per pair, which has to stay under one display period (11.1 ms at 90 Hz).
  int64_t now = qpc_now();
  double secs = g_lastReportQpc ? (double)(now - g_lastReportQpc) / (double)qpc_freq() : 0.0;
  g_lastReportQpc = now;
  double pairsPerSec = secs > 0.1 ? (g_ctl.stereoPair ? g_ss.pairs : g_ss.works) / secs : 0.0;
  const double dispHz = (double)vr_capi_display_hz();
  if (dispHz > 30.0) g_workBudgetMs = rate::work_budget_ms(dispHz) * (double)g_capDiv;   // 0.98: the budget follows the headset's refresh rate (72 / 80 / 90 / 120 Hz)
  log_line("PACING frame=%d seconds=%.2f pairsPerSecond=%.1f workAvgMs=%.2f workMaxMs=%.2f workOverBudget(%.1fms)=%d/%d "
           "waitAvgMs=%.2f flatMode=%d menuFast=%d displayHz=%.1f", (int)frame, secs, pairsPerSec,
           g_ss.works ? g_ss.workMsSum / g_ss.works : 0.0, g_ss.workMsMax, g_workBudgetMs, (int)g_ss.workOver, (int)g_ss.works,
           g_ss.waits ? g_ss.waitMsSum / g_ss.waits : 0.0, g_flatMode, (int)g_ctl.menuFast, dispHz);
  {   // 1.7.100 PERF: one short line about every 20 s that the player log keeps (PACING / SMOOTH / RATEFIT stay in the diagnostics log): is the game delivering the headset's rate, how much time one eye pair takes, how many frames were late
    static int s_perfN;
    if ((s_perfN++ % 10) == 0 && secs > 0.1 && !g_flatMode && g_ctl.stereoActive)
      log_line("PERF t=%.0fs delivering %.1f of %.1f Hz | game work per eye pair avg %.1f ms (max %.1f, budget %.1f ms, over budget %d of %d) | wait %.1f ms | picture level %d | whole run: steady %.1f%% late %.1f%% hitches %.2f%% of %ld frames, longest gap %.0f ms",
               qpc_ms() / 1000.0, pairsPerSec, dispHz, g_ss.works ? g_ss.workMsSum / g_ss.works : 0.0, g_ss.workMsMax, g_workBudgetMs, (int)g_ss.workOver, (int)g_ss.works,
               g_ss.waits ? g_ss.waitMsSum / g_ss.waits : 0.0, (int)g_ctl.pictureLevel,
               g_sm.totN ? 100.0 * (double)g_sm.totSteady / (double)g_sm.totN : 0.0, g_sm.totN ? 100.0 * (double)g_sm.totLate / (double)g_sm.totN : 0.0, g_sm.totN ? 100.0 * (double)g_sm.totHitch / (double)g_sm.totN : 0.0, (long)g_sm.totN, g_sm.totMax);
  }
  if (g_sm.n > 0) {   // 0.98 SMOOTH: this report window; printed when something was not smooth, otherwise about every 10th window
    const double per = g_workBudgetMs > 5.0 ? g_workBudgetMs : 11.1;
    if (g_sm.late + g_sm.hitch > 0 || (++g_sm.logs % 10) == 1)
      log_line("SMOOTH frame=%d pairs=%ld mean gap %.1f ms (a display period is about %.1f ms): steady %ld, one frame late %ld, hitches (2+ frames) %ld, longest gap %.0f ms | whole run: steady %.1f%% late %.1f%% hitches %.2f%% of %ld pairs, longest %.0f ms (late or hitch = the picture/animation stepped; SteamVR shows a guessed frame)",
               (int)frame, g_sm.n, g_sm.sum / (double)g_sm.n, per, g_sm.steady, g_sm.late, g_sm.hitch, g_sm.maxGap,
               100.0 * (double)g_sm.totSteady / (double)g_sm.totN, 100.0 * (double)g_sm.totLate / (double)g_sm.totN, 100.0 * (double)g_sm.totHitch / (double)g_sm.totN, g_sm.totN, g_sm.totMax);
    g_sm.n = g_sm.steady = g_sm.late = g_sm.hitch = 0; g_sm.sum = 0.0; g_sm.maxGap = 0.0;
  }
  if (g_ss.works >= 100 && !g_flatMode && g_ctl.stereoActive) {   // 0.98 RATEFIT: which refresh rates this PC and picture size could hold, from the measured work per pair
    const double workMs = g_ss.workMsSum / g_ss.works;
    static const int cand[4] = {120, 90, 80, 72};
    char fb[320]; int fl = 0; fb[0] = 0;
    for (int i = 3; i >= 0; --i) {
      const double mg = rate::margin_ms((double)cand[i], workMs, rate::kTailMs);
      fl += wsprintfA(fb + fl, "%s%d Hz: %s (%s%d.%d ms left)", fl ? " | " : "", cand[i], mg >= rate::kSpareMs ? "fits" : "too tight", mg < 0 ? "-" : "", (int)(mg < 0 ? -mg : mg), (int)((mg < 0 ? -mg : mg) * 10.0) % 10);
    }
    log_line("RATEFIT frame=%d display=%.1f Hz, game work %.2f ms per pair (max %.1f) + graphics tail assumed %.1f ms | %s | highest that fits: %d Hz. (Set the rate in Virtual Desktop > Settings > Streaming; the game keeps its own limit, so only try a rate marked fits.)",
             (int)frame, dispHz, workMs, g_ss.workMsMax, rate::kTailMs, fb, rate::best_fit(workMs, rate::kTailMs, cand, 4));
  }
  if (g_texW && g_ctl.stereoActive && (g_sharpLogs < 3 || (++g_sharpTick % 12) == 0)) {   // 0.98 SHARPNESS: how many pixels each eye gets compared with what SteamVR recommends
    ++g_sharpLogs;
    unsigned rw = 0, rh = 0;
    vr_capi_recommended_size(&rw, &rh);
    const double ew = (double)((g_eyeBounds[0][2] - g_eyeBounds[0][0]) * g_texW), eh = (double)((g_eyeBounds[0][3] - g_eyeBounds[0][1]) * g_texH);
    const double ar = rate::area_ratio(ew, eh, (double)rw, (double)rh), sr = rate::side_ratio(ew, eh, (double)rw, (double)rh);
    log_line("SHARPNESS picture=%ux%u (level %d, the engine's largest is 3840x2880) eye pixels %.0fx%.0f vs SteamVR's recommended %ux%u = %.0f%% of the pixels (%.0f%% per side). "
             "Below 100%% the headset image can be a little soft, but this is the biggest picture the game can draw; the rest of the sharpness comes from Virtual Desktop (graphics quality, bitrate, sharpening) and SteamVR's render resolution.",
             (unsigned)g_texW, (unsigned)g_texH, modes_active_level(), ew, eh, rw, rh, ar * 100.0, sr * 100.0);
  }
  {   // 1.7.63 PERFADVICE: delivery-rate problems alone must not permanently lower sharpness.
    static int s_bad, s_done;
    const double workAvg = g_ss.works ? g_ss.workMsSum / g_ss.works : 0.0;
    const double waitAvg = g_ss.waits ? g_ss.waitMsSum / g_ss.waits : 0.0;
    const double targetHz = dispHz > 30.0 ? (ratecap::fractional(dispHz, (int)g_ctl.vrFpsCap) ? (double)ratecap::valid((int)g_ctl.vrFpsCap) : dispHz / (double)g_capDiv) : 0.0;   // 1.7.153: with an FPS limit the wanted rate is the limit's
    if (g_capDiv > 1 || g_ctl.vrFpsCap) log_line("FPSCAP status: limit setting %d, a new pair on every %d headset frame(s) (1 = paced or none) of %.1f Hz = target %.1f FPS; delivered in this window %.1f FPS (%s)", (int)g_ctl.vrFpsCap, g_capDiv, dispHz, targetHz, pairsPerSec,
                                                 g_capDiv <= 1 && !ratecap::fractional(dispHz, (int)g_ctl.vrFpsCap) ? "no limit in effect" : pairsPerSec > targetHz * 0.97 && pairsPerSec < targetHz * 1.03 ? "the limit is holding" : pairsPerSec <= targetHz * 0.97 ? "below the limit: the PC is slower than the limit, or the menu / a 2D screen was up in this window" : "above the limit");
    const int slowDelivery = targetHz > 0.0 && pairsPerSec > 1.0 && pairsPerSec < 0.85 * targetHz;
    const int renderHot = g_ss.works >= safety::PerfWatch::kMinWorks && g_workBudgetMs > 2.0 &&
      (workAvg >= safety::PerfWatch::kHotFraction * g_workBudgetMs || g_ss.workOver * 4 >= g_ss.works);
    const int bad = !g_flatMode && g_ctl.stereoActive && slowDelivery && !vrmenu_is_open();
    s_bad = bad ? s_bad + 1 : 0;
    if (!s_done && s_bad >= 8) {
      s_done = 1;
      if (!renderHot || waitAvg >= safety::PerfWatch::kMaxWaitMs)
        log_line("PERFADVICE delivery stayed low (%.1f of %.1f Hz) but game work is %.1f/%.1f ms and wait is %.1f ms: keeping picture level %d because lowering resolution is not proven to help",
                 pairsPerSec, targetHz, workAvg, g_workBudgetMs, waitAvg, (int)g_ctl.pictureLevel);
      else
        log_line("PERFADVICE delivery and game render work are both under pressure (%.1f of %.1f Hz, work %.1f/%.1f ms). Auto-quality waits for the measured PerfWatch safety check before saving a lower picture level. You can lower it yourself now: VR menu (F12) > View > Resolution, then restart the game.",
                 pairsPerSec, targetHz, workAvg, g_workBudgetMs);
    }
  }
  int vHz10 = 0, pHz10 = 0, sHz10 = 0;
  if (g_ctl.diagTiming) {
    static char tb[1024];
    int hHz10 = 0;
    stage_r(ST_TIMING_REPORT);
    vr_capi_timing_report(tb, (int)sizeof(tb), &vHz10, &hHz10, &pHz10, &sHz10);
    stage_r(ST_REPORT);
    if (tb[0]) log_line("%s", tb);
    else log_line("COMPOSITOR no timing data this time (SteamVR gave none)");
    // 0.45: the rate for the notes is the measured one from the frame times, or else the presents per second
    // (PerfWatch below keeps using only the strictly measured one)
    int rHz10 = vHz10 > 0 ? vHz10 : pHz10;
    if (rHz10 > 0 && hHz10 > 0) {
      int vi = (rHz10 + 5) / 10;
      int differs = rHz10 * 20 < hHz10 * 19 || rHz10 * 19 > hHz10 * 20;   // more than ~5 % apart
      if (vi != g_noteVsyncHz && (differs || g_noteVsyncHz >= 0)) {
        g_noteVsyncHz = vi;
        if (differs)
          log_line("RATE NOTE the headset reports %d.%d Hz but the SteamVR compositor delivers frames at %d.%d Hz. "
                   "The game cannot run faster than the compositor. With Virtual Desktop: in the headset open the Virtual "
                   "Desktop menu -> Settings -> Streaming and set the refresh rate to 90 Hz (then restart SteamVR / the game). "
                   "pairsPerSecond above shows what the game really reaches.", hHz10 / 10, hHz10 % 10, rHz10 / 10, rHz10 % 10);
        else
          log_line("RATE NOTE the compositor now runs at %d.%d Hz (headset reports %d.%d Hz).", rHz10 / 10, rHz10 % 10,
                   hHz10 / 10, hHz10 % 10);
      } else if (g_noteVsyncHz < 0 && !differs) {
        g_noteVsyncHz = vi;
        log_line("RATE OK the compositor runs at %d.%d Hz, as the headset reports.", rHz10 / 10, rHz10 % 10);
      }
    }
    // 0.45: advice from the measured numbers (log only, at most every 5th report): the game delivers clearly fewer frame
    // pairs than the display shows although its own work fits one display period -> SteamVR is filling the gap with
    // guessed frames (judder). The game's work per pair plus the graphics card's tail has to fit the display period.
    if (g_ctl.stereoActive && rHz10 > 0 && secs > 0.1 && g_ss.works >= 100 && g_ss.flatFrames == g_lastFlatFrames) {
      double workMs = g_ss.workMsSum / g_ss.works, dispHz = rHz10 / 10.0;
      if (g_capShare > 0.999 && pairsPerSec < 0.88 * dispHz && workMs < 1000.0 / dispHz && (++g_adviceReports % 5) == 1) {
        int steady = 60;
        const int cand[4] = {120, 90, 80, 72};
        for (int i = 0; i < 4; ++i) if (1000.0 / cand[i] >= workMs + 4.5) { steady = cand[i]; break; }
        log_line("RATE ADVICE the game made %.1f frame pairs per second but the display shows %.1f Hz (SteamVR fills the gap with "
                 "guessed frames, which judders). One pair needs %.2f ms of PC time here plus about 3-4 ms of graphics-card time, "
                 "so a steady rate is %d Hz. Set Virtual Desktop's refresh rate to %d Hz for a steady picture, or lower the game's "
                 "own graphics (shadows, reflections) / the picture level (Insert) to try a higher rate.", pairsPerSec, dispHz, workMs,
                 steady, steady);
      }
    }
  }
  // 0.44 fail-safes ------------------------------------------------------------------------------------------------
  // (a) the PC cannot hold the compositor's rate with this picture size: next start uses a smaller one
  {
    LONG flatDelta = g_ss.flatFrames - g_lastFlatFrames;
    g_lastFlatFrames = g_ss.flatFrames;
    if (g_ctl.stereoPair && g_perf.update(secs > 0.1 ? (int)g_ss.works : 0, pairsPerSec, (int)((double)vHz10 * g_capShare + 0.5) /* 1.7.172: a paced limit (60 of 90) is not 'under the compositor rate' */, (int)flatDelta,
                                          g_ss.waits ? g_ss.waitMsSum / g_ss.waits : 0.0,
                                          g_ss.works ? g_ss.workMsSum / g_ss.works : 0.0, g_workBudgetMs, (int)g_ss.workOver)) {
      safety_issue(IS_PERF_FALLBACK);
      log_line("SAFETY PERF the game delivered under 85 %% of the compositor rate (%.1f pairs/s of %d.%d Hz) for %d reports in a row AND measured render work was near/over budget; "
               "work per pair %.2f / %.2f ms, over-budget %d/%d", pairsPerSec, vHz10 / 10, vHz10 % 10, safety::PerfWatch::kBadReports,
               g_ss.works ? g_ss.workMsSum / g_ss.works : 0.0, g_workBudgetMs, (int)g_ss.workOver, (int)g_ss.works);
      if (modes_active_level() >= 3) safety_fallback_picture(2, "the PC could not keep up with the 3840x2880 picture");
      else log_line("SAFETY PERF nothing bigger to lower automatically (picture level %d)", modes_active_level());
    }
  }
  // (b) the compositor never accepts a picture: probably the picture is too big for it
  if (g_ss.submitOK[0] == 0 && g_ss.submitFail[0] >= 20 && modes_active_level() >= 3)
    safety_fallback_picture(2, "SteamVR rejected every eye picture (20 submit errors, none accepted)");
  // (c) graphics memory: a big picture plus the game's own buffers
  if ((++g_vramReports % 8) == 1 && g_dev) {
    IDXGIDevice* dd = nullptr; IDXGIAdapter* ad = nullptr; IDXGIAdapter3* a3 = nullptr;
    if (SUCCEEDED(g_dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dd)) && dd && SUCCEEDED(dd->GetAdapter(&ad)) && ad &&
        SUCCEEDED(ad->QueryInterface(__uuidof(IDXGIAdapter3), (void**)&a3)) && a3) {
      DXGI_QUERY_VIDEO_MEMORY_INFO vi;
      ZeroMemory(&vi, sizeof(vi));
      if (SUCCEEDED(a3->QueryVideoMemoryInfo(0, DXGI_MEMORY_SEGMENT_GROUP_LOCAL, &vi))) {
        int high = vi.Budget > 0 && vi.CurrentUsage * 100 > vi.Budget * 92;
        if (high) safety_issue(IS_VRAM);
        log_line("VRAM usage=%u MB budget=%u MB%s", (unsigned)(vi.CurrentUsage >> 20), (unsigned)(vi.Budget >> 20),
                 high ? " (ABOVE 92 %: the picture may be too big for this graphics card's memory)" : "");
      }
    }
    if (a3) a3->Release();
    if (ad) ad->Release();
    if (dd) dd->Release();
  }
  safety_health(frame);
  g_ss.waitMsSum = 0; g_ss.waitMsMax = 0; g_ss.waits = 0;
  g_ss.works = 0; g_ss.workOver = 0; g_ss.workMsSum = 0; g_ss.workMsMax = 0;
  g_ss.pairs = 0; g_ss.pairGapMsSum = 0; g_ss.pairGapMsMax = 0;
}

// 1.7.102: the downloads run with diagnostics off, so stereo_report (and the PERF line inside it) never ran for players. This light version runs
// from the 30 s summary instead: it only READS the counters (deltas against its own last snapshot), takes no VR lock and changes nothing in the game.
void stereo_perf_light() {
  if (!g_ctl.stereoActive || g_flatMode) return;
  VrSection vr;
  if (!vr.ok()) return;
  static int64_t s_q; static LONG s_works, s_over, s_waits, s_pairs, s_n, s_late0, s_hitch0;
  static double s_workSum, s_waitSum;
  const int64_t now = qpc_now();
  const LONG works = g_ss.works, over = g_ss.workOver, waits = g_ss.waits, pairs = g_ss.pairs;
  const double workSum = g_ss.workMsSum, waitSum = g_ss.waitMsSum;
  const LONG n = g_sm.totN, late = g_sm.totLate, hitch = g_sm.totHitch;
  const double secs = s_q ? (double)(now - s_q) / (double)qpc_freq() : 0.0;
  const LONG dW = works - s_works, dO = over - s_over, dWt = waits - s_waits, dP = pairs - s_pairs, dN = n - s_n;
  const double workMax = g_ss.workMsMax, gapMax = g_sm.maxGap;
  s_q = now; s_works = works; s_over = over; s_waits = waits; s_pairs = pairs; s_n = n;
  const LONG lateOld = s_late0, hitchOld = s_hitch0;
  s_late0 = late; s_hitch0 = hitch;
  const double dWork = workSum - s_workSum, dWait = waitSum - s_waitSum;
  s_workSum = workSum; s_waitSum = waitSum;
  g_ss.workMsMax = 0; g_sm.maxGap = 0;   // window maxima (only touched when diagnostics are off, where nothing else resets them)
  if (secs < 5.0 || dW <= 0 || dN <= 0) return;
  const double hz = (double)vr_capi_display_hz();
  if (hz > 30.0) g_workBudgetMs = rate::work_budget_ms(hz) * (double)g_capDiv;
  const double got = (double)(g_ctl.stereoPair ? dP : dW) / secs;
  log_line("PERF t=%.0fs delivering %.1f of %.1f Hz | game work per eye pair avg %.1f ms (max %.1f, budget %.1f ms, over budget %d of %d) | wait %.1f ms | picture level %d | this window: late %d hitches %d of %d frames, longest gap %.0f ms | whole run: steady %.1f%% late %.1f%% hitches %.2f%% of %ld frames, longest %.0f ms",
           qpc_ms() / 1000.0, got, hz, dWork / (double)dW, workMax, g_workBudgetMs, (int)dO, (int)dW,
           dWt > 0 ? dWait / (double)dWt : 0.0, (int)g_ctl.pictureLevel, (int)(late - lateOld), (int)(hitch - hitchOld), (int)dN, gapMax,
           g_sm.totN ? 100.0 * (double)g_sm.totSteady / (double)g_sm.totN : 0.0, g_sm.totN ? 100.0 * (double)g_sm.totLate / (double)g_sm.totN : 0.0,
           g_sm.totN ? 100.0 * (double)g_sm.totHitch / (double)g_sm.totN : 0.0, (long)g_sm.totN, g_sm.totMax);
}

#if GBVR_HEADTRACK
// 0.54 data for a later "health ring behind the ghost": what Direct3D state is bound when the engine draws the ring (render thread,
// immediate context, read only): render target, depth buffer (present? size, format), depth test state.
void stereo_ring_probe(int n) {
  ID3D11DeviceContext* c = g_ctx;
  if (!c) { log_line("RINGPROBE %d: no context yet", n); return; }
  ID3D11RenderTargetView* rtv[2] = {nullptr, nullptr};
  ID3D11DepthStencilView* dsv = nullptr;
  c->OMGetRenderTargets(2, rtv, &dsv);
  UINT rw = 0, rh = 0, rf = 0, dw = 0, dh = 0, df = 0, dflags = 0;
  if (rtv[0]) {
    ID3D11Resource* r = nullptr; rtv[0]->GetResource(&r);
    ID3D11Texture2D* t = nullptr;
    if (r && SUCCEEDED(r->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&t)) && t) { D3D11_TEXTURE2D_DESC d; t->GetDesc(&d); rw = d.Width; rh = d.Height; rf = d.Format; t->Release(); }
    if (r) r->Release();
  }
  if (dsv) {
    D3D11_DEPTH_STENCIL_VIEW_DESC vd; dsv->GetDesc(&vd); df = vd.Format; dflags = vd.Flags;
    ID3D11Resource* r = nullptr; dsv->GetResource(&r);
    ID3D11Texture2D* t = nullptr;
    if (r && SUCCEEDED(r->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&t)) && t) { D3D11_TEXTURE2D_DESC d; t->GetDesc(&d); dw = d.Width; dh = d.Height; t->Release(); }
    if (r) r->Release();
  }
  ID3D11DepthStencilState* ds = nullptr; UINT sref = 0;
  c->OMGetDepthStencilState(&ds, &sref);
  int en = -1, mask = -1, fn = -1;
  if (ds) { D3D11_DEPTH_STENCIL_DESC d; ds->GetDesc(&d); en = d.DepthEnable; mask = d.DepthWriteMask; fn = d.DepthFunc; ds->Release(); }
  D3D11_VIEWPORT vp; UINT nvp = 1; ZeroMemory(&vp, sizeof(vp)); c->RSGetViewports(&nvp, &vp);
  log_line("RINGPROBE %d: renderTarget %ux%u fmt %u, depthBuffer %s %ux%u fmt %u flags %u, depthTest enable=%d write=%d func=%d, viewport %.0f,%.0f %.0fx%.0f depth %.3f..%.3f",
           n, rw, rh, rf, dsv ? "BOUND" : "none", dw, dh, df, dflags, en, mask, fn, (double)vp.TopLeftX, (double)vp.TopLeftY, (double)vp.Width, (double)vp.Height,
           (double)vp.MinDepth, (double)vp.MaxDepth);
  if (rtv[0]) rtv[0]->Release();
  if (rtv[1]) rtv[1]->Release();
  if (dsv) dsv->Release();
}
#endif
