// Pure stereo math for the alternate-eye prototype (0.21). No Windows
// dependency; unit-tested in tests/test_stereo.cpp.
//
// Engine facts used here (verified in ghost.exe, see layout.h / notes §16):
//  - camera basis columns are right, up, forward (left-handed, y up);
//    Euler yaw t gives forward = (sin t, 0, cos t), right = (cos t, 0, -sin t)
//  - the game renders a symmetric frustum; its half-FOV tangents are the
//    globals tanH (0x236BB54) and tanV (0x236BB58), tanH = tanV * aspect
#pragma once
#include "vmath.h"

namespace stereo {

static const double kFeetPerMetre = 3.280839895;  // game units are feet

// 0.27 "same moment": frame-time limit (game ticks, 1/65536 s) for the second
// eye's frame so that about `ticks` are left after the game multiplied them by
// its time scale and rounded down. 0 = do not use the feature for this pair
// (unusable scale, or it would need more than maxLimit).
inline int same_moment_limit(float scale, int ticks, int maxLimit) {
  if (!(scale > 0.0f) || !(scale < 1000.0f)) return 0;  // also false for NaN
  if (scale >= 0.95f) return ticks;
  float need = (float)ticks / scale + 1.0f;
  if (need > (float)maxLimit) return 0;
  return (int)need;
}

// Limit for the tick that follows an eye's prepare: > 0 = short tick with this
// limit (and the next simulation is left out), 0 = normal tick.
// role: 1 = the first eye of a pair was just prepared, 2 = the second, 0 = none.
inline int short_tick_limit(int role, int featureOn, int previousTickWasShort, float scale, int ticks, int maxLimit) {
  if (role != 1 || !featureOn || previousTickWasShort) return 0;
  return same_moment_limit(scale, ticks, maxLimit);
}

// 0.26 apparent world size in percent -> factor for eye separation and head
// movement. 100 = real size; 125 = everything looks a quarter bigger (the
// eyes are 1/1.25 as far apart); limited to 60..160.
inline double world_factor(int worldPct) {
  if (worldPct < 60) worldPct = 60;
  if (worldPct > 160) worldPct = 160;
  return 100.0 / (double)worldPct;
}

// Level (yaw-only) engine basis for a camera yaw in radians.
inline void level_basis(double yaw, float* o) {
  double s, c;
  vm::dsincos(yaw, &s, &c);
  o[0] = (float)c;  o[1] = 0; o[2] = (float)s;
  o[3] = 0;         o[4] = 1; o[5] = 0;
  o[6] = (float)-s; o[7] = 0; o[8] = (float)c;
}

// Yaw of an engine basis taken from its forward column. Returns 0 when the
// camera looks almost straight up or down (yaw undefined).
inline int basis_yaw(const float* m, double* yaw) {
  double fx = m[2], fz = m[8];
  if (fx * fx + fz * fz < 0.01) return 0;
  *yaw = vm::datan2(fx, fz);
  return 1;
}

// 1.7.216: the heading of a head basis even when it looks (almost) straight up or down: there the forward column has no horizontal part, but the head's UP column does (looking down it
// leans toward the heading, looking up it leans away from it). Returns 1 with the heading, 0 only for a basis that is not usable at all.
inline int robust_heading(const float* m, double* yaw) {
  for (int i = 0; i < 9; ++i) if (!vm::is_finite_f(m[i]) || m[i] > 1e6f || m[i] < -1e6f) return 0;   // a lost / garbled pose: no heading (nothing written)
  const double fx = m[2], fz = m[8], ux = m[1], uz = m[7];
  const double fh = fx * fx + fz * fz;
  if (fh >= 0.09) { *yaw = vm::datan2(fx, fz); return 1; }   // forward has a clear horizontal part (more than 17 deg off vertical)
  const double fy = m[5];
  const double sgn = fy < 0 ? 1.0 : -1.0;                   // looking down: up points along the heading; looking up: against it
  const double hx = sgn * ux, hz = sgn * uz;
  const double uh = hx * hx + hz * hz;
  if (uh < 1e-4) { if (fh < 1e-6) return 0; *yaw = vm::datan2(fx, fz); return 1; }
  if (fh > 1e-4) {   // blend the two so there is no jump where the choice changes
    const double w = (fh - 1e-4) / (0.09 - 1e-4);
    const double ax = fx / vm::dsqrt(fh) * w + hx / vm::dsqrt(uh) * (1.0 - w), az = fz / vm::dsqrt(fh) * w + hz / vm::dsqrt(uh) * (1.0 - w);
    *yaw = vm::datan2(ax, az); return 1;
  }
  *yaw = vm::datan2(hx, hz);
  return 1;
}

inline double angle_diff(double a, double b) {
  double d = a - b;
  while (d > vm::kPi) d -= 2 * vm::kPi;
  while (d < -vm::kPi) d += 2 * vm::kPi;
  return vm::dabs(d);
}

// Eye position for one eye:
//   out = baseEye + level * headPosFeet + right(view) * eyeXFeet
// level = yaw-only basis, view = level * headRotation (the rendered basis),
// headPosFeet = head offset from the recenter point in camera-local axes,
// eyeXFeet = signed eye offset along the view's right axis (left eye negative).
inline void eye_position(const float* baseEye, const float* level, const float* view, const float* headPosFeet,
                         double eyeXFeet, float* out) {
  for (int r = 0; r < 3; ++r) {
    double v = baseEye[r];
    if (headPosFeet)
      v += (double)level[r * 3] * headPosFeet[0] + (double)level[r * 3 + 1] * headPosFeet[1] +
           (double)level[r * 3 + 2] * headPosFeet[2];
    v += (double)view[r * 3] * eyeXFeet;
    out[r] = (float)v;
  }
}

// Symmetric half-FOV tangents that cover both eyes' frustums.
// OpenVR raw projection: left < 0 < right; "top" < 0 is the DOWNWARD edge and
// "bottom" > 0 is the UPWARD edge (y-up tangents with swapped names).
inline void required_fov(const float* left, const float* right, const float* top, const float* bottom, double* needH,
                         double* needV) {
  double h = 0, v = 0;
  for (int e = 0; e < 2; ++e) {
    if (-left[e] > h) h = -left[e];
    if (right[e] > h) h = right[e];
    if (-top[e] > v) v = -top[e];
    if (bottom[e] > v) v = bottom[e];
  }
  *needH = h; *needV = v;
}

// Vertical half-FOV tangent the game must render so that a frame of the
// given aspect (width/height) covers needH x needV.
inline double game_tan_v(double needH, double needV, double aspect) {
  double fromH = aspect > 0 ? needH / aspect : needH;
  return needV > fromH ? needV : fromH;
}

// Part of the game's frame (symmetric frustum tanH x tanV, v = 0 at the top
// row as in Direct3D) that one eye sees. b = uMin, vMin, uMax, vMax.
// Returns 1 if the eye's frustum is fully inside the frame.
inline int texture_bounds(double left, double right, double top, double bottom, double tanH, double tanV, float* b) {
  double v[4] = {0.5 + 0.5 * left / tanH, 0.5 - 0.5 * bottom / tanV, 0.5 + 0.5 * right / tanH, 0.5 - 0.5 * top / tanV};
  int inside = 1;
  for (int i = 0; i < 4; ++i) {
    if (v[i] < -1e-4 || v[i] > 1.0001) inside = 0;
    if (v[i] < 0) v[i] = 0;
    if (v[i] > 1) v[i] = 1;
    b[i] = (float)v[i];
  }
  return inside;
}

// Placement of the flat "cinema screen" (OpenVR standing space, 3x4): centred
// 'distance' metres in front of the headset's current heading, upright,
// 'drop' metres below eye level, facing the viewer. Y = yaw-only rotation of
// the headset (make_yaw_reference). Overlay quads face +Z, the viewer looks
// along -Z, so the screen uses the same yaw as the head.
inline void flat_screen_transform(const float* pose34, const float* Y, double distance, double drop, float* out34) {
  double local[3] = {0, -drop, -distance};
  for (int r = 0; r < 3; ++r) {
    out34[r * 4 + 0] = Y[r * 3 + 0];
    out34[r * 4 + 1] = Y[r * 3 + 1];
    out34[r * 4 + 2] = Y[r * 3 + 2];
    out34[r * 4 + 3] = (float)(pose34[r * 4 + 3] + Y[r * 3] * local[0] + Y[r * 3 + 1] * local[1] + Y[r * 3 + 2] * local[2]);
  }
}

}  // namespace stereo
