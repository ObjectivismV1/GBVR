// 0.51 what machine and what software the probe runs on - in the log, so a problem report does not need a
// description of the PC. Nothing here changes anything. Only kernel32 / user32 are imported; everything else
// (ntdll, version.dll, dxgi.dll) is looked up at run time.
#include "gbvr.h"
#include "envmath.h"

#if GBVR_HEADTRACK
#include <dxgi.h>
#include <cpuid.h>

namespace {
typedef LONG(NTAPI* PFN_RtlGetVersion)(void*);
typedef BOOL(WINAPI* PFN_EnumProcessModules)(HANDLE, HMODULE*, DWORD, LPDWORD);
typedef DWORD(WINAPI* PFN_GetModuleFileNameExA)(HANDLE, HMODULE, LPSTR, DWORD);
typedef HRESULT(WINAPI* PFN_CreateDXGIFactory1)(const GUID&, void**);
typedef DWORD(WINAPI* PFN_GetFileVersionInfoSizeA)(LPCSTR, LPDWORD);
typedef BOOL(WINAPI* PFN_GetFileVersionInfoA)(LPCSTR, DWORD, DWORD, LPVOID);
typedef BOOL(WINAPI* PFN_VerQueryValueA)(LPCVOID, LPCSTR, LPVOID*, PUINT);
typedef LONG(WINAPI* PFN_RegOpenKeyExA)(HKEY, LPCSTR, DWORD, REGSAM, PHKEY);
typedef LONG(WINAPI* PFN_RegQueryValueExA)(HKEY, LPCSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);
typedef LONG(WINAPI* PFN_RegCloseKey)(HKEY);
typedef UINT(WINAPI* PFN_GetDpiForWindow)(HWND);
typedef BOOL(WINAPI* PFN_IsProcessDPIAware)(void);

const char* base_name(const char* p) {
  const char* b = p;
  for (; *p; ++p) if (*p == '\\' || *p == '/') b = p + 1;
  return b;
}

// "a.b.c.d" of a file, or "?"
void file_version(const char* path, char* out, int n) {
  lstrcpynA(out, "?", n);
  HMODULE v = LoadLibraryA("version.dll");
  if (!v) return;
  PFN_GetFileVersionInfoSizeA sz = (PFN_GetFileVersionInfoSizeA)GetProcAddress(v, "GetFileVersionInfoSizeA");
  PFN_GetFileVersionInfoA gi = (PFN_GetFileVersionInfoA)GetProcAddress(v, "GetFileVersionInfoA");
  PFN_VerQueryValueA q = (PFN_VerQueryValueA)GetProcAddress(v, "VerQueryValueA");
  if (!sz || !gi || !q) return;
  DWORD z = 0, len = sz(path, &z);
  if (!len || len > 65536) return;
  static char buf[65536];
  if (!gi(path, 0, len, buf)) return;
  VS_FIXEDFILEINFO* fi = nullptr;
  UINT fl = 0;
  if (!q(buf, "\\", (LPVOID*)&fi, &fl) || !fi) return;
  wsprintfA(out, "%u.%u.%u.%u", (unsigned)HIWORD(fi->dwFileVersionMS), (unsigned)LOWORD(fi->dwFileVersionMS), (unsigned)HIWORD(fi->dwFileVersionLS), (unsigned)LOWORD(fi->dwFileVersionLS));
}

// 1.7.87 value of an environment variable (1 = set; out is empty when it is not)
int env_var(const char* name, char* out, int n) {
  out[0] = 0;
  SetLastError(0);
  const DWORD len = GetEnvironmentVariableA(name, out, (DWORD)n);
  if (len == 0) return GetLastError() == ERROR_ENVVAR_NOT_FOUND ? 0 : 1;
  if (len >= (DWORD)n) { out[n - 1] = 0; return 1; }
  return 1;
}

// 1.7.87 Windows' own "which graphics card does this program use" setting (Settings > System > Display > Graphics). Text like "GpuPreference=2;" or "" when none is set.
void windows_gpu_preference(const char* exePath, char* out, int n) {
  out[0] = 0;
  HMODULE adv = LoadLibraryA("advapi32.dll");
  if (!adv) return;
  PFN_RegOpenKeyExA ro = (PFN_RegOpenKeyExA)GetProcAddress(adv, "RegOpenKeyExA");
  PFN_RegQueryValueExA rq = (PFN_RegQueryValueExA)GetProcAddress(adv, "RegQueryValueExA");
  PFN_RegCloseKey rc = (PFN_RegCloseKey)GetProcAddress(adv, "RegCloseKey");
  if (!ro || !rq || !rc) return;
  HKEY k = nullptr;
  if (ro(HKEY_CURRENT_USER, "Software\\Microsoft\\DirectX\\UserGpuPreferences", 0, KEY_READ, &k) != ERROR_SUCCESS || !k) return;
  DWORD type = 0, sz = (DWORD)n - 1;
  if (rq(k, exePath, nullptr, &type, (LPBYTE)out, &sz) != ERROR_SUCCESS || type != REG_SZ) out[0] = 0; else out[sz < (DWORD)n ? sz : n - 1] = 0;
  rc(k);
}
}  // namespace

void sysinfo_file_version(const char* path, char* out, int n) { file_version(path, out, n); }

void sysinfo_log() {
  // Windows
  OSVERSIONINFOEXW vi;
  ZeroMemory(&vi, sizeof(vi));
  vi.dwOSVersionInfoSize = sizeof(vi);
  HMODULE nt = GetModuleHandleW(L"ntdll.dll");
  PFN_RtlGetVersion rv = nt ? (PFN_RtlGetVersion)GetProcAddress(nt, "RtlGetVersion") : nullptr;
  if (rv) rv(&vi);
  SYSTEM_INFO si;
  GetNativeSystemInfo(&si);
  MEMORYSTATUSEX ms;
  ZeroMemory(&ms, sizeof(ms));
  ms.dwLength = sizeof(ms);
  GlobalMemoryStatusEx(&ms);
  // CPU
  char brand[64] = {0};
  unsigned a, b, c, d;
  if (__get_cpuid_max(0x80000000, nullptr) >= 0x80000004) {
    for (unsigned i = 0; i < 3; ++i) { __get_cpuid(0x80000002 + i, &a, &b, &c, &d); ((unsigned*)brand)[i * 4] = a; ((unsigned*)brand)[i * 4 + 1] = b; ((unsigned*)brand)[i * 4 + 2] = c; ((unsigned*)brand)[i * 4 + 3] = d; }
    brand[63] = 0;
  }
  const char* bp = brand;
  while (*bp == ' ') ++bp;
  SYSTEMTIME lt;
  GetLocalTime(&lt);
  log_line("SYSINFO windows=%u.%u build=%u cpu=\"%s\" logicalCpus=%u ramMB=%u freeRamMB=%u pageFileFreeMB=%u arch=%u localTime=%04u-%02u-%02u_%02u:%02u:%02u",
           (unsigned)vi.dwMajorVersion, (unsigned)vi.dwMinorVersion, (unsigned)vi.dwBuildNumber, bp, (unsigned)si.dwNumberOfProcessors,
           (unsigned)(ms.ullTotalPhys >> 20), (unsigned)(ms.ullAvailPhys >> 20), (unsigned)(ms.ullAvailPageFile >> 20), (unsigned)si.wProcessorArchitecture,
           lt.wYear, lt.wMonth, lt.wDay, lt.wHour, lt.wMinute, lt.wSecond);
  // screen
  DEVMODEA dm;
  ZeroMemory(&dm, sizeof(dm));
  dm.dmSize = sizeof(dm);
  int hz = 0, bpp = 0;
  if (EnumDisplaySettingsA(nullptr, ENUM_CURRENT_SETTINGS, &dm)) { hz = (int)dm.dmDisplayFrequency; bpp = (int)dm.dmBitsPerPel; }
  log_line("SYSINFO desktop=%dx%d monitorHz=%d bits=%d monitors=%d", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), hz, bpp, GetSystemMetrics(SM_CMONITORS));
  // graphics adapters
  HMODULE dx = LoadLibraryA("dxgi.dll");
  PFN_CreateDXGIFactory1 cf = dx ? (PFN_CreateDXGIFactory1)GetProcAddress(dx, "CreateDXGIFactory1") : nullptr;
  if (cf) {
    static const GUID kIID_IDXGIFactory1 = {0x770aae78, 0xf26f, 0x4dba, {0xa8, 0x29, 0x25, 0x3c, 0x83, 0xd1, 0xb3, 0x87}};
    IDXGIFactory1* f = nullptr;
    if (SUCCEEDED(cf(kIID_IDXGIFactory1, (void**)&f)) && f) {
      for (UINT i = 0; i < 8; ++i) {
        IDXGIAdapter1* ad = nullptr;
        if (FAILED(f->EnumAdapters1(i, &ad)) || !ad) break;
        DXGI_ADAPTER_DESC1 desc;
        if (SUCCEEDED(ad->GetDesc1(&desc))) {
          char name[128];
          WideCharToMultiByte(CP_ACP, 0, desc.Description, -1, name, sizeof(name), nullptr, nullptr);
          name[sizeof(name) - 1] = 0;
          log_line("SYSINFO gpu%u=\"%s\" vendor=%04x device=%04x vramMB=%u sharedMB=%u flags=%u", i, name, (unsigned)desc.VendorId, (unsigned)desc.DeviceId,
                   (unsigned)(desc.DedicatedVideoMemory >> 20), (unsigned)(desc.SharedSystemMemory >> 20), (unsigned)desc.Flags);
        }
        ad->Release();
      }
      f->Release();
    }
  } else {
    log_line("SYSINFO dxgi.dll could not be queried");
  }
  // the game process
  char exe[MAX_PATH];
  GetModuleFileNameA(nullptr, exe, MAX_PATH);
  char ver[40];
  file_version(exe, ver, sizeof(ver));
  log_line("SYSINFO exe=%s exeVersion=%s priorityClass=0x%x commandLine=%s", exe, ver, (unsigned)GetPriorityClass(GetCurrentProcess()), GetCommandLineA());
  sysinfo_env(0);   // 1.7.87
}

// What else is loaded in the game process (overlays, capture tools, drivers). Called once, a while after start.
void sysinfo_modules() {
  HMODULE ps = LoadLibraryA("kernel32.dll");
  PFN_EnumProcessModules em = ps ? (PFN_EnumProcessModules)GetProcAddress(ps, "K32EnumProcessModules") : nullptr;
  PFN_GetModuleFileNameExA gn = ps ? (PFN_GetModuleFileNameExA)GetProcAddress(ps, "K32GetModuleFileNameExA") : nullptr;
  if (!em || !gn) { log_line("MODULES not available"); return; }
  static HMODULE mods[512];
  DWORD need = 0;
  if (!em(GetCurrentProcess(), mods, sizeof(mods), &need)) { log_line("MODULES could not be listed"); return; }
  int n = (int)(need / sizeof(HMODULE));
  if (n > 512) n = 512;
  char line[900];
  int len = 0, lines = 0;
  line[0] = 0;
  log_line("MODULES %d loaded in the game process:", n);
  for (int i = 0; i < n; ++i) {
    char path[MAX_PATH];
    if (!gn(GetCurrentProcess(), mods[i], path, MAX_PATH)) continue;
    const char* nm = base_name(path);
    int l = lstrlenA(nm);
    if (len + l + 2 > (int)sizeof(line) - 2) { log_line("MODULES %s", line); line[0] = 0; len = 0; if (++lines > 40) break; }
    len += wsprintfA(line + len, "%s ", nm);
  }
  if (len) log_line("MODULES %s", line);
  // versions of the files that decide how graphics and VR behave
  static const char* const kWanted[] = {"nvwgf2umx.dll", "nvd3dumx.dll", "atidxx64.dll", "amdxx64.dll", "igd10iumd64.dll", "igd12umd64.dll", "dxgi.dll", "d3d11.dll",
                                         "openvr_api.dll", "vrclient_x64.dll", "xinput1_3.dll", "xinput1_4.dll", "vrcompositor.exe"};
  for (int i = 0; i < n; ++i) {
    char path[MAX_PATH];
    if (!gn(GetCurrentProcess(), mods[i], path, MAX_PATH)) continue;
    const char* nm = base_name(path);
    for (const char* w : kWanted) {
      if (lstrcmpiA(nm, w) == 0) {
        char ver[40];
        file_version(path, ver, sizeof(ver));
        log_line("MODULES version %s %s (%s)", nm, ver, path);
      }
    }
  }
}

// 1.7.87 setup facts that decide whether the mod can work, as plain lines (ENVCHECK) and advice (ENVHINT). Reads only. late = 0: at start (environment
// variables); late = 1: a while into the game, when the window and Steam's overlay exist.
void sysinfo_env(int late) {
  char appId[32], gameId[32], ovId[32], vpad[8], cl[8];
  const int hasApp = env_var("SteamAppId", appId, sizeof(appId));
  const int hasGame = env_var("SteamGameId", gameId, sizeof(gameId));
  env_var("SteamOverlayGameId", ovId, sizeof(ovId));
  const int hasPad = env_var("SteamVirtualGamepadInfo", vpad, sizeof(vpad));
  const int hasCl = env_var("SteamClientLaunch", cl, sizeof(cl));
  const int launchedBySteam = (hasApp || hasGame) ? 1 : 0;
  const int overlay = GetModuleHandleA("gameoverlayrenderer64.dll") ? 1 : 0;
  if (!late) {
    log_line("ENVCHECK steam (start): launchedBySteam=%d SteamAppId=%s SteamGameId=%s SteamOverlayGameId=%s steamInputVirtualGamepad=%d (Steam Input is switched on for this game: the controls reach it through Steam's own virtual pad) startedByTheSteamClient=%d overlayModuleLoaded=%d",
             launchedBySteam, hasApp ? appId : "-", hasGame ? gameId : "-", ovId[0] ? ovId : "-", hasPad, hasCl, overlay);
    const char* note = env::steam_note(launchedBySteam, overlay);
    if (note[0]) log_line("ENVHINT %s", note);
    return;
  }
  log_line("ENVCHECK steam (later): overlayModuleLoaded=%d (Steam's overlay is in the game: its buttons and screenshots can hook the keyboard and the pad)", overlay);
  HWND w = g_ctl.gameHwnd;
  if (w && IsWindow(w)) {
    RECT cr, wr;
    ZeroMemory(&cr, sizeof(cr)); ZeroMemory(&wr, sizeof(wr));
    GetClientRect(w, &cr);
    GetWindowRect(w, &wr);
    const LONG style = GetWindowLongA(w, GWL_STYLE);
    int monW = 0, monH = 0;
    HMONITOR mon = MonitorFromWindow(w, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi;
    ZeroMemory(&mi, sizeof(mi));
    mi.cbSize = sizeof(mi);
    if (mon && GetMonitorInfoA(mon, &mi)) { monW = (int)(mi.rcMonitor.right - mi.rcMonitor.left); monH = (int)(mi.rcMonitor.bottom - mi.rcMonitor.top); }
    HMODULE u = GetModuleHandleA("user32.dll");
    PFN_GetDpiForWindow gd = u ? (PFN_GetDpiForWindow)GetProcAddress(u, "GetDpiForWindow") : nullptr;
    PFN_IsProcessDPIAware ia = u ? (PFN_IsProcessDPIAware)GetProcAddress(u, "IsProcessDPIAware") : nullptr;
    const unsigned dpi = gd ? (unsigned)gd(w) : 0u;
    const int kind = env::window_kind((style & WS_POPUP) != 0 && !(style & WS_CAPTION), (int)(wr.right - wr.left), (int)(wr.bottom - wr.top), monW, monH);
    static const char* const kKind[3] = {"a normal window", "borderless full screen", "a maximised window"};
    log_line("ENVCHECK window: %s, client %dx%d, window %dx%d, monitor %dx%d, Windows scaling %d%% (dpi %u), game is DPI-aware=%d, active window=%d",
             kKind[kind], (int)(cr.right - cr.left), (int)(cr.bottom - cr.top), (int)(wr.right - wr.left), (int)(wr.bottom - wr.top), monW, monH,
             env::dpi_scale_pct(dpi), dpi, ia ? (ia() ? 1 : 0) : -1, GetForegroundWindow() == w ? 1 : 0);
  } else {
    log_line("ENVCHECK window: the game window is not known yet");
  }
  char exe[MAX_PATH], pref[48];
  exe[0] = 0;
  GetModuleFileNameA(nullptr, exe, MAX_PATH);
  windows_gpu_preference(exe, pref, sizeof(pref));
  log_line("ENVCHECK graphics setting: Windows' own choice of graphics card for this game = %s (GpuPreference=1 power saving, 2 high performance; none = Windows decides)", pref[0] ? pref : "none");
}
#endif
