#pragma once
#include <stdint.h>
// OpenVR ReprojectionReason_Cpu/Gpu are 0x01/0x02. Async (0x04)
// and motion smoothing (0x08) mode flags alone do not prove a reused frame.
static inline int gbvr_frame_reused(uint32_t flags, uint32_t presents) {
  return (flags & 3u) != 0 || presents > 1;
}
static inline int gbvr_display_hz10(int propertyError, float hz) {
  return propertyError == 0 && hz > 30.0f && hz < 300.0f ? (int)(hz * 10.0f + 0.5f) : 0;
}
