// 0.41: rewriting the rotation of the game's "tip" matrix so the stream axis points along the controller aim.
// m = 4x4 row-major (rows 0..2 are axes, row 3 the translation, which is untouched).
#ifndef GBVR_TIPMATH_H
#define GBVR_TIPMATH_H
#include "vmath.h"
namespace tipmath {
inline double dot3(const double* a, const double* b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
// axis a (0..2) is turned to sg * d (d unit length); the other two rows are turned with it, keeping their lengths
// and the original handedness. Returns 0 (matrix untouched) when it cannot be done.
inline int rewrite_row(float* m, int a, double sg, const double* d) {
  double row[3][3], len[3];
  for (int i = 0; i < 3; ++i) {
    for (int j = 0; j < 3; ++j) { if (!vm::is_finite_f(m[i * 4 + j])) return 0; row[i][j] = m[i * 4 + j]; }
    len[i] = vm::dsqrt(dot3(row[i], row[i]));
    if (!(len[i] > 0.1) || !(len[i] < 10.0)) return 0;
  }
  double nf[3] = {sg * d[0], sg * d[1], sg * d[2]};
  int b = (a + 1) % 3, c = (a + 2) % 3;
  double pr = dot3(row[b], nf), nb[3], nbl;
  for (int j = 0; j < 3; ++j) nb[j] = row[b][j] - pr * nf[j];
  nbl = vm::dsqrt(dot3(nb, nb));
  if (!(nbl > 1e-3)) {
    pr = dot3(row[c], nf);
    for (int j = 0; j < 3; ++j) nb[j] = row[c][j] - pr * nf[j];
    nbl = vm::dsqrt(dot3(nb, nb));
    if (!(nbl > 1e-3)) return 0;
  }
  for (int j = 0; j < 3; ++j) nb[j] /= nbl;
  double nc[3] = {nf[1] * nb[2] - nf[2] * nb[1], nf[2] * nb[0] - nf[0] * nb[2], nf[0] * nb[1] - nf[1] * nb[0]};
  // handedness of the original (b x c . a) decides the sign of the third row
  double cr[3] = {row[b][1] * row[c][2] - row[b][2] * row[c][1], row[b][2] * row[c][0] - row[b][0] * row[c][2], row[b][0] * row[c][1] - row[b][1] * row[c][0]};
  double hand = dot3(cr, row[a]);
  double mine = dot3(nc, nf);    // nb x nc... use triple product of the new rows: nb x nc . nf
  (void)mine;
  double cr2[3] = {nb[1] * nc[2] - nb[2] * nc[1], nb[2] * nc[0] - nb[0] * nc[2], nb[0] * nc[1] - nb[1] * nc[0]};
  double newHand = dot3(cr2, nf);
  if ((hand < 0) != (newHand < 0)) for (int j = 0; j < 3; ++j) nc[j] = -nc[j];
  for (int j = 0; j < 3; ++j) {
    m[a * 4 + j] = (float)(nf[j] * len[a]);
    m[b * 4 + j] = (float)(nb[j] * len[b]);
    m[c * 4 + j] = (float)(nc[j] * len[c]);
  }
  return 1;
}

// Learns which of the six signed rows (+row0 +row1 +row2 -row0 -row1 -row2) of a matrix follows a reference direction.
struct Learner {
  double sum[6];
  long n;
  void reset() { for (int i = 0; i < 6; ++i) sum[i] = 0; n = 0; }
  // m: 4x4 row-major matrix; aim: unit vector. Returns 0 when the matrix or vector is unusable.
  int add(const float* m, const double* aim) {
    double c[3];
    for (int i = 0; i < 3; ++i) {
      double r[3] = {m[i * 4], m[i * 4 + 1], m[i * 4 + 2]};
      for (int j = 0; j < 3; ++j) if (!vm::is_finite_f((float)r[j])) return 0;
      double l = vm::dsqrt(dot3(r, r));
      if (!(l > 0.1) || !(l < 10.0)) return 0;
      c[i] = dot3(r, aim) / l;
    }
    for (int i = 0; i < 3; ++i) { sum[i] += c[i]; sum[i + 3] -= c[i]; }
    ++n;
    return 1;
  }
  // best index (0..5), its mean agreement and the next best mean; -1 when no clear winner
  int decide(double* meanBest, double* meanSecond, double minMean, double gap) const {
    if (n <= 0) return -1;
    int best = 0;
    for (int k = 1; k < 6; ++k) if (sum[k] > sum[best]) best = k;
    double second = -9;
    for (int k = 0; k < 6; ++k) if (k != best && sum[k] > second) second = sum[k];
    *meanBest = sum[best] / n; *meanSecond = second / n;
    return (*meanBest > minMean && *meanSecond < *meanBest - gap) ? best : -1;
  }
};
}  // namespace tipmath
#endif
