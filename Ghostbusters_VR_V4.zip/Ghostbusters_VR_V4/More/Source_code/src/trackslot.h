// 1.7.116 where an enemy's record lives in the table of damage.cpp (g_track): the record holds "this ghost just lost health" (what shows the health ring on a ghost you shoot), the seen /
// trapped / gone latches of its bar and its eased health.
// Until 1.7.115 the table had 48 slots that were never freed; the 49th ghost met (the game keeps every enemy of the level in its list, spawned or not, and a long session meets many) took
// slot (address >> 4) % 48 that another ghost owned, and the two reset each other's record in every scan, so neither ever showed "just lost health".
// Now: a ghost already in the table keeps its slot; a new one takes a free slot, else the slot that was not used for the longest time (a ghost that left the list); if every slot was used in
// this very scan (more enemies than slots) the new one gets a spare slot at index n that is reset every time, so the records of the others are never disturbed. Pure, tested in tests/test_trackslot.cpp.
#pragma once
#include <stdint.h>

namespace trackslot {

// T needs: uintptr_t id; int64_t useQ. s has n + 1 entries (the last one is the spare).
// Returns the slot. *fresh = 1: the caller resets the record for this actor (it is new in the table). *evicted = 1: that took another (stale) ghost's slot. *used = slots in use before this call (only when fresh).
template <class T>
inline int pick(T* s, int n, uintptr_t actor, int64_t now, int* fresh, int* evicted, int* used) {
  int freeI = -1, oldI = -1, u = 0; int64_t oldQ = 0;
  *fresh = 0; *evicted = 0; *used = 0;
  for (int i = 0; i < n; ++i) {
    if (s[i].id == actor) { s[i].useQ = now; return i; }
    if (!s[i].id) { if (freeI < 0) freeI = i; continue; }
    ++u;
    if (oldI < 0 || s[i].useQ < oldQ) { oldI = i; oldQ = s[i].useQ; }
  }
  *fresh = 1; *used = u;
  int ti;
  if (freeI >= 0) ti = freeI;
  else if (oldI >= 0 && oldQ < now) { ti = oldI; *evicted = 1; }
  else ti = n;   // every slot was used in this scan: the spare one
  s[ti].id = actor; s[ti].useQ = now;
  return ti;
}

}  // namespace trackslot
