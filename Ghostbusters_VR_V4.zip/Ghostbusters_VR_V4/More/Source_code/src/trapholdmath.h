// 1.7.193: the carried trap is rigid with the controller in all three turns (fully rotatable). Pure maths, unit-tested (tests/test_traphold.cpp).
// Body direction d = minus the controller's up; the flat face follows the controller's pointing made perpendicular to d.
#pragma once
#include "vmath.h"
namespace traphold {
// c[axis][component]: the world direction of each of the trap model's three axes. ua = the long axis (index), upSign/sf as learned at the grab. N (in/out) keeps the last face direction near the pole.
inline int build(const float* fwd, const float* up, int ua, double upSign, double sf, double* N, double c[3][3], double* dOut) {
  double dv[3] = {-(double)up[0], -(double)up[1], -(double)up[2]};
  double dl = vm::dsqrt(dv[0] * dv[0] + dv[1] * dv[1] + dv[2] * dv[2]);
  if (!(dl > 1e-6)) { dv[0] = 0; dv[1] = -1; dv[2] = 0; dl = 1.0; }
  for (int i = 0; i < 3; ++i) dv[i] /= dl;
  double fv[3] = {(double)fwd[0], (double)fwd[1], (double)fwd[2]};
  const double dd = fv[0] * dv[0] + fv[1] * dv[1] + fv[2] * dv[2];
  for (int i = 0; i < 3; ++i) fv[i] -= dd * dv[i];
  const double fl = vm::dsqrt(fv[0] * fv[0] + fv[1] * fv[1] + fv[2] * fv[2]);
  int fresh = 0;
  if (fl > 0.2) { for (int i = 0; i < 3; ++i) N[i] = fv[i] / fl; fresh = 1; }
  else {   // near the pole the last face is kept, made perpendicular to the new body direction again (audit: it must stay a proper rotation)
    const double nd = N[0] * dv[0] + N[1] * dv[1] + N[2] * dv[2];
    double q[3] = {N[0] - nd * dv[0], N[1] - nd * dv[1], N[2] - nd * dv[2]};
    double ql = vm::dsqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2]);
    if (ql > 1e-6) { for (int i = 0; i < 3; ++i) N[i] = q[i] / ql; }
    else { const double ax = dv[0] * dv[0] < 0.5 ? 1.0 : 0.0; double r[3] = {ax, 1.0 - ax, 0.0}; const double rd = r[0] * dv[0] + r[1] * dv[1] + r[2] * dv[2]; for (int i = 0; i < 3; ++i) r[i] -= rd * dv[i]; const double rl = vm::dsqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2]); for (int i = 0; i < 3; ++i) N[i] = r[i] / (rl > 1e-9 ? rl : 1.0); }
  }
  const int fa = (ua + 2) % 3, wa = (ua + 1) % 3;
  for (int i = 0; i < 3; ++i) { c[ua][i] = upSign * dv[i]; c[fa][i] = sf * N[i]; if (dOut) dOut[i] = dv[i]; }
  c[wa][0] = c[fa][1] * c[ua][2] - c[fa][2] * c[ua][1];
  c[wa][1] = c[fa][2] * c[ua][0] - c[fa][0] * c[ua][2];
  c[wa][2] = c[fa][0] * c[ua][1] - c[fa][1] * c[ua][0];
  return fresh;
}
}
