// 1.7.22 Comfort vignette (pure math; tested in tests/test_vignette.cpp).
//
// A soft dark edge that fades in around each eye's picture while you walk, sprint, turn or dash, and fades out again when you stand still. It is drawn by the probe into the
// final eye picture (after the game's frame and the hands), so it never touches the game itself. Off by default (vignette_pct = 0).
//
// Everything is in "picture coordinates" (NDC of the eye texture: -1..1, y up). The visible window of one eye is a rectangle inside the texture (stereo::texture_bounds); the
// vignette is an ellipse centred in that rectangle. The mesh is a set of rings. Each vertex carries a darkness d (0..1) in its colour; the blend state multiplies the picture
// by (1 - d), so the fade is a smooth gradient made by the GPU's interpolation (no banding from stacked layers).
#pragma once
#include "vmath.h"   // freestanding build: no C runtime sin/cos/exp

namespace vig {

struct State { double level; };   // 0..1, eased

inline double clamp01(double x) { return x < 0.0 ? 0.0 : (x > 1.0 ? 1.0 : x); }

// What the player is doing right now -> how dark the edge wants to be (0..1, before the strength setting). move/turn are stick pushes 0..1, pulse 0..1 (a dash).
inline double want(double move01, double turn01, int sprint, double pulse01) {
  const double m = move01 < 0.2 ? 0.0 : (move01 - 0.2) / 0.8;
  const double t = turn01 < 0.25 ? 0.0 : (turn01 - 0.25) / 0.75;
  double w = 0.75 * m;
  if (0.85 * t > w) w = 0.85 * t;
  if (sprint && m > 0.0) w = clamp01(w + 0.25);
  if (pulse01 > w) w = pulse01;
  return clamp01(w);
}

// Eases towards the wanted level: quick in (0.15 s), slow out (0.5 s). dt in seconds. Returns the level times the strength setting (0..1).
inline double step(State* st, double target, double dt, double strength01) {
  if (!(dt > 0.0)) dt = 0.0;
  if (dt > 0.25) dt = 0.25;
  const double tau = target > st->level ? 0.15 : 0.5;
  st->level += (target - st->level) * (dt / (tau + dt));   // first-order ease (no exp in the freestanding build)
  if (st->level < 0.0005) st->level = 0.0;
  return clamp01(st->level) * clamp01(strength01);
}

// Radius (1.0 = the edge of the visible ellipse) where the clear middle ends, and how dark the far edge gets.
inline double clear_radius(double level) { return 1.25 - 0.80 * clamp01(level); }   // 1.7.180: was 1.45 - 0.95 level: at 40-70 % only the picture corners darkened (the lenses hide them)
inline double fade_width() { return 0.5; }
inline double max_dark(double level) { return 0.2 + 0.77 * clamp01(level); }

inline double smooth(double x) { x = clamp01(x); return x * x * (3.0 - 2.0 * x); }

// Darkness 0..1 at normalised radius r for a level (the mesh samples this).
inline double darkness_at(double level, double r) {
  if (level <= 0.0) return 0.0;
  const double c = clear_radius(level);
  return max_dark(level) * smooth((r - c) / fade_width());
}

enum { kSegments = 48, kBands = 12 };
// Vertices needed for a full mesh (triangles): (kBands + 1) rings of kSegments quads.
inline int vertex_count() { return (kBands + 1) * kSegments * 6; }

struct Vert { float p[3]; float c[4]; };   // p: NDC x, y and 0; c: darkness in rgb, 1 in alpha (the probe's "plain colour" flag)

// Builds the ring mesh. cx, cy, hx, hy: centre and half-size of the visible window in NDC. Returns the number of vertices written, 0 if nothing is to be drawn (level too low), -1 if cap is too small.
inline int build(double level, double cx, double cy, double hx, double hy, Vert* out, int cap) {
  if (!(level > 0.01) || !(hx > 0.0) || !(hy > 0.0)) return 0;
  if (cap < vertex_count()) return -1;
  const double c0 = clear_radius(level), w = fade_width();
  double rr[kBands + 2];
  for (int b = 0; b <= kBands; ++b) rr[b] = c0 + w * (double)b / (double)kBands;
  rr[kBands + 1] = 4.0;   // the last ring is far outside the picture and as dark as the rim
  int n = 0;
  const double kTwoPi = 6.283185307179586;
  for (int b = 0; b <= kBands; ++b) {
    const double ra = rr[b], rb = rr[b + 1];
    const double da = darkness_at(level, ra), db = (b == kBands) ? darkness_at(level, rr[kBands]) : darkness_at(level, rb);
    for (int s = 0; s < kSegments; ++s) {
      const double a0 = kTwoPi * (double)s / (double)kSegments, a1 = kTwoPi * (double)(s + 1) / (double)kSegments;
      double x0, y0, x1, y1;
      vm::dsincos(a0, &y0, &x0); vm::dsincos(a1, &y1, &x1);
      const double q[4][3] = {{cx + hx * ra * x0, cy + hy * ra * y0, da}, {cx + hx * ra * x1, cy + hy * ra * y1, da},
                              {cx + hx * rb * x0, cy + hy * rb * y0, db}, {cx + hx * rb * x1, cy + hy * rb * y1, db}};
      const int idx[6] = {0, 2, 1, 1, 2, 3};
      for (int k = 0; k < 6; ++k) {
        Vert& v = out[n++];
        v.p[0] = (float)q[idx[k]][0]; v.p[1] = (float)q[idx[k]][1]; v.p[2] = 0.0f;
        v.c[0] = v.c[1] = v.c[2] = (float)q[idx[k]][2]; v.c[3] = 1.0f;
      }
    }
  }
  return n;
}

}  // namespace vig
