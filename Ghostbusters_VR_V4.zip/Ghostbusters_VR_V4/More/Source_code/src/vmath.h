// Small 3x3 math helpers. No C runtime dependency (works in the freestanding
// cross build and with MSVC). Matrices are row-major float[9]: m[r*3+c].
//
// Engine convention (verified from 0.16 log samples): the columns of the
// camera basis are right, up and forward in world space, left-handed
// (x right, y up, z forward). A camera-local rotation R is applied as
//   M' = M * R
// 0.16 yaw of +theta degrees (F7) used R = [[c,0,-s],[0,1,0],[s,0,c]].
#pragma once
#include <stdint.h>
#include <emmintrin.h>

namespace vm {

static const double kPi = 3.14159265358979323846;

inline double dsqrt(double x) { return _mm_cvtsd_f64(_mm_sqrt_sd(_mm_setzero_pd(), _mm_set_sd(x))); }
inline double dabs(double x) { return x < 0 ? -x : x; }

inline int is_finite_f(float f) {
  union { float f; uint32_t u; } v; v.f = f;
  return (v.u & 0x7f800000u) != 0x7f800000u;
}

// sin/cos with range reduction to [-pi/4, pi/4]; |error| < 1e-15.
inline void dsincos(double x, double* s, double* c) {
  const double halfPi = kPi * 0.5;
  double k = x / halfPi;
  long long q = (long long)(k < 0 ? k - 0.5 : k + 0.5);
  double r = x - (double)q * halfPi;
  double r2 = r * r;
  double sr = r * (1 - r2 / 6 * (1 - r2 / 20 * (1 - r2 / 42 * (1 - r2 / 72 * (1 - r2 / 110 * (1 - r2 / 156))))));
  double cr = 1 - r2 / 2 * (1 - r2 / 12 * (1 - r2 / 30 * (1 - r2 / 56 * (1 - r2 / 90 * (1 - r2 / 132 * (1 - r2 / 182))))));
  switch ((int)(q & 3)) {
    case 0: *s = sr;  *c = cr;  break;
    case 1: *s = cr;  *c = -sr; break;
    case 2: *s = -sr; *c = -cr; break;
    default:*s = -cr; *c = sr;  break;
  }
}

// atan2 for logging angles only (accuracy ~1e-6 rad).
inline double datan(double x) {  // |x| <= 1
  // atan via argument halving + series
  double a = x / (1 + dsqrt(1 + x * x));      // atan(x) = 2*atan(a)
  a = a / (1 + dsqrt(1 + a * a));              // = 4*atan(a)
  double a2 = a * a, t = a, sum = a;
  for (int i = 1; i < 12; ++i) { t *= -a2; sum += t / (2 * i + 1); }
  return 4 * sum;
}
inline double datan2(double y, double x) {
  if (x == 0 && y == 0) return 0;
  if (dabs(x) >= dabs(y)) {
    double r = datan(y / x);
    if (x > 0) return r;
    return y >= 0 ? r + kPi : r - kPi;
  }
  double r = datan(x / y);
  return y > 0 ? kPi * 0.5 - r : -kPi * 0.5 - r;
}
inline double dasin(double x) {
  if (x > 1) x = 1; if (x < -1) x = -1;
  return datan2(x, dsqrt(1 - x * x));
}

inline void identity(float* o) {
  for (int i = 0; i < 9; ++i) o[i] = (i % 4 == 0) ? 1.0f : 0.0f;
}

inline void mul(const float* a, const float* b, float* o) {  // o = a*b
  float t[9];
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 3; ++c)
      t[r * 3 + c] = a[r * 3 + 0] * b[0 * 3 + c] + a[r * 3 + 1] * b[1 * 3 + c] + a[r * 3 + 2] * b[2 * 3 + c];
  for (int i = 0; i < 9; ++i) o[i] = t[i];
}

inline void transpose(const float* a, float* o) {
  float t[9];
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) t[c * 3 + r] = a[r * 3 + c];
  for (int i = 0; i < 9; ++i) o[i] = t[i];
}

inline double det(const float* m) {
  return (double)m[0] * ((double)m[4] * m[8] - (double)m[5] * m[7])
       - (double)m[1] * ((double)m[3] * m[8] - (double)m[5] * m[6])
       + (double)m[2] * ((double)m[3] * m[7] - (double)m[4] * m[6]);
}

// Largest deviation of M*M^T from identity.
inline double ortho_error(const float* m) {
  double worst = 0;
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) {
      double d = (double)m[i * 3] * m[j * 3] + (double)m[i * 3 + 1] * m[j * 3 + 1] + (double)m[i * 3 + 2] * m[j * 3 + 2];
      double e = dabs(d - (i == j ? 1.0 : 0.0));
      if (e > worst) worst = e;
    }
  return worst;
}

// A proper rotation: finite, orthonormal within tol, determinant ~ +1.
inline int is_rotation(const float* m, double tol = 2e-3) {
  for (int i = 0; i < 9; ++i) if (!is_finite_f(m[i])) return 0;
  if (ortho_error(m) > tol) return 0;
  double d = det(m);
  return d > 1.0 - 4 * tol && d < 1.0 + 4 * tol;
}

// Camera-local yaw used by 0.16 (positive degrees = F7).
inline void local_yaw(double degrees, float* o) {
  double s, c; dsincos(degrees * kPi / 180.0, &s, &c);
  o[0] = (float)c; o[1] = 0; o[2] = (float)-s;
  o[3] = 0;        o[4] = 1; o[5] = 0;
  o[6] = (float)s; o[7] = 0; o[8] = (float)c;
}

// Independent double-precision check of the 0.16 yaw edit: returns the max
// element error between 'applied' and original*R(yaw).
inline double yaw_math_error(const float* original, const float* applied, double degrees) {
  double s, c; dsincos(degrees * kPi / 180.0, &s, &c);
  double worst = 0;
  for (int r = 0; r < 3; ++r) {
    double m0 = original[r * 3], m1 = original[r * 3 + 1], m2 = original[r * 3 + 2];
    double e0 = c * m0 + s * m2, e1 = m1, e2 = -s * m0 + c * m2;
    double d0 = dabs(e0 - applied[r * 3]), d1 = dabs(e1 - applied[r * 3 + 1]), d2 = dabs(e2 - applied[r * 3 + 2]);
    if (d0 > worst) worst = d0; if (d1 > worst) worst = d1; if (d2 > worst) worst = d2;
  }
  return worst;
}

// Re-orthonormalize (Gram-Schmidt on rows) to remove float drift.
inline void orthonormalize(float* m) {
  double r0[3] = {m[0], m[1], m[2]}, r1[3] = {m[3], m[4], m[5]};
  double n = dsqrt(r0[0] * r0[0] + r0[1] * r0[1] + r0[2] * r0[2]);
  if (n < 1e-9) return;
  for (int i = 0; i < 3; ++i) r0[i] /= n;
  double d = r0[0] * r1[0] + r0[1] * r1[1] + r0[2] * r1[2];
  for (int i = 0; i < 3; ++i) r1[i] -= d * r0[i];
  n = dsqrt(r1[0] * r1[0] + r1[1] * r1[1] + r1[2] * r1[2]);
  if (n < 1e-9) return;
  for (int i = 0; i < 3; ++i) r1[i] /= n;
  double r2[3] = {r0[1] * r1[2] - r0[2] * r1[1], r0[2] * r1[0] - r0[0] * r1[2], r0[0] * r1[1] - r0[1] * r1[0]};
  for (int i = 0; i < 3; ++i) { m[i] = (float)r0[i]; m[3 + i] = (float)r1[i]; m[6 + i] = (float)r2[i]; }
}

}  // namespace vm
