// 0.53 the in-VR menu: pure helpers (no Windows dependency); unit-tested in tests/test_vmenu.cpp.
#pragma once
#include <stdint.h>
#include "vmath.h"

namespace vmenu {

struct Rect { int x, y, w, h; };
inline bool inside(const Rect& r, int px, int py) { return px >= r.x && py >= r.y && px < r.x + r.w && py < r.y + r.h; }

inline int clamp_i(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

// one click of a "- value +" control
inline int step_value(int v, int lo, int hi, int step, int dir) {
  if (step < 1) step = 1;
  return clamp_i(v + (dir < 0 ? -step : step), lo, hi);
}

// SteamVR overlay pointer (u right, v up, both 0..1) -> pixel of the menu picture (0,0 = top left). Returns 0 if outside.
inline int pointer_px(float u, float v, int W, int H, int flip, int* px, int* py) {
  if (!(u >= 0.0f) || !(u <= 1.0f) || !(v >= 0.0f) || !(v <= 1.0f)) return 0;
  float vv = flip ? v : 1.0f - v;
  *px = (int)(u * (float)(W - 1) + 0.5f);
  *py = (int)(vv * (float)(H - 1) + 0.5f);
  return 1;
}

// "105" with divisor 10 -> "10.5" (ASCII, no libm). Returns the length.
inline int fmt_value(char* out, int cap, int v, int div) {
  int n = 0;
  if (cap < 16) { if (cap > 0) out[0] = 0; return 0; }
  unsigned u = (unsigned)(v < 0 ? -v : v);
  if (v < 0) out[n++] = '-';
  if (div <= 1) {
    char t[12]; int k = 0;
    do { t[k++] = (char)('0' + u % 10); u /= 10; } while (u);
    while (k) out[n++] = t[--k];
  } else {
    unsigned whole = u / (unsigned)div, frac = u % (unsigned)div;
    char t[12]; int k = 0;
    do { t[k++] = (char)('0' + whole % 10); whole /= 10; } while (whole);
    while (k) out[n++] = t[--k];
    if (frac) {   // div is 10 or 100
      out[n++] = '.';
      if (div == 100) { out[n++] = (char)('0' + frac / 10); if (frac % 10) out[n++] = (char)('0' + frac % 10); }
      else out[n++] = (char)('0' + frac);
    }
  }
  out[n] = 0;
  return n;
}

// Placement of the menu in front of the player: OpenVR 3x4 (row-major), standing space. head34 = headset pose
// (forward = -z column). The menu faces the player, upright, `dist` metres ahead along the horizontal gaze and `drop`
// metres below the eyes. Returns 0 when the player looks (almost) straight up or down.
inline int place_in_front(const float* head34, double dist, double drop, float* xf) {
  double fx = -(double)head34[2], fz = -(double)head34[10];
  double len2 = fx * fx + fz * fz;
  if (len2 < 0.04) return 0;
  double inv = 1.0 / vm::dsqrt(len2);
  fx *= inv; fz *= inv;
  // viewer's right = forward x up = (-fz, 0, fx); menu +z = toward the viewer = -forward
  double rx = -fz, rz = fx;
  double px = (double)head34[3] + fx * dist, py = (double)head34[7] - drop, pz = (double)head34[11] + fz * dist;
  xf[0] = (float)rx;  xf[1] = 0;  xf[2] = (float)-fx; xf[3] = (float)px;
  xf[4] = 0;          xf[5] = 1;  xf[6] = 0;          xf[7] = (float)py;
  xf[8] = (float)rz;  xf[9] = 0;  xf[10] = (float)-fz; xf[11] = (float)pz;
  return 1;
}

// A hand is "next to the head" when it is within r metres of the headset and not far below it.
inline int near_head(const float* head34, const float* hand34, double r) {
  double dx = (double)hand34[3] - head34[3], dy = (double)hand34[7] - head34[7], dz = (double)hand34[11] - head34[11];
  if (dy < -0.30) return 0;
  return dx * dx + dy * dy + dz * dz <= r * r;
}

// 1.7.7: "beside the head" is now a zone beside the LEFT EAR, measured in the headset's own axes (right / up / forward of the face). The 1.7.6 and older rule was a 30 cm ball around the
// headset centre, so a left hand that held the gun up in front of the face (two-hand aim) or rested in front of the chest with the grip squeezed opened the menu.
// The zone: within 24 cm of the headset centre, not further right than 8 cm (so the left ear side), not further in front of the face than 12 cm, up to 25 cm behind it,
// from 20 cm below to 18 cm above the eyes.
struct EarInfo { double right, up, fwd, dist; };
inline int ear_zone(const float* head34, const float* hand34, EarInfo* o, int mirror = 0) {   // 1.7.176: mirror = left-handed play: the menu hand is the physical right one, the zone is beside the RIGHT ear
  const double dx = (double)hand34[3] - head34[3], dy = (double)hand34[7] - head34[7], dz = (double)hand34[11] - head34[11];
  const double r = dx * head34[0] + dy * head34[4] + dz * head34[8];
  const double rr = mirror ? -r : r;
  const double u = dx * head34[1] + dy * head34[5] + dz * head34[9];
  const double f = -(dx * head34[2] + dy * head34[6] + dz * head34[10]);   // the headset looks along -z
  const double d = vm::dsqrt(dx * dx + dy * dy + dz * dz);
  if (o) { o->right = r; o->up = u; o->fwd = f; o->dist = d; }
  return d <= 0.24 && rr <= 0.08 && f <= 0.12 && f >= -0.25 && u >= -0.20 && u <= 0.18;
}

// Auto-repeat for a held "-" / "+": first after firstMs, then every everyMs (faster after a second and a half).
struct Repeater {
  int held;
  uint32_t t0, next;
  void reset() { held = 0; t0 = next = 0; }
  void press(uint32_t now) { held = 1; t0 = now; next = now + 450; }
  void release() { held = 0; }
  // number of extra steps due now (0 or 1)
  int due(uint32_t now) {
    if (!held || (int32_t)(now - next) < 0) return 0;
    uint32_t every = (now - t0) > 1500 ? 60 : 120;
    next = now + every;
    return 1;
  }
};

// ---- 0.68 the menu pointer: smooth, and held still while the trigger is squeezed ----------------------------------------------------
// The controller ray hits the menu 1.25 m away, so a 1 mm tremor of the hand is several millimetres on the menu, and squeezing the trigger
// moves the hand again right at the moment of the click. (1) a "one euro" filter: heavy smoothing while the pointer is nearly still, almost
// none while it moves fast; (2) once the trigger starts to close (before the click) the pointer position is held until it opens again, so
// the click lands where the pointer WAS when the finger began to squeeze.
inline double lp_alpha(double dt, double cutoffHz) {
  const double tau = 1.0 / (2.0 * 3.14159265358979 * cutoffHz);
  return 1.0 / (1.0 + tau / dt);
}
struct OneEuro {
  double x, dx;
  int have;
  void reset() { have = 0; x = dx = 0; }
  double filter(double v, double dt, double minCut, double beta, double dCut) {
    if (!(dt > 1e-4)) dt = 1e-4;
    if (!have) { have = 1; x = v; dx = 0; return x; }
    const double rawD = (v - x) / dt;
    dx += lp_alpha(dt, dCut) * (rawD - dx);
    const double speed = dx < 0 ? -dx : dx;
    x += lp_alpha(dt, minCut + beta * speed) * (v - x);
    return x;
  }
};
struct Pointer {
  OneEuro fx, fy;
  int armed;
  double lx, ly;          // held position
  double x, y;            // filtered position (always current)
  double jitterSum; long jitterN;   // |raw - filtered| in pixels, for the log
  long lockedMoves; double lockedMovePx;   // how far the raw pointer wandered while held (last), for the log
  double minCut, beta, dCut;
  double ox_, oy_; int haveOut;   // 0.70 dead zone: the output only follows once the filtered point is more than deadPx away
  void reset() { haveOut = 0; ox_ = oy_ = 0; fx.reset(); fy.reset(); armed = 0; lx = ly = x = y = 0; jitterSum = 0; jitterN = 0; lockedMoves = 0; lockedMovePx = 0; minCut = 0.9; beta = 0.010; dCut = 1.0; }
  // raw pixel position, seconds since the last call, trigger 0..1. Output: the position to use, and whether it is held.
  int update(double rx, double ry, double dt, double trig, double* ox, double* oy) {
    x = fx.filter(rx, dt, minCut, beta, dCut);
    y = fy.filter(ry, dt, minCut, beta, dCut);
    const double ex = rx - x, ey = ry - y;
    jitterSum += vm::dsqrt(ex * ex + ey * ey); ++jitterN;
    if (!armed && trig >= 0.15) { armed = 1; lx = haveOut ? ox_ : x; ly = haveOut ? oy_ : y; }   // held where the ring is shown
    else if (armed && trig < 0.10) armed = 0;
    if (armed) {
      const double mx = rx - lx, my = ry - ly;
      lockedMovePx = vm::dsqrt(mx * mx + my * my);
      if (lockedMovePx > 90.0 && trig < 0.45) { armed = 0; }      // pointer dragged far away while only touching the trigger: let go
      else { ++lockedMoves; *ox = lx; *oy = ly; return 1; }
    }
    // 0.70: dead zone of 4 px (about 2.5 mm on the menu); beyond it the output trails the filtered point by that much, so it stays put
    // when the hand only trembles and moves smoothly when the hand really moves
    const double deadPx = 4.0;
    if (!haveOut) { haveOut = 1; ox_ = x; oy_ = y; }
    else {
      const double ddx = x - ox_, ddy = y - oy_, dd = vm::dsqrt(ddx * ddx + ddy * ddy);
      if (dd > deadPx) { const double k = (dd - deadPx) / dd; ox_ += ddx * k; oy_ += ddy * k; }
      else { const double a = dt * 2.0 > 1.0 ? 1.0 : dt * 2.0; ox_ += ddx * a; oy_ += ddy * a; }   // inside the zone it still creeps to the filtered point (0.5 s), so no lasting offset
    }
    *ox = ox_; *oy = oy_;
    return 0;
  }
};

// the item under the pointer; the one already hovered is kept until the pointer is more than `margin` pixels outside it (no flicker between neighbours)
inline bool inside_margin(const Rect& r, int px, int py, int margin) {
  return px >= r.x - margin && py >= r.y - margin && px < r.x + r.w + margin && py < r.y + r.h + margin;
}

}  // namespace vmenu
