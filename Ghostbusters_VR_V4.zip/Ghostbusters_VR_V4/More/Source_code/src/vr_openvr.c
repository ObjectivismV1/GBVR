#include "timingmath.h"
#include "handaxismath.h"
#include "ctlprofile.h"
/* OpenVR access through the C function-table API (ABI-neutral, so the same
 * code works with MSVC and clang/mingw builds). openvr_api.dll is shipped
 * next to the probe and loaded by full path.
 *
 * Threads: the session is started on a worker thread. Everything else here is
 * called from the render thread (inside the game's Present) only, and only
 * while vr_capi_ready() is true. The camera thread never calls this file. */
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <stdint.h>
#include "openvr_capi.h" /* C "bool": char typedef (clang/mingw) or <stdbool.h> (MSVC); both are 1 byte */
#include "vr_pose.h"

typedef uint32_t(__cdecl* PFN_VR_InitInternal2)(EVRInitError* err, EVRApplicationType type, const char* startupInfo);
typedef void(__cdecl* PFN_VR_ShutdownInternal)(void);
typedef intptr_t(__cdecl* PFN_VR_GetGenericInterface)(const char* version, EVRInitError* err);
typedef bool(__cdecl* PFN_VR_IsRuntimeInstalled)(void);
typedef bool(__cdecl* PFN_VR_IsHmdPresent)(void);                                              /* 0.67: log only */
typedef const char*(__cdecl* PFN_VR_InitErrorText)(EVRInitError);                              /* VR_GetVRInitErrorAsSymbol / AsEnglishDescription */
typedef bool(__cdecl* PFN_VR_GetRuntimePath)(char* buf, uint32_t size, uint32_t* required);

static volatile LONG g_state;   /* 0 idle, 1 starting, 2 ready, 3 failed */
static volatile LONG g_wantScene;
static int g_isScene;
static volatile LONG g_startBlack;     /* 1.3 */
static volatile float g_startBlackAlpha = -2.0f;
static struct VR_IVRSystem_FnTable* g_sys;
static struct VR_IVRCompositor_FnTable* g_comp;
static struct VR_IVROverlay_FnTable* g_ovr;
static struct VR_IVRSettings_FnTable* g_set;   /* 0.43: read-only (log) */
static PFN_VR_ShutdownInternal g_shutdown;
static SRWLOCK g_hapLock = SRWLOCK_INIT;   /* 0.51: haptics thread vs. shutdown */
static VROverlayHandle_t g_overlay;
static int g_overlayCreated, g_overlayShown;
static VROverlayHandle_t g_menuOvs[2];   /* 0.53: the in-VR menu. 0.70: two of them, shown in turn, so a new picture never flashes blank */
static int g_menuOvMade[2], g_menuOvOn[2], g_menuCur, g_menuOld = -1, g_menuAny;
static DWORD g_menuOldAt;
static float g_menuXf[12], g_menuW; static int g_menuHavePlace;   /* the last placement, so the other overlay can take the same one */
static VROverlayHandle_t g_curOv;    /* 0.66: the menu pointer ring, a tiny overlay of its own that moves every frame */
static int g_curOvCreated, g_curOvShown, g_curOvPicture;
#define GLOW_N 5   /* 1.7.151: 0 = the whole glow, 1..4 = its four corners (top-left, top-right, bottom-left, bottom-right) */
static VROverlayHandle_t g_glowOvs[GLOW_N];   /* 0.95: the soft TV glow behind the flat screen (a see-through picture made by the tool itself) */
static int g_glowMade[GLOW_N], g_glowOn[GLOW_N];
static float g_glowLasts[GLOW_N][4];   /* 1.1: what the glow layer was last given (colour r g b, fade); -1 = unknown */
static float g_scrWant[2] = {0, 1};             /* 1.1: the curve and fade the flat screen should have when it is shown */
static float g_scrLast[2] = {-1, 1};            /* 1.1: curve and fade last sent to the flat screen (it starts flat and fully visible) */
static char g_status[200] = "not started";
static wchar_t g_dllPath[MAX_PATH + 32];

static void set_status(const char* s) { lstrcpynA(g_status, s, (int)sizeof(g_status)); }

static void* get_table(PFN_VR_GetGenericInterface get, const char* version, int* errOut) {
  char name[64];
  EVRInitError err = EVRInitError_VRInitError_None;
  wsprintfA(name, "FnTable:%s", version);
  void* t = (void*)get(name, &err);
  if (errOut) *errOut = (int)err;
  return err == EVRInitError_VRInitError_None ? t : NULL;
}

static DWORD WINAPI start_thread(LPVOID unused) {
  (void)unused;
  int scene = g_wantScene != 0;
  HMODULE lib = LoadLibraryW(g_dllPath);
  if (!lib) { set_status("openvr_api.dll not found next to d3d11.dll"); InterlockedExchange(&g_state, 3); return 0; }
  PFN_VR_InitInternal2 init = (PFN_VR_InitInternal2)GetProcAddress(lib, "VR_InitInternal2");
  PFN_VR_GetGenericInterface get = (PFN_VR_GetGenericInterface)GetProcAddress(lib, "VR_GetGenericInterface");
  PFN_VR_IsRuntimeInstalled inst = (PFN_VR_IsRuntimeInstalled)GetProcAddress(lib, "VR_IsRuntimeInstalled");
  g_shutdown = (PFN_VR_ShutdownInternal)GetProcAddress(lib, "VR_ShutdownInternal");
  if (!init || !get || !g_shutdown) { set_status("openvr_api.dll is missing required exports"); InterlockedExchange(&g_state, 3); return 0; }
  if (inst && !inst()) {
    set_status("SteamVR runtime is not installed");
    steamvr_diag_before(scene ? "scene" : "background", -1, 0, "", g_dllPath);
    InterlockedExchange(&g_state, 3);
    return 0;
  }

  /* 0.67: SteamVR health check (log lines only), then up to 3 tries: SteamVR that is still starting or closing often answers the
   * second or third time. Nothing is changed in SteamVR; a failed VR_Init leaves no session behind. */
  {
    PFN_VR_IsHmdPresent hmdPresent = (PFN_VR_IsHmdPresent)GetProcAddress(lib, "VR_IsHmdPresent");
    PFN_VR_GetRuntimePath rtPath = (PFN_VR_GetRuntimePath)GetProcAddress(lib, "VR_GetRuntimePath");
    PFN_VR_InitErrorText symFn = (PFN_VR_InitErrorText)GetProcAddress(lib, "VR_GetVRInitErrorAsSymbol");
    PFN_VR_InitErrorText engFn = (PFN_VR_InitErrorText)GetProcAddress(lib, "VR_GetVRInitErrorAsEnglishDescription");
    char rt[300];
    uint32_t need = 0;
    rt[0] = 0;
    if (rtPath) { if (!rtPath(rt, (uint32_t)sizeof(rt), &need)) rt[0] = 0; }
    steamvr_diag_before(scene ? "scene" : "background", hmdPresent ? (hmdPresent() ? 1 : 0) : -1, inst ? 1 : -1, rt, g_dllPath);
    EVRInitError err = EVRInitError_VRInitError_None;
    int attempt = 1, maxAttempts = 3;
    for (;;) {
      const DWORD t0 = GetTickCount();
      err = EVRInitError_VRInitError_None;
      init(&err, scene ? EVRApplicationType_VRApplication_Scene : EVRApplicationType_VRApplication_Background, NULL);
      {
        const char* sym = symFn ? symFn(err) : NULL;
        const char* eng = engFn ? engFn(err) : NULL;
        maxAttempts = err != EVRInitError_VRInitError_None ? steamvr_diag_max_attempts((int)err) : maxAttempts;
        steamvr_diag_attempt(attempt, maxAttempts, (int)err, sym ? sym : "?", eng ? eng : "?", (int)(GetTickCount() - t0));
        if (err == EVRInitError_VRInitError_None) break;
        if (attempt >= maxAttempts || !steamvr_diag_retryable((int)err)) {
          char b[240];
          steamvr_diag_failed((int)err, sym ? sym : "?", eng ? eng : "?", g_dllPath);
          wsprintfA(b, "VR init failed (%s), error %d%s - %s", scene ? "scene" : "background", (int)err,
                    err == EVRInitError_VRInitError_Init_NoServerForBackgroundApp ? " (start SteamVR first)" : "",
                    steamvr_diag_hint_short((int)err));
          set_status(b);
          InterlockedExchange(&g_state, 3);
          return 0;
        }
      }
      Sleep(4000);
      ++attempt;
    }
  }
  int e1 = 0, e2 = 0, e3 = 0;
  g_sys = (struct VR_IVRSystem_FnTable*)get_table(get, IVRSystem_Version, &e1);
  g_comp = NULL; g_ovr = NULL;
  if (scene) {
    g_comp = (struct VR_IVRCompositor_FnTable*)get_table(get, IVRCompositor_Version, &e2);
    g_ovr = (struct VR_IVROverlay_FnTable*)get_table(get, IVROverlay_Version, &e3);  /* optional */
    { int e4 = 0; g_set = (struct VR_IVRSettings_FnTable*)get_table(get, IVRSettings_Version, &e4); }  /* optional */
  }
  if (!g_sys || (scene && !g_comp)) {
    char b[200];
    wsprintfA(b, "%s error %d, %s error %d (update SteamVR)", IVRSystem_Version, e1, IVRCompositor_Version, e2);
    set_status(b);
    g_sys = NULL; g_comp = NULL; g_ovr = NULL; g_set = NULL;
    g_shutdown();
    InterlockedExchange(&g_state, 3);
    return 0;
  }
  if (scene) g_comp->SetTrackingSpace(ETrackingUniverseOrigin_TrackingUniverseStanding);
  /* 1.3: black from the first moment. Until the first picture arrives SteamVR shows its own grid room; fade it out at once. */
  if (scene && g_startBlack && g_comp->FadeGrid) {
    g_comp->FadeGrid(0.0f, 0);
    g_startBlackAlpha = g_comp->GetCurrentGridAlpha ? g_comp->GetCurrentGridAlpha() : -1.0f;
  }
  {
    char b[200];
    wsprintfA(b, "ready (%s, %s application%s%s)", IVRSystem_Version, scene ? "scene" : "background",
              scene ? ", " : "", scene ? (g_ovr ? "overlay available" : "overlay NOT available") : "");
    set_status(b);
  }
  g_isScene = scene;
  g_overlayCreated = 0; g_overlayShown = 0; for (int gi = 0; gi < GLOW_N; ++gi) { g_glowMade[gi] = 0; g_glowOn[gi] = 0; }
  InterlockedExchange(&g_state, 2);
  return 0;
}

void vr_capi_request_start(const wchar_t* dllDir, int scene) {
  LONG prev = InterlockedCompareExchange(&g_state, 1, 0);
  if (prev == 3) prev = InterlockedCompareExchange(&g_state, 1, 3); /* retry after failure */
  if (prev != 0 && prev != 3) return;                                /* already starting or ready */
  InterlockedExchange(&g_wantScene, scene ? 1 : 0);
  lstrcpynW(g_dllPath, dllDir, MAX_PATH);
  lstrcatW(g_dllPath, L"openvr_api.dll");
  set_status(scene ? "starting (scene)" : "starting");
  HANDLE t = CreateThread(NULL, 0, start_thread, NULL, 0, NULL);
  if (t) CloseHandle(t);
  else { set_status("could not create VR start thread"); InterlockedExchange(&g_state, 3); }
}

int vr_capi_shutdown(void) {
  LONG s = g_state;
  if (s == 1) return 0;  /* start in progress: the caller tries again next frame */
  if (s == 2) {
    InterlockedExchange(&g_state, 1);  /* nobody else may use the tables now */
    if (g_ovr && g_overlayCreated) g_ovr->DestroyOverlay(g_overlay);
    for (int i = 0; i < 2; ++i) if (g_ovr && g_menuOvMade[i]) g_ovr->DestroyOverlay(g_menuOvs[i]);
    if (g_ovr && g_curOvCreated) g_ovr->DestroyOverlay(g_curOv);
    g_menuOvMade[0] = g_menuOvMade[1] = 0; g_menuOvOn[0] = g_menuOvOn[1] = 0; g_menuAny = 0; g_menuOld = -1; g_menuCur = 0;
    g_curOvCreated = 0; g_curOvShown = 0; g_curOvPicture = 0;
    for (int gi = 0; gi < GLOW_N; ++gi) { if (g_ovr && g_glowMade[gi]) g_ovr->DestroyOverlay(g_glowOvs[gi]); g_glowMade[gi] = 0; g_glowOn[gi] = 0; }
    g_overlayCreated = 0; g_overlayShown = 0;
    AcquireSRWLockExclusive(&g_hapLock);   /* 0.51: the haptics thread is out of the tables */
    g_sys = NULL; g_comp = NULL; g_ovr = NULL; g_set = NULL; g_isScene = 0;
    ReleaseSRWLockExclusive(&g_hapLock);
    if (g_shutdown) g_shutdown();
    set_status("stopped");
  }
  InterlockedExchange(&g_state, 0);
  return 1;
}

int vr_capi_ready(void) { return g_state == 2 && g_sys != NULL; }
int vr_capi_starting(void) { return g_state == 1; }
int vr_capi_failed(void) { return g_state == 3; }
int vr_capi_is_scene(void) { return vr_capi_ready() && g_isScene && g_comp != NULL; }
const char* vr_capi_status(void) { return g_status; }

static void copy34(float out[12], const struct HmdMatrix34_t* m) {
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 4; ++c) out[r * 4 + c] = m->m[r][c];
}

static int pose_usable(const TrackedDevicePose_t* p) {
  return p->bPoseIsValid && p->bDeviceIsConnected && p->eTrackingResult == ETrackingResult_TrackingResult_Running_OK;
}

int vr_capi_hmd_pose(float pose34[12], int* trackingResult) {
  if (!vr_capi_ready()) return 0;
  TrackedDevicePose_t pose;
  ZeroMemory(&pose, sizeof(pose));
  g_sys->GetDeviceToAbsoluteTrackingPose(ETrackingUniverseOrigin_TrackingUniverseStanding, 0.0f, &pose, 1);
  if (trackingResult) *trackingResult = (int)pose.eTrackingResult;
  if (!pose_usable(&pose)) return 0;
  copy34(pose34, &pose.mDeviceToAbsoluteTracking);
  return 1;
}

static float g_handPredictSec = 0.0f;
static int g_handPredictOff = 0;
void vr_capi_set_hand_predict_ms(int ms) { if (ms < 0) ms = 0; if (ms > 80) ms = 80; g_handPredictSec = (float)ms * 0.001f; }
/* 0.68: the menu pointer wants the plain measured pose (a predicted one adds the hand's velocity noise: jitter); 1 = no prediction for the next calls */
void vr_capi_hand_predict_off(int off) { g_handPredictOff = off ? 1 : 0; }

/* 1.7.19: left-handed play. Everything above this file asks for the "right hand" as the gun hand; with this switch the physical left controller answers to that name (and the right one to "left"),
   so every system (gun, fingers, trap, PKE, menu, buzz) mirrors at once. Controller families (Index, Vive wands, Windows MR) get their stick / click read from the right axis here. */
static volatile LONG g_swapHands = 0;
void vr_capi_set_handed(int left) { InterlockedExchange(&g_swapHands, left ? 1 : 0); }
static int g_famKind[2];                       /* by logical hand */
static int g_famLook[2];                       /* 1.7.87: an Index-type controller that is not Valve's (Virtual Desktop "Emulate Index Controllers", other drivers) */
static char g_famName[2][48];
static int g_stickAxis[2];                      /* 1.7.96: the analog axis the stick is read from right now (0, 2 or 3) */
static int g_axType[2][5];                     /* 1.7.117: SteamVR's own axis types (EVRControllerAxisType), -1 = not said */
static int g_makerForeign[2];                  /* 1.7.117: the maker is known and is not Valve */
static unsigned long long g_supBtns[2];        /* 1.7.117: Prop_SupportedButtons */
static struct GbvrDecState g_decSt[2];
static struct GbvrDecodeOut g_decLast[2];
static volatile int g_layoutOverride = 0, g_stickForce = -1;   /* 1.7.117: the settings file's controller_layout / stick_axis */
void vr_capi_set_compat(int layout, int stickAxis) { g_layoutOverride = layout < 0 || layout > 5 ? 0 : layout; g_stickForce = stickAxis < 0 || stickAxis > 4 ? -1 : stickAxis; }
static float g_axPeak[2][5];                   /* 1.7.87: the largest push seen on each analog axis, by logical hand (log evidence) */
static TrackedDeviceIndex_t g_famId[2];
static const char* has_str(const char* h, const char* n) {   /* no C runtime in this DLL: a tiny strstr */
  for (; *h; ++h) { const char* a = h; const char* b = n; while (*a && *b && *a == *b) { ++a; ++b; } if (!*b) return h; }
  return 0;
}
static int classify_family(const char* t) {
  char lo[48]; int i = 0;
  for (; t[i] && i < 47; ++i) lo[i] = (t[i] >= 'A' && t[i] <= 'Z') ? (char)(t[i] + 32) : t[i];
  lo[i] = 0;
  if (!lo[0]) return 0;
  if (has_str(lo, "knuckles") || has_str(lo, "index")) return 2;
  if (has_str(lo, "vive_controller")) return 3;
  if (has_str(lo, "vive") && !has_str(lo, "cosmos") && !has_str(lo, "focus") && !has_str(lo, "xr") && !has_str(lo, "tracker")) return 3;
  if (has_str(lo, "holographic") || has_str(lo, "windowsmr") || has_str(lo, "wmr")) return 4;
  if (has_str(lo, "oculus") || has_str(lo, "touch") || has_str(lo, "pico") || has_str(lo, "frame") || has_str(lo, "cosmos") || has_str(lo, "focus") || has_str(lo, "xr") || has_str(lo, "quest") || has_str(lo, "rift")) return 1;
  return 5;
}
int vr_capi_family(int hand, char* name, int nameSize) {
  const int h = hand ? 1 : 0;
  if (name && nameSize > 0) { int i = 0; for (; i < nameSize - 1 && g_famName[h][i]; ++i) name[i] = g_famName[h][i]; name[i] = 0; }
  return g_famKind[h];
}
/* 1.7.87: the largest push seen on axes 0..4 of this hand since its controller was last (re)detected, x1000. Returns 1 when the stick is read from a look-alike's other axis rule. */
int vr_capi_axis_peaks(int hand, int* peaksX1000, int* lookalike) {
  const int h = hand ? 1 : 0;
  if (peaksX1000) for (int a = 0; a < 5; ++a) peaksX1000[a] = (int)(g_axPeak[h][a] * 1000.0f + 0.5f);
  if (lookalike) *lookalike = g_famLook[h];
  return g_famKind[h];
}
int vr_capi_stick_axis(int hand) { return g_stickAxis[hand ? 1 : 0]; }   /* 1.7.96 */
static void family_probe(int h, TrackedDeviceIndex_t id) {
  if (g_famId[h] == id) return;
  g_famId[h] = id;
  ETrackedPropertyError pe;
  char ct[48]; ct[0] = 0;
  g_sys->GetStringTrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_ControllerType_String, ct, (uint32_t)sizeof(ct), &pe);
  if (!ct[0]) g_sys->GetStringTrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_ModelNumber_String, ct, (uint32_t)sizeof(ct), &pe);
  g_famKind[h] = classify_family(ct);
  {   /* 1.7.87: who makes it (Valve = a real Index; anything else with an Index profile is a look-alike whose stick axis is checked) */
    char maker[40]; maker[0] = 0;
    g_sys->GetStringTrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_ManufacturerName_String, maker, (uint32_t)sizeof(maker), &pe);
    maker[sizeof(maker) - 1] = 0;
    g_famLook[h] = gbvr_index_lookalike(g_famKind[h], maker);
    g_makerForeign[h] = maker[0] && !gbvr_has_valve(maker) ? 1 : 0;
    {   /* name for the CONTROLLERFAMILY line: "type|maker" (48 bytes) */
      int n = 0;
      for (; ct[n] && n < 28; ++n) g_famName[h][n] = ct[n];
      if (maker[0] && n < 44) { g_famName[h][n++] = '|'; for (int k = 0; maker[k] && n < 47; ++k) g_famName[h][n++] = maker[k]; }
      g_famName[h][n] = 0;
    }
  }
  ZeroMemory(g_axPeak[h], sizeof(g_axPeak[h]));
  ZeroMemory(&g_decSt[h], sizeof(g_decSt[h]));
  ZeroMemory(&g_decLast[h], sizeof(g_decLast[h]));
  for (int a = 0; a < 5; ++a) {   /* 1.7.117: what SteamVR says each axis is (the same way a browser tells a stick from a trackpad) */
    pe = 0;
    int t = g_sys->GetInt32TrackedDeviceProperty(id, (ETrackedDeviceProperty)(ETrackedDeviceProperty_Prop_Axis0Type_Int32 + a), &pe);
    g_axType[h][a] = pe == 0 ? t : -1;
  }
  pe = 0;
  g_supBtns[h] = g_sys->GetUint64TrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_SupportedButtons_Uint64, &pe);
}
/* 1.7.117: one line of facts about a hand for the log (what the decoder is doing right now): family used, stick axis, axis types, counters */
void vr_capi_layout_report(int hand, char* buf, int size) {
  const int h = hand ? 1 : 0;
  if (size > 0) buf[0] = 0;
  if (size < 300) return;
  wsprintfA(buf, "family=%d(detected %d%s) layoutOverride=%d stickAxisForce=%d stickAxis=%d axisTypes=%d,%d,%d,%d,%d supportedButtons=%08x_%08x foreignMaker=%d edgePushDropped=%ld padAClicks=%ld padStickClicks=%ld",
            g_decLast[h].family, g_famKind[h], g_famLook[h] ? " look-alike" : "", (int)g_layoutOverride, (int)g_stickForce, g_decLast[h].axis,
            g_axType[h][0], g_axType[h][1], g_axType[h][2], g_axType[h][3], g_axType[h][4], (unsigned)(g_supBtns[h] >> 32), (unsigned)g_supBtns[h],
            g_makerForeign[h], g_decSt[h].edgeSupp, g_decSt[h].padAClicks, g_decSt[h].padStickClicks);
}

static int hand_read(int hand, struct GbvrHandRaw* out, int predict);
int vr_capi_hand(int hand, struct GbvrHandRaw* out) { return hand_read(hand, out, !g_handPredictOff); }
/* 1.7.31: the measured pose (no prediction) without touching the global switch, so the hand-held menu's own thread can ask while the render thread asks for the predicted pose */
int vr_capi_hand_measured(int hand, struct GbvrHandRaw* out) { return hand_read(hand, out, 0); }
static int hand_read(int hand, struct GbvrHandRaw* out, int predict) {
  ZeroMemory(out, sizeof(*out));
  if (!vr_capi_ready()) return 0;
  const int logicalHand = hand ? 1 : 0;
  const int physHand = logicalHand ^ (g_swapHands ? 1 : 0);
  TrackedDeviceIndex_t id = g_sys->GetTrackedDeviceIndexForControllerRole(
      physHand ? ETrackedControllerRole_TrackedControllerRole_RightHand : ETrackedControllerRole_TrackedControllerRole_LeftHand);
  if (id == 0 || id >= 64) return 0;   /* 0 is the headset: role not assigned */
  VRControllerState_t st;
  TrackedDevicePose_t pose;
  ZeroMemory(&st, sizeof(st));
  ZeroMemory(&pose, sizeof(pose));
  if (!g_sys->GetControllerStateWithPose(ETrackingUniverseOrigin_TrackingUniverseStanding, id, &st, (uint32_t)sizeof(st), &pose)) return 0;
  if (!pose_usable(&pose)) return 0;
  copy34(out->pose34, &pose.mDeviceToAbsoluteTracking);
  if (g_handPredictSec > 0.0f && predict) {   /* 0.50: where the controller will be when the picture reaches the eyes */
    TrackedDevicePose_t all[64];
    ZeroMemory(all, sizeof(all));
    g_sys->GetDeviceToAbsoluteTrackingPose(ETrackingUniverseOrigin_TrackingUniverseStanding, g_handPredictSec, all, 64);
    if (pose_usable(&all[id])) copy34(out->pose34, &all[id].mDeviceToAbsoluteTracking);
  }
  family_probe(logicalHand, id);
  {   /* 1.7.19: where the thumb stick lives (1.7.87: handaxismath.h; an Index look-alike takes whichever of axis 3 / axis 0 is pushed further). */
    float ax[5], ay[5];
    for (int a = 0; a < 5; ++a) { ax[a] = st.rAxis[a].x; ay[a] = st.rAxis[a].y; }
    struct GbvrDecodeIn din;
    struct GbvrDecodeOut dout;
    din.family = g_famKind[logicalHand]; din.layoutOverride = g_layoutOverride; din.stickAxisForce = g_stickForce; din.lookalike = g_makerForeign[logicalHand];
    for (int a = 0; a < 5; ++a) { din.axisType[a] = g_axType[logicalHand][a]; din.peaks[a] = g_axPeak[logicalHand][a]; din.ax[a] = ax[a]; din.ay[a] = ay[a]; }
    din.pressed = st.ulButtonPressed; din.touched = st.ulButtonTouched;
    gbvr_decode(&din, &g_decSt[logicalHand], &dout);
    g_decLast[logicalHand] = dout;
    struct GbvrStickRead sr;
    sr.x = dout.x; sr.y = dout.y; sr.pressed = dout.pressed; sr.touched = dout.touched; sr.axis = dout.axis;
    g_stickAxis[logicalHand] = sr.axis;
    out->stickX = sr.x;
    out->stickY = sr.y;
    out->trigger = st.rAxis[1].x;
    out->grip = dout.grip;   /* 1.7.111 the grip squeeze (Touch controllers report it on axis 2); 1.7.117: other controllers follow the grip button */
    out->thumbTouch = (int)((st.ulButtonTouched >> 1) & 1ull) | (int)((st.ulButtonTouched >> 7) & 1ull) | (int)((st.ulButtonTouched >> 32) & 1ull);   /* B/Y, A/X, stick */
    out->trigTouch = (int)((st.ulButtonTouched >> 33) & 1ull);
    out->pressed = sr.pressed;
    out->touched = sr.touched;
    gbvr_axis_peaks(g_axPeak[logicalHand], ax, ay);
  }
  out->valid = 1;
  return 1;
}

/* 0.51: callable from the haptics thread. 1 = pulse sent, 0 = headset session not ready, -1 = no controller in that role. */
static TrackedDeviceIndex_t g_hapId[2];
static DWORD g_hapIdTick[2];
int vr_capi_haptic_dev(int hand, unsigned us) {
  int r = 0;
  if (!us) return 0;
  AcquireSRWLockShared(&g_hapLock);
  if (g_state == 2 && g_sys) {
    int h = (hand ? 1 : 0) ^ (g_swapHands ? 1 : 0);   /* 1.7.19: left-handed play buzzes the other controller */
    DWORD now = GetTickCount();
    if (g_hapIdTick[h] == 0 || now - g_hapIdTick[h] > 400 || g_hapId[h] == 0) {
      g_hapId[h] = g_sys->GetTrackedDeviceIndexForControllerRole(
          h ? ETrackedControllerRole_TrackedControllerRole_RightHand : ETrackedControllerRole_TrackedControllerRole_LeftHand);
      g_hapIdTick[h] = now ? now : 1;
    }
    if (g_hapId[h] == 0 || g_hapId[h] >= 64) { r = -1; }
    else {
      if (us > 3999) us = 3999;
      g_sys->TriggerHapticPulse(g_hapId[h], 0, (unsigned short)us);
      r = 1;
    }
  }
  ReleaseSRWLockShared(&g_hapLock);
  return r;
}

/* 0.51: is SteamVR giving this application the controller input (dashboard closed etc.)? -1 unknown */
int vr_capi_input_available(void) {
  int r = -1;
  AcquireSRWLockShared(&g_hapLock);
  if (g_state == 2 && g_sys && g_sys->IsInputAvailable) r = g_sys->IsInputAvailable() ? 1 : 0;
  ReleaseSRWLockShared(&g_hapLock);
  return r;
}

void vr_capi_haptic(int hand, unsigned us) {
  if (!vr_capi_ready() || !us) return;
  TrackedDeviceIndex_t id = g_sys->GetTrackedDeviceIndexForControllerRole(
      ((hand ? 1 : 0) ^ (g_swapHands ? 1 : 0)) ? ETrackedControllerRole_TrackedControllerRole_RightHand : ETrackedControllerRole_TrackedControllerRole_LeftHand);
  if (id == 0 || id >= 64) return;
  if (us > 3999) us = 3999;
  g_sys->TriggerHapticPulse(id, 0, (unsigned short)us);
}

int vr_capi_eye_params(int eye, struct GbvrEyeParams* out) {
  if (!vr_capi_ready()) return 0;
  EVREye e = eye ? EVREye_Eye_Right : EVREye_Eye_Left;
  out->left = out->right = out->top = out->bottom = 0;
  g_sys->GetProjectionRaw(e, &out->left, &out->right, &out->top, &out->bottom);
  struct HmdMatrix34_t m = g_sys->GetEyeToHeadTransform(e);
  copy34(out->eyeToHead, &m);
  return 1;
}

int vr_capi_wait_get_poses(float pose34[12], int* poseValid) {
  *poseValid = 0;
  if (!vr_capi_is_scene()) return -1;
  TrackedDevicePose_t pose;
  ZeroMemory(&pose, sizeof(pose));
  EVRCompositorError e = g_comp->WaitGetPoses(&pose, 1, NULL, 0);
  if (pose_usable(&pose)) {
    copy34(pose34, &pose.mDeviceToAbsoluteTracking);
    *poseValid = 1;
  }
  return (int)e;
}

int vr_capi_submit(int eye, void* d3d11Texture, const float bounds[4], const float pose34[12], int gammaSpace) {
  if (!vr_capi_is_scene()) return -1;
  VRTextureWithPose_t t;
  ZeroMemory(&t, sizeof(t));
  t.handle = d3d11Texture;
  t.eType = ETextureType_TextureType_DirectX;
  t.eColorSpace = gammaSpace ? EColorSpace_ColorSpace_Gamma : EColorSpace_ColorSpace_Auto;
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 4; ++c) t.mDeviceToAbsoluteTracking.m[r][c] = pose34[r * 4 + c];
  VRTextureBounds_t b;
  b.uMin = bounds[0]; b.vMin = bounds[1]; b.uMax = bounds[2]; b.vMax = bounds[3];
  return (int)g_comp->Submit(eye ? EVREye_Eye_Right : EVREye_Eye_Left, (struct Texture_t*)&t, &b,
                             EVRSubmitFlags_Submit_TextureWithPose);
}

void vr_capi_clear_last_frame(void) {
  if (vr_capi_is_scene()) g_comp->ClearLastSubmittedFrame();
}

/* 1.7.29: the flat screen's own laser (SteamVR draws a laser from each controller and sends mouse events) can be switched off while the hand-held game menu is up:
   the menu has its own, smoother pointer there and two pointers would click twice. 1 = laser (the default), 0 = none. Applied on the next screen update. */
static int g_flatLaserWant = 1, g_flatLaserSet = 1;
void vr_capi_flat_laser(int on) { g_flatLaserWant = on ? 1 : 0; }
/* 1.7.31: only the placement of the flat screen overlay (no new picture): the hand-held menu's own thread calls this many times a second so the panel follows the hand at the display's pace.
   OpenVR's overlay calls may be made from any thread. */
void vr_capi_overlay_move(const float* xform34, float widthMeters) {
  if (!g_ovr || !g_overlayCreated || !xform34) return;
  struct HmdMatrix34_t m;
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 4; ++c) m.m[r][c] = xform34[r * 4 + c];
  g_ovr->SetOverlayWidthInMeters(g_overlay, widthMeters);
  g_ovr->SetOverlayTransformAbsolute(g_overlay, ETrackingUniverseOrigin_TrackingUniverseStanding, &m);
}
int vr_capi_overlay_update(void* d3d11Texture, const float* xform34, float widthMeters, int gammaSpace) {
  if (!vr_capi_is_scene() || !g_ovr) return -1;
  EVROverlayError e;
  if (!g_overlayCreated) {
    static char key[] = "gbvr.flatscreen";
    static char name[] = "Ghostbusters flat screen";
    e = g_ovr->CreateOverlay(key, name, &g_overlay);
    if (e != EVROverlayError_VROverlayError_None) e = g_ovr->FindOverlay(key, &g_overlay);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    g_overlayCreated = 1;
    g_scrLast[0] = -1.0f; g_scrLast[1] = 1.0f;
    /* The game's back buffer alpha is not meaningful: draw the screen opaque. */
    g_ovr->SetOverlayFlag(g_overlay, VROverlayFlags_IgnoreTextureAlpha, 1);
    g_ovr->SetOverlayAlpha(g_overlay, 1.0f);
    /* 0.42: the controllers point at the screen like a mouse (SteamVR draws the laser and sends mouse events). */
    g_ovr->SetOverlayInputMethod(g_overlay, VROverlayInputMethod_Mouse);
    {
      struct HmdVector2_t scale;
      scale.v[0] = 1.0f; scale.v[1] = 1.0f;
      g_ovr->SetOverlayMouseScale(g_overlay, &scale);
    }
    g_ovr->SetOverlayFlag(g_overlay, VROverlayFlags_SendVRDiscreteScrollEvents, 1);
    g_ovr->SetOverlaySortOrder(g_overlay, 2);   /* 0.95: above the TV glow (1), below the menu (20+) */
  }
  if (g_flatLaserSet != g_flatLaserWant) {
    g_ovr->SetOverlayInputMethod(g_overlay, g_flatLaserWant ? VROverlayInputMethod_Mouse : VROverlayInputMethod_None);
    g_flatLaserSet = g_flatLaserWant;
  }
  if (xform34) {
    struct HmdMatrix34_t m;
    for (int r = 0; r < 3; ++r)
      for (int c = 0; c < 4; ++c) m.m[r][c] = xform34[r * 4 + c];
    g_ovr->SetOverlayWidthInMeters(g_overlay, widthMeters);
    g_ovr->SetOverlayTransformAbsolute(g_overlay, ETrackingUniverseOrigin_TrackingUniverseStanding, &m);
  }
  vr_capi_overlay_style(g_scrWant[0], g_scrWant[1]);   /* 1.1: curve and fade are in force before the screen is shown */
  struct Texture_t t;
  t.handle = d3d11Texture;
  t.eType = ETextureType_TextureType_DirectX;
  t.eColorSpace = gammaSpace ? EColorSpace_ColorSpace_Gamma : EColorSpace_ColorSpace_Auto;
  e = g_ovr->SetOverlayTexture(g_overlay, &t);
  if (e != EVROverlayError_VROverlayError_None) return (int)e;
  if (!g_overlayShown) {
    e = g_ovr->ShowOverlay(g_overlay);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    g_overlayShown = 1;
  }
  return 0;
}

/* 0.53 the in-VR menu: a second overlay whose picture is a plain RGBA buffer made by the tool itself (GDI), with the same
   laser-pointer mouse input as the flat screen. rgba may be NULL (only move / show it). Returns EVROverlayError, -1 no session. */
static int g_menuLaser = 0;
static float g_menuAlphaNow = 1.0f;   /* 1.3: the menu fades in (vr_capi_menu_alpha); a picture made later starts at the same value */
void vr_capi_menu_laser(int on) { g_menuLaser = on; }
static int menu_make(int i) {
  if (g_menuOvMade[i]) return 0;
  static char key0[] = "gbvr.menu", key1[] = "gbvr.menu2";
  static char name0[] = "Ghostbusters VR menu", name1[] = "Ghostbusters VR menu (b)";
  char* key = i ? key1 : key0; char* name = i ? name1 : name0;
  EVROverlayError e = g_ovr->CreateOverlay(key, name, &g_menuOvs[i]);
  if (e != EVROverlayError_VROverlayError_None) e = g_ovr->FindOverlay(key, &g_menuOvs[i]);
  if (e != EVROverlayError_VROverlayError_None) return (int)e;
  g_menuOvMade[i] = 1;
  VROverlayHandle_t h = g_menuOvs[i];
  g_ovr->SetOverlayFlag(h, VROverlayFlags_IgnoreTextureAlpha, 1);
  g_ovr->SetOverlayFlag(h, VROverlayFlags_MakeOverlaysInteractiveIfVisible, g_menuLaser ? 1 : 0);   /* 0.65: no laser = the game keeps the controllers, so the own pointer ring works */
  g_ovr->SetOverlayAlpha(h, g_menuAlphaNow);
  g_ovr->SetOverlayInputMethod(h, g_menuLaser ? VROverlayInputMethod_Mouse : VROverlayInputMethod_None);
  {
    struct HmdVector2_t scale;
    scale.v[0] = 1.0f; scale.v[1] = 1.0f;
    g_ovr->SetOverlayMouseScale(h, &scale);
  }
  g_ovr->SetOverlaySortOrder(h, 20);   /* in front of the flat game screen */
  return 0;
}
static void menu_place(int i, const float* xform34, float widthMeters) {
  if (xform34 != g_menuXf) { for (int k = 0; k < 12; ++k) g_menuXf[k] = xform34[k]; g_menuW = widthMeters; g_menuHavePlace = 1; }
  struct HmdMatrix34_t m;
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 4; ++c) m.m[r][c] = xform34[r * 4 + c];
  g_ovr->SetOverlayWidthInMeters(g_menuOvs[i], widthMeters);
  g_ovr->SetOverlayTransformAbsolute(g_menuOvs[i], ETrackingUniverseOrigin_TrackingUniverseStanding, &m);
}
/* 1.7.31: the same for the probe's settings pages (both picture overlays), without touching the remembered placement */
void vr_capi_menu_move(const float* xform34, float widthMeters) {
  if (!g_ovr || !xform34) return;
  struct HmdMatrix34_t m;
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 4; ++c) m.m[r][c] = xform34[r * 4 + c];
  for (int i = 0; i < 2; ++i) {
    if (!g_menuOvMade[i] || !g_menuOvOn[i]) continue;
    g_ovr->SetOverlayWidthInMeters(g_menuOvs[i], widthMeters);
    g_ovr->SetOverlayTransformAbsolute(g_menuOvs[i], ETrackingUniverseOrigin_TrackingUniverseStanding, &m);
  }
}
/* 0.70: the old picture stays up until the new one has been on screen for a moment, then goes. Called every frame. */
void vr_capi_menu_settle(void) {
  if (g_menuOld < 0 || !g_ovr || !vr_capi_ready()) return;
  if ((DWORD)(GetTickCount() - g_menuOldAt) < 140) return;
  if (g_menuOvMade[g_menuOld] && g_menuOvOn[g_menuOld]) { g_ovr->HideOverlay(g_menuOvs[g_menuOld]); g_menuOvOn[g_menuOld] = 0; }
  g_menuOld = -1;
}
int vr_capi_menu_overlay(const void* rgba, int w, int h, const float* xform34, float widthMeters) {
  if (!vr_capi_is_scene() || !g_ovr) return -1;
  EVROverlayError e;
  int r = menu_make(g_menuCur);
  if (r) return r;
  if (rgba && w > 0 && h > 0) {
    int tgt = g_menuCur;
    if (g_menuAny && g_menuOvOn[g_menuCur]) {   /* something is on screen: build the new picture in the other overlay, then show it on top */
      tgt = 1 - g_menuCur;
      r = menu_make(tgt);
      if (r) return r;
      if (g_menuOld == tgt) { if (g_menuOvOn[tgt]) { g_ovr->HideOverlay(g_menuOvs[tgt]); g_menuOvOn[tgt] = 0; } g_menuOld = -1; }
    }
    if (xform34) menu_place(tgt, xform34, widthMeters);
    else if (g_menuHavePlace) menu_place(tgt, g_menuXf, g_menuW);
    e = g_ovr->SetOverlayRaw(g_menuOvs[tgt], (void*)rgba, (uint32_t)w, (uint32_t)h, 4);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    if (tgt != g_menuCur) {
      g_ovr->SetOverlaySortOrder(g_menuOvs[tgt], 21);
      g_ovr->SetOverlaySortOrder(g_menuOvs[g_menuCur], 20);
      e = g_ovr->ShowOverlay(g_menuOvs[tgt]);
      if (e != EVROverlayError_VROverlayError_None) return (int)e;
      g_menuOvOn[tgt] = 1;
      g_menuOld = g_menuCur; g_menuOldAt = GetTickCount();
      g_menuCur = tgt;
    } else if (!g_menuOvOn[tgt]) {
      e = g_ovr->ShowOverlay(g_menuOvs[tgt]);
      if (e != EVROverlayError_VROverlayError_None) return (int)e;
      g_menuOvOn[tgt] = 1;
    }
    g_menuAny = 1;
    return 0;
  }
  if (xform34) {
    for (int i = 0; i < 2; ++i) if (g_menuOvMade[i]) menu_place(i, xform34, widthMeters);
  }
  if (!g_menuOvOn[g_menuCur] && g_menuAny) {
    e = g_ovr->ShowOverlay(g_menuOvs[g_menuCur]);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    g_menuOvOn[g_menuCur] = 1;
  }
  return 0;
}

/* 0.66 the menu pointer: a small ring overlay placed where the controller ray meets the menu. Moving an overlay is a cheap call,
   unlike uploading the whole menu picture again (4 MB) for every pointer move, which made the 0.61-0.65 menu lag and flash.
   show = 0 hides it. rgba (w x h, straight alpha) is uploaded once. xform34 = placement in standing space. Returns EVROverlayError, -1 no session. */
int vr_capi_cursor(const void* rgba, int w, int h, const float* xform34, float widthMeters, int show) {
  if (!show) {
    if (vr_capi_ready() && g_ovr && g_curOvCreated && g_curOvShown) { g_ovr->HideOverlay(g_curOv); g_curOvShown = 0; }
    return 0;
  }
  if (!vr_capi_is_scene() || !g_ovr) return -1;
  EVROverlayError e;
  if (!g_curOvCreated) {
    static char key[] = "gbvr.menucursor";
    static char name[] = "Ghostbusters VR menu pointer";
    e = g_ovr->CreateOverlay(key, name, &g_curOv);
    if (e != EVROverlayError_VROverlayError_None) e = g_ovr->FindOverlay(key, &g_curOv);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    g_curOvCreated = 1;
    g_ovr->SetOverlayAlpha(g_curOv, 1.0f);
    g_ovr->SetOverlayInputMethod(g_curOv, VROverlayInputMethod_None);
    g_ovr->SetOverlaySortOrder(g_curOv, 30);   /* in front of the menu (20) */
  }
  if (!g_curOvPicture && rgba && w > 0 && h > 0) {
    e = g_ovr->SetOverlayRaw(g_curOv, (void*)rgba, (uint32_t)w, (uint32_t)h, 4);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    g_curOvPicture = 1;
  }
  if (!g_curOvPicture) return -2;
  if (xform34) {
    struct HmdMatrix34_t m;
    for (int r = 0; r < 3; ++r)
      for (int c = 0; c < 4; ++c) m.m[r][c] = xform34[r * 4 + c];
    g_ovr->SetOverlayWidthInMeters(g_curOv, widthMeters);
    e = g_ovr->SetOverlayTransformAbsolute(g_curOv, ETrackingUniverseOrigin_TrackingUniverseStanding, &m);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
  }
  if (!g_curOvShown) {
    e = g_ovr->ShowOverlay(g_curOv);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    g_curOvShown = 1;
  }
  return 0;
}

/* 1.3 the menu's see-through-ness, 0..1 (both overlays; the one made later starts at the same value). Cheap: only calls SteamVR when the value changed. */
void vr_capi_menu_alpha(float a) {
  if (a < 0.0f) a = 0.0f;
  if (a > 1.0f) a = 1.0f;
  if (a == g_menuAlphaNow) return;
  g_menuAlphaNow = a;
  if (!g_ovr || !vr_capi_ready()) return;
  for (int i = 0; i < 2; ++i)
    if (g_menuOvMade[i]) g_ovr->SetOverlayAlpha(g_menuOvs[i], a);
}

void vr_capi_menu_hide(void) {
  if (vr_capi_ready() && g_ovr && g_curOvCreated && g_curOvShown) { g_ovr->HideOverlay(g_curOv); g_curOvShown = 0; }
  for (int i = 0; i < 2; ++i)
    if (vr_capi_ready() && g_ovr && g_menuOvMade[i] && g_menuOvOn[i]) { g_ovr->HideOverlay(g_menuOvs[i]); g_menuOvOn[i] = 0; }
  g_menuOld = -1; g_menuAny = 0;
}

int vr_capi_menu_events(struct GbvrOverlayEvt* out, int max) {
  int n = 0;
  if (!vr_capi_ready() || !g_ovr || !out) return 0;
  struct VREvent_t ev;
  int dry = 0;
  for (int i = 0; i < 128 && n < max && dry < 2; ++i) {
    ZeroMemory(&ev, sizeof(ev));
    const int which = (i & 1);   /* both menu overlays are asked in turn (the laser belongs to the one on top) */
    if (!g_menuOvMade[which] || !g_menuOvOn[which]) { if (!g_menuOvMade[1 - which] || !g_menuOvOn[1 - which]) break; continue; }
    if (!g_ovr->PollNextOverlayEvent(g_menuOvs[which], &ev, (uint32_t)sizeof(ev))) { ++dry; continue; }
    dry = 0;
    struct GbvrOverlayEvt* o = &out[n];
    o->x = o->y = o->scrollY = 0; o->button = 0; o->type = 0;
    if (ev.eventType == EVREventType_VREvent_MouseMove) { o->type = 1; o->x = ev.data.mouse.x; o->y = ev.data.mouse.y; }
    else if (ev.eventType == EVREventType_VREvent_MouseButtonDown) { o->type = 2; o->x = ev.data.mouse.x; o->y = ev.data.mouse.y; o->button = (int)ev.data.mouse.button; }
    else if (ev.eventType == EVREventType_VREvent_MouseButtonUp) { o->type = 3; o->x = ev.data.mouse.x; o->y = ev.data.mouse.y; o->button = (int)ev.data.mouse.button; }
    if (o->type) ++n;
  }
  return n;
}

void vr_capi_overlay_hide(void) {
  if (vr_capi_ready() && g_ovr && g_overlayCreated && g_overlayShown) {
    g_ovr->HideOverlay(g_overlay);
    g_overlayShown = 0;
  }
  for (int gi = 0; gi < GLOW_N; ++gi)
    if (vr_capi_ready() && g_ovr && g_glowMade[gi] && g_glowOn[gi]) {   /* 0.95: the TV glow goes with the flat screen */
      g_ovr->HideOverlay(g_glowOvs[gi]);
      g_glowOn[gi] = 0;
    }
}

/* 0.95 the black void. After ClearLastSubmittedFrame SteamVR shows its own grid room behind the flat screen; FadeGrid(.., 0) takes the grid away and leaves black.
   in = 1 brings it back. The alpha is what the compositor reports (1 = grid fully there, 0 = gone), -1 when there is no session. */
void vr_capi_fade_grid(float secs, int in) {
  if (vr_capi_is_scene() && g_comp && g_comp->FadeGrid) g_comp->FadeGrid(secs, in ? 1 : 0);
}
void vr_capi_start_black(int on) { InterlockedExchange(&g_startBlack, on ? 1 : 0); }
float vr_capi_start_black_alpha(void) { return g_startBlackAlpha; }
void vr_capi_fade_color(float secs, float r, float g, float b, float a) {
  if (vr_capi_is_scene() && g_comp && g_comp->FadeToColor) g_comp->FadeToColor(secs, r, g, b, a, 0);
}
int vr_capi_hmd_present(const wchar_t* dllDir) {
  static HMODULE lib; static PFN_VR_IsHmdPresent fn;
  if (!fn) {
    wchar_t path[MAX_PATH + 24];
    lstrcpynW(path, dllDir, MAX_PATH);
    lstrcatW(path, L"openvr_api.dll");
    lib = LoadLibraryW(path);
    if (!lib) return -1;
    fn = (PFN_VR_IsHmdPresent)GetProcAddress(lib, "VR_IsHmdPresent");
    if (!fn) return -1;
  }
  return fn() ? 1 : 0;
}
float vr_capi_grid_alpha(void) {
  if (vr_capi_is_scene() && g_comp && g_comp->GetCurrentGridAlpha) return g_comp->GetCurrentGridAlpha();
  return -1.0f;
}

/* 0.95 the TV glow: a second, larger, see-through overlay just behind the flat screen. rgba (w x h, straight alpha) is uploaded each call that passes it;
   xform34 (standing space) and widthMeters move it, show = 0 hides it. No input (the laser belongs to the screen). Returns EVROverlayError, -1 no session. */
int vr_capi_glow_overlay_n(int idx, const void* rgba, int w, int h, const float* xform34, float widthMeters, int show) {
  if (idx < 0 || idx >= GLOW_N) return -2;
  if (!show) {
    if (vr_capi_ready() && g_ovr && g_glowMade[idx] && g_glowOn[idx]) { g_ovr->HideOverlay(g_glowOvs[idx]); g_glowOn[idx] = 0; }
    return 0;
  }
  if (!vr_capi_is_scene() || !g_ovr) return -1;
  EVROverlayError e;
  if (!g_glowMade[idx]) {
    static char keys[GLOW_N][24] = {"gbvr.flatglow", "gbvr.flatglow.tl", "gbvr.flatglow.tr", "gbvr.flatglow.bl", "gbvr.flatglow.br"};
    static char name[] = "Ghostbusters TV glow";
    e = g_ovr->CreateOverlay(keys[idx], name, &g_glowOvs[idx]);
    if (e != EVROverlayError_VROverlayError_None) e = g_ovr->FindOverlay(keys[idx], &g_glowOvs[idx]);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    g_glowMade[idx] = 1;
    g_ovr->SetOverlayAlpha(g_glowOvs[idx], 0.0f);   /* 1.1: invisible until the fade-in sets it (no pop on the first frame) */
    g_glowLasts[idx][0] = g_glowLasts[idx][1] = g_glowLasts[idx][2] = -1.0f; g_glowLasts[idx][3] = 0.0f;
    g_ovr->SetOverlayInputMethod(g_glowOvs[idx], VROverlayInputMethod_None);
    /* behind the flat screen (2). 1.7.151: the corner layers lie in one plane; neighbours (which overlap along the edges) get different orders so their drawing order is fixed:
       top-left and bottom-right 0, top-right and bottom-left 1 (opposite corners share no visible part) */
    g_ovr->SetOverlaySortOrder(g_glowOvs[idx], (idx == 1 || idx == 4) ? 0 : 1);
  }
  if (xform34) {
    struct HmdMatrix34_t m;
    for (int r = 0; r < 3; ++r)
      for (int c = 0; c < 4; ++c) m.m[r][c] = xform34[r * 4 + c];
    g_ovr->SetOverlayWidthInMeters(g_glowOvs[idx], widthMeters);
    e = g_ovr->SetOverlayTransformAbsolute(g_glowOvs[idx], ETrackingUniverseOrigin_TrackingUniverseStanding, &m);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
  }
  if (rgba && w > 0 && h > 0) {
    e = g_ovr->SetOverlayRaw(g_glowOvs[idx], (void*)rgba, (uint32_t)w, (uint32_t)h, 4);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
  }
  if (!g_glowOn[idx]) {
    e = g_ovr->ShowOverlay(g_glowOvs[idx]);
    if (e != EVROverlayError_VROverlayError_None) return (int)e;
    g_glowOn[idx] = 1;
  }
  return 0;
}
int vr_capi_glow_overlay(const void* rgba, int w, int h, const float* xform34, float widthMeters, int show) { return vr_capi_glow_overlay_n(0, rgba, w, h, xform34, widthMeters, show); }

/* 1.1 steady glow: the halo picture goes up once (vr_capi_glow_overlay); after that only the colour and the fade change here. SetOverlayColor / SetOverlayAlpha need no new texture,
   so nothing in SteamVR is re-made while the glow follows the picture's colours. Returns 0, or -1 when there is no glow layer yet. */
int vr_capi_glow_tint_n(int idx, float r, float g, float b, float a) {
  if (idx < 0 || idx >= GLOW_N) return -2;
  if (!vr_capi_is_scene() || !g_ovr || !g_glowMade[idx]) return -1;
  float* L = g_glowLasts[idx];
  if (r != L[0] || g != L[1] || b != L[2]) { g_ovr->SetOverlayColor(g_glowOvs[idx], r, g, b); L[0] = r; L[1] = g; L[2] = b; }
  if (a != L[3]) { g_ovr->SetOverlayAlpha(g_glowOvs[idx], a); L[3] = a; }
  return 0;
}
int vr_capi_glow_tint(float r, float g, float b, float a) { return vr_capi_glow_tint_n(0, r, g, b, a); }

/* 1.1 the flat 2D screen: how much it bends around you (0 = flat) and how visible it is (0..1, a fade in when it appears). Only changed values are sent. Returns 0, -1 no session / no screen yet. */
int vr_capi_overlay_style(float curvature, float alpha) {
  g_scrWant[0] = curvature; g_scrWant[1] = alpha;   /* remembered: a screen that is made or shown later starts with these, never with a one-frame pop */
  if (!vr_capi_is_scene() || !g_ovr || !g_overlayCreated) return 0;
  if (curvature != g_scrLast[0]) { g_ovr->SetOverlayCurvature(g_overlay, curvature); g_scrLast[0] = curvature; }
  if (alpha != g_scrLast[1]) { g_ovr->SetOverlayAlpha(g_overlay, alpha); g_scrLast[1] = alpha; }
  return 0;
}

int vr_capi_overlay_events(struct GbvrOverlayEvt* out, int max) {
  int n = 0;
  if (!vr_capi_ready() || !g_ovr || !g_overlayCreated || !out) return 0;
  struct VREvent_t ev;
  for (int i = 0; i < 64 && n < max; ++i) {
    ZeroMemory(&ev, sizeof(ev));
    if (!g_ovr->PollNextOverlayEvent(g_overlay, &ev, (uint32_t)sizeof(ev))) break;
    struct GbvrOverlayEvt* o = &out[n];
    o->x = o->y = o->scrollY = 0; o->button = 0; o->type = 0;
    if (ev.eventType == EVREventType_VREvent_MouseMove) { o->type = 1; o->x = ev.data.mouse.x; o->y = ev.data.mouse.y; }
    else if (ev.eventType == EVREventType_VREvent_MouseButtonDown) { o->type = 2; o->x = ev.data.mouse.x; o->y = ev.data.mouse.y; o->button = (int)ev.data.mouse.button; }
    else if (ev.eventType == EVREventType_VREvent_MouseButtonUp) { o->type = 3; o->x = ev.data.mouse.x; o->y = ev.data.mouse.y; o->button = (int)ev.data.mouse.button; }
    else if (ev.eventType == EVREventType_VREvent_ScrollDiscrete) { o->type = 4; o->scrollY = ev.data.scroll.ydelta; }
    if (o->type) ++n;
  }
  return n;
}

/* 0.51: device / focus events (log only): a small ring read by vr_capi_event_pop */
static struct { uint32_t type, dev; DWORD tick; } g_evRing[64];
static volatile LONG g_evHead, g_evTail;
/* 0.52: "the player left the game" events: the SteamVR menu opened, input taken by the dashboard, headset to standby /
   taken off, SteamVR quit. The game keeps running and the player cannot see it: the tool pauses it (autopause). */
static volatile LONG g_leaveCount, g_leaveWhy;
static DWORD g_leaveIgnoreUntil;
int vr_capi_leave_count(void) { return (int)g_leaveCount; }
int vr_capi_leave_why(void) { return (int)g_leaveWhy; }
static void leave_note(uint32_t type, uint32_t dev) {
  int leave = 0;
  switch (type) {
    case 502: case 400: case 106: case 700: case 701: leave = 1; break;
    case 104: leave = (dev == 0); break;          /* the headset (not a controller) lost the user */
    case 9003: case 9004: case 9005: leave = 1; break;   /* headset activity level 2 timeout, 3 standby, 4 idle timeout (9001 + level) */
    default: break;
  }
  if (!leave) return;
  /* the events SteamVR sends while this session starts are not the player leaving */
  if ((int32_t)(GetTickCount() - g_leaveIgnoreUntil) < 0) return;
  g_leaveWhy = (LONG)type;
  InterlockedIncrement(&g_leaveCount);
}
static void ev_note(uint32_t type, uint32_t dev) {
  leave_note(type, dev);
  switch (type) {   /* only the ones that explain missing controllers / haptics */
    case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 111:
    case 400: case 401: case 404: case 406: case 409: case 410: case 411: case 412: case 502: case 503:
    case 700: case 701: case 800: case 1306: case 1307: case 1410: case 1411: case 1412: case 1413: case 1414:
    case 1415: case 1416: case 1417: case 1418: case 1420: break;
    case 9000: case 9001: case 9002: case 9003: case 9004: case 9005: break;   /* 0.52: headset activity level (9001 + level) */
    default: return;
  }
  LONG h = g_evHead;
  if (h - g_evTail >= 64) return;   /* full: drop the newest */
  g_evRing[h & 63].type = type; g_evRing[h & 63].dev = dev; g_evRing[h & 63].tick = GetTickCount();
  InterlockedIncrement(&g_evHead);
}
int vr_capi_event_pop(unsigned* type, unsigned* dev, unsigned* ageMs) {
  LONG t = g_evTail;
  if (t >= g_evHead) return 0;
  *type = g_evRing[t & 63].type; *dev = g_evRing[t & 63].dev; *ageMs = GetTickCount() - g_evRing[t & 63].tick;
  InterlockedIncrement(&g_evTail);
  return 1;
}

int vr_capi_poll_quit(void) {
  if (!vr_capi_ready()) return 0;
  struct VREvent_t ev;
  int quit = 0;
  static int s_lvl = -2;
  if (!g_leaveIgnoreUntil) g_leaveIgnoreUntil = GetTickCount() + 6000;   /* first poll of this process */
  for (int i = 0; i < 32 && g_sys->PollNextEvent(&ev, (uint32_t)sizeof(ev)); ++i) {
    if (ev.eventType == EVREventType_VREvent_Quit) quit = 1;
    ev_note((uint32_t)ev.eventType, (uint32_t)ev.trackedDeviceIndex);
  }
  {  /* 0.52: the headset's activity level (worn / not worn / standby) */
    int lvl = (int)g_sys->GetTrackedDeviceActivityLevel(0);
    if (lvl != s_lvl) {
      if (s_lvl != -2) ev_note((uint32_t)(9001 + lvl), 0);
      s_lvl = lvl;
    }
  }
  if (quit) g_sys->AcknowledgeQuit_Exiting();   /* (the Quit event itself already counted as "player left") */
  return quit;
}

void vr_capi_describe(char* buf, int size) {
  if (size > 0) buf[0] = 0;
  if (!vr_capi_ready() || size < 256) return;
  char model[64] = "?";
  ETrackedPropertyError pe = 0;
  g_sys->GetStringTrackedDeviceProperty(0, ETrackedDeviceProperty_Prop_ModelNumber_String, model, (uint32_t)sizeof(model), &pe);
  model[sizeof(model) - 1] = 0;
  float hz = g_sys->GetFloatTrackedDeviceProperty(0, ETrackedDeviceProperty_Prop_DisplayFrequency_Float, &pe);
  float ipd = g_sys->GetFloatTrackedDeviceProperty(0, ETrackedDeviceProperty_Prop_UserIpdMeters_Float, &pe);
  uint32_t w = 0, h = 0;
  g_sys->GetRecommendedRenderTargetSize(&w, &h);
  /* wsprintfA has no %f: print fixed-point integers. */
  {   /* 1.7.117: who makes the headset and how it is tracked (for compatibility reports) */
    char man[48], trk[48], drv[32];
    ETrackedPropertyError pe2 = 0;
    man[0] = trk[0] = drv[0] = 0;
    g_sys->GetStringTrackedDeviceProperty(0, ETrackedDeviceProperty_Prop_ManufacturerName_String, man, (uint32_t)sizeof(man), &pe2);
    g_sys->GetStringTrackedDeviceProperty(0, ETrackedDeviceProperty_Prop_TrackingSystemName_String, trk, (uint32_t)sizeof(trk), &pe2);
    g_sys->GetStringTrackedDeviceProperty(0, ETrackedDeviceProperty_Prop_RegisteredDeviceType_String, drv, (uint32_t)sizeof(drv), &pe2);
    man[sizeof(man) - 1] = trk[sizeof(trk) - 1] = drv[sizeof(drv) - 1] = 0;
    for (char* c = man; *c; ++c) if (*c == ' ' || *c == '"') *c = '_';
    for (char* c = trk; *c; ++c) if (*c == ' ' || *c == '"') *c = '_';
    for (char* c = drv; *c; ++c) if (*c == ' ' || *c == '"') *c = '_';
    wsprintfA(buf, "model=\"%s\" maker=%s tracking=%s registered=%s refreshHz=%d.%d ipdMillimetres=%d.%d recommendedEye=%ux%u", model, man[0] ? man : "?", trk[0] ? trk : "?", drv[0] ? drv : "?", (int)hz,
              (int)(hz * 10) % 10, (int)(ipd * 1000), (int)(ipd * 10000) % 10, (unsigned)w, (unsigned)h);
  }
}

void vr_capi_recommended_size(unsigned* w, unsigned* h) {
  uint32_t a = 0, b = 0;
  if (w) *w = 0;
  if (h) *h = 0;
  if (!vr_capi_ready()) return;
  g_sys->GetRecommendedRenderTargetSize(&a, &b);
  if (w) *w = (unsigned)a;
  if (h) *h = (unsigned)b;
}

/* 1.7.87: the graphics card the headset hangs on, as the adapter LUID (low part | high part << 32); 0 = SteamVR did not say. The game's own card must be this one. */
unsigned long long vr_capi_output_luid(void) {
  uint64_t dev = 0;
  AcquireSRWLockShared(&g_hapLock);   /* the game's render thread asks; the session may be closed from another thread (F4) */
  if (g_state == 2 && g_sys && g_sys->GetOutputDevice) g_sys->GetOutputDevice(&dev, ETextureType_TextureType_DirectX, NULL);
  ReleaseSRWLockShared(&g_hapLock);
  return (unsigned long long)dev;
}

float vr_capi_display_hz(void) {
  ETrackedPropertyError pe = 0;
  if (!vr_capi_ready()) return 0.0f;
  return g_sys->GetFloatTrackedDeviceProperty(0, ETrackedDeviceProperty_Prop_DisplayFrequency_Float, &pe);
}

/* 0.51: what SteamVR says about a tracked device (log only). which: 0 headset, 1 left hand, 2 right hand. */
static void prop_str(TrackedDeviceIndex_t id, ETrackedDeviceProperty p, char* o, int n) {
  ETrackedPropertyError pe = 0;
  o[0] = 0;
  uint32_t len = g_sys->GetStringTrackedDeviceProperty(id, p, o, (uint32_t)n, &pe);
  if (pe != 0 || len == 0) { lstrcpynA(o, "-", n); return; }
  o[n - 1] = 0;
  for (char* c = o; *c; ++c) if (*c == ' ' || *c == '"') *c = '_';
}
void vr_capi_device_report(char* buf, int size, int which) {
  if (size > 0) buf[0] = 0;
  if (!vr_capi_ready() || size < 600) return;
  TrackedDeviceIndex_t id = 0;
  if (which) {
    id = g_sys->GetTrackedDeviceIndexForControllerRole(which == 2 ? ETrackedControllerRole_TrackedControllerRole_RightHand : ETrackedControllerRole_TrackedControllerRole_LeftHand);
    if (id == 0 || id >= 64) { wsprintfA(buf, "no device in that role (index %u)", (unsigned)id); return; }
  }
  char man[48], model[48], trk[48], rm[48], ct[48], prof[96], hw[32], drv[32];
  prop_str(id, ETrackedDeviceProperty_Prop_ManufacturerName_String, man, sizeof(man));
  prop_str(id, ETrackedDeviceProperty_Prop_ModelNumber_String, model, sizeof(model));
  prop_str(id, ETrackedDeviceProperty_Prop_TrackingSystemName_String, trk, sizeof(trk));
  prop_str(id, ETrackedDeviceProperty_Prop_RenderModelName_String, rm, sizeof(rm));
  prop_str(id, ETrackedDeviceProperty_Prop_ControllerType_String, ct, sizeof(ct));
  prop_str(id, ETrackedDeviceProperty_Prop_InputProfilePath_String, prof, sizeof(prof));
  prop_str(id, ETrackedDeviceProperty_Prop_HardwareRevision_String, hw, sizeof(hw));
  prop_str(id, ETrackedDeviceProperty_Prop_DriverVersion_String, drv, sizeof(drv));
  ETrackedPropertyError pe = 0;
  float bat = g_sys->GetFloatTrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_DeviceBatteryPercentage_Float, &pe);
  int batPct = pe == 0 ? (int)(bat * 100.0f + 0.5f) : -1;
  int provides = g_sys->GetBoolTrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_DeviceProvidesBatteryStatus_Bool, &pe) ? 1 : 0;
  int charging = g_sys->GetBoolTrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_DeviceIsCharging_Bool, &pe) ? 1 : 0;
  uint64_t btns = g_sys->GetUint64TrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_SupportedButtons_Uint64, &pe);
  uint64_t fw = g_sys->GetUint64TrackedDeviceProperty(id, ETrackedDeviceProperty_Prop_FirmwareVersion_Uint64, &pe);
  int conn = g_sys->IsTrackedDeviceConnected(id) ? 1 : 0;
  int cls = (int)g_sys->GetTrackedDeviceClass(id);
  wsprintfA(buf, "index=%u class=%d connected=%d maker=%s model=%s tracking=%s controllerType=%s renderModel=%s hwRev=%s driver=%s "
                 "firmware=%u battery=%d%% providesBattery=%d charging=%d supportedButtons=%08x_%08x inputProfile=%s",
            (unsigned)id, cls, conn, man, model, trk, ct, rm, hw, drv, (unsigned)fw, batPct, provides, charging,
            (unsigned)(btns >> 32), (unsigned)btns, prof);
}

/* ---- 0.43 compositor timing (log only) ------------------------------------------------------------------------ */
static struct Compositor_FrameTiming g_ft[48];

static void fx2(char* out, double v) { /* wsprintfA has no %f: "12.34" */
  if (v < 0) v = 0;
  if (v > 99999.0) v = 99999.0;
  wsprintfA(out, "%d.%02d", (int)v, (int)(v * 100.0) % 100);
}

static int sort_median(double* v, int n) { /* insertion sort, returns 1 if n > 0 */
  for (int i = 1; i < n; ++i) {
    double x = v[i]; int j = i - 1;
    while (j >= 0 && v[j] > x) { v[j + 1] = v[j]; --j; }
    v[j + 1] = x;
  }
  return n > 0;
}

static void set_text(char* out, int size, const char* name, int isBool, int isFloat) {
  /* "steamvr" setting as text, "-" when unavailable */
  static char section[] = "steamvr";
  char key[64];
  EVRSettingsError err = EVRSettingsError_VRSettingsError_None;
  lstrcpynA(key, name, (int)sizeof(key));
  if (!g_set) { lstrcpynA(out, "-", size); return; }
  if (isBool) {
    int b = g_set->GetBool(section, key, &err) ? 1 : 0;
    if (err != EVRSettingsError_VRSettingsError_None) lstrcpynA(out, "-", size); else wsprintfA(out, "%d", b);
  } else if (isFloat) {
    float f = g_set->GetFloat(section, key, &err);
    if (err != EVRSettingsError_VRSettingsError_None) lstrcpynA(out, "-", size); else fx2(out, (double)f);
  } else {
    lstrcpynA(out, "-", size);
  }
}

/* 0.45: counters of the previous report, to turn the compositor's cumulative statistics into rates per second */
static struct { LONGLONG qpc; uint32_t presents, submits, reprojected, dropped; int have; } g_prevStats;

void vr_capi_timing_report(char* buf, int size, int* vsyncHzX10, int* headsetHzX10, int* presentHzX10, int* submitHzX10) {
  if (size > 0) buf[0] = 0;
  if (vsyncHzX10) *vsyncHzX10 = 0;
  if (headsetHzX10) *headsetHzX10 = 0;
  if (presentHzX10) *presentHzX10 = 0;
  if (submitHzX10) *submitHzX10 = 0;
  if (!vr_capi_is_scene() || size < 600) return;
  ETrackedPropertyError pe = 0;
  float hz = g_sys->GetFloatTrackedDeviceProperty(0, ETrackedDeviceProperty_Prop_DisplayFrequency_Float, &pe);
  if (headsetHzX10) *headsetHzX10 = (int)(hz * 10.0f + 0.5f);

  int n = 0;
  ZeroMemory(g_ft, sizeof(g_ft));
  for (int i = 0; i < 48; ++i) g_ft[i].m_nSize = (uint32_t)sizeof(struct Compositor_FrameTiming);
  n = (int)g_comp->GetFrameTimings(g_ft, 48);
  if (n < 0) n = 0;
  if (n > 48) n = 48;

  double iv[48]; int ni = 0;
  double sumPresents = 0, sumClient = 0, sumGpu = 0, sumCompGpu = 0, sumSubmit = 0;
  uint32_t dropped = 0, mis = 0; int reproj = 0;
  for (int i = 0; i < n; ++i) {
    const struct Compositor_FrameTiming* t = &g_ft[i];
    sumPresents += t->m_nNumFramePresents; sumClient += t->m_flClientFrameIntervalMs;
    sumGpu += t->m_flTotalRenderGpuMs; sumCompGpu += t->m_flCompositorRenderGpuMs; sumSubmit += t->m_flSubmitFrameMs;
    dropped += t->m_nNumDroppedFrames; mis += t->m_nNumMisPresented;
    if (gbvr_frame_reused(t->m_nReprojectionFlags, t->m_nNumFramePresents)) ++reproj;
    if (i + 1 < n) {
      /* 0.45: either order (the list is not documented as newest-first) */
      double dt = t->m_flSystemTimeInSeconds - g_ft[i + 1].m_flSystemTimeInSeconds;
      int df = (int)(t->m_nFrameIndex - g_ft[i + 1].m_nFrameIndex);
      if (dt < 0) dt = -dt;
      if (df < 0) df = -df;
      if (dt > 0.0005 && dt < 0.5 && df >= 1 && df < 8) iv[ni++] = dt * 1000.0 / df;
    }
  }
  double vsyncMs = 0;
  if (ni >= 8 && sort_median(iv, ni)) vsyncMs = iv[ni / 2];
  int appHz10 = vsyncMs > 1.0 ? (int)(10000.0 / vsyncMs + 0.5) : 0;
  int vHz10 = gbvr_display_hz10(pe, hz);
  if (vsyncHzX10) *vsyncHzX10 = vHz10;

  struct Compositor_CumulativeStats cs;
  ZeroMemory(&cs, sizeof(cs));
  g_comp->GetCumulativeStats(&cs, (uint32_t)sizeof(cs));

  /* 0.45: rates over the time since the previous report (works even when the per-frame times are not usable) */
  double pRate = 0, sRate = 0, rRate = 0, dRate = 0;
  {
    LARGE_INTEGER q, f;
    QueryPerformanceCounter(&q);
    QueryPerformanceFrequency(&f);
    if (g_prevStats.have && f.QuadPart > 0 && q.QuadPart > g_prevStats.qpc) {
      double sec = (double)(q.QuadPart - g_prevStats.qpc) / (double)f.QuadPart;
      if (sec > 0.5 && cs.m_nNumFramePresents >= g_prevStats.presents) {
        pRate = (double)(cs.m_nNumFramePresents - g_prevStats.presents) / sec;
        sRate = (double)(cs.m_nNumFrameSubmits - g_prevStats.submits) / sec;
        rRate = (double)(cs.m_nNumReprojectedFrames - g_prevStats.reprojected) / sec;
        dRate = (double)(cs.m_nNumDroppedFrames - g_prevStats.dropped) / sec;
        if (presentHzX10) *presentHzX10 = (int)(pRate * 10.0 + 0.5);
        if (submitHzX10) *submitHzX10 = (int)(sRate * 10.0 + 0.5);
      }
    }
    if (!g_prevStats.have || (double)(q.QuadPart - g_prevStats.qpc) / (double)f.QuadPart > 0.5) {
      g_prevStats.qpc = q.QuadPart; g_prevStats.presents = cs.m_nNumFramePresents; g_prevStats.submits = cs.m_nNumFrameSubmits;
      g_prevStats.reprojected = cs.m_nNumReprojectedFrames; g_prevStats.dropped = cs.m_nNumDroppedFrames; g_prevStats.have = 1;
    }
  }
  char sPres[24], sClient[24], sGpu[24], sCGpu[24], sSubmit[24], sVs[24], sSS[24], sPref[24], sPr[24], sSr[24], sRr[24], sDr[24];
  fx2(sPr, pRate); fx2(sSr, sRate); fx2(sRr, rRate); fx2(sDr, dRate);
  char sMS[8], sIl[8], sAs[8], sMan[8];
  double dn = n > 0 ? (double)n : 1.0;
  fx2(sPres, sumPresents / dn); fx2(sClient, sumClient / dn); fx2(sGpu, sumGpu / dn); fx2(sCGpu, sumCompGpu / dn);
  fx2(sSubmit, sumSubmit / dn); fx2(sVs, vsyncMs);
  set_text(sMS, (int)sizeof(sMS), "motionSmoothing", 1, 0);
  set_text(sIl, (int)sizeof(sIl), "allowInterleavedReprojection", 1, 0);
  set_text(sAs, (int)sizeof(sAs), "allowAsyncReprojection", 1, 0);
  set_text(sMan, (int)sizeof(sMan), "supersampleManualOverride", 1, 0);
  set_text(sSS, (int)sizeof(sSS), "supersampleScale", 0, 1);
  set_text(sPref, (int)sizeof(sPref), "preferredRefreshRate", 0, 1);
  wsprintfA(buf, "COMPOSITOR headsetHz=%d.%d measuredAppHz=%d.%d appIntervalMs=%s frames=%d presentsPerAppFrame=%s "
            "clientIntervalMs=%s appGpuMs=%s compositorGpuMs=%s submitMs=%s dropped=%u misPresented=%u reprojected=%d/%d "
            "total(presents=%u dropped=%u reprojected=%u submits=%u) perSecond(presents=%s submits=%s reprojected=%s dropped=%s) steamvr(motionSmoothing=%s interleavedReproj=%s "
            "asyncReproj=%s supersampleManual=%s supersampleScale=%s preferredRefreshRate=%s)",
            (int)hz, (int)(hz * 10.0f) % 10, appHz10 / 10, appHz10 % 10, sVs, n, sPres, sClient, sGpu, sCGpu, sSubmit,
            (unsigned)dropped, (unsigned)mis, reproj, n, (unsigned)cs.m_nNumFramePresents, (unsigned)cs.m_nNumDroppedFrames,
            (unsigned)cs.m_nNumReprojectedFrames, (unsigned)cs.m_nNumFrameSubmits, sPr, sSr, sRr, sDr, sMS, sIl, sAs, sMan, sSS, sPref);
}
