// Head tracking (0.17) and headset session (0.21) interface. C-compatible.
#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ---- Raw OpenVR access (vr_openvr.c) --------------------------------------
// The session is started on a worker thread, either as a *background*
// application (F9: head tracking only, nothing is drawn in the headset) or as
// a *scene* application (F4: this process draws the headset picture).
enum { GBVR_VR_BACKGROUND = 0, GBVR_VR_SCENE = 1 };
void vr_capi_request_start(const wchar_t* dllDir, int scene);
// ---- SteamVR health check (steamvr_diag.cpp, 0.67). Start worker thread only; reads files / processes and writes log lines.
void steamvr_diag_before(const char* mode, int hmdPresent, int runtimeInstalled, const char* runtimePath, const wchar_t* ourDll);
void steamvr_diag_attempt(int attempt, int maxAttempts, int err, const char* symbol, const char* english, int elapsedMs);
void steamvr_diag_failed(int err, const char* symbol, const char* english, const wchar_t* ourDll);
int steamvr_diag_retryable(int err);
int steamvr_diag_max_attempts(int err);
const char* steamvr_diag_hint_short(int err);
const char* steamvr_diag_hint_long(int err);
// Render thread only. Ends the session (releases the headset picture). Does
// nothing while a start is still in progress; returns 1 when no session is left.
int vr_capi_shutdown(void);
int vr_capi_ready(void);           // 1 once IVRSystem is available
int vr_capi_starting(void);
int vr_capi_failed(void);          // 1 if the last start attempt failed
int vr_capi_is_scene(void);        // 1 if the ready session is a scene application
const char* vr_capi_status(void);  // short human-readable status
// Headset rotation in OpenVR standing space (right-handed, +Y up, -Z forward),
// row-major 3x3, plus the full 3x4 device-to-tracking matrix. Returns 1 if the
// pose is valid and tracking is Running_OK. (Background session, no prediction.)
int vr_capi_hmd_pose(float pose34[12], int* trackingResult);

// ---- Scene session only ------------------------------------------------------
struct GbvrEyeParams {
  // IVRSystem::GetProjectionRaw. Tangents of the frustum edges. OpenVR's names
  // are for a y-down image: "top" is negative and its size is the DOWNWARD
  // extent, "bottom" is positive and is the UPWARD extent (checked against the
  // SteamVR Unity plugin's texture-bounds code and OpenComposite's notes).
  float left, right, top, bottom;
  float eyeToHead[12];  // GetEyeToHeadTransform; [3] is the eye's x offset in metres
};
int vr_capi_eye_params(int eye, struct GbvrEyeParams* out);
// Blocks until the compositor wants the next frame; returns the predicted HMD
// pose for it. Return value: -1 no session, otherwise EVRCompositorError
// (0 = OK). *poseValid tells whether pose34 is usable.
int vr_capi_wait_get_poses(float pose34[12], int* poseValid);
// Submit one eye. bounds = uMin, vMin, uMax, vMax (v = 0 at the top row).
// pose34 = HMD pose the picture was rendered for. gammaSpace: 1 for 8-bit
// UNORM back buffers, 0 lets the runtime decide. Returns EVRCompositorError.
int vr_capi_submit(int eye, void* d3d11Texture, const float bounds[4], const float pose34[12], int gammaSpace);
void vr_capi_clear_last_frame(void);
// Flat "cinema screen" overlay for frames that are not 3D (menus, videos).
// xform34 = screen placement in standing space, or NULL to keep the last one.
// Returns EVROverlayError (0 = OK), -1 without a session.
int vr_capi_overlay_update(void* d3d11Texture, const float* xform34, float widthMeters, int gammaSpace);
void vr_capi_overlay_hide(void);
void vr_capi_overlay_move(const float* xform34, float widthMeters);   /* 1.7.31: placement only (the hand-held menu's own thread) */
void vr_capi_menu_move(const float* xform34, float widthMeters);      /* 1.7.31: placement of the settings pages only */
void vr_capi_fade_grid(float secs, int in);   /* 0.95: 0 = SteamVR's grid room fades out (a black void behind the flat screen), 1 = it comes back */
void vr_capi_fade_color(float secs, float r, float g, float b, float a);   /* 1.3: the scene fades to this colour (a = 0 = nothing, 1 = fully this colour) over secs; used to fade the 3D picture up from black */
void vr_capi_start_black(int on);               /* 1.3: 1 = SteamVR's grid room is faded out the moment the session is ready (set before the start) */
float vr_capi_start_black_alpha(void);          /* 1.3: the grid alpha right after that fade was asked for (-2 = not asked) */
void vr_capi_menu_alpha(float a);   /* 1.3: 0..1, the VR menu fades in with it */
int vr_capi_hmd_present(const wchar_t* dllDir); /* 1.3: 1 = SteamVR sees a headset, 0 = no, -1 = unknown (does not start SteamVR) */
float vr_capi_grid_alpha(void);               /* 0.95: what the compositor says: 1 = grid fully visible, 0 = gone, -1 no session */
int vr_capi_glow_overlay(const void* rgba, int w, int h, const float* xform34, float widthMeters, int show);   /* 0.95: the TV glow behind the flat screen (straight alpha picture); show 0 hides it */
int vr_capi_glow_tint(float r, float g, float b, float a);
int vr_capi_glow_overlay_n(int idx, const void* rgba, int w, int h, const float* xform34, float widthMeters, int show);   /* 1.7.151: idx 0 = the whole glow, 1..4 = the corner layers */
int vr_capi_glow_tint_n(int idx, float r, float g, float b, float a);   /* 1.1: the glow's colour and fade without a new picture */
int vr_capi_overlay_style(float curvature, float alpha);   /* 1.1: the flat screen's curve and fade */
// 0.42: pointer events from the flat screen (SteamVR draws a laser from each controller; the trigger is the left button).
// type 1 move, 2 button down, 3 button up, 4 scroll. x, y: 0..1 across the screen, y measured from the BOTTOM.
// button: 1 left, 2 right, 4 middle. scrollY: notches (+ up). Returns the number of events stored (at most max).
struct GbvrOverlayEvt { int type; float x, y; int button; float scrollY; };
int vr_capi_overlay_events(struct GbvrOverlayEvt* out, int max);
// 0.53 the in-VR menu: its own overlay with a plain RGBA picture (w x h, 4 bytes per pixel) and the laser-pointer mouse input.
// xform34 = placement in standing space (NULL keeps it), widthMeters its width. rgba NULL = no new picture. 0 = OK.
void vr_capi_menu_laser(int on);   /* 0.65: 1 = SteamVR laser mode for the menu overlay, 0 = plain overlay (own pointer) */
void vr_capi_flat_laser(int on);   /* 1.7.29: 1 = SteamVR's laser on the flat game screen (default), 0 = none (the hand-held menu has its own pointer) */
int vr_capi_menu_overlay(const void* rgba, int w, int h, const float* xform34, float widthMeters);
void vr_capi_menu_settle(void);   /* 0.70: hides the older of the two menu pictures once the new one has been up a moment */
int vr_capi_cursor(const void* rgba, int w, int h, const float* xform34, float widthMeters, int show);   /* 0.66: the menu pointer ring as its own small overlay (show 0 = hide) */
void vr_capi_menu_hide(void);
int vr_capi_menu_events(struct GbvrOverlayEvt* out, int max);   // same event types as vr_capi_overlay_events
// 1 if SteamVR asked this application to quit (the caller must end the session).
int vr_capi_poll_quit(void);
// One-line description of the headset for the log.
void vr_capi_describe(char* buf, int size);
void vr_capi_recommended_size(unsigned* w, unsigned* h);   // 0.98: SteamVR's recommended picture size per eye (0,0 = unknown)
float vr_capi_display_hz(void);                             // 0.98: the headset's display rate as SteamVR reports it (0 = unknown)
// 0.43: what the SteamVR compositor really does, for the log (render thread). Fills buf with a one-line
// summary (compositor frame rate measured from its own frame timings, the headset's reported rate, frames per
// application frame, dropped / reprojected frames, GPU times, cumulative statistics, relevant SteamVR settings).
// *vsyncHzX10 = measured compositor rate x 10 (0 = unknown), *headsetHzX10 = the headset's reported rate x 10.
// 0.45: *presentHzX10 / *submitHzX10 = the compositor's presents / app frame submits per second x 10 since the previous
// report (0 = unknown); they are valid even when the per-frame timings are not.
void vr_capi_timing_report(char* buf, int size, int* vsyncHzX10, int* headsetHzX10, int* presentHzX10, int* submitHzX10);

// Controller / any tracked pose -> engine-local rotation (9) and position (3), relative to the recenter point.
int vr_pose_to_engine_local(const float* pose34, float* L9, float* pos3);

// ---- Controllers (0.33) -------------------------------------------------------
struct GbvrHandRaw {
  int valid;           // 1 if the controller is connected and tracked this frame
  float pose34[12];    // device-to-tracking pose (standing space)
  float stickX, stickY, trigger;
  uint64_t pressed;    // ulButtonPressed
  uint64_t touched;    // ulButtonTouched
  float grip;          // 1.7.111: the analog grip squeeze 0..1 (legacy axis 2), 0 if the controller has none
  int thumbTouch, trigTouch;   // 1.7.111: thumb resting on a button / the stick / the thumb rest, finger resting on the trigger (touch sensors)
};
// hand: 0 = left, 1 = right. Render thread only. Returns out->valid.
int vr_capi_hand(int hand, struct GbvrHandRaw* out);
void vr_capi_set_handed(int left);   /* 1.7.19: 1 = left-handed play: the controllers swap roles for the whole mod (poses, buttons, sticks, buzz) */
/* 1.7.19: the controller family of a (logical) hand: 0 unknown, 1 Touch-style (Quest, Rift, Pico, Frame: the default layout), 2 Index, 3 Vive wand, 4 Windows Mixed Reality, 5 other; name = the game runtime's controller type string */
int vr_capi_family(int hand, char* name, int nameSize);
void vr_capi_set_compat(int layout, int stickAxis);   /* 1.7.117: settings-file overrides: controller_layout (0 auto, 1 Touch, 2 Index, 3 Vive, 4 Windows MR, 5 other), stick_axis (-1 auto, 0..4) */
void vr_capi_layout_report(int hand, char* buf, int size);   /* 1.7.117: one log line of facts about a hand's controller decoding */
int vr_capi_stick_axis(int hand);   /* 1.7.96: the analog axis the stick is read from (0, 2 or 3) */
int vr_capi_axis_peaks(int hand, int* peaksX1000, int* lookalike);   /* 1.7.87: largest push per analog axis (x1000, axes 0..4) since the controller was detected; returns the family */
unsigned long long vr_capi_output_luid(void);                      /* 1.7.87: the adapter LUID SteamVR attaches the headset to (0 = unknown) */
int vr_capi_hand_measured(int hand, struct GbvrHandRaw* out);   /* 1.7.31: the measured pose, no prediction, safe from any thread */
void vr_capi_hand_predict_off(int off);   /* 0.68: 1 = vr_capi_hand returns the measured pose without prediction (menu pointer) */
// Haptic pulse, microseconds (clamped to 3999). hand: 0 left, 1 right.
void vr_capi_haptic(int hand, unsigned us);
int vr_capi_haptic_dev(int hand, unsigned us);   /* 0.51: any thread. 1 sent, 0 session not ready, -1 no controller in that role */
int vr_capi_input_available(void);               /* 0.51: 1 SteamVR gives this application the controller input, 0 it does not, -1 unknown */
void vr_capi_device_report(char* buf, int size, int which);   /* 0.51: log text; which 0 headset, 1 left hand, 2 right hand (size >= 600) */
int vr_capi_leave_count(void);   /* 0.52: how many times the player left the game in VR (SteamVR menu, headset off, SteamVR quit) */
int vr_capi_leave_why(void);     /* 0.52: event type of the last one (502 menu, 400 input taken, 106 standby, 104 headset idle, 9003-9005 headset activity, 700 quit) */
int vr_capi_event_pop(unsigned* type, unsigned* dev, unsigned* ageMs);   /* 0.51: device / focus events seen by the quit poll */
void vr_capi_set_hand_predict_ms(int ms);   /* 0.50: controller poses are predicted this far ahead (0 = as measured now) */

// ---- Pose snapshot shared with the camera thread (headtrack.cpp) ----------
struct GbvrPose {
  float m[9];        // engine-local rotation to apply (row-major, M' = M * m)
  float pos[3];      // head position relative to recenter, engine-local metres (x right, y up, z forward)
  float raw34[12];   // OpenVR device-to-tracking pose this snapshot came from
  int64_t qpc;       // QueryPerformanceCounter when sampled
  int valid;
  uint32_t seq;
  float yawDeg, pitchDeg, rollDeg;  // relative to recenter, for logging only
};
// Render thread: publish a pose. pose34 = NULL publishes "no valid pose".
// recenter=1 re-zeroes yaw and position. Returns 1 if a valid pose was published.
int vr_publish_pose(const float* pose34, int recenter);
// Render thread: sample the headset (background session) and publish.
int vr_sample_on_render_thread(int recenter);
// Camera thread: copy the newest snapshot. Returns 0 if none was ever published.
int vr_read_snapshot(struct GbvrPose* out);
void vr_invalidate_snapshot(void);
/* 1.5 head-follow turning: A = yaw the game was turned for the player; the headset rotation (and hands) are turned back by it */
void vr_follow_add(double radians);   /* adds to A and rebuilds the newest snapshot */
double vr_follow_total(void);          /* A, radians (+ = right) */

#ifdef __cplusplus
}
#endif
