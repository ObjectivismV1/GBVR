// 0.53 the in-VR menu.
//
// A panel in front of the player (a SteamVR overlay with the laser-pointer mouse input, the same mechanism as the flat
// game screen) holds every setting and test of the probe in plain words, sorted on tabs: Start, Gun, Body, View,
// Controls, Help. Point the laser at a button and pull the trigger; "-" and "+" repeat when held. Everything is saved
// at once (settings.cpp). While the menu is open the game gets no controller input (a trigger click must not fire).
//
// The picture is drawn here (0.69: the panels are blended by hand over the blurred cover picture so they are see-through;
// the text is drawn with GDI - gdi32 is loaded by name, so the DLL's static imports stay KERNEL32 / USER32 / msvcrt),
// converted to RGBA and handed to SteamVR with SetOverlayRaw whenever something changed.
// 0.69: while the menu is open the song plays and the game's own sound is muted (audio.cpp).
//
// Opens: automatically when the headset view starts (setting menu_on_start), with F12, or with the left hand next to
// the head + left grip held for half a second (controllers.cpp). Closes with the Close button or the same.
// 1.7.28: with the hand-held game menu (held_menu, default on) those openers open the GAME's pause menu instead (heldmenu.cpp). These pages are then the
// "VR SETTINGS" inside it: they open in the same hand when the button at the bottom of the game's menu is pressed, and "< Game menu" goes back.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include "vr_pose.h"
#include "vmenumath.h"
#include "bodymath.h"
#include "hapticmath.h"
#include "version.h"
#include "ratecap.h"
#include "picturemath.h"
#include "vmath.h"
#include "menu_bg.h"   // 0.69: the blurred cover picture behind the menu (tools/make_menu_bg.py)

namespace {

const int W = 1280, H = 800;
volatile LONG g_picSerial;   // 1.7.90: counts the finished menu pictures
const float kMenuWidthM = 1.70f, kMenuDistM = 1.25f, kMenuDropM = 0.10f;
float g_menuWidthM = 1.70f;   // 1.7.28: the pages' width now (1.7 m in front of you, or 0.64 m in the hand)
int g_live;                   // 1.7.84: the pages in the hand over the LIVE world (the game is frozen, not paused: the 3D world keeps being drawn, you can look all around, both eyes as always)
int g_viaHeld;                // 1.7.28: the pages were opened from the hand-held game menu (the song and the pause belong to that, not to these pages)

// ---- GDI by name ------------------------------------------------------------------------------------------------
typedef HDC(WINAPI* PFN_CreateCompatibleDC)(HDC);
typedef HBITMAP(WINAPI* PFN_CreateDIBSection)(HDC, const BITMAPINFO*, UINT, void**, HANDLE, DWORD);
typedef HGDIOBJ(WINAPI* PFN_SelectObject)(HDC, HGDIOBJ);
typedef BOOL(WINAPI* PFN_DeleteObject)(HGDIOBJ);
typedef BOOL(WINAPI* PFN_DeleteDC)(HDC);
typedef HFONT(WINAPI* PFN_CreateFontW)(int, int, int, int, int, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, LPCWSTR);
typedef int(WINAPI* PFN_SetBkMode)(HDC, int);
typedef COLORREF(WINAPI* PFN_SetTextColor)(HDC, COLORREF);
typedef HBRUSH(WINAPI* PFN_CreateSolidBrush)(COLORREF);
typedef HPEN(WINAPI* PFN_CreatePen)(int, int, COLORREF);
typedef BOOL(WINAPI* PFN_RoundRect)(HDC, int, int, int, int, int, int);
typedef BOOL(WINAPI* PFN_GdiFlush)();
struct Gdi {
  PFN_CreateCompatibleDC CreateCompatibleDC; PFN_CreateDIBSection CreateDIBSection; PFN_SelectObject SelectObject; PFN_DeleteObject DeleteObject;
  PFN_DeleteDC DeleteDC; PFN_CreateFontW CreateFontW; PFN_SetBkMode SetBkMode; PFN_SetTextColor SetTextColor; PFN_CreateSolidBrush CreateSolidBrush;
  PFN_CreatePen CreatePen; PFN_RoundRect RoundRect; PFN_GdiFlush GdiFlush;
} g_g;
int g_gdiState;   // 0 not tried, 1 ready, -1 failed
HDC g_dc;
HBITMAP g_bmp;
uint8_t* g_bits;  // BGRA, top-down, W*H*4 (owned by the DIB)
HFONT g_fTitle, g_fTab, g_fLabel, g_fDesc, g_fValue, g_fBtn, g_fSmall, g_fHelp;
HPEN g_nullPen;
uint8_t g_rgba[W * H * 4];
uint8_t g_bgFull[W * H * 3];   // 0.69: the cover picture stretched to the menu size (RGB), built once
uint8_t g_base[W * H * 4];     // 0.69: the menu's backdrop (BGRA): the picture mixed over the dark colour by menu_bg_pct
int g_bgBuilt, g_baseFor = -1;

#define LOADG(name) (g_g.name = (PFN_##name)GetProcAddress(gd, #name))
int gdi_init() {
  if (g_gdiState) return g_gdiState > 0;
  g_gdiState = -1;
  HMODULE gd = LoadLibraryW(L"gdi32.dll");
  if (!gd) { log_line("MENU could not load gdi32.dll (error %u): the in-VR menu is off", GetLastError()); return 0; }
  LOADG(CreateCompatibleDC); LOADG(CreateDIBSection); LOADG(SelectObject); LOADG(DeleteObject); LOADG(DeleteDC); LOADG(CreateFontW);
  LOADG(SetBkMode); LOADG(SetTextColor); LOADG(CreateSolidBrush); LOADG(CreatePen); LOADG(RoundRect); LOADG(GdiFlush);
  if (!g_g.CreateCompatibleDC || !g_g.CreateDIBSection || !g_g.SelectObject || !g_g.DeleteObject || !g_g.CreateFontW || !g_g.SetBkMode ||
      !g_g.SetTextColor || !g_g.CreateSolidBrush || !g_g.CreatePen || !g_g.RoundRect || !g_g.GdiFlush || !g_g.DeleteDC) {
    log_line("MENU gdi32.dll lacks a function the menu needs: the in-VR menu is off");
    return 0;
  }
  g_dc = g_g.CreateCompatibleDC(nullptr);
  BITMAPINFO bi;
  ZeroMemory(&bi, sizeof(bi));
  bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bi.bmiHeader.biWidth = W; bi.bmiHeader.biHeight = -H; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
  void* bits = nullptr;
  g_bmp = g_dc ? g_g.CreateDIBSection(g_dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0) : nullptr;
  if (!g_dc || !g_bmp || !bits) { log_line("MENU could not create the menu picture (dc=%p bitmap=%p): the in-VR menu is off", g_dc, g_bmp); return 0; }
  g_bits = (uint8_t*)bits;
  g_g.SelectObject(g_dc, g_bmp);
  g_g.SetBkMode(g_dc, TRANSPARENT);
  const wchar_t* face = L"Segoe UI";
  g_fTitle = g_g.CreateFontW(-46, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);
  g_fTab = g_g.CreateFontW(-23, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);
  g_fLabel = g_g.CreateFontW(-30, 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);
  g_fDesc = g_g.CreateFontW(-20, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);
  g_fValue = g_g.CreateFontW(-36, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);
  g_fBtn = g_g.CreateFontW(-30, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);
  g_fSmall = g_g.CreateFontW(-24, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);
  g_fHelp = g_g.CreateFontW(-19, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);   // 1.3: the full explanation of the row you point at
  g_nullPen = g_g.CreatePen(PS_NULL, 0, 0);
  g_gdiState = 1;
  log_line("MENU picture ready (%dx%d, GDI loaded by name)", W, H);
  return 1;
}

// ---- content -----------------------------------------------------------------------------------------------------
enum Kind { K_NOTE, K_TOGGLE, K_STEP, K_ACTION };
enum Act { A_NONE, A_PAUSE, A_RESUME, A_CALIB, A_BUZZ, A_MARK, A_RECENTER, A_CLOSE, A_RESETH, A_OBJECTIVES, A_GAMEMENU };
struct Item {
  Kind kind;
  const wchar_t* label;
  const wchar_t* desc;
  const char* key;        // settings name (toggle / stepper)
  int step, div;          // stepper: size of one click; value is shown divided by div
  const wchar_t* unit;
  Act act;
  const wchar_t* btn;     // action button text
  volatile LONG* v;       // resolved from key at start
  LONG lo, hi;
};
struct Page { const wchar_t* tab; const wchar_t* title; int n; Item it[8]; };

Page g_pages[] = {
  {L"Start", L"The basics", 4, {
    {K_ACTION, L"Measure my height", L"Stand straight, look ahead, hold still. 3-second countdown, then 1.5 seconds. Your world size is matched to your real height (the normal size is a little larger, so it can look smaller). Your view is never lowered and the character is never shrunk.", nullptr, 0, 0, nullptr, A_CALIB, L"Measure"},
    {K_ACTION, L"Reset my height", L"Back to the normal world size (115 %) and height.", nullptr, 0, 0, nullptr, A_RESETH, L"Reset"},
    {K_ACTION, L"Recenter my view", L"Stand or sit the way you will play and look straight ahead. After 3 seconds this becomes straight ahead and your normal height.", nullptr, 0, 0, nullptr, A_RECENTER, L"Recenter"},
    {K_ACTION, L"Show my objectives", L"Opens the game's pause menu in your hand (Objectives, Training, Controls). Point with your gun hand, trigger = select, stick = scroll, A = close.", nullptr, 0, 0, nullptr, A_OBJECTIVES, L"Open"}}},
  {L"Play", L"Moving and fighting", 6, {
    {K_TOGGLE, L"Snap turn (off = smooth turn)", L"On (default): flick the turn stick (the right stick, or the left one when left-handed) left or right to turn in steps. Off: SMOOTH turn - hold it sideways and you turn steadily; let go to stop.", "turn_snap", 0, 0, nullptr, A_NONE, nullptr},
    {K_TOGGLE, L"Sprint: click on, click off", L"Click the move stick once to start sprinting, click again to stop.", "sprint_toggle", 0, 0, nullptr, A_NONE, nullptr},
    {K_TOGGLE, L"Left-handed", L"Swaps the hands: the gun goes in your LEFT hand and the other hand helps. Every button, stick and buzz swaps with it: the right controller then moves you, the left one turns you.", "left_handed", 0, 0, nullptr, A_NONE, nullptr},
    {K_TOGGLE, L"Seated play", L"For sitting down: your view is re-centred a few seconds after you switch it on, crouching by ducking is turned off.", "seated", 0, 0, nullptr, A_NONE, nullptr},
    {K_TOGGLE, L"Grab beam: click on, click off", L"On: click your gun-hand stick once to grab or wrangle a ghost, click again to let go. Off (default): hold the click while you grab.", "capture_tap", 0, 0, nullptr, A_NONE, nullptr},
    {K_STEP, L"Comfort vignette", L"A soft dark edge that fades in while you walk, sprint or turn and fades out when you stand still. 0 = off (default). Try 40 to 70. The preview shows when the menu is opened in the game world (not from the pause menu). Being knocked down still dims the edges.", "vignette_pct", 10, 1, L" %", A_NONE, nullptr}}},
  {L"View", L"What you see", 7, {
    {K_TOGGLE, L"Ghost health", L"On (default): a round health ring shows on the ghost or boss you look at or hold. Off: the mod adds no ghost health (the game's own lock ring still shows).", "ring_assist", 0, 0, nullptr, A_NONE, nullptr},
    {K_TOGGLE, L"Ghost health as bars (off = round ring)", L"Off (default): a round health ring on the ghost you look at, hold or shoot. On: a small glowing health vial over each ghost instead. Needs 'Ghost health' on.", "health_style", 0, 0, nullptr, A_NONE, nullptr},
    {K_TOGGLE, L"Game HUD in front of you", L"On (default): the game's on-screen info (subtitles, prompts, aiming circle, money) floats in front of you in both eyes. Off: the game draws it flat on each eye, which looks wrong in VR.", "hud_mode", 0, 0, nullptr, A_NONE, nullptr},
    {K_STEP, L"Resolution (restart the game)", L"Too slow or choppy? Press - for a smaller picture (faster). Sizes: 1080 / 1440 (default for a new install) / 1800 / 2160 / 2880 lines, at your screen's shape. It is saved and used the next time you start the game; this run keeps its picture. More lines = sharper but slower. A laptop usually wants 1080 or 1440.", "picture_level", 1, 1, nullptr, A_NONE, nullptr},
    {K_STEP, L"FPS limit", L"Off (default): as fast as your PC manages. Choppy? Pick a number from 45: the game then shows a new picture at that rate and SteamVR / Virtual Desktop fill in the rest. Numbers that divide your headset rate evenly (45 on 90 Hz, 60 on 120 Hz) are smoothest. Works at once.", "vr_fps_cap", 1, 1, L" FPS", A_NONE, nullptr},
    {K_TOGGLE, L"Smooth edges (anti-aliasing)", L"Off (default). On: jagged, shimmering edges in the headset are smoothed and lightly re-sharpened on the graphics card. Costs a little speed. Works at once; if your graphics card cannot do it, it switches itself off.", "eye_aa", 0, 0, nullptr, A_NONE, nullptr},
    {K_STEP, L"Buzz strength", L"How strong the controllers vibrate. 0 = off.", "haptic_pct", 10, 1, L" %", A_NONE, nullptr}}},
  {L"Help", L"Help", 4, {
    {K_NOTE, L"Open the menu any time: left hand next to your head + squeeze the left grip, or F12. Press VR SETTINGS at the bottom of the game menu to get these pages. The same gesture closes it.", nullptr, nullptr, 0, 0, nullptr, A_NONE, nullptr},
    {K_NOTE, L"Point at a button and pull the trigger. Hold - or + to change fast. Everything is saved at once.", nullptr, nullptr, 0, 0, nullptr, A_NONE, nullptr},
    {K_NOTE, L"Buttons: left stick down = Sprint. LEFT TRIGGER = alternate fire (hold Capture with the right stick click + full left trigger = slam). Tap Y = PKE. HOLD Y: right stick = D-pad, stick down = Vent, B = HUD, A = Select. HOLD right A = weapon wheel.", nullptr, nullptr, 0, 0, nullptr, A_NONE, nullptr},
    {K_NOTE, L"Something not working? Close the game, run COLLECT_LOGS and attach the zip when you report it.", nullptr, nullptr, 0, 0, nullptr, A_NONE, nullptr}}},
};
const int kPages = (int)(sizeof(g_pages) / sizeof(g_pages[0]));

// ---- layout / hit rectangles -------------------------------------------------------------------------------------
enum HitKind { HK_NONE, HK_TAB, HK_TOGGLE, HK_MINUS, HK_PLUS, HK_ACTION, HK_CLOSE, HK_ROW };   // 1.3: HK_ROW = the whole row (hover only: shows the full explanation)
struct Hit { vmenu::Rect r; HitKind kind; int idx; };
Hit g_hit[48];
int g_hitN;
const int kTabX = 24, kTabW = 240, kTabY = 104, kTabH = 54, kTabGap = 6;   // 1.7.48: ten tabs, last ends at 698; footer begins at 730
const int kRowX = 288, kRowW = 968, kRowY = 104, kRowH = 72, kRowGap = 5;     // 0.69: 8 rows

// ---- state -------------------------------------------------------------------------------------------------------
int g_open;
float g_menuA = 1.0f;       // 1.3: how solid the menu is (it fades in when it opens)
uint32_t g_menuAMs;
int g_page;
int g_hover = -1, g_down = -1;
int g_dirty = 1;
int g_cheap;              // 0.58 speed guard: 1 = redraw at most every 300 ms
uint32_t g_lastDraw, g_lastStatus;
vmenu::Repeater g_rep;
int g_autoOpened;
int g_resolved;
uint32_t g_calibAt;       // GetTickCount when the countdown ends (0 = none)
int g_measuring, g_calibCountBefore, g_calibCmBefore, g_calibPctBefore;
// 1.7.13: the menu measures the height itself (it used to ask the controller code, which has to be polled by the game)
body::HeightMeter g_hm; int g_mN;   // 1.7.110
DWORD g_mStartMs, g_mLastSampleMs; int g_mFail; double g_mLastM;   // g_mFail: 0 none, 1 headset not tracked, 2 head too low / too high, 3 moved, 4 too few samples

uint32_t g_resultUntil;
wchar_t g_status[160];
wchar_t g_note[160];      // 0.66: a one-line answer to a button (shown in the footer for a few seconds)
uint32_t g_noteUntil;
struct Stats { LONG heldTicks; LONG ovEvents, ownMoves, ownClicks, ownHits; LONG opens, closes, clicks, moves, redraws, uploads, uploadFail, setChanges, actions; DWORD lastDrawMs, maxDrawMs; int lastErr; } g_s;
int g_activeFrames;        // headset frames since the headset view started
uint32_t g_closedMs;
int g_closeAfter;         // a Pause / Resume closes the menu so the game's own pause menu can be seen
float g_xf[12];           // where the menu hangs (standing space)
uint32_t g_lastOvEvtMs;   // last pointer event SteamVR's laser gave us
int g_ownHover = -1, g_ownHand = -1, g_ownTrig;
int g_trigArmed;                // 0.68: a trigger already held when the menu opens must be let go once before it can click
vmenu::Pointer g_ptr;          // 0.68 smoothed / held pointer (pixels)
uint32_t g_ptrMs;               // last pointer update
int g_ptrOn;                    // the ray hit the menu on the last update
double g_ptrClickX = -1, g_ptrClickY = -1;
LONG g_clickLogged;
int g_curX = -1, g_curY = -1, g_curShown;
int g_ready;              // placement + picture delivered once
// 0.66 the pointer ring is an overlay of its own (cheap to move); the old way (ring painted into the menu picture, 4 MB re-sent per move) is the fallback
const int kCurPx = 64;
const float kCurWidthM = 0.05f;
uint8_t g_curRgba[kCurPx * kCurPx * 4];
int g_curBuilt, g_curOvState, g_curOvFails, g_curOvOn;   // g_curOvState: 0 working or untried, -1 failed (fallback)
double g_curLast[3];
struct { LONG moves, fails; } g_curSt;

void resolve() {
  if (g_resolved) return;
  g_resolved = 1;
  for (Page& p : g_pages)
    for (int i = 0; i < p.n; ++i) {
      Item& it = p.it[i];
      it.v = nullptr; it.lo = 0; it.hi = 0;
      if (it.key && !settings_lookup(it.key, &it.v, &it.lo, &it.hi)) log_line("MENU setting \"%s\" not found (row \"%ls\" will be inert)", it.key, it.label);
      if (it.key && it.v && lstrcmpA(it.key, "picture_level") == 0 && it.hi > 3) it.hi = 3;   // 1.7.117: level 4 is a test level (Insert key only), not a menu choice
    }
}

void fill(const vmenu::Rect& r, COLORREF c, int radius) {
  HBRUSH b = g_g.CreateSolidBrush(c);
  HGDIOBJ ob = g_g.SelectObject(g_dc, b);
  HGDIOBJ op = g_g.SelectObject(g_dc, g_nullPen);
  g_g.RoundRect(g_dc, r.x, r.y, r.x + r.w + 1, r.y + r.h + 1, radius, radius);
  g_g.SelectObject(g_dc, ob);
  g_g.SelectObject(g_dc, op);
  g_g.DeleteObject(b);
}
void text(const wchar_t* s, const vmenu::Rect& r, HFONT f, COLORREF c, UINT fmt) {
  if (!s) return;
  g_g.SelectObject(g_dc, f);
  g_g.SetTextColor(g_dc, c);
  RECT rc = {r.x, r.y, r.x + r.w, r.y + r.h};
  DrawTextW(g_dc, s, -1, &rc, fmt | DT_NOPREFIX);
}

const COLORREF cBg = RGB(14, 16, 22), cRow = RGB(20, 24, 34), cRowHot = RGB(34, 42, 62), cTab = RGB(30, 35, 48), cTabHover = RGB(60, 68, 90), cAccent = RGB(222, 62, 38),
               cText = RGB(246, 247, 250), cSub = RGB(190, 198, 214), cBtn = RGB(52, 60, 84), cBtnHover = RGB(86, 98, 136), cOn = RGB(46, 168, 94),
               cOff = RGB(92, 96, 110), cValue = RGB(12, 14, 20), cBand = RGB(4, 6, 10);
// 0.69 how see-through each part is (0 = invisible .. 255 = solid). The picture behind shows most through the rows.
const int kAlRow = 206, kAlTab = 205, kAlTabOn = 240, kAlBtn = 232, kAlVal = 218, kAlBand = 150, kAlPill = 238;

// the cover picture, stretched (bilinear) to the menu size
void build_bg_full() {
  if (g_bgBuilt) return;
  g_bgBuilt = 1;
  static int xi0[W], xi1[W], xw[W];
  for (int x = 0; x < W; ++x) {
    long long n = ((long long)(2 * x + 1) * GBVR_MENU_BG_W * 65536) / (2 * W) - 32768;
    if (n < 0) n = 0;
    int i0 = (int)(n >> 16), w = (int)((n & 0xFFFF) >> 8);
    if (i0 >= GBVR_MENU_BG_W - 1) { i0 = GBVR_MENU_BG_W - 1; w = 0; }
    xi0[x] = i0; xi1[x] = i0 + (i0 < GBVR_MENU_BG_W - 1 ? 1 : 0); xw[x] = w;
  }
  for (int y = 0; y < H; ++y) {
    long long n = ((long long)(2 * y + 1) * GBVR_MENU_BG_H * 65536) / (2 * H) - 32768;
    if (n < 0) n = 0;
    int j0 = (int)(n >> 16), hw = (int)((n & 0xFFFF) >> 8);
    if (j0 >= GBVR_MENU_BG_H - 1) { j0 = GBVR_MENU_BG_H - 1; hw = 0; }
    const int j1 = j0 + (j0 < GBVR_MENU_BG_H - 1 ? 1 : 0);
    const unsigned char* r0 = kMenuBg + (size_t)j0 * GBVR_MENU_BG_W * 3;
    const unsigned char* r1 = kMenuBg + (size_t)j1 * GBVR_MENU_BG_W * 3;
    uint8_t* o = g_bgFull + (size_t)y * W * 3;
    for (int x = 0; x < W; ++x, o += 3) {
      const int a = xi0[x] * 3, b = xi1[x] * 3, w = xw[x];
      for (int c = 0; c < 3; ++c) {
        const int top = r0[a + c] * (256 - w) + r0[b + c] * w;
        const int bot = r1[a + c] * (256 - w) + r1[b + c] * w;
        o[c] = (uint8_t)((top * (256 - hw) + bot * hw) >> 16);
      }
    }
  }
}

// the backdrop: picture mixed over the dark colour. Rebuilt only when the setting changes.
void ensure_base() {
  const int pct = g_ctl.menuBg ? vmenu::clamp_i((int)g_ctl.menuBgPct, 0, 100) : 0;
  if (g_baseFor == pct) return;
  g_baseFor = pct;
  const int k = pct * 256 / 100;
  const int br = GetRValue(cBg), bg = GetGValue(cBg), bb = GetBValue(cBg);
  if (k > 0) build_bg_full();
  uint8_t* o = g_base;
  const uint8_t* p = g_bgFull;
  if (k == 0) { for (int i = 0; i < W * H; ++i, o += 4) { o[0] = (uint8_t)bb; o[1] = (uint8_t)bg; o[2] = (uint8_t)br; o[3] = 255; } return; }
  const int ik = 256 - k;
  const int mr = br * ik, mg = bg * ik, mb = bb * ik;
  for (int i = 0; i < W * H; ++i, o += 4, p += 3) {
    o[0] = (uint8_t)((mb + p[2] * k) >> 8); o[1] = (uint8_t)((mg + p[1] * k) >> 8); o[2] = (uint8_t)((mr + p[0] * k) >> 8); o[3] = 255;
  }
}

// rounded-corner coverage (0..255), per radius, made on first use
uint8_t g_cov[41][40 * 40];
uint8_t g_covOk[41];
const uint8_t* cov_for(int r) {
  if (!g_covOk[r]) {
    g_covOk[r] = 1;
    for (int y = 0; y < r; ++y) for (int x = 0; x < r; ++x) {
      const double dx = (double)r - x - 0.5, dy = (double)r - y - 0.5;
      double c = (double)r - vm::dsqrt(dx * dx + dy * dy) + 0.5;
      c = c < 0 ? 0 : c > 1 ? 1 : c;
      g_cov[r][y * r + x] = (uint8_t)(c * 255.0 + 0.5);
    }
  }
  return g_cov[r];
}
inline void blend_px(uint8_t* d, int cr, int cg, int cb, int a256) {   // BGRA pixel, colour over it with a256 = 0..256
  d[0] = (uint8_t)((d[0] * (256 - a256) + cb * a256) >> 8);
  d[1] = (uint8_t)((d[1] * (256 - a256) + cg * a256) >> 8);
  d[2] = (uint8_t)((d[2] * (256 - a256) + cr * a256) >> 8);
}
// a see-through rounded panel written straight into the picture
void panel(const vmenu::Rect& rc, COLORREF col, int rad, int alpha) {
  if (rc.w <= 0 || rc.h <= 0 || rc.x < 0 || rc.y < 0 || rc.x + rc.w > W || rc.y + rc.h > H) return;
  int r = rad;
  if (r > rc.w / 2) r = rc.w / 2;
  if (r > rc.h / 2) r = rc.h / 2;
  if (r > 40) r = 40;
  if (r < 0) r = 0;
  const int cr = GetRValue(col), cg = GetGValue(col), cb = GetBValue(col);
  const int a256 = alpha + (alpha >> 7);
  const uint8_t* cov = r > 0 ? cov_for(r) : nullptr;
  for (int ry = 0; ry < rc.h; ++ry) {
    uint8_t* row = g_bits + ((size_t)(rc.y + ry) * W + rc.x) * 4;
    int edge = 0;                           // pixels at each end that are in a rounded corner
    const uint8_t* crow = nullptr;
    if (r > 0 && (ry < r || ry >= rc.h - r)) { edge = r; crow = cov + (size_t)(ry < r ? ry : rc.h - 1 - ry) * r; }
    for (int x = edge; x < rc.w - edge; ++x) blend_px(row + (size_t)x * 4, cr, cg, cb, a256);
    for (int i = 0; i < edge; ++i) {
      const int a = (a256 * crow[i] + 127) / 255;
      if (a <= 0) continue;
      blend_px(row + (size_t)i * 4, cr, cg, cb, a);
      blend_px(row + (size_t)(rc.w - 1 - i) * 4, cr, cg, cb, a);
    }
  }
}

// text is queued while the panels are laid down, then drawn on top (GDI) with a dark shadow so it stays readable over the picture
struct TextJob { wchar_t s[256]; vmenu::Rect r; HFONT f; COLORREF c; UINT fmt; };
TextJob g_tj[96];
int g_tjN;
void qtext(const wchar_t* s, const vmenu::Rect& r, HFONT f, COLORREF c, UINT fmt) {
  if (!s || !s[0] || g_tjN >= 96) return;
  TextJob& j = g_tj[g_tjN++];
  lstrcpynW(j.s, s, 256);
  j.r = r; j.f = f; j.c = c; j.fmt = fmt;
}
void flush_text() {
  for (int i = 0; i < g_tjN; ++i) {
    const TextJob& j = g_tj[i];
    vmenu::Rect sh = j.r; sh.x += 2; sh.y += 2;
    text(j.s, sh, j.f, RGB(2, 3, 6), j.fmt);
    text(j.s, j.r, j.f, j.c, j.fmt);
  }
  g_tjN = 0;
}

void add_hit(int x, int y, int w, int h, HitKind k, int idx) {
  if (g_hitN >= 48) return;
  g_hit[g_hitN].r.x = x; g_hit[g_hitN].r.y = y; g_hit[g_hitN].r.w = w; g_hit[g_hitN].r.h = h;
  g_hit[g_hitN].kind = k; g_hit[g_hitN].idx = idx;
  ++g_hitN;
}
int hit_at(int px, int py) {
  for (int i = g_hitN - 1; i >= 0; --i) if (vmenu::inside(g_hit[i].r, px, py)) return i;
  return -1;
}

// 1.7.117 the picture size the game will get at the next start: an explicit size (picture_lines) or the saved level, worked out from the desktop shape like the display-mode hook does
int picture_effective_size(unsigned* w, unsigned* h) {
  unsigned dw = 0, dh = 0;
  if (!modes_desktop_size(&dw, &dh)) return 0;
  uint32_t pw = 0, ph = 0;
  const LONG pl = g_ctl.pictureLines;
  if (pl >= (LONG)picture::kMinLines) { if (!picture::lines_size((uint32_t)pl, dw, dh, &pw, &ph)) return 0; }
  else if (g_ctl.pictureLevel <= 1) { pw = dw; ph = dh; }
  else if (!picture::level_size((int)g_ctl.pictureLevel, dw, dh, &pw, &ph)) return 0;
  *w = pw; *h = ph;
  return 1;
}
// one click on the Resolution row: the next size on the ladder 1080 / 1440 / 1800 / 2160 / 2880 lines (at your screen's shape)
void picture_menu_step(int dir) {
  unsigned w = 0, h = 0;
  if (!picture_effective_size(&w, &h)) return;
  const unsigned cur = h, next = picture::ladder_step(cur, dir);
  if (next == cur) return;
  const LONG oldLines = g_ctl.pictureLines, oldLevel = g_ctl.pictureLevel;
  { long nl = 0, nv = 2; picture::ladder_apply(next, &nl, &nv); InterlockedExchange(&g_ctl.pictureLines, (LONG)nl); InterlockedExchange(&g_ctl.pictureLevel, (LONG)nv); }
  g_guardKeepLevel = 0;   // an explicit choice beats the memory guard's remembered level
  safety_forget_override(&g_ctl.pictureLevel); safety_forget_override(&g_ctl.pictureLines);
  safety_reset_health();
  settings_changed();
  engine_request_sample();
  g_dirty = 1;
  unsigned nw = 0, nh = 0; picture_effective_size(&nw, &nh);
  log_line("PICTURE %ux%u chosen in the VR menu (was %u lines; level %d -> %d, lines %d -> %d): used from the next start of the game; this run stays at level %d", nw, nh, cur, (int)oldLevel, (int)g_ctl.pictureLevel, (int)oldLines, (int)g_ctl.pictureLines, modes_active_level());
}

void value_text(const Item& it, wchar_t* out, int cap) {
  if (it.key && lstrcmpA(it.key, "vr_fps_cap") == 0 && (!it.v || !*it.v)) { lstrcpynW(out, L"Off", cap); return; }
  if (it.key && it.v && lstrcmpA(it.key, "vr_fps_cap") == 0) {   // 1.7.155: say what you really get on THIS headset (the report: eleven clicks through numbers that mostly gave the same result)
    const int c = ratecap::valid((int)*it.v);
    if (!c) { lstrcpynW(out, L"Off", cap); return; }   // 1.7.180: a stray stored number the engine ignores shows as Off
    const double hz = (double)vr_capi_display_hz();
    wchar_t t[48];
    if (!ratecap::rate_known(hz)) {
      if (c == ratecap::kHalf || c == ratecap::kThird) lstrcpynW(t, c == ratecap::kHalf ? L"Half rate" : L"A third", 48); else wsprintfW(t, L"%d FPS", c);
    } else {
      const int n = ratecap::divisor(hz, c);
      const int eff = (int)(ratecap::effective_fps(hz, c) + 0.5);
      if (n <= 1 && !ratecap::fractional(hz, c)) wsprintfW(t, L"%d: no limit at %d Hz", c, (int)(hz + 0.5));
      else if (c == ratecap::kHalf) wsprintfW(t, L"Half rate = %d FPS", eff);
      else if (c == ratecap::kThird) wsprintfW(t, L"A third = %d FPS", eff);
      else if (eff == c) wsprintfW(t, L"%d FPS", c);   // 1.7.182: no "(uneven)" tag (it did not fit the row)
      else wsprintfW(t, L"%d -> %d FPS", c, eff);
    }
    lstrcpynW(out, t, cap); return;
  }
  if (it.key && it.v && lstrcmpA(it.key, "picture_level") == 0) {   // 1.7.117: say what the resolution really is (the game's picture size that will be used at the next start)
    unsigned pw = 0, ph = 0;
    if (picture_effective_size(&pw, &ph)) { wchar_t t[40]; wsprintfW(t, L"%ux%u", pw, ph); lstrcpynW(out, t, cap); return; }
  }
  char a[24];
  vmenu::fmt_value(a, 24, it.v ? (int)*it.v : 0, it.div);
  int n = 0;
  for (; a[n] && n < cap - 1; ++n) out[n] = (wchar_t)a[n];
  if (it.unit) for (int k = 0; it.unit[k] && n < cap - 1; ++k) out[n++] = it.unit[k];
  out[n] = 0;
}

void render() {
  g_hitN = 0; g_tjN = 0;
  ensure_base();
  g_g.GdiFlush();
  CopyMemory(g_bits, g_base, (size_t)W * H * 4);
  // header
  vmenu::Rect band = {0, 0, W, 92};
  panel(band, cBand, 0, kAlBand);
  vmenu::Rect t1 = {24, 8, 560, 70};
  qtext(L"GHOSTBUSTERS VR", t1, g_fTitle, cAccent, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
  vmenu::Rect t2 = {588, 8, 668, 70};
  qtext(g_pages[g_page].title, t2, g_fSmall, cSub, DT_RIGHT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);   // 1.3: the page title is up here (the footer shows the explanation)
  // tabs
  for (int i = 0; i < kPages; ++i) {
    vmenu::Rect r = {kTabX, kTabY + i * (kTabH + kTabGap), kTabW, kTabH};
    const int hv = g_hover >= 0 && g_hit[g_hover].kind == HK_TAB && g_hit[g_hover].idx == i;
    panel(r, i == g_page ? cAccent : hv ? cTabHover : cTab, 14, i == g_page ? kAlTabOn : kAlTab);
    qtext(g_pages[i].tab, r, g_fTab, cText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    add_hit(r.x, r.y, r.w, r.h, HK_TAB, i);
  }
  Page& pg = g_pages[g_page];
  int hotItem = -1;
  // rows
  for (int i = 0; i < pg.n; ++i) {
    Item& it = pg.it[i];
    const int y = kRowY + i * (kRowH + kRowGap);
    vmenu::Rect row = {kRowX, y, kRowW, kRowH};
    const int rowHot = it.kind != K_NOTE && g_hover >= 0 && g_hit[g_hover].idx == i && g_hit[g_hover].kind != HK_TAB && g_hit[g_hover].kind != HK_CLOSE;
    if (rowHot) hotItem = i;
    panel(row, rowHot ? cRowHot : cRow, 12, kAlRow);
    if (it.kind != K_NOTE) add_hit(row.x, row.y, row.w, row.h, HK_ROW, i);   // first, so the buttons on it win
    if (it.kind == K_NOTE) {
      vmenu::Rect r = {kRowX + 18, y + 4, kRowW - 36, kRowH - 8};
      qtext(it.label, r, g_fSmall, cText, DT_LEFT | DT_VCENTER | DT_WORDBREAK);
      continue;
    }
    const int rx = kRowX + kRowW - 12;
    const int tw = it.kind == K_TOGGLE ? 730 : it.kind == K_STEP ? 628 : 690;   // room for the words, left of the buttons
    vmenu::Rect l1 = {kRowX + 18, y + 4, tw, 36};
    vmenu::Rect l2 = {kRowX + 18, y + 38, tw, 28};
    qtext(it.label, l1, g_fLabel, cText, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    qtext(it.desc, l2, g_fDesc, cSub, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    if (it.kind == K_TOGGLE) {
      vmenu::Rect r = {rx - 200, y + 6, 200, 60};
      const int on = it.v && *it.v != 0;
      const int hv = g_hover >= 0 && g_hit[g_hover].kind == HK_TOGGLE && g_hit[g_hover].idx == i;
      panel(r, on ? (hv ? RGB(70, 196, 118) : cOn) : (hv ? RGB(122, 128, 146) : cOff), 30, kAlPill);
      qtext(on ? L"ON" : L"OFF", r, g_fBtn, cText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
      add_hit(r.x, r.y, r.w, r.h, HK_TOGGLE, i);
    } else if (it.kind == K_STEP) {
      vmenu::Rect plus = {rx - 70, y + 6, 70, 60}, val = {rx - 70 - 6 - 150, y + 6, 150, 60}, minus = {rx - 70 - 6 - 150 - 6 - 70, y + 6, 70, 60};
      const int hm = g_hover >= 0 && g_hit[g_hover].kind == HK_MINUS && g_hit[g_hover].idx == i;
      const int hp = g_hover >= 0 && g_hit[g_hover].kind == HK_PLUS && g_hit[g_hover].idx == i;
      panel(minus, hm ? cBtnHover : cBtn, 16, kAlBtn);
      panel(plus, hp ? cBtnHover : cBtn, 16, kAlBtn);
      panel(val, cValue, 16, kAlVal);
      qtext(L"-", minus, g_fValue, cText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
      qtext(L"+", plus, g_fValue, cText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
      wchar_t vt[40];
      value_text(it, vt, 40);
      qtext(vt, val, lstrlenW(vt) > 6 ? g_fSmall : g_fBtn, cText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);   // 1.7.117: "3840x2160" is smaller type so it fits
      add_hit(minus.x, minus.y, minus.w, minus.h, HK_MINUS, i);
      add_hit(plus.x, plus.y, plus.w, plus.h, HK_PLUS, i);
    } else if (it.kind == K_ACTION) {
      vmenu::Rect r = {rx - 240, y + 6, 240, 60};
      const int hv = g_hover >= 0 && g_hit[g_hover].kind == HK_ACTION && g_hit[g_hover].idx == i;
      panel(r, hv ? cAccent : cBtn, 30, kAlPill);
      qtext(it.btn, r, g_fBtn, cText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
      add_hit(r.x, r.y, r.w, r.h, HK_ACTION, i);
    }
  }
  // footer: status and close
  const int footW = kRowX + kRowW - 250 - 12 - kTabX - (g_live ? 232 : 0);   // 1.3: the whole strip left of the Close button (1.7.84: and left of "Game menu" in live mode)
  vmenu::Rect stp = {kTabX, 730, footW, 56};
  panel(stp, cBand, 14, kAlBand);
  if (hotItem >= 0 && pg.it[hotItem].desc && pg.it[hotItem].desc[0]) {   // 1.3: point at a row = its full explanation here (the row itself only has room for the start)
    vmenu::Rect st = {kTabX + 16, 732, footW - 32, 52};
    qtext(pg.it[hotItem].desc, st, g_fHelp, cText, DT_LEFT | DT_VCENTER | DT_WORDBREAK | DT_END_ELLIPSIS);
  } else {
    vmenu::Rect st = {kTabX + 16, 730, footW - 32, 56};
    qtext(g_status, st, g_fSmall, cSub, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
  }
  vmenu::Rect cl = {kRowX + kRowW - 250, 730, 250, 56};
  const int hc = g_hover >= 0 && g_hit[g_hover].kind == HK_CLOSE && g_hit[g_hover].idx == 0;
  panel(cl, hc ? cAccent : cBtn, 28, kAlPill);
  qtext((g_viaHeld && !g_live) ? L"< Game menu" : L"Close menu", cl, g_fBtn, cText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
  add_hit(cl.x, cl.y, cl.w, cl.h, HK_CLOSE, 0);
  if (g_live) {   // 1.7.84: the game's own menu (save, load, quit) is one button away
    vmenu::Rect gm = {kRowX + kRowW - 250 - 232, 730, 220, 56};
    const int hg = g_hover >= 0 && g_hit[g_hover].kind == HK_CLOSE && g_hit[g_hover].idx == 1;
    panel(gm, hg ? cAccent : cBtn, 28, kAlPill);
    qtext(L"Game menu >", gm, g_fBtn, cText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    add_hit(gm.x, gm.y, gm.w, gm.h, HK_CLOSE, 1);
  }
  flush_text();
  if (g_curShown && g_curX >= 0) {   // 0.56 own pointer: a small ring where the controller points (fallback only: the ring is normally its own overlay)
    HBRUSH b = g_g.CreateSolidBrush(RGB(255, 255, 255));
    HBRUSH b2 = g_g.CreateSolidBrush(cAccent);
    HGDIOBJ ob = g_g.SelectObject(g_dc, b);
    HGDIOBJ op = g_g.SelectObject(g_dc, g_nullPen);
    g_g.RoundRect(g_dc, g_curX - 15, g_curY - 15, g_curX + 16, g_curY + 16, 31, 31);
    g_g.SelectObject(g_dc, b2);
    g_g.RoundRect(g_dc, g_curX - 9, g_curY - 9, g_curX + 10, g_curY + 10, 19, 19);
    g_g.SelectObject(g_dc, ob);
    g_g.SelectObject(g_dc, op);
    g_g.DeleteObject(b);
    g_g.DeleteObject(b2);
  }
  g_g.GdiFlush();
  // BGRA (alpha unset) -> RGBA opaque
  const uint8_t* sp = g_bits;
  uint8_t* d = g_rgba;
  for (int i = 0; i < W * H; ++i, sp += 4, d += 4) { d[0] = sp[2]; d[1] = sp[1]; d[2] = sp[0]; d[3] = 255; }
  InterlockedIncrement(&g_picSerial);   // 1.7.90: the PC window shows the same picture (monitorview.cpp)
}

void make_status() {
  const DWORD now = GetTickCount();
  int cm = 0, pct = 0, cnt = 0;
  body_last_calibration(&cm, &pct, &cnt);
  wchar_t s[160];
  if (g_calibAt) {
    int left = (int)(((int32_t)(g_calibAt - now) + 999) / 1000);
    if (left < 1) left = 1;
    wsprintfW(s, L"Stand straight and look ahead...  %d", left);
  } else if (g_measuring) {
    wsprintfW(s, L"Measuring... keep still");
  } else if (g_resultUntil && (int32_t)(g_resultUntil - now) > 0) {
    if (!g_mFail && cnt != g_calibCountBefore && pct) wsprintfW(s, L"Done! Eye height %d cm -> world size %d %%", cm, pct);
    else if (g_mFail == 1) wsprintfW(s, L"Could not measure: the headset is not tracked. Try again.");
    else if (g_mFail == 2) wsprintfW(s, L"Could not measure: the headset reads %d cm. Stand up straight.", (int)(g_mLastM * 100.0 + 0.5));
    else if (g_mFail == 3) wsprintfW(s, L"Could not measure: you moved. Stand still and try again.");
    else if (g_mFail == 4) wsprintfW(s, L"Seated play: stand up to measure (%d cm is a sitting height). Nothing changed.", (int)(g_mLastM * 100.0 + 0.5));
    else wsprintfW(s, L"Could not measure your height - try again");
  } else if (g_noteUntil && (int32_t)(g_noteUntil - now) > 0) {
    lstrcpynW(s, g_note, 160);
  } else if (engine_freeze_active()) {
    wsprintfW(s, L"Game is frozen while this menu is open   |   VR mod " GBVR_WIDE_VERSION);
  } else {
    wsprintfW(s, L"Game: %s   |   World size %d %%   |   VR mod " GBVR_WIDE_VERSION, game_running_now() ? L"running" : L"paused or in a menu", (int)g_ctl.worldPct);
  }
  if (lstrcmpW(s, g_status) != 0) { lstrcpyW(g_status, s); g_dirty = 1; }
}

void tick_feedback() {
  haptics_add(0, hap::kSrcButton, 0.35f, 26);
  haptics_add(1, hap::kSrcButton, 0.35f, 26);
}

void set_value(Item& it, int nv) {
  if (!it.v) return;
  nv = vmenu::clamp_i(nv, (int)it.lo, (int)it.hi);
  const int old = (int)*it.v;
  if (nv == old) return;
  if (it.key[0] == 'p' && it.key[1] == 'r' && it.key[2] == 'o' && it.key[3] == 'f') {   // profile_slot: save this person, load the other
    settings_profile_switch(old, nv);
    g_dirty = 1;
    log_line("MENUSET %s %d -> %d (page %ls)", it.key, old, nv, g_pages[g_page].tab);
    return;
  }
  InterlockedExchange(it.v, nv);
  settings_changed();
  engine_request_sample();
  InterlockedIncrement(&g_s.setChanges);
  if (it.key[0] == 'r' && it.key[1] == 'e' && it.key[2] == 'a' && it.key[3] == 'l') {   // real_models: the body hide switches follow, as with F1
    InterlockedExchange(&g_ctl.hideBody, nv ? 0 : 1);
    InterlockedExchange(&g_ctl.hideWand, nv ? 0 : 1);
  }
  if (lstrcmpA(it.key, "picture_level") == 0) {   // 1.7.117: the resolution is chosen for the NEXT start: an explicit choice beats the memory guard's remembered level, and is saved a moment later
    g_guardKeepLevel = 0;
    safety_reset_health();   // (the file is written by the render thread a moment later and again when the game closes)
    log_line("PICTURE level %d chosen in the VR menu (was %d): used from the next start of the game; this run stays at level %d", nv, old, modes_active_level());
  }
  if (it.key[0] == 'h' && it.key[1] == 'a' && it.key[2] == 'p') haptics_add(1, hap::kSrcHello, 0.9f, 220);   // buzz strength: feel it at once
  g_dirty = 1;
  log_line("MENUSET %s %d -> %d (page %ls)", it.key, old, nv, g_pages[g_page].tab);
}

void do_action(Act a) {
  InterlockedIncrement(&g_s.actions);
  switch (a) {
    case A_PAUSE: autopause_manual_leave(); log_line("MENU action: pause the game (game running=%d)", game_running_now()); g_closeAfter = 1; break;
    case A_OBJECTIVES:   // 1.7.108: from the pages in the hand the game is only frozen (its "running" stamp is old), so the plain request tapped no Start and nothing opened: use the forced path like "Game menu >"
      if (g_live) { log_line("MENU action: show my objectives from the pages in the hand: the game's pause menu is asked for (Start is tapped, the game was only frozen)"); held_menu_live_to_game("Show my objectives"); }
      else { if (!g_viaHeld) game_menu_request_force(); else game_menu_request(); g_closeAfter = 1; }   // 1.7.180: from the old floating menu the world is frozen, so the Start tap must be forced
      break;
    case A_RESUME: log_line("MENU action: resume (0.61: no Start tap any more; just closes, game running=%d)", game_running_now()); g_closeAfter = 1; break;
    case A_CALIB: {
      g_calibAt = GetTickCount() + 3000;
      g_resultUntil = 0;
      log_line("MENU action: measure my height (3 s countdown)");
      break;
    }
    case A_BUZZ: haptics_test(1); log_line("MENU action: buzz test"); break;
    case A_MARK: probe_mark("menu"); log_line("MENU action: mark this moment"); break;
    case A_RESETH: {
      const LONG oldW = g_ctl.worldPct, oldS = g_ctl.sizePct;
      InterlockedExchange(&g_ctl.sizePct, 100);
      InterlockedExchange(&g_ctl.worldPct, 115);
      settings_changed();
      engine_request_sample();
      wsprintfW(g_note, L"Height reset: world size %d %% -> 115 %%", (int)oldW);
      g_noteUntil = GetTickCount() + 6000; g_lastStatus = 0; g_dirty = 1;
      log_line("MENU action: reset height: world size %d%% -> 115%%, player height %d%% -> 100%%", (int)oldW, (int)oldS);
      break;
    }
    case A_RECENTER:   // 1.7.180: after 3 seconds (stand or sit the way you will play and look ahead), with a note
      InterlockedExchange(&g_ctl.seatRecenterAt, (LONG)(GetTickCount() + 3000u) | 1);
      wsprintfW(g_note, L"Recentering in 3 seconds: look straight ahead");
      g_noteUntil = GetTickCount() + 4000; g_lastStatus = 0; g_dirty = 1;
      log_line("MENU action: recenter (in 3 s)"); break;
    case A_CLOSE: if (g_viaHeld && !g_live) g_closeAfter = 1; else vrmenu_toggle("close button"); break;   // 1.7.28: in the hand it only goes back to the game menu
    case A_GAMEMENU: held_menu_live_to_game("Game menu button"); break;   // 1.7.84: the pages close, the game's own pause menu (save, load, quit) opens in the hand
    default: break;
  }
}

void activate(const Hit& h, int fromRepeat) {
  Page& pg = g_pages[g_page];
  switch (h.kind) {
    case HK_TAB: if (g_page != h.idx) { g_page = h.idx; g_dirty = 1; g_hover = -1; g_down = -1; log_line("MENU page %ls", g_pages[g_page].tab); } break;
    case HK_TOGGLE: { Item& it = pg.it[h.idx]; if (it.v) set_value(it, *it.v ? 0 : 1); break; }
    case HK_MINUS: { Item& it = pg.it[h.idx]; if (it.key && lstrcmpA(it.key, "picture_level") == 0) { picture_menu_step(-1); break; } if (it.v) set_value(it, it.key && lstrcmpA(it.key, "vr_fps_cap") == 0 ? ratecap::next_for((double)vr_capi_display_hz(), (int)*it.v, -1) : vmenu::step_value((int)*it.v, (int)it.lo, (int)it.hi, it.step, -1)); break; }
    case HK_PLUS: { Item& it = pg.it[h.idx]; if (it.key && lstrcmpA(it.key, "picture_level") == 0) { picture_menu_step(1); break; } if (it.v) set_value(it, it.key && lstrcmpA(it.key, "vr_fps_cap") == 0 ? ratecap::next_for((double)vr_capi_display_hz(), (int)*it.v, 1) : vmenu::step_value((int)*it.v, (int)it.lo, (int)it.hi, it.step, 1)); break; }
    case HK_ACTION: do_action(pg.it[h.idx].act); break;
    case HK_CLOSE: do_action(h.idx == 1 ? A_GAMEMENU : A_CLOSE); break;   // idx 1 = the "Game menu" button next to Close (live mode only)
    default: break;
  }
  if (!fromRepeat) { InterlockedIncrement(&g_s.clicks); tick_feedback(); }
}

// pointer moved onto item hv (-1 = nothing)
void on_move(int hv, int fromOwn, int hand) {
  if (hv != g_hover) {
    g_hover = hv; g_dirty = 1;
    if (hv >= 0 && fromOwn && hand >= 0 && g_hit[hv].kind != HK_ROW) haptics_add(hand, hap::kSrcButton, 0.12f, 12);   // a tiny tick when a button is under the pointer
  }
}
void on_down(int hv) {
  g_down = hv;
  if (hv >= 0) {
    const Hit& h = g_hit[hv];
    if (h.kind == HK_TAB || h.kind == HK_MINUS || h.kind == HK_PLUS) {
      activate(h, 0);
      if (h.kind != HK_TAB) g_rep.press(GetTickCount());
    }
  }
}
void on_up(int hv) {
  g_rep.release();
  if (g_down >= 0 && g_down == hv) {
    const Hit h = g_hit[hv];
    if (h.kind == HK_TOGGLE || h.kind == HK_ACTION || h.kind == HK_CLOSE) activate(h, 0);
  }
  g_down = -1;
  g_dirty = 1;
}

void pump_events() {
  GbvrOverlayEvt ev[32];
  const int n = vr_capi_menu_events(ev, 32);
  if (g_ctl.menuOwnPointer) { InterlockedAdd(&g_s.ovEvents, n); return; }   // 0.61: laser events ignored, the ring from the controller ray is the pointer
  for (int i = 0; i < n; ++i) {
    InterlockedIncrement(&g_s.ovEvents);
    g_lastOvEvtMs = GetTickCount();
    int px, py;
    if (!vmenu::pointer_px(ev[i].x, ev[i].y, W, H, g_ctl.menuFlip != 0, &px, &py)) continue;
    const int hv = hit_at(px, py);
    if (ev[i].type == 1) { InterlockedIncrement(&g_s.moves); on_move(hv, 0, -1); }
    else if (ev[i].type == 2) { on_move(hv, 0, -1); on_down(hv); }
    else if (ev[i].type == 3) on_up(hv);
    if (!g_open) return;   // the Close button ended the menu
  }
}

// 0.56 own pointer: SteamVR's laser needs the "interactive overlay" mode; if it gives no events, a controller still works as a pointer:
// a ray from the controller (forward = -z of its pose) meets the menu plane; the trigger clicks. Used only while the laser is silent.
int ray_to_menu(const float* hp, double* fu, double* fv, double* hit = nullptr) {
  const double ox = hp[3], oy = hp[7], oz = hp[11];
  const double dx = -hp[2], dy = -hp[6], dz = -hp[10];
  const double nx = g_xf[2], ny = g_xf[6], nz = g_xf[10];
  const double den = dx * nx + dy * ny + dz * nz;
  if (den > -1e-4 && den < 1e-4) return 0;
  const double t = ((g_xf[3] - ox) * nx + (g_xf[7] - oy) * ny + (g_xf[11] - oz) * nz) / den;
  if (!(t > 0.05) || t > 6.0) return 0;
  const double rx = ox + dx * t - g_xf[3], ry = oy + dy * t - g_xf[7], rz = oz + dz * t - g_xf[11];
  const double u = (rx * g_xf[0] + ry * g_xf[4] + rz * g_xf[8]) / (double)g_menuWidthM + 0.5;
  const double v = (rx * g_xf[1] + ry * g_xf[5] + rz * g_xf[9]) / ((double)g_menuWidthM * (double)H / (double)W) + 0.5;
  if (u < 0.0 || u > 1.0 || v < 0.0 || v > 1.0) return 0;
  *fu = u * (double)(W - 1);               // 0.68: pixels as numbers with fractions (the pointer is filtered before it is rounded)
  *fv = (1.0 - v) * (double)(H - 1);
  if (hit) { hit[0] = ox + dx * t; hit[1] = oy + dy * t; hit[2] = oz + dz * t; }
  return 1;
}

// 0.66 the ring: a white band with a dark outline around a red dot, soft edges, transparent elsewhere (straight alpha)
inline double band(double r, double r0, double r1) {
  double a = r - r0 + 0.5, b = r1 - r + 0.5;
  double c = a < b ? a : b;
  return c < 0 ? 0 : c > 1 ? 1 : c;
}
void over(double* px, double cr, double cg, double cb, double ca) {   // px: r g b a (0..1, straight alpha) <- colour over px
  const double oa = ca + px[3] * (1.0 - ca);
  if (oa <= 0) return;
  for (int i = 0; i < 3; ++i) { const double c = i == 0 ? cr : i == 1 ? cg : cb; px[i] = (c * ca + px[i] * px[3] * (1.0 - ca)) / oa; }
  px[3] = oa;
}
void build_cursor() {
  if (g_curBuilt) return;
  g_curBuilt = 1;
  const double mid = (kCurPx - 1) * 0.5;
  for (int y = 0; y < kCurPx; ++y) for (int x = 0; x < kCurPx; ++x) {
    const double dx = x - mid, dy = y - mid, r = vm::dsqrt(dx * dx + dy * dy);
    double px[4] = {0, 0, 0, 0};
    over(px, 0.05, 0.05, 0.06, band(r, 19.0, 31.5) * 0.85);   // dark outline of the ring
    over(px, 1.0, 1.0, 1.0, band(r, 21.5, 29.0));              // white ring
    over(px, 0.05, 0.05, 0.06, band(r, 0.0, 11.5) * 0.85);     // dark outline of the dot
    over(px, 0.87, 0.24, 0.15, band(r, 0.0, 9.0));             // red dot
    uint8_t* o = g_curRgba + ((size_t)y * kCurPx + x) * 4;
    o[0] = (uint8_t)(px[0] * 255.0 + 0.5); o[1] = (uint8_t)(px[1] * 255.0 + 0.5); o[2] = (uint8_t)(px[2] * 255.0 + 0.5); o[3] = (uint8_t)(px[3] * 255.0 + 0.5);
  }
}
void hide_cursor() {
  if (g_curOvOn) { vr_capi_cursor(nullptr, 0, 0, nullptr, 0.0f, 0); g_curOvOn = 0; }
}

// the item under (px,py); the one already hovered keeps it until the pointer is 12 px outside it
int hit_sticky(int px, int py) {
  if (g_hover >= 0 && g_hover < g_hitN && vmenu::inside_margin(g_hit[g_hover].r, px, py, 12)) {
    const int h = hit_at(px, py);
    if (h < 0 || h == g_hover || !vmenu::inside(g_hit[h].r, px, py)) return g_hover;
    return h;
  }
  return hit_at(px, py);
}
const char* kind_name(HitKind k) { return k == HK_TAB ? "tab" : k == HK_TOGGLE ? "switch" : k == HK_MINUS ? "minus" : k == HK_PLUS ? "plus" : k == HK_ACTION ? "button" : k == HK_CLOSE ? "close" : k == HK_ROW ? "row" : "nothing"; }

void own_pointer(uint32_t now) {
  if (!g_ctl.menuOwnPointer && (int32_t)(now - g_lastOvEvtMs) < 500 && g_lastOvEvtMs) {   // the laser works: leave it alone, no ring
    if (g_curShown) { g_curShown = 0; g_dirty = 1; }
    g_ownTrig = 0;
    return;
  }
  int best = -1;
  double fu = 0, fv = 0;
  float trig = 0;
  double hitW[3] = {0, 0, 0};
  vr_capi_hand_predict_off(1);   // 0.68: the measured pose, not the predicted one (prediction adds the hand's velocity noise: jitter)
  for (int pass = 0; pass < 2; ++pass) {
    const int hand = pass == 0 ? 1 : 0;   // right hand first
    GbvrHandRaw hr;
    if (!vr_capi_hand(hand, &hr)) continue;
    double u, v;
    if (ray_to_menu(hr.pose34, &u, &v, hitW)) { best = hand; fu = u; fv = v; trig = hr.trigger; break; }
  }
  vr_capi_hand_predict_off(0);
  if (best < 0) {
    hide_cursor();
    g_ptrOn = 0; g_ptr.reset();
    if (g_curShown) { g_curShown = 0; g_dirty = 1; }
    if (g_ownTrig) { g_ownTrig = 0; on_up(-1); }
    return;
  }
  InterlockedIncrement(&g_s.ownMoves);
  // 0.68 smooth + hold: see vmenumath.h Pointer
  if (!g_ptrOn) { g_ptr.reset(); g_ptrMs = now; }
  g_ptrOn = 1;
  double dt = (double)(now - g_ptrMs) * 0.001;
  if (!(dt > 0.0005)) dt = 0.0005; if (dt > 0.25) dt = 0.25;
  g_ptrMs = now;
  double ox = fu, oy = fv;
  const int held = g_ptr.update(fu, fv, dt, (double)trig, &ox, &oy);
  if (held) InterlockedIncrement(&g_s.heldTicks);
  const int bx = vmenu::clamp_i((int)(ox + 0.5), 0, W - 1), by = vmenu::clamp_i((int)(oy + 0.5), 0, H - 1);
  const int hv = hit_sticky(bx, by);
  const int dx = bx - g_curX, dy = by - g_curY;
  if (g_curOvState == 0) {   // 0.66: the ring is its own overlay, moved a few millimetres in front of the menu; the menu picture is not touched
    build_cursor();
    // the ring goes where the (smoothed / held) pointer is, not where the raw ray is
    const double uu = ox / (double)(W - 1) - 0.5, vv = 0.5 - oy / (double)(H - 1), mw = (double)g_menuWidthM, mh = (double)g_menuWidthM * (double)H / (double)W;
    for (int i = 0; i < 3; ++i) hitW[i] = g_xf[3 + 4 * i] + g_xf[0 + 4 * i] * uu * mw + g_xf[1 + 4 * i] * vv * mh;
    const double ddx = hitW[0] - g_curLast[0], ddy = hitW[1] - g_curLast[1], ddz = hitW[2] - g_curLast[2];
    if (!g_curOvOn || ddx * ddx + ddy * ddy + ddz * ddz > 0.001 * 0.001) {
      float xf[12];
      for (int i = 0; i < 12; ++i) xf[i] = g_xf[i];
      xf[3] = (float)(hitW[0] + g_xf[2] * 0.006); xf[7] = (float)(hitW[1] + g_xf[6] * 0.006); xf[11] = (float)(hitW[2] + g_xf[10] * 0.006);
      const int e = vr_capi_cursor(g_curRgba, kCurPx, kCurPx, xf, kCurWidthM, 1);
      if (e == 0) { g_curOvOn = 1; g_curOvFails = 0; g_curLast[0] = hitW[0]; g_curLast[1] = hitW[1]; g_curLast[2] = hitW[2]; InterlockedIncrement(&g_curSt.moves); }
      else {
        InterlockedIncrement(&g_curSt.fails);
        if (++g_curOvFails >= 3) { g_curOvState = -1; log_line("MENU the pointer overlay was refused by SteamVR (error %d): the ring is painted into the menu picture instead (slower)", e); }
      }
    }
    g_curX = bx; g_curY = by;
  } else if (!g_curShown || dx * dx + dy * dy >= 25) { g_curX = bx; g_curY = by; g_curShown = 1; g_dirty = 1; }
  g_ownHand = best;
  on_move(hv, 1, best);
  if (!g_trigArmed && trig < 0.2f) g_trigArmed = 1;
  if (!g_ownTrig && g_trigArmed && trig > 0.6f) {
    g_ownTrig = 1; InterlockedIncrement(&g_s.ownClicks);
    // data for the next version: where the click landed, what was under it, how far the raw pointer wandered during the squeeze
    if (g_clickLogged < 60) {
      ++g_clickLogged;
      log_line("MENUCLICK #%d pixel %d,%d item %d (%s%s%ls) hand=%s held=%d trigger=%.2f rawNow=%.0f,%.0f wanderedWhileSqueezing=%.0f px filteredJitter=%.2f px",
               (int)g_clickLogged, bx, by, hv, hv >= 0 ? kind_name(g_hit[hv].kind) : "nothing", hv >= 0 && g_hit[hv].kind != HK_TAB && g_hit[hv].kind != HK_CLOSE ? " of " : (hv >= 0 && g_hit[hv].kind == HK_TAB ? " " : ""),
               hv >= 0 && g_hit[hv].kind == HK_TAB ? g_pages[g_hit[hv].idx].tab : (hv >= 0 && g_hit[hv].kind != HK_CLOSE ? g_pages[g_page].it[g_hit[hv].idx].label : L""),
               best ? "right" : "left", held, (double)trig, fu, fv, g_ptr.lockedMovePx, g_ptr.jitterN ? g_ptr.jitterSum / (double)g_ptr.jitterN : 0.0);
    }
    on_down(hv);
  }
  else if (g_ownTrig && trig < 0.35f) { g_ownTrig = 0; on_up(hv); }
}

void deliver(const float* place) {
  if (!gdi_init()) return;
  float hdX[12]; double hdW = 0.0;
  if (g_viaHeld && held_vr_place(hdX, &hdW)) { place = hdX; g_menuWidthM = (float)hdW; }   // 1.7.31: a new picture goes up at the hand's newest spot, not at the one remembered from a moment ago
  const DWORD t0 = GetTickCount();
  render();
  const int e = vr_capi_menu_overlay(g_rgba, W, H, place, g_menuWidthM);
  const DWORD ms = GetTickCount() - t0;
  g_s.lastDrawMs = ms;
  if (ms > g_s.maxDrawMs) g_s.maxDrawMs = ms;
  InterlockedIncrement(&g_s.redraws);
  if (e == 0) InterlockedIncrement(&g_s.uploads);
  else {
    InterlockedIncrement(&g_s.uploadFail);
    g_s.lastErr = e;
    if (g_s.uploadFail <= 5) log_line("MENU picture was not accepted by SteamVR (overlay error %d)", e);
  }
  g_dirty = 0;
  g_lastDraw = GetTickCount();
}

void open_menu(const char* why) {
  if (!gdi_init()) return;
  vr_capi_menu_laser(g_ctl.menuOwnPointer ? 0 : 1);
  resolve();
  float head[12], xf[12];
  const float* place = nullptr;
  g_lastOvEvtMs = 0; g_curShown = 0; g_ownTrig = 0; g_curOvOn = 0; g_ptrOn = 0; g_ptr.reset(); g_trigArmed = 0;
  double heldW = 0;
  g_menuWidthM = kMenuWidthM;
  if (g_viaHeld && held_vr_place(xf, &heldW)) { place = xf; g_menuWidthM = (float)heldW; }   // 1.7.28: in the hand
  else if (vr_capi_hmd_pose(head, nullptr) && vmenu::place_in_front(head, kMenuDistM, kMenuDropM, xf)) place = xf;
  else { float p0[12] = {1, 0, 0, 0, 0, 1, 0, 1.4f, 0, 0, 1, 0}; vmenu::place_in_front(p0, kMenuDistM, kMenuDropM, xf); place = xf; log_line("MENU no usable head pose: placed at a default spot"); }
  for (int i = 0; i < 12; ++i) g_xf[i] = xf[i];
  make_status();
  g_hover = g_down = -1;
  g_rep.reset();
  g_open = 1;
  g_menuA = g_ctl.fadeInMs > 0 ? 0.0f : 1.0f; g_menuAMs = GetTickCount();   // 1.3: soft fade-in
  vr_capi_menu_alpha(g_menuA);
  if (!g_viaHeld || g_live) audio_menu(1);   // 0.69: the song starts, the game's own sound is muted (1.7.28: in the hand the game menu already started it; 1.7.84: live pages start it themselves)
  if (g_ctl.menuFreeze && (!g_viaHeld || g_live)) engine_freeze_pulse(1);
  InterlockedIncrement(&g_s.opens);
  deliver(place);
  log_line("MENU opened (%s), page %ls, placed at %.2f,%.2f,%.2f m, %.2f m wide%s", why, g_pages[g_page].tab, (double)xf[3], (double)xf[7], (double)xf[11], (double)g_menuWidthM, g_viaHeld ? ", in the hand" : "");
}

void close_menu(const char* why) {
  vr_capi_menu_hide();
  g_menuA = 1.0f; vr_capi_menu_alpha(1.0f);   // the next picture of it starts solid again (the fade-in sets it to 0 when it opens)
  g_open = 0;
  if (!g_viaHeld || g_live) audio_menu(0);   // 0.69: the song fades out, the game's sound comes back (1.7.28: in the hand the game menu keeps the song until it ends)
  const int wasLive = g_live;
  g_live = 0;
  g_viaHeld = 0; g_menuWidthM = kMenuWidthM;
  g_closedMs = GetTickCount();
  engine_freeze_pulse(0);
  g_down = g_hover = -1;
  g_rep.reset();
  g_calibAt = 0; g_measuring = 0;   // 1.7.180: closing the menu mid-countdown or mid-measure no longer leaves a half-started measure for the next opening
  InterlockedIncrement(&g_s.closes);
  log_line("MENU closed (%s)", why);
  if (wasLive) held_menu_live_end(why);
}

}  // namespace

int vrmenu_is_open() { return g_open; }
void vrmenu_set_cheap(int on) { g_cheap = on; }
// 0.56: open, or closed less than 1.5 s ago - SteamVR's laser mode takes and gives back the controllers ("input focus" events); those are not the player leaving
int vrmenu_quiet() { return g_open || (g_closedMs && (int32_t)(GetTickCount() - g_closedMs) < 1500); }

void vrmenu_toggle(const char* why) {
  if (!g_ctl.stereoActive) { log_line("MENU: not available now - start the headset view first (F4)"); return; }
  if (g_ctl.heldMenu && lstrcmpA(why, "game paused") != 0) { held_menu_toggle(why); return; }   // 1.7.28: the game's own pause menu, held in the hand, is the menu
  if (g_open) close_menu(why); else open_menu(why);
}

// 1.7.28: the settings pages inside the hand-held game menu
int vrmenu_open_in_hand() {
  if (g_open) return 1;
  g_viaHeld = 1;
  open_menu("hand-held");
  if (!g_open) g_viaHeld = 0;
  return g_open;
}
void vrmenu_close_in_hand(const char* why) { if (g_open) close_menu(why); }
// 1.7.84: the pages in the hand over the live world: the game is only frozen (no Start, no pause menu), so the 3D world keeps being drawn all around you
int vrmenu_open_live() {
  if (g_open) return 1;
  g_viaHeld = 1; g_live = 1;
  open_menu("hand-held, live world");
  if (!g_open) { g_viaHeld = 0; g_live = 0; }
  return g_open;
}
int vrmenu_is_live() { return g_live; }

// 1.7.28: the "VR SETTINGS" button painted onto the bottom of the game's menu picture (heldmenu.cpp). Two pictures (plain, pointed at) are drawn once per size with the menu's own GDI
// objects and kept. bgra order is converted to RGBA when the texture wants it. Returns null when GDI is not available.
const uint8_t* vrmenu_banner(int hover, int bw, int bh, int rgba) {
  static uint8_t* img[2][2];     // [hover][rgba order]
  static int sw, sh;
  if (bw < 64 || bh < 24 || bw > 4096 || bh > 1024) return nullptr;
  if (sw != bw || sh != bh) {    // another size: forget the old pictures
    for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b) { if (img[a][b]) { HeapFree(GetProcessHeap(), 0, img[a][b]); img[a][b] = nullptr; } }
    sw = bw; sh = bh;
  }
  const int hv = hover ? 1 : 0, ro = rgba ? 1 : 0;
  if (img[hv][ro]) return img[hv][ro];
  if (!gdi_init()) return nullptr;
  // 1.7.37: the game's picture can be much bigger than the menu's own bitmap (3840 x 2880 on a wide monitor view: the button is 1690 px wide, the bitmap 1280). The button is drawn at a size
  // that fits the bitmap and stretched to the real size when it is copied out (before, bw > W simply returned null: "no VR SETTINGS button" in every report since the monitor view got wide).
  int dw = bw, dh = bh;
  if (dw > W) { dh = (int)((long long)bh * W / bw); dw = W; }
  if (dh > H) { dw = (int)((long long)dw * H / dh); dh = H; }
  if (dw < 64 || dh < 24) return nullptr;
  // draw at the top left of the menu's own bitmap (render() starts every picture from its backdrop again, so nothing is left behind)
  g_g.GdiFlush();
  const COLORREF back = hv ? RGB(214, 70, 52) : RGB(24, 28, 40);
  const COLORREF edge = RGB(240, 200, 60);
  for (int y = 0; y < dh; ++y) {
    uint8_t* row = g_bits + (size_t)y * W * 4;
    for (int x = 0; x < dw; ++x) {
      const int inEdge = (x < 6 || y < 6 || x >= dw - 6 || y >= dh - 6);
      const COLORREF c = inEdge ? edge : back;
      row[x * 4 + 0] = GetBValue(c); row[x * 4 + 1] = GetGValue(c); row[x * 4 + 2] = GetRValue(c); row[x * 4 + 3] = 255;
    }
  }
  HFONT f = g_g.CreateFontW(-(dh * 56 / 100), 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, L"Segoe UI");
  if (!f) return nullptr;
  HGDIOBJ of = g_g.SelectObject(g_dc, f);
  g_g.SetTextColor(g_dc, RGB(255, 255, 255));
  RECT rc; rc.left = 0; rc.top = 0; rc.right = dw; rc.bottom = dh;
  DrawTextW(g_dc, hv ? L"VR SETTINGS  >" : L"VR SETTINGS", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
  g_g.GdiFlush();
  g_g.SelectObject(g_dc, of);
  g_g.DeleteObject(f);
  uint8_t* out = (uint8_t*)HeapAlloc(GetProcessHeap(), 0, (size_t)bw * bh * 4);
  if (!out) return nullptr;
  for (int y = 0; y < bh; ++y) {
    const int sy = (int)((long long)y * dh / bh);
    const uint8_t* srow = g_bits + (size_t)sy * W * 4;
    uint8_t* dp = out + (size_t)y * bw * 4;
    for (int x = 0; x < bw; ++x, dp += 4) {
      const uint8_t* sp = srow + (size_t)((int)((long long)x * dw / bw)) * 4;
      if (ro) { dp[0] = sp[2]; dp[1] = sp[1]; dp[2] = sp[0]; } else { dp[0] = sp[0]; dp[1] = sp[1]; dp[2] = sp[2]; }
      dp[3] = 255;
    }
  }
  g_dirty = 1;   // the menu's bitmap was used: its picture is drawn again before it is next sent
  img[hv][ro] = out;
  return out;
}

// 1.7.90: the settings pages' last finished picture (1280 x 800, RGBA, opaque) for the PC window, or null while the pages are not open / not drawn yet.
// 1.7.145: where the controller points on the pages (menu pixels), for the PC window's copy of the menu
int vrmenu_pointer(int* x, int* y) {
  if (!g_open || !g_curShown || g_curX < 0 || g_curY < 0 || !x || !y) return 0;
  *x = g_curX; *y = g_curY;
  return 1;
}

const uint8_t* vrmenu_picture(int* w, int* h, long* serial) {
  if (!g_open || g_picSerial == 0) return nullptr;
  *w = W; *h = H; *serial = (long)g_picSerial;
  return g_rgba;
}

void vrmenu_tick(LONG frame) {
  held_menu_tick(frame);   // 1.7.28: the hand-held game menu (starts / ends it; the settings pages below follow it)
  if (!g_ctl.stereoActive) { if (g_open) close_menu("headset view ended"); engine_freeze_pulse(0); g_activeFrames = 0; return; }
  // opens by itself once, about 2.5 seconds after the headset view really runs (frames counted since it started)
  ++g_activeFrames;
  if (!g_autoOpened && g_activeFrames > 180 && vr_capi_is_scene()) {
    if (!g_ctl.menuOnStart) g_autoOpened = 1;   // switch is off: nothing to do this run
    else if (game_running_now() || g_activeFrames > 2400) {   // 0.69: wait for the level to run (a menu that freezes the world during loading was the 0.61 problem), at most ~35 s
      g_autoOpened = 1;
      if (!g_open) { if (g_ctl.heldMenu) held_menu_toggle("start"); else open_menu("start"); }
    }
  }
  vr_capi_menu_settle();
  if (!g_open) return;
  if (!g_viaHeld || g_live) audio_menu(1);   // (cheap) also starts the sound thread if a Sound switch was turned on while the menu is open
  const DWORD now = GetTickCount();
  if (g_ctl.menuFreeze && (!g_viaHeld || g_live)) engine_freeze_pulse(1); else engine_freeze_pulse(0);
  if (g_viaHeld) {   // 1.7.28: the pages follow the hand
    float hxf[12]; double hw = 0;
    if (held_vr_place(hxf, &hw)) {
      for (int i = 0; i < 12; ++i) g_xf[i] = hxf[i];
      g_menuWidthM = (float)hw;
      if (!held_menu_mover_owns(1)) vr_capi_menu_overlay(nullptr, 0, 0, hxf, g_menuWidthM);   // 1.7.31: with the follow loop its own thread moves the pages
    }
  }
  if (g_menuA < 1.0f) {   // 1.3: fade in over about a quarter of a second
    const uint32_t dt = now - g_menuAMs;
    g_menuAMs = now;
    g_menuA += (float)dt / 240.0f;
    if (g_menuA > 1.0f || g_ctl.fadeInMs <= 0) g_menuA = 1.0f;
    vr_capi_menu_alpha(g_menuA);
  }
  pump_events();
  if (g_open) own_pointer(now);
  if (g_closeAfter) { g_closeAfter = 0; if (g_open) close_menu("pause/resume"); }
  if (!g_open) return;   // the Close button (or Pause / Resume) ended it during the events
  // held - / +
  if (g_down >= 0 && g_rep.due(now)) {
    const Hit& h = g_hit[g_down];
    if (h.kind == HK_MINUS || h.kind == HK_PLUS) activate(h, 1);
  }
  // measuring my height
  if (g_calibAt && (int32_t)(now - g_calibAt) >= 0) {
    g_calibAt = 0;
    g_measuring = 1; g_mN = 0; g_mFail = 0; g_mStartMs = now; g_mLastSampleMs = 0; g_hm.reset();
    body_last_calibration(&g_calibCmBefore, &g_calibPctBefore, &g_calibCountBefore);
    log_line("MEASURE started: stand straight and look ahead (menu): done after 1.5 s once a second of the head height holds within 4 cm, up to 3.5 s");
    haptics_add(1, hap::kSrcMark, 0.3f, 120);
    g_dirty = 1;
  }
  if (g_measuring) {   // 1.7.110: the steadiest second of the head height (body::HeightMeter), listening up to 3.5 s; before: the upper quarter of 1.5 s
    float hp[12];
    const double elapsed = (double)(int32_t)(now - g_mStartMs);
    if (g_mLastSampleMs != now) {
      g_mLastSampleMs = now;
      if (vr_capi_hmd_pose(hp, nullptr)) { ++g_mN; g_hm.add(elapsed, (double)hp[7]); }
    }
    const int r = elapsed >= 1500.0 ? g_hm.step(elapsed) : 0;
    if (r == 0 && elapsed >= 3600.0) g_mFail = 1;   // nothing usable came in
    if (r != 0 || g_mFail) {
      g_measuring = 0;
      g_resultUntil = now + 9000;
      g_dirty = 1;
      if (g_mFail == 0 && g_mN < 8) g_mFail = 1;
      else if (g_mFail == 0 && g_hm.n < 10) g_mFail = 1;
      else if (g_mFail == 0) {
        g_mLastM = g_hm.value;
        if (r == 2) g_mFail = 3;
        else if (g_hm.value < 1.0 || g_hm.value > 2.3) g_mFail = 2;
        else if (g_ctl.seated && g_hm.value < 1.35) g_mFail = 4;   // 1.7.140: seated play: a sitting head height made the world 90 % (Keith); only a standing measure is used
        else { body_calibrate_apply(g_hm.value, 0.0, 0.0); haptics_add(0, hap::kSrcMark, 0.9f, 200); haptics_add(1, hap::kSrcMark, 0.9f, 200); }
      }
      log_line("MEASURE %d samples over %.1f s, steadiest second %.2f..%.2f s had %d samples spread %.1f cm (%s), result (70%% of that second) %.3f m -> %s", g_hm.n, elapsed / 1000.0, g_hm.winStartMs / 1000.0, g_hm.winEndMs / 1000.0, g_hm.winN, g_hm.range * 100.0,
               g_hm.loose ? "loose: it never held within 4 cm" : "steady", g_hm.value,
               g_mFail == 0 ? "applied" : g_mFail == 3 ? "refused: the head kept moving more than 8 cm" : g_mFail == 4 ? "refused: seated play is on and this is a sitting height (stand up to measure)" : "refused: the head height is not a standing height");
      if (g_mFail) log_line("MEASURE failed (reason %d): nothing changed", g_mFail);
    }
  }
  if (now - g_lastStatus >= 400 || g_calibAt) { g_lastStatus = now; make_status(); }
  if (g_dirty && now - g_lastDraw >= (g_cheap ? 300u : 60u)) deliver(nullptr);
}

void vrmenu_report(LONG frame) {
  log_line("MENU frame=%d open=%d gdi=%d page=%ls opens=%d closes=%d clicks=%d pointerMoves=%d redraws=%d uploads=%d uploadFail=%d lastErr=%d "
           "lastDrawMs=%d maxDrawMs=%d settingChanges=%d actions=%d onStart=%d laserEvents=%d ownMoves=%d ownClicks=%d freeze=%d cursorOverlay=%d cursorMoves=%d cursorFails=%d heldTicks=%d pointerJitterPx=%.2f bg=%d/%d%%", (int)frame, g_open, g_gdiState, g_pages[g_page].tab, (int)g_s.opens, (int)g_s.closes,
           (int)g_s.clicks, (int)g_s.moves, (int)g_s.redraws, (int)g_s.uploads, (int)g_s.uploadFail, g_s.lastErr, (int)g_s.lastDrawMs, (int)g_s.maxDrawMs,
           (int)g_s.setChanges, (int)g_s.actions, (int)g_ctl.menuOnStart, (int)g_s.ovEvents, (int)g_s.ownMoves, (int)g_s.ownClicks, (int)g_ctl.menuFreeze,
           g_curOvState == 0 ? 1 : 0, (int)g_curSt.moves, (int)g_curSt.fails, (int)g_s.heldTicks, g_ptr.jitterN ? g_ptr.jitterSum / (double)g_ptr.jitterN : 0.0, (int)g_ctl.menuBg, (int)g_ctl.menuBgPct);
}

// 1.7.93 MENUFLOW (the settings pages): does the picture reach SteamVR, does any pointer reach the pages. Runs in every build (the MENU report above is part of the full dump only).
long vrmenu_flow(char* out, int cap) {
  const long uses = (long)g_s.opens + (long)g_s.ovEvents + (long)g_s.ownMoves + (long)g_s.clicks;
  const char* hint = "";
  if (g_s.opens > 0 && g_s.uploadFail > 0 && g_s.uploads == 0) hint = " => SteamVR refused the settings picture every time";
  else if (g_s.opens > 0 && g_s.uploads == 0) hint = " => the settings picture never reached SteamVR";
  else if (g_s.opens > 0 && g_s.ovEvents == 0 && g_s.ownMoves == 0) hint = " => no pointer ever reached the settings pages (no laser, no hand ray)";
  else if ((g_s.ownMoves > 0 || g_s.ovEvents > 0) && g_s.clicks == 0 && g_s.ownClicks == 0) hint = " => the pointer moved over the pages but nothing was pressed";
  log_fmt(out, cap, "settings pages: open now %d, opened %ld, closed %ld | SteamVR laser events %ld, hand-ray moves %ld, hand-ray trigger presses %ld, items pressed %ld, settings changed %ld | picture sent %ld times, refused %ld (last error %d) | own pointer %s%s",
          g_open, (long)g_s.opens, (long)g_s.closes, (long)g_s.ovEvents, (long)g_s.ownMoves, (long)g_s.ownClicks, (long)g_s.clicks, (long)g_s.setChanges, (long)g_s.uploads, (long)g_s.uploadFail, g_s.lastErr,
          g_ctl.menuOwnPointer ? "only" : "when the laser is silent", hint);
  return uses;
}

#endif
