// 0.51 the game's own wand model at the controller. Pure math, unit-tested in tests/test_wand.cpp.
//
// The wand is a model instance drawn with a 4x4 world matrix W (row vectors, translation in row 3: world = local x W).
// Its "tip" attachment matrix is tipLocal x W (rows 0..2 = axes, row 2 = the barrel direction, row 3 = position).
// To put the wand in the hand the whole instance is turned about its grip (W's translation) so the barrel points along
// the aim, and then the grip is moved to the controller:
//     W'rot = Wrot * R^T ,  W'trans = grip point   =>   tip' = grip + R * (tip - W.trans)
#pragma once
#include "vmath.h"
#include "weightmath.h"

namespace wand {

struct Solve { double R[9]; float tip[3]; float turnDeg; float gripToTipFt; float shiftFt; float rollDeg; int rolled; };

inline double dot3(const double* a, const double* b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

// W, tipm: 16 floats (the instance's world matrix and its tip matrix). grip: where the hand holds the wand (world).
// dir: aim direction (world). Returns 0 if the numbers are unusable.
// 0.58: up (optional, game world, unit-ish) = the controller's up direction. Besides pointing the barrel along dir, the wand is
// then turned about the barrel until its own up row (tip matrix row 1) matches the controller's up, so twisting the wrist rolls
// the gun (before, only the barrel direction followed: the roll stayed whatever the game's animation had). rollRad turns the
// target up about the barrel (a fix when the model's up is not the grip's up).
inline int solve(const float* W, const float* tipm, const float* grip, const float* dir, Solve* o, const float* up = nullptr, double rollRad = 0.0) {
  o->rollDeg = 0; o->rolled = 0;
  double d0[3] = {tipm[8], tipm[9], tipm[10]}, d1[3] = {dir[0], dir[1], dir[2]};
  double l0 = vm::dsqrt(dot3(d0, d0)), l1 = vm::dsqrt(dot3(d1, d1));
  if (!(l0 > 0.5) || !(l0 < 2.0) || !(l1 > 0.5) || !(l1 < 2.0)) return 0;
  for (int i = 0; i < 3; ++i) { d0[i] /= l0; d1[i] /= l1; }
  double cr[3] = {d0[1] * d1[2] - d0[2] * d1[1], d0[2] * d1[0] - d0[0] * d1[2], d0[0] * d1[1] - d0[1] * d1[0]};
  double sn = vm::dsqrt(dot3(cr, cr)), cs = dot3(d0, d1);
  double ang = vm::datan2(sn, cs);
  if (sn > 1e-6) { for (int i = 0; i < 3; ++i) cr[i] /= sn; weight::axis_angle(cr, ang, o->R); }
  else if (cs > 0) { weight::ident(o->R); ang = 0; }
  else {   // opposite directions: half a circle about any axis perpendicular to d0
    double ax[3] = {0, 1, 0};
    if (vm::dabs(d0[1]) > 0.9) { ax[0] = 1; ax[1] = 0; }
    double c2[3] = {d0[1] * ax[2] - d0[2] * ax[1], d0[2] * ax[0] - d0[0] * ax[2], d0[0] * ax[1] - d0[1] * ax[0]};
    double n = vm::dsqrt(dot3(c2, c2));
    for (int i = 0; i < 3; ++i) c2[i] /= n;
    weight::axis_angle(c2, vm::kPi, o->R);
    ang = vm::kPi;
  }
  if (up) {
    double cu[3] = {up[0], up[1], up[2]};
    double ul = vm::dsqrt(dot3(cu, cu));
    double t1[3] = {tipm[4], tipm[5], tipm[6]}, u0[3];
    for (int k = 0; k < 3; ++k) u0[k] = o->R[k * 3] * t1[0] + o->R[k * 3 + 1] * t1[1] + o->R[k * 3 + 2] * t1[2];
    if (ul > 0.5 && ul < 2.0) {
      for (int k = 0; k < 3; ++k) cu[k] /= ul;
      if (rollRad != 0.0) { double Rr[9], t[3]; weight::axis_angle(d1, rollRad, Rr); for (int k = 0; k < 3; ++k) t[k] = Rr[k * 3] * cu[0] + Rr[k * 3 + 1] * cu[1] + Rr[k * 3 + 2] * cu[2]; for (int k = 0; k < 3; ++k) cu[k] = t[k]; }
      double a = dot3(u0, d1), b = dot3(cu, d1);
      for (int k = 0; k < 3; ++k) { u0[k] -= a * d1[k]; cu[k] -= b * d1[k]; }
      double lu = vm::dsqrt(dot3(u0, u0)), lc = vm::dsqrt(dot3(cu, cu));
      if (lu > 0.3 && lc > 0.3) {   // controller not pointing along its own up (never happens) / the model has an up
        for (int k = 0; k < 3; ++k) { u0[k] /= lu; cu[k] /= lc; }
        double x[3] = {u0[1] * cu[2] - u0[2] * cu[1], u0[2] * cu[0] - u0[0] * cu[2], u0[0] * cu[1] - u0[1] * cu[0]};
        double th = vm::datan2(dot3(d1, x), dot3(u0, cu)), T[9];
        weight::axis_angle(d1, th, T);
        weight::mul3(T, o->R, o->R);
        o->rollDeg = (float)(th * 180.0 / vm::kPi);
        o->rolled = 1;
      }
    }
  }
  double v[3] = {(double)tipm[12] - W[12], (double)tipm[13] - W[13], (double)tipm[14] - W[14]};
  double vl = vm::dsqrt(dot3(v, v));
  if (!(vl > 0.02) || !(vl < 20.0)) return 0;
  for (int k = 0; k < 3; ++k) o->tip[k] = (float)(grip[k] + o->R[k * 3] * v[0] + o->R[k * 3 + 1] * v[1] + o->R[k * 3 + 2] * v[2]);
  double sh[3] = {(double)grip[0] - W[12], (double)grip[1] - W[13], (double)grip[2] - W[14]};
  o->shiftFt = (float)vm::dsqrt(dot3(sh, sh));
  o->turnDeg = (float)(ang * 180.0 / vm::kPi);
  o->gripToTipFt = (float)vl;
  for (int k = 0; k < 3; ++k) if (!vm::is_finite_f(o->tip[k])) return 0;
  return 1;
}

// out = the new world matrix (16 floats)
inline void apply_world(const float* W, const Solve& s, const float* grip, float* out) {
  for (int i = 0; i < 16; ++i) out[i] = W[i];
  for (int i = 0; i < 3; ++i) {   // each axis row: b' = R b
    double bv[3] = {W[i * 4], W[i * 4 + 1], W[i * 4 + 2]};
    for (int k = 0; k < 3; ++k) out[i * 4 + k] = (float)(s.R[k * 3] * bv[0] + s.R[k * 3 + 1] * bv[1] + s.R[k * 3 + 2] * bv[2]);
  }
  out[12] = grip[0]; out[13] = grip[1]; out[14] = grip[2];
}

}  // namespace wand
