// gbvr_watch.exe - 0.88 - an outside watcher for the game (a separate little program, not part of the DLL).
//
// Why it exists: since 0.85 the game ends by itself about when the hotel cutscene finishes and leaves no trace inside the
// probe (no exception, no exit call). A DLL inside the game cannot see a "fast fail" (the CPU instruction int 0x29 that the
// C runtime uses for abort / stack-cookie / invalid-argument failures) - Windows kills the process before any handler runs.
// A debugger can. This program attaches to the game as a debugger and only LOOKS: every event is answered so the game
// behaves as if nobody were there (breakpoints in the game are skipped, exceptions are passed on to the game's own
// handlers). If the watcher itself dies the game keeps running (DebugSetProcessKillOnExit(FALSE)).
//
// What it writes (gbvr_watch.log, next to the probe log):
//   - DLL loads and unloads (so Media Foundation / video decoders show up), thread starts and names
//   - everything the game prints with OutputDebugString (the game's own messages, e.g. "WinVideo: open() ...")
//   - C++ exceptions and other exceptions (the first ones, with where they came from)
//   - the fatal event: exception code, fast-fail code, where it happened, a stack scan, what every thread was doing,
//     and a small dump file (gbvr_crash.dmp, thread stacks only)
//   - the exit code of the game
//
// Usage: gbvr_watch.exe <pid> <log file path> [event name to signal once attached]
// Freestanding (kernel32 only), no C runtime.
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

// ---------------------------------------------------------------- tiny formatter (no C runtime)
static HANDLE g_log = INVALID_HANDLE_VALUE;
static char g_buf[2048];
static int g_n;
static ULONGLONG g_t0;

static void b_s(const char* s) { while (*s && g_n < (int)sizeof g_buf - 4) g_buf[g_n++] = *s++; }
static void b_c(char c) { if (g_n < (int)sizeof g_buf - 4) g_buf[g_n++] = c; }
static void b_hex(unsigned long long v, int digits) {
  char t[17]; int k = 0;
  do { t[k++] = "0123456789abcdef"[v & 15]; v >>= 4; } while (v);
  while (k < digits) t[k++] = '0';
  while (k) b_c(t[--k]);
}
static void b_dec(long long v) {
  char t[24]; int k = 0;
  if (v < 0) { b_c('-'); v = -v; }
  do { t[k++] = (char)('0' + (v % 10)); v /= 10; } while (v);
  while (k) b_c(t[--k]);
}
static void line_begin(void) {
  g_n = 0;
  b_c('['); b_dec((long long)(GetTickCount64() - g_t0)); b_s(" ms] ");
}
static void line_end(void) {
  b_c('\r'); b_c('\n');
  DWORD w;
  if (g_log != INVALID_HANDLE_VALUE) WriteFile(g_log, g_buf, (DWORD)g_n, &w, NULL);
  g_n = 0;
}
// a wide string (or a narrow one) with control characters flattened, at most 'max' characters
static void b_text_a(const char* s, int len, int max) {
  for (int i = 0; i < len && i < max; ++i) { unsigned char c = (unsigned char)s[i]; if (!c) break; b_c(c < 32 || c > 126 ? ' ' : (char)c); }
}
static void b_text_w(const WCHAR* s, int len, int max) {
  for (int i = 0; i < len && i < max; ++i) { WCHAR c = s[i]; if (!c) break; b_c(c < 32 || c > 126 ? ' ' : (char)c); }
}

// ---------------------------------------------------------------- state
typedef struct { ULONGLONG base; char name[40]; } Mod;
typedef struct { DWORD tid; HANDLE h; } Thr;
static Mod g_mod[600]; static int g_nmod;
static Thr g_thr[512]; static int g_nthr;
static HANDLE g_proc; static DWORD g_pid;
static DWORD g_mainTid;
static long g_strings, g_exc, g_cpp, g_breaks, g_guard, g_other, g_dllLoads, g_threads, g_threadExits;
typedef HRESULT (WINAPI *PFN_GetThreadDescription)(HANDLE, PWSTR*);
static PFN_GetThreadDescription g_getDesc;

static void mod_add(ULONGLONG base, HANDLE hFile) {
  if (g_nmod >= 600) return;
  WCHAR p[260]; DWORD n = hFile ? GetFinalPathNameByHandleW(hFile, p, 260, 0) : 0;
  Mod* m = &g_mod[g_nmod++];
  m->base = base; m->name[0] = 0;
  if (n && n < 260) {
    int s = (int)n; while (s > 0 && p[s - 1] != L'\\') --s;
    // 0.89: a file that is not under \Windows\ gets a '!' in front, so our own proxy d3d11.dll ("!d3d11.dll") is told apart from the system one
    int inWin = 0;
    for (int i = 0; i + 9 <= (int)n && !inWin; ++i) {
      static const char w[] = "\\windows\\"; int ok = 1;
      for (int j = 0; j < 9; ++j) { WCHAR c = p[i + j]; if (c >= L'A' && c <= L'Z') c = (WCHAR)(c + 32); if (c != (WCHAR)w[j]) { ok = 0; break; } }
      if (ok) inWin = 1;
    }
    int k = 0; if (!inWin && k < 39) m->name[k++] = '!';
    for (int i = s; i < (int)n && k < 39; ++i) m->name[k++] = p[i] < 128 ? (char)p[i] : '?';
    m->name[k] = 0;
  }
}
static const char* mod_name(ULONGLONG base) {
  for (int i = 0; i < g_nmod; ++i) if (g_mod[i].base == base) return g_mod[i].name[0] ? g_mod[i].name : "(module)";
  return 0;
}
// "name+0xoff" for an address inside a loaded image, else the plain address
static void b_addr(ULONGLONG a) {
  MEMORY_BASIC_INFORMATION mbi;
  if (VirtualQueryEx(g_proc, (LPCVOID)(ULONG_PTR)a, &mbi, sizeof mbi) == sizeof mbi && mbi.Type == MEM_IMAGE) {
    const char* nm = mod_name((ULONGLONG)(ULONG_PTR)mbi.AllocationBase);
    if (nm) { b_s(nm); b_s("+0x"); b_hex(a - (ULONGLONG)(ULONG_PTR)mbi.AllocationBase, 1); return; }
  }
  b_s("0x"); b_hex(a, 1);
}
static int is_code_ptr(ULONGLONG a) {
  if (a < 0x10000 || a >= 0x00007FFFFFFF0000ull) return 0;
  MEMORY_BASIC_INFORMATION mbi;
  if (VirtualQueryEx(g_proc, (LPCVOID)(ULONG_PTR)a, &mbi, sizeof mbi) != sizeof mbi) return 0;
  if (mbi.Type != MEM_IMAGE || mbi.State != MEM_COMMIT) return 0;
  return (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
}
static HANDLE thr_handle(DWORD tid) {
  for (int i = 0; i < g_nthr; ++i) if (g_thr[i].tid == tid) return g_thr[i].h;
  return NULL;
}
static void thr_drop(DWORD tid) {
  for (int i = 0; i < g_nthr; ++i) if (g_thr[i].tid == tid) { g_thr[i] = g_thr[--g_nthr]; return; }
}

// register summary + a scan of the stack for return addresses
static void report_thread(DWORD tid, const char* tag, int deep) {
  HANDLE h = thr_handle(tid);
  int own = 0;
  if (!h) { h = OpenThread(THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION, FALSE, tid); own = 1; }
  if (!h) { line_begin(); b_s(tag); b_s(" tid="); b_dec(tid); b_s(" (no handle)"); line_end(); return; }
  static CONTEXT ctx __attribute__((aligned(16)));
  ZeroMemory(&ctx, sizeof ctx);
  ctx.ContextFlags = CONTEXT_CONTROL | CONTEXT_INTEGER;
  if (!GetThreadContext(h, &ctx)) { line_begin(); b_s(tag); b_s(" tid="); b_dec(tid); b_s(" (context unavailable)"); line_end(); if (own) CloseHandle(h); return; }
  line_begin(); b_s(tag); b_s(" tid="); b_dec(tid);
  if (g_getDesc) {
    PWSTR d = NULL;
    if (SUCCEEDED(g_getDesc(h, &d)) && d) { if (d[0]) { b_s(" name="); b_text_w(d, 40, 40); } LocalFree(d); }
  }
  if (tid == g_mainTid) b_s(" (main)");
  b_s(" rip="); b_addr(ctx.Rip);
  if (deep) {
    b_s(" rsp=0x"); b_hex(ctx.Rsp, 1); b_s(" rcx=0x"); b_hex(ctx.Rcx, 1); b_s(" rdx=0x"); b_hex(ctx.Rdx, 1);
    b_s(" r8=0x"); b_hex(ctx.R8, 1); b_s(" r9=0x"); b_hex(ctx.R9, 1); b_s(" rax=0x"); b_hex(ctx.Rax, 1);
  }
  line_end();
  // return-address candidates in the stack
  unsigned long long buf[160];
  SIZE_T got = 0; int words = deep ? 160 : 64;
  if (ReadProcessMemory(g_proc, (LPCVOID)(ULONG_PTR)ctx.Rsp, buf, (SIZE_T)words * 8, &got) || got >= 64) {
    int found = 0, maxFound = deep ? 28 : 10;
    line_begin(); b_s("  stack"); b_s(" tid="); b_dec(tid); b_s(":");
    for (int i = 0; i < (int)(got / 8) && found < maxFound; ++i) {
      if (is_code_ptr(buf[i])) { b_s(" ["); b_dec(i * 8); b_s("]"); b_addr(buf[i]); ++found; if (g_n > 1700) { line_end(); line_begin(); b_s("  stack (more):"); } }
    }
    line_end();
  }
  if (own) CloseHandle(h);
}

static const char* fastfail_name(ULONG_PTR c) {
  switch (c) {
    case 0: return "LEGACY_GS_VIOLATION"; case 1: return "VTGUARD_CHECK_FAILURE"; case 2: return "STACK_COOKIE_CHECK_FAILURE";
    case 3: return "CORRUPT_LIST_ENTRY"; case 4: return "INCORRECT_STACK"; case 5: return "INVALID_ARG (invalid parameter handler)";
    case 6: return "GS_COOKIE_INIT"; case 7: return "FATAL_APP_EXIT (abort / terminate)"; case 8: return "RANGE_CHECK_FAILURE";
    case 9: return "UNSAFE_REGISTRY_ACCESS"; case 10: return "GUARD_ICALL_CHECK_FAILURE"; case 11: return "GUARD_WRITE_CHECK_FAILURE";
    case 12: return "INVALID_FIBER_SWITCH"; case 13: return "INVALID_SET_OF_CONTEXT"; case 14: return "INVALID_REFERENCE_COUNT";
    case 18: return "INVALID_JUMP_BUFFER"; case 19: return "MRDATA_PROTECTION_FAILURE"; case 20: return "UNEXPECTED_HEAP_EXCEPTION?";
    case 21: return "INVALID_LOCK_STATE"; case 22: return "INVALID_LONGJUMP_TARGET"; case 23: return "INVALID_DISPATCH_CONTEXT";
    case 24: return "INVALID_THREAD"; case 25: return "INVALID_SYSCALL"; case 26: return "INVALID_FILE_OPERATION";
    case 27: return "LPAC_ACCESS_DENIED"; case 28: return "GUARD_SS_FAILURE"; case 29: return "LOADER_CONTINUITY_FAILURE";
    case 30: return "GUARD_EXPORT_SUPPRESSION_FAILURE"; case 31: return "INVALID_CONTROL_STACK"; case 32: return "SET_CONTEXT_DENIED";
    case 33: return "INVALID_IAT"; case 34: return "HEAP_METADATA_CORRUPTION"; case 35: return "PAYLOAD_RESTRICTION_VIOLATION";
    default: return "(see Microsoft FAST_FAIL_ list)";
  }
}

// small dump of the process (thread stacks and module list)
typedef BOOL (WINAPI *PFN_MiniDumpWriteDump)(HANDLE, DWORD, HANDLE, int, void*, void*, void*);
static void write_dump(WCHAR* logPath) {
  HMODULE dh = LoadLibraryW(L"dbghelp.dll");
  PFN_MiniDumpWriteDump fn = dh ? (PFN_MiniDumpWriteDump)GetProcAddress(dh, "MiniDumpWriteDump") : NULL;
  if (!fn) { line_begin(); b_s("DUMP dbghelp.dll not usable"); line_end(); return; }
  WCHAR p[400]; int n = 0;
  while (logPath[n] && n < 380) { p[n] = logPath[n]; ++n; }
  while (n > 0 && p[n - 1] != L'\\') --n;
  const WCHAR* nm = L"gbvr_crash.dmp"; for (int i = 0; nm[i]; ++i) p[n++] = nm[i];
  p[n] = 0;
  HANDLE f = CreateFileW(p, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  if (f == INVALID_HANDLE_VALUE) { line_begin(); b_s("DUMP could not create the file"); line_end(); return; }
  // MiniDumpNormal (0) | MiniDumpWithThreadInfo (0x1000) | MiniDumpWithUnloadedModules (0x20)
  BOOL ok = fn(g_proc, g_pid, f, 0x1020, NULL, NULL, NULL);
  DWORD sz = GetFileSize(f, NULL);
  CloseHandle(f);
  line_begin(); b_s("DUMP gbvr_crash.dmp written ok="); b_dec(ok); b_s(" bytes="); b_dec(sz); line_end();
}

static void report_fatal(const EXCEPTION_RECORD* er, DWORD tid, WCHAR* logPath, int second) {
  line_begin(); b_s("FATAL ");
  b_s(second ? "second-chance" : "first-chance"); b_s(" exception code=0x"); b_hex(er->ExceptionCode, 8);
  b_s(" at "); b_addr((ULONGLONG)(ULONG_PTR)er->ExceptionAddress); b_s(" tid="); b_dec(tid);
  b_s(" flags=0x"); b_hex(er->ExceptionFlags, 1); b_s(" params="); b_dec(er->NumberParameters);
  for (DWORD i = 0; i < er->NumberParameters && i < 4; ++i) { b_s(" p"); b_dec(i); b_s("=0x"); b_hex(er->ExceptionInformation[i], 1); }
  line_end();
  if (er->ExceptionCode == 0xC0000409 && er->NumberParameters >= 1) {
    line_begin(); b_s("FATAL fast-fail code "); b_dec((long long)er->ExceptionInformation[0]); b_s(" = "); b_s(fastfail_name(er->ExceptionInformation[0]));
    b_s(" (the game or its C runtime ended itself on purpose)"); line_end();
  } else if (er->ExceptionCode == 0xC0000005 && er->NumberParameters >= 2) {
    line_begin(); b_s("FATAL access violation: "); b_s(er->ExceptionInformation[0] == 0 ? "read of 0x" : er->ExceptionInformation[0] == 1 ? "write to 0x" : "execute at 0x");
    b_hex(er->ExceptionInformation[1], 1); line_end();
  } else if (er->ExceptionCode == 0xE06D7363) {
    line_begin(); b_s("FATAL C++ exception thrown and not caught (std::terminate follows)"); line_end();
  }
  report_thread(tid, "FATAL thread", 1);
  for (int i = 0; i < g_nthr; ++i) if (g_thr[i].tid != tid) report_thread(g_thr[i].tid, "  other", 0);
  write_dump(logPath);
}

// ---------------------------------------------------------------- debug strings
static void on_string(const OUTPUT_DEBUG_STRING_INFO* o, DWORD tid) {
  ++g_strings;
  if (g_strings > 4000) { if (g_strings == 4001) { line_begin(); b_s("DBGSTR (4000 lines logged; the rest is only counted)"); line_end(); } return; }
  char tmp[600]; SIZE_T got = 0;
  int len = o->nDebugStringLength; if (len > 300) len = 300;
  if (len <= 0) return;
  int bytes = o->fUnicode ? len * 2 : len;
  if (bytes > (int)sizeof tmp) bytes = (int)sizeof tmp;
  if (!ReadProcessMemory(g_proc, o->lpDebugStringData, tmp, (SIZE_T)bytes, &got) || got == 0) return;
  line_begin(); b_s("DBGSTR tid="); b_dec(tid); b_s(": ");
  if (o->fUnicode) b_text_w((const WCHAR*)tmp, (int)(got / 2), 300); else b_text_a(tmp, (int)got, 300);
  line_end();
}

// ---------------------------------------------------------------- main loop
static int parse_args(WCHAR* cl, DWORD* pid, WCHAR* path, int pathMax, WCHAR* evName, int evMax) {
  // skip program name
  WCHAR* p = cl;
  if (*p == L'"') { ++p; while (*p && *p != L'"') ++p; if (*p) ++p; } else { while (*p && *p != L' ') ++p; }
  while (*p == L' ') ++p;
  DWORD v = 0; int digits = 0;
  while (*p >= L'0' && *p <= L'9') { v = v * 10 + (DWORD)(*p - L'0'); ++p; ++digits; }
  if (!digits) return 0;
  *pid = v;
  while (*p == L' ') ++p;
  int k = 0;
  if (*p == L'"') { ++p; while (*p && *p != L'"' && k < pathMax - 1) path[k++] = *p++; if (*p == L'"') ++p; }
  else { while (*p && *p != L' ' && k < pathMax - 1) path[k++] = *p++; }
  path[k] = 0;
  while (*p == L' ') ++p;
  k = 0; while (*p && *p != L' ' && k < evMax - 1) evName[k++] = *p++;
  evName[k] = 0;
  return k >= 0 && path[0];
}

void __stdcall start(void) {
  WCHAR path[400], evName[100]; DWORD pid = 0;
  g_t0 = GetTickCount64();
  if (!parse_args(GetCommandLineW(), &pid, path, 400, evName, 100)) ExitProcess(2);
  g_log = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  g_pid = pid;
  HMODULE kb = GetModuleHandleW(L"kernelbase.dll");
  g_getDesc = kb ? (PFN_GetThreadDescription)GetProcAddress(kb, "GetThreadDescription") : NULL;
  line_begin(); b_s("WATCH gbvr_watch 0.88 starting for pid "); b_dec(pid); line_end();
  if (!DebugActiveProcess(pid)) {
    line_begin(); b_s("WATCH DebugActiveProcess failed, error "); b_dec(GetLastError()); b_s(" (another debugger attached, or no permission). The game runs on without the watcher."); line_end();
    ExitProcess(3);
  }
  DebugSetProcessKillOnExit(FALSE);
  if (evName[0]) { HANDLE ev = OpenEventW(EVENT_MODIFY_STATE, FALSE, evName); if (ev) { SetEvent(ev); CloseHandle(ev); } }
  line_begin(); b_s("WATCH attached; only looking, every event is passed on unchanged"); line_end();

  int sawInitialBreak = 0, running = 1, detach = 0;
  ULONGLONG t0 = GetTickCount64();
  struct { DWORD code; ULONGLONG addr; } seen[120]; int nseen = 0;
  while (running) {
    DEBUG_EVENT ev;
    if (!WaitForDebugEvent(&ev, INFINITE)) { line_begin(); b_s("WATCH WaitForDebugEvent failed, error "); b_dec(GetLastError()); line_end(); break; }
    DWORD status = DBG_EXCEPTION_NOT_HANDLED;
    switch (ev.dwDebugEventCode) {
      case CREATE_PROCESS_DEBUG_EVENT: {
        g_proc = ev.u.CreateProcessInfo.hProcess;
        g_mainTid = ev.dwThreadId;
        mod_add((ULONGLONG)(ULONG_PTR)ev.u.CreateProcessInfo.lpBaseOfImage, ev.u.CreateProcessInfo.hFile);
        if (ev.u.CreateProcessInfo.hFile) CloseHandle(ev.u.CreateProcessInfo.hFile);
        if (g_nthr < 512) { g_thr[g_nthr].tid = ev.dwThreadId; g_thr[g_nthr].h = ev.u.CreateProcessInfo.hThread; ++g_nthr; }
        line_begin(); b_s("WATCH process image base=0x"); b_hex((ULONGLONG)(ULONG_PTR)ev.u.CreateProcessInfo.lpBaseOfImage, 1); b_s(" first thread tid="); b_dec(ev.dwThreadId); line_end();
        status = DBG_CONTINUE; break;
      }
      case CREATE_THREAD_DEBUG_EVENT: {
        ++g_threads;
        if (g_nthr < 512) { g_thr[g_nthr].tid = ev.dwThreadId; g_thr[g_nthr].h = ev.u.CreateThread.hThread; ++g_nthr; }
        status = DBG_CONTINUE; break;
      }
      case EXIT_THREAD_DEBUG_EVENT: {
        ++g_threadExits; thr_drop(ev.dwThreadId);
        status = DBG_CONTINUE; break;
      }
      case LOAD_DLL_DEBUG_EVENT: {
        ++g_dllLoads;
        mod_add((ULONGLONG)(ULONG_PTR)ev.u.LoadDll.lpBaseOfDll, ev.u.LoadDll.hFile);
        if (g_dllLoads <= 700) {
          line_begin(); b_s("DLL load "); b_s(g_nmod ? g_mod[g_nmod - 1].name : "?"); b_s(" base=0x"); b_hex((ULONGLONG)(ULONG_PTR)ev.u.LoadDll.lpBaseOfDll, 1); line_end();
        }
        if (ev.u.LoadDll.hFile) CloseHandle(ev.u.LoadDll.hFile);
        status = DBG_CONTINUE; break;
      }
      case UNLOAD_DLL_DEBUG_EVENT: {
        const char* nm = mod_name((ULONGLONG)(ULONG_PTR)ev.u.UnloadDll.lpBaseOfDll);
        line_begin(); b_s("DLL unload "); b_s(nm ? nm : "?"); b_s(" base=0x"); b_hex((ULONGLONG)(ULONG_PTR)ev.u.UnloadDll.lpBaseOfDll, 1); line_end();
        status = DBG_CONTINUE; break;
      }
      case OUTPUT_DEBUG_STRING_EVENT:
        on_string(&ev.u.DebugString, ev.dwThreadId);
        status = DBG_CONTINUE; break;
      case RIP_EVENT:
        status = DBG_CONTINUE; break;
      case EXCEPTION_DEBUG_EVENT: {
        const EXCEPTION_RECORD* er = &ev.u.Exception.ExceptionRecord;
        DWORD code = er->ExceptionCode;
        int first = ev.u.Exception.dwFirstChance != 0;
        ++g_exc;
        if (code == EXCEPTION_BREAKPOINT || code == 0x4000001F /*WX86 breakpoint*/) {
          if (!sawInitialBreak) { sawInitialBreak = 1; status = DBG_CONTINUE; break; }
          ++g_breaks;
          if (g_breaks <= 20) { line_begin(); b_s("BREAKPOINT (int 3) in the game at "); b_addr((ULONGLONG)(ULONG_PTR)er->ExceptionAddress); b_s(" tid="); b_dec(ev.dwThreadId); b_s(" - skipped, as if no debugger were attached"); line_end(); }
          status = DBG_CONTINUE; break;
        }
        if (code == 0x406D1388) { status = DBG_CONTINUE; break; }   // thread name announcement
        if ((code == 0x40010006 || code == 0x4001000A) && er->NumberParameters >= 2) {   // OutputDebugString as an exception
          OUTPUT_DEBUG_STRING_INFO o; o.lpDebugStringData = (PSTR)(ULONG_PTR)er->ExceptionInformation[1];
          o.fUnicode = code == 0x4001000A; o.nDebugStringLength = (WORD)er->ExceptionInformation[0];
          on_string(&o, ev.dwThreadId);
          status = DBG_CONTINUE; break;
        }
        if (code == 0x80000001 || code == 0x80000004) { ++g_guard; break; }   // page guard / single step (the probe's own watch): not logged
        if (code == 0xE06D7363) {
          ++g_cpp;
          if (g_cpp <= 25) {
            line_begin(); b_s("C++ exception #"); b_dec(g_cpp); b_s(first ? " thrown at " : " (second chance) at "); b_addr((ULONGLONG)(ULONG_PTR)er->ExceptionAddress);
            b_s(" tid="); b_dec(ev.dwThreadId); b_s(" object=0x"); if (er->NumberParameters >= 2) b_hex(er->ExceptionInformation[1], 1); line_end();
            report_thread(ev.dwThreadId, "  thrower", 0);
          }
          if (first) break;   // pass on
        }
        if (!first || code == 0xC0000409 || code == 0xC0000374) {
          // the end: log everything we know while the game is frozen at this event
          report_fatal(er, ev.dwThreadId, path, !first);
          break;
        }
        // other first-chance exceptions: log each new (code, address) once, up to a cap
        {
          int dup = 0; for (int i = 0; i < nseen; ++i) if (seen[i].code == code && seen[i].addr == (ULONGLONG)(ULONG_PTR)er->ExceptionAddress) { dup = 1; break; }
          ++g_other;
          if (!dup && nseen < 120) {
            seen[nseen].code = code; seen[nseen].addr = (ULONGLONG)(ULONG_PTR)er->ExceptionAddress; ++nseen;
            line_begin(); b_s("EXCEPTION first-chance code=0x"); b_hex(code, 8); b_s(" at "); b_addr((ULONGLONG)(ULONG_PTR)er->ExceptionAddress); b_s(" tid="); b_dec(ev.dwThreadId);
            if (code == 0xC0000005 && er->NumberParameters >= 2) { b_s(er->ExceptionInformation[0] == 0 ? " read of 0x" : er->ExceptionInformation[0] == 1 ? " write to 0x" : " execute at 0x"); b_hex(er->ExceptionInformation[1], 1); }
            line_end();
            report_thread(ev.dwThreadId, "  at", 0);
          }
        }
        break;
      }
      case EXIT_PROCESS_DEBUG_EVENT: {
        line_begin(); b_s("EXIT the game ended, exit code 0x"); b_hex(ev.u.ExitProcess.dwExitCode, 8);
        b_s(" after "); b_dec((long long)((GetTickCount64() - t0) / 1000)); b_s(" s of watching"); line_end();
        line_begin(); b_s("EXIT totals: debug strings="); b_dec(g_strings); b_s(" exceptions="); b_dec(g_exc); b_s(" c++="); b_dec(g_cpp); b_s(" other-first-chance="); b_dec(g_other);
        b_s(" breakpoints="); b_dec(g_breaks); b_s(" guard/step="); b_dec(g_guard); b_s(" dll-loads="); b_dec(g_dllLoads); b_s(" threads-started="); b_dec(g_threads); b_s(" threads-ended="); b_dec(g_threadExits); line_end();
        running = 0; status = DBG_CONTINUE; break;
      }
      default: break;
    }
    ContinueDebugEvent(ev.dwProcessId, ev.dwThreadId, status);
    // never slow the game down for long: leave if the game spams events
    if (running && (g_strings > 60000 || g_exc > 400000)) {
      line_begin(); b_s("WATCH too many events (strings="); b_dec(g_strings); b_s(" exceptions="); b_dec(g_exc); b_s("); letting go of the game so it runs at full speed"); line_end();
      detach = 1; break;
    }
  }
  if (detach) DebugActiveProcessStop(pid);
  line_begin(); b_s("WATCH done"); line_end();
  ExitProcess(0);
}
