// 0.51 gun weight. Pure math, no Windows dependency; unit-tested in tests/test_weight.cpp.
//
// The wand (and with it the proton stream) does not follow the controller's rotation instantly.
// It is a heavy object: its orientation is pulled toward the controller's orientation by a
// spring with damping, so a quick flick of the wrist makes the wand lag, overshoot a little and
// settle. Held in ONE hand it is soft and slow, droops (gets heavier the longer it is held up),
// trembles slightly and, while firing, climbs and shakes. Held in TWO hands (off-hand on the
// wand) the spring is much stiffer, nearly nothing droops or trembles and the recoil is small.
// The pose position is never touched, only the rotation (about the hand).
//
// Rotations are 3x3 row-major, columns = the pose's axes in tracking space (OpenVR: the
// pointing direction is the NEGATIVE z column; y is up in the world).
#pragma once
#include "vmath.h"

namespace weight {

struct Params {
  double heaviness;   // 0 = off (output = input), 1 = default, 2 = very heavy
  double twistLock = 0.0;   // 0.94: 0..1 how much of the hand's twist about the barrel the gun takes at once (the aim itself keeps its weight)
  double punish = 1.0;      // 0.95: how hard firing ONE-handed is: 0 = the 0.94 feel, 1 = default (more climb, shake, kick, slower to follow), 2 = brutal
  double omegaOne = 0.0;    // 0.95: > 0 replaces the one-handed spring frequency (rad/s); the two-handed one is 1.7x that (used by the PKE)
  double zetaOne = 0.0;     // 0.95: > 0 replaces the one-handed damping (less than 1 = a little give / overshoot)
  double lagCapDeg = 0.0;   // 0.95: > 0 replaces the one-handed lag limit (degrees; two hands: 2/3 of it)
  double looseOne = 0.0;    // 1.7.177: 1 = the one-handed gun is loose even when NOT firing (slower, more give, more sway, a bigger lag limit; scaled by punish). Two hands stay firm. No kick or climb: firing moves nothing.
};

struct Out {
  double lagDeg;      // angle between the controller's rotation and the wand's rotation
  double twoBlend;    // 0 one hand ... 1 two hands (smoothed)
  double fatigue;     // 0..1
  double droopDeg, swayDeg, recoilDeg;
  double strain;      // 0.95
};

struct State {
  double R[9];        // current (filtered) rotation
  double w[3];        // angular velocity, rad/s (tracking space)
  double two;         // smoothed two-hand blend
  double fatigue;
  double t;           // seconds since start (sway phase)
  double fire;        // 0..1 how long the trigger has been held (recoil build-up)
  double stiff;       // 0.68 0..1 the aim firms up fast (0.12 s) once the trigger is down, relaxes in 0.5 s
  double kick;        // 0.74 1 -> 0 over 0.22 s after the trigger goes down: the one-handed snap upward
  double strain;      // 0.95 0..1 grows while firing ONE-handed (full after 3.5 s), eases off in 2 s: the longer the burst, the more the arm gives
  int firePrev;
  int have;
  void reset() { have = 0; two = 0; fatigue = 0; t = 0; fire = 0; stiff = 0; kick = 0; strain = 0; firePrev = 0; w[0] = w[1] = w[2] = 0; }
};

inline void ident(double* r) { for (int i = 0; i < 9; ++i) r[i] = (i % 4 == 0) ? 1.0 : 0.0; }
inline void mul3(const double* a, const double* b, double* o) {
  double t[9];
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 3; ++c) t[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c];
  for (int i = 0; i < 9; ++i) o[i] = t[i];
}
inline void transpose3(const double* a, double* o) {
  double t[9];
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) t[c * 3 + r] = a[r * 3 + c];
  for (int i = 0; i < 9; ++i) o[i] = t[i];
}
// Gram-Schmidt on the columns
inline void orthonormalize(double* m) {
  double c0[3] = {m[0], m[3], m[6]}, c1[3] = {m[1], m[4], m[7]};
  double l = vm::dsqrt(c0[0] * c0[0] + c0[1] * c0[1] + c0[2] * c0[2]);
  if (!(l > 1e-9)) { ident(m); return; }
  for (int i = 0; i < 3; ++i) c0[i] /= l;
  double d = c0[0] * c1[0] + c0[1] * c1[1] + c0[2] * c1[2];
  for (int i = 0; i < 3; ++i) c1[i] -= d * c0[i];
  l = vm::dsqrt(c1[0] * c1[0] + c1[1] * c1[1] + c1[2] * c1[2]);
  if (!(l > 1e-9)) { ident(m); return; }
  for (int i = 0; i < 3; ++i) c1[i] /= l;
  double c2[3] = {c0[1] * c1[2] - c0[2] * c1[1], c0[2] * c1[0] - c0[0] * c1[2], c0[0] * c1[1] - c0[1] * c1[0]};
  for (int i = 0; i < 3; ++i) { m[i * 3] = c0[i]; m[i * 3 + 1] = c1[i]; m[i * 3 + 2] = c2[i]; }
}
// rotation about a unit axis by angle (radians), Rodrigues
inline void axis_angle(const double* ax, double a, double* o) {
  double s, c; vm::dsincos(a, &s, &c);
  double x = ax[0], y = ax[1], z = ax[2], t = 1 - c;
  o[0] = c + x * x * t;     o[1] = x * y * t - z * s; o[2] = x * z * t + y * s;
  o[3] = y * x * t + z * s; o[4] = c + y * y * t;     o[5] = y * z * t - x * s;
  o[6] = z * x * t - y * s; o[7] = z * y * t + x * s; o[8] = c + z * z * t;
}
// rotation vector (axis * angle) of a rotation matrix
inline void rot_vector(const double* e, double* v) {
  double sx = (e[7] - e[5]) * 0.5, sy = (e[2] - e[6]) * 0.5, sz = (e[3] - e[1]) * 0.5;
  double sn = vm::dsqrt(sx * sx + sy * sy + sz * sz);
  double cs = (e[0] + e[4] + e[8] - 1.0) * 0.5;
  if (!(sn > 1e-12)) { v[0] = v[1] = v[2] = 0; return; }
  double a = vm::datan2(sn, cs);
  double k = a / sn;
  v[0] = sx * k; v[1] = sy * k; v[2] = sz * k;
}
inline double angle_between(const double* a, const double* b) {   // degrees between two rotations
  double ta[9], e[9], v[3];
  transpose3(a, ta);
  mul3(b, ta, e);
  rot_vector(e, v);
  return vm::dsqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) * 180.0 / vm::kPi;
}
inline void forward_of(const double* r, double* f) { f[0] = -r[2]; f[1] = -r[5]; f[2] = -r[8]; }

// ---- parameters -------------------------------------------------------------------
struct Tune {
  double omega1, zeta1, omega2, zeta2;        // spring: natural frequency (rad/s) and damping
  double droop1, droop2, droopFat;            // degrees the wand sags (one hand, two hands, extra at full fatigue)
  double sway1, sway2, swayFat;               // degrees of tremor
  double recoil1, recoil2;                    // degrees of climb/shake while firing
};
inline Tune tune_for(double h) {
  Tune t;
  double k = h < 0 ? 0 : (h > 3 ? 3 : h);
  // 0.68 lighter: the 0.58-0.67 numbers (5 rad/s, up to 50 degrees behind, 7 degrees of droop) made the gun trail the hand by ~23 degrees on average:
  // venting was awkward and the stream went where the hand HAD pointed. Now 1.5 (default) -> 17 rad/s (about 0.2 s to follow a flick), a few degrees of droop;
  // once the trigger is down the aim firms up (see step).
  // 0.94: stiffer again. The 0.93 log (heaviness 150): the gun trailed the hand by 6.7 degrees on average and up to 36 degrees one-handed; turning the wrist felt like the gun came after it.
  // 40 rad/s at heaviness 1 (0.93 at 150 %: 27): about 45 ms behind a steady turn; the twist about the barrel is locked to the hand separately (twistLock). (0.72-0.93: 42 / (1 + 0.35 k))
  t.omega1 = 52.0 / (1.0 + 0.30 * k);  t.zeta1 = 0.90;   // 0.72: idle one-handed follows closely (the 0.70 log: gun 9 degrees / 1.6 cm behind the hand on average); firing one-handed is made heavy separately (oneFire)
  t.omega2 = 90.0 / (1.0 + 0.35 * k);  t.zeta2 = 0.95;   // 0.94 (was 70 / (1 + 0.5 k))    // 1.0: 47 rad/s: about 25 ms, firm
  t.droop1 = 1.0 * k;  t.droop2 = 0.35 * k;  t.droopFat = 1.0 * k;   // 1.6: fatigue sag 2.2 -> 1.0 (the gun drooped away from the hand after a while)
  t.sway1 = 0.35 * k;  t.sway2 = 0.08 * k;   t.swayFat = 0.3 * k;   // 1.6: 0.7 -> 0.3
  t.recoil1 = 0.8 * k; t.recoil2 = 0.2 * k;
  return t;
}

// 1.7.155 what the gun's weight is while the hand is locked to the controller (hand_lock, always on since 1.7.58).
// History: up to 1.7.117 a one-handed shot kept its weight and punishment here; a later clean-up zeroed everything ("the gun feels weightless and
// boring", "one hand firing punishment is gone"). Back, and the resting gun has its weight again too - as ROTATION only: the grip never leaves the
// controller (the position lag stays off), the virtual hand turns with the gun, so nothing floats out of the hand.
//   gun, any time: heaviness from gun_heft_pct, the twist about the barrel locked to the hand, the one-handed punishment from gun_punish_pct
//   PKE: rigid (it has its own lock)
// *raisedOut: the "held up" flag for the fatigue sag - only while firing, so a gun merely carried never sags over time.
inline Params locked_params(double heftPct, double punishPct, int pkeOut, int firing, int raised, int* raisedOut) {
  Params p = {0.0, 1.0};
  p.punish = 0.0;
  if (raisedOut) *raisedOut = 0;
  if (pkeOut) return p;
  double h = heftPct / 100.0; if (!(h > 0.0)) h = 0.0; if (h > 3.0) h = 3.0;
  p.heaviness = h;
  p.twistLock = 1.0;
  p.punish = punishPct / 100.0; if (!(p.punish > 0.0)) p.punish = 0.0;
  if (raisedOut) *raisedOut = firing && raised;
  return p;
}
inline double sinx(double t, double hz, double ph) { double s, c; vm::dsincos(2.0 * vm::kPi * hz * t + ph, &s, &c); return s; }
inline double lerp(double a, double b, double t) { return a + (b - a) * t; }
inline double clamp01(double x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }

// One step. target: the controller's rotation (tracking space). twoHand: the off-hand is on the wand.
// firing: the trigger is down. raised: the wand is held up (not hanging at the side). out: filtered rotation.
// Returns 1 when the output differs from the input (weight on).
inline int step(State* s, const Params& p, const double* target, double dt, int twoHand, int firing, int raised, double* out, Out* info) {
  if (!(dt > 0)) dt = 0; else if (dt > 0.25) dt = 0.25;
  if (p.heaviness <= 0.001) {
    for (int i = 0; i < 9; ++i) out[i] = target[i];
    for (int i = 0; i < 9; ++i) s->R[i] = target[i];
    s->have = 1; s->w[0] = s->w[1] = s->w[2] = 0;
    if (info) { info->lagDeg = 0; info->twoBlend = s->two; info->fatigue = 0; info->droopDeg = info->swayDeg = info->recoilDeg = 0; info->strain = 0; }
    return 0;
  }
  if (!s->have) { for (int i = 0; i < 9; ++i) s->R[i] = target[i]; s->have = 1; s->w[0] = s->w[1] = s->w[2] = 0; }
  const Tune t = tune_for(p.heaviness);
  // blends
  double goal = twoHand ? 1.0 : 0.0;
  double rate = twoHand ? 9.0 : 6.0;   // the off-hand takes hold quickly, lets go a bit slower
  s->two += (goal - s->two) * clamp01(rate * dt);
  // fatigue: grows while the wand is held up with one hand, recovers otherwise
  if (raised && !twoHand) s->fatigue += dt / 30.0;   // 1.6: 12 s -> 30 s to tire else s->fatigue -= dt * (twoHand ? 0.35 : 0.5);
  s->fatigue = clamp01(s->fatigue);
  if (firing) s->fire += dt / 0.45; else s->fire -= dt / 0.25;
  s->fire = clamp01(s->fire);
  if (firing) s->stiff += dt / 0.12; else s->stiff -= dt / 0.5;
  s->stiff = clamp01(s->stiff);
  if (firing && !s->firePrev) s->kick = 1.0;   // 0.74: the trigger just went down
  s->firePrev = firing ? 1 : 0;
  s->kick -= dt / 0.22; if (s->kick < 0) s->kick = 0;
  s->t += dt;
  const double two = s->two, one = 1.0 - two;
  // 0.68: while the trigger is held with one hand the aim firms up within ~0.12 s (about 2.3x the spring frequency), so the stream goes where
  // the controller points instead of trailing it; idle it is light but still has some give
  // 0.70 (the player's observation of the game): firing ONE-handed makes the wand heavier and shakier - slower to follow, more sway and more climb - while
  // merely holding it with one hand stays light, and two hands stay firm. `oneFire` is 0 idle / two-handed, 1 firing one-handed.
  const double oneFire = s->stiff * one;
  // 0.95 more punishing one-handed (the player: "make the gun more punishing one-handed"). `pn` 0 is the 0.94 feel, 1 (default) is harder, 2 is brutal.
  // The idle gun still follows the hand closely (0.94); only a shot fired with ONE hand gets slow, shaky, climbs and kicks - and the longer the burst, the worse
  // (strain). Two hands are untouched: that is the reason to use them.
  const double pn = p.punish < 0 ? 0 : (p.punish > 2 ? 2 : p.punish);
  if (firing && one > 0.5) s->strain += dt / 3.5; else s->strain -= dt / 2.0;
  s->strain = clamp01(s->strain);
  const double strainK = 1.0 + 0.5 * pn * s->strain * one;   // up to +50 % shake and climb after a long one-handed burst (at the default)
  double slow = 0.38 + 0.15 * pn; if (slow > 0.75) slow = 0.75;
  double zetaDrop = 0.18 + 0.08 * pn; if (zetaDrop > 0.42) zetaDrop = 0.42;
  const double om1 = p.omegaOne > 0.0 ? p.omegaOne : t.omega1, om2 = p.omegaOne > 0.0 ? p.omegaOne * 1.7 : t.omega2;
  const double ze1 = p.zetaOne > 0.0 ? p.zetaOne : t.zeta1, ze2 = p.zetaOne > 0.0 ? p.zetaOne + 0.05 : t.zeta2;
  const double looseK = p.looseOne > 0.0 ? pn * one : 0.0;   // 1.7.177: the one-handed cost that does not depend on the trigger
  const double omega = lerp(om1, om2, two) * (1.0 - slow * oneFire) * (1.0 - 0.30 * looseK), zeta = lerp(ze1, ze2, two) - zetaDrop * oneFire - 0.10 * looseK;   // 0.74: slower and wobblier; 0.95: more so
  const double droop = (lerp(t.droop1, t.droop2, two) + t.droopFat * s->fatigue * one) * (raised ? 1.0 : 0.3);
  const double swayA = (lerp(t.sway1 + t.swayFat * s->fatigue, t.sway2, two) + (2.4 + 1.2 * pn) * (t.sway1 / (0.35 > 1e-9 ? 0.35 : 1.0)) * oneFire + 1.2 * (t.sway1 / 0.35) * looseK) * strainK;   // 0.74: + about 2.4 degrees x heaviness while firing one-handed; 0.95: 3.6 (+ up to 50 % more in a long burst)
  const double recoilA = lerp(t.recoil1, t.recoil2, two) * s->fire * (1.0 + (3.0 + 1.4 * pn) * oneFire) * strainK;   // 0.74: one-handed climb and shake 4x; 0.95: 5.4x

  // target with droop: lower the pointing direction about the horizontal axis (perpendicular to forward)
  double f[3]; forward_of(target, f);
  double up[3] = {0, 1, 0};
  double rt[3] = {f[1] * up[2] - f[2] * up[1], f[2] * up[0] - f[0] * up[2], f[0] * up[1] - f[1] * up[0]};   // forward x up = right
  double rl = vm::dsqrt(rt[0] * rt[0] + rt[1] * rt[1] + rt[2] * rt[2]);
  double tg[9];
  for (int i = 0; i < 9; ++i) tg[i] = target[i];
  double Rd[9];
  if (rl > 0.2) {   // not pointing nearly straight up/down
    for (int i = 0; i < 3; ++i) rt[i] /= rl;
    axis_angle(rt, -droop * vm::kPi / 180.0, Rd);   // right-handed about "right": negative = forward tips down
    mul3(Rd, target, tg);
  }
  // spring-damper on the rotation, sub-stepped
  double remaining = dt;
  while (remaining > 1e-6) {
    double h = remaining > 0.005 ? 0.005 : remaining;
    remaining -= h;
    double tr[9], e[9], th[3];
    transpose3(s->R, tr);
    mul3(tg, tr, e);
    rot_vector(e, th);
    for (int i = 0; i < 3; ++i) s->w[i] += (omega * omega * th[i] - 2.0 * zeta * omega * s->w[i]) * h;
    double wl = vm::dsqrt(s->w[0] * s->w[0] + s->w[1] * s->w[1] + s->w[2] * s->w[2]);
    if (wl > 1e-9) {
      double ax[3] = {s->w[0] / wl, s->w[1] / wl, s->w[2] / wl}, d[9];
      axis_angle(ax, wl * h, d);
      mul3(d, s->R, s->R);
    }
    orthonormalize(s->R);
  }
  // tremor + recoil are added after the spring
  double sw = vm::kPi / 180.0 * swayA;
  double yawOff = sw * (0.55 * sinx(s->t, 0.9, 0.0) + 0.30 * sinx(s->t, 1.7, 1.3) + 0.15 * sinx(s->t, 3.1, 2.1));
  double pitchOff = sw * (0.55 * sinx(s->t, 0.7, 0.4) + 0.30 * sinx(s->t, 1.3, 2.2) + 0.15 * sinx(s->t, 2.6, 0.9));
  double rc = vm::kPi / 180.0 * recoilA;
  pitchOff += rc * (0.55 + 0.30 * sinx(s->t, 17.0, 0.0) + 0.15 * sinx(s->t, 23.0, 1.0));   // climbs and shakes
  // 0.74 the one-handed snap: the trigger kicks the muzzle up about 3 degrees (at the default weight) and it settles back over a fifth of a second
  pitchOff += vm::kPi / 180.0 * ((2.0 + 2.0 * pn) * (p.heaviness > 3 ? 3.0 : p.heaviness)) * one * s->kick;   // 0.95: 4 degrees at the default weight (0.74: 2)
  yawOff += rc * (0.30 * sinx(s->t, 13.0, 0.5) + 0.15 * sinx(s->t, 19.0, 2.0));
  double Ro[9];
  for (int i = 0; i < 9; ++i) Ro[i] = s->R[i];
  double fo[3]; forward_of(s->R, fo);
  double ro[3] = {fo[1] * up[2] - fo[2] * up[1], fo[2] * up[0] - fo[0] * up[2], fo[0] * up[1] - fo[1] * up[0]};
  double rol = vm::dsqrt(ro[0] * ro[0] + ro[1] * ro[1] + ro[2] * ro[2]);
  if (rol > 0.2) {
    for (int i = 0; i < 3; ++i) ro[i] /= rol;
    double Rp[9], Ry[9];
    axis_angle(ro, pitchOff, Rp);
    axis_angle(up, yawOff, Ry);
    mul3(Ry, Rp, Rp);
    mul3(Rp, s->R, Ro);
  }
  // 0.94 twist lock: the gun may lag in WHERE it points, but turning the wrist about the barrel is followed at once (the player: "it does not follow the hand when rotating it")
  if (p.twistLock > 0.001) {
    double fo2[3]; forward_of(Ro, fo2);
    double ft2[3]; forward_of(target, ft2);
    double uo[3] = {Ro[1], Ro[4], Ro[7]}, ut[3] = {target[1], target[4], target[7]};
    // carry the target's up over to the gun's pointing direction (smallest turn from the target's barrel to the gun's)
    double sx[3] = {ft2[1] * fo2[2] - ft2[2] * fo2[1], ft2[2] * fo2[0] - ft2[0] * fo2[2], ft2[0] * fo2[1] - ft2[1] * fo2[0]};
    const double sl = vm::dsqrt(sx[0] * sx[0] + sx[1] * sx[1] + sx[2] * sx[2]);
    double cs2 = ft2[0] * fo2[0] + ft2[1] * fo2[1] + ft2[2] * fo2[2];
    if (cs2 > 1.0) cs2 = 1.0;
    if (cs2 < -1.0) cs2 = -1.0;
    if (sl > 1e-9) {
      double ax[3] = {sx[0] / sl, sx[1] / sl, sx[2] / sl}, Rs[9], ut2[3];
      axis_angle(ax, vm::datan2(sl, cs2), Rs);
      for (int i = 0; i < 3; ++i) ut2[i] = Rs[i * 3] * ut[0] + Rs[i * 3 + 1] * ut[1] + Rs[i * 3 + 2] * ut[2];
      for (int i = 0; i < 3; ++i) ut[i] = ut2[i];
    }
    // both ups flattened onto the plane across the barrel, then the signed angle between them about the barrel
    const double d1 = uo[0] * fo2[0] + uo[1] * fo2[1] + uo[2] * fo2[2], d2 = ut[0] * fo2[0] + ut[1] * fo2[1] + ut[2] * fo2[2];
    for (int i = 0; i < 3; ++i) { uo[i] -= d1 * fo2[i]; ut[i] -= d2 * fo2[i]; }
    const double lo = vm::dsqrt(uo[0] * uo[0] + uo[1] * uo[1] + uo[2] * uo[2]), lt = vm::dsqrt(ut[0] * ut[0] + ut[1] * ut[1] + ut[2] * ut[2]);
    if (lo > 1e-6 && lt > 1e-6) {
      for (int i = 0; i < 3; ++i) { uo[i] /= lo; ut[i] /= lt; }
      const double crx[3] = {uo[1] * ut[2] - uo[2] * ut[1], uo[2] * ut[0] - uo[0] * ut[2], uo[0] * ut[1] - uo[1] * ut[0]};
      const double ang = vm::datan2(crx[0] * fo2[0] + crx[1] * fo2[1] + crx[2] * fo2[2], uo[0] * ut[0] + uo[1] * ut[1] + uo[2] * ut[2]);
      double Rr[9], Rn[9], Rs2[9];
      axis_angle(fo2, ang * (p.twistLock > 1.0 ? 1.0 : p.twistLock), Rr);
      mul3(Rr, Ro, Rn);
      for (int i = 0; i < 9; ++i) Ro[i] = Rn[i];
      mul3(Rr, s->R, Rs2);   // the spring state turns with it, so the twist does not come back as a lag
      for (int i = 0; i < 9; ++i) s->R[i] = Rs2[i];
    }
  }
  // never wander far from the hand: at most 30 degrees with one hand (0.68; 0.58 had 50), 25 with two, and only 40 percent of that while firing
  const double capOne = p.lagCapDeg > 0.0 ? p.lagCapDeg : 12.0, capTwo = p.lagCapDeg > 0.0 ? p.lagCapDeg * 0.67 : 8.0;
  const double maxLag = lerp(capOne, capTwo, two) * (1.0 + (0.6 + 0.4 * pn) * oneFire + 0.25 * looseK);   // 0.94 (was 20 / 16 and +80 %: the 0.93 log reached 36 degrees); 0.95: a one-handed shot may wander up to ~24 degrees (0.94: 19)
  double lag = angle_between(target, Ro);
  if (lag > maxLag) {
    double kk = maxLag / lag, tt[9], e[9], v[3], d[9];
    transpose3(target, tt);
    mul3(Ro, tt, e);
    rot_vector(e, v);
    double vl = vm::dsqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (vl > 1e-9) {
      double ax[3] = {v[0] / vl, v[1] / vl, v[2] / vl};
      axis_angle(ax, vl * kk, d);
      mul3(d, target, Ro);
      for (int i = 0; i < 9; ++i) s->R[i] = Ro[i];
      s->w[0] = s->w[1] = s->w[2] = 0;
    }
    lag = maxLag;
  }
  for (int i = 0; i < 9; ++i) out[i] = Ro[i];
  if (info) { info->lagDeg = lag; info->twoBlend = two; info->fatigue = s->fatigue; info->droopDeg = droop; info->swayDeg = swayA; info->recoilDeg = recoilA; info->strain = s->strain; }
  return 1;
}

// ---- 0.58 the gun is also hard to MOVE ------------------------------------------------------
// The grip point (relative to the head, so walking does not drag it) follows the hand through a damped spring: a heavy
// object in one hand trails a quick sweep, and catches up when you stop. Two hands hold it firmly. At most kPosCapM behind.
static const double kPosCapM = 0.02;   // 0.97 (was 0.04; 0.72: 0.06): the 0.96 log had the hand and gun up to 7 cm behind the real hand (capped on 394 polls) - "the gun falls out of my hand"
struct PosState {
  double rel[3], v[3];
  int have;
  void reset() { have = 0; for (int i = 0; i < 3; ++i) rel[i] = v[i] = 0; }
};
// target: the hand relative to the head (metres, tracking axes). two: 0 one hand .. 1 two hands (smoothed blend).
// out: where the gun is held. Returns the distance it is behind the hand (metres).
inline double step_pos(PosState* s, double heaviness, const double* target, double dt, double two, double* out, double stiff = 0.0, double punish = 1.0) {
  if (!(dt > 0)) dt = 0; else if (dt > 0.1) dt = 0.1;
  if (heaviness <= 0.001 || !s->have) {
    for (int i = 0; i < 3; ++i) { s->rel[i] = target[i]; s->v[i] = 0; out[i] = target[i]; }
    s->have = 1;
    return 0.0;
  }
  const double k = heaviness > 3 ? 3 : heaviness;
  // 0.68: lighter (was 24 / (1 + k) rad/s and 10 cm), stiff while firing
  const double pn = punish < 0 ? 0 : (punish > 2 ? 2 : punish);   // 0.95: firing one-handed also makes the hand trail a little more
  const double omega = lerp(70.0 / (1.0 + 0.4 * k), 90.0, two) * (1.0 + 0.6 * stiff * two - (0.45 + 0.08 * pn) * stiff * (1.0 - two)), zeta = lerp(0.85, 0.95, two);
  double remaining = dt;
  while (remaining > 1e-6) {
    const double h = remaining > 0.005 ? 0.005 : remaining;
    remaining -= h;
    for (int i = 0; i < 3; ++i) {
      s->v[i] += (omega * omega * (target[i] - s->rel[i]) - 2.0 * zeta * omega * s->v[i]) * h;
      s->rel[i] += s->v[i] * h;
    }
  }
  double d[3] = {s->rel[0] - target[0], s->rel[1] - target[1], s->rel[2] - target[2]};
  double l = vm::dsqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
  const double cap = kPosCapM * lerp(1.0, 0.35, two) * (1.0 + (1.2 + 0.4 * pn) * stiff * (1.0 - two) - 0.4 * stiff * two);   // 0.70: one-handed firing is heavier (trails more), two-handed firing firmer
  if (l > cap) {
    const double f = cap / l;
    for (int i = 0; i < 3; ++i) { s->rel[i] = target[i] + d[i] * f; s->v[i] *= 0.6; }
    l = cap;
  }
  for (int i = 0; i < 3; ++i) out[i] = s->rel[i];
  return l;
}

// ---- 0.95 the PKE has a little weight -------------------------------------------------------------------
// The PKE is a light device in one hand: it should not be glued to the controller, but it must not trail it like the gun either. `pct` 0 = no weight at all,
// 40 = default (about 60 ms behind a steady turn, a slight overshoot, never more than ~7 degrees away from the hand), 100 = clearly heavy (about 110 ms, 12 degrees).
// There is no recoil, kick or firing sway (the caller passes firing = 0 for it). Position inertia (step_pos) follows the same heaviness.
inline Params pke_params(double pct, double twistLock) {
  Params p;
  const double u = clamp01(pct / 100.0);
  p.heaviness = u > 0.0 ? 0.2 + 0.6 * u : 0.0;
  p.twistLock = twistLock * 0.7;       // the roll of a handheld device trails slightly too
  p.punish = 0.0;
  p.omegaOne = 60.0 / (1.0 + 2.5 * u);
  p.zetaOne = 0.72;
  p.lagCapDeg = 4.0 + 8.0 * u;
  return p;
}

}  // namespace weight
