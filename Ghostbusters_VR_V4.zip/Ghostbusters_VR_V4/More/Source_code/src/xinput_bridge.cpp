// 0.33 XInput bridge: the game reads its Xbox pad through three imports of
// XINPUT1_3.dll (GetState, SetState, GetCapabilities, by ordinal). Their import
// address table slots are pointed at the functions below. While the Quest
// controllers are tracked they appear to the game as pad 0 (capabilities, state
// and vibration all answer "yes"); a real pad keeps working and is merged in.
// When the controllers are not tracked every call goes straight to the original.
#include "gbvr.h"

#if GBVR_HEADTRACK
#include "layout.h"
#include "padmath.h"

namespace {
typedef DWORD(WINAPI* PFN_GetState)(DWORD, void*);
typedef DWORD(WINAPI* PFN_SetState)(DWORD, void*);
typedef DWORD(WINAPI* PFN_GetCaps)(DWORD, DWORD, void*);
PFN_GetState o_getState;
PFN_SetState o_setState;
PFN_GetCaps o_getCaps;
int g_xiHook;   // 1 installed, 0 not yet, <0 why not
pad::PacketTracker g_tracker;
struct {
  volatile LONG getState, getState0, getStateFaked, getStateMerged, setState, getCaps, getCapsFaked, getStateStart, repaired;
} g_xs;

int readable8(const void* p) {
  MEMORY_BASIC_INFORMATION mbi;
  if (VirtualQuery(p, &mbi, sizeof(mbi)) != sizeof(mbi)) return 0;
  return mbi.State == MEM_COMMIT && !(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS));
}
const DWORD kNotConnected = 1167;  // ERROR_DEVICE_NOT_CONNECTED

DWORD WINAPI hk_get_state(DWORD user, void* st) {
  InterlockedIncrement(&g_xs.getState);
  DWORD r = o_getState ? o_getState(user, st) : kNotConnected;
  pad::State v;
  if (user == 0) InterlockedIncrement(&g_xs.getState0);   // 1.7.141: XInput calls for slot 0 alone (the slot the VR controllers answer)
  if (user != 0 || !st) return r;
  if (!controllers_pad_state(&v)) {
    // 0.52 auto-pause: no tracked controller (the SteamVR menu took them) but the game has to receive Start anyway
    const unsigned ap = autopause_buttons();
    if (ap) {
      v = pad::State();
      v.buttons = (uint16_t)ap;
      InterlockedIncrement(&g_xs.getStateStart);
    } else if (!controllers_pad_grace(&v)) return r;   // 1.7.166: a short tracking loss keeps the pad connected (idle)
  }
  uint8_t* b = (uint8_t*)st;
  pad::State real = {};
  uint32_t realPacket = 0;
  if (r == 0) {
    realPacket = *(uint32_t*)b;
    real.buttons = *(uint16_t*)(b + 4);
    real.lt = b[6]; real.rt = b[7];
    real.lx = *(int16_t*)(b + 8); real.ly = *(int16_t*)(b + 10);
    real.rx = *(int16_t*)(b + 12); real.ry = *(int16_t*)(b + 14);
    InterlockedIncrement(&g_xs.getStateMerged);
  } else {
    InterlockedIncrement(&g_xs.getStateFaked);
  }
  pad::State m = pad::merge(real, v);
  *(uint32_t*)b = realPacket + g_tracker.next(m);
  *(uint16_t*)(b + 4) = m.buttons;
  b[6] = m.lt; b[7] = m.rt;
  *(int16_t*)(b + 8) = m.lx; *(int16_t*)(b + 10) = m.ly;
  *(int16_t*)(b + 12) = m.rx; *(int16_t*)(b + 14) = m.ry;
  return 0;
}

DWORD WINAPI hk_set_state(DWORD user, void* vib) {
  InterlockedIncrement(&g_xs.setState);
  DWORD r = o_setState ? o_setState(user, vib) : kNotConnected;
  if (user != 0 || !vib || !controllers_active()) return r;
  controllers_set_rumble(*(uint16_t*)vib, *(uint16_t*)((uint8_t*)vib + 2));
  return 0;
}

DWORD WINAPI hk_get_caps(DWORD user, DWORD flags, void* caps) {
  InterlockedIncrement(&g_xs.getCaps);
  DWORD r = o_getCaps ? o_getCaps(user, flags, caps) : kNotConnected;
  pad::State gs;
  if (r == 0 || user != 0 || !caps || (!controllers_active() && !autopause_buttons() && !controllers_pad_grace(&gs))) return r;   // 1.7.166: grace too
  pad::fake_capabilities((uint8_t*)caps);
  InterlockedIncrement(&g_xs.getCapsFaked);
  return 0;
}

// 1.7.86: does this address point at code (a function another program has put in the game's import slot)?
int points_at_code(const void* p) {
  MEMORY_BASIC_INFORMATION mbi;
  if (!p || VirtualQuery(p, &mbi, sizeof(mbi)) != sizeof(mbi)) return 0;
  return mbi.State == MEM_COMMIT && (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY));
}

// Replace one import slot. Normally it holds the export of xinput1_3.dll. 1.7.86: when something else already stands in the slot (the Steam overlay /
// Steam Input, a controller remapper), the old code gave up and the pad never reached the game; now our function is put in front of it and calls it
// as "the original" (return 2).
int patch_slot(uint32_t slotRva, const char* ordinalName, int ordinal, void* replacement, void** original) {
  void** slot = (void**)rva(slotRva);
  if (!readable8(slot)) return -1;
  HMODULE xi = GetModuleHandleW(L"xinput1_3.dll");
  void* expected = xi ? (void*)GetProcAddress(xi, (LPCSTR)(uintptr_t)ordinal) : nullptr;
  int chained = 0;
  if (!expected || *slot != expected) {
    if (!points_at_code(*slot)) {
      log_line("HOOK xinput %s: slot %p does not hold ordinal %d of xinput1_3.dll (%p) and is not a function either; not patched", ordinalName, *slot, ordinal, expected);
      return -2;
    }
    HMODULE owner = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)*slot, &owner);
    wchar_t who[MAX_PATH] = L"?";
    if (owner) GetModuleFileNameW(owner, who, MAX_PATH);
    log_line("HOOK xinput %s: slot %p is not ordinal %d of xinput1_3.dll (%p): another program stands in the game's import (module %ls); ours goes in front of it and calls it", ordinalName, *slot, ordinal, expected, who);
    chained = 1;
  }
  DWORD old = 0;
  if (!VirtualProtect(slot, 8, PAGE_READWRITE, &old)) return -3;
  *original = *slot;
  *(void* volatile*)slot = replacement;
  DWORD dummy;
  VirtualProtect(slot, 8, old, &dummy);
  return chained ? 2 : 1;
}
}  // namespace

void xinput_bridge_install() {
  int a = patch_slot(layout::kRvaIatXInputGetState, "GetState", 2, (void*)hk_get_state, (void**)&o_getState);
  int b = patch_slot(layout::kRvaIatXInputSetState, "SetState", 3, (void*)hk_set_state, (void**)&o_setState);
  int c = patch_slot(layout::kRvaIatXInputGetCaps, "GetCapabilities", 4, (void*)hk_get_caps, (void**)&o_getCaps);
  g_xiHook = (a >= 1 && b >= 1 && c >= 1) ? 1 : -1;
  log_line("HOOK xinput-bridge (IAT slots GetState/SetState/GetCapabilities): %s [%d %d %d] (1 = the game's own import, 2 = in front of another program's function)", g_xiHook == 1 ? "installed" : "NOT installed", a, b, c);
}

int xinput_bridge_available() { return g_xiHook == 1; }

// 1.7.91 guard: see pad::guard_should_repatch. Called every few seconds from the render thread. A player's report showed the game never calling our function at all
// although all three slots were ours at the start: if another program (a protection layer, an overlay, a remapper) writes its own function into a slot later, ours
// goes in front of it again.
void xinput_bridge_guard(int inPlay) {
  if (g_xiHook != 1) return;
  static long s_last = -1; static int s_logged;
  const long now = (long)g_xs.getState;
  void* const ours[3] = {(void*)hk_get_state, (void*)hk_set_state, (void*)hk_get_caps};
  void** const orig[3] = {(void**)&o_getState, (void**)&o_setState, (void**)&o_getCaps};
  const uint32_t rv[3] = {layout::kRvaIatXInputGetState, layout::kRvaIatXInputSetState, layout::kRvaIatXInputGetCaps};
  static const char* const nm[3] = {"GetState", "SetState", "GetCapabilities"};
  for (int i = 0; i < 3; ++i) {
    void** slot = (void**)rva(rv[i]);
    if (!readable8(slot)) continue;
    void* cur = *slot;
    if (!pad::guard_should_repatch(cur == ours[i], points_at_code(cur) ? 1 : 0, now, s_last, inPlay, (int)g_xs.repaired)) continue;
    DWORD old = 0;
    if (!VirtualProtect(slot, 8, PAGE_READWRITE, &old)) continue;
    *orig[i] = cur;
    *(void* volatile*)slot = ours[i];
    DWORD dummy;
    VirtualProtect(slot, 8, old, &dummy);
    InterlockedIncrement(&g_xs.repaired);
    if (s_logged < 6) { ++s_logged; log_line("HOOK xinput %s: another program had replaced the game's import slot (%p) and our function was never called; ours is back in front of it (repair #%ld)", nm[i], cur, (long)g_xs.repaired); }
  }
  s_last = now;
}
void xinput_bridge_more(long* caps, long* repaired) { *caps = g_xs.getCaps; *repaired = g_xs.repaired; }

// 1.7.92 DirectInput takeover check (see pad::di_takeover_should_arm and engine_hooks.cpp). Called with the same rhythm as the guard above.
static long s_diTries;
void xinput_bridge_di_check(int padLive) {
  if (g_xiHook != 1) return;
  static long s_last = -1; static int s_live;
  long st[4]; unsigned long long di[4];
  engine_pad_slots(st, di);
  int diOpen = 0;
  for (int p = 0; p < 4; ++p) if (di[p]) diOpen = 1;
  s_live = padLive ? s_live + 1 : 0;
  const long now = (long)g_xs.getState;
  static long s_last0 = -1;
  const long now0 = (long)g_xs.getState0;
  if (pad::di_takeover_should_arm(padLive, s_live, diOpen, now, s_last, (int)s_diTries)) { ++s_diTries; engine_di_takeover_arm(); }
  else if (pad::di_takeover_should_arm_slot0(padLive, s_live, di[0] ? 1 : 0, now0, s_last0, (int)s_diTries)) {
    ++s_diTries; engine_di_takeover_arm();
    log_line("DITAKEOVER armed (1.7.141): a DirectInput device (joystick / HOTAS / wheel / other pad) holds the game's first pad slot and the game did not ask XInput for slot 0 (%ld calls, unchanged) while it did for the others (%ld calls in all): it is closed so the VR controllers can move you", now0, now);
  }
  s_last = now; s_last0 = now0;
}
void xinput_bridge_di_stats(long* tries) { *tries = s_diTries; }
void xinput_bridge_counts(long* getState, long* faked, long* merged, int* hook) {   // 1.7.85
  *getState = g_xs.getState; *faked = g_xs.getStateFaked; *merged = g_xs.getStateMerged; *hook = g_xiHook;
}

void xinput_bridge_report(LONG frame) {
  log_line("XINPUT frame=%d hook=%d getState=%d faked=%d merged=%d setState=%d getCaps=%d capsFaked=%d startInjected=%d", (int)frame, g_xiHook,
           (int)g_xs.getState, (int)g_xs.getStateFaked, (int)g_xs.getStateMerged, (int)g_xs.setState, (int)g_xs.getCaps,
           (int)g_xs.getCapsFaked, (int)g_xs.getStateStart);
}

#endif
