#!/usr/bin/env python3
"""Decode the files written by test_jpeg with a reference decoder (Pillow) and compare with the originals.
usage: check_jpeg.py DIR"""
import sys, glob, os, re
import numpy as np
from PIL import Image
fails = 0
for jp in sorted(glob.glob(os.path.join(sys.argv[1], 't*.jpg'))):
    m = re.search(r't(\d+)_(\d+)x(\d+)_k(\d)_q(\d+)', jp)
    w, h, kind, q = int(m[2]), int(m[3]), int(m[4]), int(m[5])
    ref = np.fromfile(jp[:-4] + '.rgb', dtype=np.uint8).reshape(h, w, 3).astype(np.float64)
    try:
        im = Image.open(jp); im.load()
        dec = np.asarray(im.convert('RGB')).astype(np.float64)
    except Exception as e:
        print('FAIL', os.path.basename(jp), 'does not decode:', e); fails += 1; continue
    ok = im.size == (w, h) and im.mode == 'RGB'
    mse = ((dec - ref) ** 2).mean() if ok else 1e9
    psnr = 99.0 if mse == 0 else 10 * np.log10(255 * 255 / mse)
    # noise and hard coloured edges cannot be kept exactly; smooth pictures must be very close
    need = {0: 38, 1: 38, 2: 24, 3: 50, 4: 30 if q >= 95 else 10}[kind]
    if w * h < 400 and kind != 3: need = min(need, 30)
    size = os.path.getsize(jp)
    good = ok and psnr >= need
    fails += not good
    print('PASS' if good else 'FAIL', os.path.basename(jp), 'size=%d bytes psnr=%.1f dB (need %d)' % (size, psnr, need))
print('ALL PASS' if not fails else '%d FAILED' % fails)
sys.exit(1 if fails else 0)
