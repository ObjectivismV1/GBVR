#!/usr/bin/env python3
# A '//' comment in the middle of a line of default settings hides everything after it (1.7.184 did this once).
# Fails if a source line has code, then '//', then another g_ctl assignment on the same line.
import re, sys, glob
bad = 0
for f in glob.glob('src/*.cpp') + glob.glob('src/*.h'):
    for n, line in enumerate(open(f, errors='replace'), 1):
        # drop string literals so '//' inside "http://" does not count
        t = re.sub(r'"(\\.|[^"\\])*"', '""', line)
        i = t.find('//')
        if i >= 0 and re.search(r'\bg_ctl\.\w+\s*=\s*[-\w.]+\s*;', t[i:]):
            print('%s:%d: a g_ctl assignment sits inside a // comment' % (f, n)); bad += 1
sys.exit(1 if bad else 0)
