#!/usr/bin/env bash
# Runs every unit test on a desktop with no game: each tests/test_*.cpp is built with the host compiler and run,
# then the JPEG files written by test_jpeg are checked with a reference decoder (tests/check_jpeg.py, needs Pillow + numpy).
# usage: bash tests/run_all.sh
set -u
cd "$(dirname "$0")/.."
CXX="${CXX:-clang++}"
out=$(mktemp -d)
pass=0; fail=0; failed=()
for t in tests/test_*.cpp; do
  n=$(basename "$t" .cpp)
  if ! "$CXX" -std=c++17 -O1 -w -Isrc -Ithird_party/openvr/headers "$t" -o "$out/$n" -lm 2>"$out/$n.build.txt"; then
    fail=$((fail+1)); failed+=("$n (build)"); sed -n 1,15p "$out/$n.build.txt"; continue
  fi
  if (cd "$out" && "./$n" >"$out/$n.txt" 2>&1); then pass=$((pass+1)); else fail=$((fail+1)); failed+=("$n"); tail -5 "$out/$n.txt"; fi
done
if command -v python3 >/dev/null && ls "$out"/t*.jpg >/dev/null 2>&1; then
  if python3 tests/check_jpeg.py "$out" >"$out/jpeg.txt" 2>&1; then pass=$((pass+1)); else fail=$((fail+1)); failed+=("check_jpeg"); tail -5 "$out/jpeg.txt"; fi
fi
if command -v python3 >/dev/null; then
  if python3 tests/lint_defaults.py >"$out/lint.txt" 2>&1; then pass=$((pass+1)); else fail=$((fail+1)); failed+=("lint_defaults"); sed -n 1,10p "$out/lint.txt"; fi
fi
echo "tests: $pass passed, $fail failed"
[ $fail -eq 0 ] || { printf '  failed: %s\n' "${failed[@]}"; exit 1; }
rm -rf "$out"
