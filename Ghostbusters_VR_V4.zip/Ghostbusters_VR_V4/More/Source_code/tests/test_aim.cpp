// Unit tests for the 0.32 head-aim math (src/aimmath.h).
// Build: g++ -std=c++17 -O1 -Isrc -o tests/test_aim tests/test_aim.cpp && tests/test_aim
#include "../src/aimmath.h"
#include "../src/stereomath.h"
#include <cmath>
#include <cstdio>
#include <initializer_list>
static int fails;
static void check(const char* name, bool ok, double v = 0) { printf("%s %s (%.6g)\n", ok ? "PASS" : "FAIL", name, v); fails += !ok; }

int main() {
  // level basis for yaw t: forward = (sin t, 0, cos t)
  for (double yaw : {0.0, 0.5, -1.2, 3.0, -3.0}) {
    float m[9], f[3];
    stereo::level_basis(yaw, m);
    check("level basis gives a forward vector", aim::forward_from_basis(m, f), yaw);
    check("forward = (sin yaw, 0, cos yaw)",
          fabs(f[0] - sin(yaw)) < 1e-6 && fabs(f[1]) < 1e-9 && fabs(f[2] - cos(yaw)) < 1e-6, f[0]);
  }
  // a head pitched up 30 degrees (rotation about the camera's right axis), no yaw
  {
    const double a = 30.0 * M_PI / 180.0;
    // engine basis columns right, up, forward; looking up: forward = (0, sin a, cos a), up = (0, cos a, -sin a)
    float m[9] = {1, 0, 0, 0, (float)cos(a), (float)sin(a), 0, (float)-sin(a), (float)cos(a)};
    float f[3];
    check("pitched basis: usable", aim::forward_from_basis(m, f));
    check("forward tilts up by 30 degrees", fabs(f[1] - sin(a)) < 1e-6 && fabs(f[2] - cos(a)) < 1e-6 && fabs(f[0]) < 1e-9, f[1]);
    float level[3] = {0, 0, 1};
    check("angle between level forward and this one is 30 degrees", fabs(aim::angle_deg(level, f) - 30.0) < 1e-3, aim::angle_deg(level, f));
  }
  // game camera yaw 90 degrees plus the head turned 20 degrees: right = 110, left = 70
  for (int dir = 0; dir < 2; ++dir) {
    float level[9], f[3];
    stereo::level_basis(M_PI / 2, level);
    const double h = 20.0 * M_PI / 180.0;
    const double s = dir == 0 ? sin(h) : -sin(h);
    // head rotation in the camera's own axes (columns right, up, forward); +sin in the forward column = turned right
    float head[9] = {(float)cos(h), 0, (float)s, 0, 1, 0, (float)-s, 0, (float)cos(h)};
    float view[9];
    vm::mul(level, head, view);
    check("view is a rotation", vm::is_rotation(view));
    check("view forward found", aim::forward_from_basis(view, f));
    double yaw = atan2(f[0], f[2]) * 180.0 / M_PI;
    check(dir == 0 ? "game yaw 90 + head 20 right = 110 degrees" : "game yaw 90 + head 20 left = 70 degrees",
          fabs(yaw - (dir == 0 ? 110.0 : 70.0)) < 1e-3, yaw);
  }
  // refusals
  {
    float f[3] = {7, 7, 7};
    float zero[9] = {0};
    check("all zero basis refused", !aim::forward_from_basis(zero, f));
    check("output untouched when refused", f[0] == 7 && f[1] == 7 && f[2] == 7);
    float nan9[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
    nan9[5] = NAN;
    check("NaN refused", !aim::forward_from_basis(nan9, f));
    float inf9[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
    inf9[8] = INFINITY;
    check("infinity refused", !aim::forward_from_basis(inf9, f));
    float big[9] = {1, 0, 0, 0, 1, 0, 0, 0, 3};
    check("not-a-rotation column (length 3) refused", !aim::forward_from_basis(big, f));
    float slight[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1.0004f};
    check("rounding noise accepted and made exactly unit", aim::forward_from_basis(slight, f) && fabs(f[2] - 1.0) < 1e-6, f[2]);
  }
  // freshness
  {
    const int64_t freq = 10000000;
    check("fresh: 100 ms old", aim::is_fresh(freq, freq - freq / 10, freq, 250));
    check("fresh: exactly 250 ms", aim::is_fresh(freq, freq - freq / 4, freq, 250));
    check("stale: 300 ms old", !aim::is_fresh(freq, freq - 3 * freq / 10, freq, 250));
    check("never stamped is stale", !aim::is_fresh(freq, 0, freq, 250));
    check("from the future is stale", !aim::is_fresh(freq, freq + 5, freq, 250));
    check("zero frequency is stale", !aim::is_fresh(100, 50, 0, 250));
  }
  // angle helper
  {
    float a[3] = {0, 0, 1}, b[3] = {0, 0, 1}, c[3] = {0, 0, -1}, d[3] = {1, 0, 0};
    check("same direction: 0", fabs(aim::angle_deg(a, b)) < 1e-4, aim::angle_deg(a, b));
    check("opposite: 180", fabs(aim::angle_deg(a, c) - 180.0) < 1e-3, aim::angle_deg(a, c));
    check("perpendicular: 90", fabs(aim::angle_deg(a, d) - 90.0) < 1e-3, aim::angle_deg(a, d));
    float e[3] = {0, 0, 1.0000001f};
    check("slightly over unit length does not give NaN", std::isfinite(aim::angle_deg(a, e)), aim::angle_deg(a, e));
  }
  check("aim field address", aim::aim_field_of(0x1000, 0xB584) == 0x1000 + 0xB584 && aim::aim_field_of(0, 0xB584) == 0);
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
