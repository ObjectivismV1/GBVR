#include <stdio.h>
#include "armmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double fabs_(double x) { return x < 0 ? -x : x; }
static double dist(const double* a, const double* b) { double d[3]; arm::sub(a, b, d); return arm::len(d); }

static void model_matrix(const double* ax, double deg, const float* t, float* m4) {
  double R[9]; weight::axis_angle(ax, deg * vm::kPi / 180.0, R);
  for (int i = 0; i < 16; ++i) m4[i] = 0;
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) m4[r * 4 + c] = (float)R[c * 3 + r];
  m4[12] = t[0]; m4[13] = t[1]; m4[14] = t[2]; m4[15] = 1;
}

int main() {
  // the actor's model -> world matrix: turned 40 degrees about y, scaled 1.1, at (10, 0, -5)
  float W[16];
  {
    double ay[3] = {0, 1, 0};
    float t[3] = {10, 0, -5};
    model_matrix(ay, 40.0, t, W);
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) W[r * 4 + c] *= 1.1f;
  }
  arm::Space sp;
  CHECK(sp.set(W));
  // round trip
  {
    float pm[3] = {0.3f, 4.2f, -1.1f}, back[3];
    double w[3];
    sp.point_world(pm, w);
    sp.point_model(w, back);
    for (int i = 0; i < 3; ++i) CHECK(fabs_(back[i] - pm[i]) < 1e-4);
    // same as the engine's row-vector product
    double e0 = pm[0] * W[0] + pm[1] * W[4] + pm[2] * W[8] + W[12];
    CHECK(fabs_(w[0] - e0) < 1e-4);
  }
  // an arm in model space: shoulder, elbow, wrist (feet): upper arm 1.0, forearm 0.9, bent
  float Sm[3] = {0.5f, 4.6f, 0.0f}, Em[3] = {0.55f, 3.9f, 0.45f}, Wm[3] = {0.5f, 3.9f, 1.3f};
  double S[3], E[3], Wp[3];
  sp.point_world(Sm, S); sp.point_world(Em, E); sp.point_world(Wm, Wp);
  double l1 = dist(S, E), l2 = dist(E, Wp);
  // target within reach
  {
    double T[3] = {S[0] + 0.9, S[1] - 0.5, S[2] + 1.0};
    arm::Ik k;
    CHECK(arm::solve(S, E, Wp, T, 1.0, &k));
    CHECK(!k.clamped);
    CHECK(fabs_(dist(S, k.E) - l1) < 1e-6);          // upper arm keeps its length
    CHECK(fabs_(dist(k.E, k.T) - l2) < 1e-6);        // forearm keeps its length
    CHECK(dist(k.T, T) < 1e-9);                      // wrist reaches the target
    // rotating the animation's bones by the solution lands elbow and wrist there
    double ev[3], e1[3], fv[3], f1[3];
    arm::sub(E, S, ev); arm::apply3(k.QU, ev, e1); for (int i = 0; i < 3; ++i) e1[i] += S[i];
    CHECK(dist(e1, k.E) < 1e-6);
    arm::sub(Wp, E, fv); arm::apply3(k.QU, fv, f1); double f2[3]; arm::apply3(k.Q2, f1, f2);
    for (int i = 0; i < 3; ++i) f2[i] += k.E[i];
    CHECK(dist(f2, k.T) < 1e-6);
    // the elbow hangs below the shoulder-wrist line
    CHECK(k.E[1] < (S[1] + k.T[1]) * 0.5);
    // the hinge plane normal after both turns is the new plane's normal (twist worked)
    CHECK(k.twisted);
    double n0[3], n1[3], n2[3], ev2[3], fv2[3];
    arm::cross(ev, fv, n0);
    arm::apply3(k.QU, n0, n1); arm::apply3(k.Q2, n1, n1);
    arm::sub(k.E, S, ev2); arm::sub(k.T, k.E, fv2); arm::cross(ev2, fv2, n2);
    arm::unit(n1, n1); arm::unit(n2, n2);
    CHECK(fabs_(arm::dot(n1, n2)) > 0.9999);
    // place(): the U bone's matrix is turned in place; the F bone moves to the new elbow with the extra turn
    float Um[16], Fm[16], U2[16], F2[16];
    double az[3] = {0, 0, 1};
    model_matrix(az, 25.0, Sm, Um);
    model_matrix(az, -15.0, Em, Fm);
    sp.place(Um, k.QU, S, U2);
    double QF[9]; weight::mul3(k.Q2, k.QU, QF);
    sp.place(Fm, QF, k.E, F2);
    float chk[3];
    sp.point_model(k.E, chk);
    for (int i = 0; i < 3; ++i) CHECK(fabs_(F2[12 + i] - chk[i]) < 1e-4);
    for (int i = 0; i < 3; ++i) CHECK(fabs_(U2[12 + i] - Um[12 + i]) < 1e-3);   // shoulder stays
    // a rotation keeps lengths: the rows of the new matrix are as long as before (model space has no scale here)
    for (int r = 0; r < 3; ++r) {
      double a = vm::dsqrt((double)Um[r*4]*Um[r*4] + (double)Um[r*4+1]*Um[r*4+1] + (double)Um[r*4+2]*Um[r*4+2]);
      double b = vm::dsqrt((double)U2[r*4]*U2[r*4] + (double)U2[r*4+1]*U2[r*4+1] + (double)U2[r*4+2]*U2[r*4+2]);
      CHECK(fabs_(a - b) < 1e-4);
    }
  }
  // target out of reach: clamped on the line, arm fully stretched
  // Raising the controller changes the elbow bend, but never the tracked wrist.
  {
    double out[3] = {S[0] + 0.8, S[1], S[2] + 1.2};
    double high[3] = {S[0] + 0.8, S[1] + 0.9, S[2] + 1.2};
    CHECK(arm::raised_elbow_down(S, out, l1 + l2, 1.0) == 1.0);
    const double raised = arm::raised_elbow_down(S, high, l1 + l2, 1.0);
    CHECK(raised < 1.0 && raised > 0.34);
    arm::Ik k;
    CHECK(arm::solve(S, E, Wp, high, raised, &k));
    CHECK(dist(k.T, high) < 1e-9);
  }
  // A modest head-height increase should leave the foot on its old floor spot.
  {
    const double hip[3] = {0, 1.05, 0}, knee[3] = {0, 0.52, 0.1}, ankle[3] = {0, 0, 0};
    const double raisedHip[3] = {0, 1.09, 0};
    double thigh[3], shin[3], kneeScaled[3], ankleScaled[3];
    arm::sub(knee, hip, thigh); arm::sub(ankle, knee, shin);
    const double total = arm::len(thigh) + arm::len(shin);
    const double scale = arm::planted_leg_scale(dist(raisedHip, ankle), total);
    CHECK(scale > 1.0 && scale < 1.08);
    for (int i = 0; i < 3; ++i) { kneeScaled[i] = raisedHip[i] + thigh[i] * scale; ankleScaled[i] = kneeScaled[i] + shin[i] * scale; }
    arm::Ik k;
    CHECK(arm::solve(raisedHip, kneeScaled, ankleScaled, ankle, 0.0, &k));
    CHECK(dist(k.T, ankle) < 1e-9);
    CHECK(arm::planted_leg_scale(5.0, total) == 1.08);
  }
  {
    double T[3] = {S[0] + 5.0, S[1], S[2]};
    arm::Ik k;
    CHECK(arm::solve(S, E, Wp, T, 1.0, &k));
    CHECK(k.clamped);
    CHECK(k.reach > 2.0);
    CHECK(fabs_(dist(S, k.T) - (l1 + l2) * 0.999) < 1e-9);
    CHECK(fabs_(dist(S, k.E) - l1) < 1e-6);
    CHECK(fabs_(dist(k.E, k.T) - l2) < 1e-4);
  }
  // target too close: the arm folds, no NaN
  {
    double T[3] = {S[0] + 0.01, S[1] - 0.01, S[2] + 0.02};
    arm::Ik k;
    int ok = arm::solve(S, E, Wp, T, 1.0, &k);
    CHECK(ok);
    if (ok) for (int i = 0; i < 3; ++i) CHECK(vm::is_finite_f((float)k.E[i]));
  }
  // target right on the shoulder: refuses
  {
    arm::Ik k;
    CHECK(!arm::solve(S, E, Wp, S, 1.0, &k));
  }
  // straight arm in the animation (no hinge plane): still solves, no twist
  {
    double Es[3] = {S[0] + 0.5, S[1], S[2]}, Ws[3] = {S[0] + 1.0, S[1], S[2]};
    double T[3] = {S[0] + 0.3, S[1] - 0.6, S[2] + 0.3};
    arm::Ik k;
    CHECK(arm::solve(S, Es, Ws, T, 1.0, &k));
    CHECK(!k.twisted);
    CHECK(fabs_(dist(k.E, k.T) - 0.5) < 1e-6);
    CHECK(k.E[1] <= (S[1] + k.T[1]) * 0.5 + 1e-9);
  }
  // swing()
  {
    double a[3] = {1, 0, 0}, b[3] = {0, 1, 0}, R[9], o[3];
    arm::swing(a, b, R);
    arm::apply3(R, a, o);
    CHECK(fabs_(o[0]) < 1e-9 && fabs_(o[1] - 1) < 1e-9);
    double c[3] = {-1, 0, 0};
    arm::swing(a, c, R);
    arm::apply3(R, a, o);
    CHECK(fabs_(o[0] + 1) < 1e-9);
    arm::swing(a, a, R);
    arm::apply3(R, a, o);
    CHECK(fabs_(o[0] - 1) < 1e-9);
  }
  // a hand's rigid motion: rows turned, origin moved (what the gun hand does)
  {
    float H[16]; double ax[3] = {0.2, 0.9, 0.1}; arm::unit(ax, ax);
    float t[3] = {0.4f, 3.7f, 1.2f};
    model_matrix(ax, 33.0, t, H);
    double Q[9], axis[3] = {0, 1, 0};
    weight::axis_angle(axis, 0.5, Q);
    double P[3] = {20, 7, 3}, H2[16 > 0 ? 3 : 1];
    float out[16];
    sp.place(H, Q, P, out);
    float back[3];
    double pw[3];
    for (int i = 0; i < 3; ++i) pw[i] = P[i];
    sp.point_model(pw, back);
    for (int i = 0; i < 3; ++i) CHECK(fabs_(out[12 + i] - back[i]) < 1e-4);
    (void)H2;
    // world axis of row 0 turned by Q
    double m[3] = {H[0], H[1], H[2]}, w0[3], w1[3], mo[3] = {out[0], out[1], out[2]}, wo[3];
    sp.dir_world(m, w0); arm::apply3(Q, w0, w1); sp.dir_world(mo, wo);
    for (int i = 0; i < 3; ++i) CHECK(fabs_(w1[i] - wo[i]) < 1e-4);
  }
  // mul4
  {
    float A[16], B[16], C[16];
    for (int i = 0; i < 16; ++i) { A[i] = (i % 5 == 0) ? 1.0f : 0.0f; B[i] = A[i]; }
    A[12] = 1; B[12] = 2; B[13] = 3;
    arm::mul4(A, B, C);
    CHECK(C[12] == 3 && C[13] == 3 && C[0] == 1);
  }
  if (!fails) printf("PASS arm\n");
  return fails ? 1 : 0;
}
