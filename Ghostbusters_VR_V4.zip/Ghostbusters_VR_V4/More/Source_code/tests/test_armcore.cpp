// A fake skinned player model with the engine's memory layout (layout.h "0.57 skeleton") and the three engine functions
// the arm override calls, to run armcore.h end to end: bone indices by name, chains, the write loop, fingers below the
// hand, idempotence, stale cache, bad data.
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>
#include "armcore.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double fabs_(double x) { return x < 0 ? -x : x; }

enum { N = 16 };
static const char* kNames[N] = {"bone_pelvis", "bone_spine1", "bone_spine2", "bone_spine3", "bone_R_clavicle", "bone_R_upperArm", "bone_R_forearm", "bone_R_hand",
                                "bone_R_finger1", "bone_R_finger2", "bone_L_clavicle", "bone_L_upperArm", "bone_L_forearm", "bone_L_hand", "bone_L_finger1", "bone_head"};
static const int kParent[N] = {-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 3, 10, 11, 12, 13, 3};

struct Fake {
  uint8_t* actor;     // 0x10000 bytes
  uint8_t* skel;
  uint8_t* local;     // N * 40
  float* world;       // N * 16
  int logs;
};
static Fake F;

static void qset(uint8_t* l, const double* axis, double deg, double scale, const double* pos) {
  double h = deg * vm::kPi / 360.0, s, c;
  vm::dsincos(h, &s, &c);
  float* f = (float*)l;
  f[0] = (float)(axis[0] * s); f[1] = (float)(axis[1] * s); f[2] = (float)(axis[2] * s); f[3] = (float)c;
  f[4] = f[5] = f[6] = (float)scale;
  f[7] = (float)pos[0]; f[8] = (float)pos[1]; f[9] = (float)pos[2];
}

struct G {
  static void local(const void* l, float* out) {
    const float* f = (const float*)l;
    double x = f[0], y = f[1], z = f[2], w = f[3];
    double R[9] = {1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w),
                   2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w),
                   2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)};
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = (float)(R[c * 3 + r] * f[4 + r]);   // rows = images of the axes (row vectors)
    out[12] = f[7]; out[13] = f[8]; out[14] = f[9];
  }
  static void mul(float* out, const float* a, const float* b) {
    float t[16] = {0};
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) t[r * 4 + c] = a[r * 4] * b[c] + a[r * 4 + 1] * b[4 + c] + a[r * 4 + 2] * b[8 + c];
    for (int c = 0; c < 3; ++c) t[12 + c] = a[12] * b[c] + a[13] * b[4 + c] + a[14] * b[8 + c] + b[12 + c];
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = t[r * 4 + c];
  }
  static void ensure(void* m) {
    int* state = (int*)((uint8_t*)m + layout::kOffModelState - layout::kOffActorModel + layout::kOffActorModel);   // M + 0x2b08
    if (*state > 0) return;
    for (int i = 0; i < N; ++i) {
      float tmp[16] = {0};
      local(F.local + 40 * i, tmp);
      if (kParent[i] < 0) { for (int k = 0; k < 16; ++k) F.world[i * 16 + k] = tmp[k]; }
      else mul(F.world + i * 16, tmp, F.world + kParent[i] * 16);
    }
    *state = 1;
  }
  static int readable(const void*, size_t, int) { return 1; }
  static int64_t clock() { static int64_t c; return ++c; }
  static void log(const char* fmt, ...) {
    ++F.logs;
    if (getenv("ARMLOG")) { va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap); printf("\n"); }
  }
};
typedef armcore::Core<G> Core;

static void* aligned16(size_t n) { return aligned_alloc(16, (n + 15u) & ~(size_t)15u); }

static void build() {
  F.actor = (uint8_t*)aligned16(0x10000);
  memset(F.actor, 0, 0x10000);
  uint8_t* M = F.actor + layout::kOffActorModel;
  F.skel = (uint8_t*)aligned16(1392);
  memset(F.skel, 0, 1392);
  F.local = (uint8_t*)aligned16(N * 40);
  memset(F.local, 0, N * 40);
  F.world = (float*)aligned16(N * 64);
  memset(F.world, 0, N * 64);
  *(int*)(F.skel + 0x88) = N;
  for (int i = 0; i < N; ++i) {
    strncpy((char*)F.skel + 0x8c + i * 0x4c, kNames[i], 0x17);
    *(int*)(F.skel + 0x8c + i * 0x4c + 0x1c) = kParent[i];
  }
  *(uint8_t**)(M + layout::kOffModelSkeleton) = F.skel;
  *(uint8_t**)(M + layout::kOffModelLocal) = F.local;
  *(float**)(M + layout::kOffModelWorld) = F.world;
  *(int*)(M + layout::kOffModelBoneCount) = N;
  *(int*)(M + layout::kOffModelState) = -1;
  int* idx = (int*)(F.actor + layout::kOffActorBoneIdx);
  idx[0] = 15; idx[1] = 3; idx[2] = 5; idx[3] = 11; idx[4] = 7; idx[5] = 13;
  const double X[3] = {1, 0, 0}, Y[3] = {0, 1, 0}, Z[3] = {0, 0, 1};
  const double p0[3] = {0, 3.0, 0}, p1[3] = {0, 0.4, 0}, cR[3] = {0.15, 0.2, 0}, uR[3] = {0.35, 0, 0}, fa[3] = {0, -1.0, 0}, ha[3] = {0, -0.9, 0}, fi[3] = {0, -0.15, 0.02}, fi2[3] = {0, -0.1, 0};
  const double cL[3] = {-0.15, 0.2, 0}, uL[3] = {-0.35, 0, 0}, hd[3] = {0, 0.5, 0};
  const double zero[3] = {0, 0, 0};
  (void)Y; (void)Z; (void)zero;
  qset(F.local + 0 * 40, X, 0, 1, p0);
  qset(F.local + 1 * 40, X, 0, 1, p1); qset(F.local + 2 * 40, X, 0, 1, p1); qset(F.local + 3 * 40, X, 0, 1, p1);
  qset(F.local + 4 * 40, X, 0, 1, cR); qset(F.local + 5 * 40, X, 10, 1, uR);
  qset(F.local + 6 * 40, X, -70, 1, fa);          // elbow bent forward
  qset(F.local + 7 * 40, X, 15, 1, ha);
  qset(F.local + 8 * 40, X, 20, 1, fi); qset(F.local + 9 * 40, X, 20, 1, fi2);
  qset(F.local + 10 * 40, X, 0, 1, cL); qset(F.local + 11 * 40, X, 10, 1, uL);
  qset(F.local + 12 * 40, X, -70, 1, fa); qset(F.local + 13 * 40, X, 15, 1, ha); qset(F.local + 14 * 40, X, 20, 1, fi);
  qset(F.local + 15 * 40, X, 0, 1, hd);
}

static void world_pos(const arm::Space& sp, int bone, double* w) { sp.point_world(F.world + bone * 16 + 12, w); }
static double dist(const double* a, const double* b) { double d[3] = {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; return arm::len(d); }

int main() {
  build();
  uintptr_t actor = (uintptr_t)F.actor;
  // body: model -> world, turned 30 degrees about y, scaled 1.05, standing at (5, 0, 2)
  float W2[16] = {0};
  {
    double ay[3] = {0, 1, 0}, R[9];
    weight::axis_angle(ay, 30.0 * vm::kPi / 180.0, R);
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) W2[r * 4 + c] = (float)(1.05 * R[c * 3 + r]);
    W2[12] = 5; W2[13] = 0; W2[14] = 2; W2[15] = 1;
  }
  arm::Space sp;
  CHECK(sp.set(W2));
  G::ensure(F.actor + layout::kOffActorModel);
  double S0[3], E0[3], H0[3], LH0[3];
  world_pos(sp, 5, S0); world_pos(sp, 6, E0); world_pos(sp, 7, H0); world_pos(sp, 13, LH0);
  double fingerRel0[3];
  {
    double f0[3]; world_pos(sp, 8, f0);
    for (int i = 0; i < 3; ++i) fingerRel0[i] = f0[i] - H0[i];
  }
  printf("anim: shoulder %.2f,%.2f,%.2f elbow %.2f,%.2f,%.2f hand %.2f,%.2f,%.2f\n", S0[0], S0[1], S0[2], E0[0], E0[1], E0[2], H0[0], H0[1], H0[2]);
  // snapshot of untouched bones to see nothing else moves
  float before[N * 16];
  memcpy(before, F.world, sizeof(before));

  // targets: right = the wand's motion (turn 40 degrees about y about P0, then to grip); left = a free controller
  ArmTargets t;
  memset(&t, 0, sizeof(t));
  {
    double ay[3] = {0, 1, 0};
    weight::axis_angle(ay, 40.0 * vm::kPi / 180.0, t.wandR);
    for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
    t.wandP0[0] += 0.1;
    t.grip[0] = S0[0] + 0.5; t.grip[1] = S0[1] - 0.4; t.grip[2] = S0[2] + 1.1;
    t.rightOn = 1;
    t.leftOn = 1;
    t.lpos[0] = LH0[0] - 0.3; t.lpos[1] = LH0[1] + 0.3; t.lpos[2] = LH0[2] + 0.5;
    double fw[3] = {0.2, 0.1, 0.97}; arm::unit(fw, t.lfwd);
    t.lup[0] = 0; t.lup[1] = 1; t.lup[2] = 0;
    t.wristBackFt = 0.2; t.wristDownFt = 0.05; t.elbowDown = 1.0;
  }
  CHECK(Core::apply(actor, W2, &t) == 1);
  CHECK(Core::st.moved[0] == 1 && Core::st.moved[1] == 1);
  CHECK(Core::c.arm[0].U == 5 && Core::c.arm[0].F == 6 && Core::c.arm[0].H == 7 && Core::c.arm[0].plen == 3);
  CHECK(Core::c.arm[1].U == 11 && Core::c.arm[1].F == 12 && Core::c.arm[1].H == 13);
  CHECK(Core::c.arm[0].subN == 5 && Core::c.arm[1].subN == 4);   // upper, fore, hand, 2 fingers / upper, fore, hand, 1 finger
  double S1[3], E1[3], H1[3], LS1[3], LE1[3], LH1[3];
  world_pos(sp, 5, S1); world_pos(sp, 6, E1); world_pos(sp, 7, H1); world_pos(sp, 11, LS1); world_pos(sp, 12, LE1); world_pos(sp, 13, LH1);
  // right: shoulder unchanged, arm lengths kept, wrist at the wand-moved hand position
  double d0[3] = {H0[0] - t.wandP0[0], H0[1] - t.wandP0[1], H0[2] - t.wandP0[2]}, rd[3], T[3];
  arm::apply3(t.wandR, d0, rd);
  for (int i = 0; i < 3; ++i) T[i] = t.grip[i] + rd[i];
  printf("right wrist target %.2f,%.2f,%.2f got %.2f,%.2f,%.2f  reach %d%%\n", T[0], T[1], T[2], H1[0], H1[1], H1[2], Core::st.lastReachX100[0]);
  CHECK(dist(S0, S1) < 1e-3);
  CHECK(fabs_(dist(S1, E1) - dist(S0, E0)) < 2e-3);
  CHECK(fabs_(dist(E1, H1) - dist(E0, H0)) < 2e-3);
  CHECK(dist(H1, T) < 2e-3);
  // elbow below the shoulder-wrist line (hangs down)
  CHECK(E1[1] < 0.5 * (S1[1] + H1[1]) + 1e-3);
  // fingers follow the hand: the offset child-to-hand is the animation's offset turned by the hand's rotation (same length)
  {
    double f1[3]; world_pos(sp, 8, f1);
    double rel[3] = {f1[0] - H1[0], f1[1] - H1[1], f1[2] - H1[2]};
    CHECK(fabs_(arm::len(rel) - arm::len(fingerRel0)) < 2e-3);
    double want[3]; arm::apply3(t.wandR, fingerRel0, want);   // the gun hand takes the wand's rigid motion
    CHECK(dist(rel, want) < 3e-3);
    double f2[3], f1b[3]; world_pos(sp, 9, f2); world_pos(sp, 8, f1b);
    CHECK(fabs_(dist(f2, f1b) - 0.105) < 3e-3);   // 0.1 ft in the model, body scale 1.05
  }
  // left: wrist at the free target, arm lengths kept
  {
    double Tl[3]; arm::free_wrist(t.lpos, t.lfwd, t.lup, t.wristBackFt, t.wristDownFt, Tl);
    CHECK(dist(LH1, Tl) < 2e-3);
    double LS0[3]; (void)LS0;
    CHECK(fabs_(dist(LS1, LE1) - 1.0 * 1.05) < 3e-3);
  }
  // the left hand turned so that the direction the forearm pointed in now points along the controller's forward
  {
    double Eb[3], Hb[3], fu[3], fa[3];
    sp.point_world(before + 12 * 16 + 12, Eb);
    sp.point_world(before + 13 * 16 + 12, Hb);
    for (int i = 0; i < 3; ++i) fa[i] = Hb[i] - Eb[i];
    arm::unit(fa, fu);
    double comb[3] = {0, 0, 0};
    for (int r = 0; r < 3; ++r) {
      double m0[3] = {before[13 * 16 + r * 4], before[13 * 16 + r * 4 + 1], before[13 * 16 + r * 4 + 2]}, m1[3] = {F.world[13 * 16 + r * 4], F.world[13 * 16 + r * 4 + 1], F.world[13 * 16 + r * 4 + 2]}, a0[3], a1[3];
      sp.dir_world(m0, a0); sp.dir_world(m1, a1);
      arm::unit(a0, a0); arm::unit(a1, a1);
      double c = arm::dot(fu, a0);
      for (int i = 0; i < 3; ++i) comb[i] += c * a1[i];
    }
    CHECK(dist(comb, t.lfwd) < 2e-3);
  }
  // 0.79: the left hand rolls with the controller: the same call with the controller rolled 90 degrees about its forward turns the hand 90 degrees about it
  {
    double h0[9], h1[9];
    for (int r = 0; r < 3; ++r) { double m[3] = {F.world[13 * 16 + r * 4], F.world[13 * 16 + r * 4 + 1], F.world[13 * 16 + r * 4 + 2]}, a[3]; sp.dir_world(m, a); arm::unit(a, a); for (int k = 0; k < 3; ++k) h0[r * 3 + k] = a[k]; }
    double up0[3] = {t.lup[0], t.lup[1], t.lup[2]}, Rr[9], up1[3];
    weight::axis_angle(t.lfwd, 90.0 * vm::kPi / 180.0, Rr);
    arm::apply3(Rr, up0, up1);
    ArmTargets t2 = t;
    for (int i = 0; i < 3; ++i) t2.lup[i] = up1[i];
    CHECK(Core::apply(actor, W2, &t2) == 1);
    for (int r = 0; r < 3; ++r) { double m[3] = {F.world[13 * 16 + r * 4], F.world[13 * 16 + r * 4 + 1], F.world[13 * 16 + r * 4 + 2]}, a[3]; sp.dir_world(m, a); arm::unit(a, a); for (int k = 0; k < 3; ++k) h1[r * 3 + k] = a[k]; }
    int checked = 0;
    for (int r = 0; r < 3; ++r) {
      double a0[3] = {h0[r * 3], h0[r * 3 + 1], h0[r * 3 + 2]}, a1[3] = {h1[r * 3], h1[r * 3 + 1], h1[r * 3 + 2]};
      if (fabs_(arm::dot(a0, t.lfwd)) < 0.3) { ++checked; CHECK(fabs_(arm::dot(a0, a1)) < 0.15); }   // an axis across the forearm ends 90 degrees from where it was
    }
    CHECK(checked >= 1);
    CHECK(Core::apply(actor, W2, &t) == 1);   // and back: the state the rest of this test expects
  }
  // 1.7.174 left-handed, drawn properly: the LEFT arm is drawn at the gun hand's target and the RIGHT arm at the free hand's target; the shoulders stay
  // where they are; the hold the gun is placed from (the stored hand pair) is still the right hand at the gun; repeated passes change nothing.
  {
    ArmTargets tm = t; tm.mirrorArms = 1;
    double RS[3], LS[3]; world_pos(sp, 5, RS); world_pos(sp, 11, LS);
    double Tl[3]; arm::free_wrist(t.lpos, t.lfwd, t.lup, t.wristBackFt, t.wristDownFt, Tl);
    double d0[3] = {H0[0] - t.wandP0[0], H0[1] - t.wandP0[1], H0[2] - t.wandP0[2]}, rd[3], Tg[3];
    arm::apply3(t.wandR, d0, rd); for (int i = 0; i < 3; ++i) Tg[i] = t.grip[i] + rd[i];
    float before2[16 * 16]; memcpy(before2, F.world, sizeof(before2));
    for (int pass = 0; pass < 7; ++pass) {
      ArmTargets t3 = tm;
      if (pass >= 2) t3.lpos[1] += 0.01 * pass;
      if (pass >= 4) t3.grip[1] += 0.01 * pass;
      if (pass == 6) t3.nativeSupport = 1;
      const long d0n = Core::st.dispSolved[0], d1n = Core::st.dispSolved[1];
      CHECK(Core::apply(actor, W2, &t3) == 1);
      double RS2[3], LS2[3], RH2[3], LH2[3]; world_pos(sp, 5, RS2); world_pos(sp, 11, LS2); world_pos(sp, 7, RH2); world_pos(sp, 13, LH2);
      double Tl3[3]; arm::free_wrist(t3.lpos, t3.lfwd, t3.lup, t3.wristBackFt, t3.wristDownFt, Tl3);
      double Tg3[3]; for (int i = 0; i < 3; ++i) Tg3[i] = t3.grip[i] + rd[i];
      const double eR = dist(RH2, Tl3), eL = dist(LH2, Tg3);
      if (pass == 0 || eR > 3e-3 || eL > 3e-3) printf("left-handed pass %d: right hand %.3f ft from the free hand's target (reach %d%%), left hand %.3f ft from the gun hand's target (reach %d%%); drawn %ld/%ld\n", pass, eR, Core::st.dispReachX100[0], eL, Core::st.dispReachX100[1], Core::st.dispSolved[0] - d0n, Core::st.dispSolved[1] - d1n);
      CHECK(eR < 3e-3 || Core::st.dispReachX100[0] >= 99);
      CHECK(eL < 3e-3 || Core::st.dispReachX100[1] >= 99);
      CHECK(dist(RS2, RS) < 1e-3 && dist(LS2, LS) < 1e-3);                      // shoulders where they were
      if (pass == 1) CHECK(Core::st.dispSolved[0] == d0n && Core::st.dispSolved[1] == d1n);   // the same targets on the same skeleton: left alone (the second eye)
      float gH[16], fH[16]; int64_t ck = 0;
      if (Core::hand_pair_read(actor, gH, fH, &ck)) { double fp[3] = {fH[12], fH[13], fH[14]}; CHECK(dist(fp, Tg3) < 0.02 || pass < 4); }   // the gun's hold is still the right hand at the gun
      for (int b = 0; b < 4; ++b) { double p0[3], p1[3]; sp.point_world(before2 + b * 16 + 12, p0); world_pos(sp, b, p1); CHECK(dist(p0, p1) < 1e-4); }
      for (int i = 0; i < 16 * 16; ++i) CHECK(F.world[i] == F.world[i]);
    }
    {   // the free hand's controller is lost: the left arm still holds the gun, the right arm is not left on the gun
      ArmTargets t4 = tm; t4.leftOn = 0; t4.grip[1] += 0.2;
      CHECK(Core::apply(actor, W2, &t4) == 1);
      double LH2[3], RH2[3]; world_pos(sp, 13, LH2); world_pos(sp, 7, RH2);
      double Tg4[3]; for (int i = 0; i < 3; ++i) Tg4[i] = t4.grip[i] + rd[i];
      printf("left-handed, free controller lost: left hand %.3f ft from the gun target, right hand %.3f ft from it\n", dist(LH2, Tg4), dist(RH2, Tg4));
      CHECK(dist(LH2, Tg4) < 3e-3 || Core::st.dispReachX100[1] >= 99);
      CHECK(dist(RH2, Tg4) > 0.05);
    }
    memcpy(F.world, before, sizeof(before));   // the game rebuilds the pose every frame; the fake does not
    CHECK(Core::apply(actor, W2, &t) == 1);   // back to the normal arms
    double RH3[3]; world_pos(sp, 7, RH3); CHECK(dist(RH3, Tg) < 3e-3);
  }
  // 0.79: no weapon in hand (the animation's hand is 72 cm from the wand origin): the right wrist goes to the controller's grip instead of flying off
  {
    ArmTargets tf = t;
    for (int i = 0; i < 3; ++i) tf.wandP0[i] = H0[i] + (i == 1 ? -2.4 : 0.0);
    tf.rdirOk = 1; tf.rdir[0] = 0; tf.rdir[1] = 0; tf.rdir[2] = 1; tf.rup[0] = 0; tf.rup[1] = 1; tf.rup[2] = 0;
    const int far0 = Core::st.gripFar;
    CHECK(Core::apply(actor, W2, &tf) == 1);
    CHECK(Core::st.gripFar == far0 + 1);
    double Hf[3]; world_pos(sp, 7, Hf);
    double Ssh[3]; world_pos(sp, 5, Ssh);
    const double reach = dist(Hf, tf.grip), arm_len = 2.0;
    CHECK(reach < 0.3 || dist(Ssh, tf.grip) > arm_len);   // at the grip, or as near as the arm can stretch
    CHECK(Core::apply(actor, W2, &t) == 1);
  }
  // 1.7.19: the left hand holds the barrel from UNDER, at the spot along it where the controller is (it slides, it is not glued to one foregrip spot)
  {
    ArmTargets tu = t;
    tu.rdirOk = 1; tu.rdir[0] = 0; tu.rdir[1] = 0; tu.rdir[2] = 1; tu.rup[0] = 0; tu.rup[1] = 1; tu.rup[2] = 0;
    tu.gunLenFt = 2.0; tu.gunPosOk = 1; tu.gunPos[0] = tu.lpos[0]; tu.gunPos[1] = tu.lpos[1]; tu.gunPos[2] = tu.lpos[2] - 0.9;   // the controller sits 0.9 ft along the barrel
    tu.underW = 1.0; tu.underFt = 0.2; tu.gripMagnet = 0.0;
    const long n0 = Core::st.lUnderN;
    CHECK(Core::apply(actor, W2, &tu) == 1);
    CHECK(Core::st.lUnderN == n0 + 1);
    double Tw[3]; arm::free_wrist(tu.lpos, tu.lfwd, tu.lup, tu.wristBackFt, tu.wristDownFt, Tw);
    double Hu[3]; world_pos(sp, 13, Hu);
    // the hand moved DOWN (about the under distance) and stayed at the same spot along the barrel: about 45 % of 2 ft
    CHECK(Core::st.lMagWNow > 0.99);
    CHECK(Hu[1] < Tw[1] - 0.12);
    CHECK(fabs_(Hu[2] - Tw[2]) < 0.15);
    CHECK(Core::st.lUnderAlongX100 / (Core::st.lUnderN ? Core::st.lUnderN : 1) > 35 && Core::st.lUnderAlongX100 / (Core::st.lUnderN ? Core::st.lUnderN : 1) < 55);
    // a hand pushed out to the end of the barrel is held at 95 % of its length
    ArmTargets te = tu; te.gunPos[2] = te.lpos[2] - 2.3;
    const long c0 = Core::st.lUnderClamped;
    CHECK(Core::apply(actor, W2, &te) == 1);
    CHECK(Core::st.lUnderClamped == c0 + 1);
    // a hand more than 1.2 ft from where it would go (arm's length from the gun) is left alone
    { ArmTargets tf2 = tu; tf2.gunPos[2] = tf2.lpos[2] - 5.0; const long f0 = Core::st.lUnderFar; CHECK(Core::apply(actor, W2, &tf2) == 1); CHECK(Core::st.lUnderFar == f0 + 1); }
    // underW = 0: nothing is pulled (the old foregrip magnet is off too)
    ArmTargets tz = tu; tz.underW = 0.0;
    const long n1 = Core::st.lUnderN;
    CHECK(Core::apply(actor, W2, &tz) == 1);
    CHECK(Core::st.lUnderN == n1);
    CHECK(Core::apply(actor, W2, &t) == 1);
  }
  // 1.7.105: the fore grab: with the grab on the hand is brought onto the barrel from farther away than the soft pull reaches, and eases there as grabW rises (no jump)
  {
    ArmTargets tg = t;
    tg.rdirOk = 1; tg.rdir[0] = 0; tg.rdir[1] = 0; tg.rdir[2] = 1; tg.rup[0] = 0; tg.rup[1] = 1; tg.rup[2] = 0;
    tg.gunLenFt = 2.0; tg.gunPosOk = 1; tg.gunPos[0] = tg.lpos[0]; tg.gunPos[1] = tg.lpos[1] + 1.3; tg.gunPos[2] = tg.lpos[2] - 0.9;   // the grip point is 1.1 ft from the real hand
    tg.underW = 1.0; tg.underFt = 0.2; tg.gripMagnet = 0.0;
    double Gp[3] = {tg.gunPos[0], tg.gunPos[1] + 0.0 - tg.underFt, tg.gunPos[2] + 0.9};
    // grab off: 1.1 ft is "too far" and the hand is left alone
    tg.grabOn = 0; tg.grabW = 0.0;
    const long f0 = Core::st.lUnderFar, n2 = Core::st.lUnderN, g0 = Core::st.lGrabPasses;
    CHECK(Core::apply(actor, W2, &tg) == 1);
    CHECK(Core::st.lUnderFar == f0 + 1 && Core::st.lUnderN == n2 && Core::st.lGrabPasses == g0);
    double Hoff[3]; world_pos(sp, 13, Hoff);
    const double dOff = dist(Hoff, Gp);
    // grab on, eased in: the hand comes nearer the grip point on every step, never farther, and ends close to it
    double prev = dOff, worstStep = 0.0; int mono = 1;
    const double ws[6] = {0.1, 0.3, 0.5, 0.7, 0.9, 1.0};
    for (int k = 0; k < 6; ++k) {
      tg.grabOn = 1; tg.grabW = ws[k];
      CHECK(Core::apply(actor, W2, &tg) == 1);
      double Hk[3]; world_pos(sp, 13, Hk);
      const double dk = dist(Hk, Gp);
      if (dk > prev + 1e-3) mono = 0;
      if (prev - dk > worstStep) worstStep = prev - dk;
      prev = dk;
    }
    printf("fore grab: hand %.2f ft from the grip point with the grab off, %.2f ft at full grab (biggest single step %.2f ft)\n", dOff, prev, worstStep);
    CHECK(mono);
    CHECK(prev < dOff - 0.4);
    CHECK(worstStep < 0.5);
    printf("fore grab: arm passes holding %ld, pulled passes %ld (want 3 and 6)\n", Core::st.lGrabPasses - g0, Core::st.lUnderN - n2);
    CHECK(Core::st.lGrabPasses - g0 == 3 && Core::st.lUnderN - n2 == 6);   // grabW above 0.5 counts as holding: 0.7, 0.9, 1.0
    CHECK(Core::apply(actor, W2, &t) == 1);
  }
  // 1.7.109: the wrap grip: a hand that holds the barrel lies ON it: the fingers point across it (for a hand under the barrel: to the player's right), the position is a palm radius from the barrel line
  {
    ArmTargets tw = t;
    tw.grabOrbitFollow = 1.0; tw.grabOrbitDeg = 0.0;   // these checks are about the real hand driving the orbit (the 1.7.109 behaviour)
    tw.rdirOk = 1; tw.rdir[0] = 0; tw.rdir[1] = 0; tw.rdir[2] = 1; tw.rup[0] = 0; tw.rup[1] = 1; tw.rup[2] = 0;
    tw.gunLenFt = 2.0; tw.gunPosOk = 1; tw.gunPos[0] = tw.lpos[0]; tw.gunPos[1] = tw.lpos[1]; tw.gunPos[2] = tw.lpos[2] - 0.9;   // the controller is on the barrel line, 0.9 ft along it
    tw.underW = 1.0; tw.underFt = 0.2; tw.gripMagnet = 0.0; tw.grabOn = 1; tw.grabW = 1.0;
    tw.grabWrap = 0.0; tw.grabWrapDeg = 0.0;
    const long w0 = Core::st.lWrapGripPasses;
    CHECK(Core::apply(actor, W2, &tw) == 1);
    CHECK(Core::st.lWrapGripPasses == w0);   // wrap off: the older look, nothing counted
    double Hold[3]; world_pos(sp, 13, Hold);
    tw.grabWrap = 1.0;
    CHECK(Core::apply(actor, W2, &tw) == 1);
    CHECK(Core::st.lWrapGripPasses == w0 + 1);
    {   // the forearm direction now points along the wanted finger direction: hand under the barrel (barrel along +z, up +y) = the player's right = numerically -(z x y) = +x here
      double Eb[3], Hb[3], fu[3], fa[3];
      sp.point_world(before + 12 * 16 + 12, Eb);
      sp.point_world(before + 13 * 16 + 12, Hb);
      for (int i = 0; i < 3; ++i) fa[i] = Hb[i] - Eb[i];
      arm::unit(fa, fu);
      double comb[3] = {0, 0, 0};
      for (int r = 0; r < 3; ++r) {
        double m0[3] = {before[13 * 16 + r * 4], before[13 * 16 + r * 4 + 1], before[13 * 16 + r * 4 + 2]}, m1[3] = {F.world[13 * 16 + r * 4], F.world[13 * 16 + r * 4 + 1], F.world[13 * 16 + r * 4 + 2]}, a0[3], a1[3];
        sp.dir_world(m0, a0); sp.dir_world(m1, a1);
        arm::unit(a0, a0); arm::unit(a1, a1);
        const double c = arm::dot(fu, a0);
        for (int i = 0; i < 3; ++i) comb[i] += c * a1[i];
      }
      const double want[3] = {1.0, 0.0, 0.0};
      printf("wrap grip: fingers point (%.2f %.2f %.2f), want (1 0 0)\n", comb[0], comb[1], comb[2]);
      CHECK(comb[0] * comb[0] + comb[1] * comb[1] + comb[2] * comb[2] > 0.8);   // 1.7.222: the orbit is picked for the least wrist bend when the hand takes hold, so the fingers point round the barrel in that orbit (not necessarily +x); they must still be a sane direction   // 1.7.215: the wrist limit (55 deg) now stops the hand folding all the way across: it still turns most of the way to the wanted direction
      CHECK(Core::st.lBendClamped > 0 && Core::st.lBendN > 0);
    }
    double Hw[3]; world_pos(sp, 13, Hw);
    CHECK(vm::is_finite_f((float)Hw[0]) && vm::is_finite_f((float)Hw[1]) && vm::is_finite_f((float)Hw[2]));
    CHECK(Core::st.lWrapOrbitX10 > -300 && Core::st.lWrapOrbitX10 < 1350);   // 1.7.222: within the orbit search range
    // tilt: 30 degrees turns the fingers toward the muzzle (+z)
    tw.grabWrapDeg = 30.0;
    CHECK(Core::apply(actor, W2, &tw) == 1);
    CHECK(Core::st.lWrapTiltX10 == 300);
    // hand held out to the player's left of the barrel: it goes round the barrel (orbit positive = left) and the fingers lean to the other side
    tw.grabWrapDeg = 0.0;
    tw.lpos[0] += 0.3;   // numeric +x = the player's right in this fake world? the code's own side basis decides; only the sign of the orbit is compared with the mirror below
    const long wl0 = Core::st.lWrapGripPasses;
    CHECK(Core::apply(actor, W2, &tw) == 1);
    const int orbA = Core::st.lWrapOrbitX10;
    tw.lpos[0] -= 0.6;
    CHECK(Core::apply(actor, W2, &tw) == 1);
    const int orbB = Core::st.lWrapOrbitX10;
    printf("wrap grip: orbit %.1f / %.1f deg for the hand 0.3 ft to either side\n", orbA / 10.0, orbB / 10.0);
    CHECK(Core::st.lWrapGripPasses == wl0 + 2);
    CHECK(orbA >= -300 && orbA <= 1350 && orbB >= -300 && orbB <= 1350);   // 1.7.220: the forearm-aware orbit moves the hand toward the lowest wrist bend (within -30..135 deg and 70 deg of the wanted orbit), so the two sides no longer have to be on opposite sides
    CHECK((Core::st.lOrbitBendX10 <= Core::st.lOrbitBend0X10 || Core::st.lOrbitBendX10 <= 380) && (Core::st.lOrbitShiftX10 < 0 ? -Core::st.lOrbitShiftX10 : Core::st.lOrbitShiftX10) <= 700);
    // 1.7.111: with the teaser hold (110 degrees, the real hand moves it 25 %) a real hand to either side leaves the held hand on the left / top-left: never on the right side
    { ArmTargets tv = tw; tv.grabOrbitDeg = 110.0; tv.grabOrbitFollow = 0.25; tv.grabWrapDeg = 0.0;
      tv.lpos[0] += 0.3;
      CHECK(Core::apply(actor, W2, &tv) == 1);
      const int oA = Core::st.lWrapOrbitX10;
      tv.lpos[0] -= 0.6;
      CHECK(Core::apply(actor, W2, &tv) == 1);
      const int oB = Core::st.lWrapOrbitX10;
      printf("wrap grip: teaser hold orbit %.1f / %.1f deg\n", oA / 10.0, oB / 10.0);
      CHECK(oA >= -300 && oA <= 1350 && oB >= -300 && oB <= 1350);   // 1.7.220: was 60..150 (the fixed teaser orbit); now the wrist-friendly orbit within 70 deg of it
      tv.lpos[0] += 0.3; }   // (1.7.222: the orbit now moves slowly, so two passes prove only the range above)
    {   // 1.7.222 NO TWISTING: once the hand has hold of the barrel the orbit must not creep round it while the real hands wobble (3 cm circles for 3000 passes). Allowed: the pick when taking hold,
        // then at most 1 deg a pass and only slowly; the whole wobble must not swing the orbit by more than 25 deg.
      ArmTargets tz = tw; tz.grabOrbitDeg = 110.0; tz.grabOrbitFollow = 0.10; tz.grabWrapDeg = 0.0;
      const double bx = tz.lpos[0], by = tz.lpos[1];
      Core::st.lOrbitPrevOk = 0;
      int prev = 0, havePrev = 0, maxStep = 0, mn = 100000, mx = -100000;
      for (int f = 0; f < 3000; ++f) {
        tz.lpos[0] = bx + 0.10 * std::sin(f * 0.07); tz.lpos[1] = by + 0.10 * std::cos(f * 0.05);
        CHECK(Core::apply(actor, W2, &tz) == 1);
        const int o = Core::st.lWrapOrbitX10;
        if (havePrev && f > 2) { int d = o - prev; if (d < 0) d = -d; if (d > maxStep) maxStep = d; if (o < mn) mn = o; if (o > mx) mx = o; }
        prev = o; havePrev = 1;
      }
      printf("no twisting: 3000 passes of 3 cm hand wobble: orbit swung %.1f deg in all, biggest step %.1f deg a pass\n", (mx - mn) / 10.0, maxStep / 10.0);
      CHECK(maxStep <= 120);   // the real hand's own follow (10 %) is a smooth part of the orbit; the search itself adds at most 1 deg a pass
      CHECK(mx - mn <= 350);
    }
    // the hand never goes over the top: a real hand held far above the barrel still sits at or below its side
    tw.lpos[0] += 0.3; tw.gunPos[1] = tw.lpos[1] - 0.8;
    CHECK(Core::apply(actor, W2, &tw) == 1);
    CHECK(Core::st.lWrapOrbitX10 > -300 && Core::st.lWrapOrbitX10 < 1350);
    // grabbing is eased: at half weight the wrap is half in (one pass, no jump) and counts as not yet holding
    tw.gunPos[1] = tw.lpos[1]; tw.grabW = 0.4; tw.grabWrap = 0.4;
    const long w1 = Core::st.lWrapGripPasses;
    CHECK(Core::apply(actor, W2, &tw) == 1);
    CHECK(Core::st.lWrapGripPasses == w1);
    CHECK(Core::apply(actor, W2, &t) == 1);
  }
  // 1.7.110: the real-hand distances follow the world size (fpm): a hand 1.1 ft from the grip point is "too far" at a smaller world (fpm x0.5) and still taken at the standard one
  {
    ArmTargets tg = t;
    tg.rdirOk = 1; tg.rdir[0] = 0; tg.rdir[1] = 0; tg.rdir[2] = 1; tg.rup[0] = 0; tg.rup[1] = 1; tg.rup[2] = 0;
    tg.gunLenFt = 2.0; tg.gunPosOk = 1; tg.gunPos[0] = tg.lpos[0]; tg.gunPos[1] = tg.lpos[1] + 1.3; tg.gunPos[2] = tg.lpos[2] - 0.9;
    tg.underW = 1.0; tg.underFt = 0.2; tg.gripMagnet = 0.0; tg.grabOn = 1; tg.grabW = 1.0;
    tg.fpm = 3.28084;
    long n0 = Core::st.lUnderN, f0 = Core::st.lUnderFar;
    CHECK(Core::apply(actor, W2, &tg) == 1);
    CHECK(Core::st.lUnderN == n0 + 1 && Core::st.lUnderFar == f0);   // standard world: pulled (1.1 ft < 1.7 ft)
    tg.fpm = 3.28084 * 0.5;
    n0 = Core::st.lUnderN; f0 = Core::st.lUnderFar;
    CHECK(Core::apply(actor, W2, &tg) == 1);
    CHECK(Core::st.lUnderFar == f0 + 1 && Core::st.lUnderN == n0);   // half-size world: 1.7 ft became 0.85 ft: left alone
    CHECK(Core::apply(actor, W2, &t) == 1);
  }
  // 1.7.215 STRESS + UNUSUAL EVENTS for the wrap-grip wrist limit: 30000 random left-hand frames incl. degenerate ones (hand on the shoulder, far away, zero / parallel pointing and up,
  // tiny and huge guns, flickering grab weights, odd world sizes, zero palm length). Never NaN, never a blown-up bone, nothing outside the left arm moves, counters stay sane,
  // and where the wrist limit worked the hand is within the limit (plus the slack the second solve leaves) of the forearm.
  {
    unsigned long long rs = 88172645463325252ULL;
    auto rr = [&]() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return (double)(rs >> 11) / 9007199254740992.0; };
    auto rg = [&](double lo, double hi) { return lo + (hi - lo) * rr(); };
    int preOver = 0; double preSum = 0, orbSum = 0; int unreach = 0, applied = 0, refused = 0, limited = 0, within = 0, over = 0, badFinite = 0, moved = 0;
    double worstOver = 0.0;
    const long bn0 = Core::st.lBendN, bc0 = Core::st.lBendClamped;
    for (int it = 0; it < 30000; ++it) {
      ArmTargets x = t;
      const int kind = it % 10;
      x.rdirOk = 1; x.leftOn = 1; x.rightOn = 1;
      if (kind == 9) x.mirrorArms = (it / 10) % 2;   // left-handed play on and off
      for (int i = 0; i < 3; ++i) { x.rdir[i] = rg(-1, 1); x.rup[i] = rg(-1, 1); }
      if (kind == 1) { x.rdir[0] = x.rdir[1] = x.rdir[2] = 0; }                          // no pointing at all
      if (kind == 2) { for (int i = 0; i < 3; ++i) x.rup[i] = x.rdir[i] * 2.0; }          // up parallel to pointing
      if (kind == 3) { x.rdir[0] = 0; x.rdir[1] = 1; x.rdir[2] = 0; x.rup[0] = 0; x.rup[1] = 0; x.rup[2] = 1; }   // gun straight up (view forced down / looking at the sky)
      if (kind == 4) { x.rdir[0] = 0; x.rdir[1] = -1; x.rdir[2] = 0; x.rup[0] = 1; x.rup[1] = 0; x.rup[2] = 0; }  // gun straight down
      double nominal[3] = {t.lpos[0], t.lpos[1], t.lpos[2]};
      const double spread = kind == 5 ? 60.0 : (kind == 6 ? 0.02 : 1.5);
      for (int i = 0; i < 3; ++i) x.lpos[i] = nominal[i] + rg(-spread, spread);
      x.gunLenFt = kind == 7 ? rg(0.0, 0.3) : (kind == 8 ? rg(10.0, 100.0) : rg(0.5, 4.0));
      x.gunPosOk = (it & 1);
      for (int i = 0; i < 3; ++i) x.gunPos[i] = x.lpos[i] + rg(-1.5, 1.5);
      x.underW = rg(0, 1.3); x.underFt = rg(0.0, 0.6); x.gripMagnet = rg(0, 1);
      x.grabOn = 1; x.grabW = (it % 7 == 0) ? 1.0 : ((it % 7 == 1) ? 0.0 : rg(0, 1.2));   // grabbing / letting go flicker
      x.grabWrap = (it % 5 == 0) ? 0.0 : rg(0, 1.2); x.grabWrapDeg = rg(-10, 90);
      x.grabOrbitFollow = rg(-0.5, 1.5); x.grabOrbitDeg = (it % 9 == 0) ? -999.0 : rg(-120, 200);
      x.grabLatOk = it % 3 == 0; x.grabLatX = rg(-1, 1); x.grabLatY = rg(-1, 1);
      x.wristBackFt = (it % 11 == 0) ? 0.0 : rg(0.0, 0.8); x.wristDownFt = rg(0.0, 0.2);
      x.fpm = (it % 13 == 0) ? 0.0 : rg(0.5, 8.0);
      if (kind == 0) { x.grabW = 1.0; x.grabWrap = 1.0; x.underW = 1.0; x.gunLenFt = rg(1.0, 3.0); x.gunPosOk = 1; x.grabOrbitDeg = rg(60, 130); x.grabWrapDeg = 30.0; x.wristBackFt = rg(0.15, 0.5); x.fpm = 3.28084; for (int i = 0; i < 3; ++i) x.lpos[i] = nominal[i] + rg(-0.5, 0.5); }   // the roof-fight grip: fully held, teaser orbit
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      const long clamp0 = Core::st.clamped[1];
      const int rc = Core::apply(actor, W2, &x);
      const bool reachLimited = Core::st.clamped[1] != clamp0;
      if (rc == 1) ++applied; else ++refused;
      bool fin = true;
      for (int i = 0; i < N * 16; ++i) if ((i & 3) != 3 && !(vm::is_finite_f(F.world[i]) && F.world[i] < 1e5f && F.world[i] > -1e5f)) fin = false;
      if (!fin) { ++badFinite; continue; }
      for (int i = 0; i < N; ++i) {
        if ((i >= 5 && i <= 9) || (i >= 11 && i <= 14)) continue;
        if (memcmp(before + i * 16, F.world + i * 16, 12 * sizeof(float)) != 0) ++moved;
      }
      if (rc == 1 && Core::st.lWrapNow > 0.99 && x.rdirOk && kind == 0 && x.fpm > 0.0) {   // measure: hand pointing vs forearm
        double Eb[3], Hb[3], fu[3], fa[3];
        sp.point_world(before + 12 * 16 + 12, Eb); sp.point_world(before + 13 * 16 + 12, Hb);
        for (int i = 0; i < 3; ++i) fa[i] = Hb[i] - Eb[i];
        double E1[3], H1[3], f1[3];
        sp.point_world(F.world + 12 * 16 + 12, E1); sp.point_world(F.world + 13 * 16 + 12, H1);
        for (int i = 0; i < 3; ++i) f1[i] = H1[i] - E1[i];
        double comb[3] = {0, 0, 0};
        if (arm::unit(fa, fu) && arm::unit(f1, f1)) {
          for (int r = 0; r < 3; ++r) {
            double m0[3] = {before[13 * 16 + r * 4], before[13 * 16 + r * 4 + 1], before[13 * 16 + r * 4 + 2]}, m1[3] = {F.world[13 * 16 + r * 4], F.world[13 * 16 + r * 4 + 1], F.world[13 * 16 + r * 4 + 2]}, a0[3], a1[3];
            sp.dir_world(m0, a0); sp.dir_world(m1, a1); arm::unit(a0, a0); arm::unit(a1, a1);
            const double c = arm::dot(fu, a0); for (int i = 0; i < 3; ++i) comb[i] += c * a1[i];
          }
          if (arm::unit(comb, comb)) {
            double cs = arm::dot(comb, f1); cs = cs > 1 ? 1 : (cs < -1 ? -1 : cs);
            const double deg = vm::datan2(vm::dsqrt(1.0 - cs * cs), cs) * 57.29577951308232;
            if (reachLimited) { ++unreach; continue; }
            ++limited; if (Core::st.lBendLastX10 > 550) ++preOver; preSum += Core::st.lBendLastX10 / 10.0; orbSum += Core::st.lOrbitShiftX10 / 10.0; if (deg <= 55.0 + 12.0) ++within; else { ++over; if (over <= 12) printf("  over: deg %.1f pre-bend(log) %.1f reach-limited %d\n", deg, Core::st.lBendLastX10 / 10.0, (int)reachLimited); if (deg - 55.0 > worstOver) worstOver = deg - 55.0; }
          }
        }
      }
      CHECK(Core::st.lBendClamped - bc0 <= Core::st.lBendN - bn0);
      CHECK(Core::st.lBendMaxX10 >= 0 && Core::st.lBendMaxX10 <= 1800);
    }
    printf("wrist limit stress: 30000 frames: %d drawn, %d refused (bad data, fine), %d measured with the grip fully on: %d within the limit (+12 deg slack), %d over (worst +%.1f deg); clamped %ld of %ld passes (%d more skipped: the wrist target was out of the arm's reach)\n",
           applied, refused, limited, within, over, worstOver, Core::st.lBendClamped - bc0, Core::st.lBendN - bn0, unreach);
    CHECK(badFinite == 0);
    CHECK(moved == 0);
    CHECK(applied > 20000);
    CHECK(Core::st.lBendClamped - bc0 > 100);
    CHECK(limited > 500 && over == 0);   // every measured grip is inside the limit (+ slack): when the arm will not settle the hand alone is turned (st.lBendFallback)
    printf("orbit search (roof-fight style grips, %d measured): wrist bend before the 55 deg limit averaged %.1f deg, %d of them still above 55 deg; the orbit moved %.1f deg on average from the wanted one\n", limited, limited ? preSum / limited : 0.0, preOver, limited ? orbSum / limited : 0.0);
    printf("wrist limit stress: %ld passes needed the hand-only fallback (the forearm kept turning away)\n", Core::st.lBendFallback);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &t) == 1);
  }
  // 1.7.217 UNUSUAL EVENTS: lost / garbled controller data (NaN, infinity, huge numbers) in the left-hand targets while the wrap grip is on: the call may refuse, but it must never write a broken bone
  {
    unsigned long long rs = 1234567891234567ULL;
    auto rr = [&]() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return (double)(rs >> 11) / 9007199254740992.0; };
    const double odd[] = {NAN, INFINITY, -INFINITY, 0.0, 1e30, -1e30, 1e-30, 7.0, -7.0};
    int nOdd = (int)(sizeof(odd) / sizeof(odd[0])), refusedBad = 0, wroteBad = 0, applied = 0;
    for (int it = 0; it < 20000; ++it) {
      ArmTargets x = t;
      x.rdirOk = 1; x.leftOn = 1; x.rightOn = 1; x.gunLenFt = 2.0; x.gunPosOk = 1; x.underW = 1.0; x.underFt = 0.2; x.gripMagnet = 0.0; x.grabOn = 1; x.grabW = 1.0; x.grabWrap = 1.0; x.grabWrapDeg = 30.0;
      double* fields[] = {x.lpos, x.lpos + 1, x.lpos + 2, x.rdir, x.rdir + 1, x.rdir + 2, x.rup, x.rup + 1, x.rup + 2, x.gunPos, x.gunPos + 1, x.gunPos + 2, x.lfwd, x.lfwd + 1, x.lfwd + 2, x.lup, x.lup + 1, x.lup + 2, &x.wristBackFt, &x.wristDownFt, &x.gunLenFt, &x.fpm, &x.grabLatX, &x.grabLatY, &x.grabOrbitDeg, &x.underFt};
      const int nf = (int)(sizeof(fields) / sizeof(fields[0]));
      const int hits = 1 + (int)(rr() * 3);
      for (int h = 0; h < hits; ++h) *fields[(int)(rr() * nf) % nf] = odd[(int)(rr() * nOdd) % nOdd];
      x.grabLatOk = it & 1;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      const int rc = Core::apply(actor, W2, &x);
      if (rc == 1) ++applied;
      for (int i = 0; i < N * 16; ++i) if ((i & 3) != 3 && !(vm::is_finite_f(F.world[i]) && F.world[i] < 1e5f && F.world[i] > -1e5f)) { ++wroteBad; break; }
    }
    printf("garbled-controller stress: 20000 frames, %d drawn, %d wrote a broken bone (must be 0)\n", applied, wroteBad);
    CHECK(wroteBad == 0);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &t) == 1);
  }
  // nothing outside the two arms moved
  for (int i = 0; i < N; ++i) {
    int inArm = (i >= 5 && i <= 9) || (i >= 11 && i <= 14);
    if (inArm) continue;
    CHECK(memcmp(before + i * 16, F.world + i * 16, 12 * sizeof(float)) == 0);
  }
  // idempotent: the same call again leaves the same matrices (two eyes of one frame)
  {
    float snap[N * 16];
    memcpy(snap, F.world, sizeof(snap));
    CHECK(Core::apply(actor, W2, &t) == 1);
    int same = 1;
    for (int i = 0; i < N; ++i) for (int r = 0; r < 4; ++r) for (int c = 0; c < 3; ++c) if (fabs_(snap[i * 16 + r * 4 + c] - F.world[i * 16 + r * 4 + c]) > 1e-4) same = 0;
    CHECK(same);
  }
  // verify(): kept right after apply, lost when the engine recomputes
  {
    int kept0 = Core::st.verifyKept, lost0 = Core::st.verifyLost;
    Core::verify(actor);
    printf("verify kept %d->%d lost %d->%d\n", kept0, Core::st.verifyKept, lost0, Core::st.verifyLost);
    CHECK(Core::st.verifyKept == kept0 + 2 && Core::st.verifyLost == lost0);
    CHECK(Core::apply(actor, W2, &t) == 1);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = 0;   // the animation changed the pose
    G::ensure(F.actor + layout::kOffActorModel);                              // the engine recomputes all bones
    Core::verify(actor);
    CHECK(Core::st.verifyLost == lost0 + 2);
  }
  // a new animation frame (local pose changed, cache stale): the arm is moved again from the NEW pose
  {
    const double X[3] = {1, 0, 0}; const double fa[3] = {0, -1.0, 0};
    qset(F.local + 6 * 40, X, -40, 1, fa);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);          // the pure animation pose of this frame
    double Hn[3], dn[3], rn[3], Tn[3];
    world_pos(sp, 7, Hn);
    for (int i = 0; i < 3; ++i) dn[i] = Hn[i] - t.wandP0[i];
    arm::apply3(t.wandR, dn, rn);
    for (int i = 0; i < 3; ++i) Tn[i] = t.grip[i] + rn[i];
    CHECK(Core::apply(actor, W2, &t) == 1);
    double H2[3]; world_pos(sp, 7, H2);
    CHECK(dist(H2, Tn) < 2e-3);
    CHECK(dist(Tn, T) > 0.05);                            // the new frame really has a different hand
  }
  // 0.75 gun in hand: the game's own hand (from the local poses, through the game's UNMOVED body matrix O) is the reference for the wand,
  // so the wrist ends up at grip + R * (hand - wandOrigin) and the hand's axes are R * (the game's axes), whatever W2 (moved / scaled body) is.
  {
    float O[16] = {0};
    {
      double ay[3] = {0, 1, 0}, R[9];
      weight::axis_angle(ay, -20.0 * vm::kPi / 180.0, R);
      for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) O[r * 4 + c] = (float)R[c * 3 + r];
      O[12] = 3; O[13] = 0; O[14] = 1; O[15] = 1;
    }
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);          // the pure animation pose
    float Pw[16];
    CHECK(Core::pose_world(F.local, 7, Pw));
    arm::Space spO;
    CHECK(spO.set(O));
    double Hg[3];
    spO.point_world(Pw + 12, Hg);                         // the game's hand in the game's own world
    ArmTargets g = t;
    g.leftOn = 0;
    g.origOn = 1;
    for (int i = 0; i < 16; ++i) g.origBody[i] = O[i];
    for (int i = 0; i < 3; ++i) g.wandP0[i] = Hg[i];
    g.wandP0[0] += 0.06; g.wandP0[1] += 0.02; g.wandP0[2] -= 0.04;   // the wand's origin is a hand's width from the wrist bone
    g.grip[0] = S0[0] + 0.45; g.grip[1] = S0[1] - 0.5; g.grip[2] = S0[2] + 1.0;
    const int fixed0 = Core::st.gripFixed;
    CHECK(Core::apply(actor, W2, &g) == 1);
    CHECK(Core::st.gripFixed == fixed0 + 1);
    double d0[3] = {Hg[0] - g.wandP0[0], Hg[1] - g.wandP0[1], Hg[2] - g.wandP0[2]}, rd[3], Tg[3];
    arm::apply3(g.wandR, d0, rd);
    for (int i = 0; i < 3; ++i) Tg[i] = g.grip[i] + rd[i];
    double Hn[3]; world_pos(sp, 7, Hn);
    printf("grip fix: wrist target %.3f,%.3f,%.3f got %.3f,%.3f,%.3f  offset to wand %.1f cm\n", Tg[0], Tg[1], Tg[2], Hn[0], Hn[1], Hn[2], arm::len(d0) * 30.48);
    CHECK(dist(Hn, Tg) < 2e-3);                           // the wrist is exactly at the rigid place next to the controller
    CHECK(Core::st.gripOldErrMaxX100 > 5);                // the 0.74 way (hand measured in the moved body) would have missed by more than 5 cm
    // the hand's axes: world direction of each axis row = R * the game's direction of the same axis row
    {
      float Hb[16];
      for (int i = 0; i < 16; ++i) Hb[i] = F.world[7 * 16 + i];
      double worst = 0;
      for (int r = 0; r < 3; ++r) {
        double mg[3] = {Pw[r * 4], Pw[r * 4 + 1], Pw[r * 4 + 2]}, wg[3], want[3], mc[3] = {Hb[r * 4], Hb[r * 4 + 1], Hb[r * 4 + 2]}, got[3];
        spO.dir_world(mg, wg); arm::unit(wg, wg); arm::apply3(g.wandR, wg, want);
        sp.dir_world(mc, got); arm::unit(got, got);
        const double e = dist(want, got);
        if (e > worst) worst = e;
      }
      printf("grip fix: hand axes worst error %.4f\n", worst);
      CHECK(worst < 5e-3);
    }
    // 1.7.7 the wrist sits back like the left hand's: grip_at_hand puts the wrist at grip - rdir*back - rup*down and the weapon slides by -rd - back (the fist, not the wrist, is at the real hand)
    {
      ArmTargets w1 = g;
      w1.gripAtHand = 1; w1.rdirOk = 1;
      w1.rdir[0] = 0.0; w1.rdir[1] = 0.0; w1.rdir[2] = 1.0; w1.rup[0] = 0.0; w1.rup[1] = 1.0; w1.rup[2] = 0.0;
      w1.fpm = 3.28084; w1.gunLenFt = 1.5;
      w1.gunWristBackFt = 0.23; w1.gunWristDownFt = 0.066;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      CHECK(Core::apply(actor, W2, &w1) == 1);
      double Hw[3]; world_pos(sp, 7, Hw);
      const double want[3] = {w1.grip[0], w1.grip[1] - 0.066, w1.grip[2] - 0.23};
      printf("wrist back: wrist %.3f,%.3f,%.3f want %.3f,%.3f,%.3f\n", Hw[0], Hw[1], Hw[2], want[0], want[1], want[2]);
      CHECK(dist(Hw, want) < 2e-3);
      const double wbv[3] = {0.0, 0.066, 0.23};
      const double sh[3] = {-rd[0] - wbv[0], -rd[1] - wbv[1], -rd[2] - wbv[2]};
      CHECK(vm::dabs((double)Core::st.gripShift[0] - sh[0]) < 2e-3 && vm::dabs((double)Core::st.gripShift[1] - sh[1]) < 2e-3 && vm::dabs((double)Core::st.gripShift[2] - sh[2]) < 2e-3);
      CHECK(Core::st.wfN[0] >= 1 && vm::dabs(Core::st.wfLast[0] - 0.2393 * 30.48) < 0.5);   // |wb| = sqrt(0.23^2+0.066^2) ft in cm
      // back = 0: exactly the 1.7.6 placement (wrist on the controller point)
      ArmTargets w0 = w1; w0.gunWristBackFt = 0.0; w0.gunWristDownFt = 0.0;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      CHECK(Core::apply(actor, W2, &w0) == 1);
      world_pos(sp, 7, Hw);
      CHECK(dist(Hw, w0.grip) < 2e-3);
      CHECK(vm::dabs((double)Core::st.gripShift[0] + rd[0]) < 2e-3 && vm::dabs((double)Core::st.gripShift[2] + rd[2]) < 2e-3);
    }
    // a hand far from the wand origin (another model / bad pair) is not trusted: the old way is used, nothing breaks
    {
      ArmTargets farw = g;
      for (int i = 0; i < 3; ++i) farw.wandP0[i] += 5.0;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      const int f1 = Core::st.gripFixed;
      CHECK(Core::apply(actor, W2, &farw) == 1);
      CHECK(Core::st.gripFixed == f1);
      for (int i = 0; i < N * 16; ++i) CHECK(vm::is_finite_f(F.world[i]));
    }
    // origOn = 0 keeps the old path exactly
    {
      ArmTargets offg = g; offg.origOn = 0;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      const int f1 = Core::st.gripFixed;
      CHECK(Core::apply(actor, W2, &offg) == 1);
      CHECK(Core::st.gripFixed == f1);
    }
  }
  // unreachable target: the arm stretches towards it, no NaN
  {
    ArmTargets far = t;
    far.leftOn = 0;
    far.grip[0] += 20;
    CHECK(Core::apply(actor, W2, &far) == 1);
    CHECK(Core::st.clamped[0] >= 1);
    for (int i = 0; i < N * 16; ++i) CHECK(vm::is_finite_f(F.world[i]));
    double Sx[3], Ex[3], Hx[3]; world_pos(sp, 5, Sx); world_pos(sp, 6, Ex); world_pos(sp, 7, Hx);
    CHECK(fabs_(dist(Sx, Hx) - (dist(Sx, Ex) + dist(Ex, Hx)) * 0.999) < 0.02);
  }
  // only one hand tracked
  {
    ArmTargets one = t; one.rightOn = 0;
    float snap[16 * 16]; memcpy(snap, F.world, sizeof(snap) > N * 64 ? N * 64 : sizeof(snap));
    G::ensure(F.actor + layout::kOffActorModel);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &one) == 1);
    CHECK(Core::st.noTarget[0] >= 1);
  }
  // bad data
  {
    int sv = *(int*)(F.skel + 0x88);
    *(int*)(F.skel + 0x88) = N + 1;                       // count mismatch
    int bad0 = Core::st.badLayout;
    CHECK(Core::apply(actor, W2, &t) == 0 && Core::st.badLayout == bad0 + 1);
    *(int*)(F.skel + 0x88) = sv;
    float Wbad[16]; memcpy(Wbad, W2, sizeof(Wbad)); for (int i = 0; i < 12; ++i) Wbad[i] = 0;   // singular body matrix
    CHECK(Core::apply(actor, Wbad, &t) == 0);
    float Wfar[16]; memcpy(Wfar, W2, sizeof(Wfar)); for (int i = 0; i < 12; ++i) Wfar[i] *= 100.0f;   // bones in other units than feet
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, Wfar, &t) == 0 && Core::st.badSpace[0] >= 1);
    ArmTargets none; memset(&none, 0, sizeof(none));
    CHECK(Core::apply(actor, W2, &none) == 0);
  }
  // 1.7.32 stereo pair: even when native animation is rebuilt between eyes,
  // the second eye draws exactly the finished first-eye skeleton. A NEW pair
  // must consume its new animation/targets, and unpaired calls never reuse it.
  {
    ArmTargets first = t;
    first.stereoPair = 10000000001LL; first.stereoRole = 1;
    first.gripAtHand = 1;
    first.armsOnly = 1; first.headOnly = 1;
    first.bodyOn = 1; first.calmSeq = first.stereoPair;
    first.calmTauS = 0.14; first.calmDtS = 1.0 / 90;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &first) == 1);
    float eyeOne[N * 16]; memcpy(eyeOne, F.world, sizeof(eyeOne));
    const long filters = Core::st.calmFrames;
    const long reused = Core::st.stereoReused;
    ArmTargets second = first; second.stereoRole = 2;
    second.grip[0] += 0.8; second.lpos[1] += 0.4; // an accidental late input sample
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &second) == 1);
    for (int i = 0; i < N * 16; ++i) if ((i & 3) != 3) CHECK(F.world[i] == eyeOne[i]);
    CHECK(Core::st.stereoReused == reused + 1);
    CHECK(Core::st.calmFrames == filters);
    second.stereoPair++; second.stereoRole = 1; second.calmSeq = second.stereoPair;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &second) == 1);
    CHECK(Core::st.stereoReused == reused + 1);
    CHECK(memcmp(eyeOne, F.world, sizeof(eyeOne)) != 0);
    second.stereoPair = 0; second.stereoRole = 0;
    Core::apply(actor, W2, &second);
    CHECK(Core::st.stereoReused == reused + 1);
  }
  // Fight view: shoulders follow the virtual head while arm lengths stay human.
  {
    ArmTargets floating = t;
    floating.floatingArms = 1; floating.armsOnly = 1; floating.headOnly = 0;
    floating.keepShoulders = 0; floating.bodyOn = 0; floating.eyeOn = 1;
    floating.eyeTarget[0] = 5; floating.eyeTarget[1] = 5.5; floating.eyeTarget[2] = 2;
    floating.bodyYaw = 0; floating.fpm = 3.28084;
    floating.stretchMax = 1.05; floating.shoulderPullDeg = 0; floating.shoulderSlideFt = 0;
    floating.gripAtHand = 1;
    floating.grip[0] = 5.5; floating.grip[1] = 4.8; floating.grip[2] = 3.2;
    floating.lpos[0] = 4.5; floating.lpos[1] = 4.8; floating.lpos[2] = 3.2;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &floating) == 1);
    double shoulder[3]; world_pos(sp, 5, shoulder);
    CHECK(fabs_(shoulder[0] - (5 + 0.17 * floating.fpm)) < 1e-3);
    CHECK(fabs_(shoulder[1] - (5.5 - 0.24 * floating.fpm)) < 1e-3);
    CHECK(fabs_(shoulder[2] - (2 - 0.16 * floating.fpm)) < 1e-3);
    CHECK(Core::st.lastStretchX100[0] <= 105 && Core::st.lastStretchX100[1] <= 105);
    float once[N * 16]; memcpy(once, F.world, sizeof(once));
    CHECK(Core::apply(actor, W2, &floating) == 1);
    for (int i = 0; i < N * 16; ++i) if ((i & 3) != 3) CHECK(fabs_(once[i] - F.world[i]) < 1e-4);
  }
  // Native support follows the current weapon animation's hand relation,
  // without sliding when the tracked left hand moves around while gripping.
  {
    ArmTargets ns = t;
    ns.nativeSupport = 1; ns.origOn = 1; ns.gripAtHand = 1;
    ns.grabW = 1; ns.grabOn = 1; ns.underW = 1; ns.grabWrap = 1;
    ns.stretchMax = 3.0; ns.rdirOk = 1;
    ns.rdir[0] = 0; ns.rdir[1] = 0; ns.rdir[2] = 1;
    ns.rup[0] = 0; ns.rup[1] = 1; ns.rup[2] = 0;
    for (int i = 0; i < 16; ++i) ns.origBody[i] = W2[i];
    for (int variant = 0; variant < 3; ++variant) {
      ns.gunLenFt = 1.0 + variant * 0.65;
      // A changed native support position stands in for a different weapon's animation.
      float* lhLocal = (float*)(F.local + 13 * 40);
      const float oldX = lhLocal[7]; lhLocal[7] += 0.03f * variant;
      float lp[16] = {}, rp[16] = {}, lw[16] = {}, rw[16] = {}, rel[16], want[16];
      CHECK(Core::pose_world(F.local, 13, lp)); CHECK(Core::pose_world(F.local, 7, rp));
      G::mul(lw, lp, W2); G::mul(rw, rp, W2);
      CHECK(handprop::relative(lw, rw, rel));
      for (int move = 0; move < 3; ++move) {
        ns.lpos[0] = t.lpos[0] + 0.2 * move;
        ns.lpos[2] = t.lpos[2] - 0.2 * move;
        CHECK(Core::apply(actor, W2, &ns));
        CHECK(handprop::place(rel, Core::handFinalW, want));
        double got[3]; world_pos(sp, 13, got);
        const double target[3] = {want[12], want[13], want[14]};
        CHECK(dist(got, target) < 0.005);
        float gotWorld[16] = {}; G::mul(gotWorld, F.world + 13 * 16, W2);
        for (int row = 0; row < 3; ++row) {
          double ga[3] = {gotWorld[row * 4], gotWorld[row * 4 + 1], gotWorld[row * 4 + 2]};
          double wa[3] = {want[row * 4], want[row * 4 + 1], want[row * 4 + 2]};
          CHECK(arm::unit(ga, ga) && arm::unit(wa, wa)); CHECK(dist(ga, wa) < 0.005);
        }
      }
      lhLocal[7] = oldX;
    }
  }
  // Stress the shared solver over 10,000 frames: weapon lengths and native
  // poses change while turning; grip/release, missing tracking and absent
  // original pose alternate. The native grip must never change the gun hand,
  // and it must have no effect at all after its release blend reaches zero.
  {
    float savedW[16]; memcpy(savedW, W2, sizeof(savedW));
    float* leftLocal = (float*)(F.local + 13 * 40);
    const float savedLeftX = leftLocal[7];
    int heldChecks = 0, releaseChecks = 0;
    for (int frame = 0; frame < 10000; ++frame) {
      const double angle = ((frame * 37) % 360) * vm::kPi / 180.0;
      double axis[3] = {0, 1, 0}, rot[9]; weight::axis_angle(axis, angle, rot);
      const double scale = 0.85 + 0.35 * ((frame * 17) % 101) / 100.0;
      for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) W2[r * 4 + c] = (float)(scale * rot[c * 3 + r]);
      CHECK(sp.set(W2));
      leftLocal[7] = savedLeftX + (float)(((frame / 20) % 7 - 3) * 0.01);
      ArmTargets x = t;
      x.origOn = frame % 43 != 0; x.rightOn = frame % 37 != 0; x.leftOn = frame % 31 != 0;
      x.gripAtHand = 1; x.rdirOk = 1; x.stretchMax = 3.0;
      x.gunLenFt = frame % 47 == 0 ? 0.0 : 0.25 + (frame % 15) * 0.22;
      x.grabW = x.grabWrap = frame % 11 == 0 ? 0.0 : (frame % 5 == 0 ? 0.4 : 1.0);
      x.grabOn = x.grabW > 0.5; x.underW = x.grabW;
      for (int i = 0; i < 16; ++i) x.origBody[i] = W2[i];
      x.rdir[0] = rot[2]; x.rdir[1] = 0; x.rdir[2] = rot[8];
      x.rup[0] = 0; x.rup[1] = 1; x.rup[2] = 0;
      x.grip[0] = 5 + 0.6 * rot[0] + 0.8 * rot[2]; x.grip[1] = 3.8; x.grip[2] = 2 + 0.6 * rot[6] + 0.8 * rot[8];
      x.lpos[0] = x.grip[0] + 0.5 * x.rdir[0]; x.lpos[1] = 3.7; x.lpos[2] = x.grip[2] + 0.5 * x.rdir[2];
      float ref[N * 16];
      x.nativeSupport = 0;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      CHECK(Core::apply(actor, W2, &x) == (x.rightOn || x.leftOn)); memcpy(ref, F.world, sizeof(ref));
      x.nativeSupport = 1;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      CHECK(Core::apply(actor, W2, &x) == (x.rightOn || x.leftOn));
      for (int i = 0; i < N * 16; ++i) if ((i & 3) != 3) CHECK(vm::is_finite_f(F.world[i]));
      for (int b = 4; b <= 9; ++b) for (int i = 0; i < 16; ++i) if ((i & 3) != 3)
        CHECK(fabs_(F.world[b * 16 + i] - ref[b * 16 + i]) < 0.001);
      if (x.grabW == 1 && x.origOn && x.rightOn && x.leftOn && x.gunLenFt > 0.2) {
        float lp[16] = {}, rp[16] = {}, lw[16] = {}, rw[16] = {}, rel[16], want[16];
        CHECK(Core::pose_world(F.local, 13, lp)); CHECK(Core::pose_world(F.local, 7, rp));
        G::mul(lw, lp, W2); G::mul(rw, rp, W2);
        CHECK(handprop::relative(lw, rw, rel)); CHECK(handprop::place(rel, Core::handFinalW, want));
        double got[3]; world_pos(sp, 13, got); const double target[3] = {want[12], want[13], want[14]};
        CHECK(dist(got, target) < 0.005);
      }
      if (x.grabW == 0) {
        ++releaseChecks;
        for (int i = 0; i < N * 16; ++i) if ((i & 3) != 3) CHECK(fabs_(F.world[i] - ref[i]) < 0.001);
      } else ++heldChecks;
    }
    leftLocal[7] = savedLeftX; memcpy(W2, savedW, sizeof(savedW)); CHECK(sp.set(W2));
    printf("native support stress: 10000 frames, %d held/blending, %d fully released; gun hand unchanged\n", heldChecks, releaseChecks);
  }
  // wrong bone order (parent after child): refused, nothing written
  {
    Core::c.model = 0;                                    // force revalidation
    *(int*)(F.skel + 0x8c + 5 * 0x4c + 0x1c) = 9;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &t) == 0);
    *(int*)(F.skel + 0x8c + 5 * 0x4c + 0x1c) = 4;
  }
  // a skeleton without the arm bones (another model on the same code)
  {
    Core::c.model = 0;
    strncpy((char*)F.skel + 0x8c + 5 * 0x4c, "bone_xxx", 0x17);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    CHECK(Core::apply(actor, W2, &t) == 1);               // the left arm still works
    CHECK(Core::c.arm[0].U < 0 && Core::c.arm[1].U == 11);
  }
  if (!fails) printf("PASS armcore (logs=%d)\n", F.logs);
  return fails ? 1 : 0;
}
