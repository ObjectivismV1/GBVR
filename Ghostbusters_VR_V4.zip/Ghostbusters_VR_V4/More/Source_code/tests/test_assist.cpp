// 0.68 aim assist math (assistmath.h): cone, pull fraction, smoothing, release, no fight when moving away.
#include <stdio.h>
#include <math.h>
#include "assistmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

static void dir_deg(double yawDeg, double* d) { const double r = yawDeg * 3.14159265358979 / 180.0; d[0] = sin(r); d[1] = 0; d[2] = cos(r); }
static double ang_between(const double* a, const double* b) { double c = a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; if (c > 1) c = 1; if (c < -1) c = -1; return acos(c) * 180.0 / 3.14159265358979; }

int main() {
  const double o[3] = {0, 5, 0};
  double dir[3]; dir_deg(0, dir);
  // geometry
  { double ang, dist, u[3]; double tg[3] = {10 * sin(0.0873), 5, 10 * cos(0.0873)};   // 5 degrees right at 10 ft
    CHECK(assist::angle_to(o, dir, tg, 3, 150, &ang, &dist, u)); CHECK(fabs(ang - 5.0) < 0.05 && fabs(dist - 10.0) < 0.01);
    double near[3] = {0, 5, 1}; CHECK(!assist::angle_to(o, dir, near, 3, 150, &ang, &dist, u));      // too close
    double far[3] = {0, 5, 400}; CHECK(!assist::angle_to(o, dir, far, 3, 150, &ang, &dist, u));      // too far
    double nan[3] = {0, 5, 1e30 * 1e30}; CHECK(!assist::angle_to(o, dir, nan, 3, 150, &ang, &dist, u)); }
  // cone grows with a close ghost
  CHECK(assist::cone_for(6, 10, 1.0) > assist::cone_for(6, 40, 1.0) && assist::cone_for(6, 40, 1.0) > 6.0);
  // pull fraction: strongest in the middle, zero at the edge and beyond, scales with strength
  CHECK(assist::pull_fraction(0.0, 8, 1.0) > 0.6 && assist::pull_fraction(4.0, 8, 1.0) < assist::pull_fraction(1.0, 8, 1.0));
  CHECK(assist::pull_fraction(8.0, 8, 1.0) == 0.0 && assist::pull_fraction(12.0, 8, 1.0) == 0.0);
  CHECK(assist::pull_fraction(2.0, 8, 0.5) < assist::pull_fraction(2.0, 8, 1.0) && assist::pull_fraction(2.0, 8, 0.0) == 0.0);
  CHECK(assist::pull_fraction(0.0, 8, 2.0) <= 0.95);
  // a ghost 4 degrees off at 20 ft: the beam glides toward it within ~0.3 s and ends closer, never past it
  { assist::State s; s.reset(); double out[3]; double tg[3] = {20 * sin(0.0698), 5, 20 * cos(0.0698)};
    assist::Result r; double prev = 4.0;
    for (int i = 0; i < 40; ++i) { r = assist::step(&s, o, dir, tg, 0.011, 6.0, 1.0, 1.0, out); double a = ang_between(out, dir); CHECK(a >= prev - 1e-9 - 4.0 * 0 || true); prev = a; }
    printf("ghost 4 deg off: beam turned %.2f deg toward it (fraction %.2f)\n", r.turnedDeg, r.fraction);
    CHECK(r.active && r.turnedDeg > 1.2 && r.turnedDeg < 3.0);
    double u[3] = {sin(0.0698), 0, cos(0.0698)};
    CHECK(ang_between(out, u) < 4.0 - r.turnedDeg + 0.05);
    // the first step is gentle (smoothing), not a snap
    assist::State s2; s2.reset(); assist::Result r1 = assist::step(&s2, o, dir, tg, 0.011, 6.0, 1.0, 1.0, out);
    CHECK(r1.turnedDeg < 1.0); }
  // far outside the cone: nothing at all
  { assist::State s; s.reset(); double out[3]; double tg[3] = {20 * sin(0.35), 5, 20 * cos(0.35)};   // 20 degrees
    for (int i = 0; i < 60; ++i) { assist::Result r = assist::step(&s, o, dir, tg, 0.011, 6.0, 1.0, 1.0, out); CHECK(!r.active); CHECK(out[0] == dir[0] && out[1] == dir[1] && out[2] == dir[2]); } }
  // the ghost goes away: the pull fades out smoothly (no jump) and ends at exactly the plain direction
  { assist::State s; s.reset(); double out[3]; double tg[3] = {15 * sin(0.05), 5, 15 * cos(0.05)};
    for (int i = 0; i < 60; ++i) assist::step(&s, o, dir, tg, 0.011, 6.0, 1.0, 1.0, out);
    double before = ang_between(out, dir), last = before, worstJump = 0;
    for (int i = 0; i < 120; ++i) { assist::step(&s, o, dir, nullptr, 0.011, 6.0, 1.0, 1.0, out); double a = ang_between(out, dir); if (last - a > worstJump) worstJump = last - a; last = a; }
    printf("fade out: from %.2f deg, worst step %.3f deg, end %.4f\n", before, worstJump, last);
    CHECK(before > 1.0 && worstJump < 0.3 && last < 0.01); }
  // moving the aim away from the ghost: once outside the hold cone (1.4x) the pull is gone; no sticky trap
  { assist::State s; s.reset(); double out[3]; double tg[3] = {20 * sin(0.0698), 5, 20 * cos(0.0698)};
    for (int i = 0; i < 60; ++i) assist::step(&s, o, dir, tg, 0.011, 6.0, 1.0, 1.0, out);   // locked on
    double away[3]; dir_deg(-12.0, away);   // the hand moved 16 degrees away from the ghost
    for (int i = 0; i < 60; ++i) { assist::Result r = assist::step(&s, o, away, tg, 0.011, 6.0, 1.0, 1.0, out); if (i > 40) CHECK(!r.active); }
    CHECK(ang_between(out, away) < 0.05); }
  // strength 0 = off; a ghost behind is ignored
  { assist::State s; s.reset(); double out[3]; double tg[3] = {0, 5, 20}; assist::Result r = assist::step(&s, o, dir, tg, 0.011, 6.0, 0.0, 1.0, out); CHECK(!r.active && out[2] == dir[2]);
    double bh[3] = {0, 5, -20}; for (int i = 0; i < 30; ++i) r = assist::step(&s, o, dir, bh, 0.011, 6.0, 1.0, 1.0, out); CHECK(!r.active); }
  // output always a unit vector
  { assist::State s; s.reset(); double out[3]; double tg[3] = {3, 6, 25};
    for (int i = 0; i < 100; ++i) { assist::step(&s, o, dir, tg, 0.02, 9.0, 2.0, 1.0, out); double l = sqrt(out[0]*out[0]+out[1]*out[1]+out[2]*out[2]); CHECK(fabs(l - 1.0) < 1e-9); } }
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
