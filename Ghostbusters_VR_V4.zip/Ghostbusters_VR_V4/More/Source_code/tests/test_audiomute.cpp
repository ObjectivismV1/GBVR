// 1.7.88: when the mod may silence the game's own sound (src/audiomath.h).
#include "audiomath.h"
#include <cassert>

int main() {
  using audio::want_mute;
  // the user's setup: song file there, mute setting on, menu open -> silenced (unchanged behaviour)
  assert(want_mute(1, 1, 1, 0) == 1);
  // no song file (the public download has none): nothing would replace the game's sound, so it is never touched
  assert(want_mute(1, 1, 0, 0) == 0);
  // the song could not be started (device refused it, bad file): sound comes back
  assert(want_mute(1, 1, 1, 1) == 0);
  // menu closed or the setting off: not silenced
  assert(want_mute(0, 1, 1, 0) == 0);
  assert(want_mute(1, 0, 1, 0) == 0);
  // the audio thread is only worth starting when there is something to do with it
  using audio::thread_needed;
  assert(thread_needed(1, 1, 1, 1) == 1);     // menu opening, music on, song present
  assert(thread_needed(1, 0, 1, 1) == 1);     // music off but the mute setting on and a song file present: as before
  assert(thread_needed(1, 1, 1, 0) == 0);     // no song file: no thread, no audio calls at all
  assert(thread_needed(1, 0, 0, 1) == 0);     // both off
  assert(thread_needed(0, 1, 1, 1) == 0);     // menu closing: nothing to start
  return 0;
}
