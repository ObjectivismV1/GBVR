// 1.7.220: the roof auto-centre (sceneview::AutoCenter): fires once per fight, only after 2 s, only when the head rests 12+ deg off, never while turning, never when off or with garbage input.
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include "../src/vmath.h"
#include "../src/stereomath.h"
#include "../src/sceneviewmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { ++fails; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static const double D = 3.14159265358979 / 180.0;
static int run(sceneview::AutoCenter& a, double t0, double t1, uintptr_t boss, double stY, double head, double face, int on, double turnRate = 0) {
  int fired = 0; double o, r, g; double h = head;
  for (double t = t0; t < t1; t += 0.011) { h += turnRate * D * 0.011; fired += a.step(t, boss, stY, h, face, on, &o, &r, &g); }
  return fired;
}
int main() {
  { sceneview::AutoCenter a; a.reset(); CHECK(run(a, 0, 1.9, 1, 0.5, 20 * D, 0, 1) == 0); }                 // too early
  { sceneview::AutoCenter a; a.reset(); CHECK(run(a, 0, 6, 1, 0.5, 20 * D, 0, 1) == 1); }                   // 20 deg off at rest: once
  { sceneview::AutoCenter a; a.reset(); CHECK(run(a, 0, 60, 1, 0.5, 20 * D, 0, 1) == 1); }                  // never twice
  { sceneview::AutoCenter a; a.reset(); CHECK(run(a, 0, 6, 1, 0.5, 8 * D, 0, 1) == 0); }                    // only 8 deg off: nothing
  { sceneview::AutoCenter a; a.reset(); CHECK(run(a, 0, 6, 1, 0.5, 20 * D, 0, 0) == 0); }                   // setting off
  { sceneview::AutoCenter a; a.reset(); CHECK(run(a, 0, 6, 1, 0.5, 20 * D, 0, 1, 40) == 0); }               // head turning 40 deg/s: wait
  { sceneview::AutoCenter a; a.reset(); CHECK(run(a, 0, 6, 1, 0.5, -170 * D, 175 * D, 1) == 1); }   // 15 deg apart across the +-180 seam: fires
  { sceneview::AutoCenter a; a.reset(); int f = run(a, 0, 6, 1, 0.5, 20 * D, 0, 1); f += run(a, 6, 12, 2, 0.5, 20 * D, 0, 1); CHECK(f == 2); }   // new boss: again
  { sceneview::AutoCenter a; a.reset(); int f = run(a, 0, 6, 1, 0.5, 20 * D, 0, 1); f += run(a, 6, 12, 1, 0.9, 20 * D, 0, 1); CHECK(f == 1); }  // re-placed: count stays (once per fight)
  { sceneview::AutoCenter a; a.reset(); const double nan = std::nan(""); CHECK(run(a, 0, 6, 1, 0.5, nan, 0, 1) == 0); CHECK(run(a, 6, 12, 1, 0.5, 20 * D, nan, 1) == 0); }
  { sceneview::AutoCenter a; a.reset(); int f = 0; double o, r, g; std::srand(11);   // a head resting 20 deg off whose heading jitters +-4 deg every frame (looking almost straight down): still fires, within 4 s of placement
    double firstAt = -1; for (double t = 0; t < 8; t += 0.011) { const double h = 20 * D + ((std::rand() % 2001) - 1000) * 0.001 * 4 * D; if (a.step(t, 1, 0.5, h, 0, 1, &o, &r, &g)) { ++f; if (firstAt < 0) firstAt = t; } }
    CHECK(f == 1); CHECK(firstAt > 1.9 && firstAt < 4.0); }
  { sceneview::AutoCenter a; a.reset(); int f = 0; double o, r, g; for (double t = 0; t < 12; t += 0.011) f += a.step(t, 1, 0.5, 20 * D + 30 * D * std::sin(t * 2.0), 0, 1, &o, &r, &g); CHECK(f == 0); }   // a head swinging 30 deg at 1 Hz never counts as resting
  std::srand(3); for (int i = 0; i < 20000; ++i) { sceneview::AutoCenter a; a.reset(); double o, r, g; for (int k = 0; k < 40; ++k) { double h = (std::rand() % 2000 - 1000) * 1e3, f = (std::rand() % 2000 - 1000) * 1e-2; a.step(k * 0.1, 1, 0.5, h, f, 1, &o, &r, &g); } }
  std::printf(fails ? "test_autocenter FAILED %d\n" : "test_autocenter ok\n", fails); return fails ? 1 : 0;
}
