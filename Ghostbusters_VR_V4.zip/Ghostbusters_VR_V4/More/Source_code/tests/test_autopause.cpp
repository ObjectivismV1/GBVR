#include <stdio.h>
#include "autopausemath.h"
using namespace autop;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  Pauser p; p.reset();
  // nothing happens without an event
  CHECK(p.update(1000, 0, 1, 1) == 0 && !p.held(1000));
  // event while running -> Start held for 180 ms
  CHECK(p.update(2000, 1, 1, 1) == 1);
  CHECK(p.held(2000) && p.held(2100) && !p.held(2200));
  p.update(2200, 1, 1, 1);
  CHECK(p.phase == 2);
  // game stopped -> success
  CHECK(p.update(3500, 1, 0, 1) == 5 && p.paused == 1 && p.phase == 0 && p.lastResult == 1);
  // event while the game is paused: nothing pressed
  CHECK(p.update(4000, 2, 0, 1) == 3 && !p.held(4000) && p.skipNotRunning == 1);
  // switched off
  CHECK(p.update(5000, 3, 1, 0) == 2 && p.skipOff == 1 && p.phase == 0);
  // game ignores the press: retried twice, then gives up (3 tries in all)
  Pauser q; q.reset();
  q.update(1000, 1, 1, 1);
  q.update(1200, 1, 1, 1);
  CHECK(q.update(2400, 1, 1, 1) == 6 && q.tries == 2 && q.held(2400));
  q.update(2600, 1, 1, 1);
  CHECK(q.update(3800, 1, 1, 1) == 6 && q.tries == 3);
  q.update(4000, 1, 1, 1);
  CHECK(q.update(5200, 1, 1, 1) == 7 && q.failed == 1 && q.lastResult == 2 && q.phase == 0);
  // a second event during an attempt does not start another one
  Pauser r; r.reset();
  r.update(1000, 1, 1, 1);
  CHECK(r.update(1050, 2, 1, 1) == 4 && r.skipBusy == 1 && r.started == 1);
  // wrap of the millisecond counter
  Pauser w; w.reset();
  uint32_t t0 = 0xFFFFFF00u;
  CHECK(w.update(t0, 1, 1, 1) == 1);
  CHECK(w.held(t0 + 100));
  CHECK(!w.held(t0 + 200));
  w.update(t0 + 200, 1, 1, 1);
  CHECK(w.update(t0 + 200 + 1200, 1, 0, 1) == 5);
  // running detection
  CHECK(!running_from_stamp(1000, 0));
  CHECK(running_from_stamp(1000, 800));
  CHECK(!running_from_stamp(1000, 500));
  CHECK(running_from_stamp(100, 0xFFFFFFF0u) == 1);
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
