#include <stdio.h>
#include "barlifemath.h"
int main() {
  barlife::Ledger l;
  l.begin(100);
  if (l.finished(200)) return 1;  // live actor isn't hidden
  l.caught(200);
  if (!l.finished(200)) return 2;
  for (int i=0;i<1000;++i) { l.begin(100); if (!l.finished(200)) return 3; }
  l.begin(100); l.begin(100);  // actor absent for a completed scan
  if (l.finished(200)) return 4; // pointer reuse is not a trapped ghost
  l.caught(200); l.begin(101);
  if (l.finished(200)) return 5; // a new world forgets old objects
  puts("PASS barlife");
}
