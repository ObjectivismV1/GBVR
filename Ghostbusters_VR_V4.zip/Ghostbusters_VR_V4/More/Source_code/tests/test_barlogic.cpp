// 1.7.30 smart health bars (barlogic.h): seen-once latch, self-check of the drawn test, forgetting, the trapped latch.
#include <stdio.h>
#include "barlogic.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  using namespace barlogic;
  // trust: fine at the start, lost after many fails with (almost) no passes, regained when it passes
  CHECK(trust_drawn(0, 0) == 1); CHECK(trust_drawn(0, 11) == 1); CHECK(trust_drawn(0, 12) == 0); CHECK(trust_drawn(1, 12) == 0);
  CHECK(trust_drawn(2, 12) == 1); CHECK(trust_drawn(50, 300) == 1); CHECK(trust_drawn(3, 300) == 0);
  // seen: not drawn -> no bar yet; drawn -> latched; stays after it stops being drawn (behind a wall)
  int seen = 0;
  seen = seen_step(seen, 0, 0, 1); CHECK(seen == 0);
  seen = seen_step(seen, 1, 0, 1); CHECK(seen == 1);
  seen = seen_step(seen, 0, 0, 1); CHECK(seen == 1);
  // a hit or the capture stream make a ghost seen at once
  CHECK(seen_step(0, 0, 1, 1) == 1);
  // an untrusted or unreadable test falls back to "active = bar"
  CHECK(seen_step(0, 0, 0, 0) == 1); CHECK(seen_step(0, -1, 0, 1) == 1);
  // forgetting: 2 s of neither active nor drawn clears the latch; a blink does not; drawing or being active resets the timer
  { int64_t iq = 0; const int64_t f = 1000; int s = 1;
    s = forget_step(s, 0, 0, &iq, 1000, f, 2.0); CHECK(s == 1 && iq == 1000);
    s = forget_step(s, 0, 0, &iq, 2500, f, 2.0); CHECK(s == 1);
    s = forget_step(s, 1, 0, &iq, 2600, f, 2.0); CHECK(s == 1 && iq == 0);
    s = forget_step(s, 0, 0, &iq, 3000, f, 2.0); CHECK(s == 1 && iq == 3000);
    s = forget_step(s, 0, 0, &iq, 5100, f, 2.0); CHECK(s == 0);
    iq = 0; s = 1; s = forget_step(s, 0, 1, &iq, 6000, f, 2.0); CHECK(s == 1 && iq == 0);   // drawn counts as there
  }
  // trap: a floor trap vs a carried one
  { float pl[3] = {0, 0, 0}, tr[3] = {5, 0.3f, 0}, car[3] = {0.5f, 2.8f, 0.2f};
    CHECK(trap_on_floor(tr, pl) == 1); CHECK(trap_on_floor(car, pl) == 0); }
  // trapped latch: held and within 4 ft of a trap on the floor -> latched; not held or not near -> not; leaves when it is 8 ft away from the anchor
  { float anc[3] = {0, 0, 0}, tp[3] = {10, 0.2f, 0}, g1[3] = {12, 1.0f, 0.5f}, g2[3] = {30, 1.0f, 0.5f}, g3[3] = {19.5f, 1.0f, 0.5f};
    CHECK(trap_step(0, anc, 1, 1, tp, g1, 4.0, 8.0) == 1 && anc[0] == 12.0f);
    CHECK(trap_step(0, anc, 0, 1, tp, g1, 4.0, 8.0) == 0);                       // not held: nothing latches
    CHECK(trap_step(0, anc, 1, 0, tp, g1, 4.0, 8.0) == 0);                       // trap is carried: nothing latches
    CHECK(trap_step(0, anc, 1, 1, tp, g2, 4.0, 8.0) == 0);                       // held but far from the trap
    anc[0] = 12; anc[1] = 1; anc[2] = 0.5f;
    CHECK(trap_step(1, anc, 0, 1, tp, g1, 4.0, 8.0) == 1);                       // stays latched without the stream
    CHECK(trap_step(1, anc, 0, 1, tp, g3, 4.0, 8.0) == 1);                       // 8 ft away is the limit
    CHECK(trap_step(1, anc, 0, 1, tp, g2, 4.0, 8.0) == 0);                       // got away: released
  }
  // ---- 1.7.31 ----
  // trap_step2: the ghost hovers above the trap (3D distance would be too big), measured along the floor
  { float anc[3] = {0, 0, 0}, tp[3] = {10, 0.2f, 0}, hover[3] = {11.5f, 7.0f, 0.5f}, onTop[3] = {10.5f, 2.0f, 0.2f}, hoverFar[3] = {14.5f, 7.0f, 0.5f}, tooHigh[3] = {11.0f, 20.0f, 0.0f}, below[3] = {10.5f, -6.0f, 0.0f};
    CHECK(dist_xz(hover, tp) < 2.0 && dist3(hover, tp) > 6.0);                                                  // the 1.7.30 3D rule would have said "far"
    CHECK(trap_step2(0, anc, 1, 1, 1, tp, hover, 3.0, 1.5, 14.0, 8.0) == 1 && anc[0] == 11.5f);                 // held + capture button + near along the floor -> latched
    CHECK(trap_step2(0, anc, 0, 1, 1, tp, hover, 3.0, 1.5, 14.0, 8.0) == 0);                                    // not the ghost you hold: not latched (1.5 ft is the on-top circle: it is 1.58 ft away)
    CHECK(trap_step2(0, anc, 1, 0, 1, tp, hover, 3.0, 1.5, 14.0, 8.0) == 0);                                    // capture not pressed lately: not latched
    CHECK(trap_step2(0, anc, 0, 0, 1, tp, onTop, 3.0, 1.5, 14.0, 8.0) == 1);                                    // right on top of the trap: latched whatever the stream does
    CHECK(trap_step2(0, anc, 1, 1, 0, tp, onTop, 3.0, 1.5, 14.0, 8.0) == 0);                                    // the trap is carried: nothing
    CHECK(trap_step2(0, anc, 1, 1, 1, tp, hoverFar, 3.0, 1.5, 14.0, 8.0) == 0);                                 // 4.5 ft along the floor: too far
    CHECK(trap_step2(0, anc, 1, 1, 1, tp, tooHigh, 3.0, 1.5, 14.0, 8.0) == 0);                                  // 20 ft above: outside the height window
    CHECK(trap_step2(0, anc, 1, 1, 1, tp, below, 3.0, 1.5, 14.0, 8.0) == 0);                                    // under the floor of the trap: no
    anc[0] = 11.5f; anc[1] = 7.0f; anc[2] = 0.5f;
    CHECK(trap_step2(1, anc, 0, 0, 1, tp, hover, 3.0, 1.5, 14.0, 8.0) == 1);                                    // stays latched on its own
    float away[3] = {25.0f, 7.0f, 0.5f};
    CHECK(trap_step2(1, anc, 0, 0, 1, tp, away, 3.0, 1.5, 14.0, 8.0) == 0);                                     // got away (13.5 ft along the floor from where it was caught)
  }
  // vanish_step: the timer needs an unbroken run
  { int64_t sq = 0; const int64_t f = 1000;
    CHECK(vanish_step(&sq, 1, 1000, f, 1.0) == 0 && sq == 1000);
    CHECK(vanish_step(&sq, 1, 1900, f, 1.0) == 0);
    CHECK(vanish_step(&sq, 1, 2000, f, 1.0) == 1);
    CHECK(vanish_step(&sq, 0, 2100, f, 1.0) == 0 && sq == 0);                                                    // drawn again (or line blocked): restart
    CHECK(vanish_step(&sq, 1, 2200, f, 1.0) == 0 && sq == 2200);
  }
  // vanish_trusted: needs 200 samples before it can switch itself off; half of the in-view samples must be "drawn"
  CHECK(vanish_trusted(0, 0) == 1); CHECK(vanish_trusted(0, 150) == 1); CHECK(vanish_trusted(0, 250) == 0);
  CHECK(vanish_trusted(125, 125) == 1); CHECK(vanish_trusted(124, 126) == 0); CHECK(vanish_trusted(300, 100) == 1);
  // in_cone: straight ahead yes, 20 deg yes, 40 deg no, behind no
  { float a[3] = {0, 0, 10}, b[3] = {3.64f, 0, 10}, c[3] = {8.4f, 0, 10}, d[3] = {0, 0, -5}, e[3] = {0, 0, 0.2f};
    CHECK(in_cone(a, 30.0) == 1); CHECK(in_cone(b, 30.0) == 1); CHECK(in_cone(c, 30.0) == 0); CHECK(in_cone(d, 30.0) == 0); CHECK(in_cone(e, 30.0) == 0); }
  CHECK(bar_allowed(1, 0) == 1); CHECK(bar_allowed(0, 0) == 0); CHECK(bar_allowed(1, 1) == 0);
  printf(fails ? "FAILED %d\n" : "PASS test_barlogic\n", fails);
  return fails ? 1 : 0;
}
