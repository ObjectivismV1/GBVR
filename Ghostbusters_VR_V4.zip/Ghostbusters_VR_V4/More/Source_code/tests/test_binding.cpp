#include <assert.h>
#include <stdio.h>
#include "bindingmath.h"
#include "padmath.h"
#include "gearmath.h"

int main() {
  pad::Config cfg = {18, 0, 1, 0, 1};
  pad::Hand left = {}, right = {};
  left.valid = right.valid = 1;
  right.trigger = 1; right.pressed = 1ull << pad::kVrStick; // current layout: hold Capture on right-stick click
  binding::Action capture, fire;
  gear::TrigSlam slam = {}; slam.reset();
  gear::PullDir pull = {}; pull.reset();
  int presses = 0, slams = 0;
  for (int i = 0; i < 600; ++i) {
    left.trigger = i < 30 ? 0.0f : i < 180 ? 0.55f : 1.0f;
    pad::State state = pad::build(left, right, cfg);
    const unsigned mask = pad::game_button_mask(state.buttons, state.lt, state.rt);
    capture.step((mask & (1u << 6)) != 0, 1.0f / 90);
    fire.step((mask & (1u << 5)) != 0, 1.0f / 90);
    presses += capture.query(2);
    assert(fire.query(0));
    if (i >= 30) assert(capture.query(0));
    if (i > 30) assert(!capture.query(2));
    // Even if the native binding buffer is reset every frame, this history
    // keeps capture down; a full squeeze still uses the native slam helper.
    double x = 0, y = 0; int force = 0, start = 0, denied = 0, ping = 0;
    const int extraFire = slam.update(1.0 / 90, left.trigger, capture.query(0), 1, 1, 0.90,
                                    pull, &x, &y, &force, &start, &denied, &ping);
    assert(!extraFire && !slam.releaseNow);
    slams += start;
    if (i < 180) assert(!start);
  }
  assert(presses == 1 && slams == 1); // holding the full squeeze never repeats it
  capture.step(false, 1.0f / 90);
  assert(capture.query(1) && !capture.query(0));
  capture.step(false, 1.0f / 90);
  assert(!capture.query(1));
  capture.step(true, 1.0f / 90);
  assert(capture.query(2));
  puts("PASS binding: right-click capture + left-trigger alt fire, single edge, native slam coexistence");
}
