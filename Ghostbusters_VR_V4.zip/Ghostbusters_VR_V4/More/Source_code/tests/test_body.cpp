#include <stdio.h>
#include <math.h>
#include "bodymath.h"
using namespace body;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static int near(double a, double b, double e = 1e-3) { return fabs(a - b) <= e; }
int main() {
  // torso: stays inside the dead zone, follows beyond it
  Torso t; t.reset();
  double dead = 20.0 * 3.14159265 / 180.0;
  for (int i = 0; i < 200; ++i) t.step(0.2, 0.011, dead, 0.25);
  CHECK(near(t.yaw, 0.0));
  for (int i = 0; i < 600; ++i) t.step(1.0, 0.011, dead, 0.25);
  CHECK(near(t.yaw, 1.0 - dead, 0.02));                 // settles at head minus dead zone
  for (int i = 0; i < 600; ++i) t.step(-1.0, 0.011, dead, 0.25);
  CHECK(near(t.yaw, -1.0 + dead, 0.02));
  // one frame moves only a part of the way (lag)
  Torso u; u.reset(); u.step(1.0, 0.011, dead, 0.25);
  CHECK(u.yaw > 0 && u.yaw < 0.05);
  // wrap: head looks behind, torso goes the short way and stops at the limit
  Torso w; w.reset();
  for (int i = 0; i < 2000; ++i) w.step(3.0, 0.011, dead, 0.25);
  CHECK(w.yaw <= 2.3 + 1e-9 && w.yaw > 2.0);
  CHECK(near(one_minus_exp(0.0), 0.0) && near(one_minus_exp(1.0), 0.6321, 2e-3) && near(one_minus_exp(10.0), 1.0));
  // The full chest leaves the eye's near field on a steep look down, and
  // returns with a gap so a small head tremor cannot toggle it every frame.
  CHECK(chest_occluded_step(0, -0.50, 0.866) == 0);
  CHECK(chest_occluded_step(0, -0.80, 0.60) == 1);
  CHECK(chest_occluded_step(1, -0.70, 0.714) == 1);
  CHECK(chest_occluded_step(1, -0.50, 0.866) == 0);
  CHECK(chest_occluded_step(0, -1.0, 0.0) == 1);
  CHECK(chest_occluded_step(1, 1.0, 0.0) == 0);
  // placement: forward (0,0,1) at 90 degrees points to +x
  float feet[3] = {10, 2, -5}, off[3] = {1, 0, 0.5f};
  Xf x; x.set(1.0, 3.14159265358979 / 2, feet, off);
  float p[3] = {10, 2, -4}, o[3];
  x.point(p, o);
  CHECK(near(o[0], 10 + 1 + 1) && near(o[1], 2) && near(o[2], -5 + 0.5));
  // scale about the feet: a point 4 ft up goes to 4*s
  x.set(1.25, 0.0, feet, off);
  float q[3] = {10, 6, -5};
  x.point(q, o);
  CHECK(near(o[0], 10 + 1) && near(o[1], 2 + 4 * 1.25) && near(o[2], -5 + 0.5));
  // matrix: a world matrix with identity rotation at the feet; after yaw 90 the first row (x axis) points to -z
  float W[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 10,2,-5,1}, M[16];
  x.set(1.0, 3.14159265358979 / 2, feet, off);
  x.matrix(W, M);
  CHECK(near(M[0], 0) && near(M[2], -1));       // x axis -> -z
  CHECK(near(M[8], 1) && near(M[10], 0));       // z axis -> +x
  CHECK(near(M[12], 11) && near(M[13], 2) && near(M[14], -4.5) && near(M[15], 1));
  // Cutscene fade across a half-turn must keep a full-length orthogonal body
  // basis. Elementwise matrix averaging would collapse its X/Z rows at 50%.
  x.set_blend(1.10, 3.14159265358979, feet, off, 0.5);
  x.matrix(W, M);
  CHECK(near(sqrt(M[0]*M[0] + M[2]*M[2]), 1.05, 1e-3));
  CHECK(near(sqrt(M[8]*M[8] + M[10]*M[10]), 1.05, 1e-3));
  CHECK(near(M[0]*M[8] + M[2]*M[10], 0.0, 1e-3));
  x.set_blend(1.10, 3.14159265358979, feet, off, 1.0);
  x.matrix(W, M);
  CHECK(near(M[0], 1.0) && near(M[12], W[12]));
  // scaled matrix has scaled axes
  x.set(0.9, 0.0, feet, off);
  x.matrix(W, M);
  CHECK(near(M[0], 0.9) && near(M[5], 0.9) && near(M[10], 0.9));
  // scale from eye heights
  CHECK(near(body_scale(6.05, 5.5), 1.1, 1e-6));
  CHECK(near(body_scale(1.0, 5.5), 0.85) && near(body_scale(20.0, 5.5), 1.2) && near(body_scale(0.0, 5.5), 1.0));
  // calibration: 1.70 m eye height, world factor 0.87, nominal eye 5.5 ft
  int pct = size_pct_for(1.70, 100.0 / 115.0, 5.5);
  CHECK(pct >= 86 && pct <= 90);
  CHECK(size_pct_for(0.2, 1.0, 5.5) == 0);
  CHECK(size_pct_for(2.6, 1.0, 5.5) == 120 && size_pct_for(0.9, 1.0, 5.5) == 85);
  // gesture: needs the hold, reports the median
  Calib c; c.reset();
  double med = 0;
  int ev = 0, done = 0;
  for (int i = 0; i < 200 && !done; ++i) { ev = c.update(11.0, 1, 1.70 + (i % 5) * 0.001, &med); if (ev == 2) done = 1; }
  CHECK(done && near(med, 1.702, 0.01));
  CHECK(c.update(11.0, 1, 1.7, &med) == 0);        // holding on after done does nothing
  CHECK(c.update(11.0, 0, 1.7, &med) == 0);        // letting go after done: no cancel message
  CHECK(c.update(11.0, 1, 1.7, &med) == 1);        // a new hold starts again
  CHECK(c.update(11.0, 0, 1.7, &med) == 3);        // let go early: cancelled
  // too few samples (the head was not tracked) -> cancelled, never a bogus height
  Calib d; d.reset();
  int last = 0;
  for (int i = 0; i < 400; ++i) { int e = d.update(11.0, 1, 0.0, &med); if (e) last = e; }
  CHECK(last == 3);
  // 1.7.13: a head that moves a lot during the hold is refused, a steady one reports the upper quarter
  Calib e; e.reset(); int lastE = 0;
  for (int i = 0; i < 400; ++i) { int ev2 = e.update(11.0, 1, 1.40 + (i % 40) * 0.01, &med); if (ev2) lastE = ev2; }
  CHECK(lastE == 3);
  // 1.7.110 height meter: the steadiest second counts, not everything seen
  {
    Calib g; g.reset(); int dn = 0; double mv = 0;
    for (int i = 0; i < 600 && !dn; ++i) {   // 0.8 s of settling (a dip from 1.55 up to 1.70), then standing steady at 1.70
      const double tms = i * 11.0;
      const double y = tms < 800.0 ? 1.55 + 0.15 * (tms / 800.0) : 1.70 + ((i * 7) % 5) * 0.002;
      if (g.update(11.0, 1, y, &mv) == 2) dn = 1;
    }
    CHECK(dn && near(mv, 1.70, 0.012));
    Calib h; h.reset(); dn = 0; mv = 0;
    for (int i = 0; i < 600 && !dn; ++i) {   // one high spike (a glance up / tracking glitch) must not raise it
      const double y = 1.70 + ((i * 3) % 4) * 0.003 + (i == 80 ? 0.12 : 0.0);
      if (h.update(11.0, 1, y, &mv) == 2) dn = 1;
    }
    CHECK(dn && near(mv, 1.70, 0.012));
    Calib k; k.reset(); dn = 0; mv = 0; int refused = 0;   // slow constant sway of 6 cm: accepted only at the end (3.5 s), as a loose measure
    for (int i = 0; i < 400 && !dn && !refused; ++i) { const int r = k.update(11.0, 1, 1.70 + 0.03 * ((i % 90) < 45 ? -1.0 : 1.0) * 0.95, &mv); if (r == 2) dn = 1; if (r == 3) refused = 1; }
    CHECK(dn || refused);
    Calib q; q.reset(); dn = 0; int rf = 0;   // a head that keeps moving 15 cm is refused
    for (int i = 0; i < 400 && !dn && !rf; ++i) { const int r = q.update(11.0, 1, 1.70 + 0.075 * ((i % 40) < 20 ? -1.0 : 1.0), &mv); if (r == 2) dn = 1; if (r == 3) rf = 1; }
    CHECK(rf && !dn);
    // steady: finishes by 1.7 s, not later
    Calib f2; f2.reset(); int tdone = -1; for (int i = 0; i < 600 && tdone < 0; ++i) if (f2.update(11.0, 1, 1.65, &mv) == 2) tdone = i;
    CHECK(tdone > 0 && tdone * 11 <= 1700 && tdone * 11 >= 1400);
  }
  // 1.7.17: the measure matches the WORLD to the player, never lowers the view
  CHECK(world_pct_for(1.613, 5.5) == 96);            // the 1.7.16 report: 161 cm
  CHECK(world_pct_for(1.93, 5.5) == 115);            // a tall player lands on the old default
  CHECK(world_pct_for(1.2, 5.5) == 90 && world_pct_for(2.3, 5.5) == 125);   // clamped
  CHECK(world_pct_for(0.2, 5.5) == 0 && world_pct_for(1.7, 0.5) == 0);
  // 1.7.99 scale_hold: no scale yet = the target at once; a small drift is ignored; a lasting one is followed slowly
  CHECK(near(scale_hold(0.0, 1.07, 0.016), 1.07));
  CHECK(near(scale_hold(1.00, 1.01, 0.016), 1.00) && near(scale_hold(1.00, 0.99, 0.016), 1.00));
  CHECK(near(scale_hold(1.00, 1.10, 1.0), 1.00));                                  // a gap in the frames (dt 1 s) moves nothing
  CHECK(near(scale_hold(1.00, 1.10, 0.1), 1.0002, 1e-9) && near(scale_hold(1.00, 0.90, 0.1), 0.9998, 1e-9));
  { double v = 1.00; for (int i = 0; i < 100000 && !(v >= 1.10); ++i) v = scale_hold(v, 1.10, 0.016); CHECK(v >= 1.0 && v <= 1.10 + 1e-9); CHECK(near(scale_hold(1.10, 1.10, 0.016), 1.10)); }
  { double v = 1.00; for (int i = 0; i < 100; ++i) v = scale_hold(v, 1.10, 0.016); CHECK(v > 1.0 && v < 1.02); }   // 1.6 s = 1.6 %: a slow glide
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
