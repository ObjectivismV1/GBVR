// 1.7.167 the chest turns toward the hands (bodymath.h hands_yaw) and the hand balls that hide the gun tube (the HLSL hid(), mirrored here)
#include <cstdio>
#include <cmath>
#include "bodymath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static const double D = 3.14159265358979 / 180.0;
// a head pose looking at engine yaw y (tracking: forward = -z turned), at (0,1.6,0); hands at a direction a (engine yaw) and distance r
static void head(double y, float* h) { const double s = sin(y), c = cos(y); float m[12] = {(float)c, 0, (float)s, 0, 0, 1, 0, 1.6f, (float)-s, 0, (float)c, 0};
  // forward (-z column) = (-s, 0, -c)... engine yaw of that = atan2(-s, c)? we want atan2(fx, -fz) = y: fx = sin y, fz = -cos y => -z column = (sin y, 0, -cos y) => z column = (-sin y, 0, cos y)
  m[2] = (float)-s; m[10] = (float)c; m[0] = (float)c; m[8] = (float)s; for (int i = 0; i < 12; ++i) h[i] = m[i]; }
static void handAt(double a, double r, double side, float* p) { for (int i = 0; i < 12; ++i) p[i] = 0; p[0] = p[5] = p[10] = 1;
  p[3] = (float)(sin(a) * r + cos(a) * side); p[7] = 1.1f; p[11] = (float)(-cos(a) * r + sin(a) * side); }
static double hid(const double* e, const double* S) { if (S[3] <= 0) return 0; const double ee = e[0]*e[0]+e[1]*e[1]+e[2]*e[2]; const double t = (S[0]*e[0]+S[1]*e[1]+S[2]*e[2]) / (ee > 1e-6 ? ee : 1e-6);
  if (t <= 0 || t >= 1) return 0; double q2 = 0; for (int k = 0; k < 3; ++k) { const double d = e[k]*t - S[k]; q2 += d*d; } return q2 < S[3]*S[3] ? 1 : 0; }
int main() {
  float H[12], L[12], R[12]; double w = 0;
  for (int hy = -170; hy <= 180; hy += 10) {
    head(hy * D, H);
    handAt(hy * D, 0.45, -0.15, L); handAt(hy * D, 0.45, 0.15, R);   // hands straight ahead
    double y = body::hands_yaw(0.3, H, L, R, &w); CHECK(fabs(y - 0.3) < 1e-6 && w > 0.4);
    handAt((hy + 40) * D, 0.45, -0.15, L); handAt((hy + 40) * D, 0.45, 0.15, R);   // hands 40 deg to one side: the chest follows 45 % of it
    y = body::hands_yaw(0.3, H, L, R, &w); CHECK(fabs(body::wrap_pi(y - 0.3) - 0.45 * 40 * D) < 0.02);
    handAt((hy - 40) * D, 0.45, -0.15, L); handAt((hy - 40) * D, 0.45, 0.15, R);
    y = body::hands_yaw(0.3, H, L, R, &w); CHECK(fabs(body::wrap_pi(y - 0.3) + 0.45 * 40 * D) < 0.02);
    handAt((hy + 180) * D, 0.45, -0.15, L); handAt((hy + 180) * D, 0.45, 0.15, R);   // hands behind you: nothing
    y = body::hands_yaw(0.3, H, L, R, &w); CHECK(y == 0.3 && w == 0.0);
    handAt(hy * D, 0.08, -0.03, L); handAt(hy * D, 0.08, 0.03, R);   // hands against the chest: nothing
    y = body::hands_yaw(0.3, H, L, R, &w); CHECK(w == 0.0);
  }
  { float B[12]; for (int i = 0; i < 12; ++i) B[i] = L[i]; B[3] = NAN; double y = body::hands_yaw(0.3, H, B, R, &w); CHECK(y == 0.3 || (y == y)); }
  { float U[12] = {1, 0, 0, 0, 0, 0, 1, 1.6f, 0, -1, 0, 0}; handAt(0, 0.45, -0.1, L); handAt(0, 0.45, 0.1, R); double y = body::hands_yaw(0.3, U, L, R, &w); CHECK(y == 0.3); }   // looking straight down
  // hand balls: a hand 30 cm away right in front of a tube 50 cm away hides it; beside it, behind it, or the tube in front of the hand: not hidden
  { const double tube[3] = {0.0, -0.1, 0.5}; double S[4] = {0.0, -0.06, 0.3, 0.07};
    CHECK(hid(tube, S) == 1);
    S[0] = 0.2; CHECK(hid(tube, S) == 0);
    S[0] = 0.0; S[2] = 0.7; S[1] = -0.14; CHECK(hid(tube, S) == 0);
    const double near[3] = {0.0, -0.05, 0.25}; S[2] = 0.3; S[1] = -0.06; CHECK(hid(near, S) == 0);
    S[3] = 0; CHECK(hid(tube, S) == 0); }
  printf("%s body follows hands / hand balls, %d failures\n", fails ? "FAIL" : "PASS", fails);
  return fails ? 1 : 0;
}
