// Tests for src/boostmath.h (1.7.8 / 1.7.9 sprint as a plain speed boost) and the stick rotation in src/followmath.h.
#include <stdio.h>
#include <math.h>
#include "boostmath.h"
#include "followmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

// A fake game: plain speed `base` ft/s at a full stick; method `works` multiplies it by the asked k, the others do nothing.
struct Fake {
  boost::State s; boost::Cfg c; double base = 7.4; int works = boost::kVelocity; int worksAlso = -1; double t = 0, dt = 0.011; int sprintOn = 0;
  Fake(int pct, int setting, int charLive = 1) { c = boost::make_cfg(pct); boost::reset(s, setting); boost::set_avail(s, boost::kVelocity, charLive); boost::set_avail(s, boost::kTime, charLive); }
  void run(double secs, int on) {
    const int n = (int)(secs / dt);
    for (int i = 0; i < n; ++i) {
      boost::ramp(s, dt, on, c);
      double speed = base;
      if (s.k > 1.0 && (s.method == works || s.method == worksAlso)) speed = base * s.k;
      boost::sample(s, speed * dt, dt, 1.0, c);
      boost::judge(s, c);
      t += dt;
    }
  }
};

int main() {
  // ramp: from 1 to K in about upSec, back in about downSec, smooth and monotonic
  {
    boost::Cfg c = boost::make_cfg(170); boost::State s; boost::reset(s, 0);
    double prev = 1.0; int mono = 1;
    for (int i = 0; i < 20; ++i) { double k = boost::ramp(s, 0.011, 1, c); if (k < prev - 1e-12) mono = 0; prev = k; }
    CHECK(mono); CHECK(prev > 1.0 && prev < 1.7);
    for (int i = 0; i < 60; ++i) boost::ramp(s, 0.011, 1, c);
    CHECK(fabs(s.k - 1.7) < 1e-9);
    for (int i = 0; i < 40; ++i) boost::ramp(s, 0.011, 0, c);
    CHECK(fabs(s.k - 1.0) < 1e-9);
    boost::Cfg off = boost::make_cfg(100); boost::State s2; boost::reset(s2, 0);
    for (int i = 0; i < 100; ++i) boost::ramp(s2, 0.011, 1, off);
    CHECK(fabs(s2.k - 1.0) < 1e-12);   // 100% = no boost
    CHECK(boost::make_cfg(900).K == 3.0); CHECK(boost::make_cfg(0).K == 1.0);
  }
  // 1.7.9: the nudge (main loop) is the first way and is the only one when the character update never runs for the player
  {
    Fake f(170, 0, 0); f.works = boost::kNudge;
    CHECK(f.s.method == boost::kNudge);
    f.run(1.5, 0); f.run(4.0, 1);
    CHECK(f.s.method == boost::kNudge); CHECK(f.s.locked); CHECK(f.s.verdict[boost::kNudge] == 1); CHECK(f.s.switches == 0);
    CHECK(fabs(f.s.gain[boost::kNudge] - 1.7) < 0.05);
    CHECK(fabs(boost::base_speed(f.s, f.c) - 7.4) < 0.05);
  }
  // the nudge does not work and the character update never runs: no way left, the boost gives up (off)
  {
    Fake f(170, 0, 0); f.works = -1;
    f.run(1.0, 0); f.run(10.0, 1);
    CHECK(f.s.method == boost::kOff); CHECK(f.s.verdict[boost::kNudge] == -1);
    for (int i = 0; i < 100; ++i) boost::ramp(f.s, 0.011, 1, f.c);
    CHECK(fabs(f.s.k - 1.0) < 1e-12);
  }
  // the nudge does not work, the character update runs: velocity next
  {
    Fake f(170, 0); f.works = boost::kVelocity;
    f.run(1.5, 0); f.run(10.0, 1);
    CHECK(f.s.method == boost::kVelocity); CHECK(f.s.locked); CHECK(f.s.verdict[boost::kNudge] == -1); CHECK(f.s.verdict[boost::kVelocity] == 1); CHECK(f.s.switches == 1);
    CHECK(fabs(f.s.gain[boost::kVelocity] - 1.7) < 0.05);
  }
  // nudge and velocity do not work, time does: two switches, ends on time
  {
    Fake f(170, 0); f.works = boost::kTime;
    f.run(1.0, 0); f.run(14.0, 1);
    CHECK(f.s.method == boost::kTime); CHECK(f.s.locked); CHECK(f.s.verdict[boost::kNudge] == -1); CHECK(f.s.verdict[boost::kVelocity] == -1); CHECK(f.s.verdict[boost::kTime] == 1); CHECK(f.s.switches == 2);
  }
  // nothing works: the boost gives up (off) and never writes again
  {
    Fake f(170, 0); f.works = -1;
    f.run(1.0, 0); f.run(24.0, 1);
    CHECK(f.s.method == boost::kOff);
    for (int i = 0; i < 100; ++i) boost::ramp(f.s, 0.011, 1, f.c);
    CHECK(fabs(f.s.k - 1.0) < 1e-12);
  }
  // a way fixed by the setting never switches, even when it does not work (time is possible here)
  {
    Fake f(170, boost::kTime); f.works = boost::kVelocity;
    CHECK(f.s.method == boost::kTime);   // the character update is live from the start in this fake: the fixed way is taken as soon as it is possible
    f.run(1.0, 0); f.run(10.0, 1);
    CHECK(f.s.method == boost::kTime); CHECK(f.s.switches == 0); CHECK(f.s.verdict[boost::kTime] == -1);
  }
  // a velocity / time way fixed by the setting waits (nudge in the meantime) until the character update shows up, and goes back to the nudge if it stops
  {
    Fake f(170, boost::kVelocity, 0);
    CHECK(f.s.method == boost::kNudge); CHECK(!f.s.fixedMethod);
    boost::set_avail(f.s, boost::kVelocity, 1);
    CHECK(f.s.method == boost::kVelocity); CHECK(f.s.fixedMethod);
    boost::set_avail(f.s, boost::kVelocity, 0);
    CHECK(boost::ensure_available(f.s) == 1); CHECK(f.s.method == boost::kNudge); CHECK(!f.s.fixedMethod);
    CHECK(boost::ensure_available(f.s) == 0);
  }
  // a nudge fixed by the setting is always possible
  {
    Fake f(170, boost::kNudge, 0);
    CHECK(f.s.method == boost::kNudge); CHECK(f.s.fixedMethod);
  }
  // the nudge's own estimate of the game's step: no runaway when the game keeps the nudge, no negative step when it throws it away
  {
    for (int keep = 0; keep < 2; ++keep) for (int half = 0; half < 2; ++half) {
      boost::Cfg c = boost::make_cfg(170); boost::State s; boost::reset(s, boost::kNudge);
      // measured plain speed first
      for (int i = 0; i < 200; ++i) boost::sample(s, 7.4 * 0.011, 0.011, 1.0, c);
      const double dt = 0.011, stick = half ? 0.5 : 1.0, move = 7.4 * stick * dt;
      double pos = 0.0, prePos = 0.0, lastNudge = 0.0, nudgeSum = 0.0, moved = 0.0, maxNudge = 0.0, plainSum = 0.0;
      s.r = 1.0; s.k = c.K;
      for (int i = 0; i < 600; ++i) {
        pos += move;                          // the game's own step
        const double md = pos - prePos;       // measured: pre-nudge to pre-nudge
        prePos = pos;
        const double plain = boost::plain_step(md, lastNudge, dt, s, c);
        double ex, ez; boost::nudge_extra(plain, 0.0, c.K, 0.35, &ex, &ez);
        if (i >= 300) plainSum += plain;
        if (keep) pos += ex;                  // the game keeps what we add; otherwise the next tick starts again from the body (our nudge is thrown away)
        lastNudge = ex; nudgeSum += ex; if (ex > maxNudge) maxNudge = ex;
        moved += keep ? (move + ex) : move;
      }
      if (keep) {
        // kept: the estimate of the plain step stays at the real one (no feedback), the nudge is (K - 1) x it, and the character gets K x
        CHECK(fabs(plainSum / 300.0 - move) < 1e-6);
        CHECK(fabs(maxNudge - 0.7 * move) < 1e-6);
        CHECK(fabs(moved / 600.0 / move - 1.7) < 1e-6);
      } else {
        // thrown away: what is measured is the plain step minus the last nudge, never negative, never growing
        CHECK(plainSum >= 0.0); CHECK(maxNudge <= 0.7 * move + 1e-9);
      }
    }
  }
  // a slower base (a limited walk) is measured and the gain is relative to it
  {
    Fake f(150, 0); f.base = 5.0; f.works = boost::kVelocity;
    f.run(1.5, 0); f.run(4.0, 1);
    CHECK(f.s.locked); CHECK(fabs(boost::base_speed(f.s, f.c) - 5.0) < 0.05); CHECK(fabs(f.s.gain[boost::kVelocity] - 1.5) < 0.05);
  }
  // no plain walk measured before the first boost: the default base (7.4) is used
  {
    Fake f(170, 0); f.works = boost::kVelocity;
    f.run(4.0, 1);
    CHECK(f.s.locked); CHECK(f.s.baseN == 0);
  }
  // a half-hearted effect (gain 1.3 of a wanted 1.7): "works" needs 1 + 0.55 * 0.7 = 1.385, so it is judged as not working after maxSec
  {
    Fake f(170, boost::kVelocity); f.works = -1;
    boost::Cfg c = f.c;
    for (int i = 0; i < 400; ++i) { boost::ramp(f.s, 0.011, 1, c); boost::sample(f.s, 7.4 * 1.3 * 0.011, 0.011, 1.0, c); boost::judge(f.s, c); }
    CHECK(f.s.verdict[boost::kVelocity] == -1);
  }
  // samples at a weak stick or with a jump are ignored
  {
    boost::Cfg c = boost::make_cfg(170); boost::State s; boost::reset(s, 0);
    boost::sample(s, 0.01, 0.011, 1.0, c); CHECK(s.baseN == 0);   // 0.9 ft/s: standing against a wall (1.7.9)
    boost::sample(s, 0.05, 0.011, 0.5, c); CHECK(s.baseN == 0);
    boost::sample(s, 9.0, 0.011, 1.0, c); CHECK(s.baseN == 0);   // 800 ft/s
    boost::sample(s, 0.08, 0.011, 1.0, c); CHECK(s.baseN == 1);
    boost::sample(s, 0.08, 0.0005, 1.0, c); CHECK(s.baseN == 1);   // the second eye of a pair: no new step
  }
  // 1.7.9 the strength trim: a game that feeds the nudge back (gain 2.5 against a wanted 1.7) is turned down, one that keeps only part of it (1.4) is turned up, one that ignores it is left alone
  {
    boost::Cfg c = boost::make_cfg(170);
    for (int mode = 0; mode < 3; ++mode) {
      boost::State s; boost::reset(s, boost::kNudge);
      for (int i = 0; i < 200; ++i) boost::sample(s, 7.4 * 0.011, 0.011, 1.0, c);   // plain speed
      s.r = 1.0; s.k = c.K;
      double game = 0.0;   // the game's gain with trim 1: mode 0 runs away (1.7 -> trim scales it), 1 keeps 60 % of the nudge, 2 ignores it
      for (int step = 0; step < 40; ++step) {
        const double nudgeEff = 0.7 * s.trim;                       // extra step as a fraction of the plain step
        double gain = mode == 0 ? 1.0 + 1.9 * nudgeEff : mode == 1 ? 1.0 + 0.6 * nudgeEff : 1.0;
        game = gain;
        for (int i = 0; i < 60; ++i) boost::sample(s, 7.4 * gain * 0.011, 0.011, 1.0, c);
        boost::adapt(s, c);
      }
      if (mode == 0) { CHECK(game < 1.7 * 1.12 && game > 1.7 * 0.88); CHECK(s.trim < 1.0); }
      if (mode == 1) { CHECK(s.trim > 1.0); CHECK(s.trim <= 1.6 + 1e-9); }
      if (mode == 2) { CHECK(fabs(s.trim - 1.0) < 1e-9); }
    }
  }
  // the pure writes
  {
    double ox, oz;
    boost::vel_scale(3.0, 4.0, 1.7, 30.0, &ox, &oz); CHECK(fabs(ox - 5.1) < 1e-9 && fabs(oz - 6.8) < 1e-9);
    boost::vel_scale(30.0, 40.0, 3.0, 25.0, &ox, &oz); CHECK(fabs(sqrt(ox * ox + oz * oz) - 25.0) < 1e-6); CHECK(fabs(ox / oz - 0.75) < 1e-6);
    boost::vel_scale(0.0, 0.0, 2.0, 25.0, &ox, &oz); CHECK(ox == 0.0 && oz == 0.0);
    boost::nudge_extra(0.08, 0.0, 1.7, 0.35, &ox, &oz); CHECK(fabs(ox - 0.056) < 1e-9 && oz == 0.0);
    boost::nudge_extra(2.0, 0.0, 3.0, 0.35, &ox, &oz); CHECK(fabs(ox - 0.35) < 1e-9);
    CHECK(fabs(boost::time_step(0.01, 1.7) - 0.017) < 1e-12); CHECK(boost::time_step(0.01, 9.0) == 0.03); CHECK(boost::time_step(0.01, 0.2) == 0.01);
  }
  // the stick rotation: the game walks relative to ITS heading; the head is e away from it
  {
    double ox, oy; const double P = follow::kPi;
    follow::rotate_stick(0, 1, 0, &ox, &oy); CHECK(fabs(ox) < 1e-12 && fabs(oy - 1) < 1e-12);
    follow::rotate_stick(0, 1, P / 2, &ox, &oy); CHECK(fabs(ox - 1) < 1e-9 && fabs(oy) < 1e-9);     // head 90 deg right: forward becomes "right" in the game's frame
    follow::rotate_stick(0, 1, -P / 2, &ox, &oy); CHECK(fabs(ox + 1) < 1e-9 && fabs(oy) < 1e-9);
    follow::rotate_stick(0, 1, P, &ox, &oy); CHECK(fabs(ox) < 1e-9 && fabs(oy + 1) < 1e-9);          // looking backwards: forward is backwards for the game
    follow::rotate_stick(1, 0, P / 2, &ox, &oy); CHECK(fabs(ox) < 1e-9 && fabs(oy + 1) < 1e-9);      // stick right with the head 90 right = the game's "back"
    // length is kept for any angle and any push
    int ok = 1;
    for (int a = -360; a <= 360; a += 7) for (int i = 0; i < 12; ++i) {
      const double lx = 0.9 * cos(i * 0.5), ly = 0.9 * sin(i * 0.5);
      follow::rotate_stick(lx, ly, a * P / 180.0, &ox, &oy);
      if (fabs(sqrt(ox * ox + oy * oy) - sqrt(lx * lx + ly * ly)) > 1e-9) ok = 0;
    }
    CHECK(ok);
    // the walk direction in the world equals the head direction: game heading h, head h + e, stick forward -> world direction angle h + e
    const double h = 0.7, e = 0.4;
    follow::rotate_stick(0, 1, e, &ox, &oy);
    // game frame -> world: forward (0,1) = heading h (clockwise from north), right (1,0) = h + 90 deg
    const double wx = ox * cos(h) + oy * sin(h), wz = -ox * sin(h) + oy * cos(h);
    CHECK(fabs(atan2(wx, wz) - (h + e)) < 1e-9);
  }
  printf(fails ? "test_boost: %d FAILED\n" : "test_boost: ALL PASS\n", fails);
  return fails ? 1 : 0;
}
