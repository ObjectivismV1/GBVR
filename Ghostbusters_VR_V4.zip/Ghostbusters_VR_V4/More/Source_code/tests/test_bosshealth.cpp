// 1.7.164 boss health (vial and ring) for every boss: the size is the fixed boss size (no "fit to ghost": a boss's radius is bossring::ring_radius, a size for the view),
// readable at any distance (vial >= 4.3 deg with the ring style, >= 2.6 deg without), never filling the view, finite; normal ghosts still get fitted.
#include <cstdio>
#include <cmath>
#include "fightmath.h"
#include "bossringmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static cord::V v[12000];
static double width_deg(int n) { double lo = 1e9, hi = -1e9, z = 0; for (int i = 0; i < n; ++i) { if (v[i].p[0] < lo) lo = v[i].p[0]; if (v[i].p[0] > hi) hi = v[i].p[0]; z = fabs(v[i].p[2]); } return n > 0 && z > 0 ? 2.0 * atan(0.5 * (hi - lo) / z) * 57.2958 : 0.0; }
int main() {
  // every boss the mod knows by name, plus the big-health ones the logs met (CBipedLarge), with the distances the logs saw (9 m .. 278 m; 450 m is the boss range)
  const char* names[] = {"CStayPuftBoss", "COrreryBoss", "CGolem", "CGolemBase", "CAzetlor", "CLibrarian", "CSpiderWitch", "CArchitect", "CNightmare", "CBipedLarge"};
  const double dists[] = {4.0, 9.0, 12.0, 25.0, 44.0, 65.0, 101.0, 150.0, 278.0, 449.0};
  for (int ni = 0; ni < 10; ++ni) {
    CHECK(bossring::is_boss(names[ni], ni == 9 ? 1000.0 : 100.0));
    for (int di = 0; di < 10; ++di) for (int rs = 0; rs < 2; ++rs) for (int liq = 0; liq < 2; ++liq) {
      const double d = dists[di];
      fight::Bar b[1]; b[0].p[0] = 0; b[0].p[1] = 0; b[0].p[2] = (float)d; b[0].radius = (float)bossring::ring_radius(d, 0.4); b[0].frac = 0.6f; b[0].actor = 7;
      b[0].flags = fight::kFlagBoss | (rs ? fight::kFlagFocus : 0);
      fight::Look lk; lk.sizePct = 100; lk.digitsFocus = 0; lk.focusDeg = 7; lk.ringStyle = rs; lk.liquid = liq; lk.liq = nullptr;
      const int n = fight::build(b, 1, 0.0, lk, v, 12000);
      CHECK(n > 0 && n % 3 == 0);
      int finite = 1; for (int i = 0; i < n; ++i) for (int k = 0; k < 3; ++k) if (!(v[i].p[k] == v[i].p[k])) finite = 0; CHECK(finite);
      const double deg = width_deg(n);
      if (liq && !rs) {   // 1.7.170: with the ring style the ring is drawn (the vial had hidden it)
        const double want = fight::vial_width(d, b[0].radius, 100.0, rs, 1);
        double old = fight::bar_width(d, b[0].radius, 100.0) * (rs ? 1.45 : 1.15); const double fl = d * (rs ? 0.075 : 0.045); if (old < fl) old = fl;
        CHECK(fabs(want - old) < 1e-9);   // exactly the boss size of 1.7.160 (no fitting)
        CHECK(deg > (rs ? 4.2 : 2.5) && deg < 30.0);
      } else {
        if (0) printf("  old look: d=%.0f ring=%d deg=%.2f n=%d\n", d, rs, deg, n);
        CHECK(deg > 0.1 && deg < 40.0);   // the old bar / ring look (ghost_hp_liquid=0) is unchanged
        if (rs) CHECK(fabs(fight::ring_diameter(d, b[0].radius, 100.0, 1) - fight::bar_width(d, b[0].radius, 100.0) * 2.4) < 1e-9);
      }
    }
  }
  {   // a normal ghost (not a boss) is still fitted to its size: a small far ghost gets a smaller ring than the boss rule would give
    const double d = 30.0, r = 0.3;
    CHECK(fight::ring_diameter(d, r, 100.0, 0) < fight::ring_diameter(d, r, 100.0, 1));
    CHECK(fight::vial_width(d, r, 100.0, 0, 0) <= fight::vial_width(d, r, 100.0, 0, 1) + 1e-12);
  }
  printf("%s boss health: 10 bosses x 10 distances x ring/bars x vial/plain checked, %d failures\n", fails ? "FAIL" : "PASS", fails);
  return fails ? 1 : 0;
}
