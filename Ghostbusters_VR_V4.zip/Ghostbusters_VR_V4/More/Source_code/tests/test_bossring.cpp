// 1.7.106 health ring on bosses (bossringmath.h): which enemies count as bosses, how far the body is from where you look, where the ring sits on it,
// when a boss counts as present, the ring's size, and the fallback to the probe's own ring.
#include <stdio.h>
#include <math.h>
#include "bossringmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
#define NEAR(a, b, e) do { if (!(fabs((a) - (b)) <= (e))) { printf("FAIL line %d: %s = %.4f, wanted %.4f +- %g\n", __LINE__, #a, (double)(a), (double)(b), (double)(e)); ++fails; } } while (0)

int main() {
  // ---- which are bosses
  CHECK(bossring::name_is_boss("CStayPuftBoss") && bossring::name_is_boss("COrreryBoss") && bossring::name_is_boss("CGolem") && bossring::name_is_boss("CArchitect"));
  { const char* const all[] = {"CStayPuftBoss","COrreryBoss","CGolem","CGolemBase","CArchitect","CAzetlor","CLibrarian","CNightmare","CSpiderWitch","CBipedLarge"}; for (const char* n : all) CHECK(bossring::name_is_boss(n)); }   // 1.7.208: every boss class in the game exe (each has an AiController + CombatGoal)
  CHECK(!bossring::name_is_boss("CGhost") && !bossring::name_is_boss("CBiped") && !bossring::name_is_boss("CSlimer") && !bossring::name_is_boss("CStayPuftMinion"));
  CHECK(!bossring::name_is_boss("CGolemX") && !bossring::name_is_boss("") && !bossring::name_is_boss(nullptr));
  CHECK(bossring::is_boss("CGhost", 1600.0));      // big maximum health: a boss whatever it is called
  CHECK(!bossring::is_boss("CGhost", 150.0) && !bossring::is_boss("CBiped", 999.0));

  // ---- the body's angle from the gaze
  { double c[3] = {0, 0, 20}; NEAR(bossring::body_angle_deg(c, 1.0), 0.0, 1e-6); }                       // straight ahead
  { double c[3] = {10, 0, 10}; NEAR(bossring::body_angle_deg(c, 0.001), 45.0, 0.05); }                    // a point 45 deg right
  { double c[3] = {10, 0, 10}; const double a = bossring::body_angle_deg(c, 5.0); printf("body 45 deg off, radius 5 at 14.1: edge at %.1f deg\n", a); CHECK(a > 24.0 && a < 26.5); }   // asin(5/14.14)=20.7 -> 24.3
  { double c[3] = {10, 0, 10}; CHECK(bossring::body_angle_deg(c, 14.2) == 0.0); }                        // you are inside it
  { double c[3] = {0, 0, -20}; NEAR(bossring::body_angle_deg(c, 1.0), 180.0, 1e-9); }                    // behind you
  { double c[3] = {0, 0, 0}; NEAR(bossring::body_angle_deg(c, 1.0), 180.0, 1e-9); }

  // ---- where the ring sits
  double p[3];
  { double c[3] = {1, 2, 40}; CHECK(bossring::ring_point(c, 10.0, p)); NEAR(p[0], 1, 1e-9); NEAR(p[1], 2, 1e-9); NEAR(p[2], 40, 1e-9); }   // centre in view: on the centre
  { double c[3] = {0, 60, 40}; CHECK(bossring::ring_point(c, 30.0, p)); printf("centre 56 deg up, radius 30: ring at %.1f,%.1f,%.1f\n", p[0], p[1], p[2]);
    CHECK(p[1] < 60.0 && p[1] > 60.0 - 24.5); }                                                           // slid toward the gaze, at most 0.8 radius = 24 below the centre
  { double c[3] = {0, 200, 40}; CHECK(bossring::ring_point(c, 10.0, p)); CHECK(p[1] >= 200.0 - 8.001 && p[1] < 200.0); }  // 79 deg up: fully the gaze point, held inside 0.8 of the radius
  { double c[3] = {0, 3, 40}; CHECK(bossring::ring_point(c, 30.0, p)); NEAR(p[1], 3.0, 1e-9); }           // 4 deg: still the centre
  { double c[3] = {0, 0, -5}; CHECK(!bossring::ring_point(c, 30.0, p)); }                                // behind
  // it moves smoothly: no step between neighbouring angles
  { double prev[3] = {0, 0, 0}; int have = 0; double worst = 0; 
    for (int a = 0; a <= 85; ++a) { const double r = a * 3.14159265358979 / 180.0; double c[3] = {0, 50.0 * sin(r), 50.0 * cos(r)}; double q[3];
      if (!bossring::ring_point(c, 12.0, q)) continue;
      if (have) { const double d = sqrt((q[0]-prev[0])*(q[0]-prev[0]) + (q[1]-prev[1])*(q[1]-prev[1]) + (q[2]-prev[2])*(q[2]-prev[2])); if (d > worst) worst = d; }
      prev[0] = q[0]; prev[1] = q[1]; prev[2] = q[2]; have = 1; }
    printf("ring point: biggest step per degree of the centre's angle %.2f (the centre itself moves %.2f per degree at 50)\n", worst, 50.0 * 3.14159265358979 / 180.0);
    CHECK(worst < 1.6); }

  // ---- head space and back (a turned, offset head and a world scale)
  { const double k = 0.7; const float cy = (float)cos(k), sy = (float)sin(k), cp = (float)cos(0.3), sp = (float)sin(0.3);
    // an orthonormal turn about the vertical, then a tilt; the columns are the head's right, up and forward in world
    float v9[9] = {cy, 0, -sy,   sy * sp, cp, cy * sp,   sy * cp, -sp, cy * cp};
    float hc[3] = {12.5f, 5.5f, -40.0f}; const double fpm = 3.2808399, inv = 1.0 / fpm;
    const float w[3] = {30.0f, 60.0f, 80.0f}; double h[3]; float back[3];
    bossring::world_to_head(v9, hc, inv, w, h);
    bossring::head_to_world(v9, hc, inv, h, back);
    printf("head %.3f,%.3f,%.3f -> world back %.3f,%.3f,%.3f (was %.1f,%.1f,%.1f)\n", h[0], h[1], h[2], back[0], back[1], back[2], w[0], w[1], w[2]);
    NEAR(back[0], w[0], 2e-3); NEAR(back[1], w[1], 2e-3); NEAR(back[2], w[2], 2e-3);
    // ten feet straight ahead of the head is on +z in head space
    const float ahead[3] = {hc[0] + v9[2] * 10.0f, hc[1] + v9[5] * 10.0f, hc[2] + v9[8] * 10.0f}; double ha[3];   // the head's forward is the third COLUMN of view9
    bossring::world_to_head(v9, hc, inv, ahead, ha); NEAR(ha[0], 0.0, 1e-3); NEAR(ha[1], 0.0, 1e-3); NEAR(ha[2], 10.0 * inv, 1e-3); }

  // ---- present
  // 1.7.116: present(engaged, lockOk, drawnRecently, named, strictLine). Drawn alone and a clear line alone are NOT signs (the unspawned Stay Puft 85 m away was "drawn" with an open sky in front of it)
  CHECK(!bossring::present(0, 0, 0) && !bossring::present(0, 0, -1));
  CHECK(!bossring::present(0, 0, 1) && !bossring::present(0, 0, 1, 1, 1));      // the game says it drew it: that is not enough
  CHECK(!bossring::present(0, 1, 0) && !bossring::present(0, 1, -1));            // lockable but not drawn: not enough
  CHECK(bossring::present(1, 0, 0) && bossring::present(1, 0, -1, 0, 0));        // hit or held lately: there
  CHECK(bossring::present(0, 1, 1));                                             // the game's lock test says yes and it draws it: there (named)
  // a big body that is not a named boss: the lock + drawn way also needs the strict line
  CHECK(!bossring::present(0, 1, 1, 0, 0) && bossring::present(0, 1, 1, 0, 1) && bossring::present(1, 0, 0, 0, 0));
  // the hit window and the latch
  CHECK(bossring::lost_health(1.0, 0.99) && !bossring::lost_health(1.0, 0.9985) && !bossring::lost_health(0.5, 0.5) && !bossring::lost_health(0.5, 0.7));
  CHECK(bossring::healed(0.4, 1.0) && !bossring::healed(0.4, 0.41) && !bossring::healed(1.0, 0.5));
  NEAR(bossring::engage_s(), 20.0, 1e-9);

  // ---- size and range
  NEAR(bossring::ring_radius(100.0, 0.5), 7.5, 1e-9);
  NEAR(bossring::ring_radius(2.0, 0.5), 0.5, 1e-9);
  CHECK(bossring::max_range_m() > 60.0);

  // ---- fallback
  { long long since = 0;
    CHECK(!bossring::fallback_due(0, 1000, 0, &since, 300, 600) && since == 0);                            // nothing to show it on
    CHECK(!bossring::fallback_due(1, 1000, 900, &since, 300, 600) && since == 0);                          // the game's ring was drawn 100 ms ago
    CHECK(!bossring::fallback_due(1, 2000, 900, &since, 300, 600) && since == 2000);                       // not drawn for a while: the wait begins
    CHECK(!bossring::fallback_due(1, 2400, 900, &since, 300, 600));                                         // 400 ms: still waiting
    CHECK(bossring::fallback_due(1, 2650, 900, &since, 300, 600));                                          // 650 ms: the probe's ring shows
    CHECK(!bossring::fallback_due(1, 2700, 2690, &since, 300, 600) && since == 0);                         // the game's ring came: probe's ring off, wait reset
    CHECK(!bossring::fallback_due(1, 2800, 2690, &since, 300, 600));
    CHECK(!bossring::fallback_due(0, 2900, 2690, &since, 300, 600) && since == 0);                         // focus gone
    long long s2 = 0; CHECK(!bossring::fallback_due(1, 500, 0, &s2, 300, 600)); CHECK(bossring::fallback_due(1, 1200, 0, &s2, 300, 600));   // the game's ring never drew
  }
  // 1.7.142 moving boss: close counts, the Times Square escort distance does not
  CHECK(bossring::moving_counts(1, 44.0) == 1);
  CHECK(bossring::moving_counts(1, 60.0) == 1);
  CHECK(bossring::moving_counts(1, 84.0) == 0);
  CHECK(bossring::moving_counts(1, 130.0) == 0);
  CHECK(bossring::moving_counts(0, 10.0) == 0);
  CHECK(bossring::moving_counts(1, -1.0) == 0);
  if (!fails) printf("bossring: ok\n");
  return fails ? 1 : 0;
}
