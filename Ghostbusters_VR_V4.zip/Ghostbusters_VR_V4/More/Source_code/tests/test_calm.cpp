// 1.7.29 calm walking (calmmath.h): the smoothed eye-to-pelvis offset, its limits, the restart rules, and the shake meter.
#include <stdio.h>
#include <math.h>
#include "calmmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  calm::Filter f; calm::reset(&f);
  double out[3], off[3] = {0.1, 1.5, 0.2};
  // the first sample restarts the filter: out = off
  CHECK(calm::step(&f, off, 0.011, 0.14, 0.10, 0.6, out) == 0 && out[1] == 1.5);
  // a steady offset stays put
  for (int i = 0; i < 50; ++i) CHECK(calm::step(&f, off, 0.011, 0.14, 0.10, 0.6, out) == 1);
  CHECK(fabs(out[0] - 0.1) < 1e-9 && fabs(out[1] - 1.5) < 1e-9);
  // a bob of +-3 cm at 2 Hz (stride rate) is flattened to well under half
  { calm::reset(&f); double mx = 0, ox = 0; double sumRaw = 0, sumOut = 0; int n = 0;
    for (int i = 0; i < 400; ++i) {
      const double t = i * 0.011; double o[3] = {0.0, 1.5 + 0.0984 * sin(2.0 * 3.14159265 * 2.0 * t), 0.0};   // 0.0984 ft = 3 cm
      calm::step(&f, o, 0.011, 0.14, 0.10, 0.6, out);
      if (i > 100) { const double r = o[1] - 1.5, a = out[1] - 1.5; sumRaw += r * r; sumOut += a * a; ++n; double d = fabs(o[1] - out[1]); if (d > mx) mx = d; (void)ox; }
    }
    CHECK(sumOut < sumRaw * 0.35);           // the bob that reaches the body is a third of the energy or less (about 40% of the size)
    CHECK(mx <= 0.10 + 1e-9);                 // the lag never exceeds the limit: the hidden head slides at most this far
  }
  // a steady walk (the offset drifting 20 cm in a second): follows, lag capped at maxLag
  { calm::reset(&f); double o[3] = {0, 1.5, 0}; double mx = 0;
    for (int i = 0; i < 100; ++i) { o[0] += 0.0022; calm::step(&f, o, 0.011, 0.5, 0.10, 0.6, out); double d = fabs(o[0] - out[0]); if (d > mx) mx = d; }
    CHECK(mx <= 0.10 + 1e-9);
    for (int i = 0; i < 300; ++i) calm::step(&f, o, 0.011, 0.5, 0.10, 0.6, out);
    CHECK(fabs(out[0] - o[0]) < 1e-3);        // and catches up when the offset stops
  }
  // a jump (a different animation, a roll) restarts at once
  { calm::reset(&f); double a[3] = {0, 1.5, 0}, b[3] = {0.9, 1.0, 0};
    calm::step(&f, a, 0.011, 0.14, 0.10, 0.6, out); calm::step(&f, a, 0.011, 0.14, 0.10, 0.6, out);
    CHECK(calm::step(&f, b, 0.011, 0.14, 0.10, 0.6, out) == 0 && out[0] == 0.9 && out[1] == 1.0);
  }
  // a long gap restarts; tau 0 = off (out = off, and the next call starts again); the same frame again (dt 0) holds
  { calm::reset(&f); double a[3] = {0, 1.5, 0}, b[3] = {0.05, 1.5, 0};
    calm::step(&f, a, 0.011, 0.14, 0.10, 0.6, out); calm::step(&f, a, 0.011, 0.14, 0.10, 0.6, out);
    CHECK(calm::step(&f, b, 0.5, 0.14, 0.10, 0.6, out) == 0 && out[0] == 0.05);              // gap > 0.25 s
    calm::step(&f, a, 0.011, 0.14, 0.10, 0.6, out);
    const double held = out[0];
    CHECK(calm::step(&f, b, 0.0, 0.14, 0.10, 0.6, out) == 1 && fabs(out[0] - held) < 1e-12);   // dt 0: no step
    CHECK(calm::step(&f, b, 0.011, 0.0, 0.10, 0.6, out) == 0 && out[0] == 0.05);             // off
  }
  // not-a-number input never poisons the state
  { calm::reset(&f); double a[3] = {0, 1.5, 0}, bad[3] = {0.0, NAN, 0.0};
    calm::step(&f, a, 0.011, 0.14, 0.10, 0.6, out); calm::step(&f, a, 0.011, 0.14, 0.10, 0.6, out);
    calm::step(&f, bad, 0.011, 0.14, 0.10, 0.6, out);
    CHECK(calm::step(&f, a, 0.011, 0.14, 0.10, 0.6, out) == 0 && out[1] == 1.5);
  }
  // the shake meter: a straight glide has no second difference, a zig-zag does
  { double p0[3] = {0, 0, 0}, p1[3] = {0.1, 0, 0}, p2[3] = {0.2, 0, 0}, p3[3] = {0.1, 0, 0};
    CHECK(calm::second_diff(p0, p1, p2) < 1e-12);
    CHECK(fabs(calm::second_diff(p1, p2, p3) - 0.2) < 1e-9);
  }
  if (fails) { printf("test_calm FAILED\n"); return 1; }
  printf("test_calm OK\n");
  return 0;
}
