#include <assert.h>
#include <stdio.h>
#include "capturemath.h"
#include "ratecap.h"
int main() {
  auto a = capbridge::step(0x200000u, true, false); // firing and left trigger together
  assert(a.mask == (0x200000u | 0x40u) && a.owned && a.added);
  auto b = capbridge::step(a.mask, true, a.owned);
  assert(b.mask == a.mask && !b.added && !b.removed);
  auto c = capbridge::step(b.mask, false, b.owned);
  assert(c.mask == 0x200000u && c.removed && !c.owned); // fire survives release
  auto native = capbridge::step(0x40u, true, false);
  assert(native.mask == 0x40u && !native.owned);
  assert(capbridge::step(native.mask, false, native.owned).mask == 0x40u);
  assert(ratecap::next(0, 1) == 45 && ratecap::next(ratecap::kThird, 1) == 45 && ratecap::next(80, 1) == 90 && ratecap::next(60, 1) == 72);   // 1.7.158: Off, 45 .. 120
  assert(ratecap::next(90, -1) == 80 && ratecap::next(120, 1) == 120);
  assert(ratecap::interval_ticks(90000, 90) == 1000);
  puts("PASS capture bridge with fire and slam path; FPS choices");
}
