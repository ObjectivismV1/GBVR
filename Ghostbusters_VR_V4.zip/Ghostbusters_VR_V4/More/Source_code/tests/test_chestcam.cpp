// Unit tests for the 1.7.38 chest camera maths (src/chestmath.h). Build: clang++ -std=c++17 -Isrc tests/test_chestcam.cpp
#include "../src/chestmath.h"
#include "../src/stereomath.h"
#include <cmath>
#include <initializer_list>
#include <cstdio>
static int fails;
static void check(const char* name, bool ok, double v = 0) { printf("%s %s (%.6g)\n", ok ? "PASS" : "FAIL", name, v); fails += !ok; }
int main() {
  const double D = 3.14159265358979323846 / 180.0;
  // level view (pitch 0) must equal the engine's own level basis for the same yaw
  for (double yaw : {0.0, 0.7, -2.1, 3.0}) {
    float a[9], b[9];
    chest::basis(yaw, 0.0, a); stereo::level_basis(yaw, b);
    double d = 0; for (int i = 0; i < 9; ++i) d = fmax(d, fabs(a[i] - b[i]));
    check("pitch 0 = the engine's level basis", d < 1e-6, d);
  }
  // always a rotation, forward = (cos p sin y, sin p, cos p cos y), up never tips sideways (no roll: right stays horizontal)
  for (double yaw : {-3.0, -1.0, 0.4, 2.5}) for (double pitch : {-30.0 * D, -10.0 * D, 0.0, 5.0 * D}) {
    float v[9]; chest::basis(yaw, pitch, v);
    check("valid rotation", vm::is_rotation(v, 1e-5), vm::det(v));
    check("forward matches yaw/pitch", fabs(v[2] - cos(pitch) * sin(yaw)) < 1e-6 && fabs(v[5] - sin(pitch)) < 1e-6 && fabs(v[8] - cos(pitch) * cos(yaw)) < 1e-6);
    check("no roll: right column is horizontal", v[3] == 0.0f);
    check("right = up x forward", fabs(v[0] - (v[4] * v[8] - v[7] * v[5])) < 1e-5 && fabs(v[6] - (v[1] * v[5] - v[4] * v[2])) < 1e-5);
    check("looking up tilts the up vector back", pitch <= 0 || v[4] > 0);
  }
  // pitch limits
  int lim = 0;
  check("pitch 40 up is limited to 5", fabs(chest::clamp_pitch(40 * D, &lim) - 5 * D) < 1e-9 && lim == 1);
  lim = 0;
  check("pitch 60 down is limited to 30", fabs(chest::clamp_pitch(-60 * D, &lim) + 30 * D) < 1e-9 && lim == 1);
  lim = 0;
  check("pitch inside the limits is kept", chest::clamp_pitch(-10 * D, &lim) == -10 * D && lim == 0);
  // smoothing: goes the short way round, never overshoots, jumps when the gap in time is long
  double c = 3.0, t = -3.0;  // 6.0 rad apart the long way, 0.283 the short way (through pi)
  double n = chest::smooth_angle(c, t, 0.05, 0.08);
  check("smoothing takes the short way round", n > 3.0 && n < 3.0 + 0.283, n);
  check("smoothing never overshoots", fabs(chest::wrap_pi(t - n)) <= fabs(chest::wrap_pi(t - c)));
  check("a long gap jumps to the target", chest::smooth_angle(0.0, 1.0, 2.0, 0.08) == 1.0);
  double x = 0; for (int i = 0; i < 40; ++i) x = chest::smooth_angle(x, 1.0, 0.05, 0.08);
  check("converges", fabs(x - 1.0) < 1e-3, x);
  // position: below the head and behind it along the body heading
  float head[3] = {10.f, 5.f, -3.f}, p[3];
  chest::position(head, 0.0, 0.8, 0.6, p);   // heading +z: behind = -z
  check("heading +z: 0.6 ft behind is z - 0.6, 0.8 ft down", fabs(p[0] - 10.f) < 1e-5 && fabs(p[1] - 4.2f) < 1e-5 && fabs(p[2] + 3.6f) < 1e-5);
  chest::position(head, 3.14159265358979323846 * 0.5, 0.0, 1.0, p);   // heading +x: behind = -x
  check("heading +x: behind is x - 1", fabs(p[0] - 9.f) < 1e-4 && fabs(p[2] + 3.f) < 1e-4);
  chest::position(head, 1.234, 0.0, 0.0, p);
  check("zero offsets leave the head centre", p[0] == 10.f && p[1] == 5.f && p[2] == -3.f);
  // the head stays out of the picture: with the defaults (25 cm down, 18 cm back) the head centre is more than 48 degrees above the lens axis when the lens looks level
  const double ang = atan2(0.25, 0.18) / D;
  check("default head direction is above a 100 degree wide picture's top edge (tan(vertical half) about 0.84)", ang > 50.0 || tan(ang * D) > 0.9, ang);
  printf("%s\n", fails ? "SOME FAILED" : "ALL PASS");
  return fails ? 1 : 0;
}
