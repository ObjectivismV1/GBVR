// 1.7.26 the cutscene guard (cinemath.h)
#include <stdio.h>
#include "cinemath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  const double dt = 1.0 / 90.0;
  cine::Guard g; g.reset();
  // normal play: nothing
  for (int i = 0; i < 300; ++i) g.update(0, 0, dt);
  CHECK(g.blend == 0.0 && !g.active && g.events == 0);
  // a knock-back (forced for 0.4 s): the guard must NOT engage (the gun stays in the hand)
  for (int i = 0; i < 36; ++i) g.update(1, 0, dt);
  for (int i = 0; i < 200; ++i) g.update(0, 0, dt);
  CHECK(g.events == 0 && g.blend == 0.0);
  // a cutscene walk (forced for 3 s): engages after about 0.55 s, blend reaches 1 within 0.12 s more
  int at = -1;
  double b30 = 0;
  for (int i = 0; i < 270; ++i) {
    g.update(1, 0, dt);
    if (g.active && at < 0) at = i;
    if (i == 20) b30 = g.blend;
  }
  CHECK(at >= 45 && at <= 55);
  CHECK(b30 == 0.0);
  CHECK(g.blend == 1.0 && g.events == 1 && g.byMove == 1 && g.byJump == 0);
  // the game lets go: the guard holds 0.6 s, then eases out over 0.7 s
  double bHold = 0, bMid = 0;
  for (int i = 0; i < 400; ++i) {
    g.update(0, 0, dt);
    if (i == 30) bHold = g.blend;
    if (i == 54 + 30) bMid = g.blend;
  }
  CHECK(bHold == 1.0);
  CHECK(bMid > 0.2 && bMid < 0.9);
  CHECK(g.blend == 0.0 && !g.active);
  CHECK(g.longest > 3.0 && g.longest < 5.0);
  // a jump (cut): engages at once, holds 1.5 s
  g.update(0, 1, dt);
  CHECK(g.active && g.byJump == 1 && g.events == 2);
  for (int i = 0; i < 90; ++i) g.update(0, 1, dt);
  CHECK(g.active && g.blend == 1.0);
  for (int i = 0; i < 90; ++i) g.update(0, 1, dt);
  CHECK(!g.active);
  // the second eye of a pair (tiny dt) changes nothing
  { const double b = g.blend; const double ev = g.events; g.update(1, 5, 0.0005); CHECK(g.blend == b && g.events == ev); }
  // mix: 0 = probe, 1 = game
  float p[16], q[16], o[16];
  for (int i = 0; i < 16; ++i) { p[i] = (float)i; q[i] = (float)(100 + i); }
  cine::mix16(p, q, 0.0, o); CHECK(o[5] == 5.0f);
  cine::mix16(p, q, 1.0, o); CHECK(o[5] == 105.0f);
  cine::mix16(p, q, 0.5, o); CHECK(o[5] > 54.9f && o[5] < 55.1f);
  printf(fails ? "test_cine FAILED\n" : "test_cine OK\n");
  return fails ? 1 : 0;
}
