// 1.7.156 "the gun floats out of the hand when fired": the game-in-charge guard (cinemath.h) fed by the forced-move detector (forcedmath.h), with the
// keep_control rules the mod now sets (engage only after 6 s of forced move, jumps do not engage). Scenario from the report + a long stress run.
#include <cstdio>
#include <cmath>
#include "forcedmath.h"
#include "cinemath.h"
#include "gungatemath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static unsigned long long sd = 0xABCDEF987ULL;
static double rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (double)(sd >> 11) / 9007199254740992.0; }
struct Sim {
  forced::Detector f; cine::Guard g; double pos[3]; double worstBlend; long frames, engaged;
  void init(int keep) { f.reset(); g.reset(); pos[0] = pos[1] = pos[2] = 0; worstBlend = 0; frames = engaged = 0; g.engageSec = keep ? gungate::kKnockGraceS : 0.55; g.jumpEngages = keep ? 0 : 1; }
  // move the character at vx ft/s for secs with the stick at `stick`; fps frames a second
  void run(double secs, double vx, double stick, double fps, double hitchChance = 0.0) {
    for (double t = 0; t < secs;) {
      double dt = 1.0 / fps; if (hitchChance > 0 && rnd() < hitchChance) dt += rnd() * 0.45;
      t += dt; pos[0] += vx * dt;
      f.update(pos, stick, dt);
      const double b = g.update(f.forced, f.teleports, dt);
      if (b > worstBlend) worstBlend = b; ++frames; if (b > 0.5) ++engaged;
    }
  }
  void jump(double ft, double fps) { pos[0] += ft; const double dt = 1.0 / fps; f.update(pos, 0.0, dt); const double b = g.update(f.forced, f.teleports, dt); if (b > worstBlend) worstBlend = b; ++frames; }
};
int main() {
  // 1. THE REPORT: fighting, stick released, a ghost hit shoves the character at 3.6..13.9 ft/s for 1.1 s. Old rules: the guard engages. New rules: it never does.
  { Sim o; o.init(0); o.run(2.0, 0, 0.0, 72); o.run(1.1, 8.0, 0.0, 72); o.run(3.0, 0, 0.0, 72);
    Sim n; n.init(1); n.run(2.0, 0, 0.0, 72); n.run(1.1, 8.0, 0.0, 72); n.run(3.0, 0, 0.0, 72);
    printf("cinekeep: a 1.1 s shove in a fight: old rules took the gun and body for %ld frames (blend up to %.2f); new rules %ld frames (blend %.2f)\n", o.engaged, o.worstBlend, n.engaged, n.worstBlend);
    CHECK(o.engaged > 40 && o.worstBlend > 0.99);
    CHECK(n.engaged == 0 && n.worstBlend == 0.0); }
  // 2. a knock-down with the get-up (5.5 s of forced move): still yours
  { Sim n; n.init(1); n.run(1.0, 0, 0.0, 90); n.run(5.5, 3.0, 0.0, 90); n.run(2.0, 0, 0.0, 90); CHECK(n.worstBlend == 0.0); }
  // 3. a scripted walk (the game walks the character for 9 s): the guard engages after the 6 s grace, and lets go again afterwards
  { Sim n; n.init(1); n.run(1.0, 0, 0.0, 90); n.run(9.0, 4.0, 0.0, 90); CHECK(n.worstBlend > 0.99 && n.g.events == 1); n.run(3.0, 0, 0.0, 90); CHECK(n.g.blend == 0.0 && !n.g.active); }
  // 4. cuts / respawns (jumps of 30 ft in one frame): no longer engage with keep_control; they still do without it
  { Sim n; n.init(1); n.run(1.0, 0, 0.0, 90); for (int i = 0; i < 6; ++i) { n.jump(30.0, 90); n.run(1.5, 0, 0.0, 90); } CHECK(n.worstBlend == 0.0 && n.f.jumpsAll == 6);
    Sim o; o.init(0); o.run(1.0, 0, 0.0, 90); o.jump(30.0, 90); o.run(0.5, 0, 0.0, 90); CHECK(o.worstBlend > 0.99); }
  // 5. a hitch while sprinting is not a jump any more: 26 ft/s with the stick pushed and frames of up to 0.45 s (up to 11.7 ft in one frame)
  { Sim n; n.init(0); n.run(60.0, 26.0, 1.0, 72, 0.03); printf("cinekeep: sprinting 60 s through hitches: jumps counted %d, guard blend %.2f (old jump rules, new jump test)\n", n.f.jumpsAll, n.worstBlend);
    CHECK(n.f.jumpsAll == 0 && n.worstBlend == 0.0); }
  // a real jump is still one, at any frame rate from 20 to 240 FPS, and during a hitch when it is far
  for (int fps = 20; fps <= 240; fps += 10) { Sim n; n.init(1); n.run(0.5, 0, 0.0, fps); n.jump(6.0, fps); CHECK(n.f.jumpsAll == 1); }
  { Sim n; n.init(1); n.run(0.5, 0, 0.0, 60); n.pos[0] += 40.0; n.f.update(n.pos, 0.0, 0.5); CHECK(n.f.jumpsAll == 1); }
  // 6. stress: 3 hours of random play with keep_control: walking, sprinting, standing, shoves and knock-downs of up to 4.5 s, hitches, cuts, 20..240 FPS. The guard never engages.
  //    Then one 7 s scripted walk: it does.
  { Sim n; n.init(1); double total = 0; long shoves = 0, cuts = 0;
    while (total < 3.0 * 3600.0) {
      const double fps = 20.0 + rnd() * 220.0; const int k = (int)(rnd() * 6); const double secs = 0.2 + rnd() * 6.0;
      // every forced stretch is followed by at least half a second of the character standing (a knock, then on your feet): two shoves in a row would be one long one
      if (k == 0) n.run(secs, 5.0 + rnd() * 20.0, 0.3 + rnd() * 0.7, fps, 0.01);                    // walking / sprinting
      else if (k == 1) n.run(secs, 0.0, 0.0, fps, 0.01);                                              // standing
      else if (k == 2) { const double s2 = 0.1 + rnd() * 4.4; n.run(s2, 1.6 + rnd() * 14.0, 0.0, fps); n.run(1.0 + rnd(), 0.0, 0.0, fps); ++shoves; }   // a shove / knock-down of up to 4.5 s (the detector keeps "forced" about 0.75 s longer: under the 6 s grace)
      else if (k == 3) { n.jump(5.5 + rnd() * 200.0, fps); n.run(0.6 + rnd(), 0.0, 0.0, fps); ++cuts; }   // a cut / respawn
      else if (k == 4) { n.run(secs * 0.5, 2.0 + rnd() * 3.0, 0.0, fps); n.run(0.6, 0.0, 0.0, fps); } // carried by a platform / sliding for up to 3 s
      else { n.run(secs < 4.0 ? secs : 4.0, 3.0, rnd() < 0.5 ? 0.1 : 0.9, fps); n.run(1.0, 0.0, 0.0, fps); }   // the stick barely touched while the character still moves (up to 4 s)
      total += secs;
    }
    printf("CINEKEEP STRESS: %ld frames (3 hours, 20..240 FPS), %ld shoves, %ld cuts: frames with the gun / body handed to the game %ld, highest blend %.3f\n", n.frames, shoves, cuts, n.engaged, n.worstBlend);
    CHECK(n.engaged == 0 && n.worstBlend == 0.0);
    n.run(1.0, 0, 0, 90); n.run(7.0, 4.0, 0.0, 90); CHECK(n.worstBlend > 0.99); }
  if (!fails) printf("cinekeep: ok\n");
  return fails ? 1 : 0;
}
