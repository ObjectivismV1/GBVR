#include <stdio.h>
#include <math.h>
#include "cordmath.h"
using namespace cord;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

static void pose(float* p, double x, double y, double z, double yawDeg) {   // 3x4, forward = -z, rotated about y
  const double a = yawDeg * vm::kPi / 180.0, c = cos(a), s = sin(a);
  float m[12] = {(float)c, 0, (float)s, (float)x,  0, 1, 0, (float)y,  (float)-s, 0, (float)c, (float)z};
  for (int i = 0; i < 12; ++i) p[i] = m[i];
}

static double dist3(const double* a, const double* b) { double d[3] = {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; return len3(d); }

struct Scene {
  Rope r; float head[12]; float hand[12];
  double A[3], eA[3], B[3], dir[3];
  void init() { r.init(); pose(head, 0, 1.7, 0, 0); pose(hand, 0.25, 1.2, -0.45, 0); }
  void anchors() {
    body_yaw(&r, pose_yaw(head), 0.011);
    pack_anchor(head, r.yaw, 1.7 / 1.6, A, eA);
    wand_anchor(hand, B, dir);
  }
  void run(double secs, double dt = 0.011) {
    const double hp[3] = {head[3], head[7], head[11]};
    for (double t = 0; t < secs; t += dt) { anchors(); step(&r, A, eA, B, dir, hp, 1.7 / 1.6, 0.0, dt); }
  }
  double total() const { double t = 0; for (int i = 0; i < kN - 1; ++i) t += dist3(r.p[i], r.p[i + 1]); return t; }
};

int main() {
  // yaw axes: yaw 0 looks along -z
  { double f[3], rt[3]; yaw_axes(0, f, rt); CHECK(fabs(f[2] + 1) < 1e-9 && fabs(rt[0] - 1) < 1e-9);
    yaw_axes(vm::kPi / 2, f, rt); CHECK(fabs(f[0] - 1) < 1e-9 && fabs(rt[2] - 1) < 1e-9); }
  // pose_yaw agrees with the pose builder
  { float p[12]; pose(p, 0, 1.7, 0, 0); CHECK(fabs(pose_yaw(p)) < 1e-6);
    pose(p, 0, 1.7, 0, 90); double y = pose_yaw(p); CHECK(fabs(fabs(y) - vm::kPi / 2) < 1e-4); }
  // the pack anchor is behind, well below the head, a little to the right; the cord leaves it downwards and out to the right
  { Scene s; s.init(); s.anchors();
    CHECK(s.A[2] > 0.15); CHECK(s.A[1] < 1.7 - 0.5); CHECK(s.A[0] > 0.0 && s.A[0] < 0.15);
    CHECK(fabs(len3(s.eA) - 1.0) < 1e-9); CHECK(s.eA[1] < -0.6); CHECK(s.eA[0] > 0.2); }
  // 0.75 the avatar stands out in front and lower: the pack outlet is that much further forward / lower
  { Scene s; s.init(); s.anchors(); double A0[3] = {s.A[0], s.A[1], s.A[2]}; double eA[3]; pack_anchor(s.head, s.r.yaw, 1.7 / 1.6, s.A, eA, 0.10, 0.08);
    CHECK(fabs((A0[2] - s.A[2]) - 0.10) < 1e-6); CHECK(fabs((A0[1] - s.A[1]) - 0.08) < 1e-6); CHECK(fabs(A0[0] - s.A[0]) < 1e-6); }
  // the wand anchor is behind the grip (towards the player) and a little below
  { Scene s; s.init(); s.anchors(); CHECK(s.B[2] > -0.45 + 0.1); CHECK(s.B[1] < 1.2); }
  // the length follows the distance: always some slack, more of it close up, never shorter than the distance, within the limits
  {
    double prev = 0;
    for (double d = 0.05; d < 2.4; d += 0.05) {
      const double w = want_length(d);
      CHECK(w >= d * 1.03 - 1e-12); CHECK(w >= kMinLenM - 1e-12); CHECK(w >= prev - 1e-9);
      if (d * 1.03 <= kMaxLenM) CHECK(w <= kMaxLenM + 1e-12);
      prev = w;
    }
    CHECK(fabs(want_length(0.4) - 1.35) < 1e-9); CHECK(fabs(want_length(1.0) - 1.425) < 1e-9);
  }
  // settle: ends pinned, every segment about the same length, nothing longer than the rest length, finite
  {
    Scene s; s.init(); s.run(3.0);
    CHECK(s.r.have);
    CHECK(dist3(s.r.p[0], s.A) < 1e-6);
    CHECK(dist3(s.r.p[kN - 1], s.B) < 1e-6);
    double mx = 0;
    for (int i = 0; i < kN - 1; ++i) { double d = dist3(s.r.p[i], s.r.p[i + 1]); if (d > mx) mx = d; }
    const double total = s.total();
    printf("settled: length %.3f m (rest %.3f), longest segment %.4f (ideal %.4f), ends %.3f apart\n", total, s.r.len, mx, s.r.len / (kN - 1), dist3(s.A, s.B));
    CHECK(total < s.r.len * 1.08);
    CHECK(mx < s.r.len / (kN - 1) * 1.12);
    // it hangs: the lowest middle point is below both ends, but not by much (no loop on the floor)
    double lo = 9; for (int i = 3; i < kN - 3; ++i) if (s.r.p[i][1] < lo) lo = s.r.p[i][1];
    printf("lowest middle point %.2f m (ends %.2f / %.2f)\n", lo, s.A[1], s.B[1]);
    CHECK(lo < s.B[1] - 0.05);
    CHECK(lo > s.A[1] - 0.65);
    CHECK(lo >= kRadiusM - 1e-9);
    // it settles (speed small at the end)
    double before[kN][3]; for (int i = 0; i < kN; ++i) for (int k = 0; k < 3; ++k) before[i][k] = s.r.p[i][k];
    s.run(0.2);
    double mv = 0; for (int i = 0; i < kN; ++i) { double d = dist3(before[i], s.r.p[i]); if (d > mv) mv = d; }
    printf("movement over 0.2 s when resting: %.4f m\n", mv);
    CHECK(mv < 0.03);   // 0.82: a longer, looser hose settles a little slower
  }
  // no ball: the hand comes right up to the chest after being out: the cord reels in, stays short and never folds into a knot
  {
    Scene s; s.init(); pose(s.hand, 0.3, 1.3, -0.8, 0); s.run(2.0);
    const double lenFar = s.r.len;
    pose(s.hand, 0.15, 1.15, -0.25, 0); s.run(2.0);
    const double dAB = dist3(s.A, s.B);
    printf("reel: length far %.2f m -> close %.2f m (ends %.2f apart), total %.2f, fold min %.2f\n", lenFar, s.r.len, dAB, s.total(), s.r.foldMin);
    CHECK(s.r.len < lenFar - 0.1);
    CHECK(fabs(s.r.len - want_length(dAB)) < 0.02);
    CHECK(s.total() < s.r.len * 1.08);
    double lo = 9; for (int i = 0; i < kN; ++i) if (s.r.p[i][1] < lo) lo = s.r.p[i][1];
    CHECK(lo > (s.A[1] < s.B[1] ? s.A[1] : s.B[1]) - 0.60);       // hangs at most 60 cm below the lower end (0.82: NPC-like loop)
    CHECK(s.r.foldMin > 0.70);                                    // no hairpin
  }
  // swinging the hand in and out quickly never makes a knot
  {
    Scene s; s.init(); s.run(1.0);
    s.r.reset_stats();
    for (int k = 0; k < 400; ++k) {
      pose(s.hand, 0.25 + 0.1 * sin(k * 0.09), 1.2 + 0.1 * sin(k * 0.13), -0.25 - 0.40 * (0.5 + 0.5 * sin(k * 0.07)), 0);
      s.run(0.011);
    }
    printf("in/out: fold min %.2f, max point speed %.1f m/s, resets %ld, lowest sag max %.2f\n", s.r.foldMin, s.r.maxSpeed, s.r.resets, s.r.sagMax);
    CHECK(s.r.resets == 0);
    CHECK(s.r.foldMin > 0.55);
    CHECK(s.r.sagMax < 0.65);
  }
  // pulled taut: ends far apart, the cord stretches at most 3 percent beyond the distance
  {
    Scene s; s.init(); pose(s.hand, 0.2, 1.4, -1.2, 0); s.run(2.0);
    double dAB = dist3(s.A, s.B);
    printf("far: A-B %.3f, cord %.3f, rest %.3f\n", dAB, s.total(), s.r.len);
    CHECK(s.r.len >= dAB * 1.029);
    CHECK(s.total() < dAB * 1.20 + 0.05);
  }
  // the floor holds: hand held low, head low
  {
    Scene s; s.init(); pose(s.head, 0, 0.9, 0, 0); pose(s.hand, 0.3, 0.12, -0.35, 0); s.run(3.0);
    for (int i = 0; i < kN; ++i) CHECK(s.r.p[i][1] > -1e-6);
    CHECK(s.r.floorHits > 0);
  }
  // the torso ellipse: no middle point ends up inside it (checked after a long settle)
  {
    Scene s; s.init(); s.run(3.0);
    const double sc = 1.7 / 1.6; int inside = 0;
    double fw[3], rt[3]; yaw_axes(s.r.yaw, fw, rt);
    for (int i = 3; i <= kN - 3; ++i) {
      const double top = 1.7 - 0.10 * sc, bot = 1.7 - 0.95 * sc;
      const double y = s.r.p[i][1]; if (y < top && y > bot) {
        const double dx = s.r.p[i][0] - (0 - fw[0] * 0.04 * sc), dz = s.r.p[i][2] - (0 - fw[2] * 0.04 * sc);
        const double u = dx * rt[0] + dz * rt[2], v = dx * fw[0] + dz * fw[2];
        const double g = sqrt(u * u / (0.20 * sc * 0.20 * sc) + v * v / (0.13 * sc * 0.13 * sc));
        if (g < 0.97) ++inside;
      }
    }
    printf("points inside the torso: %d, pushes %ld\n", inside, s.r.capsuleHits);
    CHECK(inside == 0);
  }
  // moving the hand drags the cord along (follows within a second) and the speed stays sane
  {
    Scene s; s.init(); s.run(2.0);
    s.r.reset_stats();
    for (int k = 0; k < 120; ++k) {   // 1.3 s of swinging the hand side to side
      pose(s.hand, 0.25 + 0.35 * sin(k * 0.12), 1.2 + 0.1 * sin(k * 0.2), -0.45, 0);
      s.run(0.011);
    }
    printf("swing: max point speed %.1f m/s, resets %ld, fold min %.2f\n", s.r.maxSpeed, s.r.resets, s.r.foldMin);
    CHECK(s.r.resets == 0);
    CHECK(s.r.maxSpeed < 25.0);
    CHECK(dist3(s.r.p[kN - 1], s.B) < 1e-6);
    for (int i = 0; i < kN; ++i) for (int k = 0; k < 3; ++k) CHECK(vm::is_finite_f((float)s.r.p[i][k]));
  }
  // teleport: the pinned end jumps 3 m, the rope starts again instead of stretching across the room
  {
    Scene s; s.init(); s.run(1.0);
    pose(s.head, 3, 1.7, 3, 0); pose(s.hand, 3.25, 1.2, 2.55, 0);
    s.run(0.05);
    CHECK(s.r.resets >= 2);
    CHECK(s.total() < 2.0);
  }
  // body yaw: the pack stays put for a head turn inside the dead zone, follows a bigger turn
  {
    Rope r; r.init();
    body_yaw(&r, 0.0, 0.011);
    body_yaw(&r, 20.0 * vm::kPi / 180.0, 0.5); CHECK(fabs(r.yaw) < 1e-9);
    for (int k = 0; k < 200; ++k) body_yaw(&r, 90.0 * vm::kPi / 180.0, 0.011);
    double want = (90.0 - 25.0) * vm::kPi / 180.0;
    printf("body yaw after a 90 degree turn: %.1f degrees\n", r.yaw * 180.0 / vm::kPi);
    CHECK(fabs(r.yaw - want) < 0.05);
  }
  // mesh: vertex count, all finite, normals unit, ends are metal, black rubber in between
  {
    Scene s; s.init(); s.run(1.0);
    static V buf[6000];
    CHECK(vertex_count() == (kRings - 1) * kSides * 6);
    CHECK(build_mesh(s.r, buf, 100) == 0);   // too small a buffer
    int n = build_mesh(s.r, buf, 6000);
    CHECK(n == vertex_count());
    int bad = 0;
    for (int i = 0; i < n; ++i) {
      for (int k = 0; k < 3; ++k) if (!vm::is_finite_f(buf[i].p[k]) || !vm::is_finite_f(buf[i].n[k])) ++bad;
      double l = sqrt((double)buf[i].n[0] * buf[i].n[0] + (double)buf[i].n[1] * buf[i].n[1] + (double)buf[i].n[2] * buf[i].n[2]);
      if (fabs(l - 1.0) > 0.01) ++bad;
      if (buf[i].c[3] != 0.0f) ++bad;
    }
    CHECK(bad == 0);
    {   // 0.75 seamless: the ends are dark metal, the hose between is black rubber; the colour changes smoothly (no ring-to-ring bands)
      auto avg = [&](int a, int b) { double t = 0; for (int i = a; i < b; ++i) t += buf[i].c[0]; return t / (double)(b - a); };
      const int ring6 = 6 * kSides;
      const double endA = avg(0, ring6), endB = avg(n - ring6, n), mid = avg(n / 2 - ring6 * 4, n / 2 + ring6 * 4);
      printf("tube colours: end %.3f / %.3f, middle %.3f\n", endA, endB, mid);
      CHECK(endA > mid * 1.3 && endB > mid * 1.3);
      double mxShade = 0, worstStep = 0;
      for (int i = 0; i < n; ++i) if (i > 600 && i < n - 600 && buf[i].c[0] > mxShade) mxShade = buf[i].c[0];
      CHECK(mxShade < 0.2);                           // the hose itself is dark
      // no banding: the same side of two neighbouring rings differs only a little
      for (int m = 20; m < (int)(kRings - 22); ++m) {
        const int i0 = m * ring6, i1 = (m + 1) * ring6;
        for (int s = 0; s < kSides; ++s) { const double d = fabs((double)buf[i0 + s * 6].c[0] - (double)buf[i1 + s * 6].c[0]); if (d > worstStep) worstStep = d; }
      }
      printf("largest colour step between neighbouring rings %.4f\n", worstStep);
      CHECK(worstStep < 0.03);
      // the boots flare: the end ring is thicker than the hose
      double rEnd = 0, rMid = 0; { const double* c0 = nullptr; (void)c0; }
      auto radius = [&](int m) { double cx = 0, cy = 0, cz = 0; for (int s = 0; s < kSides; ++s) { const V& v = buf[m * ring6 + s * 6]; cx += v.p[0]; cy += v.p[1]; cz += v.p[2]; }
        cx /= kSides; cy /= kSides; cz /= kSides; double rr = 0; for (int s = 0; s < kSides; ++s) { const V& v = buf[m * ring6 + s * 6]; rr += sqrt((v.p[0] - cx) * (v.p[0] - cx) + (v.p[1] - cy) * (v.p[1] - cy) + (v.p[2] - cz) * (v.p[2] - cz)); } return rr / kSides; };
      rEnd = radius(0); rMid = radius(kRings / 2);
      printf("tube radius: end %.4f m, middle %.4f m\n", rEnd, rMid);
      CHECK(rEnd > rMid * 1.3 && rMid > kRadiusM * 0.9 && rMid < kRadiusM * 1.1);
    }
    // every vertex lies within a thin tube round the rope
    double worst = 0;
    for (int i = 0; i < n; ++i) {
      double best = 9; for (int j = 0; j < kN; ++j) { double q[3] = {buf[i].p[0], buf[i].p[1], buf[i].p[2]}; double d = dist3(q, s.r.p[j]); if (d < best) best = d; }
      if (best > worst) worst = best;
    }
    CHECK(worst < 0.1);
    // the tube starts at the pack end and ends at the wand end (the spline passes through the rope's end points)
    double q0[3] = {0, 0, 0}, q1[3] = {0, 0, 0}; int c0 = 0, c1 = 0;
    for (int i = 0; i < 6 * kSides; ++i) { for (int k = 0; k < 3; ++k) q0[k] += buf[i].p[k]; ++c0; }
    for (int i = n - 6 * kSides; i < n; ++i) { for (int k = 0; k < 3; ++k) q1[k] += buf[i].p[k]; ++c1; }
    for (int k = 0; k < 3; ++k) { q0[k] /= c0; q1[k] /= c1; }
    CHECK(dist3(q0, s.r.p[0]) < 0.06); CHECK(dist3(q1, s.r.p[kN - 1]) < 0.06);
  }
  {   // 0.79: the chest shield no longer swallows the cord: rays from the eye to a cord at the side / in front miss it, a cord behind the chest is hidden
    const double head[3] = {0, 1.7, 0};
    static V sh[400];
    const int n = build_shield(head, 0.0, 1.0, sh, 400);
    CHECK(n > 0);
    auto hit = [&](const double* P) {   // does the segment eye -> P cross any shield triangle?
      for (int i = 0; i + 2 < n; i += 3) {
        double a[3], b[3], c[3], d[3] = {P[0] - head[0], P[1] - head[1], P[2] - head[2]};
        for (int k = 0; k < 3; ++k) { a[k] = sh[i].p[k]; b[k] = sh[i + 1].p[k]; c[k] = sh[i + 2].p[k]; }
        double e1[3] = {b[0] - a[0], b[1] - a[1], b[2] - a[2]}, e2[3] = {c[0] - a[0], c[1] - a[1], c[2] - a[2]};
        double pv[3] = {d[1] * e2[2] - d[2] * e2[1], d[2] * e2[0] - d[0] * e2[2], d[0] * e2[1] - d[1] * e2[0]};
        double det = e1[0] * pv[0] + e1[1] * pv[1] + e1[2] * pv[2];
        if (det > -1e-12 && det < 1e-12) continue;
        double tv[3] = {head[0] - a[0], head[1] - a[1], head[2] - a[2]};
        double u = (tv[0] * pv[0] + tv[1] * pv[1] + tv[2] * pv[2]) / det;
        if (u < 0 || u > 1) continue;
        double qv[3] = {tv[1] * e1[2] - tv[2] * e1[1], tv[2] * e1[0] - tv[0] * e1[2], tv[0] * e1[1] - tv[1] * e1[0]};
        double v = (d[0] * qv[0] + d[1] * qv[1] + d[2] * qv[2]) / det;
        if (v < 0 || u + v > 1) continue;
        double t = (e2[0] * qv[0] + e2[1] * qv[1] + e2[2] * qv[2]) / det;
        if (t > 0 && t < 1) return 1;
      }
      return 0;
    };
    const double inFront[3] = {0.25, 1.2, -0.45};    // the gun hand's cord end: right and in front (forward = -z)
    const double sideHip[3] = {0.30, 1.0, -0.05};    // beside you
    const double behind[3] = {0.0, 1.0, 0.35};       // behind the chest
    CHECK(!hit(inFront)); CHECK(!hit(sideHip)); CHECK(hit(behind));
  }
  printf(fails ? "cord: %d FAILED\n" : "cord: all ok\n", fails);
  return fails ? 1 : 0;
}
