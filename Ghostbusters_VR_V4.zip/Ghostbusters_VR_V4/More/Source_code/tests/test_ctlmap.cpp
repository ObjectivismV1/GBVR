// 0.78: the controller map is checked for clashes (standing rule: a new mapping must not interfere with any other control),
// and the real pad mapping is simulated for the two buttons that got a second job (right A: wheel, left X: trap).
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "ctlmap.h"
#include "padmath.h"
#include "gearmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

// what the game sees from the controllers in one poll, the way controllers.cpp builds it: the right A button goes through a TapHold, then pad::build,
// then the replay is added. holdCan = the wheel may claim A.
struct Rig {
  gear::TapHold a; gear::Wheel w; pad::Config cfg;
  Rig() { memset(this, 0, sizeof(*this)); a.reset(); w.reset(); cfg.deadzonePct = 18; cfg.twoHandFire = 0; cfg.dpadWithGrip = 1; cfg.ltCapture = 1; }
  pad::State poll(uint64_t lp, uint64_t rp, float rsx, float rsy, int canClaim, double dtMs) {
    int toGame = 0;
    const int aNow = pad::vr_pressed(rp, pad::kVrA);
    a.update(aNow, canClaim, dtMs, 200.0, 90.0, &toGame);
    if (aNow) rp &= ~(1ull << pad::kVrA);
    pad::Hand l = {}, r = {};
    l.valid = r.valid = 1; l.pressed = lp; r.pressed = rp; r.stickX = rsx; r.stickY = rsy;
    pad::State s = pad::build(l, r, cfg);
    if (toGame) s.buttons |= pad::kA;
    const int held = canClaim && a.state == 2;
    int slot = -1, hc = 0;
    w.update(held, held ? rsx : 0.0, held ? rsy : 0.0, 0, 0, dtMs, gear::kSlots, 0, &slot, &hc);
    if (w.open) { s.rx = 0; s.ry = 0; s.rt = 0; s.buttons &= (uint16_t)~(pad::kDpadUp | pad::kDpadDown | pad::kDpadLeft | pad::kDpadRight | pad::kRightShoulder); }
    return s;
  }
};

int main() {
  // ---- the written-down map has no unsettled clash and no wheel / trap on a grip
  int ia = -1, ib = -1;
  const int nc = ctlmap::conflicts(&ia, &ib);
  if (nc) printf("clash: [%s] versus [%s]\n", ctlmap::kMap[ia].what, ctlmap::kMap[ib].what);
  CHECK(nc == 0);
  CHECK(ctlmap::new_on_grip() == 0);
  // the check really catches a clash: two always-on uses of the same button
  { int clashes = 0;
    const ctlmap::Use a = {ctlmap::kRight, ctlmap::kFaceTop, ctlmap::kAlways, ctlmap::kNoGroup, "x", 1, nullptr}, b = {ctlmap::kRight, ctlmap::kFaceTop, ctlmap::kAlways, ctlmap::kNoGroup, "y", 1, nullptr};
    if (a.hand == b.hand && a.button == b.button && !(a.group != ctlmap::kNoGroup && a.group == b.group && a.ctx != b.ctx) && !ctlmap::settled(a, b)) ++clashes;
    CHECK(clashes == 1); }
  // every button the game uses is still mapped in the current layout: A, B, X, Y, RB, LB, RT, LT
  { pad::Hand l = {}, r = {}; l.valid = r.valid = 1;
    pad::Config c = {18, 0, 1, 0, 1};
    r.pressed = 1ull << pad::kVrA; CHECK(pad::build(l, r, c).buttons & pad::kA);
    r.pressed = 1ull << pad::kVrMenu; CHECK(pad::build(l, r, c).buttons & pad::kB);
    r.pressed = 1ull << pad::kVrStick; CHECK(pad::build(l, r, c).buttons & pad::kLeftShoulder); // Capture = LB
    l.layer = 1; CHECK(pad::build(l, r, c).buttons & pad::kRightShoulder);                        // D-layer click = RB / Vent
    l.layer = 0; r.pressed = 0; l.pressed = 1ull << pad::kVrA; CHECK(pad::build(l, r, c).buttons & pad::kX);
    l.pressed = 1ull << pad::kVrMenu; CHECK(pad::build(l, r, c).buttons & pad::kY);
    l.pressed = 0; l.trigger = 0.9f; CHECK(pad::build(l, r, c).lt > 200);                       // physical left trigger = LT
    l.trigger = 0; r.trigger = 0.9f; CHECK(pad::build(l, r, c).rt > 200); }
  // ---- the right A button: a tap is Interact, a hold is the wheel and never Interact
  { Rig g; const uint64_t A = 1ull << pad::kVrA;
    int sawA = 0;
    for (int i = 0; i < 7; ++i) { pad::State s = g.poll(0, A, 0, 0, 1, 10); sawA |= (s.buttons & pad::kA) != 0; }
    CHECK(!sawA);                                                                      // held back while undecided
    int aFrames = 0;
    for (int i = 0; i < 20; ++i) { pad::State s = g.poll(0, 0, 0, 0, 1, 10); aFrames += (s.buttons & pad::kA) != 0; }
    CHECK(aFrames >= 8 && aFrames <= 11);                                              // the tap reaches the game as a press of ~90 ms
    CHECK(!g.w.open);                                                                  // and never opened the wheel
    Rig h; sawA = 0; int open = 0;
    for (int i = 0; i < 40; ++i) { pad::State s = h.poll(0, A, 0, 0, 1, 10); sawA |= (s.buttons & pad::kA) != 0; open |= h.w.open; }
    CHECK(!sawA && open);                                                              // a hold: wheel, no Interact
    // while the wheel is open the right stick picks and does not turn / D-pad / vent / fire
    pad::State s = h.poll(0, A | (1ull << pad::kVrStick) | (1ull << pad::kVrTrigger), 1.0f, 0.0f, 1, 10);
    CHECK(s.rx == 0 && s.ry == 0 && s.rt == 0 && !(s.buttons & pad::kRightShoulder));
    // B (jump), X, Y, the left stick and the triggers of the other hand are untouched while the wheel is open
    s = h.poll((1ull << pad::kVrA) | (1ull << pad::kVrMenu), A | (1ull << pad::kVrMenu), 0.0f, 0.0f, 1, 10);
    CHECK((s.buttons & pad::kB) && (s.buttons & pad::kX) && (s.buttons & pad::kY));
    // the feature off (or in a menu / outside a level): A goes straight through, no delay
    Rig o; pad::State s0 = o.poll(0, A, 0, 0, 0, 10);
    CHECK(s0.buttons & pad::kA);
    // the right stick turns normally when A is only tapped
    Rig t; pad::State s1 = t.poll(0, 0, 1.0f, 0.0f, 1, 10);
    CHECK(s1.rx > 20000); }
  // ---- the left X button: nothing about it changed in the pad mapping (the trap logic strips it only while the trap is in the hand)
  { pad::Hand l = {}, r = {}; l.valid = r.valid = 1; pad::Config c = {18, 0, 1, 1};
    l.pressed = 1ull << pad::kVrA;
    CHECK(pad::build(l, r, c).buttons & pad::kX);
    l.pressed = 1ull << pad::kVrGrip;                                                   // the grip alone does nothing to the pad (no wheel, no trap on it)
    pad::State s = pad::build(l, r, c);
    CHECK(s.buttons == 0 && s.lt == 0 && s.rt == 0);
    r.pressed = 1ull << pad::kVrGrip;
    s = pad::build(l, r, c);
    CHECK(s.buttons == 0); }
  // ---- the trap: the hip zone grab takes X, a plain X press elsewhere is not a grab
  { gear::Trap t; memset(&t, 0, sizeof(t)); t.reset();
    double pos[3] = {-0.22, -0.55, 0.0}, dir[3], spd;
    t.update(0.011, 0, 1, 0, pos, 1.6, dir, &spd);
    CHECK(t.update(0.011, 1, 1, 0, pos, 1.6, dir, &spd) == 1);
    gear::Trap e; memset(&e, 0, sizeof(e)); e.reset();
    double far[3] = {0.3, -0.1, 0.4};
    e.update(0.011, 0, 0, 0.8, far, 1.6, dir, &spd);
    CHECK(e.update(0.011, 1, 0, 0.8, far, 1.6, dir, &spd) == 0 && !e.held);          // away from the hip: X stays the game's deploy
    // X held while the hand walks into the zone is not a grab (only the press counts)
    e.update(0.011, 1, 1, 0.0, pos, 1.6, dir, &spd);
    CHECK(!e.held); }
  // ---- 1.7.57 layout: left click = Sprint, right click = Capture, left trigger = Alt Fire, hold Y = D layer
  {
    pad::Config n = {18, 0, 1, 1, 1};   // deadzone, twoHandFire, dpadWithGrip, ltCapture, sprintClick
    pad::Hand l = {}, r = {}; l.valid = r.valid = 1;
    const uint64_t SK = 1ull << pad::kVrStick, A = 1ull << pad::kVrA, B = 1ull << pad::kVrMenu;
    // sprint: the left stick click is L3 and nothing else (no LT, no LB)
    l.pressed = SK; pad::State s = pad::build(l, r, n);
    CHECK((s.buttons & pad::kLeftThumb) && s.lt == 0 && !(s.buttons & pad::kLeftShoulder));
    // the game's own binding of Sprint is button 10 = L3 (settings.ini eControlSprint=10): kLeftThumb is that bit
    CHECK(pad::kLeftThumb == 0x0040);
    // Capture / wrangle is the normal RIGHT stick click: LB, and no longer Vent (RB)
    l.pressed = 0; r.pressed = SK; s = pad::build(l, r, n);
    CHECK((s.buttons & pad::kLeftShoulder) && !(s.buttons & pad::kRightShoulder) && s.lt == 0);
    // the other buttons are exactly as before
    r.pressed = A; CHECK(pad::build(l, r, n).buttons & pad::kA);
    r.pressed = B; CHECK(pad::build(l, r, n).buttons & pad::kB);
    r.pressed = 0; l.pressed = A; CHECK(pad::build(l, r, n).buttons & pad::kX);
    l.pressed = B; CHECK(pad::build(l, r, n).buttons & pad::kY);
    l.pressed = 0; l.trigger = 0.9f; CHECK(pad::build(l, r, n).lt > 200);
    l.trigger = 0; r.trigger = 0.9f; CHECK(pad::build(l, r, n).rt > 200);
    // Sprint and Capture together: both reach the game; Alt Fire stays on the physical left trigger
    r.trigger = 0; l.trigger = 0; l.pressed = SK; r.pressed = SK; s = pad::build(l, r, n);
    CHECK((s.buttons & pad::kLeftThumb) && (s.buttons & pad::kLeftShoulder) && s.lt == 0);
    // the D layer (left Y held): right stick = D-pad and no turning, stick click = Vent, B = HUD (R3), A = Select (Back); no jump, no interact, no second fire
    l.pressed = 0; l.layer = 1;
    r.stickX = 1.0f; r.stickY = 0.0f; r.pressed = 0; s = pad::build(l, r, n);
    CHECK((s.buttons & pad::kDpadRight) && s.rx == 0 && s.ry == 0);
    r.stickX = -1.0f; CHECK(pad::build(l, r, n).buttons & pad::kDpadLeft);
    r.stickX = 0.0f; r.stickY = 1.0f; CHECK(pad::build(l, r, n).buttons & pad::kDpadUp);
    r.stickY = -1.0f; CHECK(pad::build(l, r, n).buttons & pad::kDpadDown);
    r.stickY = 0.3f; s = pad::build(l, r, n); CHECK(!(s.buttons & 0x000F) && s.ry == 0);   // a small push is not a D-pad press and still does not turn
    r.stickY = 0.0f; r.pressed = SK; s = pad::build(l, r, n);
    CHECK((s.buttons & pad::kRightShoulder) && s.lt == 0);
    r.pressed = B; s = pad::build(l, r, n); CHECK((s.buttons & pad::kRightThumb) && !(s.buttons & pad::kB));
    r.pressed = A; s = pad::build(l, r, n); CHECK((s.buttons & pad::kBack) && !(s.buttons & pad::kA));
    // the left hand is unchanged in the layer: Sprint, move and Alt Fire; Capture is intentionally replaced by Vent while D-layer is held
    r.pressed = 0; l.pressed = SK; l.stickY = 1.0f; l.trigger = 0.9f; r.trigger = 0.9f;
    s = pad::build(l, r, n);
    CHECK((s.buttons & pad::kLeftThumb) && s.ly > 20000 && s.lt > 200 && s.rt > 200 && !(s.buttons & pad::kLeftShoulder));
    // the layer does nothing in the old layout (sprintClick off): the right stick turns and the old buttons stay
    pad::Config old = {18, 0, 1, 1, 0};
    l = pad::Hand(); r = pad::Hand(); l.valid = r.valid = 1; l.layer = 1; r.stickX = 1.0f;
    s = pad::build(l, r, old); CHECK(s.rx > 20000 && !(s.buttons & pad::kDpadRight));
    l.layer = 0; l.pressed = SK; s = pad::build(l, r, old); CHECK((s.buttons & pad::kLeftShoulder) && !(s.buttons & pad::kLeftThumb));
    r.pressed = SK; l.pressed = 0; s = pad::build(l, r, old); CHECK(s.buttons & pad::kRightShoulder);
  }
  // ---- 0.98 Y: a tap is the game's Y, a hold is the D layer and never Y
  {
    gear::TapHold y; y.reset();
    int toGame = 0, sawY = 0, claimed = 0;
    for (int i = 0; i < 20; ++i) { const int ev = y.update(1, 1, 10.0, 300.0, 90.0, &toGame); sawY |= toGame; claimed |= (ev == 1); }   // 200 ms: undecided
    CHECK(!sawY && !claimed && y.state == 1);
    int yFrames = 0;
    for (int i = 0; i < 20; ++i) { y.update(0, 1, 10.0, 300.0, 90.0, &toGame); yFrames += toGame; }
    CHECK(yFrames >= 18 && yFrames <= 22);                                              // the tap reaches the game as a press of about 200 ms
    gear::TapHold h; h.reset(); sawY = 0; claimed = 0;
    for (int i = 0; i < 40; ++i) { const int ev = h.update(1, 1, 10.0, 300.0, 90.0, &toGame); sawY |= toGame; claimed |= (ev == 1); }
    CHECK(!sawY && claimed && h.state == 2);                                            // a hold: the layer, no Y
    h.update(0, 1, 10.0, 300.0, 90.0, &toGame); CHECK(h.state == 0 && !toGame);         // let go: nothing is replayed
    gear::TapHold o; o.reset(); o.update(1, 0, 10.0, 300.0, 90.0, &toGame);              // feature off / in a menu / outside a level: Y goes straight through
    CHECK(toGame);
  }
  // ---- 1.7.22: the blink dash is a double-tap of the left stick itself: no new button, nothing on a grip, and the stick entry says so
  {
    int found = 0, onGrip = 0;
    for (int i = 0; i < ctlmap::kMapN; ++i) {
      const ctlmap::Use& u = ctlmap::kMap[i];
      if (u.hand == ctlmap::kLeft && u.button == ctlmap::kStick && u.isNew078 == 3 && strstr(u.what, "blink dash")) ++found;
      if (u.isNew078 == 3 && u.button == ctlmap::kGrip) ++onGrip;
    }
    CHECK(found == 1 && onGrip == 0);
    CHECK(ctlmap::new_on_grip() == 0);
  }
  if (!fails) printf("test_ctlmap: all passed\n");
  return fails ? 1 : 0;
}
