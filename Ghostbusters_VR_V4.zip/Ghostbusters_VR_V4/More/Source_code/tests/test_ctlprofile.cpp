// 1.7.117: controller compatibility decoder (src/ctlprofile.h).
#include "ctlprofile.h"
#include "handmath.h"
#include <cassert>
#include <cmath>
#include <cstring>

static const uint64_t B0 = 1ull << 32, B2 = 1ull << 34, B3 = 1ull << 35, GRIP = 1ull << 2, A = 1ull << 7, MENU = 1ull << 1;

static GbvrDecodeIn mk(int fam) {
  GbvrDecodeIn in; memset(&in, 0, sizeof(in));
  in.family = fam; in.stickAxisForce = -1;
  for (int i = 0; i < 5; ++i) in.axisType[i] = -1;
  return in;
}
static GbvrDecodeOut run(const GbvrDecodeIn& in, GbvrDecState* st = nullptr) {
  GbvrDecState local; memset(&local, 0, sizeof(local));
  GbvrDecodeOut o; gbvr_decode(&in, st ? st : &local, &o);
  return o;
}

int main() {
  // ---- Touch-style: identical to the old path (stick = axis 0, buttons untouched, grip = axis 2) over a grid of inputs
  {
    int n = 0;
    for (int bi = 0; bi < 64; ++bi) for (int k = 0; k < 9; ++k) {
      GbvrDecodeIn in = mk(1);
      in.ax[0] = (k - 4) * 0.25f; in.ay[0] = (4 - k) * 0.2f; in.ax[1] = 0.4f; in.ax[2] = (k % 3) * 0.5f; in.ax[3] = 0.9f; in.ay[3] = 0.9f; in.peaks[3] = 1.0f;
      in.pressed = (1ull << bi) | A; in.touched = (1ull << ((bi + 5) % 64));
      GbvrDecodeOut o = run(in);
      GbvrStickRead r; gbvr_pick_stick(1, 0, 1, in.ax, in.ay, in.pressed, in.touched, &r);
      assert(o.x == r.x && o.y == r.y && o.pressed == r.pressed && o.touched == r.touched && o.axis == 0);
      assert(o.grip == in.ax[2] && o.padA == 0 && o.family == 1);
      ++n;
    }
    assert(n == 576);
    // a Quest with a zero grip analog and the grip button down keeps grip analog 0 (unchanged from before)
    GbvrDecodeIn in = mk(1); in.pressed = GRIP;
    assert(run(in).grip == 0.0f);
  }

  // ---- Valve Index (real): edge push is not a click
  {
    GbvrDecodeIn in = mk(2); in.axisType[0] = 1; in.axisType[3] = 2;
    GbvrDecState st; memset(&st, 0, sizeof(st));
    in.ax[3] = 0.9f; in.ay[3] = 0.1f; in.peaks[3] = 0.9f; in.pressed = B3; in.touched = B3;
    GbvrDecodeOut o = run(in, &st);
    assert(o.axis == 3 && o.x == 0.9f && !(o.pressed & B0) && st.edgeSupp == 1);
    in.ax[3] = 0.5f;                       // still held, stick comes back: still no click until released
    o = run(in, &st); assert(!(o.pressed & B0));
    in.pressed = 0; in.touched = 0;        // released
    o = run(in, &st); assert(!(o.pressed & B0));
    in.ax[3] = 0.1f; in.ay[3] = 0.0f; in.pressed = B3;   // a deliberate click at rest passes
    o = run(in, &st); assert(o.pressed & B0);
    in.ax[3] = 0.9f;                       // push while the click is held: it stays
    o = run(in, &st); assert(o.pressed & B0);
    // grip comes from the grip button (the Index has no analog grip on axis 2)
    in.pressed = GRIP;
    assert(run(in, &st).grip == 1.0f);
    // an Index look-alike (maker not Valve): clicks are real, never dropped
    GbvrDecodeIn lk = mk(2); lk.lookalike = 1; lk.ax[0] = 0.9f; lk.peaks[0] = 0.9f; lk.pressed = B0; lk.touched = B0;
    GbvrDecState st2; memset(&st2, 0, sizeof(st2));
    o = run(lk, &st2); assert(o.axis == 0 && (o.pressed & B0) && st2.edgeSupp == 0);
    // real Index whose axis 3 never moved: axis 0 is read, the edge guard still applies
    GbvrDecodeIn fb = mk(2); fb.ax[0] = 0.95f; fb.pressed = B0;
    GbvrDecState st3; memset(&st3, 0, sizeof(st3));
    o = run(fb, &st3); assert(o.axis == 0 && !(o.pressed & B0) && st3.edgeSupp == 1);
  }

  // ---- Vive wand: trackpad = stick; the bottom of the pad is A
  {
    GbvrDecodeIn in = mk(3); in.axisType[0] = 1;
    GbvrDecState st; memset(&st, 0, sizeof(st));
    in.ax[0] = 0.0f; in.ay[0] = -0.8f; in.pressed = B0 | MENU; in.touched = B0;
    GbvrDecodeOut o = run(in, &st);
    assert(o.axis == 0 && (o.pressed & A) && !(o.pressed & B0) && (o.pressed & MENU) && o.padA && st.padAClicks == 1);
    in.ay[0] = 0.8f;                        // finger slides up while clicked: still the A decision
    o = run(in, &st); assert((o.pressed & A) && !(o.pressed & B0));
    in.pressed = MENU; in.ay[0] = 0.0f;     // released
    o = run(in, &st); assert(!(o.pressed & A) && !o.padA);
    in.ay[0] = 0.6f; in.pressed = B0 | MENU;   // click on the upper pad = stick click
    o = run(in, &st); assert((o.pressed & B0) && !(o.pressed & A) && st.padStickClicks == 1);
    // grip (bit 2) follows the button
    in.pressed = GRIP; assert(run(in, &st).grip == 1.0f);
  }

  // ---- Windows MR: stick on axis 2, trackpad click = A, stick click from its own bit
  {
    GbvrDecodeIn in = mk(4); in.axisType[0] = 1; in.axisType[2] = 2;
    in.ax[2] = 0.6f; in.ay[2] = -0.6f; in.ax[0] = 0.1f; in.pressed = B0 | GRIP; in.touched = B0;
    GbvrDecodeOut o = run(in);
    assert(o.axis == 2 && o.x == 0.6f && (o.pressed & A) && !(o.pressed & B0) && (o.pressed & GRIP) && o.grip == 1.0f);
    in.pressed = B2;                        // stick click
    o = run(in); assert((o.pressed & B0) && !(o.pressed & A));
    in.ax[2] = 0.7f; in.pressed = 0;        // stick pushed with nothing pressed: the stick value is not the grip
    assert(run(in).grip == 0.0f);
  }

  // ---- Unknown / other controllers
  {
    GbvrDecodeIn in = mk(5);                      // SteamVR says nothing: axis 0 (as before)
    in.ax[0] = 0.5f; in.pressed = B0;
    GbvrDecodeOut o = run(in); assert(o.axis == 0 && o.x == 0.5f && (o.pressed & B0));
    in = mk(5); in.axisType[0] = 1; in.axisType[2] = 2; in.ax[2] = -0.4f;   // trackpad + joystick: the joystick
    in.pressed = B2; o = run(in); assert(o.axis == 2 && o.x == -0.4f && (o.pressed & B0));
    in = mk(0); in.axisType[0] = 2; in.ax[0] = 0.3f; o = run(in); assert(o.axis == 0 && o.x == 0.3f);
    in = mk(5); in.axisType[0] = 1; in.ax[0] = 0.0f; in.ay[0] = -0.9f; in.pressed = B0;   // only a trackpad: bottom click = A
    o = run(in); assert(o.axis == 0 && (o.pressed & A) && !(o.pressed & B0));
    in = mk(5); in.ax[3] = 0.8f; in.peaks[3] = 0.8f;                         // no types, axis 0 never moved, axis 3 did
    o = run(in); assert(o.axis == 3 && o.x == 0.8f);
    in = mk(5); in.ax[0] = 0.8f; in.peaks[0] = 0.8f; in.peaks[3] = 0.9f;    // axis 0 works: stays
    o = run(in); assert(o.axis == 0);
  }

  // ---- overrides
  {
    GbvrDecodeIn in = mk(1); in.stickAxisForce = 3; in.ax[3] = 0.7f; in.ax[0] = 0.2f; in.pressed = B3;
    GbvrDecodeOut o = run(in); assert(o.axis == 3 && o.x == 0.7f && (o.pressed & B0));
    in = mk(1); in.layoutOverride = GBVR_LAYOUT_WMR; in.ax[2] = 0.5f; o = run(in);
    assert(o.family == 4 && o.axis == 2 && o.x == 0.5f);
    in = mk(2); in.layoutOverride = GBVR_LAYOUT_TOUCH; in.ax[0] = 0.5f; in.pressed = B0; o = run(in);
    assert(o.family == 1 && o.axis == 0 && (o.pressed & B0));
    // forcing the Index layout on a non-Valve controller (a Quest): treated as a look-alike, nothing dropped
    in = mk(1); in.layoutOverride = GBVR_LAYOUT_INDEX; in.lookalike = 1; in.ax[0] = 0.9f; in.peaks[0] = 0.9f; in.pressed = B0;
    o = run(in); assert(o.family == 2 && (o.pressed & B0));
  }

  // ---- Index grip tap = A
  {
    GbvrGripTap g; memset(&g, 0, sizeof(g));
    assert(!gbvr_grip_tap(&g, 1, 0.0f, 0, 1, 11.0, 250.0));
    assert(!gbvr_grip_tap(&g, 1, 0.0f, 0, 1, 11.0, 250.0));
    assert(gbvr_grip_tap(&g, 0, 0.0f, 0, 1, 11.0, 250.0));       // quick tap -> A
    for (int i = 0; i < 40; ++i) gbvr_grip_tap(&g, 1, 0.0f, 0, 1, 11.0, 250.0);   // long hold -> not a tap
    assert(!gbvr_grip_tap(&g, 0, 0.0f, 0, 1, 11.0, 250.0));
    gbvr_grip_tap(&g, 1, 0.0f, 0, 1, 11.0, 250.0);                // trigger pulled during the press (holster / draw gesture)
    gbvr_grip_tap(&g, 1, 0.8f, 0, 1, 11.0, 250.0);
    assert(!gbvr_grip_tap(&g, 0, 0.0f, 0, 1, 11.0, 250.0));
    gbvr_grip_tap(&g, 1, 0.0f, 1, 1, 11.0, 250.0);                // pressed in the pack zone
    assert(!gbvr_grip_tap(&g, 0, 0.0f, 1, 1, 11.0, 250.0));
    gbvr_grip_tap(&g, 1, 0.0f, 0, 0, 11.0, 250.0);                // not allowed (menu up, D layer ...)
    assert(!gbvr_grip_tap(&g, 0, 0.0f, 0, 0, 11.0, 250.0));
    assert(g.taps == 1);
  }
  // The rendered native grip consumes the same shared hold state on all
  // controller layouts. Touch/proximity may remain after the grip is released.
  for (int fam = 0; fam <= 5; ++fam) for (int lookalike = 0; lookalike <= (fam == 2); ++lookalike) {
    GbvrDecodeIn in = mk(fam); in.lookalike = lookalike;
    GbvrDecState st = {}; hand::SupportHold hold;
    auto poll = [&](int pressed) {
      in.pressed = pressed ? GRIP : 0; in.touched = GRIP;
      in.ax[2] = pressed ? 0.8f : 0.0f;
      const GbvrDecodeOut out = run(in, &st);
      return hold.step(hand::support_requested((out.pressed & GRIP) != 0, 1, 1), 1);
    };
    for (int i = 0; i < 100; ++i) assert(!poll(0));
    assert(!poll(1)); assert(!poll(1)); assert(poll(1));
    for (int i = 0; i < 100; ++i) assert(poll(1));
    assert(!poll(0));
    for (int i = 0; i < 100; ++i) assert(!poll(0));
    assert(!poll(1)); assert(!poll(1)); assert(poll(1)); assert(!poll(0));
  }
  return 0;
}
