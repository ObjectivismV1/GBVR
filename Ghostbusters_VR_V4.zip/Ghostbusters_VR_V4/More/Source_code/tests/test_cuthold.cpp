// 1.7.151 tests for cutholdmath.h (cutscene shots stay on the 2D screen)
#include <cstdio>
#include "cutholdmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
int main() {
  const double dt = 1.0 / 90.0, H = 2.0, never = 1e9;
  cuthold::Hold h; h.reset();
  double t = 100.0;
  // play in 3D: never held
  for (int i = 0; i < 900; ++i, t += dt) CHECK(cuthold::step(&h, t, 0, never, 0, H) == 0);
  CHECK(h.holds == 0);
  // the report: 2D for 9.3 s (no playable frames), then a 0.9 s shot on the player's camera, 2D 3.2 s, a 0.6 s shot, 2D 4.8 s, then play
  t += 9.3;
  int shown = 0;
  for (int i = 0; i < 81; ++i, t += dt) shown += !cuthold::step(&h, t, 1, never, 0, H);
  CHECK(shown == 0);
  t += 3.2;
  for (int i = 0; i < 54; ++i, t += dt) shown += !cuthold::step(&h, t, 1, never, 0, H);
  CHECK(shown == 0);
  t += 4.8;
  int held = 0, flat = 1;
  for (int i = 0; i < 400; ++i, t += dt) { const int k = cuthold::step(&h, t, flat, never, 0, H); held += k; if (!k) flat = 0; }
  CHECK(held >= 179 && held <= 181);                       // exactly the wait, then 3D for good
  CHECK(h.holds == 3 && h.shortShots == 2 && h.fullWaits == 1 && h.byInput == 0);
  CHECK(h.longestShort > 0.85 && h.longestShort < 0.95);
  // the stick ends the wait at once
  t += 5.0; flat = 1; held = 0;
  for (int i = 0; i < 200; ++i, t += dt) { const int k = cuthold::step(&h, t, flat, never, i >= 20, H); held += k; if (!k) flat = 0; }
  CHECK(held == 20 && h.byInput == 1);
  // after the game's pause menu: no wait
  t += 5.0; flat = 1; held = 0;
  for (int i = 0; i < 200; ++i, t += dt) { const int k = cuthold::step(&h, t, flat, 0.05 + i * dt, 0, H); held += k; if (!k) flat = 0; }
  CHECK(held == 0 && h.byMenu == 1);
  // let through, but the 2D screen needs two more frames to go: still through (no flicker back)
  t += 5.0; held = 0;
  for (int i = 0; i < 190; ++i, t += dt) held += cuthold::step(&h, t, 1, never, 0, H);
  CHECK(held == 180);
  // switched off
  t += 5.0;
  for (int i = 0; i < 50; ++i, t += dt) CHECK(cuthold::step(&h, t, 1, never, 0, 0.0) == 0);
  // a short 2D blip in the middle of play (0.6 s of another camera) is not a cutscene: no wait
  { cuthold::Hold q; q.reset(); double u = 50.0; int hh = 0;
    for (int i = 0; i < 300; ++i, u += dt) hh += cuthold::step(&q, u, 0, never, 0, H);
    u += 0.6;
    for (int i = 0; i < 100; ++i, u += dt) hh += cuthold::step(&q, u, i < 3, never, 0, H);
    CHECK(hh == 0 && q.byQuick == 1 && q.holds == 0);
    // ... but 2D for 3 s is one
    u += 3.0; int f2 = 1;
    for (int i = 0; i < 400; ++i, u += dt) { const int k = cuthold::step(&q, u, f2, never, 0, H); hh += k; if (!k) f2 = 0; }
    CHECK(hh >= 179 && hh <= 181);
    // a held shot does not count as "3D was shown": 2D 3 s, shot 1 s (held), 2D 1 s, shot 1 s -> still held
    u += 3.0; hh = 0;
    for (int i = 0; i < 90; ++i, u += dt) hh += cuthold::step(&q, u, 1, never, 0, H);
    u += 1.0;
    for (int i = 0; i < 90; ++i, u += dt) hh += cuthold::step(&q, u, 1, never, 0, H);
    CHECK(hh == 180);
  }
  // a time that is not a number is let through and changes nothing
  { volatile double z = 0.0; const double nan = z / z; const long hb = h.holds; CHECK(cuthold::step(&h, nan, 1, never, 0, H) == 0 && h.holds == hb); }
  if (!fails) printf("cuthold: ok\n");
  return fails ? 1 : 0;
}
