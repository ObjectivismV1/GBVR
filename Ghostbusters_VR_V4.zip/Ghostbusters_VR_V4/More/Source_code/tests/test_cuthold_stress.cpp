// 1.7.151 stress: days of random cutscenes / play / menus / camera blips through cutholdmath.h, checked against an independent model.
// Rules checked on every frame:
//  (1) a playable run shorter than the wait that follows a real 2D stretch is NEVER shown in 3D unless the stick was pushed, it follows a menu, or 3D was shown
//      less than 2 s before; (2) a run is never held longer than the wait; (3) once a run is shown it is never held again (no flicker);
//  (4) while 3D is up nothing is ever held; (5) after a menu / a short blip / with the wait off there is no hold at all; (6) the counters add up.
// Also: bad times (NaN, infinity, time running backwards, hours-long gaps, huge values) never hold for longer than the wait and never crash.
#include <cstdio>
#include "cutholdmath.h"
static unsigned long long s = 88172645463325252ULL;
static double rnd() { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return (double)(s >> 11) / 9007199254740992.0; }
int main() {
  long bad = 0, frames = 0, runs = 0;
  for (int pass = 0; pass < 3; ++pass) {
    const double H = pass == 0 ? 2.0 : pass == 1 ? 0.5 + rnd() * 5.0 : 0.0;
    cuthold::Hold h; h.reset();
    double t = pass == 1 ? 3.0e6 : 10.0;      // also far into a long session (qpc seconds get big)
    double last3D = -1e9; int flat = 0; long expectHolds = 0;
    for (int ep = 0; ep < 150000; ++ep) {
      const double dt = 1.0 / (rnd() < 0.2 ? 15.0 + rnd() * 30.0 : 30.0 + rnd() * 210.0);   // 15 FPS (a struggling PC, a 30 FPS limit) up to 240 Hz headsets
      const int kind = (int)(rnd() * 6);        // 0 short shot, 1 long play, 2 after a menu, 3 a shot with the stick, 4 a blip in play, 5 3D never left (hitch only)
      double gap = kind == 4 ? 0.26 + rnd() * 1.2 : kind == 5 ? 0.26 + rnd() * 0.5 : 2.2 + rnd() * 10.0;
      if (kind == 4 && flat) gap = 2.2 + rnd() * 4.0; // a blip can only follow 3D
      t += gap;
      if (kind != 5 || flat) flat = 1;           // the 2D screen came up during the gap (kind 5: only if it already was)
      const double len = kind == 0 ? 0.05 + rnd() * (H > 0.2 ? H - 0.1 : 0.1) : 0.05 + rnd() * 8.0;
      const double pausedAgo0 = kind == 2 ? rnd() * 2.4 : 2.6 + rnd() * 1e6;
      const double inputAt = kind == 3 ? rnd() * len : 1e9;
      const int quick = (t - last3D) < 2.0;      // the model: 3D was shown less than 2 s ago
      double t0 = -1; int shown = 0, pend = 0, held = 0, startedFlat = flat;
      ++runs;
      for (double e = 0; e < len; e += dt, t += dt, ++frames) {
        double jitter = rnd() < 0.01 ? dt * (1.0 + rnd() * 6.0) : 0.0;   // a hitch (kept under the break time together with the frame itself)
        if (jitter > 0.24 - dt) jitter = 0.24 - dt > 0 ? 0.24 - dt : 0;
        t += jitter; e += jitter;
        if (t0 < 0) t0 = t;
        const int in = e >= inputAt;
        const int k = cuthold::step(&h, t, flat, pausedAgo0 + (t - t0), in, H);
        if (k) {
          ++held;
          if (shown) ++bad;                                   // (3)
          if (!flat) ++bad;                                   // (4)
          if (t - t0 > H + 1e-9) ++bad;                       // (2)
          if (kind == 2 || quick || !startedFlat || H <= 0.0 || in) ++bad;   // (5)
        } else {
          if (!shown) {
            shown = 1;
            const int allowedEarly = kind == 2 || quick || !startedFlat || H <= 0.0 || in;
            if (!allowedEarly && (t - t0) < H - 1e-9) ++bad;  // (1)
          }
          last3D = t;
          if (flat && ++pend >= 2) flat = 0;                  // the 2D screen goes two frames after the first 3D frame
        }
      }
      if (held) ++expectHolds;
      if (len > H + 0.3 && !shown) ++bad;                     // a long run always gets to 3D
    }
    if (h.holds != expectHolds) ++bad;                                              // (6)
    if (h.holds < h.shortShots + h.fullWaits + h.byInput || h.holds > h.shortShots + h.fullWaits + h.byInput + 1) ++bad;
    printf("CUTHOLD STRESS pass %d (wait %.2f s): %ld runs, holds %ld = short shots kept 2D %ld + full waits %ld + ended by the stick %ld; no wait after a menu %ld, after a short blip %ld; longest shot kept 2D %.2f s\n",
           pass, H, runs, h.holds, h.shortShots, h.fullWaits, h.byInput, h.byMenu, h.byQuick, h.longestShort);
  }
  // bad clocks
  {
    cuthold::Hold h; h.reset();
    volatile double z = 0.0; const double nan = z / z, inf = 1.0 / z;
    double t = 5.0; long heldRun = 0, worst = 0;
    for (long i = 0; i < 4000000; ++i) {
      const double r = rnd();
      double now = t;
      if (r < 0.0005) now = nan; else if (r < 0.001) now = inf; else if (r < 0.0015) now = -inf; else if (r < 0.002) t -= rnd() * 100.0; else if (r < 0.0025) t += rnd() * 1e5; else if (r < 0.003) now = 1e300;
      else t += 0.011;
      const int k = cuthold::step(&h, now, rnd() < 0.7, rnd() < 0.9 ? 1e9 : rnd() * 5, rnd() < 0.001, 2.0);
      if (k != 0 && k != 1) ++bad;
      if (k) { if (++heldRun > worst) worst = heldRun; } else heldRun = 0;
      if (!(h.longestShort == h.longestShort)) ++bad;
    }
    if (worst > 2.0 / 0.011 + 3) ++bad;       // never held longer than the wait, whatever the clock did
    printf("CUTHOLD STRESS bad clocks: 4000000 frames with NaN / infinite / backward / jumping time: longest hold %ld frames (the wait is %d)\n", worst, (int)(2.0 / 0.011));
  }
  printf("CUTHOLD STRESS: %ld frames, rule breaks %ld\n", frames, bad);
  if (bad) { printf("FAIL\n"); return 1; }
  printf("CUTHOLD STRESS: all OK\n");
  return 0;
}
