// 1.7.22 blink dash detector (dashmath.h).
#include <stdio.h>
#include "dashmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static const double DT = 1.0 / 60.0;
struct Run { dash::State s; dash::Cfg c; double kmax; int starts; double t; };
static void init(Run& r) { dash::reset(r.s); r.c = dash::make_cfg(); r.kmax = 1.0; r.starts = 0; r.t = 0; }
static void hold(Run& r, double mag, double sec, int enabled = 1) {
  const int n = (int)(sec / DT + 0.5);
  for (int i = 0; i < n; ++i) { int st = 0; const double k = dash::feed(r.s, r.c, mag, DT, enabled, &st); if (k > r.kmax) r.kmax = k; r.starts += st; r.t += DT; }
}
int main() {
  Run r;
  // 1. a clean double tap starts exactly one dash with a multiplier up to K
  init(r); hold(r, 0.0, 0.3); hold(r, 1.0, 0.12); hold(r, 0.0, 0.15); hold(r, 1.0, 0.12);
  CHECK(r.starts == 1);
  hold(r, 1.0, 0.0);
  hold(r, 0.0, 0.5);
  CHECK(r.kmax > 3.9 && r.kmax <= 4.0 + 1e-9);
  CHECK(r.s.triggers == 1);
  // 2. the dash ends: after its duration the multiplier is back to 1
  { int st; double k = 0; for (int i = 0; i < 60; ++i) k = dash::feed(r.s, r.c, 0.0, DT, 1, &st); CHECK(k == 1.0); }
  // 3. a single tap does nothing; so does walking (held stick)
  init(r); hold(r, 0.0, 0.2); hold(r, 1.0, 0.1); hold(r, 0.0, 1.0);
  CHECK(r.starts == 0 && r.kmax == 1.0);
  init(r); hold(r, 1.0, 5.0);
  CHECK(r.starts == 0 && r.s.hardHolds == 1);
  // 4. a long push, release, push is NOT a double tap (the first push was a hold)
  init(r); hold(r, 1.0, 0.8); hold(r, 0.0, 0.1); hold(r, 1.0, 0.1);
  CHECK(r.starts == 0);
  // 5. too slow a second push is missed
  init(r); hold(r, 1.0, 0.1); hold(r, 0.0, 0.7); hold(r, 1.0, 0.1);
  CHECK(r.starts == 0 && r.s.windowMisses == 1);
  // 6. the stick must come back to the middle: walking with a wobble between 0.4 and 1.0 never fires
  init(r);
  for (int i = 0; i < 20; ++i) { hold(r, 1.0, 0.1); hold(r, 0.5, 0.1); }
  CHECK(r.starts == 0 && r.kmax == 1.0);
  // 7. cooldown: a second double tap right after the first is refused, one after 1.2 s works
  init(r); hold(r, 1.0, 0.1); hold(r, 0.0, 0.1); hold(r, 1.0, 0.1); hold(r, 0.0, 0.1);
  hold(r, 1.0, 0.1); hold(r, 0.0, 0.1); hold(r, 1.0, 0.1); hold(r, 0.0, 0.1);
  CHECK(r.starts == 1 && r.s.blockedByCooldown == 1);
  hold(r, 0.0, 1.3);
  hold(r, 1.0, 0.1); hold(r, 0.0, 0.1); hold(r, 1.0, 0.1);
  CHECK(r.starts == 2);
  // 8. the setting off: nothing ever happens and a running dash is cut at once
  init(r); hold(r, 1.0, 0.1, 0); hold(r, 0.0, 0.1, 0); hold(r, 1.0, 0.1, 0);
  CHECK(r.starts == 0 && r.kmax == 1.0);
  init(r); hold(r, 1.0, 0.1); hold(r, 0.0, 0.1); hold(r, 1.0, 0.1);
  { int st; const double k = dash::feed(r.s, r.c, 1.0, DT, 0, &st); CHECK(k == 1.0 && r.s.left == 0.0); }
  // 9. the shape and the total extra distance: 4x for about 0.3 s is about 3 m at 7.4 ft/s walking
  { dash::Cfg c = dash::make_cfg(); double extra = 0; const int n = 1000;
    for (int i = 0; i < n; ++i) { const double left = c.durSec * (1.0 - (double)i / n); extra += (dash::multiplier(c, left) - 1.0) * 7.4 * (c.durSec / n); }
    CHECK(extra > 4.0 && extra < 9.0);   // feet (2.9 m = 9.5 ft would be a full 4x over the whole time; the soft ends make it less)
    CHECK(dash::multiplier(c, 0.0) == 1.0 && dash::multiplier(c, c.durSec) < 1.01);
    for (int i = 0; i <= 100; ++i) { const double m = dash::multiplier(c, c.durSec * i / 100.0); CHECK(m >= 1.0 && m <= c.K + 1e-9); } }
  // 10. a giant dt (a hitch) does not skip the whole window
  init(r); hold(r, 1.0, 0.1); hold(r, 0.0, 0.1); { int st; dash::feed(r.s, r.c, 1.0, 5.0, 1, &st); CHECK(st == 1); }
  if (!fails) printf("test_dash: all pass\n");
  return fails ? 1 : 0;
}
