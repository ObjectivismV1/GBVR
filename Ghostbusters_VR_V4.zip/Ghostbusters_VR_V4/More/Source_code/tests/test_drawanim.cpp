#include <stdio.h>
#include <math.h>
#include "drawanimmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  using namespace drawanim;
  CHECK(is_gun_item(1) && is_gun_item(2) && is_gun_item(3) && is_gun_item(6) && is_gun_item(7));
  CHECK(!is_gun_item(0) && !is_gun_item(4) && !is_gun_item(5) && !is_gun_item(-2) && !is_gun_item(8));

  // no window: never draws the live relation
  Window w; reset(&w);
  CHECK(step(&w, 1, 1.0, 2.0, 1, 2.0, 1.0) == 0);

  // a switch to item 1 with a stored hold of about 10 cm: the gun comes in from 70 cm
  begin(&w, 1, 10.0);
  CHECK(step(&w, 1, 10.00, 2.3, 1, 2.0, 1.0) == 1);   // 70 cm away, 60 cm from the hold: drawn from the live relation
  CHECK(step(&w, 1, 10.10, 1.5, 1, 1.2, 1.0) == 1);
  CHECK(step(&w, 1, 10.20, 0.6, 1, 0.3, 1.0) == 1);   // still 9 cm from the hold: drawn from the live relation
  CHECK(step(&w, 1, 10.30, 0.36, 1, 0.05, 1.0) == 0); // within 1.5 cm of the hold: the normal hold again
  CHECK(w.open == 1);                                 // not closed until it stayed there
  CHECK(step(&w, 1, 10.40, 0.34, 1, 0.02, 1.0) == 0);
  CHECK(w.open == 0 && w.closedBy == 1);              // arrived for 60 ms: closed
  CHECK(w.shown == 3 && w.maxLenFt > 2.29 && w.maxLenFt < 2.31);
  CHECK(step(&w, 1, 10.50, 2.3, 1, 2.0, 1.0) == 0);   // once closed, a far relation is never drawn again

  // arriving, leaving again (a bounce) before the calm time: the window stays open
  begin(&w, 3, 20.0);
  CHECK(step(&w, 3, 20.00, 0.3, 1, 0.02, 1.0) == 0);
  CHECK(step(&w, 3, 20.03, 1.0, 1, 0.7, 1.0) == 1);   // it moved away again
  CHECK(w.open == 1 && w.nearSinceS < 0.0);

  // no stored hold yet (first draw of this weapon): drawn while farther than the normal path's own limit, then the normal path takes over
  begin(&w, 2, 30.0);
  CHECK(step(&w, 2, 30.00, 2.5, 0, 0.0, 1.0) == 1);
  CHECK(step(&w, 2, 30.10, 1.2, 0, 0.0, 1.0) == 1);
  CHECK(step(&w, 2, 30.20, 0.9, 0, 0.0, 1.0) == 0);   // inside 1.0 ft: handprop::step follows the live relation itself
  // the meter's limit is 0.82 ft
  begin(&w, 5, 40.0);
  CHECK(step(&w, 5, 40.00, 0.9, 0, 0.0, 0.82) == 1);
  CHECK(step(&w, 5, 40.05, 0.8, 0, 0.0, 0.82) == 0);

  // a relation beyond the cap is never drawn (cut-scene / streamed pose), and bad numbers are ignored
  begin(&w, 1, 50.0);
  CHECK(step(&w, 1, 50.0, 3.4, 1, 3.0, 1.0) == 0 && w.shown == 0);
  CHECK(step(&w, 1, 50.0, NAN, 1, 3.0, 1.0) == 0);
  CHECK(step(&w, 1, 50.0, 2.0, 1, INFINITY, 1.0) == 0);
  CHECK(w.open == 1);

  // time runs out
  begin(&w, 1, 60.0);
  CHECK(step(&w, 1, 61.4, 2.0, 1, 1.5, 1.0) == 1);
  CHECK(step(&w, 1, 61.6, 2.0, 1, 1.5, 1.0) == 0);
  CHECK(w.open == 0 && w.closedBy == 2);

  // a different item closes the window
  begin(&w, 1, 70.0);
  CHECK(step(&w, 5, 70.1, 2.0, 1, 1.5, 1.0) == 0);
  CHECK(w.open == 0 && w.closedBy == 3);

  // the leftover offset fades linearly and clamps
  CHECK(fabs(fade(0.0) - 1.0) < 1e-12 && fabs(fade(kFadeS * 0.5) - 0.5) < 1e-12 && fade(kFadeS) == 0.0 && fade(1.0) == 0.0 && fade(-1.0) == 1.0);

  printf(fails ? "FAILED\n" : "test_drawanim ok\n"); return fails;
}
