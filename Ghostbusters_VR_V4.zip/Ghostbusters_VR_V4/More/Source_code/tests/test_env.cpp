// 1.7.87: which graphics card, and what to tell the player (src/envmath.h).
#include "envmath.h"
#include <cassert>
#include <cstring>

int main() {
  using namespace env;
  assert(luid_pack(0x1234u, 0x5) == 0x0000000500001234ull);
  assert(gpu_relation(0, 0x10) == kGpuUnknown);          // SteamVR did not say
  assert(gpu_relation(0x10, 0) == kGpuUnknown);
  assert(gpu_relation(0x10, 0x10) == kGpuSame);
  assert(gpu_relation(0x10, 0x20) == kGpuDifferent);

  assert(std::strlen(gpu_hint(kGpuDifferent)) > 40);
  assert(std::strstr(gpu_hint(kGpuDifferent), "High performance") != nullptr);
  assert(gpu_hint(kGpuSame)[0] == 0 && gpu_hint(kGpuUnknown)[0] == 0);

  assert(dpi_scale_pct(96) == 100 && dpi_scale_pct(144) == 150 && dpi_scale_pct(192) == 200 && dpi_scale_pct(0) == 100);

  assert(window_kind(true, 1920, 1080, 1920, 1080) == kWinBorderless);   // covers the monitor, no frame
  assert(window_kind(false, 1920, 1080, 1920, 1080) == kWinMaximized);
  assert(window_kind(true, 1280, 720, 1920, 1080) == kWinWindowed);
  assert(window_kind(false, 1280, 720, 1920, 1080) == kWinWindowed);
  assert(window_kind(true, 1920, 1080, 0, 0) == kWinWindowed);           // monitor size unknown

  // steam facts -> note
  assert(std::strstr(steam_note(0, 0), "not started from Steam") != nullptr);
  assert(steam_note(1, 0)[0] == 0 && steam_note(1, 1)[0] == 0);
  return 0;
}
