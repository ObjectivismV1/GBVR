// 1.7.153 the "Smooth edges" filter (src/eyeaa.cpp). The shader itself runs on the graphics card; this is the same arithmetic on the CPU (line for line),
// run over test pictures: does it do what it should, and can it ever produce a colour that was not there?
#include <cstdio>
#include <cmath>
#include <vector>
#include <algorithm>
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
struct V3 { float r, g, b; };
static V3 operator+(V3 a, V3 b) { return {a.r + b.r, a.g + b.g, a.b + b.b}; }
static V3 operator-(V3 a, V3 b) { return {a.r - b.r, a.g - b.g, a.b - b.b}; }
static V3 operator*(V3 a, float k) { return {a.r * k, a.g * k, a.b * k}; }
struct Img { int w, h; std::vector<V3> p; V3 at(int x, int y) const { x = std::max(0, std::min(w - 1, x)); y = std::max(0, std::min(h - 1, y)); return p[y * w + x]; } };
// bilinear, clamp: what SampleLevel does with the linear sampler (u, v in 0..1; texel centres at +0.5)
static V3 samp(const Img& im, float u, float v) {
  const float x = u * im.w - 0.5f, y = v * im.h - 0.5f; const int x0 = (int)floorf(x), y0 = (int)floorf(y); const float fx = x - x0, fy = y - y0;
  return (im.at(x0, y0) * (1 - fx) + im.at(x0 + 1, y0) * fx) * (1 - fy) + (im.at(x0, y0 + 1) * (1 - fx) + im.at(x0 + 1, y0 + 1) * fx) * fy;
}
static float sat(float v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
static float luma(V3 c, int lin) { if (lin) c = {sqrtf(sat(c.r)), sqrtf(sat(c.g)), sqrtf(sat(c.b))}; return c.r * 0.299f + c.g * 0.587f + c.b * 0.114f; }
static float clampf(float v, float lo, float hi) { return v < lo ? lo : v > hi ? hi : v; }
static V3 filter(const Img& im, int X, int Y, int lin, float SHARP, int* edge) {
  const float pxx = 1.0f / im.w, pxy = 1.0f / im.h, u = (X + 0.5f) * pxx, v = (Y + 0.5f) * pxy;
  const V3 cM = samp(im, u, v), cNW = samp(im, u - pxx, v - pxy), cNE = samp(im, u + pxx, v - pxy), cSW = samp(im, u - pxx, v + pxy), cSE = samp(im, u + pxx, v + pxy);
  const float lM = luma(cM, lin), lNW = luma(cNW, lin), lNE = luma(cNE, lin), lSW = luma(cSW, lin), lSE = luma(cSE, lin);
  const float lMin = std::min(lM, std::min(std::min(lNW, lNE), std::min(lSW, lSE))), lMax = std::max(lM, std::max(std::max(lNW, lNE), std::max(lSW, lSE)));
  if (lMax - lMin >= std::max(0.0312f, lMax * 0.125f)) {
    *edge = 1;
    float dx = -((lNW + lNE) - (lSW + lSE)), dy = (lNW + lSW) - (lNE + lSE);
    const float red = std::max((lNW + lNE + lSW + lSE) * 0.03125f, 0.0078125f);
    const float rcp = 1.0f / (std::min(fabsf(dx), fabsf(dy)) + red);
    dx = clampf(dx * rcp, -8, 8) * pxx; dy = clampf(dy * rcp, -8, 8) * pxy;
    const V3 a = (samp(im, u + dx * (1.0f / 3 - 0.5f), v + dy * (1.0f / 3 - 0.5f)) + samp(im, u + dx * (2.0f / 3 - 0.5f), v + dy * (2.0f / 3 - 0.5f))) * 0.5f;
    const V3 b = a * 0.5f + (samp(im, u - dx * 0.5f, v - dy * 0.5f) + samp(im, u + dx * 0.5f, v + dy * 0.5f)) * 0.25f;
    const float lB = luma(b, lin);
    return (lB < lMin || lB > lMax) ? a : b;
  }
  *edge = 0;
  const V3 avg = (cNW + cNE + cSW + cSE) * 0.25f, s = cM + (cM - avg) * SHARP;
  auto lo = [&](float m, float a, float b, float c, float d) { return std::min(m, std::min(std::min(a, b), std::min(c, d))); };
  auto hi = [&](float m, float a, float b, float c, float d) { return std::max(m, std::max(std::max(a, b), std::max(c, d))); };
  return {clampf(s.r, lo(cM.r, cNW.r, cNE.r, cSW.r, cSE.r), hi(cM.r, cNW.r, cNE.r, cSW.r, cSE.r)), clampf(s.g, lo(cM.g, cNW.g, cNE.g, cSW.g, cSE.g), hi(cM.g, cNW.g, cNE.g, cSW.g, cSE.g)),
          clampf(s.b, lo(cM.b, cNW.b, cNE.b, cSW.b, cSE.b), hi(cM.b, cNW.b, cNE.b, cSW.b, cSE.b))};
}
static unsigned long long sd = 0x1234567ULL * 7919;
static float rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (float)((double)(sd >> 11) / 9007199254740992.0); }
int main() {
  const int W = 96, H = 96;
  // 1. a flat picture comes out exactly as it went in (nothing to smooth, nothing to sharpen)
  { Img im{W, H, std::vector<V3>(W * H, V3{0.3f, 0.5f, 0.7f})}; int e; for (int y = 0; y < H; y += 7) for (int x = 0; x < W; x += 5) { const V3 o = filter(im, x, y, 0, 0.25f, &e); CHECK(!e && fabsf(o.r - 0.3f) < 1e-6f && fabsf(o.g - 0.5f) < 1e-6f && fabsf(o.b - 0.7f) < 1e-6f); } }
  // 2. a slanted hard edge (white over dark, a stair of 1-pixel steps every 6 pixels): the steps get softer. Measured as the biggest jump between
  //    neighbours ALONG the edge row by row; and the picture's average brightness stays (nothing is added or lost).
  for (int lin = 0; lin < 2; ++lin) {
    Img im{W, H, std::vector<V3>(W * H)};
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) { const float v = y > 40 + x / 6 ? 0.9f : 0.08f; im.p[y * W + x] = {v, v, v}; }
    Img out = im; int edges = 0; double sumIn = 0, sumOut = 0;
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) { int e; out.p[y * W + x] = filter(im, x, y, lin, 0.25f, &e); edges += e; sumIn += im.p[y * W + x].r; sumOut += out.p[y * W + x].r; }
    // jaggedness: for every row, the number of pixels that take a value strictly between dark and bright (a hard stair has none; a smoothed edge has some)
    long between = 0; float worstOver = 0;
    for (int i = 0; i < W * H; ++i) { const float v = out.p[i].r; if (v > 0.12f && v < 0.86f) ++between; worstOver = std::max(worstOver, std::max(v - 0.9f, 0.08f - v)); }
    CHECK(edges > 150 && edges < W * 8);          // only the edge is touched
    CHECK(between > 80);                          // the stair became a ramp
    CHECK(worstOver < 1e-5f);                     // no value brighter than white or darker than the dark side (no halo)
    CHECK(fabs(sumOut - sumIn) / sumIn < 0.004);  // the brightness of the picture is kept
  }
  // 3. stress: 300 random pictures (noise, blocks, lines, extreme and out-of-range values, both colour modes, every sharpening): every result is finite and
  //    lies inside the range of the pixels it reads (so the filter can never invent a colour).
  long bad = 0, n = 0;
  for (int t = 0; t < 300; ++t) {
    Img im{48, 40, std::vector<V3>(48 * 40)};
    const int kind = t % 5; const float amp = kind == 4 ? 4.0f : 1.0f;
    for (int y = 0; y < im.h; ++y) for (int x = 0; x < im.w; ++x) {
      V3 c;
      if (kind == 0) c = {rnd(), rnd(), rnd()};
      else if (kind == 1) { const float v = ((x / 5 + y / 3) & 1) ? 1.0f : 0.0f; c = {v, v * rnd(), 1 - v}; }
      else if (kind == 2) { const float v = (x == y || x + 1 == y) ? 1.0f : 0.02f; c = {v, v, v}; }
      else if (kind == 3) c = {0, 0, 0};
      else c = {rnd() * amp - 1.0f, rnd() * amp, rnd() * amp};
      im.p[y * im.w + x] = c;
    }
    const int lin = t & 1; const float sharp = (float)(t % 11) / 10.0f;
    for (int y = 0; y < im.h; ++y) for (int x = 0; x < im.w; ++x, ++n) {
      int e; const V3 o = filter(im, x, y, lin, sharp, &e);
      float lo[3] = {1e9f, 1e9f, 1e9f}, hi[3] = {-1e9f, -1e9f, -1e9f};
      const int R = e ? 5 : 1;   // the edge blend reaches up to 4 pixels along the edge (and blends neighbours); the sharpening only the pixels touching it
      for (int j = -R; j <= R; ++j) for (int i = -R; i <= R; ++i) { const V3 c = im.at(x + i, y + j); const float* f = &c.r; for (int k = 0; k < 3; ++k) { lo[k] = std::min(lo[k], f[k]); hi[k] = std::max(hi[k], f[k]); } }
      const float* f = &o.r;
      for (int k = 0; k < 3; ++k) if (!(f[k] == f[k]) || f[k] < lo[k] - 1e-4f || f[k] > hi[k] + 1e-4f) ++bad;
    }
  }
  printf("EYEAA STRESS: %ld pixels of 300 random pictures: results outside the colours around them (or not a number): %ld\n", n, bad);
  CHECK(bad == 0);
  if (!fails) printf("eyeaa: ok\n");
  return fails ? 1 : 0;
}
