#include <stdio.h>
#include <math.h>
#include "fightmath.h"
using namespace fight;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

int main() {
  // which damage is a beam
  CHECK(is_beam(kDmgProton, 0)); CHECK(is_beam(kDmgSlime, 0)); CHECK(is_beam(kDmgFreeze, 0)); CHECK(is_beam(kDmgWrangle, 0)); CHECK(is_beam(kDmgWrangleSlam, 0));
  CHECK(is_beam(0x64, 0x0C)); CHECK(is_beam(0x64, 0x0D)); CHECK(is_beam(0x64, 0x0E)); CHECK(is_beam(0x64, 0x0F)); CHECK(is_beam(0x64, 0x10));
  CHECK(is_beam(0x64, 0x13)); CHECK(is_beam(0x64, 0x16));
  CHECK(!is_beam(0x65, 0x02)); CHECK(!is_beam(0x68, 0x0B)); CHECK(!is_beam(0x77, 0)); CHECK(is_beam(0x64, 0x11)); CHECK(is_beam(0x64, 0x12)); CHECK(is_beam(0x64, 0x09)); CHECK(!is_beam(0x64, 0x17)); CHECK(!is_beam(0x64, 0x08)); CHECK(!is_beam(0x64, 0x0A));   // 1.7.19: boson dart + meson count; turret / sniper / body do not
  // boost: +15 % and nothing silly
  CHECK(fabsf(boost(100.0f, 115) - 115.0f) < 1e-3f);
  CHECK(boost(0.0f, 115) == 0.0f);
  CHECK(boost(100.0f, 100) == 100.0f);
  CHECK(boost(100.0f, 50) == 100.0f);            // never less than the game's own damage
  CHECK(fabsf(boost(100.0f, 9999) - 400.0f) < 1e-3f);   // capped at x4
  CHECK(boost(-5.0f, 115) == -5.0f);             // a heal / negative number is left alone
  { float nan = 0.0f / 0.0f; volatile float z = 0.0f; nan = z / z; CHECK(!(boost(nan, 115) == boost(nan, 115))); }
  // health fraction
  CHECK(fabs(health_frac(50, 100) - 0.5) < 1e-9);
  CHECK(health_frac(150, 100) == 1.0);
  CHECK(health_frac(-3, 100) == 0.0);
  CHECK(health_frac(50, 0) < 0.0);
  { float base = 1.0f;
    CHECK(!health_drop(0.999f, &base)); CHECK(!health_drop(0.997f, &base));
    CHECK(health_drop(0.995f, &base)); CHECK(fabsf(base - 0.995f) < 1e-6f);
    CHECK(!health_drop(0.998f, &base)); CHECK(!health_drop(1.0f, &base));
    CHECK(!health_drop(0.998f, &base)); CHECK(health_drop(0.995f, &base));
  }
  // colours: red low, green high
  { // 1.7.19: the colour changes smoothly with health: no jump bigger than a few percent per 1 % of health anywhere, and the ramp runs green -> yellow -> red
    float prev[3]; colour_for(1.0, prev); double worst = 0.0;
    for (int i = 99; i >= 0; --i) { float c[3]; colour_for(i / 100.0, c); for (int k = 0; k < 3; ++k) { const double d = fabs((double)c[k] - (double)prev[k]); if (d > worst) worst = d; prev[k] = c[k]; } }
    CHECK(worst < 0.06);
    float a[3], b[3], d[3]; colour_for(0.75, a); colour_for(0.5, b); colour_for(0.2, d);
    CHECK(a[0] > 0.4f && a[0] < 0.8f && a[1] > 0.85f);   // lime between green and yellow
    CHECK(b[0] > 0.95f && b[1] > 0.8f);                   // yellow
    CHECK(d[0] > 0.9f && d[1] > 0.2f && d[1] < 0.5f);     // orange-red on the way to red
    // the shown health eases toward the real one and never overshoots
    double sh = 1.0; for (int i = 0; i < 6; ++i) { const double n2 = ease_shown(sh, 0.2, 0.011); CHECK(n2 < sh && n2 > 0.2); sh = n2; }
    CHECK(ease_shown(-1.0, 0.7, 0.011) == 0.7);           // a new bar starts at the real value
    double s2 = 1.0; for (int i = 0; i < 200; ++i) s2 = ease_shown(s2, 0.3, 0.011); CHECK(fabs(s2 - 0.3) < 0.01); }
  { float c[3]; colour_for(0.0, c); CHECK(c[0] > 0.9f && c[1] < 0.2f); colour_for(1.0, c); CHECK(c[1] > 0.9f && c[0] < 0.3f); colour_for(0.5, c); CHECK(c[0] > 0.9f && c[1] > 0.8f); }
  // widths: small, bounded, scaled by the size setting
  CHECK(bar_width(1.0, 0.3, 100) >= 0.19);
  CHECK(bar_width(200.0, 0.3, 100) <= 1.31);
  CHECK(fabs(bar_width(10.0, 0.3, 200) - 2.0 * bar_width(10.0, 0.3, 100)) < 1e-9);
  CHECK(bar_width(10.0, 0.3, 100) < 0.6);       // "small": half a metre at 10 m
  // building
  static cord::V v[4000];
  Look look = {100.0, 1, 8.0};
  Bar one = {{0.0f, 0.0f, 6.0f}, 0.5f, 0.73f, 0};
  int n = build(&one, 1, 0.032, look, v, 4000);
  CHECK(n > 0 && n % 3 == 0);
  CHECK(n < 1500);
  for (int i = 0; i < n; ++i) { CHECK(v[i].p[2] > 0.0f); CHECK(v[i].c[3] > 0.5f); }
  // the fill is as wide as the fraction says: find the widest coloured (non-white non-dark) rectangle extent
  {
    double lo = 1e9, hi = -1e9;
    for (int i = 0; i < n; ++i) { const float* c = v[i].c; if (c[1] > 0.8f && c[2] < 0.4f) { if (v[i].p[0] < lo) lo = v[i].p[0]; if (v[i].p[0] > hi) hi = v[i].p[0]; } }
    CHECK(hi > lo);
  }
  // 1.7.103: the round ring: only on the ghost marked as the ring's, as a closed circle whose filled part follows the health
  {
    Look rl = look; rl.ringStyle = 1;
    Bar two[2] = {{{0.0f, 0.0f, 6.0f}, 0.5f, 0.5f, 0}, {{1.0f, 0.0f, 9.0f}, 0.5f, 1.0f, (unsigned)kFlagFocus}};
    CHECK(build(two, 1, 0.0, rl, v, 4000) == 0);                       // not the ring's ghost: nothing at all
    const int nr = build(two + 1, 1, 0.0, rl, v, 4000);
    CHECK(nr > 0 && nr % 3 == 0 && nr < 2000);
    for (int i = 0; i < nr; ++i) { CHECK(v[i].p[2] > 8.9f && v[i].p[2] < 9.1f); CHECK(v[i].c[3] > 0.5f); }
    const int nBoth = build(two, 2, 0.0, rl, v, 4000);
    CHECK(nBoth == nr);                                                // two ghosts, one marked: one ring
    // a full ring has more coloured vertices than a half ring, and an empty one has no coloured fill beyond the hairline glow
    Bar half = two[1]; half.frac = 0.5f;
    Bar empty = two[1]; empty.frac = 0.0f;
    const int nHalf = build(&half, 1, 0.0, rl, v, 4000);
    const int nEmpty = build(&empty, 1, 0.0, rl, v, 4000);
    CHECK(nEmpty < nHalf && nHalf < nr);
    // the ring is centred on the ghost: the average of the black frame vertices is the ghost's place
    double sx = 0, sy = 0; int cnt = 0;
    const int nf = build(two + 1, 1, 0.0, rl, v, 4000);
    for (int i = 0; i < nf; ++i) if (v[i].c[0] < 0.01f && v[i].c[1] < 0.01f && v[i].c[2] < 0.01f) { sx += v[i].p[0]; sy += v[i].p[1]; ++cnt; }
    CHECK(cnt > 0 && fabs(sx / cnt - 1.0) < 0.02 && fabs(sy / cnt) < 0.02);
    // size follows the setting and the distance
    CHECK(fabs(ring_diameter(10.0, 0.3, 120) - 1.2 * ring_diameter(10.0, 0.3, 100)) < 1e-9);
    CHECK(ring_diameter(10.0, 0.3, 60) > ring_diameter(2.0, 0.3, 60));
    // a tiny buffer reports "over" rather than writing past it
    CHECK(build(two + 1, 1, 0.0, rl, v, 30) == -1);
  }
  // 1.7.24: no percent number any more, looked at or not, recently hit or not
  Bar side = {{3.0f, 0.0f, 6.0f}, 0.5f, 0.73f, 0};
  int nSide = build(&side, 1, 0.0, look, v, 4000);
  CHECK(nSide > 0 && nSide < n + 1);
  Bar recent = side; recent.flags = kFlagRecent;
  int nRecent = build(&recent, 1, 0.0, look, v, 4000);
  CHECK(nRecent == nSide);                       // recently hit: same bar, no digits
  look.digitsFocus = 0;
  CHECK(build(&one, 1, 0.032, look, v, 4000) == nSide);   // digits setting is ignored
  look.digitsFocus = 1;
  CHECK(build(&one, 1, 0.032, look, v, 4000) == nSide);
  // 1.7.24: the frame is black and nothing is white; the health colour only appears as the fill and the hairline
  {
    int black = 0, white = 0;
    for (int i = 0; i < nSide; ++i) { const float* c = v[i].c; if (c[0] == 0.0f && c[1] == 0.0f && c[2] == 0.0f) ++black; if (c[0] > 0.9f && c[1] > 0.9f && c[2] > 0.9f) ++white; }
    CHECK(black >= 12);
    CHECK(white == 0);
  }
  // behind the player / far outside the picture: nothing
  Bar behind = {{0, 0, -2.0f}, 0.5f, 1.0f, 0};
  CHECK(build(&behind, 1, 0.0, look, v, 4000) == 0);
  Bar wide = {{40.0f, 0, 5.0f}, 0.5f, 1.0f, 0};
  CHECK(build(&wide, 1, 0.0, look, v, 4000) == 0);
  // empty bar: rim, track and ticks only
  Bar empty = {{2.0f, 0, 6.0f}, 0.5f, 0.0f, 0};
  int nEmpty = build(&empty, 1, 0.0, look, v, 4000);
  CHECK(nEmpty > 0 && nEmpty < nSide);
  // a full set of 24 fits
  Bar many[kMaxBars];
  for (int i = 0; i < kMaxBars; ++i) { many[i] = one; many[i].p[0] = (float)(i % 6) - 3.0f; many[i].p[2] = 4.0f + i; many[i].flags = i < 3 ? kFlagRecent : 0; }
  int nMany = build(many, kMaxBars, 0.0, look, v, 4000);
  CHECK(nMany > 0 && nMany <= 4000);
  // too small a buffer is never overrun: 1.7.165 the nearest bars are kept, the farthest left out
  { const int nS = build(many, kMaxBars, 0.0, look, v, 100); CHECK(nS > 0 && nS <= 100 && nS % 3 == 0); }
  // far to near: the nearest bar is drawn last
  {
    Bar two[2] = {{{0.0f, 0.0f, 5.0f}, 0.5f, 1.0f, 0}, {{0.0f, 0.0f, 15.0f}, 0.5f, 1.0f, 0}};
    int n2 = build(two, 2, 0.0, look, v, 4000);
    CHECK(n2 > 0);
    CHECK(v[0].p[2] > 14.0f && v[n2 - 1].p[2] < 6.0f);
  }
  // text: 100 % has four glyphs, 7 % has two
  { Buf b = {v, 0, 4000, 0}; float c[3] = {1, 1, 1}; text(b, 100, 0, 0, 5, 0.01, c); int a = b.n; b.n = 0; text(b, 7, 0, 0, 5, 0.01, c); CHECK(a > b.n && b.n > 0); }
  // swing: a quick down-swing with the capture stream held presses the trigger once; not without capture; refractory
  {
    Swing s; s.reset(); s.swings = 0;
    double pos[3] = {0, 1.2, -0.4};
    int fired = 0, held = 0;
    for (int i = 0; i < 60; ++i) {       // 0.66 s still
      CHECK(s.update(0.011, pos, 1, 1.4, 1.8) == 0);
    }
    for (int i = 0; i < 20; ++i) {       // down at 3 m/s for 0.22 s
      pos[1] -= 3.0 * 0.011;
      if (s.update(0.011, pos, 1, 1.4, 1.8)) { ++held; if (!fired) fired = i; }
    }
    CHECK(held > 10 && held < 25);
    CHECK(s.swings == 1);
    for (int i = 0; i < 40; ++i) { pos[1] += 1.0 * 0.011; s.update(0.011, pos, 1, 1.4, 1.8); }    // coming back up slowly: nothing new
    CHECK(s.swings == 1);
    Swing t; t.reset(); t.swings = 0;
    double q[3] = {0, 1.2, -0.4};
    int any = 0;
    for (int i = 0; i < 40; ++i) { q[1] -= 3.0 * 0.011; any |= t.update(0.011, q, 0, 1.4, 1.8); }   // no capture stream: never
    CHECK(!any && t.swings == 0);
    Swing u; u.reset(); u.swings = 0;
    double w[3] = {0, 1.2, -0.4};
    any = 0;
    for (int i = 0; i < 60; ++i) { w[1] -= 0.5 * 0.011; any |= u.update(0.011, w, 1, 1.4, 1.8); }    // slow lowering: never
    CHECK(!any);
    Swing x; x.reset(); x.swings = 0;
    double h[3] = {0, 1.2, -0.4};
    any = 0;
    for (int i = 0; i < 60; ++i) { h[0] += 3.0 * 0.011; any |= x.update(0.011, h, 1, 1.4, 1.8); }    // sideways: never
    CHECK(!any);
  }
  // 1.7.3 collectible markers
  {
    cord::V buf[1500];
    Marker m[4];
    m[0] = {{0.0f, 0.0f, 6.0f}, 0, 20.0f};      // straight ahead, 6 m, a collectible
    m[1] = {{2.0f, 0.5f, 8.0f}, 1, 26.0f};      // off to the side, a PKE target
    m[2] = {{0.0f, 0.0f, -4.0f}, 0, 13.0f};     // behind you: not drawn
    m[3] = {{0.1f, 0.0f, 0.6f}, 0, 2.0f};       // closer than a metre: not drawn
    const int n1 = build_markers(m, 1, 0.0, 100.0, 0.0, buf, 1500);
    CHECK(n1 > 0 && n1 % 3 == 0);
    const int n2 = build_markers(m, 2, 0.0, 100.0, 0.0, buf, 1500);
    CHECK(n2 > n1 - 100 && n2 > 0);                                   // a second marker adds geometry (the first one has the distance number, the second one does not)
    CHECK(build_markers(m + 2, 1, 0.0, 100.0, 0.0, buf, 1500) == 0);  // behind
    CHECK(build_markers(m + 3, 1, 0.0, 100.0, 0.0, buf, 1500) == 0);  // too close
    CHECK(build_markers(m, 0, 0.0, 100.0, 0.0, buf, 1500) == 0);
    CHECK(build_markers(m, 4, 0.0, 100.0, 0.0, buf, 20) < 0);         // buffer too small
    bool finite = true; for (int i = 0; i < n2; ++i) for (int k = 0; k < 3; ++k) if (!(buf[i].p[k] == buf[i].p[k]) || fabsf(buf[i].p[k]) > 1000.0f) finite = false;
    CHECK(finite);
    // the gold collectible is gold, the PKE target is cyan
    build_markers(m, 1, 0.0, 100.0, 0.0, buf, 1500); bool gold = false; for (int i = 0; i < n1; ++i) if (buf[i].c[0] > 0.9f && buf[i].c[1] > 0.7f && buf[i].c[2] < 0.2f) gold = true; CHECK(gold);
    const int nc = build_markers(m + 1, 1, 0.0, 100.0, 0.0, buf, 1500); bool cyan = false; for (int i = 0; i < nc; ++i) if (buf[i].c[0] < 0.3f && buf[i].c[2] > 0.9f) cyan = true; CHECK(cyan);
    // far markers are bigger than near ones but bounded; the size setting scales them
    CHECK(marker_width(30.0, 100) <= 0.551 && marker_width(1.0, 100) >= 0.069);
    CHECK(marker_width(10.0, 200) > marker_width(10.0, 100) * 1.9);
    // the pulse keeps the shape finite for any phase
    for (double ph = -50.0; ph < 50.0; ph += 7.3) CHECK(build_markers(m, 1, 0.0, 100.0, ph, buf, 1500) > 0);
    // 12 markers fit the buffer the draw uses
    Marker many[kMaxMarkers]; for (int i = 0; i < kMaxMarkers; ++i) many[i] = {{(float)(i - 6) * 0.3f, 0.2f, 4.0f + i}, i & 1, 10.0f + i};
    CHECK(build_markers(many, kMaxMarkers, 0.0, 300.0, 1.0, buf, 1500) > 0);
  }
  // A cached bar must remain at the same world point after head movement.
  {
    const float oldView[9] = {1,0,0, 0,1,0, 0,0,1}, oldHead[3] = {0,0,0};
    const float view[9] = {0,0,1, 0,1,0, -1,0,0}, head[3] = {1,0,0};
    Bar b = {{1,2,3}, 0.5f, 1, 0, 1};
    rebase_bar(b, oldView, oldHead, 2, view, head, 2);
    CHECK(fabs(b.p[0] + 3) < 1e-5 && fabs(b.p[1] - 2) < 1e-5 && fabs(b.p[2] - 0.5) < 1e-5);
    CHECK(fabs(b.radius - 0.5) < 1e-5);
  }
  if (!fails) printf("test_fight: all passed\n");
  return fails ? 1 : 0;
}
