// 0.84 fingers and the PKE: same fake engine as test_armcore, with finger chains and the cloth_pke bones.
// (the first lines below are the original description) A fake skinned player model with the engine's memory layout (layout.h "0.57 skeleton") and the three engine functions
// the arm override calls, to run armcore.h end to end: bone indices by name, chains, the write loop, fingers below the
// hand, idempotence, stale cache, bad data.
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "armcore.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double fabs_(double x) { return x < 0 ? -x : x; }


enum { N = 35 };
static const char* kNames[N] = {"bone_pelvis", "bone_spine1", "bone_spine2", "bone_spine3", "bone_R_clavicle", "bone_R_upperArm", "bone_R_forearm", "bone_R_hand",
                                "bone_L_clavicle", "bone_L_upperArm", "bone_L_forearm", "bone_L_hand", "bone_head",
                                "bone_R_index1", "bone_R_index2", "bone_R_index3", "bone_R_index4", "bone_R_pinkie1", "bone_R_pinkie2", "bone_R_pinkie3", "bone_R_pinkie4",
                                "bone_R_thumb1", "bone_R_thumb2", "bone_R_thumb3", "bone_R_thumb4",
                                "bone_L_index1", "bone_L_index2", "bone_L_index3", "bone_L_index4", "bone_L_pinkie1", "bone_L_pinkie2", "bone_L_pinkie3", "bone_L_pinkie4",
                                "cloth_pke", "cloth_pke1"};
static const int kParent[N] = {-1, 0, 1, 2, 3, 4, 5, 6, 3, 8, 9, 10, 3, 7, 13, 14, 15, 7, 17, 18, 19, 7, 21, 22, 23, 11, 25, 26, 27, 11, 29, 30, 31, 0, 33};

struct Fake { uint8_t* actor; uint8_t* skel; uint8_t* local; float* world; int logs; };
static Fake F;
static void qset(uint8_t* l, const double* axis, double deg, double scale, const double* pos) {
  double h = deg * vm::kPi / 360.0, s, c;
  vm::dsincos(h, &s, &c);
  float* f = (float*)l;
  f[0] = (float)(axis[0] * s); f[1] = (float)(axis[1] * s); f[2] = (float)(axis[2] * s); f[3] = (float)c;
  f[4] = f[5] = f[6] = (float)scale;
  f[7] = (float)pos[0]; f[8] = (float)pos[1]; f[9] = (float)pos[2];
}
struct G {
  static void local(const void* l, float* out) {
    const float* f = (const float*)l;
    double x = f[0], y = f[1], z = f[2], w = f[3];
    double R[9] = {1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w),
                   2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w),
                   2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)};
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = (float)(R[c * 3 + r] * f[4 + r]);   // rows = images of the axes (row vectors)
    out[12] = f[7]; out[13] = f[8]; out[14] = f[9];
  }
  static void mul(float* out, const float* a, const float* b) {
    float t[16] = {0};
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) t[r * 4 + c] = a[r * 4] * b[c] + a[r * 4 + 1] * b[4 + c] + a[r * 4 + 2] * b[8 + c];
    for (int c = 0; c < 3; ++c) t[12 + c] = a[12] * b[c] + a[13] * b[4 + c] + a[14] * b[8 + c] + b[12 + c];
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = t[r * 4 + c];
  }
  static void ensure(void* m) {
    int* state = (int*)((uint8_t*)m + layout::kOffModelState - layout::kOffActorModel + layout::kOffActorModel);   // M + 0x2b08
    if (*state > 0) return;
    for (int i = 0; i < N; ++i) {
      float tmp[16] = {0};
      local(F.local + 40 * i, tmp);
      if (kParent[i] < 0) { for (int k = 0; k < 16; ++k) F.world[i * 16 + k] = tmp[k]; }
      else mul(F.world + i * 16, tmp, F.world + kParent[i] * 16);
    }
    *state = 1;
  }
  static int readable(const void*, size_t, int) { return 1; }
  static int64_t clock() { static int64_t c; return ++c; }
  static void log(const char* fmt, ...) {
    ++F.logs;
    if (getenv("ARMLOG")) { va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap); printf("\n"); }
  }
};
typedef armcore::Core<G> Core;

static void* aligned16(size_t n) { return aligned_alloc(16, (n + 15u) & ~(size_t)15u); }

static void build() {
  F.actor = (uint8_t*)aligned16(0x10000);
  memset(F.actor, 0, 0x10000);
  uint8_t* M = F.actor + layout::kOffActorModel;
  F.skel = (uint8_t*)aligned16(0x8c + N * 0x4c + 64);
  memset(F.skel, 0, 0x8c + N * 0x4c + 64);
  F.local = (uint8_t*)aligned16(N * 40);
  memset(F.local, 0, N * 40);
  F.world = (float*)aligned16(N * 64);
  memset(F.world, 0, N * 64);
  *(int*)(F.skel + 0x88) = N;
  for (int i = 0; i < N; ++i) {
    strncpy((char*)F.skel + 0x8c + i * 0x4c, kNames[i], 0x17);
    *(int*)(F.skel + 0x8c + i * 0x4c + 0x1c) = kParent[i];
  }
  *(uint8_t**)(M + layout::kOffModelSkeleton) = F.skel;
  *(uint8_t**)(M + layout::kOffModelLocal) = F.local;
  *(float**)(M + layout::kOffModelWorld) = F.world;
  *(int*)(M + layout::kOffModelBoneCount) = N;
  *(int*)(M + layout::kOffModelState) = -1;
  int* idx = (int*)(F.actor + layout::kOffActorBoneIdx);
  idx[0] = 12; idx[1] = 3; idx[2] = 5; idx[3] = 9; idx[4] = 7; idx[5] = 11;
  const double X[3] = {1, 0, 0};
  const double p0[3] = {0, 3.0, 0}, p1[3] = {0, 0.4, 0}, cR[3] = {0.15, 0.2, 0}, uR[3] = {0.35, 0, 0}, fa[3] = {0, -1.0, 0}, ha[3] = {0, -0.9, 0};
  const double cL[3] = {-0.15, 0.2, 0}, uL[3] = {-0.35, 0, 0}, hd[3] = {0, 0.5, 0};
  qset(F.local + 0 * 40, X, 0, 1, p0);
  qset(F.local + 1 * 40, X, 0, 1, p1); qset(F.local + 2 * 40, X, 0, 1, p1); qset(F.local + 3 * 40, X, 0, 1, p1);
  qset(F.local + 4 * 40, X, 0, 1, cR); qset(F.local + 5 * 40, X, 10, 1, uR); qset(F.local + 6 * 40, X, -70, 1, fa); qset(F.local + 7 * 40, X, 15, 1, ha);
  qset(F.local + 8 * 40, X, 0, 1, cL); qset(F.local + 9 * 40, X, 10, 1, uL); qset(F.local + 10 * 40, X, -70, 1, fa); qset(F.local + 11 * 40, X, 15, 1, ha);
  qset(F.local + 12 * 40, X, 0, 1, hd);
  // fingers: knuckles at x = +-0.03 (index) / -+0.03 (pinkie), segments 0.08 long; the index is bent 25 degrees at its joints in the animation, the pinkie is straight
  const double seg[3] = {0, -0.08, 0};
  const double iR[3] = {-0.03, -0.1, 0}, pR[3] = {0.03, -0.1, 0}, tR[3] = {0.07, -0.05, 0.02};
  const double iL[3] = {0.03, -0.1, 0}, pL[3] = {-0.03, -0.1, 0};
  qset(F.local + 13 * 40, X, 0, 1, iR);  qset(F.local + 14 * 40, X, 25, 1, seg); qset(F.local + 15 * 40, X, 25, 1, seg); qset(F.local + 16 * 40, X, 0, 1, seg);
  qset(F.local + 17 * 40, X, 0, 1, pR);  qset(F.local + 18 * 40, X, 0, 1, seg);  qset(F.local + 19 * 40, X, 0, 1, seg);  qset(F.local + 20 * 40, X, 0, 1, seg);
  qset(F.local + 21 * 40, X, 0, 1, tR);  qset(F.local + 22 * 40, X, 20, 1, seg); qset(F.local + 23 * 40, X, 20, 1, seg); qset(F.local + 24 * 40, X, 0, 1, seg);
  qset(F.local + 25 * 40, X, 0, 1, iL);  qset(F.local + 26 * 40, X, 25, 1, seg); qset(F.local + 27 * 40, X, 25, 1, seg); qset(F.local + 28 * 40, X, 0, 1, seg);
  qset(F.local + 29 * 40, X, 0, 1, pL);  qset(F.local + 30 * 40, X, 0, 1, seg);  qset(F.local + 31 * 40, X, 0, 1, seg);  qset(F.local + 32 * 40, X, 0, 1, seg);
  const double pke0[3] = {0.35, 0.9, 0.3}, pke1[3] = {0, 0.1, 0.05};   // near the right hand once the arm swings forward
  qset(F.local + 33 * 40, X, 12, 1, pke0); qset(F.local + 34 * 40, X, 5, 1, pke1);
}

static void wp(const arm::Space& sp, int bone, double* w) { sp.point_world(F.world + bone * 16 + 12, w); }
static double dist(const double* a, const double* b) { double d[3] = {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; return arm::len(d); }
// the signed bend of joint j (0..2) of a finger chain along `ax`, degrees
static double bend(const arm::Space& sp, int hand, const int* b, int j, const double* ax) {
  double P[5][3], g[4][3];
  wp(sp, hand, P[0]);
  for (int k = 0; k < 4; ++k) wp(sp, b[k], P[k + 1]);
  for (int i = 0; i < 4; ++i) arm::sub(P[i + 1], P[i], g[i]);
  double x[3];
  arm::cross(g[j], g[j + 1], x);
  return vm::datan2(arm::dot(x, ax), arm::dot(g[j], g[j + 1])) * 180.0 / vm::kPi;
}

int main() {
  build();
  uintptr_t actor = (uintptr_t)F.actor;
  float W2[16] = {0};
  {
    double ay[3] = {0, 1, 0}, R[9];
    weight::axis_angle(ay, 30.0 * vm::kPi / 180.0, R);
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) W2[r * 4 + c] = (float)(1.05 * R[c * 3 + r]);
    W2[12] = 5; W2[13] = 0; W2[14] = 2; W2[15] = 1;
  }
  arm::Space sp;
  CHECK(sp.set(W2));
  G::ensure(F.actor + layout::kOffActorModel);
  double H0[3], LH0[3];
  wp(sp, 7, H0); wp(sp, 11, LH0);
  const int RI[4] = {13, 14, 15, 16}, RP[4] = {17, 18, 19, 20}, LI[4] = {25, 26, 27, 28}, LP[4] = {29, 30, 31, 32};

  ArmTargets t;
  memset(&t, 0, sizeof(t));
  double R3[9]; weight::ident(R3);
  for (int i = 0; i < 9; ++i) t.wandR[i] = R3[i];
  for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
  t.grip[0] = H0[0] + 0.3; t.grip[1] = H0[1] + 0.2; t.grip[2] = H0[2] + 0.4;
  t.rightOn = 1; t.leftOn = 1;
  t.lpos[0] = LH0[0] - 0.2; t.lpos[1] = LH0[1] + 0.3; t.lpos[2] = LH0[2] + 0.5;
  double fw[3] = {0.2, 0.1, 0.97}; arm::unit(fw, t.lfwd);
  t.lup[0] = 0; t.lup[1] = 1; t.lup[2] = 0;
  t.wristBackFt = 0.2; t.wristDownFt = 0.05; t.elbowDown = 1.0;

  // ---- 1. nothing asked: the fingers stay as the animation has them
  {
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::c.fing[0][1][0] == 13 && Core::c.fing[0][4][3] == 20 && Core::c.fing[1][1][0] == 25 && Core::c.fing[0][2][0] == -1);   // middle / ring not in this fake
    CHECK(Core::c.bPke[0] == 33 && Core::c.bPke[1] == 34);
    CHECK(Core::st.fingerPasses[0] == 0);
  }
  // ---- 2. fully closed index (animation-bent: measured axis) and pinkie (straight: geometry axis), right hand
  double axR[3];
  {
    G::ensure(F.actor + layout::kOffActorModel);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;   // the engine rebuilds the pose
    G::ensure(F.actor + layout::kOffActorModel);
    t.fingersOn = 1;
    for (int h = 0; h < 2; ++h) for (int f = 0; f < 5; ++f) t.curl[h][f] = 1.0;
    t.curl[0][0] = -1; t.curl[1][0] = -1;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.fingerPasses[0] >= 1 && Core::st.fingerPasses[1] >= 1);
    CHECK(Core::st.fingerMeasured[0] >= 1 && Core::st.fingerGeometry[0] >= 1);   // index measured, pinkie from the geometry
    CHECK(Core::st.fingerNoAxis[0] == 0 && Core::st.fingerBad[0] == 0);
    CHECK(Core::st.fingerFlips[0] == 0 && Core::st.fingerFlips[1] == 0);        // measured and geometric axes agree in this model
    double pi3[3], pp3[3], across[3], fd[3], g1[3], pa[3], pb[3];
    wp(sp, 13, pi3); wp(sp, 17, pp3);
    arm::sub(pi3, pp3, across); arm::unit(across, across);
    wp(sp, 13, pa); wp(sp, 14, pb); arm::sub(pb, pa, g1); arm::unit(g1, fd);
    const double k = arm::dot(across, fd);
    for (int i = 0; i < 3; ++i) axR[i] = -(across[i] - k * fd[i]);   // right hand: from the index knuckle to the little finger
    arm::unit(axR, axR);
    // index: joints 2 and 3 at 0.48 and 0.06 of 190 degrees (1.7.99: an empty right hand has the softer finger shape the left hand got in 1.7.98)
    const double b2 = bend(sp, 7, RI, 1, axR), b3 = bend(sp, 7, RI, 2, axR);
    printf("right index bends now %.1f / %.1f (want 91.2 / 11.4)\n", b2, b3);
    CHECK(fabs_(b2 - 91.2) < 1.5 && fabs_(b3 - 11.4) < 1.5);
    const double p2 = bend(sp, 7, RP, 1, axR), p3 = bend(sp, 7, RP, 2, axR);
    printf("right pinkie bends now %.1f / %.1f (want 0.50*190=95.0 / 0.06*190=11.4)\n", p2, p3);
    CHECK(fabs_(p2 - 95.0) < 1.5 && fabs_(p3 - 11.4) < 1.5);
    // finger bones stayed rigid: segment lengths are the animation's (0.08 x body scale 1.05)
    double q0[3], q1[3], q2[3], q3[3];
    wp(sp, 14, q0); wp(sp, 15, q1); wp(sp, 16, q2); wp(sp, 13, q3);
    CHECK(fabs_(dist(q0, q1) - 0.084) < 2e-3 && fabs_(dist(q1, q2) - 0.084) < 2e-3 && fabs_(dist(q3, q0) - 0.084) < 2e-3);
    // the knuckles did not move with the curl
    double pi4[3]; wp(sp, 13, pi4);
    CHECK(dist(pi3, pi4) < 1e-6);
  }
  // ---- 3. open: curl 0 straightens the finger (bends ~ 0 at the joints) ; half: between
  {
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    for (int h = 0; h < 2; ++h) for (int f = 1; f < 5; ++f) t.curl[h][f] = 0.0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    const double b2 = bend(sp, 7, RI, 1, axR), b3 = bend(sp, 7, RI, 2, axR);
    printf("right index open: %.1f / %.1f\n", b2, b3);
    CHECK(fabs_(b2) < 1.5 && fabs_(b3) < 1.5);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    for (int f = 1; f < 5; ++f) t.curl[0][f] = 0.5;
    CHECK(Core::apply(actor, W2, &t) == 1);
    const double h2 = bend(sp, 7, RI, 1, axR);
    printf("right index half: %.1f (want 45.6)\n", h2);
    CHECK(fabs_(h2 - 45.6) < 1.5);
  }
  // ---- 3b. 1.7.103: the left hand keeps the game's own finger pose (leftFingerKeep 1) or blends toward it (0.5)
  {
    double res[3] = {0, 0, 0};
    const double keeps[3] = {0.0, 0.5, 1.0};
    double ax[3];
    for (int m = 0; m < 3; ++m) {
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      for (int f = 1; f < 5; ++f) { t.curl[0][f] = 0.0; t.curl[1][f] = 1.0; }
      t.leftFingerKeep = keeps[m];
      CHECK(Core::apply(actor, W2, &t) == 1);
      double pi3[3], pp3[3], across[3], fd[3], g1[3], pa[3], pb[3];
      wp(sp, 25, pi3); wp(sp, 29, pp3);
      arm::sub(pi3, pp3, across); arm::unit(across, across);
      wp(sp, 25, pa); wp(sp, 26, pb); arm::sub(pb, pa, g1); arm::unit(g1, fd);
      const double k = arm::dot(across, fd);
      for (int i = 0; i < 3; ++i) ax[i] = across[i] - k * fd[i];
      arm::unit(ax, ax);
      res[m] = bend(sp, 11, LI, 1, ax);
    }
    t.leftFingerKeep = 0.0;
    printf("left index knuckle: own curl %.1f, half kept %.1f, fully kept %.1f (the game's own pose in this fake is 25)\n", res[0], res[1], res[2]);
    CHECK(res[0] > 85.0);                                 // keep 0: the mod's curl
    CHECK(fabs_(res[2] - 25.0) < 2.0);                    // keep 1: exactly the animation's own bend
    CHECK(res[1] > res[2] + 20.0 && res[1] < res[0] - 20.0 && fabs_(res[1] - 0.5 * (res[0] + res[2])) < 4.0);   // half: half way between the animation's bend and the mod's
    CHECK(Core::st.leftFingerKept >= 1 && Core::st.leftFingerBlend >= 1);
  }
  // ---- 4. left hand: its fingers curl the same way (mirror image of the model)
  {
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    for (int f = 1; f < 5; ++f) { t.curl[0][f] = 0.0; t.curl[1][f] = 1.0; }
    CHECK(Core::apply(actor, W2, &t) == 1);
    double pi3[3], pp3[3], across[3], fd[3], g1[3], pa[3], pb[3], ax[3];
    wp(sp, 25, pi3); wp(sp, 29, pp3);
    arm::sub(pi3, pp3, across); arm::unit(across, across);
    wp(sp, 25, pa); wp(sp, 26, pb); arm::sub(pb, pa, g1); arm::unit(g1, fd);
    const double k = arm::dot(across, fd);
    for (int i = 0; i < 3; ++i) ax[i] = across[i] - k * fd[i];   // left hand: the other way round
    arm::unit(ax, ax);
    const double b2 = bend(sp, 11, LI, 1, ax), p2 = bend(sp, 11, LP, 1, ax);
    printf("left index %.1f pinkie %.1f (want 91.2 / 95.0: 0.48 x 190, 0.50 x 190)\n", b2, p2);   // 1.7.98: the left hand's knuckle and middle joint carry the bend, the tip only 6 %
    CHECK(fabs_(b2 - 91.2) < 1.5 && fabs_(p2 - 95.0) < 1.5);
    const double t2 = bend(sp, 11, LI, 2, ax), tp2 = bend(sp, 11, LP, 2, ax);   // 1.7.98 "left hand fingertips curl and look bad": the tip joint takes 6 % (11.4 deg), never more than 14
    printf("left fingertip joints: index %.1f pinkie %.1f (want 11.4 each, at most 14)\n", t2, tp2);
    CHECK(fabs_(t2 - 11.4) < 1.5 && fabs_(tp2 - 11.4) < 1.5 && t2 <= 14.5 && tp2 <= 14.5);
  }
  // ---- 5. a gun hand keeps the animation's grip: trigger pulls the index further, grip held leaves the others as they are
  {
    ArmTargets tg = t;
    tg.origOn = 1;                                  // the game's own body matrix: the hand is taken from the animation's pose, so the wand grip counts
    for (int i = 0; i < 16; ++i) tg.origBody[i] = W2[i];
    for (int i = 0; i < 3; ++i) tg.wandP0[i] = H0[i];
    tg.grip[0] = H0[0]; tg.grip[1] = H0[1]; tg.grip[2] = H0[2];
    tg.curl[0][2] = tg.curl[0][3] = tg.curl[0][4] = 1.0; tg.curl[0][1] = 0.0;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    CHECK(Core::apply(actor, W2, &tg) == 1);
    const double base2 = bend(sp, 7, RI, 1, axR), baseP = bend(sp, 7, RP, 1, axR);
    printf("gun hand: index %.1f (animation 25), pinkie %.1f (animation 0)\n", base2, baseP);
    CHECK(fabs_(base2 - 25.0) < 2.0);       // trigger not touched: the animation's bend
    CHECK(fabs_(baseP) < 2.0);              // grip held: the animation's grip
    tg.curl[0][1] = 1.0;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    CHECK(Core::apply(actor, W2, &tg) == 1);
    const double pull2 = bend(sp, 7, RI, 1, axR) + bend(sp, 7, RI, 2, axR);
    printf("gun hand trigger pulled: index joints total %.1f (was %.1f + 25)\n", pull2, base2);
    CHECK(pull2 > 50.0 + 25.0 * 0 && pull2 < 120.0);
  }
  // ---- 5b. 1.7: the weapon hand keeps the animation's grip even when the controller's grip button is not squeezed (the 1.6 pictures: fingers opened to 40 % = a flat hand
  //          with the PKE / gun floating in front of it)
  {
    const double X[3] = {1, 0, 0}, seg[3] = {0, -0.08, 0};
    qset(F.local + 18 * 40, X, 40, 1, seg); qset(F.local + 19 * 40, X, 40, 1, seg);   // the animation's pinkie is curled around the grip: 80 degrees at its two joints
    auto total_bend = [&](void) { return bend(sp, 7, RP, 0, axR) + bend(sp, 7, RP, 1, axR) + bend(sp, 7, RP, 2, axR); };
    double base = 0, open40 = 0, wrapped = 0, half = 0;
    for (int mode = 0; mode < 4; ++mode) {
      ArmTargets tg = t;
      tg.origOn = 1;
      for (int i = 0; i < 16; ++i) tg.origBody[i] = W2[i];
      for (int i = 0; i < 3; ++i) tg.wandP0[i] = H0[i];
      tg.grip[0] = H0[0]; tg.grip[1] = H0[1]; tg.grip[2] = H0[2];
      for (int f = 1; f < 5; ++f) tg.curl[0][f] = 0.0;           // the controller's grip button is NOT squeezed, the trigger is not pulled
      tg.gunWrap = mode == 0 ? 0.0 : mode == 1 ? 1.0 : mode == 2 ? 0.5 : 1.0;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      if (mode == 0) base = total_bend();                       // before anything is changed: what the animation has
      CHECK(Core::apply(actor, W2, &tg) == 1);
      const double now = total_bend();
      if (mode == 0) open40 = now; else if (mode == 1) wrapped = now; else if (mode == 2) half = now;
      if (mode == 3) {   // grip squeezed: always the animation's grip, whatever gunWrap says
        tg.curl[0][4] = 1.0; tg.gunWrap = 0.0;
        *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
        G::ensure(F.actor + layout::kOffActorModel);
        CHECK(Core::apply(actor, W2, &tg) == 1);
        const double sq = total_bend();
        printf("gun hand pinkie: animation %.1f, grip released + wrap 0 -> %.1f, wrap 100 -> %.1f, wrap 50 -> %.1f, grip squeezed -> %.1f\n", base, open40, wrapped, half, sq);
        CHECK(fabs_(sq - base) < 2.5);
      }
    }
    CHECK(base > 60.0);                                          // the animation's pinkie really is curled
    CHECK(open40 < 0.6 * base && open40 > 0.3 * base);           // the 1.6 behaviour (wrap 0): about 40 % of the grip (a little more: the knuckle cannot bend backwards), the hand opens
    CHECK(fabs_(wrapped - base) < 2.5);                          // 1.7 (wrap 100): the animation's grip, fingers around the handle
    CHECK(half > open40 + 5.0 && half < wrapped - 5.0);          // in between
    // put the animation's pinkie back for the tests below
    qset(F.local + 18 * 40, X, 0, 1, seg); qset(F.local + 19 * 40, X, 0, 1, seg);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
  }
  // ---- 5d. 1.7.104: with nothing in the right hand (gun holstered) the fingers follow the controller fully. Before, the hand was still treated as a gun hand: the animation's grip stayed and the
  //          grip button / trigger moved the fingers hardly at all ("when the right hand does not have a gun, fingers don't work").
  {
    double res[2][3] = {{0}};
    for (int empty = 0; empty < 2; ++empty) {
      ArmTargets tg = t;
      tg.origOn = 1;
      for (int i = 0; i < 16; ++i) tg.origBody[i] = W2[i];
      for (int i = 0; i < 3; ++i) tg.wandP0[i] = H0[i];
      tg.grip[0] = H0[0]; tg.grip[1] = H0[1]; tg.grip[2] = H0[2];
      tg.rightEmpty = empty;
      tg.gunWrap = 0.0;
      for (int f = 1; f < 5; ++f) tg.curl[0][f] = 1.0;            // grip squeezed
      tg.curl[0][1] = 1.0;                                        // trigger pulled
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      CHECK(Core::apply(actor, W2, &tg) == 1);
      res[empty][0] = bend(sp, 7, RP, 0, axR) + bend(sp, 7, RP, 1, axR) + bend(sp, 7, RP, 2, axR);   // pinkie, total
      res[empty][1] = bend(sp, 7, RI, 0, axR) + bend(sp, 7, RI, 1, axR) + bend(sp, 7, RI, 2, axR);   // index, total
      // open hand
      for (int f = 1; f < 5; ++f) tg.curl[0][f] = 0.0;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      CHECK(Core::apply(actor, W2, &tg) == 1);
      res[empty][2] = bend(sp, 7, RP, 0, axR) + bend(sp, 7, RP, 1, axR) + bend(sp, 7, RP, 2, axR);
    }
    printf("right hand, grip squeezed: gun-hand rules pinkie %.1f index %.1f | empty-hand rules pinkie %.1f index %.1f | open: gun-hand %.1f empty-hand %.1f\n", res[0][0], res[0][1], res[1][0], res[1][1], res[0][2], res[1][2]);
    CHECK(res[0][0] < 40.0);                                       // the old rule: the hand barely closes
    CHECK(res[1][0] > 100.0);                                      // the free-finger rule: a real fist
    CHECK(res[1][1] > 100.0);                                      // trigger pulled: the index closes too
    CHECK(res[1][0] - res[1][2] > 80.0);                           // and opens again when the grip is let go
  }
  // ---- 5e. 1.7.104: the PKE out (hand tied to the controller): with pke_align the meter's long side is turned into the controller's centre plane and its centre is brought over the controller.
  //          The relation to the controller is captured from whatever the hand happened to be; the numbers are made so that the long side leans 20 deg and the centre is 6 cm off to the side.
  {
    auto repose = [&]() { *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1; G::ensure(F.actor + layout::kOffActorModel); };
    double fwd[3] = {0.15, 0.05, 1.0}, up[3] = {0.0, 1.0, 0.0}, cr[3];
    arm::unit(fwd, fwd); { const double k = arm::dot(up, fwd); for (int i = 0; i < 3; ++i) up[i] -= k * fwd[i]; } arm::unit(up, up); arm::cross(fwd, up, cr);
    double lean[2] = {0, 0}, shift[2] = {0, 0}, latF = 0, leanAfterReported = 0, swingReported = 0;
    double handAt[2][3];
    for (int al = 0; al < 2; ++al) {
      ArmTargets a = t;
      a.fingersOn = 0; a.handFreeze = 1; a.rdirOk = 1; a.pkeAlign = al;
      for (int i = 0; i < 3; ++i) { a.rdir[i] = fwd[i]; a.rup[i] = up[i]; }
      Core::frz_reset();
      repose();
      CHECK(Core::apply(actor, W2, &a) == 1);
      CHECK(Core::frz.have == 1);
      const double* K = Core::frz.K;
      double s20, c20; vm::dsincos(20.0 * vm::kPi / 180.0, &s20, &c20);
      const double cdes[3] = {c20, 0.0, s20}, pdes[3] = {0.10, 0.05, 0.20};
      for (int i = 0; i < 3; ++i) { a.pkeVh[i] = K[0 * 3 + i] * cdes[0] + K[1 * 3 + i] * cdes[1] + K[2 * 3 + i] * cdes[2]; a.pkePh[i] = K[0 * 3 + i] * pdes[0] + K[1 * 3 + i] * pdes[1] + K[2 * 3 + i] * pdes[2]; }
      for (int pass = 0; pass < 3; ++pass) { repose(); CHECK(Core::apply(actor, W2, &a) == 1); }   // the sideways move of one pass is used by the next
      // the long side in the world, from the drawn hand
      double w[3][3], v[3] = {0, 0, 0};
      for (int r = 0; r < 3; ++r) { const double m[3] = {F.world[7 * 16 + r * 4], F.world[7 * 16 + r * 4 + 1], F.world[7 * 16 + r * 4 + 2]}; sp.dir_world(m, w[r]); arm::unit(w[r], w[r]); }
      for (int r = 0; r < 3; ++r) for (int i = 0; i < 3; ++i) v[i] += a.pkeVh[r] * w[r][i];
      arm::unit(v, v);
      lean[al] = vm::dasin(arm::dot(v, cr)) * 180.0 / vm::kPi;
      wp(sp, 7, handAt[al]);
      if (al) { latF = Core::frz.latFt; leanAfterReported = Core::frz.al.leanAfterDeg; swingReported = Core::frz.al.swingDeg; CHECK(Core::frz.al.ok == 1); CHECK(Core::frz.alignN >= 3 && Core::frz.alignFail == 0); }
    }
    { double d[3] = {handAt[1][0] - handAt[0][0], handAt[1][1] - handAt[0][1], handAt[1][2] - handAt[0][2]}; shift[0] = arm::dot(d, cr); shift[1] = arm::len(d); }
    printf("PKE align: long side leans %.1f deg off the controller's centre plane without it, %.1f deg with it (reported after: %.2f, hand turned %.1f deg); the hand moved %.1f cm sideways (wanted %.1f), %.1f cm in all\n",
           lean[0], lean[1], leanAfterReported, swingReported, shift[0] * 30.48, -latF * 30.48, shift[1] * 30.48);
    CHECK(fabs_(lean[0]) > 15.0 && fabs_(lean[0]) < 25.0);          // without it: the captured relation, leaning
    CHECK(fabs_(lean[1]) < 1.5);                                    // with it: straight along the controller
    CHECK(fabs_(leanAfterReported) < 0.5 && fabs_(swingReported - 20.0) < 1.0);
    CHECK(latF != 0.0 && fabs_(shift[0] + latF) < 0.5 * fabs_(latF) + 0.01);   // the hand moved against the centre's sideways offset
    CHECK(shift[1] < fabs_(shift[0]) + 0.02);                       // and only sideways
    Core::frz_reset();
    repose();
  }
  // ---- 5f. 1.7.225: the PKE alignment (turn + centring move) EASES IN after the grip locks instead of jumping on the first pass ("pulled around when it comes out")
  {
    auto repose = [&]() { *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1; G::ensure(F.actor + layout::kOffActorModel); };
    double fwd[3] = {0.15, 0.05, 1.0}, up[3] = {0.0, 1.0, 0.0};
    arm::unit(fwd, fwd); { const double k = arm::dot(up, fwd); for (int i = 0; i < 3; ++i) up[i] -= k * fwd[i]; } arm::unit(up, up);
    double pos[120][3];
    for (int ease = 0; ease < 2; ++ease) {
      ArmTargets a = t;
      a.fingersOn = 0; a.handFreeze = 1; a.rdirOk = 1; a.pkeAlign = 1; a.pkeEaseS = ease ? 0.45 : 0.0; a.calmDtS = 1.0 / 90.0;
      for (int i = 0; i < 3; ++i) { a.rdir[i] = fwd[i]; a.rup[i] = up[i]; }
      Core::frz_reset(); repose();
      a.calmSeq = (decltype(a.calmSeq))(1000 + ease * 100); CHECK(Core::apply(actor, W2, &a) == 1);
      const double* K = Core::frz.K;
      double s20, c20; vm::dsincos(20.0 * vm::kPi / 180.0, &s20, &c20);
      const double cdes[3] = {c20, 0.0, s20}, pdes[3] = {0.10, 0.05, 0.20};
      for (int i = 0; i < 3; ++i) { a.pkeVh[i] = K[0 * 3 + i] * cdes[0] + K[1 * 3 + i] * cdes[1] + K[2 * 3 + i] * cdes[2]; a.pkePh[i] = K[0 * 3 + i] * pdes[0] + K[1 * 3 + i] * pdes[1] + K[2 * 3 + i] * pdes[2]; }
      for (int pass = 0; pass < 110; ++pass) {   // two passes per frame (two eyes) for the first 55 frames
        a.calmSeq = (decltype(a.calmSeq))(1001 + ease * 100 + pass / 2);
        repose(); CHECK(Core::apply(actor, W2, &a) == 1);
        wp(sp, 7, pos[pass]);
      }
      double d[6]; const int at[6] = {2, 4, 10, 20, 40, 100};
      for (int k = 0; k < 6; ++k) { const double* p = pos[at[k]]; const double* q = pos[109]; d[k] = 30.48 * vm::dsqrt((p[0]-q[0])*(p[0]-q[0]) + (p[1]-q[1])*(p[1]-q[1]) + (p[2]-q[2])*(p[2]-q[2])); }
      printf("PKE ease-in (%s): the hand is %.2f / %.2f / %.2f / %.2f / %.2f / %.2f cm from where it settles after pass 2 / 4 / 10 / 20 / 40 / 100\n", ease ? "0.45 s" : "off", d[0], d[1], d[2], d[3], d[4], d[5]);
      if (!ease) CHECK(d[0] < 0.05);                         // old way: already in the final place on the first passes (the jump)
      else {
        CHECK(d[0] > 1.0);                                   // eased: starts well away from the settled place ...
        CHECK(d[1] <= d[0] + 0.02 && d[2] <= d[1] + 0.02 && d[3] <= d[2] + 0.02 && d[4] <= d[3] + 0.02);   // ... and only gets closer
        CHECK(d[5] < 0.05);                                  // and has settled by 0.45 s
        double step = 0.0; for (int k = 3; k < 110; ++k) { const double* p = pos[k]; const double* q = pos[k - 1]; const double v = 30.48 * vm::dsqrt((p[0]-q[0])*(p[0]-q[0]) + (p[1]-q[1])*(p[1]-q[1]) + (p[2]-q[2])*(p[2]-q[2])); if (v > step) step = v; }
        printf("PKE ease-in: largest step between passes %.2f cm\n", step);
        CHECK(step < 0.25);                                  // no jump: at most 2.5 mm per pass (the old way: 47 mm at once)
      }
    }
    Core::frz_reset(); repose();
  }
  // ---- 5c. 1.7.1: the left hand on the gun's foregrip keeps its fingers wrapped even when the controller's grip button is not squeezed (1.7 opened them to 0 = a flat hand "floating" on the foregrip)
  {
    auto left_axis = [&](double* ax) {
      double pi3[3], pp3[3], across[3], fd[3], g1[3], pa[3], pb[3];
      wp(sp, 25, pi3); wp(sp, 29, pp3);
      arm::sub(pi3, pp3, across); arm::unit(across, across);
      wp(sp, 25, pa); wp(sp, 26, pb); arm::sub(pb, pa, g1); arm::unit(g1, fd);
      const double k = arm::dot(across, fd);
      for (int i = 0; i < 3; ++i) ax[i] = across[i] - k * fd[i];
      arm::unit(ax, ax);
    };
    double res[5] = {0, 0, 0, 0, 0};
    for (int mode = 0; mode < 5; ++mode) {   // 0 on the foregrip wrap 100, 1 wrap 0 (setting off), 2 magnet off, 3 far from the foregrip, 4 on the foregrip with the grip squeezed
      ArmTargets tl = t;
      tl.fingersOn = 1;
      tl.rdirOk = 1; tl.rdir[0] = 0; tl.rdir[1] = 0; tl.rdir[2] = 1; tl.rup[0] = 0; tl.rup[1] = 1; tl.rup[2] = 0;
      tl.gunLenFt = 2.0;
      tl.gripMagnet = mode == 2 ? 0.0 : 1.0;
      tl.gunWrap = mode == 1 ? 0.0 : 1.0;
      for (int f = 1; f < 5; ++f) { tl.curl[1][f] = mode == 4 ? 1.0 : 0.0; tl.curl[0][f] = 0.0; }
      const double fore = 0.55 * tl.gunLenFt;
      for (int i = 0; i < 3; ++i) tl.lpos[i] = tl.grip[i] + tl.rdir[i] * fore - tl.rup[i] * 0.10 + (mode == 3 ? 3.0 * (i == 0) : 0.0);
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      G::ensure(F.actor + layout::kOffActorModel);
      CHECK(Core::apply(actor, W2, &tl) == 1);
      double ax[3]; left_axis(ax);
      res[mode] = bend(sp, 11, LI, 1, ax) + bend(sp, 11, LP, 1, ax);   // the knuckle-side joint of the index and the pinkie, summed
      printf("left hand mode %d: index+pinkie first joints %.1f deg, magnet weight now %.0f%%, wrapped passes %d\n", mode, res[mode], Core::st.lMagWNow * 100.0, Core::st.lWrapPasses);
    }
    CHECK(res[0] > 140.0 && res[0] < 170.0);            // 0.48 x 0.85 x 190 + 0.50 x 0.85 x 190 = 158: wrapped on the foregrip (1.7.98 shares)
    CHECK(fabs_(res[1]) < 3.0);                          // setting at 0: like 1.7, the hand opens
    CHECK(fabs_(res[2]) < 3.0);                          // no pull to the foregrip: the fingers follow the controller only
    CHECK(fabs_(res[3]) < 3.0);                          // the hand is far from the foregrip: open
    CHECK(res[4] > 140.0);                               // grip squeezed: closed fully, as before
    CHECK(Core::st.lWrapPasses >= 1);
  }
  // ---- 6. the PKE bones follow the hand
  {
    ArmTargets tp = t;
    tp.fingersOn = 0;
    tp.pkeAttach = 1;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    float inv[16];
    CHECK(Core::inv34(F.world + 7 * 16, inv));
    alignas(16) float off0[16] = {0}, off1[16] = {0};
    G::mul(off0, F.world + 33 * 16, inv); G::mul(off1, F.world + 34 * 16, inv);
    CHECK(Core::apply(actor, W2, &tp) == 1);
    CHECK(Core::st.pkeApplied[0] == 1 && Core::st.pkeApplied[1] == 0 && Core::st.pkeHand == 0);
    alignas(16) float want0[16] = {0}, want1[16] = {0};
    G::mul(want0, off0, F.world + 7 * 16); G::mul(want1, off1, F.world + 7 * 16);
    double e0 = 0, e1 = 0;
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 3; ++c) { e0 += fabs_(want0[r * 4 + c] - F.world[33 * 16 + r * 4 + c]); e1 += fabs_(want1[r * 4 + c] - F.world[34 * 16 + r * 4 + c]); }
    printf("PKE offset error %.6f / %.6f\n", e0, e1);
    CHECK(e0 < 1e-4 && e1 < 1e-4);
    double ph[3], pp[3];
    wp(sp, 7, ph); wp(sp, 33, pp);
    CHECK(dist(ph, pp) < 3.0);
    // armsOnly: the PKE bones are kept, other body bones are squashed
    tp.armsOnly = 1;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    CHECK(Core::apply(actor, W2, &tp) == 1);
    CHECK(Core::col.have && !Core::col.was[33] && !Core::col.was[34] && Core::col.was[0] && Core::col.was[12]);
    CHECK(Core::st.pkeKept >= 1);
    // not asked for: the PKE bones go with the rest of the body
    ArmTargets tq = t;
    tq.fingersOn = 0; tq.armsOnly = 1;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    CHECK(Core::apply(actor, W2, &tq) == 1);
    CHECK(Core::col.was[33] && Core::col.was[34]);
  }
  // ---- 7. the PKE as the wand-slot model: its place relative to the hand is kept when the hand moves
  {
    ArmTargets tw = t;
    tw.fingersOn = 0; tw.pkeAttach = 0; tw.pkeWand = 1;
    tw.origOn = 1;
    for (int i = 0; i < 16; ++i) tw.origBody[i] = W2[i];
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    G::ensure(F.actor + layout::kOffActorModel);
    double h0[3]; wp(sp, 7, h0);
    // a wand matrix: turned 25 degrees about y, 1.5x scale, placed a little off the hand
    double ay[3] = {0, 1, 0}, Rw[9];
    weight::axis_angle(ay, 25.0 * vm::kPi / 180.0, Rw);
    for (int i = 0; i < 16; ++i) tw.wandM[i] = 0;
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) tw.wandM[r * 4 + c] = (float)(1.5 * Rw[c * 3 + r]);
    tw.wandM[12] = (float)(h0[0] + 0.1); tw.wandM[13] = (float)(h0[1] - 0.2); tw.wandM[14] = (float)(h0[2] + 0.15); tw.wandM[15] = 1;
    double M0[9], MT0[9];
    Core::frame_world(sp, F.world + 7 * 16, M0);
    weight::transpose3(M0, MT0);
    double d0[3] = {tw.wandM[12] - h0[0], tw.wandM[13] - h0[1], tw.wandM[14] - h0[2]}, l0[3];
    arm::apply3(MT0, d0, l0);
    CHECK(Core::apply(actor, W2, &tw) == 1);
    CHECK(Core::st.pwOut[0] == 1 && Core::st.pwOut[1] == 0);
    float out[16]; int64_t ck;
    CHECK(Core::pke_wand_read(out, &ck));
    double h1[3], M1[9], l1[3], d1[3];
    wp(sp, 7, h1);
    Core::frame_world(sp, F.world + 7 * 16, M1);
    d1[0] = out[12] - h1[0]; d1[1] = out[13] - h1[1]; d1[2] = out[14] - h1[2];
    double MT1[9]; weight::transpose3(M1, MT1); arm::apply3(MT1, d1, l1);
    printf("PKE wand offset in the hand's axes: before %.3f,%.3f,%.3f after %.3f,%.3f,%.3f (hand moved %.2f ft)\n", l0[0], l0[1], l0[2], l1[0], l1[1], l1[2], dist(h0, h1));
    CHECK(dist(l0, l1) < 2e-3 && dist(h0, h1) > 0.2);
    double sc = 0; for (int k = 0; k < 3; ++k) sc += out[k] * out[k];
    CHECK(fabs_(vm::dsqrt(sc) - 1.5) < 1e-3);   // size kept
  }
  if (!fails) printf("PASS fingers and PKE (logs=%d)\n", F.logs);
  return fails ? 1 : 0;
}
