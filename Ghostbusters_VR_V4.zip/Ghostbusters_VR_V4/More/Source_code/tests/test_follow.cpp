// Tests for src/followmath.h (1.5 head-follow turning, snap turn, stick flick).
// A small fake game turns its camera when the right stick is pushed (any direction, with an easing lag and a dead zone) so the whole loop is exercised:
// the picture must never turn because of the follow, the body must end up where the head looks, and a game that does not answer must be given up on.
#include <stdio.h>
#include <math.h>
#include "followmath.h"
using namespace follow;
static Cfg make_cfg0(int e, double d, int w = 0) { Cfg c = make_cfg(e, d, w); c.dwellSec = 0.0; return c; }   // the older tests run without the 1.7.25 wait
static int fails = 0;
static int near_deg(double a, double b, double e = 0.05) { return fabs(a - b) <= e; }
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

struct Sim {
  double cam = 0.3, v = 0.0, signTrue = 1.0, head = 0.0, A = 0.0, omega = 3.0, tau = 0.12, dead = 0.25, camPrev = 0.3;
  double u = 0.0, t = 0.0, dt = 0.011;
  int respond = 1, step_i = 0, allowed = 1, userBusy = 0; double moving = 0.0, firstPush = 0.0;
  double maxViewErr = 0.0, view0 = 0.0, cutAt = -1.0, cutBy = 0.0;
  int uSignChanges = 0; double lastUSign = 0.0; double pushedSeconds = 0.0;
  State s = {}; Cfg c;
  Sim(int enabled, double startDeg) { c = make_cfg0(enabled, startDeg); view0 = cam; }
  double e() const { return head - A; }
  double view() const { return cam + e(); }
  void frame() {
    t += dt; ++step_i;
    // the game: eases toward the angular speed the stick asks for (only every 2nd frame does the camera really change, like a 45 Hz game under a 90 Hz headset)
    const double a = u < 0 ? -u : u;
    const double target = (respond && a >= dead) ? signTrue * u * omega : 0.0;
    v += (target - v) * dt / tau;
    if ((step_i & 1) == 0) { cam += v * dt * 2.0; }
    if (cutAt >= 0 && t >= cutAt) { cam += cutBy; cutAt = -1; }
    // the probe: measure the camera, keep the picture steady, decide the next push
    const double dA = on_camera_delta(s, cam - camPrev, dt, c);
    camPrev = cam;
    A += dA;
    const double out = step(s, e(), dt, c, allowed, userBusy, moving);
    if (out != 0.0 && firstPush == 0.0) firstPush = out < 0 ? -out : out;
    u = out;
    if (out != 0.0) pushedSeconds += dt;
    const double sg = out > 0 ? 1.0 : out < 0 ? -1.0 : 0.0;
    if (sg != 0.0 && lastUSign != 0.0 && sg != lastUSign) ++uSignChanges;
    if (sg != 0.0) lastUSign = sg;
  }
  // where the picture should be: the start view plus what the head really did (and snap steps), nothing from the game's own turning
  double expectView(double snapped) const { return view0 + head + snapped; }
};

static double run(Sim& m, double seconds, double snapped) {
  double worst = 0.0;
  const int n = (int)(seconds / m.dt);
  for (int i = 0; i < n; ++i) {
    m.frame();
    double d = wrap(m.view() - m.expectView(snapped));
    if (d < 0) d = -d;
    if (d > worst) worst = d;
  }
  return worst;
}

int main() {
  // 1. head turns 90 degrees right: the body follows, the picture never turns by itself
  {
    Sim m(1, 35);
    run(m, 0.5, 0);
    m.head = rad(90);
    const double w = run(m, 5.0, 0);
    CHECK(w < rad(0.2));
    CHECK((m.e() < 0 ? -m.e() : m.e()) < m.c.stopRad + rad(0.5));
    CHECK(m.s.sign == 1);
    CHECK(m.uSignChanges == 0);                             // no wobbling left and right
    CHECK(m.pushedSeconds > 0.3 && m.pushedSeconds < 3.5);
    CHECK(deg(m.cam - 0.3) > 75 && deg(m.cam - 0.3) < 100); // the body really turned about as far as the head
  }
  // 2. a game that turns the other way round for a positive stick: it is found out, the picture still never turns
  {
    Sim m(1, 35);
    m.signTrue = -1.0;
    run(m, 0.5, 0);
    m.head = rad(-120);
    const double w = run(m, 6.0, 0);
    CHECK(w < rad(0.2));
    CHECK(m.s.sign == -1 && m.s.flips >= 1);
    CHECK((m.e() < 0 ? -m.e() : m.e()) < m.c.stopRad + rad(0.5));
  }
  // 3. a glance inside the start angle does nothing
  {
    Sim m(1, 35);
    m.head = rad(30);
    run(m, 3.0, 0);
    CHECK(m.pushedSeconds == 0.0 && m.s.runs == 0);
    CHECK(m.cam == 0.3);
  }
  // 4. follow off: nothing moves
  {
    Sim m(0, 35);
    m.head = rad(100);
    run(m, 3.0, 0);
    CHECK(m.pushedSeconds == 0.0);
  }
  // 5. you push the stick yourself: the probe stays out of it, and what the game turns for you is not taken away from the picture
  {
    Sim m(1, 35);
    m.head = rad(90);
    m.userBusy = 1;
    run(m, 1.0, 0);
    CHECK(m.pushedSeconds == 0.0);
    CHECK(m.A == 0.0);
    m.cam += rad(40);                                       // your own stick turn: the picture turns with it, as it should
    m.userBusy = 0;
    run(m, 0.02, 0);
    CHECK(m.A == 0.0 && m.s.cuts == 0);                       // not counted as ours
  }
  // 6. a snap turn right by 30 degrees: the picture jumps 30 degrees at once, then the body catches up without moving the picture again
  {
    Sim m(1, 90);                                           // follow wants 90 degrees: only the snap can start it
    run(m, 0.3, 0);
    const double before = m.view();
    m.A += snap(m.s, 30.0);
    CHECK(near_deg(deg(wrap(m.view() - before)), 30.0));
    const double w = run(m, 4.0, rad(30));
    CHECK(w < rad(0.2));
    CHECK((m.e() < 0 ? -m.e() : m.e()) < m.c.stopRad + rad(0.5));
    CHECK(deg(m.cam - 0.3) > 23 && deg(m.cam - 0.3) < 37);
    CHECK(m.s.forced == 0 && m.s.active == 0);
  }
  // 7. snap left, and several in a row (the same direction twice = 60 degrees)
  {
    Sim m(0, 90);                                           // follow off: the snap alone works
    m.A += snap(m.s, -30.0);
    run(m, 2.0, rad(-30));
    m.A += snap(m.s, -30.0);
    const double w = run(m, 3.0, rad(-60));
    CHECK(w < rad(0.2));
    CHECK(deg(m.cam - 0.3) < -50 && deg(m.cam - 0.3) > -70);
  }
  // 8. the game does not answer at all (menu, pause, cut-scene): given up after about a second and a half, then quiet for a few seconds
  {
    Sim m(1, 35);
    m.respond = 0;
    m.head = rad(100);
    run(m, 3.0, 0);
    CHECK(m.s.noAnswer >= 1);
    CHECK(m.pushedSeconds < 2.0);                           // not 3 s of nonstop pushing
    CHECK(m.A == 0.0);
  }
  // 9. a camera cut (respawn, cut-scene) while following is not taken as our turn
  {
    Sim m(1, 35);
    m.head = rad(80);
    m.cutAt = 0.5; m.cutBy = rad(150);
    run(m, 1.0, 0);
    CHECK(m.s.cuts >= 1);
  }
  // 10. not allowed (menu / wheel / cut-scene): no push, and a pending snap is dropped
  {
    Sim m(1, 35);
    m.allowed = 0;
    m.head = rad(90);
    m.A += snap(m.s, 30.0);
    run(m, 1.0, rad(30));
    CHECK(m.pushedSeconds == 0.0 && m.s.forced == 0);
  }
  // 11. the push never falls below what the game's dead zone lets through, and never above the maximum
  {
    Sim m(1, 35);
    m.head = rad(170);
    double lo = 9, hi = 0;
    for (int i = 0; i < 400; ++i) { m.frame(); const double a = m.u < 0 ? -m.u : m.u; if (a > 0) { if (a < lo) lo = a; if (a > hi) hi = a; } }
    CHECK(lo >= 0.37 && hi <= 1.0001);
  }
  // 14. Walking: body follows a 20-degree head turn, while the standing glance still does not turn it.
  {
    Cfg walking = make_cfg(1, 75, 1);
    CHECK(near_deg(deg(walking.walkStartRad), 10.0) && near_deg(deg(walking.walkStopRad), 5.0));
    State subtle = {};
    CHECK(step(subtle, rad(20), 0.011, walking, 1, 0, 1.0) != 0.0); // the reported 20-degree drift starts a turn when walking
    State standing = {};
    for (int i = 0; i < 100; ++i) CHECK(step(standing, rad(20), 0.011, walking, 1, 0, 0.0) == 0.0);
    Sim a(1, 35); a.c = make_cfg0(1, 35, 1); run(a, 0.5, 0); a.head = rad(25); run(a, 3.0, 0);
    CHECK(a.s.runs == 0);                                   // standing still: no turn
    Sim b(1, 35); b.c = make_cfg0(1, 35, 1); b.moving = 1.0; run(b, 0.5, 0); b.head = rad(25);
    const double w = run(b, 4.0, 0);
    CHECK(w < rad(0.2));                                    // the picture still never turns by itself
    CHECK(b.s.runs >= 1 && b.s.walkRuns >= 1);
    CHECK((b.e() < 0 ? -b.e() : b.e()) < rad(8.0));   // the game's camera keeps easing a little after the push stops
    CHECK(b.uSignChanges == 0);                             // no hunting left and right
    Sim d(1, 35); d.c = make_cfg0(1, 35, 0); d.moving = 1.0; run(d, 0.5, 0); d.head = rad(25); run(d, 3.0, 0);
    CHECK(d.s.runs == 0);                                   // boost off: walking changes nothing
    Sim h(1, 35); h.c = make_cfg0(1, 35, 1); h.moving = 0.1; run(h, 0.5, 0); h.head = rad(25); run(h, 3.0, 0);
    CHECK(h.s.runs == 0);                                   // a tiny stick push does not count as walking
  }
  // 15. 1.7.5 ramp: a big turn starts at the weakest working push (no jerk), grows within about a quarter second, and eases out (never more than downRate per second)
  {
    Sim m(1, 35); run(m, 0.5, 0); m.head = rad(120);
    m.frame();
    CHECK(m.firstPush > 0.57 && m.firstPush < 0.66);
    double prev = m.u < 0 ? -m.u : m.u, maxUp = 0.0, maxDown = 0.0, peak = 0.0;
    for (int i = 0; i < 900; ++i) {
      m.frame();
      const double a = m.u < 0 ? -m.u : m.u;
      if (m.s.active && prev > 0.0) { const double d = (a - prev) / m.dt; if (d > maxUp) maxUp = d; if (-d > maxDown) maxDown = -d; }
      if (a > peak) peak = a; prev = a;
    }
    CHECK(maxUp <= m.c.upRate + 0.3);
    CHECK(maxDown <= m.c.downRate + 0.3);
    CHECK(peak > 0.9);
    CHECK(m.uSignChanges == 0);
  }
  // 16. 1.7.6: a game whose look dead zone swallows pushes under 0.7 (the 1.7.5 report: 47 snap turns, 0 degrees of real turning) is still learned and followed
  {
    Sim m(1, 35); m.dead = 0.7; run(m, 0.5, 0); m.head = rad(90);
    const double w = run(m, 8.0, 0);
    CHECK(w < rad(0.2));
    CHECK(m.s.sign == 1 && m.s.noAnswer == 0);
    CHECK((m.e() < 0 ? -m.e() : m.e()) < m.c.stopRad + rad(3.0));
    CHECK(!gave_up(m.s));
  }
  // 17. 1.7.6: even a dead zone of 0.9 is found within the first run: nothing moves for 0.4 s, so the pushes go to full strength
  {
    Sim m(1, 35); m.dead = 0.9; run(m, 0.5, 0); m.head = rad(90);
    run(m, 8.0, 0);
    CHECK(m.s.sign == 1);
    CHECK(m.s.boosts >= 1);
    CHECK((m.e() < 0 ? -m.e() : m.e()) < m.c.stopRad + rad(3.0));
  }
  // 18. 1.7.6: a game that never turns: misses are counted, the probe gives up after two in a row and the offset bookkeeping can be reset by the caller
  {
    Sim m(1, 35); m.respond = 0; run(m, 0.5, 0); m.head = rad(90);
    run(m, 20.0, 0);
    CHECK(m.s.noAnswer >= 2);
    CHECK(gave_up(m.s));
    CHECK(m.s.boosts >= 1);
    note_answer(m.s);
    CHECK(!gave_up(m.s));
  }
  // 12. flick detector: one step per flick, comes back to the middle first
  {
    Flick f = {};
    CHECK(flick(f, 0.0, 0.0) == 0);
    CHECK(flick(f, 0.5, 0.0) == 0);
    CHECK(flick(f, 0.95, 0.1) == 1);
    CHECK(flick(f, 0.95, 0.1) == 0 && flick(f, 1.0, 0.0) == 0);   // held: no second step
    CHECK(flick(f, 0.1, 0.0) == 0);
    CHECK(flick(f, -0.9, 0.2) == -1);
    CHECK(flick(f, 0.0, 0.0) == 0 && flick(f, 0.1, 0.9) == 0);     // pushing up / down is not a turn
    CHECK(flick(f, 0.0, 0.0) == 0 && flick(f, 0.8, 0.7) == 0);     // a diagonal is not a turn either
    CHECK(f.fired == 2);
  }
  // 13. wrap
  CHECK(near_deg(deg(wrap(rad(190))), -170.0) && near_deg(deg(wrap(rad(-190))), 170.0) && near_deg(deg(wrap(rad(10))), 10.0));
  // 1.7.25: a quick glance past the start angle does not move the body; a look held longer does
  {
    Cfg c = make_cfg(1, 75); State st = {};
    double push = 0; for (int i = 0; i < 40; ++i) push += step(st, rad(100), 0.011, c, 1, 0, 0.0);   // 0.44 s
    CHECK(push == 0.0 && st.dwellHolds > 0);
    for (int i = 0; i < 40; ++i) push += step(st, rad(100), 0.011, c, 1, 0, 0.0);   // 0.88 s in all
    CHECK(push != 0.0);
    State s2 = {}; for (int i = 0; i < 30; ++i) step(s2, rad(100), 0.011, c, 1, 0, 0.0);
    for (int i = 0; i < 30; ++i) step(s2, rad(10), 0.011, c, 1, 0, 0.0);   // back inside: the wait starts over
    CHECK(s2.dwell == 0.0 && s2.active == 0);
  }
  // 1.7.81 smooth turn (the mod turns you itself while the right stick is held sideways: works where the game ignores its own stick)
  {
    CHECK(smooth_deg(0.10, 0.0, 120, 0.011) == 0.0);                          // inside the dead zone
    CHECK(smooth_deg(0.20, 0.0, 120, 0.011) == 0.0);                          // exactly at its edge
    CHECK(near_deg(smooth_deg(1.0, 0.0, 120, 0.010), 1.2, 1e-9));             // full stick right: speed x time
    CHECK(near_deg(smooth_deg(-1.0, 0.0, 120, 0.010), -1.2, 1e-9));          // left is the other way
    CHECK(near_deg(smooth_deg(0.60, 0.0, 120, 0.010), 0.6, 1e-9));            // half way between the dead zone and full = half speed
    CHECK(smooth_deg(0.50, 0.90, 120, 0.011) == 0.0);                         // pushing up / down is not a turn
    CHECK(smooth_deg(0.90, 0.70, 120, 0.011) == 0.0);                         // a diagonal is not a turn
    CHECK(smooth_deg(0.90, 0.30, 120, 0.011) > 0.0);                          // mostly sideways is
    CHECK(near_deg(smooth_deg(1.0, 0.0, 120, 0.500), 6.0, 1e-9));             // a long hitch counts as 50 ms at most (no swing)
    CHECK(smooth_deg(1.0, 0.0, 120, 0.0) == 0.0 && smooth_deg(1.0, 0.0, 120, -0.01) == 0.0);
    CHECK(near_deg(smooth_deg(1.0, 0.0, 1000, 0.010), 3.6, 1e-9));            // speed is limited to 360 deg/s
    CHECK(near_deg(smooth_deg(1.0, 0.0, 1, 0.010), 0.3, 1e-9));               // ... and to at least 30 deg/s
    CHECK(smooth_deg(NAN, 0.0, 120, 0.011) == 0.0);                           // a bad stick value turns nothing
    double sum = 0; for (int i = 0; i < 91; ++i) sum += smooth_deg(1.0, 0.0, 120, 0.011);   // one second at 91 Hz
    CHECK(near_deg(sum, 120.0, 0.5));
    State st = {}; const double a = smooth(st, 2.0);
    CHECK(near_deg(deg(a), -2.0, 1e-9) && st.forced == 1 && st.snaps == 0 && st.smooths == 1);   // same direction as a snap (+ = right), counted on its own
  }
  printf(fails ? "%d FAILED\n" : "test_follow: all passed\n", fails);
  return fails ? 1 : 0;
}
