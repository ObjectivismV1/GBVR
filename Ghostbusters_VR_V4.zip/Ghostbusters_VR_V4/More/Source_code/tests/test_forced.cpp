// 0.69 the forced-move detector (forcedmath.h)
#include <stdio.h>
#include "forcedmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  forced::Detector d; d.reset();
  double pos[3] = {0, 0, 0};
  const double dt = 1.0 / 90.0;
  // standing still, stick idle: never forced
  for (int i = 0; i < 300; ++i) d.update(pos, 0.0, dt);
  CHECK(!d.forced && d.fade == 1.0 && d.events == 0);
  // the player walks with the stick: never forced
  for (int i = 0; i < 300; ++i) { pos[2] += 6.0 * dt; d.update(pos, 0.9, dt); }
  CHECK(!d.forced && d.fade == 1.0 && d.events == 0 && d.speed > 5.5);
  // the player lets go: the actor slows down over 0.3 s (stick idle meanwhile): not forced
  { double v = 6.0; for (int i = 0; i < 27; ++i) { v *= 0.88; pos[2] += v * dt; d.update(pos, 0.0, dt); } }
  for (int i = 0; i < 90; ++i) d.update(pos, 0.0, dt);
  CHECK(!d.forced && d.events == 0 && d.fade == 1.0);
  // the game walks the character (cutscene): stick idle, 4 ft/s -> forced after 0.1 s, fade down to 0 within 0.12 s more
  int started = -1;
  double fadeAt[4] = {1, 1, 1, 1};
  for (int i = 0; i < 270; ++i) {
    pos[0] += 4.0 * dt; d.update(pos, 0.0, dt);
    if (d.forced && started < 0) started = i;
    if (i == 20) fadeAt[0] = d.fade;
    if (i == 60) fadeAt[1] = d.fade;
    if (i == 90) fadeAt[2] = d.fade;
    if (i == 269) fadeAt[3] = d.fade;
  }
  printf("forced started at frame %d (%.2f s); fade at 20/60/90/269 = %.2f %.2f %.2f %.2f\n", started, started * dt, fadeAt[0], fadeAt[1], fadeAt[2], fadeAt[3]);
  CHECK(started > 0 && started * dt >= 0.05 && started * dt <= 0.2);
  CHECK(fadeAt[0] < 0.1 && fadeAt[3] == 0.0 && d.forced && d.events == 1 && d.maxSpeed > 3.9);
  // it stops: not forced after 0.25 s still; the fade comes back slowly (hold 0.5 s, then 0.9 s ramp)
  int ended = -1;
  double back[3] = {0, 0, 0};
  for (int i = 0; i < 270; ++i) {
    d.update(pos, 0.0, dt);
    if (!d.forced && ended < 0) ended = i;
    if (i == 60) back[0] = d.fade;
    if (i == 100) back[1] = d.fade;
    if (i == 200) back[2] = d.fade;
  }
  printf("forced ended at frame %d (%.2f s); fade at 60/100/200 = %.2f %.2f %.2f, final %.2f\n", ended, ended * dt, back[0], back[1], back[2], d.fade);
  CHECK(ended >= 15 && ended <= 30 && back[0] < 0.2 && back[1] > 0.2 && back[1] < 0.9 && back[2] == 1.0 && d.fade == 1.0);
  // a jump (cut / level load): forced at once and held a second
  pos[0] += 40.0; d.update(pos, 0.0, dt);
  CHECK(d.forced && d.teleports == 1 && d.events == 2);
  for (int i = 0; i < 10; ++i) d.update(pos, 0.0, dt);
  CHECK(d.fade < 0.4);
  for (int i = 0; i < 400; ++i) d.update(pos, 0.0, dt);
  CHECK(!d.forced && d.fade == 1.0);
  // the player takes over while the actor moves: not forced any more at once
  d.reset();
  for (int i = 0; i < 90; ++i) { pos[2] += 4.0 * dt; d.update(pos, 0.0, dt); }
  CHECK(d.forced);
  for (int i = 0; i < 5; ++i) { pos[2] += 4.0 * dt; d.update(pos, 0.8, dt); }
  CHECK(!d.forced);
  // the second eye of a pair (tiny dt) changes nothing; a bad dt neither
  d.reset();
  for (int i = 0; i < 5; ++i) d.update(pos, 0.0, dt);
  double f0 = d.fade, s0 = d.idleSec;
  d.update(pos, 0.0, 0.0005); d.update(pos, 0.0, -1.0);
  CHECK(d.fade == f0 && d.idleSec == s0);
  // unknown stick (1.0): never forced even with a move
  d.reset();
  for (int i = 0; i < 300; ++i) { pos[2] += 4.0 * dt; d.update(pos, 1.0, dt); }
  CHECK(!d.forced && d.events == 0);
  // a slow drift (a moving platform, 0.8 ft/s) is not a forced move
  d.reset();
  for (int i = 0; i < 600; ++i) { pos[2] += 0.8 * dt; d.update(pos, 0.0, dt); }
  CHECK(!d.forced && d.events == 0);
  if (!fails) printf("PASS forced\n");
  return fails ? 1 : 0;
}
