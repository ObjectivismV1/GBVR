// 1.7.105 fore grab (foregrabmath.h): take hold near the barrel, stay put on the gun, follow a real slide, let go far away, follow the gun's length.
#include <stdio.h>
#include <math.h>
#include "foregrabmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
#define NEAR(a, b, e) do { if (!(fabs((a) - (b)) <= (e))) { printf("FAIL line %d: %s = %.5f, wanted %.5f +- %g\n", __LINE__, #a, (double)(a), (double)(b), (double)(e)); ++fails; } } while (0)

int main() {
  const foregrab::Params P = foregrab::defaults();
  const double base[3] = {0, 4, 0}, dir[3] = {0, 0, 1}, up[3] = {0, 1, 0};
  const double L = 2.0, under = 0.2;
  // 1. not held: nothing, state cleared
  {
    foregrab::State s = {0, 0, 0}; double l[3] = {0, 3.8, 1.0};
    foregrab::Out o = foregrab::step(&s, 0, l, base, dir, up, L, under, P);
    CHECK(!o.on && !s.have);
  }
  // 2. a hand near the barrel takes hold at the spot where it is; a hand far away does not
  {
    foregrab::State s = {0, 0, 0}; double l[3] = {0.1, 3.8, 1.0};
    foregrab::Out o = foregrab::step(&s, 1, l, base, dir, up, L, under, P);
    CHECK(o.on); NEAR(o.along, 1.0, 1e-9);
    foregrab::State s2 = {0, 0, 0}; double f[3] = {2.2, 3.0, 1.0};
    o = foregrab::step(&s2, 1, f, base, dir, up, L, under, P);
    CHECK(!o.on);
  }
  // 3. held: the real hand jitters by 8 cm in every direction: the grip point does not move at all
  {
    foregrab::State s = {0, 0, 0}; double l[3] = {0.0, 3.8, 1.0};
    foregrab::step(&s, 1, l, base, dir, up, L, under, P);
    double maxMove = 0;
    for (int k = 0; k < 200; ++k) {
      double j[3] = {0.0 + 0.08 * sin(k * 0.9), 3.8 + 0.08 * cos(k * 1.3), 1.0 + 0.12 * sin(k * 0.7)};   // up to 0.12 ft = 3.7 cm along, within the 0.15 ft dead zone
      foregrab::Out o = foregrab::step(&s, 1, j, base, dir, up, L, under, P);
      CHECK(o.on);
      const double m = fabs(o.along - 1.0); if (m > maxMove) maxMove = m;
    }
    printf("foregrab: real hand jitters 3.7 cm along the barrel, the grip point moved by %.4f ft\n", maxMove);
    NEAR(maxMove, 0.0, 1e-9);
  }
  // 4. a real slide along the barrel: the grip point follows, trailing by the dead zone
  {
    foregrab::State s = {0, 0, 0}; double l[3] = {0.0, 3.8, 1.0};
    foregrab::step(&s, 1, l, base, dir, up, L, under, P);
    double l2[3] = {0.0, 3.8, 1.6};
    foregrab::Out o = foregrab::step(&s, 1, l2, base, dir, up, L, under, P);
    CHECK(o.on); NEAR(o.along, 1.6 - P.deadFt, 1e-9);
    double l3[3] = {0.0, 3.8, 1.4};
    o = foregrab::step(&s, 1, l3, base, dir, up, L, under, P);
    NEAR(o.along, 1.6 - P.deadFt, 1e-9);     // coming back inside the dead zone: no move
  }
  // 5. the hand goes far from the grip point: let go; coming back takes hold again
  {
    foregrab::State s = {0, 0, 0}; double l[3] = {0.0, 3.8, 1.0};
    foregrab::step(&s, 1, l, base, dir, up, L, under, P);
    double far[3] = {2.2, 3.2, 1.0};
    foregrab::Out o = foregrab::step(&s, 1, far, base, dir, up, L, under, P);
    CHECK(!o.on);
    o = foregrab::step(&s, 1, l, base, dir, up, L, under, P);
    CHECK(o.on);
  }
  // 6. the grip point stays inside the gun's length range, for whatever length the gun has now
  {
    foregrab::State s = {0, 0, 0}; double l[3] = {0.0, 3.8, 0.1};
    foregrab::Out o = foregrab::step(&s, 1, l, base, dir, up, 2.0, under, P);
    NEAR(o.along, 0.25 * 2.0, 1e-9);
    o = foregrab::step(&s, 1, l, base, dir, up, 3.0, under, P);                 // a longer gun (another model): the range is the new one
    CHECK(o.along >= 0.25 * 3.0 - 1e-9 && o.along <= 0.95 * 3.0 + 1e-9);
    double e[3] = {0.0, 3.8, 9.0};
    o = foregrab::step(&s, 1, e, base, dir, up, 3.0, under, P);
    CHECK(o.along <= 0.95 * 3.0 + 1e-9);
  }
  // 7. the gun moves (the right hand aims, or you walk): the grip point is rebuilt from the gun's current place, the hand does not lag behind it
  {
    foregrab::State s = {0, 0, 0}; double l[3] = {0.0, 3.8, 1.0};
    foregrab::step(&s, 1, l, base, dir, up, L, under, P);
    const double base2[3] = {0.0, 4.0, 5.0};    // the gun is 5 ft further on; the real hand is carried along with it
    double l2[3] = {0.0, 3.8, 6.0};
    foregrab::Out o = foregrab::step(&s, 1, l2, base2, dir, up, L, under, P);
    CHECK(o.on); NEAR(o.along, 1.0, 1e-9);
  }
  // 8. bad length: nothing
  {
    foregrab::State s = {0, 0, 0}; double l[3] = {0, 3.8, 1.0};
    foregrab::Out o = foregrab::step(&s, 1, l, base, dir, up, 0.05, under, P);
    CHECK(!o.on && !s.have);
  }
  // 9. 1.7.116 FORE NEAR: a free hand near the barrel takes hold, with hysteresis, only along the gun; real cm follow the world's size
  {
    const double fpm = 3.28084, Lg = 1.9122;                      // a 58.3 cm gun
    const double reach = foregrab::cm_to_ft(18.0, fpm);            // 18 cm
    NEAR(reach, 0.59055, 1e-4); NEAR(foregrab::ft_to_cm(reach, fpm), 18.0, 1e-9);
    NEAR(foregrab::cm_to_ft(18.0, 2.0 * fpm), 2.0 * reach, 1e-9);  // a world twice the size: twice the feet
    const double mid = 0.5 * Lg;
    CHECK(foregrab::near_step(0, mid, foregrab::cm_to_ft(5.0, fpm), Lg, reach) == 1);        // 5 cm from the barrel, half way along: takes hold
    CHECK(foregrab::near_step(0, mid, foregrab::cm_to_ft(17.0, fpm), Lg, reach) == 1);       // 17 cm: still inside 18
    CHECK(foregrab::near_step(0, mid, foregrab::cm_to_ft(19.0, fpm), Lg, reach) == 0);       // 19 cm: not yet
    CHECK(foregrab::near_step(1, mid, foregrab::cm_to_ft(19.0, fpm), Lg, reach) == 1);       // holding: stays out to 1.4 x (25.2 cm)
    CHECK(foregrab::near_step(1, mid, foregrab::cm_to_ft(24.0, fpm), Lg, reach) == 1);
    CHECK(foregrab::near_step(1, mid, foregrab::cm_to_ft(26.0, fpm), Lg, reach) == 0);       // beyond that it lets go
    // along the barrel: not behind the gun's origin, not far past the muzzle; the edges have hysteresis
    CHECK(foregrab::near_step(0, 0.10 * Lg, 0.1, Lg, reach) == 0);                          // at the back (10 %): no
    CHECK(foregrab::near_step(0, 0.16 * Lg, 0.1, Lg, reach) == 1);
    CHECK(foregrab::near_step(1, 0.10 * Lg, 0.1, Lg, reach) == 1);                          // holding: it lets go only below 8 %
    CHECK(foregrab::near_step(1, 0.05 * Lg, 0.1, Lg, reach) == 0);
    CHECK(foregrab::near_step(0, 1.04 * Lg, 0.1, Lg, reach) == 1 && foregrab::near_step(0, 1.08 * Lg, 0.1, Lg, reach) == 0);
    CHECK(foregrab::near_step(1, 1.12 * Lg, 0.1, Lg, reach) == 1 && foregrab::near_step(1, 1.20 * Lg, 0.1, Lg, reach) == 0);
    // off / bad input: 0 cm = off, a tiny or unknown gun = off
    CHECK(foregrab::near_step(0, mid, 0.0, Lg, 0.0) == 0 && foregrab::near_step(1, mid, 0.0, Lg, -1.0) == 0);
    CHECK(foregrab::near_step(0, 0.05, 0.0, 0.1, reach) == 0);
    // a hand that wobbles around the take-hold edge (18 cm +- 1.5 cm) switches on once, not every pass
    { int on = 0, flips = 0; const double wob[10] = {16.5, 19.5, 17.0, 19.0, 17.5, 18.5, 19.5, 16.8, 19.2, 17.2};
      for (int i = 0; i < 10; ++i) { const int n = foregrab::near_step(on, mid, foregrab::cm_to_ft(wob[i], fpm), Lg, reach); if (n != on) ++flips; on = n; }
      CHECK(flips == 1 && on == 1); }
    // where the hand is against the gun (the gun at the origin along +z; the hand 1 ft along, 0.3 ft to the side and 0.4 ft up)
    { const double h[3] = {0.3, 0.4, 1.0}, g[3] = {0, 0, 0}, d[3] = {0, 0, 1}; double al = 0, pe = 0;
      foregrab::hand_vs_barrel(h, g, d, &al, &pe); NEAR(al, 1.0, 1e-12); NEAR(pe, 0.5, 1e-12); }
    // the buckets
    CHECK(foregrab::near_bucket(0.0) == 0 && foregrab::near_bucket(5.9) == 0 && foregrab::near_bucket(6.0) == 1 && foregrab::near_bucket(13.9) == 2 && foregrab::near_bucket(14.0) == 3 &&
          foregrab::near_bucket(21.9) == 4 && foregrab::near_bucket(27.9) == 5 && foregrab::near_bucket(39.9) == 6 && foregrab::near_bucket(40.0) == 7 && foregrab::near_bucket(900.0) == 7);
  }
  if (fails) { printf("%d failures\n", fails); return 1; }
  printf("foregrab: ok\n");
  return 0;
}
