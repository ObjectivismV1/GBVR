// 1.7.104 steady foregrip (foregripmath.h): the gun's place is rebuilt from the SAME controller sample as the left hand, so walking / sprinting does not move the hand along the barrel.
#include <stdio.h>
#include <math.h>
#include "foregripmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
#define NEAR(a, b, e) do { if (!(fabs((a) - (b)) <= (e))) { printf("FAIL line %d: %s = %.5f, wanted %.5f +- %g\n", __LINE__, #a, (double)(a), (double)(b), (double)(e)); ++fails; } } while (0)

// a controller pose: grip point, forward, up (game world, feet); the gun sits at a fixed offset (a forward, b up, c side) in the controller's axes
struct Pose { double grip[3], dir[3], up[3]; };
static void gun_at(const Pose& p, double a, double b, double c, double* g) {
  double D[3], U[3], S[3]; foregrip::frame(p.dir, p.up, D, U, S);
  for (int i = 0; i < 3; ++i) g[i] = p.grip[i] + a * D[i] + b * U[i] + c * S[i];
}
static Pose make(double x, double y, double z, double yawDeg, double pitchDeg, double rollDeg) {
  const double k = 3.14159265358979323846 / 180.0;
  const double cy = cos(yawDeg * k), sy = sin(yawDeg * k), cp = cos(pitchDeg * k), sp = sin(pitchDeg * k), cr = cos(rollDeg * k), sr = sin(rollDeg * k);
  Pose p; p.grip[0] = x; p.grip[1] = y; p.grip[2] = z;
  p.dir[0] = sy * cp; p.dir[1] = sp; p.dir[2] = cy * cp;
  // up: world up tilted by the roll about the forward axis
  double up0[3] = {0, 1, 0}, D[3] = {p.dir[0], p.dir[1], p.dir[2]};
  double S0[3] = {D[1] * up0[2] - D[2] * up0[1], D[2] * up0[0] - D[0] * up0[2], D[0] * up0[1] - D[1] * up0[0]};
  double l = sqrt(S0[0] * S0[0] + S0[1] * S0[1] + S0[2] * S0[2]); for (int i = 0; i < 3; ++i) S0[i] /= l;
  double U0[3] = {S0[1] * D[2] - S0[2] * D[1], S0[2] * D[0] - S0[0] * D[2], S0[0] * D[1] - S0[1] * D[0]};
  for (int i = 0; i < 3; ++i) p.up[i] = U0[i] * cr + S0[i] * sr;
  return p;
}
static double along(const double* a, const double* b, const Pose& p) { double D[3], U[3], S[3]; foregrip::frame(p.dir, p.up, D, U, S); double v[3] = {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; return v[0] * D[0] + v[1] * D[1] + v[2] * D[2]; }

int main() {
  const double A = 0.9, B = -0.15, C = 0.05;   // the gun's origin 0.9 ft in front of the grip, 0.15 below, 0.05 to the side
  // 1. the rebuilt place equals the real one for ANY pose, after one placement
  {
    foregrip::Offsets s = {{0, 0, 0}, 0};
    const Pose p0 = make(5, 4, 2, 30, 10, 20);
    double g0[3]; gun_at(p0, A, B, C, g0);
    CHECK(foregrip::learn(&s, p0.grip, p0.dir, p0.up, g0, 0.12));
    NEAR(s.o[0], A, 1e-9); NEAR(s.o[1], B, 1e-9); NEAR(s.o[2], C, 1e-9);
    const Pose poses[4] = {make(5.3, 4.1, 2.4, 33, 12, 25), make(-3, 2, 8, 170, -30, -40), make(0, 0, 0, 0, 80, 0), make(9, 9, 9, -120, 5, 90)};
    for (int k = 0; k < 4; ++k) {
      double want[3], got[3]; gun_at(poses[k], A, B, C, want);
      CHECK(foregrip::place(&s, poses[k].grip, poses[k].dir, poses[k].up, got));
      for (int i = 0; i < 3; ++i) NEAR(got[i], want[i], 1e-9);
    }
  }
  // 2. walking: the world moves 0.17 ft per frame (a sprint at 90 Hz); the gun is placed every 2nd frame, the left hand comes from every frame.
  //    The old way (the last placement's place) is off by the world's move since then along the barrel; the new way is exact.
  {
    foregrip::Offsets s = {{0, 0, 0}, 0};
    double gunStale[3] = {0, 0, 0}; int have = 0;
    double stepOldMax = 0, stepNewMax = 0, prevOld = 0, prevNew = 0; int n = 0;
    for (int f = 0; f < 120; ++f) {
      const Pose p = make(0.0, 4.0, 0.17 * f, 0.0, 0.0, 0.0);               // walking straight along +z, the barrel points +z
      double g[3]; gun_at(p, A, B, C, g);
      if (f % 2 == 0) { for (int i = 0; i < 3; ++i) gunStale[i] = g[i]; foregrip::learn(&s, p.grip, p.dir, p.up, g, 0.12); have = 1; }
      double mine[3]; CHECK(foregrip::place(&s, p.grip, p.dir, p.up, mine));
      // the left hand rides at 0.3 ft ahead of the gun origin, from the current sample
      double hand[3]; for (int i = 0; i < 3; ++i) hand[i] = g[i] + p.dir[i] * 0.3;
      const double aOld = along(hand, gunStale, p), aNew = along(hand, mine, p);
      if (f > 4) { n++; const double dO = fabs(aOld - prevOld), dN = fabs(aNew - prevNew); if (dO > stepOldMax) stepOldMax = dO; if (dN > stepNewMax) stepNewMax = dN; }
      prevOld = aOld; prevNew = aNew;
      (void)have;
    }
    printf("foregrip: walking at 0.17 ft per frame, hand-to-gun distance along the barrel changes by up to %.3f ft per frame the old way, %.6f ft the new way\n", stepOldMax, stepNewMax);
    CHECK(stepOldMax > 0.1);          // the old way jumps by the world's move
    CHECK(stepNewMax < 1e-6);         // the new way holds still
  }
  // 3. a placement that is slightly different each time (noise) is averaged, not followed
  {
    foregrip::Offsets s = {{0, 0, 0}, 0};
    const Pose p = make(1, 2, 3, 10, 5, 0);
    for (int k = 0; k < 200; ++k) {
      const double e = (k % 2 ? 1 : -1) * 0.05;
      double g[3]; gun_at(p, A + e, B, C, g);
      foregrip::learn(&s, p.grip, p.dir, p.up, g, 0.12);
    }
    NEAR(s.o[0], A, 0.03);
  }
  // 3b. another weapon in the hand (a jump in the offset) is taken at once, not eased over seconds
  {
    foregrip::Offsets s = {{0, 0, 0}, 0};
    const Pose p = make(1, 2, 3, 10, 5, 0);
    double g[3]; gun_at(p, A, B, C, g); foregrip::learn(&s, p.grip, p.dir, p.up, g, 0.12);
    gun_at(p, A + 0.6, B, C, g); foregrip::learn(&s, p.grip, p.dir, p.up, g, 0.12);
    NEAR(s.o[0], A + 0.6, 1e-9);
  }
  // 4. bad input: zero direction -> nothing learned / placed, no NaN
  {
    foregrip::Offsets s = {{0, 0, 0}, 0};
    const double z[3] = {0, 0, 0}, g[3] = {1, 1, 1}, u[3] = {0, 1, 0}, d[3] = {0, 0, 1};
    CHECK(!foregrip::learn(&s, g, z, u, g, 0.12) && !s.have);
    double out[3]; CHECK(!foregrip::place(&s, g, d, u, out));
    CHECK(foregrip::learn(&s, g, d, u, g, 0.12) && s.have);
    CHECK(!foregrip::place(&s, g, d, d, out));    // up parallel to forward: no frame
  }
  if (fails) { printf("%d failures\n", fails); return 1; }
  printf("foregrip: ok\n");
  return 0;
}
