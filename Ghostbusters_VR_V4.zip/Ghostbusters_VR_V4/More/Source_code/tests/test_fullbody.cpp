#include <initializer_list>
#include <math.h>
// 0.61 full body: head / spine / crouch / legs / arm stretch through armcore.h on a fake skinned model that has the
// real bone names and parent layout (pelvis, hips, legs, spine, clavicles, arms, neck, head).
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "armcore.h"
#include "packmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double fabs_(double x) { return x < 0 ? -x : x; }

enum { N = 26 };
static const char* kNames[N] = {"bone_pelvis", "bone_hips", "bone_L_thigh", "bone_L_calf", "bone_L_ankle", "bone_L_foot", "bone_R_thigh", "bone_R_calf", "bone_R_ankle", "bone_R_foot",
                                "bone_spine1", "bone_spine2", "bone_spine3", "bone_R_clavicle1", "bone_R_upperarm", "bone_R_forearm", "bone_R_hand",
                                "bone_L_clavicle1", "bone_L_upperarm", "bone_L_forearm", "bone_L_hand", "bone_neck", "bone_head", "bone_head_top", "bone_L_eye", "bone_R_eye"};
static const int kParent[N] = {-1, 0, 1, 2, 3, 4, 1, 6, 7, 8, 0, 10, 11, 12, 13, 14, 15, 12, 17, 18, 19, 12, 21, 22, 22, 22};
enum { PELVIS = 0, LTHIGH = 2, LCALF = 3, LANKLE = 4, RTHIGH = 6, RCALF = 7, RANKLE = 8, SPINE1 = 10, SPINE3 = 12, RUP = 14, RFORE = 15, RHAND = 16, LUP = 18, LHAND = 20, NECK = 21, HEAD = 22, TOP = 23, LEYE = 24, REYE = 25, SPINE2 = 11, RCLAV = 13 };

struct Fake { uint8_t* actor; uint8_t* skel; uint8_t* local; float* world; int logs; };
static Fake F;
static void qset(uint8_t* l, const double* axis, double deg, double scale, const double* pos) {
  double h = deg * vm::kPi / 360.0, s, c;
  vm::dsincos(h, &s, &c);
  float* f = (float*)l;
  f[0] = (float)(axis[0] * s); f[1] = (float)(axis[1] * s); f[2] = (float)(axis[2] * s); f[3] = (float)c;
  f[4] = f[5] = f[6] = (float)scale;
  f[7] = (float)pos[0]; f[8] = (float)pos[1]; f[9] = (float)pos[2];
}
struct G {
  static void local(const void* l, float* out) {
    const float* f = (const float*)l;
    double x = f[0], y = f[1], z = f[2], w = f[3];
    double R[9] = {1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w), 2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w),
                   2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)};
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = (float)(R[c * 3 + r] * f[4 + r]);
    out[12] = f[7]; out[13] = f[8]; out[14] = f[9];
  }
  static void mul(float* out, const float* a, const float* b) {
    float t[16] = {0};
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) t[r * 4 + c] = a[r * 4] * b[c] + a[r * 4 + 1] * b[4 + c] + a[r * 4 + 2] * b[8 + c];
    for (int c = 0; c < 3; ++c) t[12 + c] = a[12] * b[c] + a[13] * b[4 + c] + a[14] * b[8 + c] + b[12 + c];
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = t[r * 4 + c];
  }
  static void ensure(void* m) {
    int* state = (int*)((uint8_t*)m + layout::kOffModelState - layout::kOffActorModel + layout::kOffActorModel);
    if (*state > 0) return;
    for (int i = 0; i < N; ++i) {
      float tmp[16] = {0};
      local(F.local + 40 * i, tmp);
      if (kParent[i] < 0) { for (int k = 0; k < 16; ++k) F.world[i * 16 + k] = tmp[k]; }
      else mul(F.world + i * 16, tmp, F.world + kParent[i] * 16);
    }
    *state = 1;
  }
  static int readable(const void*, size_t, int) { return 1; }
  static int64_t clock() { static int64_t c; return ++c; }
  static void log(const char* fmt, ...) {
    ++F.logs;
    if (getenv("ARMLOG")) { va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap); printf("\n"); }
  }
};
typedef armcore::Core<G> Core;

static void* aligned16(size_t n) { return aligned_alloc(16, (n + 15u) & ~(size_t)15u); }

static void build() {
  if (!F.actor) {
    F.actor = (uint8_t*)aligned16(0x10000);
    F.skel = (uint8_t*)aligned16(0x8c + N * 0x4c + 64);
    F.local = (uint8_t*)aligned16(N * 40);
    F.world = (float*)aligned16(N * 64);
  }
  memset(F.actor, 0, 0x10000); memset(F.skel, 0, 0x8c + N * 0x4c + 64); memset(F.local, 0, N * 40); memset(F.world, 0, N * 64);
  uint8_t* M = F.actor + layout::kOffActorModel;
  *(int*)(F.skel + 0x88) = N;
  for (int i = 0; i < N; ++i) {
    strncpy((char*)F.skel + 0x8c + i * 0x4c, kNames[i], 0x17);
    *(int*)(F.skel + 0x8c + i * 0x4c + 0x1c) = kParent[i];
  }
  *(uint8_t**)(M + layout::kOffModelSkeleton) = F.skel;
  *(uint8_t**)(M + layout::kOffModelLocal) = F.local;
  *(float**)(M + layout::kOffModelWorld) = F.world;
  *(int*)(M + layout::kOffModelBoneCount) = N;
  *(int*)(M + layout::kOffModelState) = -1;
  int* idx = (int*)(F.actor + layout::kOffActorBoneIdx);
  idx[0] = HEAD; idx[1] = SPINE3; idx[2] = RUP; idx[3] = LUP; idx[4] = RHAND; idx[5] = LHAND;
  const double X[3] = {1, 0, 0};
  struct P { int b; double deg; double p[3]; } tab[N] = {
    {0, 0, {0, 3.0, 0}}, {1, 0, {0, 0, 0}}, {2, 0, {-0.2, 0, 0}}, {3, 8, {0, -1.4, 0}}, {4, -8, {0, -1.4, 0}}, {5, 0, {0, -0.2, 0.3}},
    {6, 0, {0.2, 0, 0}}, {7, 8, {0, -1.4, 0}}, {8, -8, {0, -1.4, 0}}, {9, 0, {0, -0.2, 0.3}},
    {10, 0, {0, 0.3, 0}}, {11, 0, {0, 0.5, 0}}, {12, 0, {0, 0.5, 0}}, {13, 0, {0.15, 0.2, 0}}, {14, 10, {0.35, 0, 0}}, {15, -70, {0, -1.0, 0}}, {16, 15, {0, -0.9, 0}},
    {17, 0, {-0.15, 0.2, 0}}, {18, 10, {-0.35, 0, 0}}, {19, -70, {0, -1.0, 0}}, {20, 15, {0, -0.9, 0}}, {21, 0, {0, 0.4, 0}}, {22, 0, {0, 0.3, 0.05}}, {23, 0, {0, 0.5, 0}}, {24, 0, {-0.1, 0.12, 0.25}}, {25, 0, {0.1, 0.12, 0.25}}};
  for (int i = 0; i < N; ++i) qset(F.local + 40 * i, X, tab[i].deg, 1, tab[i].p);
}
static void world_pos(const arm::Space& sp, int bone, double* w) { sp.point_world(F.world + bone * 16 + 12, w); }
static double dist(const double* a, const double* b) { double d[3] = {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; return arm::len(d); }
static void level(double yaw, double* o) { double s, c; vm::dsincos(yaw, &s, &c); o[0] = c; o[1] = 0; o[2] = s; o[3] = 0; o[4] = 1; o[5] = 0; o[6] = -s; o[7] = 0; o[8] = c; }
static void reset_model() { build(); Core::c.model = 0; }

int main() {
  float W2[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 2, 0, 3, 1};   // body at (2,0,3), no turn, scale 1
  arm::Space sp;
  CHECK(sp.set(W2));
  uintptr_t actor;
  ArmTargets t;
  auto fresh = [&]() { reset_model(); actor = (uintptr_t)F.actor; G::ensure(F.actor + layout::kOffActorModel); memset(&t, 0, sizeof(t));
                       t.bodyOn = 1; level(0, t.hmdBasis); t.bodyYaw = 0; t.leanMaxDeg = 55; t.headMaxDeg = 95; t.dropMaxFt = 2.1; t.crouchOn = 1; t.stretchMax = 1.7; t.fade = 1.0; };
  // 1. nothing asked: the pose stays the animation's
  {
    fresh();
    float before[N * 16]; memcpy(before, F.world, sizeof(before));
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::c.torsoOk);
    CHECK(Core::c.arm[2].U == LTHIGH && Core::c.arm[3].U == RTHIGH);
    double maxd = 0;
    for (int i = 0; i < N * 16; ++i) { double d = fabs_(F.world[i] - before[i]); if (d > maxd) maxd = d; }
    printf("neutral: largest change %.5f\n", maxd);
    CHECK(maxd < 2e-3);
  }
  // 2. head turn of 40 degrees: the head's forward axis follows, the pelvis does not move
  {
    fresh();
    level(40.0 * vm::kPi / 180.0, t.hmdBasis);
    double p0[3]; world_pos(sp, PELVIS, p0);
    CHECK(Core::apply(actor, W2, &t) == 1);
    double hf[3] = {F.world[HEAD * 16 + 8], F.world[HEAD * 16 + 9], F.world[HEAD * 16 + 10]}, w[3];
    sp.dir_world(hf, w);
    double s40, c40; vm::dsincos(40.0 * vm::kPi / 180.0, &s40, &c40);
    printf("head forward %.3f,%.3f,%.3f want %.3f,0,%.3f\n", w[0], w[1], w[2], s40, c40);
    CHECK(fabs_(w[0] - s40) < 0.02 && fabs_(w[2] - c40) < 0.02 && fabs_(w[1]) < 0.02);
    double p1[3]; world_pos(sp, PELVIS, p1);
    CHECK(dist(p0, p1) < 1e-4);
    CHECK(Core::st.headMaxX10 > 350 && Core::st.headMaxX10 < 450);
  }
  // 3. head tilt (roll 25 deg) and pitch down 30 deg, limited head angle
  {
    fresh();
    double ax[3] = {1, 0, 0}, R[9];
    weight::axis_angle(ax, 30.0 * vm::kPi / 180.0, R);   // look down about the right axis (sign irrelevant for the check)
    for (int i = 0; i < 9; ++i) t.hmdBasis[i] = R[i];
    CHECK(Core::apply(actor, W2, &t) == 1);
    for (int i = 0; i < N * 16; ++i) CHECK(vm::is_finite_f(F.world[i]));
    double hu[3] = {F.world[HEAD * 16 + 4], F.world[HEAD * 16 + 5], F.world[HEAD * 16 + 6]}, w[3];
    sp.dir_world(hu, w);
    double want[3] = {R[1], R[4], R[7]};   // image of the up axis
    CHECK(dist(w, want) < 0.03);
  }
  // 4. a huge head turn is limited
  {
    fresh();
    level(170.0 * vm::kPi / 180.0, t.hmdBasis);
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.lastHeadX10 > 1500);          // asked for 170 deg
    double hf[3] = {F.world[HEAD * 16 + 8], F.world[HEAD * 16 + 9], F.world[HEAD * 16 + 10]}, w[3];
    sp.dir_world(hf, w);
    double s, c; vm::dsincos(95.0 * vm::kPi / 180.0, &s, &c);
    CHECK(fabs_(w[0] - s) < 0.05 && fabs_(w[2] - c) < 0.05);
  }
  // 5. crouch 1.0 ft: head goes down ~0.85, ankles stay, legs keep their lengths, knees bend forward (+z)
  {
    fresh();
    double a0[2][3], k0[2][3], h0[3];
    world_pos(sp, LANKLE, a0[0]); world_pos(sp, RANKLE, a0[1]); world_pos(sp, LCALF, k0[0]); world_pos(sp, RCALF, k0[1]); world_pos(sp, HEAD, h0);
    double th0[3], th1[3]; world_pos(sp, LTHIGH, th0);
    double len1 = dist(th0, k0[0]);
    t.headDelta[1] = -1.0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    double a1[2][3], k1[2][3], h1[3];
    world_pos(sp, LANKLE, a1[0]); world_pos(sp, RANKLE, a1[1]); world_pos(sp, LCALF, k1[0]); world_pos(sp, RCALF, k1[1]); world_pos(sp, HEAD, h1);
    printf("crouch: head y %.3f -> %.3f, knee z %.3f -> %.3f, legMoved %d/%d clamped %d/%d\n", h0[1], h1[1], k0[0][2], k1[0][2], Core::st.legMoved[0], Core::st.legMoved[1], Core::st.legClamped[0], Core::st.legClamped[1]);
    CHECK(Core::st.legMoved[0] == 1 && Core::st.legMoved[1] == 1);
    CHECK(dist(a0[0], a1[0]) < 3e-3 && dist(a0[1], a1[1]) < 3e-3);
    CHECK(h0[1] - h1[1] > 0.8 && h0[1] - h1[1] < 1.1);
    world_pos(sp, LTHIGH, th1);
    CHECK(fabs_(dist(th1, k1[0]) - len1) < 3e-3);
    CHECK(k1[0][2] - th1[2] > k0[0][2] - th0[2] - 0.01);   // knee not behind where it was relative to the hip
    CHECK(k1[0][2] > a1[0][2] + 0.1 || k1[0][2] > th1[2] + 0.1);   // knee in front of the hip-ankle line
    CHECK(Core::st.dropMaxX100 > 80);
  }
  // 6. drop limit
  {
    fresh();
    t.headDelta[1] = -5.0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.lastDropX100 <= 211);
    for (int i = 0; i < N * 16; ++i) CHECK(vm::is_finite_f(F.world[i]));
  }
  // 7. lean forward 0.5 ft: the head ends near its target, pelvis and ankles stay
  {
    fresh();
    double h0[3], p0[3], a0[3]; world_pos(sp, HEAD, h0); world_pos(sp, PELVIS, p0); world_pos(sp, LANKLE, a0);
    t.headDelta[0] = 0.5; t.headDelta[2] = 0.3;
    CHECK(Core::apply(actor, W2, &t) == 1);
    double h1[3], p1[3], a1[3]; world_pos(sp, HEAD, h1); world_pos(sp, PELVIS, p1); world_pos(sp, LANKLE, a1);
    double want[3] = {h0[0] + 0.5, h0[1] + 0, h0[2] + 0.3};
    printf("lean: head %.2f,%.2f,%.2f want ~%.2f,%.2f,%.2f lean %.1f deg\n", h1[0], h1[1], h1[2], want[0], want[1], want[2], Core::st.lastLeanX10 / 10.0);
    CHECK(h1[0] - h0[0] > 0.35 && h1[2] - h0[2] > 0.2);
    CHECK(dist(p0, p1) < 1e-4 && dist(a0, a1) < 1e-4);
    CHECK(Core::st.lastLeanX10 > 100 && Core::st.lastLeanX10 < 560);
    // shoulders went with the spine
    double s0[3]; world_pos(sp, RUP, s0); (void)s0;
  }
  // 8. arm stretch: a hand target 1.45 x the arm's length away is reached
  {
    fresh();
    double S0[3], E0[3], H0[3]; world_pos(sp, RUP, S0); world_pos(sp, RFORE, E0); world_pos(sp, RHAND, H0);
    double L = dist(S0, E0) + dist(E0, H0);
    t.bodyOn = 0;
    t.rightOn = 1; weight::ident(t.wandR);
    for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
    t.grip[0] = S0[0] + 0.3 * L; t.grip[1] = S0[1] - 0.2 * L; t.grip[2] = S0[2] + 1.35 * L;   // just over 1.4 L away
    double want[3] = {t.grip[0], t.grip[1], t.grip[2]};
    double d = dist(S0, want);
    printf("stretch: arm %.2f ft, target %.2f ft away (%.0f%%)\n", L, d, d / L * 100);
    CHECK(Core::apply(actor, W2, &t) == 1);
    double H1[3]; world_pos(sp, RHAND, H1);
    CHECK(dist(H1, want) < 4e-3);
    CHECK(Core::st.stretched[0] == 1 && Core::st.lastStretchX100[0] > 135);
    CHECK(Core::st.clamped[0] == 0);
    for (int i = 0; i < N * 16; ++i) CHECK(vm::is_finite_f(F.world[i]));
    // stretch is limited: a target 3 L away stays at the cap
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    t.grip[2] = S0[2] + 3.0 * L;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.lastStretchX100[0] <= 170);
    CHECK(Core::st.clamped[0] >= 1);
    // stretch off
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    int sBefore = Core::st.stretched[0];
    t.stretchMax = 1.0; t.grip[2] = S0[2] + 1.35 * L;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.stretched[0] == sBefore);
  }
  // 9. missing torso bones: body layer off, arms still work
  {
    fresh();
    t.bodyOn = 1; t.headDelta[1] = -1.0;
    strncpy((char*)F.skel + 0x8c + HEAD * 0x4c, "bone_xxx", 0x17);
    CHECK(Core::apply(actor, W2, &t) == 1);      // bodyOn alone counts as work done only if... torso off
    CHECK(Core::st.noTorso >= 1);
  }
  // 10. idempotent for two eyes: the same targets applied twice (animation rebuilt in between) give the same pose
  {
    fresh();
    t.headDelta[0] = 0.2; t.headDelta[1] = -0.5; level(25.0 * vm::kPi / 180.0, t.hmdBasis);
    CHECK(Core::apply(actor, W2, &t) == 1);
    float a[N * 16]; memcpy(a, F.world, sizeof(a));
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;   // the engine recomputes the animation
    CHECK(Core::apply(actor, W2, &t) == 1);
    double maxd = 0;
    for (int i = 0; i < N * 16; ++i) { double d = fabs_(F.world[i] - a[i]); if (d > maxd) maxd = d; }
    CHECK(maxd < 1e-4);
  }
  // 11. the second eye of a pair (no animation rebuild in between): nothing is applied twice
  {
    fresh();
    t.headDelta[0] = 0.2; t.headDelta[1] = -0.5; level(25.0 * vm::kPi / 180.0, t.hmdBasis);
    CHECK(Core::apply(actor, W2, &t) == 1);
    float a1[N * 16]; memcpy(a1, F.world, sizeof(a1));
    int sk = Core::st.torsoSkipped;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.torsoSkipped == sk + 1);
    double maxd = 0;
    for (int i = 0; i < N * 16; ++i) { double d = fabs_(F.world[i] - a1[i]); if (d > maxd) maxd = d; }
    CHECK(maxd < 1e-4);
  }
  // 12. 0.66 gun in hand: a target farther than the stretch cap leaves a miss; the second eye skips the arm; a new target does not
  {
    fresh();
    double S0[3], E0[3], H0[3]; world_pos(sp, RUP, S0); world_pos(sp, RFORE, E0); world_pos(sp, RHAND, H0);
    const double L = dist(S0, E0) + dist(E0, H0);
    t.bodyOn = 0; t.rightOn = 1; weight::ident(t.wandR);
    for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
    t.grip[0] = S0[0] + 0.3 * L; t.grip[1] = S0[1] - 0.2 * L; t.grip[2] = S0[2] + 2.9 * L;   // about 2.9 arm lengths away, cap 1.7
    const int sk0 = Core::st.armSkipped[0];
    CHECK(Core::apply(actor, W2, &t) == 1);
    printf("miss: last %.2f ft (wanted ~%.2f), over0.1=%d demand>=220%%=%d\n", Core::st.lastMissX100[0] / 100.0, 2.9 * L - 1.7 * L, Core::st.missOver[0], Core::st.demand[0][5]);
    CHECK(Core::st.lastMissX100[0] > 100 && Core::st.missOver[0] >= 1);
    CHECK(Core::st.demand[0][5] >= 1);   // 2.9 x -> bucket 220..300
    float miss[3] = {Core::st.lastMiss[0][0], Core::st.lastMiss[0][1], Core::st.lastMiss[0][2]};
    float a1[N * 16]; memcpy(a1, F.world, sizeof(a1));
    CHECK(Core::apply(actor, W2, &t) == 1);                      // second eye: same pose, same targets
    CHECK(Core::st.armSkipped[0] == sk0 + 1);
    double maxd = 0;
    for (int i = 0; i < N * 16; ++i) { double d = fabs_(F.world[i] - a1[i]); if (d > maxd) maxd = d; }
    CHECK(maxd < 1e-6);
    CHECK(Core::st.lastMiss[0][0] == miss[0] && Core::st.lastMiss[0][2] == miss[2]);
    t.grip[2] += 0.05;                                            // the hand moved: not skipped
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.armSkipped[0] == sk0 + 1);
    // with a 2.6 cap the same 2.9 L target is still short, a 2.0 L target is reached without any miss
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    t.stretchMax = 2.6; t.grip[2] = S0[2] + 1.8 * L;
    CHECK(Core::apply(actor, W2, &t) == 1);
    printf("cap 2.6, target ~1.8 L: stretch %d%% miss %.2f ft clamped %d\n", Core::st.lastStretchX100[0], Core::st.lastMissX100[0] / 100.0, Core::st.clamped[0]);
    CHECK(Core::st.lastMissX100[0] <= 1);
    double H1[3]; world_pos(sp, RHAND, H1);
    double want[3] = {t.grip[0], t.grip[1], t.grip[2]};
    CHECK(dist(H1, want) < 4e-3);
  }
  // 13. 0.66 the arm guard does not skip after the engine rebuilt the animation (the matrices are no longer the ones we wrote)
  {
    fresh();
    double S0[3], E0[3], H0[3]; world_pos(sp, RUP, S0); world_pos(sp, RFORE, E0); world_pos(sp, RHAND, H0);
    const double L = dist(S0, E0) + dist(E0, H0);
    t.bodyOn = 0; t.rightOn = 1; weight::ident(t.wandR);
    for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
    t.grip[0] = S0[0] + 0.3 * L; t.grip[1] = S0[1] - 0.2 * L; t.grip[2] = S0[2] + 1.35 * L;
    CHECK(Core::apply(actor, W2, &t) == 1);
    const int sk = Core::st.armSkipped[0];
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;   // animation rebuilt: the arm is back at the animated pose
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.armSkipped[0] == sk);
    double H1[3]; world_pos(sp, RHAND, H1);
    double want[3] = {t.grip[0], t.grip[1], t.grip[2]};
    CHECK(dist(H1, want) < 4e-3);
  }

  // 14. 0.69 eye alignment: the avatar's eyes (midpoint of the two eye bones) end exactly at the camera's eye; the whole body shifts (ankles stay), the head slide is capped
  auto eye_mid = [&](double* e) { double a[3], b[3]; world_pos(sp, LEYE, a); world_pos(sp, REYE, b); for (int i = 0; i < 3; ++i) e[i] = 0.5 * (a[i] + b[i]); };
  {
    fresh();
    CHECK(Core::c.bEyeL == LEYE && Core::c.bEyeR == REYE);
    double E0[3]; eye_mid(E0);
    double an0[2][3]; world_pos(sp, LANKLE, an0[0]); world_pos(sp, RANKLE, an0[1]);
    t.eyeOn = 1;
    t.eyeTarget[0] = E0[0] + 0.05; t.eyeTarget[1] = E0[1] - 0.04; t.eyeTarget[2] = E0[2] + 0.08;
    const int hs = Core::st.headShifted, sh = Core::st.shifted;
    CHECK(Core::apply(actor, W2, &t) == 1);
    double E1[3]; eye_mid(E1);
    double want[3] = {t.eyeTarget[0], t.eyeTarget[1], t.eyeTarget[2]};
    printf("eyes: moved %.3f,%.3f,%.3f ft, left %.4f ft from the camera eye; model eye height %.2f ft\n", E1[0] - E0[0], E1[1] - E0[1], E1[2] - E0[2], dist(E1, want), (double)Core::st.modelEyeFt);
    CHECK(dist(E1, want) < 0.005);
    CHECK(Core::st.shifted == sh + 1 && Core::st.headShifted == hs);   // a small error is taken out by shifting the body, the head does not slide
    double an1[2][3]; world_pos(sp, LANKLE, an1[0]); world_pos(sp, RANKLE, an1[1]);
    printf("ankles moved %.4f / %.4f ft\n", dist(an0[0], an1[0]), dist(an0[1], an1[1]));
    { const double hz = sqrt(0.05 * 0.05 + 0.08 * 0.08);   // 0.70: the sideways part moves the feet with the body, the up/down part leaves them planted
      CHECK(fabs(dist(an0[0], an1[0]) - hz) < 6e-3 && fabs(dist(an0[1], an1[1]) - hz) < 6e-3); }
    // 0.70: 1.5 ft sideways: the whole body (feet too) goes there, no cap, exact
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    eye_mid(E0);
    t.eyeTarget[0] = E0[0]; t.eyeTarget[1] = E0[1]; t.eyeTarget[2] = E0[2] + 1.5;
    const int cp = Core::st.shiftCapped;
    CHECK(Core::apply(actor, W2, &t) == 1);
    eye_mid(E1);
    want[0] = t.eyeTarget[0]; want[1] = t.eyeTarget[1]; want[2] = t.eyeTarget[2];
    printf("eyes far sideways: left %.3f ft\n", dist(E1, want));
    CHECK(dist(E1, want) < 0.005 && Core::st.shiftCapped == cp);
    // a smaller cap
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    eye_mid(E0);
    t.shiftCapFt = 0.3; t.eyeTarget[1] = E0[1] + 0.6; t.eyeTarget[0] = E0[0]; t.eyeTarget[2] = E0[2];   // 0.70: the cap is for the up/down part
    CHECK(Core::apply(actor, W2, &t) == 1);
    eye_mid(E1);
    want[0] = t.eyeTarget[0]; want[1] = t.eyeTarget[1]; want[2] = t.eyeTarget[2];
    printf("eyes cap 0.3: left %.3f ft (body 0.3 + head 0.2 of 0.6)\n", dist(E1, want));
    CHECK(dist(E1, want) > 0.09 && dist(E1, want) < 0.11);
    // eye alignment off: nothing is moved
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    const int hs2 = Core::st.headShifted, sh2 = Core::st.shifted;
    t.eyeOn = 0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.headShifted == hs2 && Core::st.shifted == sh2);
  }
  // 14b. 0.75 view higher / body pushed out: the avatar's eyes end at (camera eye - viewDown) pushed bodyOut ahead along the body's facing
  {
    fresh();
    double E0[3], E1[3]; eye_mid(E0);
    t.eyeOn = 1; t.shiftCapFt = 0.5;
    t.eyeTarget[0] = E0[0]; t.eyeTarget[1] = E0[1]; t.eyeTarget[2] = E0[2];
    t.bodyYaw = 0.6;
    t.viewDownFt = 0.2; t.bodyOutFt = 0.3;
    CHECK(Core::apply(actor, W2, &t) == 1);
    eye_mid(E1);
    double want[3] = {t.eyeTarget[0] + sin(0.6) * 0.3, t.eyeTarget[1] - 0.2, t.eyeTarget[2] + cos(0.6) * 0.3};
    printf("view higher 0.2 ft + body out 0.3 ft: eyes %.3f,%.3f,%.3f want %.3f,%.3f,%.3f (left %.4f ft); eyeGoalOn=%d\n", E1[0], E1[1], E1[2], want[0], want[1], want[2], dist(E1, want), Core::st.eyeGoalOn);
    CHECK(dist(E1, want) < 0.006);
    CHECK(Core::st.eyeGoalOn == 1);
    // both at 0 = the old target exactly
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    t.viewDownFt = 0; t.bodyOutFt = 0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    eye_mid(E1);
    double w0[3] = {t.eyeTarget[0], t.eyeTarget[1], t.eyeTarget[2]};
    CHECK(dist(E1, w0) < 0.006);
    // 1.7.168 looking 70 deg down: body_out is gone and the body slides back by down_back (the eye ends in front of the collar); 40 deg down: halfway
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    t.bodyOutFt = 0.3; t.downBackFt = 0.4; t.viewDownFt = 0;
    t.hmdBasis[2] = 0.0; t.hmdBasis[5] = -sin(70.0 * 3.14159265358979 / 180.0); t.hmdBasis[8] = cos(70.0 * 3.14159265358979 / 180.0);
    CHECK(Core::apply(actor, W2, &t) == 1);
    eye_mid(E1);
    { double wd[3] = {t.eyeTarget[0] - sin(0.6) * 0.4, t.eyeTarget[1], t.eyeTarget[2] - cos(0.6) * 0.4};
      printf("looking 70 deg down: eyes %.3f ft from the slid-back goal (want 0), slide %d %%\n", dist(E1, wd), Core::st.downK100); CHECK(dist(E1, wd) < 0.006 && Core::st.downK100 == 100); }
    reset_model(); G::ensure(F.actor + layout::kOffActorModel);
    t.hmdBasis[5] = -sin(40.0 * 3.14159265358979 / 180.0); t.hmdBasis[8] = cos(40.0 * 3.14159265358979 / 180.0);
    CHECK(Core::apply(actor, W2, &t) == 1);
    eye_mid(E1);
    { const double kk = (40.0 - 20.0) / 40.0, k2 = kk * kk * (3.0 - 2.0 * kk); const double o = 0.3 * (1.0 - k2) - 0.4 * k2; double wd[3] = {t.eyeTarget[0] + sin(0.6) * o, t.eyeTarget[1], t.eyeTarget[2] + cos(0.6) * o};
      CHECK(dist(E1, wd) < 0.006 && abs(Core::st.downK100 - (int)(k2 * 100.0 + 0.5)) <= 1); }
    for (int i = 0; i < 9; ++i) t.hmdBasis[i] = 0; t.downBackFt = 0; t.bodyOutFt = 0;
    t.eyeOn = 0; t.bodyYaw = 0;
  }
  // 15. 0.69 forced moves: with the fade at 0 nothing is matched, at 0.5 half of the error is taken out
  {
    double E0[3], E1[3];
    for (int pass = 0; pass < 3; ++pass) {
      fresh();
      eye_mid(E0);
      t.eyeOn = 1; t.fade = pass == 0 ? 1.0 : pass == 1 ? 0.5 : 0.0;
      t.eyeTarget[0] = E0[0] + 0.20; t.eyeTarget[1] = E0[1]; t.eyeTarget[2] = E0[2];
      const int fc = Core::st.forcedCalls;
      CHECK(Core::apply(actor, W2, &t) == 1);
      eye_mid(E1);
      const double moved = E1[0] - E0[0];
      printf("fade %.1f: the eye moved %.3f of 0.200 ft\n", t.fade, moved);
      CHECK(fabs_(moved - 0.20 * t.fade) < 0.004);
      CHECK(Core::st.forcedCalls == fc + (pass == 2 ? 1 : 0));
    }
  }
  // 15b. 0.69 the model's eye height is the tallest peak, not a mean: a few odd poses do not move it, and nothing is learned while the game forces the character
  {
    fresh();
    auto again = [&]() { build(); Core::tpHave = 0; G::ensure(F.actor + layout::kOffActorModel); };   // the same model instance, the animation rebuilt (a new frame)
    t.eyeOn = 1;
    Core::apply(actor, W2, &t);
    const int n0 = Core::eyeHist.n;
    for (int k = 0; k < 80; ++k) {
      again();
      double E0[3]; eye_mid(E0);
      t.eyeTarget[0] = E0[0]; t.eyeTarget[1] = E0[1]; t.eyeTarget[2] = E0[2];
      Core::apply(actor, W2, &t);
    }
    printf("model eye height %.3f ft (n=%d, peak share %.0f%%)\n", (double)Core::st.modelEyeFt, Core::st.modelEyeN, (double)Core::st.modelEyeShare * 100.0);
    CHECK(Core::st.modelEyeFt > 5.0 && Core::st.modelEyeFt < 5.3 && Core::eyeHist.n >= n0 + 80);
    const int nBefore = Core::st.modelEyeN;
    t.fade = 0.3;   // forced
    for (int k = 0; k < 20; ++k) { again(); Core::apply(actor, W2, &t); }
    CHECK(Core::st.modelEyeN == nBefore);
    // scaled body: the measured height is the unscaled one
    t.fade = 1.0;
    float W3[16] = {1.2f, 0, 0, 0, 0, 1.2f, 0, 0, 0, 0, 1.2f, 0, 2, 0, 3, 1};
    for (int k = 0; k < 30; ++k) { again(); Core::apply(actor, W3, &t); }
    printf("model eye height with a 1.2 scaled body: %.3f ft\n", (double)Core::st.modelEyeFt);
    CHECK(Core::st.modelEyeFt > 5.0 && Core::st.modelEyeFt < 5.3);
    // a new model instance starts the measurement again
    Core::c.model = 0; build(); Core::tpHave = 0;
    G::ensure(F.actor + layout::kOffActorModel);
    Core::apply(actor, W2, &t);
    CHECK(Core::st.modelEyeN <= 1);
  }
  // 16. 0.68 shoulder reach: the clavicle swings toward a far hand target, so the arm stretches less; the hand still arrives
  {
    int lastNo = 0, lastYes = 0;
    for (int pass = 0; pass < 2; ++pass) {
      fresh();
      CHECK(Core::c.clav[0] == RCLAV);
      double S0[3], E0[3], H0[3]; world_pos(sp, RUP, S0); world_pos(sp, RFORE, E0); world_pos(sp, RHAND, H0);
      const double L = dist(S0, E0) + dist(E0, H0);
      t.bodyOn = 0; t.rightOn = 1; weight::ident(t.wandR);
      for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
      t.grip[0] = S0[0] + 0.3 * L; t.grip[1] = S0[1] - 0.2 * L; t.grip[2] = S0[2] + 1.35 * L;
      t.shoulderPullDeg = pass ? 35.0 : 0.0;
      const int p0 = Core::st.pulled[0];
      CHECK(Core::apply(actor, W2, &t) == 1);
      double H1[3]; world_pos(sp, RHAND, H1);
      double want[3] = {t.grip[0], t.grip[1], t.grip[2]};
      printf("shoulder pull %.0f deg: stretch %d%%, pulled %d times, last swing %.1f deg, hand %.4f ft from target\n", t.shoulderPullDeg, Core::st.lastStretchX100[0], Core::st.pulled[0] - p0, Core::st.lastPullX10[0] / 10.0, dist(H1, want));
      CHECK(dist(H1, want) < 4e-3);
      if (pass) { lastYes = Core::st.lastStretchX100[0]; CHECK(Core::st.pulled[0] == p0 + 1); CHECK(Core::st.lastPullX10[0] > 50 && Core::st.lastPullX10[0] <= 350); }
      else { lastNo = Core::st.lastStretchX100[0]; CHECK(Core::st.pulled[0] == p0); }
      for (int i = 0; i < N * 16; ++i) CHECK(vm::is_finite_f(F.world[i]));
    }
    printf("stretch without / with the shoulder: %d%% / %d%%\n", lastNo, lastYes);
    CHECK(lastYes < lastNo - 4);
    // a target inside the arm's reach does not move the shoulder
    fresh();
    double S0[3], H0[3]; world_pos(sp, RUP, S0); world_pos(sp, RHAND, H0);
    t.bodyOn = 0; t.rightOn = 1; weight::ident(t.wandR); t.shoulderPullDeg = 35.0;
    for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
    for (int i = 0; i < 3; ++i) t.grip[i] = H0[i];
    const int p0 = Core::st.pulled[0];
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.pulled[0] == p0);
  }
  // 17. 0.68 crouch dead zone: a small head dip is a lean, not a crouch; a real one folds the legs and drops by (dip - dead zone) * 0.9
  {
    fresh();
    t.crouchDeadFt = 0.26; t.headDelta[1] = -0.2;
    const int lm = Core::st.legMoved[0];
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.legMoved[0] == lm && Core::st.lastDropX100 == 0);
    fresh();
    t.crouchDeadFt = 0.26; t.headDelta[1] = -1.0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    printf("dead zone: dip 1.0 ft -> drop x100 ft = %d, want about 66\n", Core::st.lastDropX100);
    CHECK(Core::st.lastDropX100 >= 64 && Core::st.lastDropX100 <= 69 && Core::st.legMoved[0] == lm + 1);
  }
  // 18. 0.68 the recorded torso motion, applied to a matrix of its own (the pack), gives the same place the bone ended up at
  {
    fresh();
    t.crouchDeadFt = 0.1; t.headDelta[0] = 0.4; t.headDelta[1] = -0.7; t.headDelta[2] = 0.2;
    {   // 0.69 and the eye-match shift of the whole body (applied after the rotations)
      double Ee[3]; { double a[3], b[3]; world_pos(sp, LEYE, a); world_pos(sp, REYE, b); for (int i = 0; i < 3; ++i) Ee[i] = 0.5 * (a[i] + b[i]); }
      t.eyeOn = 1; t.eyeTarget[0] = Ee[0] + 0.5; t.eyeTarget[1] = Ee[1] - 0.2; t.eyeTarget[2] = Ee[2] + 0.4;
    }
    float before[2][16]; memcpy(before[0], F.world + SPINE2 * 16, 64); memcpy(before[1], F.world + SPINE3 * 16, 64);
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.motion.have == 1 && Core::st.motion.drop < -0.3);
    bpack::Motion m; m.have = 1; m.drop = Core::st.motion.drop;
    for (int i = 0; i < 3; ++i) m.shift[i] = Core::st.motion.shift[i];
    CHECK(fabs_(m.shift[0]) + fabs_(m.shift[1]) + fabs_(m.shift[2]) > 0.2);
    for (int s = 0; s < 2; ++s) { for (int i = 0; i < 3; ++i) m.pv[s][i] = Core::st.motion.pv[s][i]; for (int i = 0; i < 9; ++i) m.Q[s][i] = Core::st.motion.Q[s][i]; }
    auto to_world = [&](const float* mm, float* out) {
      for (int r = 0; r < 3; ++r) { double a[3] = {mm[r * 4], mm[r * 4 + 1], mm[r * 4 + 2]}, w[3]; sp.dir_world(a, w); for (int c = 0; c < 3; ++c) out[r * 4 + c] = (float)w[c]; out[r * 4 + 3] = 0; }
      double w[3]; sp.point_world(mm + 12, w); out[12] = (float)w[0]; out[13] = (float)w[1]; out[14] = (float)w[2]; out[15] = 1;
    };
    for (int which = 0; which < 2; ++which) {
      float a[16], b[16], c[16];
      to_world(before[which], a); to_world(F.world + (which ? SPINE3 : SPINE2) * 16, b);
      memcpy(c, a, 64);
      CHECK(bpack::apply(m, c, which ? 3 : 1) == 1);
      double md = 0;
      for (int i = 0; i < 15; ++i) { if (i == 3 || i == 7 || i == 11) continue; double d = fabs_(c[i] - b[i]); if (d > md) md = d; }
      printf("pack matrix vs bone (%s): largest difference %.5f\n", which ? "spine3, both stages" : "spine2, lower stage", md);
      CHECK(md < 2e-3);
    }
  }
  // 17. 0.71 arms only: everything that is not an arm is squashed to one point; the arms are untouched; the next call puts the bones back first
  {
    fresh();
    float ref[N * 16];
    t.armsOnly = 0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    memcpy(ref, F.world, sizeof(ref));
    fresh();
    t.armsOnly = 1;
    CHECK(Core::apply(actor, W2, &t) == 1);
    const int LCLAV = 17;
    const int armBones[] = {RCLAV, RUP, RFORE, RHAND, LCLAV, LUP, LHAND};
    double md = 0;
    for (int b : armBones) for (int i = 0; i < 12; ++i) { if (i % 4 == 3) continue; double d = fabs_(F.world[b * 16 + i] - ref[b * 16 + i]); if (d > md) md = d; }
    printf("arms only: largest change of an arm bone %.5f\n", md);
    CHECK(md < 1e-5);
    const int bodyBones[] = {PELVIS, LTHIGH, LANKLE, RANKLE, SPINE1, SPINE3, NECK, HEAD, LEYE};
    for (int b : bodyBones) {
      const float* B = F.world + b * 16;
      CHECK(fabs_(B[0]) < 2e-4 && fabs_(B[5]) < 2e-4 && fabs_(B[10]) < 2e-4 && fabs_(B[1]) == 0 && fabs_(B[4]) == 0);
      CHECK(B[12] == F.world[PELVIS * 16 + 12] && B[13] == F.world[PELVIS * 16 + 13] && B[14] == F.world[PELVIS * 16 + 14]);
    }
    printf("arms only: %d bones squashed\n", Core::st.colBones);
    CHECK(Core::st.colBones == N - 7 - 0 - (Core::c.arm[0].subN - 3) - (Core::c.arm[1].subN - 3) + 0 || Core::st.colBones > 8);
    // the second eye of the pair: the same call again, nothing rebuilt: the bones are put back first, torso/arms skip, then squashed again
    const int und = Core::st.colUndone;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.colUndone == und + 1);
    md = 0;
    for (int b : armBones) for (int i = 0; i < 12; ++i) { if (i % 4 == 3) continue; double d = fabs_(F.world[b * 16 + i] - ref[b * 16 + i]); if (d > md) md = d; }
    CHECK(md < 1e-5);
    CHECK(fabs_(F.world[HEAD * 16]) < 2e-4);
    // the engine rebuilt the pose: nothing is "put back" over the fresh matrices
    build(); G::ensure(F.actor + layout::kOffActorModel);
    const int und2 = Core::st.colUndone;
    Core::tpHave = 0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.colUndone == und2);
    // switched off: bones stay as they are
    fresh(); t.armsOnly = 0; CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(fabs_(F.world[HEAD * 16] - ref[HEAD * 16]) < 1e-4);
  }
  // 16b. 0.74 shoulder slide: after the swing, the whole shoulder (clavicle and arm) slides toward a hand that is still out of reach, so the arm stretches less; the hand still arrives
  {
    int stretch[2] = {0, 0}; double slid[2] = {0, 0};
    for (int pass = 0; pass < 2; ++pass) {
      fresh();
      double S0[3], E0[3], H0[3]; world_pos(sp, RUP, S0); world_pos(sp, RFORE, E0); world_pos(sp, RHAND, H0);
      const double L = dist(S0, E0) + dist(E0, H0);
      t.bodyOn = 0; t.rightOn = 1; weight::ident(t.wandR);
      for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
      t.grip[0] = S0[0] + 0.3 * L; t.grip[1] = S0[1] - 0.2 * L; t.grip[2] = S0[2] + 1.6 * L;
      t.shoulderPullDeg = 35.0; t.stretchMax = 2.6;
      t.shoulderSlideFt = pass ? 0.4 : 0.0;
      const int s0 = Core::st.slid[0];
      CHECK(Core::apply(actor, W2, &t) == 1);
      double H1[3], S1[3]; world_pos(sp, RHAND, H1); world_pos(sp, RUP, S1);
      double want[3] = {t.grip[0], t.grip[1], t.grip[2]};
      slid[pass] = dist(S1, S0);
      stretch[pass] = Core::st.lastStretchX100[0];
      printf("shoulder slide %.2f ft allowed: stretch %d%%, shoulder moved %.3f ft, hand %.4f ft from target\n", t.shoulderSlideFt, stretch[pass], slid[pass], dist(H1, want));
      CHECK(dist(H1, want) < 4e-3);
      if (pass) { CHECK(Core::st.slid[0] == s0 + 1); CHECK(Core::st.lastSlideX100[0] > 20 && Core::st.lastSlideX100[0] <= 40); }
      else CHECK(Core::st.slid[0] == s0);
      for (int i = 0; i < N * 16; ++i) CHECK(vm::is_finite_f(F.world[i]));
    }
    CHECK(stretch[1] < stretch[0] - 8);
    CHECK(slid[1] > slid[0] + 0.15 && slid[1] <= slid[0] + 0.45);
    // a hand inside the arm's reach does not slide the shoulder
    fresh();
    double S0[3], H0[3]; world_pos(sp, RUP, S0); world_pos(sp, RHAND, H0);
    t.bodyOn = 0; t.rightOn = 1; weight::ident(t.wandR); t.shoulderSlideFt = 0.4;
    for (int i = 0; i < 3; ++i) { t.wandP0[i] = H0[i]; t.grip[i] = H0[i]; }
    const int s1 = Core::st.slid[0];
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.slid[0] == s1);
  }
  // 16c. 0.74 rig view snapshot: joints relative to the camera eye in the headset's axes, taken before arms-only squashes the body
  {
    fresh();
    t.armsOnly = 1; t.keepShoulders = 0; t.rigOn = 1; t.fpm = 3.28084; t.eyeOn = 1;
    double Ew[3]; world_pos(sp, LEYE, Ew);
    double Er[3]; world_pos(sp, REYE, Er);
    double Hd[3]; world_pos(sp, HEAD, Hd);   // before anything moves (the torso pass may shift the body, so this is only close)
    for (int i = 0; i < 3; ++i) t.eyeTarget[i] = 0.5 * (Ew[i] + Er[i]);   // the camera eye is exactly between the avatar's eyes
    level(0, t.hmdBasis);
    const int p0 = Core::st.rigPasses;
    CHECK(Core::apply(actor, W2, &t) == 1);
    rig::Snap sn; sn.clear();
    CHECK(Core::rig_read(&sn) == 1);
    CHECK(Core::st.rigPasses == p0 + 1);
    CHECK(sn.ok[rig::J_HEAD] && sn.ok[rig::J_WRR] && sn.ok[rig::J_WRL] && sn.ok[rig::J_FTL] && sn.ok[rig::J_EYEL] && sn.ok[rig::J_PELVIS]);
    // the head is above the eye midpoint, the pelvis and feet below, the right wrist is to the right of the left one (headset axes: right, up, forward)
    printf("rig: head %.2f,%.2f,%.2f pelvis %.2f,%.2f,%.2f foot %.2f,%.2f,%.2f wristR %.2f,%.2f,%.2f wristL %.2f,%.2f,%.2f eyeL %.2f,%.2f,%.2f\n",
           (double)sn.j[rig::J_HEAD][0], (double)sn.j[rig::J_HEAD][1], (double)sn.j[rig::J_HEAD][2], (double)sn.j[rig::J_PELVIS][0], (double)sn.j[rig::J_PELVIS][1], (double)sn.j[rig::J_PELVIS][2],
           (double)sn.j[rig::J_FTL][0], (double)sn.j[rig::J_FTL][1], (double)sn.j[rig::J_FTL][2], (double)sn.j[rig::J_WRR][0], (double)sn.j[rig::J_WRR][1], (double)sn.j[rig::J_WRR][2],
           (double)sn.j[rig::J_WRL][0], (double)sn.j[rig::J_WRL][1], (double)sn.j[rig::J_WRL][2], (double)sn.j[rig::J_EYEL][0], (double)sn.j[rig::J_EYEL][1], (double)sn.j[rig::J_EYEL][2]);
    CHECK(sn.j[rig::J_PELVIS][1] < sn.j[rig::J_HEAD][1] - 0.5f);
    CHECK(sn.j[rig::J_FTL][1] < sn.j[rig::J_PELVIS][1]);
    CHECK(sn.j[rig::J_WRR][0] > sn.j[rig::J_WRL][0]);
    CHECK(sn.j[rig::J_EYEL][0] < 0.0f && (double)sn.j[rig::J_EYER][0] > 0.0);                // eyes straddle the camera eye
    CHECK(fabs_(sn.j[rig::J_EYEL][0] + sn.j[rig::J_EYER][0]) < 1e-3 && fabs_(sn.j[rig::J_EYEL][1] - sn.j[rig::J_EYER][1]) < 1e-3);
    // measured against the world positions: the same distance
    double dd[3] = {Hd[0] - t.eyeTarget[0], Hd[1] - t.eyeTarget[1], Hd[2] - t.eyeTarget[2]};
    const double dh = arm::len(dd);
    const double dr = vm::dsqrt((double)sn.j[rig::J_HEAD][0] * sn.j[rig::J_HEAD][0] + (double)sn.j[rig::J_HEAD][1] * sn.j[rig::J_HEAD][1] + (double)sn.j[rig::J_HEAD][2] * sn.j[rig::J_HEAD][2]);
    CHECK(fabs_(dh - dr) < 1e-4);
    // the body is squashed afterwards (arms only) but the snapshot was taken before
    CHECK(fabs_(F.world[HEAD * 16]) < 2e-4);
    // the pack: a matrix at known position, 1 m right and 2 m ahead of the eye (headset axes: forward = +z of the basis)
    float Wp[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
    for (int i = 0; i < 3; ++i) Wp[12 + i] = (float)t.eyeTarget[i];
    Wp[12] += 1.0f; Wp[14] += 2.0f;
    Core::rig_part(1, Wp, t.hmdBasis, t.eyeTarget);
    CHECK(Core::rig_read(&sn) == 1 && sn.packOk);
    CHECK(fabs_(sn.pack[0] - 1.0) < 1e-4 && fabs_(sn.pack[1]) < 1e-4 && fabs_(sn.pack[2] - 2.0) < 1e-4);
    CHECK(fabs_(sn.packAx[0][0] - 1.0) < 1e-5 && fabs_(sn.packAx[1][1] - 1.0) < 1e-5);
    t.armsOnly = 0; t.rigOn = 0; t.eyeOn = 0;
  }
  // 17b. 0.73 shoulders kept: the upper chest bone (and the clavicles / arms) stay exactly as they were; the neck, head, hips and legs are squashed to a point below and behind the upper chest
  {
    fresh();
    float ref[N * 16];
    t.armsOnly = 0; t.keepShoulders = 0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    memcpy(ref, F.world, sizeof(ref));
    fresh();
    t.armsOnly = 1; t.keepShoulders = 1;
    CHECK(Core::apply(actor, W2, &t) == 1);
    const int LCLAV = 17;
    const int keptBones[] = {SPINE3, RCLAV, RUP, RFORE, RHAND, LCLAV, LUP, LHAND};
    double md = 0;
    for (int b : keptBones) for (int i = 0; i < 12; ++i) { if (i % 4 == 3) continue; double d = fabs_(F.world[b * 16 + i] - ref[b * 16 + i]); if (d > md) md = d; }
    printf("shoulders kept: largest change of a kept bone %.5f, bones squashed %d (without shoulders: more)\n", md, Core::st.colBones);
    CHECK(md < 1e-5);
    const int bodyBones[] = {PELVIS, LTHIGH, LANKLE, RANKLE, SPINE1, NECK, HEAD, LEYE};
    for (int b : bodyBones) {
      const float* B = F.world + b * 16;
      CHECK(fabs_(B[0]) < 2e-4 && fabs_(B[5]) < 2e-4 && fabs_(B[10]) < 2e-4 && fabs_(B[1]) == 0 && fabs_(B[4]) == 0);
    }
    // the squash point lies below the upper chest bone
    CHECK(F.world[HEAD * 16 + 13] < ref[SPINE3 * 16 + 13] - 0.2);
    CHECK(Core::st.colShoulders >= 1);
    const int squashedWith = Core::st.colBones;
    fresh();
    t.armsOnly = 1; t.keepShoulders = 0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.colBones > squashedWith);              // without the shoulders, the upper chest bones are squashed as well
    CHECK(fabs_(F.world[SPINE3 * 16]) < 2e-4);
    // next call with the switch on again puts the bones back first
    t.keepShoulders = 1;
    CHECK(Core::apply(actor, W2, &t) == 1);
    md = 0;
    for (int b : keptBones) for (int i = 0; i < 12; ++i) { if (i % 4 == 3) continue; double d = fabs_(F.world[b * 16 + i] - ref[b * 16 + i]); if (d > md) md = d; }
    CHECK(md < 1e-5);
    fresh(); t.armsOnly = 0; t.keepShoulders = 0; CHECK(Core::apply(actor, W2, &t) == 1);
  }
  // Full-body head hiding preserves torso/limbs at steep pitch and displaced neck poses.
  {
    ArmTargets saved = t;
    for (int frame = 0; frame < 360; ++frame) {
      fresh(); t = saved; t.armsOnly = 0; t.headOnly = 0; t.bodyOn = 1;
      level(frame * vm::kPi / 180.0, t.hmdBasis);
      double sy, cy; vm::dsincos((frame % 91) * vm::kPi / 180.0, &sy, &cy);
      t.hmdBasis[3] = t.hmdBasis[2] * sy; t.hmdBasis[7] = t.hmdBasis[8] * sy;
      t.hmdBasis[4] = cy; t.hmdBasis[5] = -sy; t.hmdBasis[2] *= cy; t.hmdBasis[8] *= cy;
      ((float*)(F.local + 40 * NECK))[8] = (frame & 1) ? 1.1f : 0.4f;
      *(int*)(F.actor + layout::kOffModelState) = -1;
      ArmTargets pose = t;
      CHECK(Core::apply(actor, W2, &t) == 1);
      float ref[N * 16]; memcpy(ref, F.world, sizeof(ref));
      fresh(); t = pose; t.armsOnly = 1; t.headOnly = 1;
      ((float*)(F.local + 40 * NECK))[8] = (frame & 1) ? 1.1f : 0.4f;
      *(int*)(F.actor + layout::kOffModelState) = -1;
      CHECK(Core::apply(actor, W2, &t) == 1);
      for (int b = 0; b < NECK; ++b) for (int k = 0; k < 16; ++k)
        if (k % 4 != 3) CHECK(fabs_(F.world[b*16+k] - ref[b*16+k]) < 1e-4);
      // The neck now closes the shirt collar; the head and facial bones still
      // disappear from the first-person view at every look angle.
      for (int k = 0; k < 16; ++k)
        if (k % 4 != 3) CHECK(fabs_(F.world[NECK*16+k] - ref[NECK*16+k]) < 1e-4);
      for (int b = HEAD; b < N; ++b) {
        CHECK(fabs_(F.world[b*16]) < 2e-4);
        CHECK(fabs_(F.world[b*16+13] - ref[HEAD*16+13]) < 2e-3);   // 1.7.213: the head gathers at ONE point, the neck top (the head bone's own place), so the neck skin closes there instead of falling into the chest
        CHECK(fabs_(F.world[b*16+12] - ref[HEAD*16+12]) < 2e-3 && fabs_(F.world[b*16+14] - ref[HEAD*16+14]) < 2e-3);
      }
      CHECK(Core::apply(actor, W2, &t) == 1);
      CHECK(fabs_(F.world[PELVIS*16]) > 0.1);
    }
    ((float*)(F.local + 40 * NECK))[8] = 0.4f;
    t = saved; fresh();
  }
  // 18. 0.72 elbows bend a little away from the body centre; the hand still arrives
  {
    double outDot[2] = {0, 0}, miss[2] = {0, 0};
    for (int pass = 0; pass < 2; ++pass) {
      fresh();
      double H0[3], S[3], Sl[3];
      world_pos(sp, RHAND, H0); world_pos(sp, RUP, S); world_pos(sp, LUP, Sl);
      t.bodyOn = 0; t.rightOn = 1; weight::ident(t.wandR);
      for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
      const double G3[3] = {H0[0] + 0.1, H0[1] - 0.3, H0[2] + 0.45};
      for (int i = 0; i < 3; ++i) t.grip[i] = G3[i];
      t.elbowDown = 1.0; t.elbowOut = pass ? 0.5 : 0.0;
      CHECK(Core::apply(actor, W2, &t) == 1);
      double E[3], H1[3];
      world_pos(sp, RFORE, E); world_pos(sp, RHAND, H1);
      double lat[3] = {S[0] - Sl[0], 0, S[2] - Sl[2]};
      const double ll = sqrt(lat[0] * lat[0] + lat[2] * lat[2]);
      outDot[pass] = ((E[0] - S[0]) * lat[0] + (E[2] - S[2]) * lat[2]) / ll;
      miss[pass] = dist(H1, G3);
    }
    printf("elbow outward offset: %.3f ft without, %.3f ft with the polish; hand misses %.4f / %.4f ft\n", outDot[0], outDot[1], miss[0], miss[1]);
    CHECK(outDot[1] > outDot[0] + 0.02);
    CHECK(miss[1] < 0.01);
  }
  // 1.7.21 the body bends when you look down: the upper back (spine1 -> spine3) tips forward by bendFrac * (pitch - 10 deg), at most bendMaxDeg
  {
    auto spine_tip_deg = [&](double pitchDeg, double frac, double maxDeg) {
      fresh();
      double ax[3] = {1, 0, 0}, R[9];
      weight::axis_angle(ax, pitchDeg * vm::kPi / 180.0, R);
      for (int i = 0; i < 9; ++i) t.hmdBasis[i] = R[i];
      t.bendFrac = frac; t.bendMaxDeg = maxDeg;
      double a0[3], b0[3];
      world_pos(sp, SPINE1, a0); world_pos(sp, SPINE3, b0);
      CHECK(Core::apply(actor, W2, &t) == 1);
      double a1[3], b1[3];
      world_pos(sp, SPINE1, a1); world_pos(sp, SPINE3, b1);
      for (int i = 0; i < N * 16; ++i) CHECK(vm::is_finite_f(F.world[i]));
      double v0[3] = {b0[0] - a0[0], b0[1] - a0[1], b0[2] - a0[2]}, v1[3] = {b1[0] - a1[0], b1[1] - a1[1], b1[2] - a1[2]};
      const double c = (v0[0] * v1[0] + v0[1] * v1[1] + v0[2] * v1[2]) / (arm::len(v0) * arm::len(v1));
      double ang = vm::datan2(vm::dsqrt(1.0 - (c > 1 ? 1 : c) * (c > 1 ? 1 : c)), c) * 180.0 / vm::kPi;
      // forward means the top of the back moved along +z (the head's forward at yaw 0) relative to its waist
      const double fwd = (b1[2] - a1[2]) - (b0[2] - a0[2]);
      return ang * (fwd >= 0 ? 1.0 : -1.0);
    };
    const double off = spine_tip_deg(60.0, 0.0, 55.0), on = spine_tip_deg(60.0, 0.65, 55.0), small = spine_tip_deg(8.0, 0.65, 55.0), cap = spine_tip_deg(85.0, 1.0, 55.0);
    printf("body bend: off %.1f deg, 60 deg look-down at 65%% %.1f deg (want 32.5), 8 deg look-down %.1f (dead zone), 85 deg at 100%% %.1f (capped at 55)\n", off, on, small, cap);
    CHECK(fabs_(off) < 0.3);
    CHECK(on > 30.0 && on < 35.0);
    CHECK(fabs_(small) < 0.3);
    CHECK(cap > 52.0 && cap < 58.0);
  }
  // The bend stays in the body's forward plane while the headset turns aside.
  {
    for (int yawDeg = -135; yawDeg <= 180; yawDeg += 45) {
      fresh();
      double ay[3] = {0, 1, 0}, ax[3] = {1, 0, 0}, Ry[9], Rx[9], R[9];
      weight::axis_angle(ay, yawDeg * vm::kPi / 180.0, Ry);
      weight::axis_angle(ax, 50.0 * vm::kPi / 180.0, Rx);
      weight::mul3(Ry, Rx, R);                                        // some head: yaw about up, then 50 degrees down
      for (int i = 0; i < 9; ++i) t.hmdBasis[i] = R[i];
      t.bendFrac = 0.6; t.bendMaxDeg = 40.0;
      const double fx = R[2], fy = R[5], fz = R[8], hl = vm::dsqrt(fx * fx + fz * fz);
      CHECK(fy < -0.5 && hl > 0.3);                                   // really looking down
      double a0[3], n0[3];
      world_pos(sp, SPINE1, a0); world_pos(sp, NECK, n0);
      CHECK(Core::apply(actor, W2, &t) == 1);
      double a1[3], n1[3];
      world_pos(sp, SPINE1, a1); world_pos(sp, NECK, n1);
      const double vf = n1[2] - a1[2], vu = n1[1] - a1[1];
      const double tilt = vm::datan2(vf, vu) * 180.0 / vm::kPi;
      const double vf0 = n0[2] - a0[2], vu0 = n0[1] - a0[1];
      const double tilt0 = vm::datan2(vf0, vu0) * 180.0 / vm::kPi;
      if (yawDeg == -135 || yawDeg == 0 || yawDeg == 90) printf("bend toward body: head yaw %d: tilt %.1f -> %.1f (want 24)\n", yawDeg, tilt0, tilt);
      CHECK(tilt > 23.0 && tilt < 25.5);
    }
    // a body that already leans further than wanted is left alone, and a small look-down does nothing
    fresh();
    double ax[3] = {1, 0, 0}, R[9];
    weight::axis_angle(ax, 8.0 * vm::kPi / 180.0, R);
    for (int i = 0; i < 9; ++i) t.hmdBasis[i] = R[i];
    t.bendFrac = 0.6; t.bendMaxDeg = 40.0;
    CHECK(Core::apply(actor, W2, &t) == 1);
    CHECK(Core::st.lastBendX10 == 0);
  }
  // Reload uses private upper-body locals, preserving the neutral render pose
  // while leaving the game's live animation data untouched.
  {
    fresh(); t.bodyOn = 0; t.itemId = 1;
    t.rightOn = t.origOn = t.rdirOk = t.gripAtHand = 1; t.gunLenFt = 2;
    weight::ident(t.wandR); t.rdir[2] = 1; t.rup[1] = 1;
    double initialHand[3]; world_pos(sp, RHAND, initialHand);
    for (int i = 0; i < 3; ++i) t.grip[i] = t.wandP0[i] = initialHand[i];
    for (int i = 0; i < 16; ++i) t.origBody[i] = W2[i];
    Core::apply(actor, W2, &t);
    float beforeReload[N * 16]; memcpy(beforeReload, F.world, sizeof(beforeReload));
    float* spineLocal = (float*)(F.local + SPINE1 * 40);
    spineLocal[7] += 0.4f; spineLocal[8] += 0.5f;
    uint8_t gameLocals[N * 40]; memcpy(gameLocals, F.local, sizeof(gameLocals));
    t.reloadHold = 1;
    double turnAxis[3] = {0, 1, 0}; weight::axis_angle(turnAxis, 0.6, t.wandR);
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    Core::apply(actor, W2, &t);
    for (int b : {SPINE1, SPINE3, NECK, HEAD}) for (int i = 0; i < 16; ++i) if ((i & 3) != 3)
      CHECK(fabs_(F.world[b * 16 + i] - beforeReload[b * 16 + i]) < 1e-5);
    CHECK(memcmp(gameLocals, F.local, sizeof(gameLocals)) == 0);
    for (int i = 0; i < 16; ++i) if ((i & 3) != 3)
      CHECK(fabs_(F.world[RHAND * 16 + i] - beforeReload[RHAND * 16 + i]) < 1e-4);
    t.reloadHold = 0;
    *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
    Core::apply(actor, W2, &t);
    double releasedDelta = 0;
    for (int i = 12; i <= 14; ++i) releasedDelta += fabs_(F.world[SPINE3 * 16 + i] - beforeReload[SPINE3 * 16 + i]);
    printf("reload release delta %.3f\n", releasedDelta);
    CHECK(releasedDelta > 0.2);
  }
  // 1.7.226: a WEAPON CHANGE is held like a reload: the item id changes (1 -> 2) while the game's switch animation moves the spine, and the pose from before it is still shown.
  // Without switchHold the old behaviour stays (the hold is dropped when the item id changes).
  {
    for (int mode = 0; mode < 2; ++mode) {   // 0: switchHold on, 1: off
      fresh(); t.bodyOn = 0; t.itemId = 1; t.reloadHold = 0; t.switchHold = 0;
      t.rightOn = t.origOn = t.rdirOk = t.gripAtHand = 1; t.gunLenFt = 2;
      weight::ident(t.wandR); t.rdir[2] = 1; t.rup[1] = 1;
      double initialHand[3]; world_pos(sp, RHAND, initialHand);
      for (int i = 0; i < 3; ++i) t.grip[i] = t.wandP0[i] = initialHand[i];
      for (int i = 0; i < 16; ++i) t.origBody[i] = W2[i];
      Core::apply(actor, W2, &t);
      float before[N * 16]; memcpy(before, F.world, sizeof(before));
      float* spineLocal = (float*)(F.local + SPINE1 * 40);
      spineLocal[7] += 0.4f; spineLocal[8] += 0.5f;                    // the game's switch animation moves the spine
      t.itemId = 2; t.reloadHold = 1; t.switchHold = mode == 0;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      Core::apply(actor, W2, &t);
      double d = 0; for (int b : {SPINE1, SPINE3, NECK}) for (int i = 12; i <= 14; ++i) d += fabs_(F.world[b * 16 + i] - before[b * 16 + i]);
      printf("weapon change %s: spine moved %.3f ft\n", mode == 0 ? "held" : "not held", d);
      if (mode == 0) CHECK(d < 1e-4); else CHECK(d > 0.1);
    }
    t.reloadHold = 0; t.switchHold = 0; t.itemId = 1;
  }
  // 1.7.226 STRESS: item changes, reload / switch / alt-fire holds switching on and off in random order with a moving spine and hand: every matrix stays finite and the arm never explodes
  {
    unsigned seed = 12345; auto rnd = [&]() { seed = seed * 1664525u + 1013904223u; return (seed >> 8) & 0xffff; };
    fresh(); t.bodyOn = 0; t.rightOn = t.origOn = t.rdirOk = t.gripAtHand = 1; t.gunLenFt = 2;
    weight::ident(t.wandR); t.rdir[2] = 1; t.rup[1] = 1;
    double h0[3]; world_pos(sp, RHAND, h0);
    for (int i = 0; i < 16; ++i) t.origBody[i] = W2[i];
    static const int items[6] = {1, 2, 3, 7, 5, 4};
    long bad = 0, passes = 0; double worst = 0;
    for (int it = 0; it < 3000; ++it) {
      if (rnd() % 7 == 0) t.itemId = items[rnd() % 6];
      t.reloadHold = (rnd() % 3) == 0; t.switchHold = t.reloadHold && (rnd() % 2);
      for (int i = 0; i < 3; ++i) t.grip[i] = t.wandP0[i] = h0[i] + ((double)(rnd() % 200) - 100.0) / 1000.0;
      float* spineLocal = (float*)(F.local + SPINE1 * 40);
      spineLocal[7] += ((float)(rnd() % 100) - 50.0f) / 500.0f; spineLocal[8] += ((float)(rnd() % 100) - 50.0f) / 500.0f;
      if (spineLocal[7] > 3.0f || spineLocal[7] < -3.0f) spineLocal[7] = 0.0f; if (spineLocal[8] > 3.0f || spineLocal[8] < -3.0f) spineLocal[8] = 0.0f;
      *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1;
      Core::apply(actor, W2, &t); ++passes;
      for (int i = 0; i < N * 16; ++i) if (!(F.world[i] == F.world[i]) || fabs_(F.world[i]) > 1.0e6) { ++bad; break; }
      double hp[3]; world_pos(sp, RHAND, hp); const double dd = vm::dsqrt((hp[0]-t.grip[0])*(hp[0]-t.grip[0]) + (hp[1]-t.grip[1])*(hp[1]-t.grip[1]) + (hp[2]-t.grip[2])*(hp[2]-t.grip[2])); if (dd > worst) worst = dd;
    }
    printf("hold stress: %ld passes, %ld bad matrices, hand at most %.2f ft from the controller\n", passes, bad, worst);
    CHECK(bad == 0);
    t.reloadHold = 0; t.switchHold = 0; t.itemId = 1;
  }
  // 1.7.168 LOOK-DOWN STRESS: every pitch 0..89 deg, 8 headings, body bend on and off, eye heights, with and without the slide back.
  // "Seeing your own body from above" = the neck is AHEAD of your eye (in your heading), or the neck / shoulder tops are inside a 50 deg view cone.
  // The old settings (down_back 0) must show it (the bug, reproduced); the new ones must never, and the body must move smoothly as the head pitches.
  {
    const double kD = vm::kPi / 180.0;
    long oldSeen = 0, newSeen = 0, newAhead = 0, oldAhead = 0, cases = 0, bad = 0; double worstStep = 0, worstNeckFwdNew = -9;
    for (int pass = 0; pass < 2; ++pass)
    for (int hd = 0; hd < 8; ++hd) for (int bend = 0; bend < 2; ++bend) for (int hgt = 0; hgt < 2; ++hgt) {
      const double yaw = hd * 45.0 * kD;
      double prevP[3] = {0, 0, 0}; int havePrev = 0;
      for (int pd = 0; pd <= 89; ++pd) {
        fresh();
        double E0[3]; eye_mid(E0);
        const double p = pd * kD, sy = sin(yaw), cy = cos(yaw), sp_ = sin(p), cp = cos(p);
        // columns: right, up, forward (forward pitched down)
        t.hmdBasis[0] = cy; t.hmdBasis[3] = 0; t.hmdBasis[6] = -sy;
        t.hmdBasis[1] = sy * sp_; t.hmdBasis[4] = cp; t.hmdBasis[7] = cy * sp_;
        t.hmdBasis[2] = sy * cp; t.hmdBasis[5] = -sp_; t.hmdBasis[8] = cy * cp;
        t.eyeOn = 1; t.shiftCapFt = 0.5; t.bodyYaw = yaw;
        t.eyeTarget[0] = E0[0]; t.eyeTarget[1] = E0[1] + (hgt ? -0.3 : 0.0); t.eyeTarget[2] = E0[2];
        t.bodyOutFt = 0.328; t.downBackFt = pass ? 0.394 : 0.0; t.viewDownFt = 0.0;   // body_out 10 cm, down_back 12 cm (new) or 0 (old)
        t.bendFrac = bend ? 0.6 : 0.0; t.bendMaxDeg = 40.0;
        if (Core::apply(actor, W2, &t) != 1) { ++bad; continue; }
        for (int i = 0; i < N * 16; ++i) if (!vm::is_finite_f(F.world[i])) { ++bad; break; }
        ++cases;
        const double look[3] = {sy * cp, -sp_, cy * cp};
        double neck[3], lsh[3], rsh[3], pel[3];
        world_pos(sp, NECK, neck); world_pos(sp, 13, lsh); world_pos(sp, 17, rsh); world_pos(sp, PELVIS, pel);
        const double* eye = t.eyeTarget;
        auto seen = [&](const double* q) { double v[3] = {q[0] - eye[0], q[1] - eye[1], q[2] - eye[2]}; const double l = arm::len(v); if (l < 1e-6) return 1;
          const double c = (v[0] * look[0] + v[1] * look[1] + v[2] * look[2]) / l; return c > cos(50.0 * kD) ? 1 : 0; };
        const double neckFwd = (neck[0] - eye[0]) * sy + (neck[2] - eye[2]) * cy;   // ahead (+) or behind (-) your eye, along your heading
        const int vis = seen(neck) || (pd < 70 && (seen(lsh) || seen(rsh)));   // looking almost straight down, the shoulder edges are in view in real life too
        if (getenv("ARMDBG") && (pd == 86 || pd == 60) && hd == 0 && bend == 1 && hgt == 0) {
          double up_[3], el[3]; world_pos(sp, 18, up_); world_pos(sp, 19, el);
          auto ang = [&](const double* q) { double v[3] = {q[0] - eye[0], q[1] - eye[1], q[2] - eye[2]}; const double l = arm::len(v); return acos((v[0] * look[0] + v[1] * look[1] + v[2] * look[2]) / l) * 57.29578; };
          printf("  pass %d pitch %d: angle from your look: neck %.0f, clavicle %.0f, upper arm root %.0f, elbow %.0f deg (in view under 50)\n", pass, pd, ang(neck), ang(lsh), ang(up_), ang(el));
        }
        if (pd >= 45) {
          if (pass && vis && getenv("LOOKDBG")) printf("  seen: pitch %d head %d bend %d hgt %d neck %d lsh %d rsh %d neckFwd %.2f\n", pd, hd, bend, hgt, seen(neck), seen(lsh), seen(rsh), neckFwd);
          if (pass) { if (vis) ++newSeen; if (neckFwd > 0.0) ++newAhead; if (neckFwd > worstNeckFwdNew) worstNeckFwdNew = neckFwd; }
          else { if (vis) ++oldSeen; if (neckFwd > 0.0) ++oldAhead; }
        }
        if (pass && havePrev) { const double st2 = dist(pel, prevP); if (st2 > worstStep) worstStep = st2; }
        for (int i = 0; i < 3; ++i) prevP[i] = pel[i]; havePrev = 1;
      }
    }
    printf("LOOKDOWN STRESS: %ld poses (0-89 deg down, 8 headings, bend on/off, 2 eye heights). Looking 45+ deg down: OLD neck/shoulder tops in view %ld, neck ahead of the eye %ld | NEW in view %ld, ahead %ld (neck at most %.2f ft along your heading) | body step per degree at most %.3f ft | broken %ld\n",
           cases, oldSeen, oldAhead, newSeen, newAhead, worstNeckFwdNew, worstStep, bad);
    CHECK(bad == 0);
    CHECK(oldAhead > 0 || oldSeen > 0);   // the bug is reproduced with the old settings
    CHECK(newSeen == 0 && newAhead == 0); // and gone with the new
    CHECK(worstStep < 0.05);              // no jump while the head pitches (under 1.5 cm per degree of head pitch)
    for (int i = 0; i < 9; ++i) t.hmdBasis[i] = 0; t.eyeOn = 0; t.bodyYaw = 0; t.downBackFt = 0; t.bodyOutFt = 0; t.bendFrac = 0;
  }
  if (!fails) printf("PASS fullbody\n");
  return fails ? 1 : 0;
}
