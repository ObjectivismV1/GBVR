#include <stdio.h>
#include <math.h>
#include <string.h>
#include "gearmath.h"
#include "padmath.h"
#include "handmath.h"
using namespace gear;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

int main() {
  // ---- the wheel slots follow the stick, slot 0 at the top, clockwise
  CHECK(slot_from_stick(0.0, 1.0, kSlots, 0.5) == 0);
  CHECK(slot_from_stick(1.0, 0.0, kSlots, 0.5) == 1);   // right: slot 1.25 of 5 (1.7: five slots)
  CHECK(slot_from_stick(0.0, -1.0, kSlots, 0.5) == 2 || slot_from_stick(0.0, -1.0, kSlots, 0.5) == 3);   // straight down sits on the edge between 2 and 3
  CHECK(slot_from_stick(-1.0, 0.0, kSlots, 0.5) == 4);
  CHECK(slot_from_stick(-0.05, 1.0, kSlots, 0.5) == 0);        // a hair to the left of the top is still the top slot
  CHECK(slot_from_stick(0.1, 0.1, kSlots, 0.5) == -1);         // a small push picks nothing
  for (int i = 0; i < kSlots; ++i) {                           // every slot can be reached
    double a = i * 2.0 * 3.14159265358979 / kSlots;
    CHECK(slot_from_stick(sin(a), cos(a), kSlots, 0.5) == i);
  }
  // ---- usable slots, locked ("?") and switched-off slots
  { int st[kItemCount] = {0, 1, 0, 2, 3, 1, 0, 1};
    CHECK(slot_usable(0, st));            // proton, owned
    CHECK(!slot_usable(1, st));           // meson (item 2) not owned
    CHECK(slot_usable(2, st));            // boson (item 3) in hand
    CHECK(!slot_usable(5, st));           // 0.84: the trap is not on the wheel any more; 1.7: no sixth slot either
    CHECK(slot_usable(3, st) && slot_usable(4, st));   // slime (slot 3) and PKE (slot 4) owned; 1.7: BEAM SWITCH is gone from the wheel
    CHECK(slot_usable(1, nullptr));       // unknown state: allowed
    CHECK(!slot_usable(-1, st) && !slot_usable(kSlots, st));
    CHECK(slot_status(1, st) == kLocked);           // meson: never given by the campaign yet -> "?"
    CHECK(slot_status(4, st) == kOk && slot_status(5, st) == kLocked);   // PKE ok; no sixth slot
    CHECK(kSlots == 5);                              // 0.83: Light, Next, Previous removed; 0.84: the Trap too; 1.7: BEAM SWITCH too (it did nothing)
    CHECK(slot_status(0, st) == kOk && slot_status(2, st) == kOk);
    CHECK(slot_status(1, nullptr) == kOk);           // inventory unknown: nothing is shown locked
    const unsigned lm = locked_mask(st), um = unusable_mask(st);
    CHECK(((lm >> 1) & 1) && !((lm >> 4) & 1) && !((lm >> 0) & 1));
    CHECK(((um >> 1) & 1) && !((um >> 4) & 1) && !((um >> 2) & 1));
    CHECK(locked_mask(nullptr) == 0 && unusable_mask(nullptr) == 0); }
  // ---- the wheel state machine (0.78: opened by a claimed button; stick or hand picks; release chooses)
  { Wheel w; memset(&w, 0, sizeof(w)); w.reset();
    int slot = -9, hc = 0;
    CHECK(w.update(0, 0, 0, 0, 0, 11, kSlots, 0, &slot, &hc) == 0 && !w.active());
    CHECK(w.update(1, 0, 0, 0, 0, 11, kSlots, 0, &slot, &hc) == 1 && w.open);             // opens at once when the button is claimed
    CHECK(w.sel == -1);
    for (int i = 0; i < 5; ++i) w.update(1, 0.0, 1.0, 0, 0, 11, kSlots, 0, &slot, &hc);
    CHECK(w.sel == 0 && w.src == 1);
    for (int i = 0; i < 5; ++i) w.update(1, 0.4, 0.0, 0, 0, 11, kSlots, 0, &slot, &hc);
    CHECK(w.sel == 0);                                                                       // a half push keeps the old pick (hysteresis)
    int changed = 0;
    for (int i = 0; i < 5; ++i) { w.update(1, sin(4 * 2 * 3.14159265358979 / 5.0), cos(4 * 2 * 3.14159265358979 / 5.0), 0, 0, 11, kSlots, 0, &slot, &hc); changed += hc; }
    CHECK(w.sel == 4 && changed == 1);                                                      // exactly one hover change for the tick
    for (int i = 0; i < 20; ++i) w.update(1, sin(4 * 2 * 3.14159265358979 / 5.0), cos(4 * 2 * 3.14159265358979 / 5.0), 0, 0, 11, kSlots, 0, &slot, &hc);
    CHECK(w.hov[4] > 0.9 && w.hov[0] < 0.1 && w.openT == 1.0);                              // smooth: the lit disc eased up, the open animation finished
    int ev = w.update(0, 0, 0, 0, 0, 11, kSlots, 0, &slot, &hc);
    CHECK(ev == 2 && slot == 4 && !w.open && w.picked == 4 && w.flash > 0.9);              // letting go chooses; the wheel is still closing
    CHECK(w.active() && w.openT < 1.0);
    for (int i = 0; i < 40; ++i) w.update(0, 0, 0, 0, 0, 11, kSlots, 0, &slot, &hc);
    CHECK(!w.active() && w.picked == -1 && w.sel == -1);                                     // fully closed after ~0.14 s
    w.update(1, 0, 0, 0, 0, 11, kSlots, 0, &slot, &hc);
    for (int i = 0; i < 30; ++i) w.update(1, 0, 0, 0, 0, 11, kSlots, 0, &slot, &hc);
    ev = w.update(0, 0, 0, 0, 0, 11, kSlots, 0, &slot, &hc);
    CHECK(ev == 3);                                                                          // nothing lit: cancelled
    CHECK(w.opens == 2 && w.chosen == 1 && w.cancelled == 1);
    // a locked disc refuses (event 4), an unlocked one does not
    Wheel l; memset(&l, 0, sizeof(l)); l.reset();
    const unsigned mask = 1u << 1;
    l.update(1, 0, 0, 0, 0, 11, kSlots, mask, &slot, &hc);
    for (int i = 0; i < 5; ++i) l.update(1, sin(1 * 2 * 3.14159265358979 / 5.0), cos(1 * 2 * 3.14159265358979 / 5.0), 0, 0, 11, kSlots, mask, &slot, &hc);
    CHECK(l.sel == 1);
    CHECK(l.update(0, 0, 0, 0, 0, 11, kSlots, mask, &slot, &hc) == 4 && slot == 1 && l.pickLocked && l.lockedPicks == 1 && l.chosen == 0);
    // the hand picks when the stick rests: 8 cm toward the right
    Wheel h; memset(&h, 0, sizeof(h)); h.reset();
    h.update(1, 0, 0, 0, 0, 11, kSlots, 0, &slot, &hc);
    h.update(1, 0, 0, 0.02, 0.0, 11, kSlots, 0, &slot, &hc);
    CHECK(h.sel == -1);                                                                      // 2 cm: inside the dead zone
    h.update(1, 0, 0, 0.08, 0.0, 11, kSlots, 0, &slot, &hc);
    CHECK((h.sel == 1 || h.sel == 2) && h.src == 2 && hc == 1);
    h.update(1, 0, 0, 0.04, 0.0, 11, kSlots, 0, &slot, &hc);
    CHECK(h.sel >= 0);                                                                       // between 3.5 and 5 cm: keeps the pick
    h.update(1, 0, 0, 0.01, 0.0, 11, kSlots, 0, &slot, &hc);
    CHECK(h.sel == -1);                                                                      // back near the middle: nothing lit
    // the stick overrides the hand
    h.update(1, 0, 0, 0.08, 0.0, 11, kSlots, 0, &slot, &hc);
    h.update(1, 0.0, 1.0, 0.08, 0.0, 11, kSlots, 0, &slot, &hc);
    CHECK(h.sel == 0 && h.src == 1); }
  // ---- one button, two jobs: a quick tap goes to the game, a hold is claimed
  { TapHold t; memset(&t, 0, sizeof(t)); t.reset();
    int g = 0, ev = 0, seenGame = 0, claimed = 0;
    // quick tap of 60 ms: nothing reaches the game while it is down; a press of at least 90 ms is replayed afterwards
    for (int i = 0; i < 6; ++i) { ev = t.update(1, 1, 10, 200, 90, &g); CHECK(g == 0 && ev == 0); }
    ev = t.update(0, 1, 10, 200, 90, &g);
    CHECK(ev == 2 && g == 1 && t.taps == 1);
    int replay = 1;
    for (int i = 0; i < 20; ++i) { t.update(0, 1, 10, 200, 90, &g); replay += g; }
    CHECK(replay >= 8 && replay <= 11);                                                       // ~90 ms of press, in 10 ms polls
    // a hold of 0.3 s: claimed at 0.2 s, never seen by the game, claimed release at the end
    TapHold h; memset(&h, 0, sizeof(h)); h.reset();
    for (int i = 0; i < 30; ++i) { ev = h.update(1, 1, 10, 200, 90, &g); seenGame |= g; if (ev == 1) { claimed = i; CHECK(h.state == 2); } }
    CHECK(!seenGame && claimed >= 18 && claimed <= 21);
    CHECK(h.update(0, 1, 10, 200, 90, &g) == 3 && g == 0 && h.state == 0);
    for (int i = 0; i < 10; ++i) { h.update(0, 1, 10, 200, 90, &g); CHECK(g == 0); }         // a hold is never replayed as a tap
    // not allowed at the press (menu open, not in a level, feature off): the button goes straight through, with no delay
    TapHold p; memset(&p, 0, sizeof(p)); p.reset();
    CHECK(p.update(1, 0, 10, 200, 90, &g) == 0 && g == 1);
    for (int i = 0; i < 40; ++i) { p.update(1, 0, 10, 200, 90, &g); CHECK(g == 1); }
    p.update(0, 0, 10, 200, 90, &g);
    CHECK(g == 0 && p.state == 0);
    // allowed at the press but switched off while undecided: the game gets it from then on
    TapHold q; memset(&q, 0, sizeof(q)); q.reset();
    q.update(1, 1, 10, 200, 90, &g); CHECK(g == 0);
    q.update(1, 0, 10, 200, 90, &g); CHECK(g == 1 && q.state == 3);
    // an A held for the game (revive-like) before the feature was allowed is not stolen: pressed while not allowed, then allowed
    TapHold r; memset(&r, 0, sizeof(r)); r.reset();
    r.update(1, 0, 10, 200, 90, &g);
    for (int i = 0; i < 40; ++i) { ev = r.update(1, 1, 10, 200, 90, &g); CHECK(ev != 1 && g == 1); }
    // two quick taps in a row both reach the game
    TapHold d; memset(&d, 0, sizeof(d)); d.reset();
    for (int n = 0; n < 2; ++n) { for (int i = 0; i < 8; ++i) d.update(1, 1, 10, 200, 90, &g); d.update(0, 1, 10, 200, 90, &g); for (int i = 0; i < 12; ++i) d.update(0, 1, 10, 200, 90, &g); }
    CHECK(d.taps == 2); }
  // ---- where the wheel stands
  { float head[12] = {1, 0, 0, 0, 0, 1, 0, 1.6f, 0, 0, 1, 0};     // looking along -z
    const double hand1[3] = {0.25, 1.2, -0.35};                     // right hand, a bit low, in front
    float pose[12];
    CHECK(wheel_anchor(head, hand1, pose));
    CHECK(pose[11] < -0.4 && pose[11] > -0.75);                       // in front of the head, 0.42..0.70 m
    CHECK(pose[3] > 0.1 && pose[3] <= 0.30 + 1e-6);                   // to the right
    CHECK(pose[7] < 1.6f && pose[7] >= 1.6f - 0.28f - 1e-6f);        // not above the eyes by more than 10 cm, not lower than 28 cm
    // z toward the viewer: from the wheel back to the head
    const double zx = pose[2], zy = pose[6], zz = pose[10];
    CHECK(fabs(zx * zx + zy * zy + zz * zz - 1.0) < 1e-4 && zz > 0.6 && zy > 0.0);   // faces the head: back toward it and a little up (the wheel is below the eyes)
    float m9[9] = {pose[0], pose[1], pose[2], pose[4], pose[5], pose[6], pose[8], pose[9], pose[10]};
    CHECK(vm::is_rotation(m9, 1e-3));
    CHECK(fabs(pose[4] * 0 + pose[0] * pose[0] + pose[8] * pose[8] - 1.0) < 1e-3);   // the x axis is level (horizontal) so the wheel stands upright
    // a hand far behind / far left / far above is pulled into the box
    const double hand2[3] = {-1.5, 3.0, 2.0};
    CHECK(wheel_anchor(head, hand2, pose));
    CHECK(pose[11] < -0.4 && pose[3] >= -0.30 - 1e-6 && pose[7] <= 1.6f + 0.10f + 1e-6f);
    // hand offset in the wheel's plane
    const double origin[3] = {0.25, 1.2, -0.35};
    float pz[12]; wheel_anchor(head, origin, pz);
    double hx, hy;
    { const double mv[3] = {origin[0] + 0.06 * pz[0], origin[1] + 0.06 * pz[4], origin[2] + 0.06 * pz[8]};    // along the wheel's own x axis
      wheel_hand_offset(pz, origin, mv, &hx, &hy); CHECK(fabs(hx - 0.06) < 1e-4 && fabs(hy) < 1e-4); }
    { const double mv[3] = {origin[0] + 0.05 * pz[1], origin[1] + 0.05 * pz[5], origin[2] + 0.05 * pz[9]};    // along its y axis
      wheel_hand_offset(pz, origin, mv, &hx, &hy); CHECK(fabs(hx) < 1e-4 && fabs(hy - 0.05) < 1e-4); }
    { const double mv[3] = {origin[0] + 0.10 * pz[2], origin[1] + 0.10 * pz[6], origin[2] + 0.10 * pz[10]};   // toward the player: does not count
      wheel_hand_offset(pz, origin, mv, &hx, &hy); CHECK(fabs(hx) < 1e-4 && fabs(hy) < 1e-4); }
    { const double mv[3] = {origin[0], origin[1] + 0.05, origin[2]};                                           // straight up in the world: mostly "up" in the wheel
      wheel_hand_offset(pz, origin, mv, &hx, &hy); CHECK(hy > 0.035 && hy < 0.05 && fabs(hx) < 1e-4); }
    const double bad[3] = {0, 0, 0}; float head0[12] = {1, 0, 0, 0, 0, 0, -1, 1.6f, 0, 1, 0, 0};   // looking straight down: no yaw
    CHECK(!wheel_anchor(head0, bad, pose)); }
  // ---- the trap
  { Trap t; memset(&t, 0, sizeof(t)); t.reset();
    double dir[3] = {0, 0, 0}, spd = 0;
    double pos[3] = {-0.22, -0.55, 0.0};
    int ev = 0;
    t.update(0.011, 0, 1, 0.0, pos, 1.6, dir, &spd);
    CHECK(t.update(0.011, 1, 1, 0.0, pos, 1.6, dir, &spd) == 1 && t.held);       // X pressed in the zone: grabbed
    // swing forward fast
    ev = 0;
    for (int i = 0; i < 40 && !ev; ++i) {
      pos[2] += 3.0 * 0.011;                                                      // 3 m/s forward
      pos[0] += 0.4 * 0.011;
      const double zd = sqrt((pos[0] + 0.22) * (pos[0] + 0.22) + (pos[1] + 0.55) * (pos[1] + 0.55) + pos[2] * pos[2]);
      ev = t.update(0.011, 1, 0, zd, pos, 1.6, dir, &spd);
    }
    CHECK(ev == 0 && t.held);                                                     // 0.91: holding the button never throws, however fast the hand goes
    { pos[2] += 3.0 * 0.011; pos[0] += 0.4 * 0.011;
      const double zd = sqrt((pos[0] + 0.22) * (pos[0] + 0.22) + (pos[1] + 0.55) * (pos[1] + 0.55) + pos[2] * pos[2]);
      ev = t.update(0.011, 0, 0, zd, pos, 1.6, dir, &spd); }                       // let go with force: the throw
    CHECK(ev == 2 && !t.held);
    CHECK(dir[2] > 0.8);                                                          // thrown forward
    CHECK(spd > 1.6);
    // right after a throw there is no new grab
    CHECK(t.update(0.011, 1, 1, 0.0, pos, 1.6, dir, &spd) == 0);
    // 1.7.19: a swing to the right-forward that then drifts DOWN in the last two samples (the hand slowing as the button comes up) still throws along the swing
    { Trap w; memset(&w, 0, sizeof(w)); w.reset();
      double pw[3] = {-0.22, -0.55, 0.0}, dw[3] = {0, 0, 0}, sw = 0;
      w.update(0.011, 0, 1, 0, pw, 1.1, dw, &sw);
      CHECK(w.update(0.011, 1, 1, 0, pw, 1.1, dw, &sw) == 1);
      for (int i = 0; i < 18; ++i) { pw[0] += 2.0 * 0.011; pw[2] += 2.0 * 0.011; const double zd = sqrt((pw[0] + 0.22) * (pw[0] + 0.22) + (pw[1] + 0.55) * (pw[1] + 0.55) + pw[2] * pw[2]); w.update(0.011, 1, 0, zd, pw, 1.1, dw, &sw); }
      int ev2 = 0;
      for (int i = 0; i < 3 && !ev2; ++i) { pw[1] -= 1.5 * 0.011; const double zd = sqrt((pw[0] + 0.22) * (pw[0] + 0.22) + (pw[1] + 0.55) * (pw[1] + 0.55) + pw[2] * pw[2]); ev2 = w.update(0.011, i == 2 ? 0 : 1, 0, zd, pw, 1.1, dw, &sw); }
      CHECK(ev2 == 2);
      CHECK(dw[0] > 0.45 && dw[2] > 0.45 && dw[1] > -0.5);                       // along the swing (right and forward), not pulled down by the last drift
      CHECK(w.swingDirDeg > 5.0);                                                // the plain release velocity pointed somewhere else: the swing won
      CHECK(sw > 1.1); }
    // a gentle lob (1.2 m/s) throws now
    { Trap g; memset(&g, 0, sizeof(g)); g.reset();
      double pg[3] = {-0.22, -0.55, 0.0}, dg[3] = {0, 0, 0}, sg = 0;
      g.update(0.011, 0, 1, 0, pg, 1.1, dg, &sg); g.update(0.011, 1, 1, 0, pg, 1.1, dg, &sg);
      int evg = 0;
      for (int i = 0; i < 80 && !evg; ++i) { pg[2] += 1.3 * 0.011; const double zd = sqrt((pg[0] + 0.22) * (pg[0] + 0.22) + (pg[1] + 0.55) * (pg[1] + 0.55) + pg[2] * pg[2]); evg = g.update(0.011, i < 70 ? 1 : 0, 0, zd, pg, 1.1, dg, &sg); }
      CHECK(evg == 2 && dg[2] > 0.9); }
    // grab, then let go at the hip: put back
    Trap u; memset(&u, 0, sizeof(u)); u.reset();
    double p2[3] = {-0.22, -0.55, 0.0};
    u.update(0.011, 0, 1, 0, p2, 1.6, dir, &spd);
    CHECK(u.update(0.011, 1, 1, 0, p2, 1.6, dir, &spd) == 1);
    CHECK(u.update(0.011, 0, 1, 0, p2, 1.6, dir, &spd) == 3 && !u.held && u.putbacks == 1);
    CHECK(u.tapLike == 1);                                                                 // a quick still tap: the caller replays X (the game's own deploy)
    Trap v2; memset(&v2, 0, sizeof(v2)); v2.reset();
    v2.update(0.011, 0, 1, 0, p2, 1.6, dir, &spd);
    v2.update(0.011, 1, 1, 0, p2, 1.6, dir, &spd);
    for (int i = 0; i < 60; ++i) v2.update(0.011, 1, 1, 0, p2, 1.6, dir, &spd);            // held for 0.66 s
    CHECK(v2.update(0.011, 0, 1, 0, p2, 1.6, dir, &spd) == 3 && v2.tapLike == 0);         // a long hold put back is not a tap
    // grabbing outside the hip zone does nothing
    Trap z; memset(&z, 0, sizeof(z)); z.reset();
    double p3[3] = {0.1, 0.0, 0.3};
    z.update(0.011, 0, 0, 0.7, p3, 1.6, dir, &spd);
    CHECK(z.update(0.011, 1, 0, 0.7, p3, 1.6, dir, &spd) == 0 && !z.held);
    // fast jiggle at the hip while held does not throw (not armed: never left the zone)
    Trap j; memset(&j, 0, sizeof(j)); j.reset();
    double p4[3] = {-0.22, -0.55, 0.0};
    j.update(0.011, 0, 1, 0, p4, 1.6, dir, &spd);
    j.update(0.011, 1, 1, 0, p4, 1.6, dir, &spd);
    int thrown = 0;
    for (int i = 0; i < 60; ++i) { p4[2] += (i % 2 ? 0.05 : -0.05); thrown |= (j.update(0.011, 1, 1, 0.1, p4, 1.6, dir, &spd) == 2); }
    CHECK(!thrown); }
  // ---- the sweep slam: any direction, only with the capture stream held
  { const double right[3] = {1, 0, 0}, up[3] = {0, 1, 0};
    double sx, sy;
    struct { double dx, dy, dz; } dirs[] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0.7, -0.7, 0}, {0, 0, 1}};
    for (auto& d : dirs) {
      Sweep s; memset(&s, 0, sizeof(s)); s.reset();
      double p[3] = {0, 0, 0.3};
      int pressed = 0; double fx = 0, fy = 0;
      for (int i = 0; i < 40; ++i) {
        p[0] += d.dx * 3.0 * 0.011; p[1] += d.dy * 3.0 * 0.011; p[2] += d.dz * 3.0 * 0.011;
        pressed |= s.update(0.011, p, 1, 2.2, right, up, &sx, &sy);
        if (sx != 0 || sy != 0) { fx = sx; fy = sy; }
      }
      CHECK(pressed);
      CHECK(s.sweeps == 1);
      if (d.dz == 0) { CHECK(fabs(fx - d.dx / sqrt(d.dx * d.dx + d.dy * d.dy)) < 0.05); CHECK(fabs(fy - d.dy / sqrt(d.dx * d.dx + d.dy * d.dy)) < 0.05); }
      else CHECK(fx == 0 && fy == 0);                    // straight at / away from the face: fire only, no flick
    }
    Sweep n; memset(&n, 0, sizeof(n)); n.reset();
    double p[3] = {0, 0, 0.3}; int any = 0;
    for (int i = 0; i < 40; ++i) { p[0] += 3.0 * 0.011; any |= n.update(0.011, p, 0, 2.2, right, up, &sx, &sy); }   // no capture: never
    CHECK(!any && n.sweeps == 0);
    Sweep m; memset(&m, 0, sizeof(m)); m.reset();
    p[0] = 0; any = 0;
    for (int i = 0; i < 60; ++i) { p[0] += 0.8 * 0.011; any |= m.update(0.011, p, 1, 2.2, right, up, &sx, &sy); }     // slow: never
    CHECK(!any);
    // the fire pulse is about half a second and then stops
    Sweep k; memset(&k, 0, sizeof(k)); k.reset();
    p[0] = 0; int pulses = 0;
    for (int i = 0; i < 20; ++i) { p[0] += 3.0 * 0.011; k.update(0.011, p, 1, 2.2, right, up, &sx, &sy); }
    for (int i = 0; i < 90; ++i) pulses += k.update(0.011, p, 1, 2.2, right, up, &sx, &sy);
    CHECK(pulses > 20 && pulses < 60);
    // no second sweep within the refractory time
    CHECK(k.sweeps == 1); }
  // ---- the font
  CHECK(glyph_for('A') && glyph_for('z') && glyph_for('5') && glyph_for('%') && !glyph_for(' ') && glyph_for('?') && glyph_for('-'));
  CHECK(glyph_for('?')[0] == 7 && glyph_for('?')[4] == 2 && glyph_for('?')[3] == 0);   // the locked disc's "?"
  CHECK(fabs(str_width("AB", 1.0) - 7.0) < 1e-9);
  { static cord::V v[3000]; fight::Buf b = {v, 0, 3000, 0};
    const float col[3] = {1, 1, 1};
    text_str(b, "PROTON", 0, 0, 1.0, 0.01, col, 0);
    CHECK(b.n > 0 && b.n % 6 == 0 && !b.over); }
  // ---- the wheel drawing is bounded, finite, flat (z = 0) and fits the buffer the game uses (9000 vertices)
  { static cord::V v[20000];
    WheelView wv; memset(&wv, 0, sizeof(wv));
    double hv[kSlots]; for (int i = 0; i < kSlots; ++i) hv[i] = 0;
    hv[3] = 1.0;
    wv.openT = 1.0; wv.hov = hv; wv.sel = 3; wv.picked = -1; wv.current = 1; wv.scale = 1.0; wv.curX = 0.4; wv.curY = 0.2;
    int st[kItemCount] = {0, 1, 0, 1, 1, 1, 1, 1};
    wv.state = st;
    int n = build_wheel(wv, v, 20000);
    CHECK(n > 600 && n < 19000 && n % 3 == 0);
    int finite = 1, flat = 1;
    for (int i = 0; i < n; ++i) { for (int k = 0; k < 3; ++k) if (!(v[i].p[k] == v[i].p[k]) || fabsf(v[i].p[k]) > 1.0f) finite = 0; if (v[i].p[2] != 0.0f) flat = 0; }
    CHECK(finite && flat);
    CHECK(build_wheel(wv, v, 100) == -1);                           // too small a buffer is reported, not overrun
    wv.openT = 0.0; CHECK(build_wheel(wv, v, 20000) == 0);           // closed: nothing drawn
    // the worst case (every disc lit text, a name with three lines, a locked pick flashing) still fits
    int allOpen[kItemCount] = {1, 1, 1, 1, 1, 1, 1, 1};
    for (int i = 0; i < kSlots; ++i) hv[i] = 1.0;
    wv.openT = 1.0; wv.state = allOpen; wv.sel = 2; wv.picked = 2; wv.pickLocked = 1; wv.flash = 1.0; wv.current = 2;
    n = build_wheel(wv, v, 20000);
    CHECK(n > 0 && n < 19000);
    // locked discs show a "?" instead of their code: fewer vertices than the same wheel with everything unlocked
    int none[kItemCount] = {0, 0, 0, 0, 0, 0, 0, 0};
    wv.state = none; wv.picked = -1; wv.pickLocked = 0; wv.flash = 0; wv.sel = -1;
    const int nLocked = build_wheel(wv, v, 20000);
    wv.state = allOpen;
    const int nOpen = build_wheel(wv, v, 20000);
    CHECK(nLocked > 0 && nOpen > 0 && nLocked != nOpen);
    // mid-animation sizes are smaller than the final wheel
    wv.openT = 0.5; wv.state = allOpen;
    float maxHalf = 0, maxFull = 0;
    n = build_wheel(wv, v, 20000);
    for (int i = 0; i < n; ++i) maxHalf = fmaxf(maxHalf, fabsf(v[i].p[1]));
    wv.openT = 1.0; n = build_wheel(wv, v, 20000);
    for (int i = 0; i < n; ++i) maxFull = fmaxf(maxFull, fabsf(v[i].p[1]));
    CHECK(maxHalf < maxFull);
    // ---- 1.6: two groups. The body comes first (drawn see-through), then the neon rims / words / cursor (drawn solid)
    { int from = -5;
      wv.openT = 1.0; wv.state = allOpen; wv.sel = 2; wv.picked = -1; wv.pickLocked = 0; wv.flash = 0;
      n = build_wheel(wv, v, 20000, &from);
      CHECK(n > 0 && from > 0 && from < n && from % 3 == 0);
      CHECK((n - from) > 0 && (n - from) % 3 == 0);
      // 1.7.189: the solid group holds the neon rims (a bright cyan-ish colour: blue high) and the steel bezel; no red outline any more
      int neonAfter = 0, redAny = 0;
      for (int i = 0; i < n; ++i) { const float* c = v[i].c; if (i >= from && c[2] > 0.9f && c[0] < 0.9f) ++neonAfter; if (c[0] > 0.7f && c[1] < 0.2f && c[2] < 0.2f) ++redAny; }
      CHECK(neonAfter > 0 && redAny == 0);
      // closed: nothing, and the split is reported as 0
      wv.openT = 0.0; from = -5; CHECK(build_wheel(wv, v, 20000, &from) == 0 && from == 0);
      // too small a buffer is still reported
      wv.openT = 1.0; from = -5; CHECK(build_wheel(wv, v, 100, &from) == -1);
      // a locked weapon in the middle shows "?" (a short mark) and not its long name: fewer solid vertices than the same wheel with that weapon unlocked
      int one[kItemCount] = {1, 1, 1, 1, 1, 1, 1, 1};
      int lockedOne[kItemCount] = {1, 1, 1, 1, 1, 1, 1, 1};
      int selSlot = -1;
      for (int i = 0; i < kSlots; ++i) if (kWheel[i].kind == kKindItem && kWheel[i].arg > 0 && kWheel[i].arg < kItemCount && strlen(kWheel[i].label) > 4) { selSlot = i; break; }
      CHECK(selSlot >= 0);
      if (selSlot >= 0) {
        lockedOne[kWheel[selSlot].arg] = 0;
        wv.sel = selSlot; wv.current = -1; wv.openT = 1.0;
        for (int i = 0; i < kSlots; ++i) hv[i] = 0.0;
        wv.state = one;      int f1 = 0; const int nUnl = build_wheel(wv, v, 20000, &f1);
        wv.state = lockedOne; int f2 = 0; const int nLk = build_wheel(wv, v, 20000, &f2);
        CHECK(nUnl > 0 && nLk > 0 && (nLk - f2) < (nUnl - f1));
      } } }
  // ---- 1.7.189 stress test: the wheel opens, closes and changes its lit disc smoothly (no pops), always inside its buffer, always finite
  { static cord::V v[20000];
    unsigned seed = 12345u;
    auto rnd = [&]() { seed = seed * 1664525u + 1013904223u; return (double)(seed >> 8) / 16777216.0; };
    auto area = [&](int n, int from, int solid) {   // total triangle area of the see-through body (solid 0) or of the solid group (solid 1)
      double a = 0; const int s0 = solid ? from : 0, s1 = solid ? n : from;
      for (int i = s0; i + 2 < s1 + 0 && i + 2 < n; i += 3) {
        const double ax = v[i + 1].p[0] - v[i].p[0], ay = v[i + 1].p[1] - v[i].p[1], bx = v[i + 2].p[0] - v[i].p[0], by = v[i + 2].p[1] - v[i].p[1];
        a += 0.5 * fabs(ax * by - ay * bx);
      }
      return a; };
    int st[kItemCount] = {0, 1, 1, 1, 1, 1, 1, 1};
    double hv[kSlots] = {0, 0, 0, 0, 0};
    WheelView wv; memset(&wv, 0, sizeof(wv));
    wv.hov = hv; wv.sel = 2; wv.picked = -1; wv.current = 1; wv.scale = 1.0; wv.state = st; wv.curX = 0.2; wv.curY = -0.3;
    // opening and closing: sweep openT in 1000 steps; the ink may only change a little per step
    double prev[2] = {-1, -1}, maxJump[2] = {0, 0}, maxArea[2] = {0, 0}; int worstN = 0, bad = 0;
    double areas[2][1001];
    for (int k = 0; k <= 1000; ++k) {
      wv.openT = k / 1000.0; hv[2] = 1.0;
      int from = 0; const int n = build_wheel(wv, v, 20000, &from);
      if (n < 0) { ++bad; continue; }
      if (n > worstN) worstN = n;
      for (int i = 0; i < n; ++i) for (int q = 0; q < 3; ++q) if (!(v[i].p[q] == v[i].p[q]) || fabsf(v[i].p[q]) > 0.5f) ++bad;
      for (int s = 0; s < 2; ++s) { areas[s][k] = area(n, from, s); if (areas[s][k] > maxArea[s]) maxArea[s] = areas[s][k]; }
    }
    for (int s = 0; s < 2; ++s) for (int k = 1; k <= 1000; ++k) { const double j = fabs(areas[s][k] - areas[s][k - 1]); if (j > maxJump[s]) maxJump[s] = j; }
    (void)prev;
    CHECK(bad == 0 && worstN < 19000);
    CHECK(maxJump[0] < 0.02 * maxArea[0] && maxJump[1] < 0.02 * maxArea[1]);   // 1 / 1000 of the opening changes the picture by under 2 %
    // the lit disc changes: hover 0 -> 1 in 500 steps on a fully open wheel; no step moves any colour by more than 6 %
    wv.openT = 1.0; double worstColour = 0, worstArea = 0, a0 = 0;
    static cord::V v2[20000];
    int n2 = 0;
    for (int k = 0; k <= 500; ++k) {
      hv[2] = k / 500.0; hv[3] = 1.0 - hv[2];
      int from = 0; const int n = build_wheel(wv, v, 20000, &from);
      if (k > 0 && n == n2) { for (int i = 0; i < n; ++i) for (int q = 0; q < 3; ++q) { const double d = fabs((double)v[i].c[q] - v2[i].c[q]); if (d > worstColour) worstColour = d; } }
      const double a = area(n, from, 1); if (k > 0 && fabs(a - a0) > worstArea) worstArea = fabs(a - a0);
      a0 = a; n2 = n; memcpy(v2, v, sizeof(cord::V) * (size_t)n);
    }
    CHECK(worstColour < 0.06);
    CHECK(worstArea < 0.02 * a0);
    // random mixes of everything, a thousand times: never out of the buffer, never not a number
    int fails = 0;
    for (int t = 0; t < 1000; ++t) {
      wv.openT = rnd(); for (int i = 0; i < kSlots; ++i) hv[i] = rnd();
      for (int i = 0; i < kItemCount; ++i) st[i] = (int)(rnd() * 4.0);
      wv.sel = (int)(rnd() * 6.0) - 1; wv.picked = (int)(rnd() * 6.0) - 1; wv.pickLocked = rnd() > 0.5; wv.flash = rnd(); wv.current = (int)(rnd() * 9.0) - 1;
      wv.curX = rnd() * 2 - 1; wv.curY = rnd() * 2 - 1; wv.scale = 0.5 + rnd() * 1.5;
      int from = 0; const int n = build_wheel(wv, v, 20000, &from);
      if (n < 0 || n > 20000 || n % 3 != 0 || from < 0 || from > n) { ++fails; continue; }
      for (int i = 0; i < n; ++i) for (int q = 0; q < 3; ++q) if (!(v[i].p[q] == v[i].p[q]) || fabsf(v[i].p[q]) > 1.0f) ++fails;
      for (int i = 0; i < n; ++i) for (int q = 0; q < 4; ++q) if (!(v[i].c[q] == v[i].c[q]) || v[i].c[q] < 0.0f || v[i].c[q] > 1.0f) ++fails;
    }
    CHECK(fails == 0);
    // every letter and digit the wheel can show has a stroke shape
    const char* all = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789%?-";
    int missing = 0; for (const char* c = all; *c; ++c) if (!stroke_for(*c)) ++missing;
    CHECK(missing == 0 && !stroke_for(' '));
  }
  // ---- 1.7.57: left trigger is always the game's LT / alternate fire; current layout puts Capture on the right stick click
  { pad::Hand l = {}, r = {};
    l.valid = r.valid = 1;
    pad::Config c = {18, 0, 1, 0, 1};
    l.trigger = 0.8f;
    pad::State s = pad::build(l, r, c);
    CHECK(!(s.buttons & pad::kLeftShoulder) && s.lt > 200);
    l.trigger = 0.0f; r.pressed = 1ull << pad::kVrStick;
    s = pad::build(l, r, c);
    CHECK((s.buttons & pad::kLeftShoulder) && s.lt == 0);
    l.trigger = 0.8f;
    s = pad::build(l, r, c);
    CHECK((s.buttons & pad::kLeftShoulder) && s.lt > 200);            // Capture + Alt Fire can coexist (slam / weapon alt)
    pad::Config old = {18, 0, 1, 0, 0};
    r.pressed = 0; l.trigger = 0.8f; l.pressed = 0;
    s = pad::build(l, r, old);
    CHECK(!(s.buttons & pad::kLeftShoulder) && s.lt > 200);
    l.trigger = 0.0f; l.pressed = 1ull << pad::kVrStick;
    s = pad::build(l, r, old);
    CHECK((s.buttons & pad::kLeftShoulder) != 0); }
  // ---- two-hand pose: the nose is tilted up by the pitch and the free hand must be within the limit
  { float R[12] = {1, 0, 0, 0, 0, 1, 0, 1.0f, 0, 0, 1, 0}, L[12] = {1, 0, 0, 0, 0, 1, 0, 1.0f, 0, 0, 1, -0.3f};   // left hand 0.3 m in front (OpenVR: -z)
    float out0[12], out7[12];
    CHECK(hand::two_hand_pose_ex(R, L, 0.12, 0.45, 0.0, out0));
    CHECK(hand::two_hand_pose_ex(R, L, 0.12, 0.45, 7.0, out7));
    CHECK(fabsf(out0[10] - 1.0f) < 1e-5f);                             // forward is -z, so the z column of the pose is +1... (back)
    // forward vector = -column 2
    const double f0y = -out0[6], f7y = -out7[6];
    CHECK(fabs(f0y) < 1e-6);
    CHECK(f7y > 0.12 && f7y < 0.125);                                  // sin(7 deg) = 0.1219: nose up
    CHECK(!hand::two_hand_pose_ex(R, L, 0.12, 0.25, 0.0, out0));      // farther than the limit: not a two-hand hold
    float far[12] = {1, 0, 0, 0, 0, 1, 0, 1.0f, 0, 0, 1, -0.6f};
    CHECK(!hand::two_hand_pose_ex(R, far, 0.12, 0.45, 0.0, out0));
    CHECK(hand::two_hand_pose(R, far, 0.12, out0));                    // the old call keeps its 0.8 m limit
    { float m9[9] = {out7[0], out7[1], out7[2], out7[4], out7[5], out7[6], out7[8], out7[9], out7[10]}; CHECK(vm::is_rotation(m9, 1e-3)); } }
  // ---- 1.7.111: sliding the support hand along a barrel it holds from below must not move the muzzle (the tilt follows the distance)
  { const double h = 0.049;                                           // the hand sits 4.9 cm under the barrel line
    float R[12] = {1, 0, 0, 0, 0, 1, 0, 1.0f, 0, 0, 1, 0};
    double minF = 9, maxF = -9, minO = 9, maxO = -9;
    for (int i = 0; i <= 8; ++i) {
      const double d = 0.20 + 0.04 * i;                               // 20..52 cm along the barrel
      float L[12] = {1, 0, 0, 0, 0, 1, 0, (float)(1.0 - h), 0, 0, 1, (float)-d};
      L[7] = 1.0f - (float)h;
      // true barrel: from the rear hand level (up by h at the rear end) - emulate with the hand below the axis by h at the front, and the rear grip on the axis
      float o[12], o2[12];
      CHECK(hand::two_hand_pose_ref(R, L, 0.12, 0.8, 7.0, 0.40, o));
      CHECK(hand::two_hand_pose_ex(R, L, 0.12, 0.8, 7.0, o2));
      const double fy = -o[6], fy2 = -o2[6];
      if (fy < minF) minF = fy; if (fy > maxF) maxF = fy;
      if (fy2 < minO) minO = fy2; if (fy2 > maxO) maxO = fy2;
      if (i == 5) CHECK(fabs(fy) < 0.01);                                // at the reference distance (40 cm) the 7 deg tilt cancels the 4.9 cm drop exactly
      CHECK(fabs(fy) < 0.06);                                          // and everywhere along the barrel the muzzle stays near level
    }
    // the muzzle direction in the world = hand line + tilt; with the new tilt the spread is far smaller than with the fixed tilt
    CHECK((maxF - minF) < 0.5 * (maxO - minO));
    float o3[12]; float Ln[12] = {1, 0, 0, 0, 0, 1, 0, 1.0f, 0, 0, 1, -0.2f}, Lf[12] = {1, 0, 0, 0, 0, 1, 0, 1.0f, 0, 0, 1, -0.5f};
    float oa[12], ob[12];
    CHECK(hand::two_hand_pose_ref(R, Ln, 0.12, 0.8, 7.0, 0.40, oa) && hand::two_hand_pose_ref(R, Lf, 0.12, 0.8, 7.0, 0.40, ob));
    CHECK(-oa[6] > -ob[6] + 0.05);                                      // a near hand tilts more than a far one
    CHECK(hand::two_hand_pose_ref(R, Ln, 0.12, 0.8, 7.0, 0.0, o3) && fabs(-o3[6] - 0.1219) < 0.002);   // ref 0 = the old fixed tilt
  }
  // ---- 1.7: the direction of the pull and the slam on the left trigger
  { PullDir pd; pd.reset();
    const double right[3] = {1, 0, 0}, up[3] = {0, 1, 0};
    double fx, fy;
    CHECK(pd.dir(0.5, 0.05, &fx, &fy) == 0.0 && fx == 0.0 && fy == 0.0);          // nothing recorded: no direction
    for (int i = 0; i < 40; ++i) { const double p[3] = {0.002 * i, 0.0, -0.3}; pd.push(0.011, p, right, up); }   // 8 cm to the right over 0.44 s
    double len = pd.dir(0.5, 0.05, &fx, &fy);
    CHECK(len > 0.07 && len < 0.09 && fx > 0.99 && fabs(fy) < 0.01);               // pulling to the right
    PullDir pu; pu.reset();
    for (int i = 0; i < 40; ++i) { const double p[3] = {0.0, 0.003 * i, -0.3}; pu.push(0.011, p, right, up); }
    len = pu.dir(0.5, 0.05, &fx, &fy);
    CHECK(len > 0.10 && fabs(fx) < 0.01 && fy > 0.99);                              // pulling up
    PullDir ph; ph.reset();
    for (int i = 0; i < 80; ++i) { const double p[3] = {0.001, 0.001, -0.3}; ph.push(0.011, p, right, up); }
    CHECK(ph.dir(0.5, 0.05, &fx, &fy) == 0.0 && fx == 0.0 && fy == 0.0);          // a hand that stays put: no direction (the game slams down by itself)
    PullDir pl; pl.reset();                                                          // only the last half second counts: a pull to the right, then a pull to the left
    for (int i = 0; i < 60; ++i) { const double p[3] = {0.003 * i, 0.0, -0.3}; pl.push(0.011, p, right, up); }
    for (int i = 0; i < 60; ++i) { const double p[3] = {0.18 - 0.003 * i, 0.0, -0.3}; pl.push(0.011, p, right, up); }
    pl.dir(0.5, 0.05, &fx, &fy);
    CHECK(fx < -0.99);
    PullDir pr; pr.reset();                                                          // the head turned (right axis flipped): the direction is in head space
    const double right2[3] = {-1, 0, 0};
    for (int i = 0; i < 40; ++i) { const double p[3] = {0.002 * i, 0.0, -0.3}; pr.push(0.011, p, right2, up); }
    pr.dir(0.5, 0.05, &fx, &fy);
    CHECK(fx < -0.99);
    PullDir pg; pg.reset();                                                          // a long gap (the game was paused) forgets the old samples
    for (int i = 0; i < 20; ++i) { const double p[3] = {0.01 * i, 0.0, -0.3}; pg.push(0.011, p, right, up); }
    { const double p[3] = {5.0, 0.0, -0.3}; pg.push(1.0, p, right, up); }
    CHECK(pg.n == 1);
    // 1.7.2: the strongest recent pull (best): found even when the hand stopped moving before the squeeze
    { PullDir pb; pb.reset();
      for (int i = 0; i < 40; ++i) { const double p[3] = {0.002 * i, 0.0, -0.3}; pb.push(0.011, p, right, up); }     // 8 cm to the right ...
      for (int i = 0; i < 80; ++i) { const double p[3] = {0.078, 0.0, -0.3}; pb.push(0.011, p, right, up); }          // ... then the hand rests for 0.9 s
      CHECK(pb.dir(0.5, 0.05, &fx, &fy) == 0.0);                                                                         // the old look (last half second) saw nothing
      len = pb.best(1.5, 0.6, 0.03, &fx, &fy);
      CHECK(len > 0.07 && fx > 0.99 && fabs(fy) < 0.01);                                                                 // the new look still finds the pull to the right
      PullDir pn; pn.reset();                                                                                              // a small wobble (1 cm) is no pull
      for (int i = 0; i < 100; ++i) { const double p[3] = {0.005 * (i % 2), 0.0, -0.3}; pn.push(0.011, p, right, up); }
      CHECK(pn.best(1.5, 0.6, 0.03, &fx, &fy) == 0.0 && fx == 0.0 && fy == 0.0);
      PullDir pw; pw.reset();                                                                                              // right, then left: the newer move wins
      for (int i = 0; i < 60; ++i) { const double p[3] = {0.003 * i, 0.0, -0.3}; pw.push(0.011, p, right, up); }
      for (int i = 0; i < 60; ++i) { const double p[3] = {0.18 - 0.003 * i, 0.0, -0.3}; pw.push(0.011, p, right, up); }
      pw.best(1.5, 0.6, 0.03, &fx, &fy);
      CHECK(fx < -0.99);
      PullDir pq; pq.reset();                                                                                              // up and to the right at 45 degrees
      for (int i = 0; i < 50; ++i) { const double p[3] = {0.002 * i, 0.002 * i, -0.3}; pq.push(0.011, p, right, up); }
      pq.best(1.5, 0.6, 0.03, &fx, &fy);
      CHECK(fabs(fx - 0.7071) < 0.02 && fabs(fy - 0.7071) < 0.02);
      PullDir pe; pe.reset();
      CHECK(pe.best(1.5, 0.6, 0.03, &fx, &fy) == 0.0);                                                                     // nothing recorded
    }
    // the slam (1.7.2: a sequence: capture held 0.70 s, fire from 0.10 s for 0.45 s, stick flick from 0.10 s for 0.30 s)
    double sx = 0, sy = 0; int started = 0, denied = 0, force = 0, ping = 0;
    auto U = [&](TrigSlam& t, double dt, double trig, int cap, int ready, int held, const PullDir& p) { return t.update(dt, trig, cap, ready, held, 0.9, p, &sx, &sy, &force, &started, &denied, &ping); };
    TrigSlam ts; ts.reset(); ts.slams = ts.denied = ts.flickless = ts.noGhost = ts.pings = 0;
    int pressFrames = 0;
    // 1) light squeeze: capture only, never a slam
    for (int i = 0; i < 50; ++i) { pressFrames += U(ts, 0.011, 0.5, 1, 1, 1, pd); CHECK(!started && !force); }
    CHECK(pressFrames == 0 && ts.slams == 0);
    // 2) a squeeze that was already held tight when the meter filled does nothing by itself
    TrigSlam t2; t2.reset(); t2.slams = t2.denied = t2.flickless = t2.noGhost = t2.pings = 0;
    for (int i = 0; i < 100; ++i) U(t2, 0.011, 1.0, 1, 0, 1, pd);
    CHECK(t2.denied == 1 && t2.slams == 0);                                          // told once that the meter is not full
    for (int i = 0; i < 100; ++i) { U(t2, 0.011, 1.0, 1, 1, 1, pd); CHECK(!started); }
    CHECK(t2.slams == 0);
    // 3) a fresh full squeeze with the meter full: capture held for 0.70 s, fire for 0.45 s, the stick flicks the way of the pull for 0.3 s
    TrigSlam t3; t3.reset(); t3.slams = t3.denied = t3.flickless = t3.noGhost = t3.pings = 0;
    for (int i = 0; i < 10; ++i) U(t3, 0.011, 0.5, 1, 1, 1, pd);
    int press = 0, flickFrames = 0, startedCount = 0, forceFrames = 0, firstFire = -1, firstForce = -1;
    for (int i = 0; i < 120; ++i) {
      const int pr = U(t3, 0.011, i < 8 ? 1.0 : 0.0, i < 8 ? 1 : 0, 1, 1, pd);   // a QUICK TAP: the trigger is let go after 8 polls (0.09 s)
      press += pr; startedCount += started; forceFrames += force;
      if (pr && firstFire < 0) firstFire = i;
      if (force && firstForce < 0) firstForce = i;
      if (sx != 0.0 || sy != 0.0) { ++flickFrames; CHECK(sx > 0.99); }
    }
    CHECK(startedCount == 1 && t3.slams == 1);                                        // one slam per squeeze
    CHECK(press == 0);                                                                // 1.7.25: the probe no longer presses fire
    CHECK(flickFrames >= 25 && flickFrames <= 29);                                    // about 0.3 s of stick flick
    CHECK(forceFrames >= 80 && forceFrames <= 88);                                    // capture is held for 0.9 s even though the tap lasted 0.09 s
    // 4) no pull seen: no flick (the game slams down by itself) but the fire press still happens
    TrigSlam t4; t4.reset(); t4.slams = t4.denied = t4.flickless = t4.noGhost = t4.pings = 0;
    PullDir still; still.reset();
    U(t4, 0.011, 0.2, 1, 1, 1, still);
    int p4 = 0, f4 = 0;
    for (int i = 0; i < 60; ++i) { p4 += U(t4, 0.011, 1.0, 1, 1, 1, still); if (sx != 0.0 || sy != 0.0) ++f4; }
    CHECK(t4.slams == 1 && t4.flickless == 1 && f4 == 0);
    // 5) the meter fills up to 0.4 s after the squeeze began: still a slam; later: not
    TrigSlam t5; t5.reset(); t5.slams = t5.denied = t5.flickless = t5.noGhost = t5.pings = 0;
    for (int i = 0; i < 10; ++i) U(t5, 0.011, 1.0, 1, 0, 1, pd);
    U(t5, 0.011, 1.0, 1, 1, 1, pd);
    CHECK(t5.slams == 1);
    // 6) without the capture stream the trigger never slams, and the refractory time stops a second slam at once
    TrigSlam t6; t6.reset(); t6.slams = t6.denied = t6.flickless = t6.noGhost = t6.pings = 0;
    for (int i = 0; i < 30; ++i) { U(t6, 0.011, 1.0, 0, 1, 1, pd); CHECK(!started); }
    for (int k = 0; k < 2; ++k) { U(t6, 0.011, 0.1, 1, 1, 1, pd); U(t6, 0.011, 1.0, 1, 1, 1, pd); }
    CHECK(t6.slams == 1);
    // 7) 1.7.2: the meter reads full but the game says nothing is held (the ghost got away): no slam, no fire press, told once
    TrigSlam t7; t7.reset(); t7.slams = t7.denied = t7.flickless = t7.noGhost = t7.pings = 0;
    int p7 = 0, d7 = 0;
    for (int k = 0; k < 3; ++k) { U(t7, 0.011, 0.1, 1, 1, 0, pd); for (int i = 0; i < 40; ++i) { p7 += U(t7, 0.011, 1.0, 1, 1, 0, pd); if (denied == 2) ++d7; CHECK(!started && !force); } }
    CHECK(t7.slams == 0 && p7 == 0 && t7.noGhost == 3 && d7 == 3);
    // 8) 1.7.2: the held-field is not trusted (-1): the old behaviour (the meter alone decides)
    TrigSlam t8; t8.reset(); t8.slams = t8.denied = t8.flickless = t8.noGhost = t8.pings = 0;
    U(t8, 0.011, 0.1, 1, 1, -1, pd); U(t8, 0.011, 1.0, 1, 1, -1, pd);
    CHECK(t8.slams == 1);
    // 9) 1.7.2: the "meter is full" ping, once, only while a ghost is held
    TrigSlam t9; t9.reset(); t9.slams = t9.denied = t9.flickless = t9.noGhost = t9.pings = 0;
    int pings = 0;
    for (int i = 0; i < 20; ++i) { U(t9, 0.011, 0.5, 1, 0, 1, pd); pings += ping; }
    for (int i = 0; i < 20; ++i) { U(t9, 0.011, 0.5, 1, 1, 1, pd); pings += ping; }
    CHECK(pings == 1);
    TrigSlam t10; t10.reset(); t10.slams = t10.denied = t10.flickless = t10.noGhost = t10.pings = 0;
    pings = 0;
    for (int i = 0; i < 20; ++i) { U(t10, 0.011, 0.5, 1, 0, 0, pd); pings += ping; }
    for (int i = 0; i < 20; ++i) { U(t10, 0.011, 0.5, 1, 1, 0, pd); pings += ping; }
    CHECK(pings == 0);
    // 10) 1.7.2: a second slam can follow after the sequence and the refractory time are over
    TrigSlam t11; t11.reset(); t11.slams = t11.denied = t11.flickless = t11.noGhost = t11.pings = 0;
    for (int k = 0; k < 2; ++k) { U(t11, 0.011, 0.1, 1, 1, 1, pd); for (int i = 0; i < 20; ++i) U(t11, 0.011, 1.0, 1, 1, 1, pd); for (int i = 0; i < 120; ++i) U(t11, 0.011, 0.1, 1, 1, 1, pd); }
    CHECK(t11.slams == 2); }
  // ---- 1.7.25: a full squeeze starts the slam at once; the probe never lets fire go and never presses it (the slam goes through the game's own slam function)
  {
    double sx = 0, sy = 0; int started = 0, denied = 0, force = 0, ping = 0;
    PullDir pd2; pd2.reset();
    TrigSlam t; t.reset(); t.slams = t.denied = t.flickless = t.noGhost = t.pings = 0;
    for (int i = 0; i < 10; ++i) t.update(0.011, 0.5, 1, 1, 1, 0.9, pd2, &sx, &sy, &force, &started, &denied, &ping);
    int press = 0, rel = 0, startedAt = -1, forceSum = 0;
    for (int i = 0; i < 140; ++i) {
      const int pr = t.update(0.011, 1.0, 1, 1, 1, 0.9, pd2, &sx, &sy, &force, &started, &denied, &ping);
      press += pr; rel += t.releaseNow; forceSum += force;
      if (started && startedAt < 0) startedAt = i;
    }
    CHECK(startedAt == 0 && press == 0 && rel == 0 && t.slams == 1);
    CHECK(forceSum >= 70 && forceSum <= 90);   // the capture button is kept for about 0.9 s
    // one charge is enough (ready = meter >= one charge): a second squeeze after the refractory time slams again
    for (int i = 0; i < 150; ++i) t.update(0.011, 0.1, 1, 1, 1, 0.9, pd2, &sx, &sy, &force, &started, &denied, &ping);
    t.update(0.011, 1.0, 1, 1, 1, 0.9, pd2, &sx, &sy, &force, &started, &denied, &ping);
    CHECK(t.slams == 2);
    // meter below one charge: denied, no slam
    TrigSlam t4; t4.reset(); t4.slams = t4.denied = t4.flickless = t4.noGhost = t4.pings = 0;
    t4.update(0.011, 0.1, 1, 0, 1, 0.9, pd2, &sx, &sy, &force, &started, &denied, &ping);
    t4.update(0.011, 1.0, 1, 0, 1, 0.9, pd2, &sx, &sy, &force, &started, &denied, &ping);
    CHECK(t4.slams == 0 && t4.denied == 1);
  }
  if (!fails) printf("test_gear: all passed\n");
  return fails ? 1 : 0;
}
