// Build: clang++ -std=c++17 -Isrc tests/test_ghostmove.cpp
#include "ghostmovemath.h"
#include <stdio.h>
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  const int64_t F = 1000;   // 1000 ticks per second
  float a[3] = {0, 0, 0}; int64_t aq = 0, mq = 0;
  float p[3] = {597.3f, 107.0f, -924.8f};
  // a ghost that has not spawned: never moves, never counts as moving, even over a minute
  for (int64_t t = 1; t <= 60000; t += 14) { ghostmove::step(a, &aq, &mq, p, t, F); CHECK(!ghostmove::moving(mq, t, F)); }
  // a flying ghost (3 ft/s, polled every 14 ms): counts as moving after a fraction of a second and stays so
  float b[3] = {0, 0, 0}; int64_t bq = 0, bm = 0; float q[3] = {0, 0, 0}; int movingSeen = 0;
  for (int64_t t = 1; t <= 5000; t += 14) { q[0] = 3.0f * (float)t / 1000.0f; ghostmove::step(b, &bq, &bm, q, t, F); if (t > 500) CHECK(ghostmove::moving(bm, t, F)); else movingSeen += ghostmove::moving(bm, t, F); }
  CHECK(movingSeen > 0);
  // it stops: moving ends 2 s later
  ghostmove::step(b, &bq, &bm, q, 5100, F); CHECK(ghostmove::moving(bm, 5100, F));
  ghostmove::step(b, &bq, &bm, q, 8000, F); CHECK(!ghostmove::moving(bm, 8000, F));
  // a slow drift (0.2 ft/s) is not a move
  float c[3] = {0, 0, 0}; int64_t cq = 0, cm = 0; float r[3] = {0, 0, 0};
  for (int64_t t = 1; t <= 20000; t += 14) { r[0] = 0.2f * (float)t / 1000.0f; ghostmove::step(c, &cq, &cm, r, t, F); CHECK(!ghostmove::moving(cm, t, F)); }
  // a jump (spawn into the level) counts
  float d[3] = {0, 0, 0}; int64_t dq = 0, dm = 0; float s0[3] = {10, 0, 0}, s1[3] = {40, 0, 5};
  ghostmove::step(d, &dq, &dm, s0, 100, F); ghostmove::step(d, &dq, &dm, s1, 200, F); CHECK(ghostmove::moving(dm, 250, F));
  printf(fails ? "%d FAILED\n" : "ALL PASS\n", fails);
  return fails ? 1 : 0;
}
