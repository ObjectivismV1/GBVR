// 1.7.158 the ghost health vial (fightmath.h): vertex budget, finite values, bounds, liquid vs plain path, and a long random stress run.
#include <cstdio>
#include <cmath>
#include "fightmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static unsigned long long sd = 0x6A09E667ULL;
static double rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (double)(sd >> 11) / 9007199254740992.0; }
static cord::V v[12000];
static int bad(int n) {
  int b = 0;
  for (int i = 0; i < n; ++i) { for (int k = 0; k < 3; ++k) if (!(v[i].p[k] == v[i].p[k]) || !(v[i].n[k] == v[i].n[k])) ++b;
    for (int k = 0; k < 4; ++k) if (!(v[i].c[k] == v[i].c[k]) || v[i].c[k] < -0.001f || v[i].c[k] > 1.001f) ++b; }
  return b;
}
int main() {
  fight::Bar bars[fight::kMaxBars]; gunbar::Liquid liq[fight::kMaxBars];
  fight::Look look; look.sizePct = 100; look.digitsFocus = 0; look.focusDeg = 7; look.ringStyle = 0; look.liquid = 1; look.liq = liq;
  for (int i = 0; i < fight::kMaxBars; ++i) { bars[i].p[0] = (float)(-1.0 + 0.09 * i); bars[i].p[1] = 0.1f; bars[i].p[2] = 3.0f; bars[i].radius = 1.0f; bars[i].flags = 0; bars[i].actor = i + 1; bars[i].frac = 0.5f; liq[i].reset(); gunbar::step(&liq[i], 0.5, 0.011); }
  const int one = fight::build(bars, 1, 0.0, look, v, 12000);
  CHECK(one > 0 && one % 3 == 0 && bad(one) == 0);
  const int all = fight::build(bars, fight::kMaxBars, 0.0, look, v, 12000);
  CHECK(all == one * fight::kMaxBars || all <= 12000);   // 24 vials fit the buffer the draw uses
  CHECK(all <= 12000 && all % 3 == 0 && bad(all) == 0);
  look.liq = nullptr;   // no liquid state: the plain health fraction still draws
  const int plain = fight::build(bars, 3, 0.0, look, v, 12000);
  CHECK(plain > 0 && bad(plain) == 0);
  look.liq = liq;
  { cord::V tiny[30]; const int c = fight::build(bars, 3, 0.0, look, tiny, 30); CHECK(c == -1 || (c >= 0 && c <= 30 && c % 3 == 0)); }   // a small buffer is never overrun
  look.liquid = 0; const int old = fight::build(bars, 3, 0.0, look, v, 12000); CHECK(old > 0 && bad(old) == 0);   // the bar path is untouched
  look.liquid = 1;
  {   // 1.7.160: a far boss (Stay Puft from the roof, 65 m) keeps a readable size: at least 4.3 deg wide with the ring style, 2.6 deg without; near ghosts unchanged
    for (int rs = 0; rs < 2; ++rs) for (int d = 0; d < 4; ++d) {
      const double z = d == 0 ? 3.0 : d == 1 ? 12.0 : d == 2 ? 30.0 : 65.0;
      fight::Bar fb[1]; fb[0] = bars[0]; fb[0].p[0] = 0; fb[0].p[1] = 0; fb[0].p[2] = (float)z; fb[0].radius = 4.0f; fb[0].flags = rs ? fight::kFlagFocus : 0u;
      fight::Look lk = look; lk.ringStyle = rs; lk.liq = nullptr;
      const int c = fight::build(fb, 1, 0.0, lk, v, 12000);
      double lo = 1e9, hi = -1e9, zz = 0; for (int i = 0; i < c; ++i) { if (v[i].p[0] < lo) lo = v[i].p[0]; if (v[i].p[0] > hi) hi = v[i].p[0]; zz = fabs(v[i].p[2]); }
      const double deg = c > 0 && zz > 0 ? 2.0 * atan(0.5 * (hi - lo) / zz) * 57.2958 : 0.0;
      const double want = fight::vial_width(z, 4.0, 100.0, rs);
      CHECK(c > 0 && deg > (rs ? 1.0 : 2.5) && deg < 40.0);   // 1.7.170: ring style draws the ring now
      if (z <= 12.0) CHECK(fabs(want - fight::bar_width(z, 4.0, 100.0) * (rs ? 1.45 : 1.15)) < 1e-12 || want >= fight::bar_width(z, 4.0, 100.0));
      printf("  vial at %4.0f m, ring style %d: %.1f deg wide\n", z, rs, deg);
    }
  }
  // stress: random positions (some behind, far, NaN), fractions, states
  long worst = 0, badTotal = 0;
  for (int it = 0; it < 4000; ++it) {
    const int nb = 1 + (int)(rnd() * fight::kMaxBars);
    for (int i = 0; i < nb; ++i) {
      bars[i].p[0] = (float)((rnd() - 0.5) * 12); bars[i].p[1] = (float)((rnd() - 0.5) * 8); bars[i].p[2] = (float)(rnd() * 40 - 3);
      if (rnd() < 0.02) bars[i].p[0] = NAN; bars[i].radius = (float)(0.5 + rnd() * 6); bars[i].flags = rnd() < 0.3 ? 1u : 0u;
      const double f = rnd() < 0.1 ? (rnd() < 0.5 ? -0.5 : 1.7) : rnd(); bars[i].frac = (float)f;
      if (rnd() < 0.3) { gunbar::step(&liq[i], rnd(), 0.002 + 0.02 * rnd()); }
    }
    look.sizePct = 30 + rnd() * 300; look.ringStyle = rnd() < 0.2 ? 1 : 0;
    const int n = fight::build(bars, nb, (rnd() - 0.5) * 0.1, look, v, 12000);
    CHECK(n >= 0 && n <= 12000 && n % 3 == 0); badTotal += n > 0 ? bad(n) : 0; if (n > worst) worst = n;
  }
  CHECK(badTotal == 0);
  printf("%s ghost vial: %d vertices per vial, 24 vials = %d, worst stress %ld, %d failures\n", fails ? "FAIL" : "PASS", one, all, worst, fails);
  return fails ? 1 : 0;
}
