#include <stdio.h>
#include <string.h>
#include <math.h>
#include <vector>
#include "glowmath.h"
using namespace glow;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

static const double kAspect = 16.0 / 9.0;

static int pixel_at(const Look& l, int iw, int ih, double x, double y, int* oi, int* oj) {   // nearest pixel to a position
  double qw, qh; quad_units(l, &qw, &qh);
  int i = (int)((x / qw + 0.5) * iw), j = (int)((y / qh + 0.5) * ih);
  if (i < 0) i = 0; if (i > iw - 1) i = iw - 1; if (j < 0) j = 0; if (j > ih - 1) j = ih - 1;
  *oi = i; *oj = j; return 1;
}

int main() {
  // ---- decode: the three formats the graphics card may hand back
  {
    uint8_t px[2 * 4] = {10, 20, 30, 255,  255, 128, 0, 255};   // two pixels, one row
    Grid g;
    CHECK(decode(px, 8, 2, 1, kRGBA8, &g));
    CHECK(fabsf(g.c[0] - 10 / 255.0f) < 1e-6f && fabsf(g.c[1] - 20 / 255.0f) < 1e-6f && fabsf(g.c[2] - 30 / 255.0f) < 1e-6f);
    CHECK(fabsf(g.c[3] - 1.0f) < 1e-6f && fabsf(g.c[4] - 128 / 255.0f) < 1e-6f && g.c[5] == 0.0f);
    CHECK(decode(px, 8, 2, 1, kBGRA8, &g));   // blue first
    CHECK(fabsf(g.c[0] - 30 / 255.0f) < 1e-6f && fabsf(g.c[2] - 10 / 255.0f) < 1e-6f);
    uint32_t v = 1023u | (512u << 10) | (0u << 20) | (3u << 30);   // r max, g half, b 0
    uint8_t p10[4]; memcpy(p10, &v, 4);
    CHECK(decode(p10, 4, 1, 1, kRGB10A2, &g));
    CHECK(fabsf(g.c[0] - 1.0f) < 1e-6f && fabsf(g.c[1] - 512 / 1023.0f) < 1e-6f && g.c[2] == 0.0f);
    // a row pitch larger than the row (the card pads rows)
    uint8_t padded[2 * 16] = {};
    padded[0] = 255; padded[16 + 1] = 255;
    CHECK(decode(padded, 16, 1, 2, kRGBA8, &g));
    CHECK(g.c[0] == 1.0f && g.c[3 + 1] == 1.0f);
    CHECK(!decode(px, 8, 2, 1, 7, &g) && !decode(nullptr, 8, 2, 1, kRGBA8, &g) && !decode(px, 8, 0, 1, kRGBA8, &g) && !decode(px, 8, 33, 1, kRGBA8, &g));
  }
  // ---- black bars are skipped
  {
    Grid g; fill_grid(&g, 16, 9, 0.8f, 0.3f, 0.1f);
    Insets in = bars(g);
    CHECK(in.l == 0 && in.r == 0 && in.t == 0 && in.b == 0);                 // a full picture has none
    Grid k; fill_grid(&k, 16, 9, 0, 0, 0);
    in = bars(k); CHECK(in.l == 0 && in.t == 0);                              // an all-black picture: nothing to skip
    for (int x = 0; x < 16; ++x) { for (int c = 0; c < 3; ++c) { g.c[(0 * 16 + x) * 3 + c] = 0; g.c[(1 * 16 + x) * 3 + c] = 0; g.c[(8 * 16 + x) * 3 + c] = 0; } }
    in = bars(g); CHECK(in.t == 2 && in.b == 1 && in.l == 0 && in.r == 0);   // letterbox: 2 rows on top, 1 at the bottom
    for (int y = 0; y < 9; ++y) for (int x = 0; x < 3; ++x) for (int c = 0; c < 3; ++c) g.c[(y * 16 + x) * 3 + c] = 0;
    in = bars(g); CHECK(in.l == 3);                                           // pillar box
    Grid dark; fill_grid(&dark, 16, 9, 0.001f, 0.001f, 0.001f); dark.c[(4 * 16 + 8) * 3] = 0.5f;
    in = bars(dark); CHECK(in.t == 3 && in.b == 3 && in.l == 6 && in.r == 6);   // never more than 40 % (the bright cell is in the middle)
  }
  // ---- the halo picture
  {
    Look l = default_look(0.7, kAspect);
    int iw, ih; image_size(l, 160, &iw, &ih);
    double qw, qh; quad_units(l, &qw, &qh);
    printf("halo picture %d x %d for a quad of %.3f x %.3f screen widths (pixel aspect %.4f, quad aspect %.4f)\n", iw, ih, qw, qh, (double)iw / ih, qw / qh);
    CHECK(fabs((double)iw / ih - qw / qh) < 0.02);
    std::vector<float> img((size_t)iw * ih * 4);
    // red on the right half, blue on the left half, green top/bottom does not matter
    Grid g; g.w = 16; g.h = 9;
    for (int y = 0; y < 9; ++y) for (int x = 0; x < 16; ++x) { float* c = &g.c[(y * 16 + x) * 3]; c[0] = x >= 8 ? 1.0f : 0.0f; c[1] = 0; c[2] = x < 8 ? 1.0f : 0.0f; }
    render_target(g, l, iw, ih, img.data());
    auto A = [&](int i, int j) { return img[((size_t)j * iw + i) * 4 + 3]; };
    auto C = [&](int i, int j, int k) { return img[((size_t)j * iw + i) * 4 + k]; };
    // everything finite and in range
    for (size_t i = 0; i < img.size(); ++i) CHECK(img[i] == img[i] && img[i] >= 0.0f && img[i] <= 1.0f);
    // corners: beyond the reach -> invisible; inside the screen -> invisible
    CHECK(A(0, 0) == 0.0f && A(iw - 1, 0) == 0.0f && A(0, ih - 1) == 0.0f && A(iw - 1, ih - 1) == 0.0f);
    int ci, cj; pixel_at(l, iw, ih, 0.0, 0.0, &ci, &cj);
    CHECK(A(ci, cj) == 0.0f);
    // just outside the right edge: bright, red; just outside the left edge: bright, blue
    int ri, rj, li, lj; pixel_at(l, iw, ih, 0.5 + 0.02, 0.0, &ri, &rj); pixel_at(l, iw, ih, -0.5 - 0.02, 0.0, &li, &lj);
    printf("alpha just outside the right edge %.3f (peak %.2f x strength %.2f), colour %.2f,%.2f,%.2f; left edge colour %.2f,%.2f,%.2f\n", A(ri, rj), l.peak, l.strength, C(ri, rj, 0), C(ri, rj, 1), C(ri, rj, 2), C(li, lj, 0), C(li, lj, 1), C(li, lj, 2));
    CHECK(A(ri, rj) > 0.6f * (float)(l.peak * l.strength) && A(ri, rj) <= (float)(l.peak * l.strength) + 1e-6f);
    CHECK(C(ri, rj, 0) > 0.9f && C(ri, rj, 2) < 0.3f && C(ri, rj, 0) > 3.0f * C(ri, rj, 2));   // (a share of the picture's average colour, purple-ish, is mixed in)
    CHECK(C(li, lj, 2) > 0.9f && C(li, lj, 0) < 0.3f && C(li, lj, 2) > 3.0f * C(li, lj, 0));
    // fading away: alpha only goes down as the distance from the edge grows (right side, middle row)
    float prev = 2.0f; int steps = 0;
    for (int i = ri; i < iw; ++i) { CHECK(A(i, rj) <= prev + 1e-6f); prev = A(i, rj); ++steps; }
    CHECK(prev < 1e-4f && steps > 10);
    // above the screen (middle column): still lit, same alpha pattern (the distance is measured in the same units)
    int ti, tj; pixel_at(l, iw, ih, 0.0, -0.5 / kAspect - 0.02, &ti, &tj);
    CHECK(A(ti, tj) > 0.5f * (float)(l.peak * l.strength));
    // strength 0: no halo at all
    Look off = default_look(0.0, kAspect);
    render_target(g, off, iw, ih, img.data());
    for (int j = 0; j < ih; ++j) for (int i = 0; i < iw; ++i) CHECK(A(i, j) == 0.0f);
    // a black picture lights nothing (colour 0 wherever there is alpha)
    Grid k; fill_grid(&k, 16, 9, 0, 0, 0);
    render_target(k, l, iw, ih, img.data());
    for (int j = 0; j < ih; ++j) for (int i = 0; i < iw; ++i) CHECK(C(i, j, 0) == 0.0f && C(i, j, 1) == 0.0f && C(i, j, 2) == 0.0f);
    // letterbox: the halo above and below takes the picture's colour, not the bars' black
    Grid lb; fill_grid(&lb, 16, 9, 0.9f, 0.6f, 0.2f);
    for (int x = 0; x < 16; ++x) for (int c = 0; c < 3; ++c) { lb.c[(0 * 16 + x) * 3 + c] = 0; lb.c[(1 * 16 + x) * 3 + c] = 0; lb.c[(7 * 16 + x) * 3 + c] = 0; lb.c[(8 * 16 + x) * 3 + c] = 0; }
    render_target(lb, l, iw, ih, img.data());
    pixel_at(l, iw, ih, 0.0, -0.5 / kAspect - 0.02, &ti, &tj);
    CHECK(C(ti, tj, 0) > 0.7f && C(ti, tj, 1) > 0.4f);
    // a dim picture gives a dim halo, a bright one a brighter halo (alpha is the same; the colour carries it)
    Grid dim, bright; fill_grid(&dim, 16, 9, 0.1f, 0.1f, 0.1f); fill_grid(&bright, 16, 9, 0.9f, 0.9f, 0.9f);
    std::vector<float> a(img.size()), b(img.size());
    render_target(dim, l, iw, ih, a.data()); render_target(bright, l, iw, ih, b.data());
    CHECK(a[((size_t)rj * iw + ri) * 4] < b[((size_t)rj * iw + ri) * 4] * 0.5f);
  }
  // ---- the halo never flashes: easing toward the target, with a step limit
  {
    float cur[8] = {0}, tgt[8]; for (int i = 0; i < 8; ++i) tgt[i] = 1.0f;
    float worst = 1; int n = 0;
    float first = 0;
    while (worst > 0.01f && n < 200) { worst = ease(cur, tgt, 8, 0.2f, 0.12f); ++n; if (n == 1) first = cur[0]; }
    printf("a white flash: first step %.3f, settled after %d updates\n", first, n);
    CHECK(first <= 0.12f + 1e-6f && n > 8 && n < 60);
    for (int i = 0; i < 8; ++i) CHECK(cur[i] <= 1.0f);
    float down[4] = {1, 1, 1, 1}, zero[4] = {0, 0, 0, 0};
    ease(down, zero, 4, 0.2f, 0.12f); CHECK(down[0] >= 0.88f - 1e-6f && down[0] < 1.0f);
    float hold[3] = {0.5f, 0.5f, 0.5f}; CHECK(ease(hold, hold, 3, 0.2f, 0.12f) == 0.0f && hold[0] == 0.5f);
  }
  // ---- bytes
  {
    Look l = default_look(0.7, kAspect);
    int iw, ih; image_size(l, 64, &iw, &ih);
    std::vector<float> img((size_t)iw * ih * 4);
    Grid g; fill_grid(&g, 8, 5, 0.6f, 0.5f, 0.9f);
    render_target(g, l, iw, ih, img.data());
    std::vector<uint8_t> by((size_t)iw * ih * 4), by2((size_t)iw * ih * 4);
    to_bytes(img.data(), iw, ih, by.data(), 1); to_bytes(img.data(), iw, ih, by2.data(), 2);
    int diffs = 0, maxDiff = 0;
    for (int j = 0; j < ih; ++j) for (int i = 0; i < iw; ++i) {
      const float* p = &img[((size_t)j * iw + i) * 4]; const uint8_t* o = &by[((size_t)j * iw + i) * 4];
      int e = (int)(p[3] * 255.0f + 0.5f), d = (int)o[3] - e; if (d < 0) d = -d; if (d > maxDiff) maxDiff = d;
      if (p[3] == 0.0f) CHECK(o[3] == 0);
      const uint8_t* o2 = &by2[((size_t)j * iw + i) * 4]; if (o[3] != o2[3]) ++diffs;
    }
    printf("alpha dither: at most %d step off, differs between frames in %d pixels\n", maxDiff, diffs);
    CHECK(maxDiff <= 1);
  }
  // ---- 0.98 calm glow: a flash in the picture barely moves the average; a lasting change gets there in a few seconds
  {
    Grid slow; slow.clear();
    Grid dark; fill_grid(&dark, 6, 4, 0.10f, 0.10f, 0.20f);
    Grid flash; fill_grid(&flash, 6, 4, 1.0f, 1.0f, 1.0f);
    blend_toward(&slow, dark, 1.0, 5.0);                     // first reading: taken as it is
    CHECK(slow.w == 6 && slow.h == 4 && slow.c[0] == 0.10f && slow.c[2] == 0.20f);
    blend_toward(&slow, flash, 0.09, 5.0);                   // one 90 ms white flash
    CHECK(slow.c[0] < 0.10f + 0.9f * 0.02f);                 // moved by less than 2 % of the way
    for (int i = 0; i < 3; ++i) blend_toward(&slow, flash, 0.09, 5.0);   // ~0.4 s of white in all
    CHECK(slow.c[0] < 0.30f);
    for (int i = 0; i < 400; ++i) blend_toward(&slow, flash, 0.09, 5.0); // 36 s of white
    CHECK(slow.c[0] > 0.95f);
    blend_toward(&slow, dark, 0.0, 5.0); CHECK(slow.c[0] > 0.95f);       // no time passed: nothing moves
    blend_toward(&slow, dark, -1.0, 5.0); CHECK(slow.c[0] > 0.95f);
    Grid big; fill_grid(&big, 8, 5, 0.5f, 0.5f, 0.5f);
    blend_toward(&slow, big, 0.09, 5.0); CHECK(slow.w == 8 && slow.h == 5 && slow.c[0] == 0.5f);   // another size starts over
    Grid empty; empty.clear(); Grid keep = slow; blend_toward(&slow, empty, 0.09, 5.0); CHECK(slow.w == keep.w && slow.c[0] == keep.c[0]);
    blend_toward(nullptr, flash, 0.09, 5.0);                 // no crash
    // a long gap counts as 1 s at most
    Grid a, b; fill_grid(&a, 4, 4, 0.0f, 0.0f, 0.0f); fill_grid(&b, 4, 4, 1.0f, 1.0f, 1.0f);
    blend_toward(&a, b, 100.0, 5.0); CHECK(a.c[0] > 0.15f && a.c[0] < 0.18f);   // 1/(5+1) = 0.1667
    // the calm look is fainter and takes less from the edge
    Look c = steady_look(0.7, kAspect), d = default_look(0.7, kAspect);
    CHECK(c.peak < d.peak && c.edgeShare < d.edgeShare && c.reach == d.reach);
    // the calm glow at a hard cut: with the SAME step rule used in the probe (k 0.10, at most 0.012), no pixel moves more than 1.2 % per update
    float cur[4] = {0, 0, 0, 0}, tgt[4] = {1, 1, 1, 1};
    ease(cur, tgt, 4, 0.10f, 0.012f); CHECK(cur[0] <= 0.012f + 1e-6f);
  }
  // ---- 1.1 the steady glow: one colour at a fixed brightness, a slow drift, nothing that can flash
  {
    const Tint def = default_tint();
    float black[3] = {0, 0, 0}, nearBlack[3] = {0.02f, 0.01f, 0.01f}, dim[3] = {0.20f, 0.10f, 0.02f}, bright[3] = {0.80f, 0.40f, 0.08f}, blue[3] = {0.05f, 0.10f, 0.40f}, nan3[3] = {0.0f / 0.0f, 0.5f, 0.5f};
    Tint tb = ambient_target(black), tn = ambient_target(nearBlack);
    CHECK(tb.r == def.r && tb.g == def.g && tb.b == def.b);                 // a black picture: the default soft blue-white
    CHECK(vm::dabs((double)tn.r - def.r) < 0.02 && vm::dabs((double)tn.g - def.g) < 0.02 && vm::dabs((double)tn.b - def.b) < 0.02);   // nearly black too (no jumping around in the dark)
    Tint td = ambient_target(dim), tr = ambient_target(bright);
    // a dim and a bright scene of the same hue glow with the SAME colour (brightness never follows the picture)
    CHECK(vm::dabs((double)td.r - tr.r) < 0.02 && vm::dabs((double)td.g - tr.g) < 0.02 && vm::dabs((double)td.b - tr.b) < 0.02);
    CHECK(tr.r > tr.b);                                                      // an orange room glows warm
    Tint tbl = ambient_target(blue);
    CHECK(tbl.b > tbl.r);                                                    // a blue room glows cool
    // the brightness (luma) of every colour the glow can have stays in a narrow band
    float lo = 9, hi = 0;
    for (int i = 0; i < 40; ++i) {
      float m[3] = {(float)((i * 7) % 11) / 10.0f, (float)((i * 5) % 13) / 12.0f, (float)((i * 3) % 7) / 6.0f};
      Tint t = ambient_target(m);
      float l = tint_luma(t);
      CHECK(t.r >= 0.0f && t.r <= 1.0f && t.g >= 0.0f && t.g <= 1.0f && t.b >= 0.0f && t.b <= 1.0f);
      if (l < lo) lo = l; if (l > hi) hi = l;
    }
    printf("steady glow colour: luma %.2f .. %.2f over 40 different pictures\n", (double)lo, (double)hi);
    CHECK(lo > 0.40f && hi < 0.70f);   // 1.1: the same brightness for every hue (bright scene = dark scene = red room = blue room)
    Tint tnan = ambient_target(nan3); (void)tnan;   // no crash on a bad reading
    // follow_tint: slow, never faster than the cap, no overshoot
    Tint cur = def, target = tr;
    follow_tint(&cur, target, 1.0 / 72.0, 6.0, 0.05);
    CHECK(vm::dabs((double)cur.r - def.r) <= 0.05 / 72.0 + 1e-6);
    float prevR = cur.r; int mono = 1, over = 0;
    for (int i = 0; i < 72 * 40; ++i) {
      follow_tint(&cur, target, 1.0 / 72.0, 6.0, 0.05);
      if (cur.r < prevR - 1e-6f && target.r > def.r) mono = 0;
      if ((target.r > def.r && cur.r > target.r + 1e-5f) || (target.r < def.r && cur.r < target.r - 1e-5f)) over = 1;
      prevR = cur.r;
    }
    CHECK(mono && !over);
    CHECK(vm::dabs((double)cur.r - target.r) < 0.02 && vm::dabs((double)cur.b - target.b) < 0.02);   // 40 s later it is there
    // a hard cut from red to blue: the biggest step per frame at 72 Hz stays tiny
    Tint red = ambient_target(bright), blu = ambient_target(blue), c2 = red; double worst = 0;
    for (int i = 0; i < 72 * 5; ++i) { Tint b4 = c2; follow_tint(&c2, blu, 1.0 / 72.0, 6.0, 0.05); double st = vm::dabs((double)c2.r - b4.r) + vm::dabs((double)c2.g - b4.g) + vm::dabs((double)c2.b - b4.b); if (st > worst) worst = st; }
    printf("hard cut red -> blue: biggest colour step per frame %.4f, after 5 s the glow is %.0f %% of the way\n", worst, 100.0 * (1.0 - (vm::dabs((double)c2.b - blu.b) / vm::dabs((double)red.b - blu.b))));
    CHECK(worst < 0.003);
    Tint z = def; follow_tint(&z, target, 0.0, 6.0, 0.05); CHECK(z.r == def.r);          // no time: no move
    follow_tint(&z, target, -1.0, 6.0, 0.05); CHECK(z.r == def.r);
    follow_tint(nullptr, target, 0.1, 6.0, 0.05);                                        // no crash
    follow_tint(&z, target, 100.0, 6.0, 0.05); CHECK(vm::dabs((double)z.r - def.r) <= 0.05 * 0.25 + 1e-6);   // a long gap counts as 0.25 s
    // fade in
    CHECK(fade_in(0.0, 1.6) == 0.0f && fade_in(-1.0, 1.6) == 0.0f);
    CHECK(fade_in(1.6, 1.6) == 1.0f && fade_in(9.0, 1.6) == 1.0f && fade_in(1.0, 0.0) == 1.0f);
    float prev = 0; int up = 1; for (int i = 1; i <= 100; ++i) { float f = fade_in(1.6 * i / 100.0, 1.6); if (f < prev) up = 0; prev = f; }
    CHECK(up && fade_in(0.8, 1.6) > 0.45f && fade_in(0.8, 1.6) < 0.55f);
    // screen curvature: 0 = flat; 100 % wraps the screen around the viewer (2 pi r c = width); never more than 0.45
    CHECK(screen_curvature(0, 3.2, 2.8) == 0.0f && screen_curvature(-5, 3.2, 2.8) == 0.0f && screen_curvature(50, 0.0, 2.8) == 0.0f);
    const float full = screen_curvature(100, 3.2, 2.8);
    printf("screen bend at 100 %% for a 3.2 m screen at 2.8 m: %.3f (a %.0f degree arc)\n", (double)full, (double)full * 360.0);
    CHECK(vm::dabs((double)full - 3.2 / (6.283185307 * 2.8)) < 1e-4);
    CHECK(screen_curvature(40, 3.2, 2.8) < full && screen_curvature(40, 3.2, 2.8) > 0.0f);
    CHECK(screen_curvature(100, 20.0, 1.2) <= 0.45f);
  }
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
