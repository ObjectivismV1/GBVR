// 1.7.151 tests for the four-corner TV glow (glowmath.h corner_*), with a stress run over random pictures
#include <cstdio>
#include <cmath>
#include "glowmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static unsigned long long s = 0x9E3779B97F4A7C15ULL;
static float rnd() { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return (float)((double)(s >> 11) / 9007199254740992.0); }
int main() {
  // the four shares add up to 1 everywhere and each is 1 in its own corner
  for (int j = 0; j <= 40; ++j) for (int i = 0; i <= 40; ++i) {
    const double u = i / 40.0, v = j / 40.0; float sum = 0;
    for (int c = 0; c < 4; ++c) { const float w = glow::corner_weight(c, u, v); CHECK(w >= 0.0f && w <= 1.0f); sum += w; }
    CHECK(fabs(sum - 1.0f) < 1e-5f);
  }
  CHECK(glow::corner_weight(0, 0, 0) == 1.0f && glow::corner_weight(1, 1, 0) == 1.0f && glow::corner_weight(2, 0, 1) == 1.0f && glow::corner_weight(3, 1, 1) == 1.0f);
  CHECK(glow::corner_weight(0, 1, 1) == 0.0f && glow::corner_weight(3, 0, 0) == 0.0f);
  // a picture: red top-left, green top-right, blue bottom-left, white bottom-right
  glow::Grid g; g.w = 16; g.h = 8;
  for (int y = 0; y < 8; ++y) for (int x = 0; x < 16; ++x) {
    float* c = &g.c[(y * 16 + x) * 3]; const int q = (x >= 8) | ((y >= 4) << 1);
    c[0] = q == 0 || q == 3 ? 0.8f : 0.02f; c[1] = q == 1 || q == 3 ? 0.8f : 0.02f; c[2] = q == 2 || q == 3 ? 0.8f : 0.02f;
  }
  {   // 1.7.161: a dark menu with a little orange writing glows orange (not grey, not blue); a black picture glows a faint neutral light (not blue)
    glow::Grid g; glow::fill_grid(&g, 15, 8, 0.05f, 0.05f, 0.06f);
    for (int x = 1; x < 6; ++x) { float* c = &g.c[(2 * g.w + x) * 3]; c[0] = 0.95f; c[1] = 0.55f; c[2] = 0.10f; }
    const glow::Insets in = {0, 0, 0, 0}; float m[3]; glow::corner_mean(g, in, 0, m); const glow::Tint t = glow::corner_target(m);
    CHECK(t.r > t.b * 2.0f && t.g > t.b * 1.3f);
    glow::Grid k; glow::fill_grid(&k, 15, 8, 0.0f, 0.0f, 0.0f); float mk[3]; glow::corner_mean(k, in, 1, mk); const glow::Tint tk = glow::corner_target(mk);
    CHECK(tk.b < tk.r * 1.15f && glow::tint_luma(tk) > 0.15f && glow::tint_luma(tk) < 0.40f);
    glow::Grid gr; glow::fill_grid(&gr, 15, 8, 0.33f, 0.31f, 0.33f); float mg[3]; glow::corner_mean(gr, in, 2, mg); const glow::Tint tg = glow::corner_target(mg);
    CHECK(fabs(tg.r - tg.g) < 0.08f && fabs(tg.b - tg.g) < 0.08f);   // a grey menu stays grey (no invented colour)
    printf("  dark menu, orange text: glow %.2f,%.2f,%.2f | black: %.2f,%.2f,%.2f | grey: %.2f,%.2f,%.2f\n", t.r, t.g, t.b, tk.r, tk.g, tk.b, tg.r, tg.g, tg.b);
  }
  const glow::Insets in = glow::bars(g);
  glow::Tint t[4];
  for (int c = 0; c < 4; ++c) { float m[3]; glow::corner_mean(g, in, c, m); t[c] = glow::corner_target(m); }
  CHECK(t[0].r > t[0].g * 1.5f && t[0].r > t[0].b * 1.5f);   // red corner glows red
  CHECK(t[1].g > t[1].r * 1.5f && t[1].g > t[1].b * 1.5f);
  CHECK(t[2].b > t[2].r * 1.5f && t[2].b > t[2].g * 1.5f);
  CHECK(fabs(t[3].r - t[3].g) < 0.08f && fabs(t[3].g - t[3].b) < 0.08f);   // white corner: white
  // a black corner keeps a faint light (never off, never bright)
  { float m[3] = {0, 0, 0}; const glow::Tint k = glow::corner_target(m); CHECK(glow::tint_luma(k) > 0.15f && glow::tint_luma(k) < 0.40f); }
  { volatile float z = 0; float m[3] = {z / z, 0.5f, 0.5f}; const glow::Tint k = glow::corner_target(m); CHECK(k.r == k.r && k.g == k.g && k.b == k.b); }
  // a dark picture glows fainter than a bright one of the same colour, both in range
  { float a[3] = {0.08f, 0.04f, 0.02f}, b[3] = {0.8f, 0.4f, 0.2f}; CHECK(glow::tint_luma(glow::corner_target(a)) < glow::tint_luma(glow::corner_target(b))); }
  // the masks: four masked halos add up to the one halo (see-through part), colours untouched
  const glow::Look look = glow::steady_look(0.7, 16.0 / 9.0);
  int iw, ih; glow::image_size(look, 160, &iw, &ih);
  static float halo[160 * 192 * 4], part[160 * 192 * 4], sum[160 * 192];
  glow::Grid white; glow::fill_grid(&white, 4, 3, 1, 1, 1);
  glow::render_target(white, look, iw, ih, halo);
  for (int i = 0; i < iw * ih; ++i) sum[i] = 0;
  for (int c = 0; c < 4; ++c) { glow::corner_mask(halo, iw, ih, c, part); for (int i = 0; i < iw * ih; ++i) { sum[i] += part[i * 4 + 3]; CHECK(part[i * 4] == halo[i * 4]); } }
  for (int i = 0; i < iw * ih; ++i) CHECK(fabs(sum[i] - halo[i * 4 + 3]) < 1e-5f);
  // stress: 200000 random pictures (random sizes, black bars, extreme values): every colour finite and 0..1, and the follow never steps more than its cap
  glow::Tint cur[4]; for (int c = 0; c < 4; ++c) cur[c] = glow::default_tint();
  long bad = 0; float biggest = 0;
  for (int n = 0; n < 200000; ++n) {
    glow::Grid r; r.w = 3 + (int)(rnd() * 22); r.h = 3 + (int)(rnd() * 22);
    const int kind = (int)(rnd() * 5);
    for (int i = 0; i < r.w * r.h * 3; ++i) r.c[i] = kind == 0 ? 0.0f : kind == 1 ? rnd() * 0.02f : kind == 2 ? 1.0f : rnd();
    if (kind == 3) for (int x = 0; x < r.w; ++x) for (int k = 0; k < 3; ++k) { r.c[x * 3 + k] = 0; r.c[((r.h - 1) * r.w + x) * 3 + k] = 0; }
    const glow::Insets ri = glow::bars(r);
    const double dt = 0.005 + rnd() * 0.05;
    for (int c = 0; c < 4; ++c) {
      float m[3]; glow::corner_mean(r, ri, c, m);
      const glow::Tint tg = glow::corner_target(m);
      const float* p = &tg.r; for (int k = 0; k < 3; ++k) if (!(p[k] >= 0.0f && p[k] <= 1.0f)) ++bad;
      const glow::Tint before = cur[c];
      glow::follow_tint(&cur[c], tg, dt, 1.3, 0.45);
      const float* a = &cur[c].r; const float* b = &before.r;
      for (int k = 0; k < 3; ++k) { const float d = (float)fabs(a[k] - b[k]); if (d > biggest) biggest = d; if (d > 0.45 * dt + 1e-6 || !(a[k] >= 0.0f && a[k] <= 1.0f)) ++bad; }
    }
  }
  printf("GLOWCORNERS STRESS: 200000 pictures x 4 corners, colours out of range or steps over the cap: %ld, biggest step of a colour in one frame %.4f\n", bad, biggest);
  CHECK(bad == 0);
  if (!fails) printf("glowcorners: ok\n");
  return fails ? 1 : 0;
}
