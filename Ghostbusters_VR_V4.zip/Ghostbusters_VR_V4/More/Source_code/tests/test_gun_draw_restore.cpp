// 1.7.117: the gun's drawn / holstered state across the game's temporary "no gun" gates (gungatemath.h DrawMemory).
#include "gungatemath.h"
#include <cassert>
int main() {
  gungate::DrawMemory m = {};
  assert(gungate::restore_on_gain(&m) == 0);        // the first gun of a session is in the hand (even though the gate holstered it while it waited)
  gungate::remember_loss(&m, 0);
  assert(gungate::restore_on_gain(&m) == 0);        // a cut-scene / level took a drawn gun: it comes back drawn
  gungate::remember_player_choice(&m, 1);           // the player puts it on his back
  gungate::remember_loss(&m, 1);
  assert(gungate::restore_on_gain(&m) == 1);        // a manual holster survives the next gate
  gungate::remember_player_choice(&m, 0);           // draws it again
  assert(gungate::restore_on_gain(&m) == 0);
  gungate::remember_loss(&m, 1);                    // lost while holstered
  assert(gungate::restore_on_gain(&m) == 1);
  return 0;
}
