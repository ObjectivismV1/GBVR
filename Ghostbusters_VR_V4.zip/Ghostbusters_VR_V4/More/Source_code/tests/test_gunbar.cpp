#include <stdio.h>
#include <math.h>
#include "gunbarmath.h"
#include <initializer_list>
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  CHECK(fabs(gunbar::fraction(50, 100) - 0.5) < 1e-9 && gunbar::fraction(100, 100) == 1.0 && gunbar::fraction(0, 100) == 0.0);
  CHECK(gunbar::fraction(1000, 100) < 0.0 && gunbar::fraction(-5, 100) < 0.0);   // not plausible
  CHECK(gunbar::fraction(0.4, 0.0) == 0.4);                                       // no maximum: the value is the fraction
  float c[3];
  gunbar::colour(1.0, c); CHECK(c[1] > c[0] && c[1] > c[2]);                      // green
  gunbar::colour(0.5, c); CHECK(c[0] > 0.9f && c[1] > 0.75f && c[2] < 0.2f);      // yellow
  gunbar::colour(0.0, c); CHECK(c[0] > c[1] && c[0] > c[2]);                      // red
  float a[3], b[3]; gunbar::colour(0.8, a); gunbar::colour(0.2, b); CHECK(a[1] > b[1] && a[0] < b[0]);   // greener at 0.8, redder at 0.2
  CHECK(gunbar::glow(0.9, 1.0) == 0.80f && gunbar::glow(0.1, 1.0) >= 0.7f - 1e-6f && gunbar::glow(0.1, 1.0) <= 1.0f);
  CHECK(gunbar::fill_len(0.0, 0.085) == 0.0 && gunbar::fill_len(0.01, 0.085) == 0.004 && fabs(gunbar::fill_len(1.0, 0.085) - 0.085) < 1e-12);
  for (int it : {1, 2, 3, 7}) { CHECK(gunbar::show_for_item(1, it)); CHECK(!gunbar::show_for_item(0, it)); }
  for (int it : {-2, -1, 0, 4, 5, 6, 8}) CHECK(!gunbar::show_for_item(1, it));
  printf(fails ? "FAILED\n" : "test_gunbar ok\n"); return fails;
}
