#include <stdio.h>
#include "gungatemath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  using namespace gungate;
  CHECK(raw(0, 0, 1) == 0 && raw(1, 1, 1) == 0 && raw(1, 0, 1) == 1 && raw(1, 0, 7) == 1 && raw(1, 0, 0) == 0);
  // 1.7.117 a knock-down (short forced move, gun equipped) changes nothing; a long one, or a forced move with no gun, still counts
  CHECK(raw_knock(1, 1, 1, 2.0, kKnockGraceS) == -1 && raw_knock(1, 1, 7, 5.9, kKnockGraceS) == -1);
  CHECK(raw_knock(1, 1, 1, 6.5, kKnockGraceS) == 0 && raw_knock(1, 1, 0, 1.0, kKnockGraceS) == 0 && raw_knock(0, 1, 1, 1.0, kKnockGraceS) == 0);
  CHECK(raw_knock(1, 0, 1, 0.0, kKnockGraceS) == 1 && raw_knock(1, 0, 0, 0.0, kKnockGraceS) == 0);
  { Gate g; reset(&g); g.stable = 1; double t = 0; int lost = 0; for (int i = 0; i < 400; ++i) { t += 0.011; if (step(&g, t, raw_knock(1, 1, 1, t, kKnockGraceS)) == kLost) lost = 1; } CHECK(!lost || t > 6.0); }
  CHECK(raw(1, 0, 5) == -1 && raw(1, 0, 4) == -1 && raw(1, 0, -1) == -1 && raw(1, 0, -2) == -1);
  Gate g; reset(&g);
  CHECK(!g.stable && blocked(g, 1) && !blocked(g, 0));
  // the game gives the gun: it takes kGainS of steady "allowed", then one Gained event
  CHECK(step(&g, 10.0, 1) == kNone);
  CHECK(step(&g, 10.3, 1) == kNone && !g.stable);
  CHECK(step(&g, 10.5, 1) == kGained && g.stable && !blocked(g, 1));
  CHECK(step(&g, 10.6, 1) == kNone);
  // a gun-to-gun switch (item stays a gun) and the PKE round trip change nothing
  CHECK(step(&g, 11.0, raw(1, 0, 5)) == kNone && g.stable);
  CHECK(step(&g, 20.0, raw(1, 0, 5)) == kNone && g.stable);
  // a short flicker of "not allowed" does not take the gun away
  CHECK(step(&g, 21.0, 0) == kNone && g.stable);
  CHECK(step(&g, 21.2, 1) == kNone && g.stable);
  CHECK(step(&g, 21.7, 0) == kNone);                 // the timer restarted
  CHECK(step(&g, 22.0, 0) == kNone && g.stable);
  CHECK(step(&g, 22.1, 0) == kLost && !g.stable && blocked(g, 1));
  CHECK(step(&g, 22.2, 0) == kNone);
  // allowed again, but a flicker shorter than kGainS does not unlock
  CHECK(step(&g, 30.0, 1) == kNone);
  CHECK(step(&g, 30.2, 0) == kNone);
  CHECK(step(&g, 30.4, 1) == kNone && !g.stable);
  CHECK(step(&g, 30.8, 1) == kNone);
  CHECK(step(&g, 30.95, 1) == kGained);
  // a neutral reading clears both timers
  reset(&g);
  CHECK(step(&g, 40.0, 1) == kNone); CHECK(step(&g, 40.3, -1) == kNone); CHECK(step(&g, 40.6, 1) == kNone && !g.stable);
  CHECK(step(&g, 41.1, 1) == kGained);
  CHECK(step(nullptr, 1.0, 1) == kNone);
  printf(fails ? "FAILED\n" : "test_gungate ok\n"); return fails;
}
