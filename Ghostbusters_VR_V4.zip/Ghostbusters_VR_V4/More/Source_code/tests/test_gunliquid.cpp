// 1.7.157 the gun's life tube: glowing liquid + beating heart (gunbarmath.h Liquid / step / build). Rules, then a long stress run.
#include <cstdio>
#include <cmath>
#include "gunbarmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static unsigned long long sd = 0x51EDC0FFEEULL;
static double rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (double)(sd >> 11) / 9007199254740992.0; }
static hand::Vertex vb[gunbar::kMaxVerts];
static const gunbar::Layout L = {-0.05f, -0.04f, -0.13f, 0.085f};
// checks one built mesh; returns the furthest-forward z of any bright green/yellow/red "liquid" vertex is not needed: returns vertex count, or -1 when broken
static int check_mesh(const gunbar::Liquid& s, long* bad) {
  hand::Mesh m = {vb, 0, gunbar::kMaxVerts};
  const int n = gunbar::build(&m, L, s);
  if (n != m.n || n <= 0 || n >= gunbar::kMaxVerts || n % 3) ++*bad;
  const float zRear = L.zc + L.lenM * 0.5f, zFront = L.zc - L.lenM * 0.5f;
  for (int i = 0; i < m.n; ++i) {
    const hand::Vertex& v = vb[i];
    for (int k = 0; k < 3; ++k) if (!(v.p[k] == v.p[k]) || !(v.n[k] == v.n[k])) ++*bad;
    for (int k = 0; k < 3; ++k) if (!(v.c[k] >= 0.0f && v.c[k] <= 1.0f)) ++*bad;
    if (v.c[3] != 0.0f && v.c[3] != 1.0f) ++*bad;
    // everything stays in a small box on the gun: 2.2 cm wide, 1.6 cm tall, from 1 cm in front of the tube to 2.6 cm behind it (the heart)
    if (fabsf(v.p[0] - L.xc) > 0.011f || v.p[1] < L.yc - 0.004f || v.p[1] > L.yc + 0.012f || v.p[2] < zFront - 0.010f || v.p[2] > zRear + 0.026f) ++*bad;
  }
  return n;
}
int main() {
  // colours: green when well, yellow in the middle, red when low; never dark
  float c[3];
  gunbar::liquid_colour(1.0, c); CHECK(c[1] > 0.95f && c[1] > c[0] * 3 && c[1] > c[2] * 3);
  gunbar::liquid_colour(0.5, c); CHECK(c[0] > 0.85f && c[1] > 0.80f && c[2] < 0.2f);
  gunbar::liquid_colour(0.22, c); CHECK(c[0] > 0.95f && c[1] > 0.3f && c[1] < 0.6f);
  gunbar::liquid_colour(0.0, c); CHECK(c[0] > 0.95f && c[1] < 0.15f);
  for (int i = 0; i <= 1000; ++i) { gunbar::liquid_colour(i / 1000.0, c); CHECK(c[0] >= 0 && c[0] <= 1 && c[1] >= 0 && c[1] <= 1 && c[2] >= 0 && c[2] <= 1 && (c[0] > 0.85f || c[1] > 0.85f)); }
  { float a[3], b[3]; double worst = 0; for (int i = 0; i < 1000; ++i) { gunbar::liquid_colour(i / 1000.0, a); gunbar::liquid_colour((i + 1) / 1000.0, b); for (int k = 0; k < 3; ++k) worst = fmax(worst, fabs(a[k] - b[k])); }
    CHECK(worst < 0.01); }   // the colour never jumps
  { volatile double z = 0; gunbar::liquid_colour(z / z, c); CHECK(c[0] == c[0]); }
  // the heart: resting size 1, two swells per beat, faster when low
  CHECK(gunbar::heart_scale(0.6) == 1.0 && gunbar::heart_scale(0.10) > 1.16 && gunbar::heart_scale(0.32) > 1.09 && gunbar::heart_scale(0.21) < gunbar::heart_scale(0.10));
  for (int i = -2000; i <= 2000; ++i) { const double h = gunbar::heart_scale(i / 500.0); CHECK(h >= 1.0 && h <= 1.18); }
  CHECK(fabs(gunbar::heart_bpm(1.0) - 62.0) < 1e-9 && fabs(gunbar::heart_bpm(0.0) - 150.0) < 1e-9 && gunbar::heart_bpm(0.3) > gunbar::heart_bpm(0.8));
  // the heart's outline: a closed shape seen from its middle without folding (every slice of the fan turns the same way), about 2 wide and 2 tall
  { double minx = 9, maxx = -9, miny = 9, maxy = -9; int sign = 0;
    for (int i = 0; i < gunbar::kHeartN; ++i) { double x0, y0, x1, y1; gunbar::heart_point(i, gunbar::kHeartN, &x0, &y0); gunbar::heart_point((i + 1) % gunbar::kHeartN, gunbar::kHeartN, &x1, &y1);
      const double cr = x0 * y1 - x1 * y0; if (fabs(cr) > 1e-9) { const int sg = cr > 0 ? 1 : -1; if (!sign) sign = sg; CHECK(sg == sign); }
      minx = fmin(minx, x0); maxx = fmax(maxx, x0); miny = fmin(miny, y0); maxy = fmax(maxy, y0); }
    CHECK(fabs(minx + 1.0) < 0.02 && fabs(maxx - 1.0) < 0.02 && maxy > 0.85 && maxy < 1.0 && miny < -0.85 && miny > -1.0);
    double x, y; gunbar::heart_point(0, gunbar::kHeartN, &x, &y); CHECK(fabs(x) < 1e-9 && y < maxy - 0.2);   // the notch is lower than the lobes
    gunbar::heart_point(gunbar::kHeartN / 2, gunbar::kHeartN, &x, &y); CHECK(fabs(x) < 1e-6 && fabs(y - miny) < 1e-9); }   // the point at the bottom
  const double dt = 1.0 / 90.0;
  // the level: starts where the health is; a hit drains it in about a fifth of a second, never below the health; the lost part shows pale, waits, then goes
  { gunbar::Liquid s; s.reset(); gunbar::step(&s, 0.8, dt); CHECK(s.shown == 0.8 && s.lost == 0.8 && s.slosh == 0.0);
    double prev = s.shown; int mono = 1; double at02 = 0, lostAt02 = 0, sloshMax = 0;
    for (int i = 0; i < 180; ++i) { gunbar::step(&s, 0.45, dt); if (s.shown > prev + 1e-12 || s.shown < 0.45 - 1e-12 || s.lost < s.shown - 1e-12) mono = 0; prev = s.shown; if (i == 17) { at02 = s.shown; lostAt02 = s.lost; } if (s.slosh > sloshMax) sloshMax = s.slosh; }
    CHECK(mono && at02 < 0.58 && at02 > 0.45 && fabs(lostAt02 - 0.8) < 1e-9);   // 0.2 s on: most of the way down, the pale part still whole
    CHECK(s.shown == 0.45 && s.lost == 0.45 && sloshMax > 0.9 && s.slosh < 0.06);   // 2 s on: settled
    // healing rises gently and never overshoots; no pale part, no slosh
    prev = s.shown; mono = 1; for (int i = 0; i < 270; ++i) { gunbar::step(&s, 0.9, dt); if (s.shown < prev - 1e-12 || s.shown > 0.9 + 1e-12) mono = 0; prev = s.shown; }
    CHECK(mono && s.shown == 0.9 && s.lost == 0.9 && s.slosh < 0.02); }
  // the same result whatever the frame rate (30, 72, 90, 144 FPS): the level 0.3 s after a hit within 2 % of each other
  { double v[4]; const double fps[4] = {30, 72, 90, 144};
    for (int k = 0; k < 4; ++k) { gunbar::Liquid s; s.reset(); gunbar::step(&s, 1.0, 0.01); for (double t = 0; t < 0.3 - 1e-9; t += 1.0 / fps[k]) gunbar::step(&s, 0.3, 1.0 / fps[k]); v[k] = s.shown; }
    for (int k = 1; k < 4; ++k) CHECK(fabs(v[k] - v[0]) < 0.02); }
  // dead: no beat, grey heart, no liquid; bad input is treated as empty, never as a crash
  { gunbar::Liquid s; s.reset(); gunbar::step(&s, 0.0, dt); for (int i = 0; i < 90; ++i) gunbar::step(&s, 0.0, dt); CHECK(s.beat == 0.0 && s.shown == 0.0);
    volatile double z = 0; gunbar::step(&s, z / z, z / z); gunbar::step(&s, 1e300, -5.0); gunbar::step(&s, -1e300, 1e300); CHECK(s.shown >= 0.0 && s.shown <= 1.0 && s.lost >= s.shown); }
  // the picture: the liquid's length follows the level (measured: the furthest-forward bright vertex of the liquid body), more vertices with liquid than without
  { long bad = 0; gunbar::Liquid s; s.reset(); gunbar::step(&s, 1.0, dt); const int nFull = check_mesh(s, &bad);
    gunbar::Liquid e; e.reset(); gunbar::step(&e, 0.0, dt); const int nEmpty = check_mesh(e, &bad);
    CHECK(bad == 0 && nFull > nEmpty && nFull < gunbar::kMaxVerts - 50);
    printf("gunliquid: %d vertices full, %d empty (room for %d)\n", nFull, nEmpty, (int)gunbar::kMaxVerts); }
  // stress: 4 hours of random play at 20..240 FPS: hits, heals, death, respawn, pauses (the bar away), wild inputs. Every frame's state and every 7th frame's
  // whole mesh are checked: level between 0 and 1, never under the real health while draining, the pale part never behind the level, all vertices in the box.
  { gunbar::Liquid s; s.reset(); long bad = 0, frames = 0, meshes = 0, hits = 0; double t = 0, hp = 1.0; int maxN = 0;
    while (t < 4.0 * 3600.0) {
      double d = 1.0 / (20.0 + rnd() * 220.0); if (rnd() < 0.003) d += rnd() * 0.5; if (rnd() < 0.0003) { d += 3.0; s.reset(); }
      t += d; ++frames;
      const double r = rnd();
      if (r < 0.004) { hp -= rnd() * 0.45; if (hp < 0) hp = 0; ++hits; } else if (r < 0.006) hp = hp + rnd() * 0.4 > 1 ? 1 : hp + rnd() * 0.4; else if (r < 0.0063) hp = 0; else if (r < 0.0068) hp = 1; else if (hp > 0 && hp < 1) hp = hp + 0.02 * d > 1 ? 1 : hp + 0.02 * d;
      double in = hp; if (r > 0.9995) { volatile double z = 0; in = r > 0.9998 ? z / z : 7.0; }
      const double before = s.shown; const int had = s.have;
      gunbar::step(&s, in, d > 0.25 ? 0.25 : d);
      const double tgt = in == in ? (in > 1 ? 1 : in < 0 ? 0 : in) : 0.0;
      if (!(s.shown >= 0.0 && s.shown <= 1.0) || !(s.lost >= s.shown - 1e-12 && s.lost <= 1.0) || !(s.slosh >= 0.0 && s.slosh <= 1.0) || !(s.beat >= 0.0 && s.beat < 1.0) || !(s.t >= 0.0)) ++bad;
      if (had && ((before >= tgt && (s.shown < tgt - 1e-12 || s.shown > before + 1e-12)) || (before <= tgt && (s.shown > tgt + 1e-12 || s.shown < before - 1e-12)))) ++bad;   // it only ever moves toward the health, never past it
      if (frames % 7 == 0) { const int n = check_mesh(s, &bad); if (n > maxN) maxN = n; ++meshes; }
    }
    printf("GUNLIQUID STRESS: %ld frames (4 hours, 20..240 FPS), %ld hits, %ld whole meshes checked (most vertices %d of %d): broken %ld\n", frames, hits, meshes, maxN, (int)gunbar::kMaxVerts, bad);
    CHECK(bad == 0); }
  if (!fails) printf("gunliquid: ok\n");
  return fails ? 1 : 0;
}
