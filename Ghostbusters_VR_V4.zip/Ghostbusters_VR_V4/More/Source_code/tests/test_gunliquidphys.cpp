// 1.7.162 the gun tube's liquid physics (gunbarmath.h step_phys): level surface at rest, tilts the right way, overshoots and settles like water, a swing stirs it,
// tracking jumps / NaN poses never shove it, 4 hours of random play at 20..240 FPS stay finite and bounded, and the ghosts' vials are untouched.
#include <cstdio>
#include <cmath>
#include "fightmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static unsigned long long sd = 0x243F6A8885A308D3ULL;
static double rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (double)(sd >> 11) / 9007199254740992.0; }
// a pose: the gun pitched by p degrees (barrel up = +), rolled by r degrees, at position (x,y,z). Gun axes: x side, y up, z rear (barrel -z).
static void pose(double pitch, double roll, double x, double y, double z, float* P) {
  const double a = pitch * 3.14159265358979 / 180.0, b = roll * 3.14159265358979 / 180.0;
  // R = Rx(pitch) * Rz(roll); columns = the gun's axes in the room
  const double ca = cos(a), sa = sin(a), cb = cos(b), sb = sin(b);
  const double Rz[9] = {cb, -sb, 0, sb, cb, 0, 0, 0, 1}, Rx[9] = {1, 0, 0, 0, ca, -sa, 0, sa, ca};
  double R[9]; for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { R[i * 3 + j] = 0; for (int k = 0; k < 3; ++k) R[i * 3 + j] += Rx[i * 3 + k] * Rz[k * 3 + j]; }
  for (int i = 0; i < 3; ++i) { P[i * 4] = (float)R[i * 3]; P[i * 4 + 1] = (float)R[i * 3 + 1]; P[i * 4 + 2] = (float)R[i * 3 + 2]; }
  P[3] = (float)x; P[7] = (float)y; P[11] = (float)z;
}
static void settle(gunbar::Liquid* s, const float* P, double secs) { for (double t = 0; t < secs; t += 1.0 / 90) gunbar::step_phys(s, P, 1.0 / 90); }
int main() {
  float P[12];
  { gunbar::Liquid s; s.reset(); pose(0, 0, 0, 1.2, 0, P); settle(&s, P, 4.0); CHECK(fabs(s.sx) < 0.01 && fabs(s.sy) < 0.01); }   // level gun at rest: a flat surface
  { gunbar::Liquid s; s.reset(); pose(15, 0, 0, 1.2, 0, P); settle(&s, P, 5.0);   // barrel up: the liquid's top recedes toward the rear (z grows with y)
    CHECK(s.sy > 0.3 && fabs(s.sx) < 0.05); printf("  barrel up 15 deg: tilt %.2f\n", s.sy); }
  { gunbar::Liquid s; s.reset(); pose(-15, 0, 0, 1.2, 0, P); settle(&s, P, 5.0); CHECK(s.sy < -0.3); }   // barrel down: the other way
  { gunbar::Liquid s; s.reset(); pose(15, 0, 0, 1.2, 0, P); settle(&s, P, 0.08); const double early = s.sy; settle(&s, P, 0.12); double peak = 0; for (double t = 0; t < 1.0; t += 1.0 / 90) { gunbar::step_phys(&s, P, 1.0 / 90); if (s.sy > peak) peak = s.sy; }
    gunbar::Liquid r; r.reset(); settle(&r, P, 6.0);
    CHECK(early < r.sy && peak > r.sy * 1.15); printf("  overshoot: settles at %.2f, peak %.2f\n", r.sy, peak); }   // it lags, then overshoots like water
  { gunbar::Liquid s; s.reset(); pose(0, 0, 0, 1.2, 0, P); settle(&s, P, 1.0);   // a hard swing sideways stirs it, then it calms
    for (int i = 0; i < 9; ++i) { pose(0, 0, 0.6 * sin(i * 0.7), 1.2, 0, P); gunbar::step_phys(&s, P, 1.0 / 90); }
    CHECK(s.agit > 0.3 || s.slosh > 0.2); pose(0, 0, 0, 1.2, 0, P); settle(&s, P, 6.0); CHECK(s.agit < 0.05 && fabs(s.sx) < 0.05); }
  { gunbar::Liquid s; s.reset(); pose(0, 0, 0, 1.2, 0, P); settle(&s, P, 2.0);   // a recentre / tracking jump of 3 m: no shove
    pose(0, 0, 3.0, 1.2, 2.0, P); for (int i = 0; i < 30; ++i) gunbar::step_phys(&s, P, 1.0 / 90); CHECK(fabs(s.sx) < 0.02 && fabs(s.sy) < 0.02 && s.agit < 0.05);
    float B[12]; for (int i = 0; i < 12; ++i) B[i] = P[i]; B[5] = NAN; gunbar::step_phys(&s, B, 1.0 / 90); CHECK(s.sx == s.sx && s.phys == 0); }
  {   // 1.7.166 "very unsteady and flickers": aiming with a normal hand (3 mm tremor, 2 deg wobble, slow turns) keeps the surface calm
    gunbar::Liquid s; s.reset(); double worstStep = 0, prev = 0; int first = 1; double t = 0;
    for (int i = 0; i < 90 * 60; ++i) {
      t += 1.0 / 90; const double pitch = 10 + 8 * sin(t * 0.7) + (rnd() - 0.5) * 2.0, roll = (rnd() - 0.5) * 2.0;
      pose(pitch, roll, (rnd() - 0.5) * 0.003, 1.2 + (rnd() - 0.5) * 0.003, (rnd() - 0.5) * 0.003, P); gunbar::step_phys(&s, P, 1.0 / 90);
      const double tl = sqrt(s.sx * s.sx + s.sy * s.sy); if (!first && i > 90) worstStep = fmax(worstStep, fabs(tl - prev)); prev = tl; first = 0;
    }
    CHECK(worstStep < 0.02 && s.agit < 0.05);
    printf("  aiming for a minute: the surface tilt moves at most %.4f per frame, stirred %.2f\n", worstStep, s.agit);
  }
  {   // a full tube shows no tilted surface (nothing to tilt), whatever the gun does
    gunbar::Liquid s; s.reset(); gunbar::step(&s, 1.0, 0.01); s.sx = 1.2; s.sy = -1.2; s.slosh = 1.0;
    static hand::Vertex vb2[gunbar::kMaxVerts]; hand::Mesh m = {vb2, 0, gunbar::kMaxVerts}; const gunbar::Layout L = {0.0f, 0.0f, -0.13f, 0.085f};
    gunbar::Liquid s0 = s; s0.sx = 0; s0.sy = 0; s0.slosh = 0;
    static hand::Vertex vb3[gunbar::kMaxVerts]; hand::Mesh m0 = {vb3, 0, gunbar::kMaxVerts};
    const int n1 = gunbar::build(&m, L, s), n0 = gunbar::build(&m0, L, s0);
    int same = n1 == n0; for (int i = 0; same && i < n1; ++i) for (int k = 0; k < 3; ++k) if (fabs(vb2[i].p[k] - vb3[i].p[k]) > 1e-6f) same = 0;
    CHECK(same);
  }
  {   // 4 hours of random play: hand jitter, swings, turns, hitches, tracking loss, 20..240 FPS
    gunbar::Liquid s; s.reset(); long frames = 0, bad = 0; double worst = 0, t = 0; double pitch = 0, roll = 0, x = 0, y = 1.2, z = 0;
    static hand::Vertex vb[gunbar::kMaxVerts];
    while (t < 4 * 3600.0) {
      const double fps = 20 + rnd() * 220; double dt = 1.0 / fps; if (rnd() < 0.001) dt = rnd() * 0.6;
      pitch += (rnd() - 0.5) * 6; roll += (rnd() - 0.5) * 6; if (pitch > 80) pitch = 80; if (pitch < -80) pitch = -80; if (roll > 180) roll -= 360; if (roll < -180) roll += 360;
      x += (rnd() - 0.5) * 0.02; y += (rnd() - 0.5) * 0.02; z += (rnd() - 0.5) * 0.02; if (rnd() < 0.0005) { x += 4; z -= 3; }
      pose(pitch, roll, x, y, z, P); if (rnd() < 0.0002) P[(int)(rnd() * 12)] = NAN;
      gunbar::step(&s, rnd() < 0.999 ? s.target : rnd(), dt); gunbar::step_phys(&s, P, dt); t += dt; ++frames;
      if (!(s.sx == s.sx && s.sy == s.sy && s.agit == s.agit) || fabs(s.sx) > gunbar::kMaxTilt * 1.41 || fabs(s.sy) > gunbar::kMaxTilt * 1.41 || s.agit < 0 || s.agit > 1.0) ++bad;
      if (fabs(s.sx) > worst) worst = fabs(s.sx); if (fabs(s.sy) > worst) worst = fabs(s.sy);
      if ((frames % 5000) == 0) {   // the mesh stays inside the tube: every vertex finite, the liquid surface between the tube's ends
        hand::Mesh m = {vb, 0, gunbar::kMaxVerts}; const gunbar::Layout L = {0.0f, 0.0f, -0.13f, 0.085f}; const int n = gunbar::build(&m, L, s);
        if (n <= 0 || n % 3 || n >= gunbar::kMaxVerts) ++bad;
        for (int i = 0; i < n; ++i) for (int k = 0; k < 3; ++k) if (!(vb[i].p[k] == vb[i].p[k]) || fabs(vb[i].p[k] + (k == 2 ? 0.13f : 0.0f)) > 0.08f) ++bad;
      }
    }
    CHECK(bad == 0);
    printf("GUNLIQUIDPHYS STRESS: %ld frames (4 hours, 20..240 FPS, jumps, NaN poses, hitches): broken %ld, largest tilt %.2f (cap %.1f)\n", frames, bad, worst, gunbar::kMaxTilt);
  }
  {   // the ghosts' vials never move with the gun: a vial built from a liquid with physics set looks exactly like one without
    fight::Bar b[1]; b[0].p[0] = 0; b[0].p[1] = 0.2f; b[0].p[2] = 4; b[0].radius = 1; b[0].flags = 0; b[0].actor = 1; b[0].frac = 0.6f;
    gunbar::Liquid a[1], c[1]; a[0].reset(); gunbar::step(&a[0], 0.6, 0.01); c[0] = a[0]; c[0].sx = 2.0; c[0].sy = -1.5; c[0].vx = 3; c[0].phys = 2;
    fight::Look lk; lk.sizePct = 100; lk.digitsFocus = 0; lk.focusDeg = 7; lk.ringStyle = 0; lk.liquid = 1;
    static cord::V v1[3000], v2[3000];
    lk.liq = a; const int n1 = fight::build(b, 1, 0.0, lk, v1, 3000); lk.liq = c; const int n2 = fight::build(b, 1, 0.0, lk, v2, 3000);
    int same = n1 == n2 && n1 > 0; for (int i = 0; same && i < n1; ++i) for (int k = 0; k < 3; ++k) if (v1[i].p[k] != v2[i].p[k]) same = 0;
    CHECK(same);
  }
  printf("%s gun liquid physics, %d failures\n", fails ? "FAIL" : "PASS", fails);
  return fails ? 1 : 0;
}
