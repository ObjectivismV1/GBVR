// 1.7.170 gun tube shift kept in the controller frame: steady while the hand turns fast, survives a 30+ cm gap, holds back one-frame spikes.
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "gunshift.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static void rotyx(double y, double x, float* r) {   // yaw then pitch, row-major
  double cy = cos(y), sy = sin(y), cx = cos(x), sx = sin(x);
  double Ry[9] = {cy, 0, sy, 0, 1, 0, -sy, 0, cy}, Rx[9] = {1, 0, 0, 0, cx, -sx, 0, sx, cx};
  for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { double v = 0; for (int k = 0; k < 3; ++k) v += Ry[i * 3 + k] * Rx[k * 3 + j]; r[i * 3 + j] = (float)v; }
}
static double rnd() { return rand() / (double)RAND_MAX - 0.5; }
int main() {
  using namespace gunshift;
  const float G[3] = {0.02f, 0.05f, -0.29f};   // true gap in the controller frame (~30 cm, over the old 30 cm check)
  for (int lagFrames = 0; lagFrames <= 2; ++lagFrames) {
    Filter f; f.reset(); double oldSh[3] = {0, 0, 0}; int oldHave = 0;
    double worstNew = 0, worstOld = 0; float rHist[4][9];
    for (int n = 0; n < 900; ++n) {   // 10 s at 90 Hz, hand waving +-70 deg at 1.5 Hz
      const double t = n / 90.0; float r[9]; rotyx(1.2 * sin(2 * 3.14159 * 1.5 * t), 0.6 * sin(2 * 3.14159 * 1.1 * t), r);
      for (int k = 3; k > 0; --k) for (int i = 0; i < 9; ++i) rHist[k][i] = rHist[k - 1][i];
      for (int i = 0; i < 9; ++i) rHist[0][i] = r[i];
      const float* rm = rHist[n >= lagFrames ? lagFrames : 0];   // the game measured with an older hand turn
      float trueEye[3]; to_eye(r, G, trueEye);
      float meas[3]; to_eye(rm, G, meas); for (int i = 0; i < 3; ++i) meas[i] += (float)(rnd() * 0.01);
      if (n == 400) for (int i = 0; i < 3; ++i) meas[i] += 0.5f;   // one wild sample
      float lo[3]; to_local(r, meas, lo); feed(f, lo, 1.0 / 90.0);
      float sh[3]; to_eye(r, f.lo, sh);
      // old 1.7.167: eye space, 50 ms smoothing, 30 cm check
      double L2 = meas[0] * meas[0] + meas[1] * meas[1] + meas[2] * meas[2];
      if (L2 < 0.09) { double k = oldHave ? (1.0 / 90) / (0.05 + 1.0 / 90) : 1.0; for (int i = 0; i < 3; ++i) oldSh[i] += (meas[i] - oldSh[i]) * k; oldHave = 1; }
      if (n > 90) {
        double en = 0, eo = 0; for (int i = 0; i < 3; ++i) { en += (sh[i] - trueEye[i]) * (sh[i] - trueEye[i]); eo += (oldSh[i] - trueEye[i]) * (oldSh[i] - trueEye[i]); }
        if (sqrt(en) > worstNew) worstNew = sqrt(en);
        if (sqrt(eo) > worstOld) worstOld = sqrt(eo);
      }
    }
    printf("lag %d frames: tube off the drawn gun at most %.1f cm now, %.1f cm with the 1.7.167 way\n", lagFrames, worstNew * 100, worstOld * 100);
    CHECK(worstNew < (lagFrames == 0 ? 0.01 : 0.035 * lagFrames + 0.01));
    CHECK(worstNew < worstOld * 0.6);
    CHECK(f.rejected >= 1);   // the wild sample was limited
  }
  {   // the game's hold really changes: followed within ~1.5 s
    Filter f; f.reset(); float a[3] = {0, 0.05f, -0.25f}, b[3] = {0, 0.05f, -0.15f};
    for (int n = 0; n < 90; ++n) feed(f, a, 1.0 / 90);
    int n = 0; for (; n < 400; ++n) { feed(f, b, 1.0 / 90); float d[3] = {f.lo[0] - b[0], f.lo[1] - b[1], f.lo[2] - b[2]}; if (len3(d) < 0.01) break; }
    printf("hold change followed in %.2f s\n", n / 90.0);
    CHECK(n < 160);
  }
  {   // a gap past 45 cm never moves the tube
    Filter f; f.reset(); float far_[3] = {0, 0, -0.6f}; feed(f, far_, 0.01); CHECK(!f.have);
  }
  {   // 1.7.172 recheck against the 1.7.170 report: about 37 % of the samples were held back (noise of several cm from the game thread's lag).
      // With that much noise the kept gap must still settle on the true gap and stay there (never stuck on an early outlier, never walking off).
    double worst = 0, worstStep = 0; long held = 0, fed = 0;
    for (int run = 0; run < 300; ++run) {
      Filter f; f.reset(); const float G[3] = {(float)(rnd() * 0.1), (float)(rnd() * 0.1), (float)(-0.27 + rnd() * 0.06)};
      const double sigma = 0.02 + (run % 5) * 0.006;   // 2 .. 4.4 cm on each axis (the 1.7.170 report fits about 3.7 cm: 37 % of the samples more than 6 cm off)
      float prev[3] = {0, 0, 0};
      for (int n = 0; n < 2700; ++n) {   // 30 s
        float sm[3]; for (int i = 0; i < 3; ++i) sm[i] = G[i] + (float)((rnd() + rnd() + rnd() + rnd()) * sigma * 1.73);   // near-normal noise
        if (rnd() + 0.5 < 0.01) sm[2] += 0.4f;                       // a wild sample now and then
        double dt = 1.0 / 90; if (rnd() + 0.5 < 0.005) dt = 0.3;      // a gap in the samples (hands away, PKE out)
        const int took = feed(f, sm, dt); ++fed; if (!took) ++held;
        if (n > 450) { float d[3] = {f.lo[0] - G[0], f.lo[1] - G[1], f.lo[2] - G[2]}; if (len3(d) > worst) worst = len3(d);
          float st[3] = {f.lo[0] - prev[0], f.lo[1] - prev[1], f.lo[2] - prev[2]}; if (len3(st) > worstStep) worstStep = len3(st); }
        for (int i = 0; i < 3; ++i) prev[i] = f.lo[i];
        CHECK(f.lo[0] == f.lo[0] && f.lo[1] == f.lo[1] && f.lo[2] == f.lo[2]);
      }
    }
    printf("noisy samples: %ld of %ld limited (%.0f %%), kept gap at most %.1f cm from the true one after 5 s, biggest move in one frame %.2f cm\n", held, fed, 100.0 * held / fed, worst * 100, worstStep * 100);
    CHECK(worst < 0.03 && worstStep < 0.01);   // 1.7.176: a faster follow (tau 0.15 s) lets a little more noise through
  }
  {   // wrong numbers never get in
    Filter f; f.reset(); volatile float z = 0; float nan[3] = {z / z, 0, 0}, ok[3] = {0, 0, -0.3f}, inf[3] = {1e30f, 0, 0};
    CHECK(!feed(f, nan, 0.01) && !f.have && !feed(f, inf, 0.01) && feed(f, ok, z / z) && f.have && !feed(f, nan, 0.01) && feed(f, ok, -5.0) && feed(f, ok, 1e9));
    CHECK(f.lo[2] == -0.3f && f.lo[0] == 0.0f);
  }
  printf("%s\n", fails ? "FAILED" : "ok");
  return fails ? 1 : 0;
}
