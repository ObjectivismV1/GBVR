// 1.7.186 STRESS TEST of the health tube lock (gunshift::take, gun_hp_rigid=1).
// "stress test health tube to make sure it does not fall behind and is locked": the drawn gun sits at the controller plus a hold gap that CHANGES in steps
// (a grab with the other hand moves the gun 5-7 cm; a release moves it back) while the hand swings fast. The game's samples come at a lower rate than the
// pictures, a frame late, with noise, with wild ones (out of range or wrong but in range), and some are not numbers.
// Measured: how far the tube is from the drawn gun's muzzle, how long after a step until it is within 1.5 cm, and the same for the old filter (feed).
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "gunshift.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double rnd() { return rand() / (double)RAND_MAX - 0.5; }
static void rotyx(double y, double x, float* r) {
  double cy = cos(y), sy = sin(y), cx = cos(x), sx = sin(x);
  double Ry[9] = {cy, 0, sy, 0, 1, 0, -sy, 0, cy}, Rx[9] = {1, 0, 0, 0, cx, -sx, 0, sx, cx};
  for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { double v = 0; for (int k = 0; k < 3; ++k) v += Ry[i * 3 + k] * Rx[k * 3 + j]; r[i * 3 + j] = (float)v; }
}
struct Run { double worst, steady, recoverMsWorst; long samples; };
// mode 0: take (1.7.185/186), mode 1: the old feed (learns only while the hand is slow)
static Run run(int mode, int sampleEvery, int lagFrames, double noise, double speedAmp, unsigned seed, int withWild) {
  using namespace gunshift;
  srand(seed);
  Filter f; f.reset();
  float G[3] = {0.02f, 0.05f, -0.29f}, Gnext[3];
  Run out = {0, 0, 0, 0};
  double errSum = 0; long errN = 0; int sinceStep = -1000; double recWorst = 0; bool recovered = true; int stepAt = 0;
  float rHist[8][9]; double pHist[8][3] = {{0}};
  double prev[3] = {0, 0, 0}, spd = 0;
  for (int n = 0; n < 90 * 40; ++n) {   // 40 s at 90 Hz
    const double t = n / 90.0;
    float r[9]; rotyx(1.2 * sin(2 * 3.14159 * 1.5 * t), 0.6 * sin(2 * 3.14159 * 1.1 * t), r);
    const double p[3] = {speedAmp * sin(2 * 3.14159 * 1.3 * t), speedAmp * 0.5 * sin(2 * 3.14159 * 0.9 * t), 0};
    for (int k = 7; k > 0; --k) { for (int i = 0; i < 9; ++i) rHist[k][i] = rHist[k - 1][i]; for (int i = 0; i < 3; ++i) pHist[k][i] = pHist[k - 1][i]; }
    for (int i = 0; i < 9; ++i) rHist[0][i] = r[i]; for (int i = 0; i < 3; ++i) pHist[0][i] = p[i];
    if (n % 271 == 137) {   // a grab or a release: the hold moves the gun 5-7 cm
      const double a = (n / 271) % 2 ? -1.0 : 1.0, m = 0.05 + 0.02 * (rnd() + 0.5);
      for (int i = 0; i < 3; ++i) Gnext[i] = G[i];
      Gnext[0] += (float)(a * m * 0.5); Gnext[1] += (float)(a * m * 0.6); Gnext[2] += (float)(a * m * 0.6);
      for (int i = 0; i < 3; ++i) G[i] = Gnext[i];
      sinceStep = 0; recovered = false; stepAt = n;
    }
    // the drawn gun is drawn with the pose of 'lagFrames' ago (the game's tick); the tube uses the same stale pose (the game's own wand matrix)
    const float* rd = rHist[lagFrames]; const double* pd = pHist[lagFrames];
    float Ge[3]; gunshift::to_eye(rd, G, Ge);
    if (n % sampleEvery == 0) {   // a new game sample: the drawn muzzle minus the controller's muzzle, in the controller frame
      float meas[3]; for (int i = 0; i < 3; ++i) meas[i] = Ge[i] + (float)(rnd() * noise);
      if (withWild && n % 97 == 0) { meas[0] += 0.9f; }               // out of range: rejected
      if (withWild && n % 211 == 0) { meas[1] += 0.12f; }             // in range but wrong: one sample
      if (withWild && n % 307 == 0) { meas[2] = NAN; }                // not a number
      float lo[3]; gunshift::to_local(rd, meas, lo);
      if (mode == 0) { double j; take(f, lo, &j); }
      else { double sdt = sampleEvery / 90.0; (void)sdt; if (!f.have || spd < 0.25) feed(f, lo, sampleEvery / 90.0); }
      ++out.samples;
    }
    { double dx = pd[0] - prev[0], dy = pd[1] - prev[1]; spd += (sqrt(dx * dx + dy * dy) * 90.0 - spd) * 0.3; prev[0] = pd[0]; prev[1] = pd[1]; }
    float sh[3] = {0, 0, 0}; if (f.have) gunshift::to_eye(rd, f.lo, sh);
    const double err = sqrt((double)(sh[0] - Ge[0]) * (sh[0] - Ge[0]) + (double)(sh[1] - Ge[1]) * (sh[1] - Ge[1]) + (double)(sh[2] - Ge[2]) * (sh[2] - Ge[2]));
    if (n > 90 && err == err) {
      if (err > out.worst) out.worst = err;
      if (sinceStep > 40 || sinceStep < 0) { errSum += err; ++errN; }   // steady state: not within 0.45 s after a step
    }
    if (sinceStep >= 0) ++sinceStep;
    if (!recovered && err < 0.015) { recovered = true; const double ms = (n - stepAt) * 1000.0 / 90.0; if (ms > recWorst) recWorst = ms; }
    if (!recovered && n - stepAt > 80) { recovered = true; recWorst = 9999; }
  }
  out.steady = errN ? errSum / errN : 0; out.recoverMsWorst = recWorst;
  return out;
}
int main() {
  // the pictures run at 90 Hz; the game's samples come every 3rd picture (30 Hz) or every 2nd (45 Hz), a frame or two late, hand swinging fast
  const int every[3] = {1, 2, 3};
  for (int e = 0; e < 3; ++e) for (int lag = 0; lag <= 2; ++lag) {
    double worstRec = 0, worstSteady = 0, worst = 0;
    for (unsigned seed = 1; seed <= 6; ++seed) {
      Run a = run(0, every[e], lag, 0.004, 0.5, seed, 1);
      if (a.recoverMsWorst > worstRec) worstRec = a.recoverMsWorst;
      if (a.steady > worstSteady) worstSteady = a.steady;
      if (a.worst > worst) worst = a.worst;
    }
    Run o = run(1, every[e], lag, 0.004, 0.5, 1, 1);
    printf("sample every %d pictures, %d late: take: steady error %.1f mm, worst %.1f cm, back within 1.5 cm after a grab in %.0f ms | old filter: steady %.1f mm, back in %.0f ms\n",
           every[e], lag, worstSteady * 1000, worst * 100, worstRec, o.steady * 1000, o.recoverMsWorst);
    CHECK(worstSteady < 0.006);                    // steady: within 6 mm of the drawn muzzle
    CHECK(worstRec <= 1000.0 * (every[e] + 1.0) / 90.0 + 12.0);   // after a grab: within about one sample interval, never a second
    CHECK(worst < 0.085);                          // never more off than the grab itself (5-7 cm, for the one picture before the next sample): the lone 12 cm wrong sample is not believed
    CHECK(o.recoverMsWorst > worstRec || worstRec < 50.0);        // better than (or as good as) the old filter
  }
  // a wrong sample must not stay: one in-range outlier is gone with the next sample
  { gunshift::Filter f; f.reset(); float g[3] = {0.02f, 0.05f, -0.29f}, w[3] = {0.02f, 0.17f, -0.29f}; double j;
    gunshift::take(f, g, &j); gunshift::take(f, w, &j); gunshift::take(f, g, &j);
    CHECK(fabs(f.lo[1] - 0.05f) < 1e-5); CHECK(f.used == 2); }
  // a real big change (a different gun, 15 cm) is taken with the second agreeing sample
  { gunshift::Filter f; f.reset(); float a[3] = {0, 0.05f, -0.29f}, b[3] = {0, 0.20f, -0.29f}, b2[3] = {0.005f, 0.20f, -0.29f}; double j;
    gunshift::take(f, a, &j); CHECK(gunshift::take(f, b, &j) == 0 && fabs(f.lo[1] - 0.05f) < 1e-6);
    CHECK(gunshift::take(f, b2, &j) == 1 && fabs(f.lo[1] - 0.20f) < 1e-5); }
  // two far samples that disagree: none taken
  { gunshift::Filter f; f.reset(); float a[3] = {0, 0.05f, -0.29f}, b[3] = {0, 0.20f, -0.29f}, c[3] = {0.1f, -0.1f, -0.2f}; double j;
    gunshift::take(f, a, &j); gunshift::take(f, b, &j); CHECK(gunshift::take(f, c, &j) == 0 && fabs(f.lo[1] - 0.05f) < 1e-6); }
  // not a number / out of range: nothing changes
  { gunshift::Filter f; f.reset(); float g[3] = {0.02f, 0.05f, -0.29f}, nn[3] = {NAN, 0, 0}, ii[3] = {INFINITY, 0, 0}, big[3] = {0.5f, 0.5f, 0.5f}; double j = 0;
    gunshift::take(f, g, &j); const float before = f.lo[2];
    CHECK(gunshift::take(f, nn, &j) == 0); CHECK(gunshift::take(f, ii, &j) == 0); CHECK(gunshift::take(f, big, &j) == 0);
    CHECK(f.lo[2] == before && f.have == 1 && f.rejected == 3); }
  // small noise is followed 60 %, a real step is taken whole
  { gunshift::Filter f; f.reset(); float a[3] = {0, 0, -0.30f}, b[3] = {0.01f, 0, -0.30f}, c[3] = {0.07f, 0, -0.30f}; double j;
    gunshift::take(f, a, &j); gunshift::take(f, b, &j); CHECK(fabs(f.lo[0] - 0.006f) < 1e-5);
    gunshift::take(f, c, &j); CHECK(fabs(f.lo[0] - 0.07f) < 1e-6 && j > 0.06); }
  // fuzz: random samples never produce a NaN or a gap over the limit
  { gunshift::Filter f; f.reset(); srand(7); double j;
    for (int i = 0; i < 100000; ++i) { float s[3] = {(float)(rnd() * 2), (float)(rnd() * 2), (float)(rnd() * 2)}; if (i % 13 == 0) s[i % 3] = NAN; if (i % 17 == 0) s[(i + 1) % 3] = INFINITY; gunshift::take(f, s, &j);
      CHECK(f.lo[0] == f.lo[0] && f.lo[1] == f.lo[1] && f.lo[2] == f.lo[2]); if (!f.have) continue; CHECK(gunshift::len3(f.lo) < gunshift::kMaxM + 1e-4); } }
  if (fails) { printf("%d FAILED\n", fails); return 1; }
  printf("ok\n"); return 0;
}
