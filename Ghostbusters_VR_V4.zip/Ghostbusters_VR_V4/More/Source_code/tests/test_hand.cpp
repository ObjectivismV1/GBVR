// Unit tests for handmath.h (0.34 hands and wand in the eye pictures).
#include <stdio.h>
#include <math.h>
#include "handmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static void ident34(float* p, float x, float y, float z) {
  for (int i = 0; i < 12; ++i) p[i] = 0;
  p[0] = p[5] = p[10] = 1; p[3] = x; p[7] = y; p[11] = z;
}
int main() {
  using namespace hand;
  // Grip -> steer -> release while still beside the barrel: proximity must
  // neither begin nor prolong steering. Re-gripping uses the normal debounce.
  {
    SupportHold hold;
    for (int i = 0; i < 100; ++i) CHECK(!hold.step(support_requested(0, 1, 1), 1));
    CHECK(!hold.step(support_requested(1, 1, 1), 1));
    CHECK(!hold.step(support_requested(1, 1, 1), 1));
    CHECK(hold.step(support_requested(1, 1, 1), 1));
    CHECK(!hold.step(support_requested(0, 1, 1), 1));
    for (int i = 0; i < 100; ++i) CHECK(!hold.step(support_requested(0, 1, 1), 1));
    CHECK(!hold.step(1, 1)); CHECK(!hold.step(1, 1)); CHECK(hold.step(1, 1));
    CHECK(!hold.step(1, 0)); // tracking/geometry loss also releases
    CHECK(support_requested(0, 1, 0)); // legacy right-only steadiness retained
  }
  float head[12], dev[12], e[3];
  Xform x;
  ident34(head, 0, 1.6f, 0);
  ident34(dev, 0, 1.6f, -0.5f);                 // 0.5 m straight ahead of the head (OpenVR: -z is forward)
  CHECK(model_to_eye(head, dev, nullptr, 0, &x));
  float o[3] = {0, 0, 0};
  apply(x, o, e); CHECK(fabs(e[0]) < 1e-6 && fabs(e[1]) < 1e-6 && fabs(e[2] - 0.5) < 1e-6);
  double nx, ny; CHECK(project(e, 1.0, 1.0, &nx, &ny)); CHECK(fabs(nx) < 1e-6 && fabs(ny) < 1e-6);
  // a point 0.5 m to the right of the controller appears to the right of the centre
  float pr[3] = {0.5f, 0, 0}; apply(x, pr, e); CHECK(e[0] > 0.49); CHECK(project(e, 1.0, 1.0, &nx, &ny) && nx > 0.9);
  // wand forward (-z in the model) points away from the viewer (+z in eye space)
  float pf[3] = {0, 0, -0.3f}; apply(x, pf, e); CHECK(fabs(e[2] - 0.8) < 1e-5);
  // up stays up
  float pu[3] = {0, 0.1f, 0}; apply(x, pu, e); CHECK(e[1] > 0.099);
  // eye offset: the left eye (x = -0.0353 in head space) sees the object shifted right
  float off[3] = {-0.0353f, 0, 0}; CHECK(model_to_eye(head, dev, off, 0, &x)); apply(x, o, e); CHECK(fabs(e[0] - 0.0353) < 1e-5);
  // pitch 30 deg: the model's forward axis tilts up
  CHECK(model_to_eye(head, dev, nullptr, 30, &x)); apply(x, pf, e);
  CHECK(fabs(e[1] - 0.15) < 1e-4 && fabs(e[2] - (0.5 + 0.3 * 0.8660254)) < 1e-4);
  // head turned 90 degrees to the left (OpenVR yaw +90): an object that was ahead is now on the head's right
  float yaw[12] = {0,0,-1,0, 0,1,0,1.6f, 1,0,0,0};   // rotation about y by -90 deg: forward (-z) -> +x
  float tgt[12]; ident34(tgt, 0.5f, 1.6f, 0);        // 0.5 m along the head new forward (+x world)
  CHECK(model_to_eye(yaw, tgt, nullptr, 0, &x)); apply(x, o, e); CHECK(fabs(e[2] - 0.5) < 1e-5 && fabs(e[0]) < 1e-5);
  // two-handed pose: left hand 0.4 m ahead of the right hand -> the wand points along -z, no roll
  { float r34[12], l34[12], w[12]; ident34(r34, 0.2f, 1.2f, -0.3f); ident34(l34, 0.2f, 1.2f, -0.7f);
    CHECK(two_hand_pose(r34, l34, 0.1, w));
    CHECK(fabs(w[2]) < 1e-6 && fabs(w[6]) < 1e-6 && fabs(w[10] - 1) < 1e-6);   // z column = back = +z
    CHECK(fabs(w[0] - 1) < 1e-6 && fabs(w[5] - 1) < 1e-6 && fabs(w[3] - 0.2) < 1e-6);
    // left hand to the right of the right hand: forward turns to +x
    ident34(l34, 0.6f, 1.2f, -0.3f); CHECK(two_hand_pose(r34, l34, 0.1, w)); CHECK(fabs(w[2] + 1) < 1e-6);   // z col = -f = -x
    // the result is a rotation
    float R[9]; for (int a = 0; a < 3; ++a) for (int b = 0; b < 3; ++b) R[a * 3 + b] = w[a * 4 + b];
    CHECK(vm::is_rotation(R, 1e-4));
    // too close, or pointing straight up with no roll reference
    ident34(l34, 0.2f, 1.25f, -0.3f); CHECK(!two_hand_pose(r34, l34, 0.1, w));
    ident34(l34, 0.2f, 2.2f, -0.3f); CHECK(!two_hand_pose(r34, l34, 0.1, w));   // forward == up: no roll reference
  }
  // non-rotation refused
  float bad[12] = {0}; CHECK(!model_to_eye(bad, dev, nullptr, 0, &x));
  // geometry: counts fit, normals are unit length, vertices are finite
  static Vertex buf[kMaxVerts]; Mesh m = {buf, 0, kMaxVerts};
  build_wand(&m); int nw = m.n; build_hand(&m);
  CHECK(nw > 0 && m.n > nw && m.n <= kMaxVerts);
  CHECK(nw % 3 == 0 && m.n % 3 == 0);
  printf("wand vertices %d, hand vertices %d, total %d of %d\n", nw, m.n - nw, m.n, (int)kMaxVerts);
  for (int i = 0; i < m.n; ++i) {
    double l = buf[i].n[0] * buf[i].n[0] + buf[i].n[1] * buf[i].n[1] + buf[i].n[2] * buf[i].n[2];
    CHECK(fabs(l - 1) < 1e-4);
    for (int k = 0; k < 3; ++k) CHECK(vm::is_finite_f(buf[i].p[k]));
  }
  // the wand tip is about half a metre ahead of the grip, the hand sleeve behind it
  float zmin = 0, zmax = 0;
  for (int i = 0; i < nw; ++i) { if (buf[i].p[2] < zmin) zmin = buf[i].p[2]; if (buf[i].p[2] > zmax) zmax = buf[i].p[2]; }
  CHECK(zmin < -0.45 && zmin > -0.55 && zmax < 0.12);
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
