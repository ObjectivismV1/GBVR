// 1.7.87: where the thumb stick is read from, per controller family (src/handaxismath.h, used by vr_openvr.c).
#include "handaxismath.h"
#include <cassert>
#include <cmath>

static const uint64_t B0 = 1ull << 32, B2 = 1ull << 34, B3 = 1ull << 35, GRIP = 1ull << 2, A = 1ull << 7;

static GbvrStickRead pick(int fam, int emu, const float x[5], const float y[5], uint64_t pr, uint64_t tc, int seen3 = 1) {
  GbvrStickRead o;
  gbvr_pick_stick(fam, emu, seen3, x, y, pr, tc, &o);
  return o;
}

static const float* z0() { static const float z[5] = {0, 0, 0, 0, 0}; return z; }

int main() {
  float x[5] = {0, 0, 0, 0, 0}, y[5] = {0, 0, 0, 0, 0};

  // Touch-style (Quest, Rift, Pico): axis 0, buttons untouched
  x[0] = 0.5f; y[0] = -0.25f; x[3] = 0.9f;
  GbvrStickRead o = pick(1, 0, x, y, B0 | A, B0);
  assert(o.x == 0.5f && o.y == -0.25f && o.pressed == (B0 | A) && o.touched == B0);

  // Unknown family: axis 0 as before
  o = pick(5, 0, x, y, B0, 0);
  assert(o.x == 0.5f && o.pressed == B0);

  // Real Valve Index: stick on axis 3, trackpad (axis 0) ignored; click arrives as axis 3's bit and leaves as the stick click; the trackpad's own click is dropped
  float xi[5] = {0.7f, 0, 0, -0.4f, 0}, yi[5] = {0.7f, 0, 0, 0.3f, 0};
  o = pick(2, 0, xi, yi, B3 | GRIP, B3);
  assert(o.x == -0.4f && o.y == 0.3f && o.pressed == (B0 | B3 | GRIP) && o.touched == (B0 | B3));   // exactly as before 1.7.87: the axis bit itself stays set
  o = pick(2, 0, xi, yi, B0 | A, B0);                        // trackpad click only
  assert(o.pressed == A && o.touched == 0);

  // Windows MR: stick on axis 2
  float xw[5] = {0.1f, 0, 0.6f, 0, 0}, yw[5] = {0.1f, 0, -0.6f, 0, 0};
  o = pick(4, 0, xw, yw, B2, B2);
  assert(o.x == 0.6f && o.y == -0.6f && o.pressed == (B0 | B2) && o.touched == (B0 | B2));

  // Vive wand: the trackpad is the stick (axis 0)
  o = pick(3, 0, x, y, B0, B0);
  assert(o.x == 0.5f && o.pressed == B0);

  // An Index look-alike (Virtual Desktop "Emulate Index Controllers" or another driver): the stick may be on axis 3 (like the real thing) ...
  float xe[5] = {0, 0, 0, 0.8f, 0}, ye[5] = {0, 0, 0, -0.1f, 0};
  o = pick(2, 1, xe, ye, B3, B3);
  assert(o.x == 0.8f && o.y == -0.1f && o.pressed == B0 && o.touched == B0);
  // ... or on axis 0 (like a Touch controller)
  float xt[5] = {-0.9f, 0, 0, 0, 0}, yt[5] = {0.2f, 0, 0, 0, 0};
  o = pick(2, 1, xt, yt, B0 | A, B0);
  assert(o.x == -0.9f && o.y == 0.2f && o.pressed == (B0 | A) && o.touched == B0);
  // whichever is pushed further wins; at rest nothing moves
  float xr[5] = {0.1f, 0, 0, 0.5f, 0}, yr[5] = {0, 0, 0, 0, 0};
  o = pick(2, 1, xr, yr, 0, 0);
  assert(o.x == 0.5f);
  float z[5] = {0, 0, 0, 0, 0};
  o = pick(2, 1, z, z, 0, 0);
  assert(o.x == 0 && o.y == 0 && o.pressed == 0 && o.touched == 0);
  // the click from either axis' bit is the stick click; other buttons stay
  o = pick(2, 1, z, z, B3 | GRIP | A, 0);
  assert(o.pressed == (B0 | GRIP | A));
  o = pick(2, 1, z, z, B0 | B3, B0 | B3);
  assert(o.pressed == B0 && o.touched == B0);

  // "emulated" is decided by the maker string: only an Index-type controller that is not made by Valve
  assert(gbvr_index_lookalike(2, "Oculus") == 1);
  assert(gbvr_index_lookalike(2, "Virtual Desktop, Inc.") == 1);
  assert(gbvr_index_lookalike(2, "Valve") == 0);
  assert(gbvr_index_lookalike(2, "VALVE Corporation") == 0);
  assert(gbvr_index_lookalike(2, "") == 0);          // unreadable: keep the real-Index reading (no change from before)
  assert(gbvr_index_lookalike(1, "Oculus") == 0);
  assert(gbvr_index_lookalike(4, "Microsoft") == 0);


  // 1.7.96 a REAL Valve Index whose axis 3 has never moved while axis 0 does (the Index report: axis 0 pushed to 100 %, axis 3 always 0): the stick is read from axis 0
  float xa[5] = {-0.8f, 0, 0, 0, 0}, ya[5] = {0.6f, 0, 0, 0, 0};
  o = pick(2, 0, xa, ya, B0 | GRIP, B0, 0);
  assert(o.x == -0.8f && o.y == 0.6f && o.axis == 0 && o.pressed == (B0 | GRIP) && o.touched == B0);
  // ... its click is the stick click whichever bit it comes on, even when the stick is at rest (axis 3 unused so far)
  o = pick(2, 0, z0(), z0(), B0 | A, 0, 0);
  assert(o.axis == 3 && o.pressed == (B0 | A));
  o = pick(2, 0, z0(), z0(), B3, 0, 0);
  assert(o.pressed == B0);
  // once axis 3 HAS been pushed the trackpad on axis 0 is ignored again, exactly as in 1.7.87 .. 1.7.95
  o = pick(2, 0, xa, ya, 0, 0, 1);
  assert(o.x == 0 && o.y == 0 && o.axis == 3);
  // other families: unchanged by the new flag
  o = pick(1, 0, xa, ya, 0, 0, 0);
  assert(o.x == -0.8f && o.axis == 0);
  o = pick(4, 0, xw, yw, B2, B2, 0);
  assert(o.x == 0.6f && o.axis == 2);

  // peaks: the evidence line keeps the largest push per axis
  float pk[5] = {0, 0, 0, 0, 0};
  gbvr_axis_peaks(pk, xi, yi);
  assert(std::fabs(pk[0] - 0.7f) < 1e-6f && std::fabs(pk[3] - 0.4f) < 1e-6f && pk[1] == 0);
  float x2[5] = {0.2f, 0, 0, 0.9f, 0}, y2[5] = {0, 0, 0, 0, 0};
  gbvr_axis_peaks(pk, x2, y2);
  assert(std::fabs(pk[0] - 0.7f) < 1e-6f && std::fabs(pk[3] - 0.9f) < 1e-6f);
  return 0;
}
