// 1.7.143 stress test for handprop::drift_step (the gun / PKE hold easing back into the drawn hand).
// Simulates long play sessions at 90 arm passes a second: the controller moves, the drawn hand is the controller times a "true" relation that changes over
// the session (slow drift, sudden steps, rotation), plus walking bob, arm-solve trailing in fast swings and noise. The gun is placed the way the mod does it
// (controller x locked relation, after drift_step). Measures the gap between the placed gun hold and the drawn hand.
// Run by tests/run_all.sh (about 1 s). Pass -v for a minute-by-minute trace.
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <chrono>
#include "handprop.h"

static const double kCm = 30.48;   // game feet -> cm
static unsigned g_seed = 12345;
static double urand() { g_seed = g_seed * 1664525u + 1013904223u; return (g_seed >> 8) / 16777216.0; }
static double nrand() { double u = urand() + 1e-12, v = urand(); return std::sqrt(-2.0 * std::log(u)) * std::cos(6.283185307 * v); }

struct Pose { double grip[3], fwd[3], up[3]; };
static void norm(double* v) { double l = std::sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); for (int i = 0; i < 3; ++i) v[i] /= l; }
static int controller(const Pose& p, float* m) {
  float g[3], f[3], u[3];
  for (int i = 0; i < 3; ++i) { g[i] = (float)p.grip[i]; f[i] = (float)p.fwd[i]; u[i] = (float)p.up[i]; }
  return handprop::tracked_frame(g, f, u, m);
}
// a relation: rotation about an axis by ang, scale s, translation (hand-local, feet)
static void make_rel(double yawDeg, double pitchDeg, double s, double tx, double ty, double tz, float* r) {
  const double a = yawDeg * M_PI / 180.0, b = pitchDeg * M_PI / 180.0;
  const double ca = std::cos(a), sa = std::sin(a), cb = std::cos(b), sb = std::sin(b);
  // R = Ry(a) * Rx(b), rows
  double R[9] = {ca, sa * sb, -sa * cb,  0, cb, sb,  sa, -ca * sb, ca * cb};
  for (int i = 0; i < 16; ++i) r[i] = 0;
  for (int rr = 0; rr < 3; ++rr) for (int c = 0; c < 3; ++c) r[rr * 4 + c] = (float)(R[rr * 3 + c] * s);
  r[12] = (float)tx; r[13] = (float)ty; r[14] = (float)tz; r[15] = 1;
}
static double dist3(const float* a, const float* b) { double d = 0; for (int i = 12; i < 15; ++i) d += (double)(a[i] - b[i]) * (a[i] - b[i]); return std::sqrt(d); }
static double axis_err_deg(const float* a, const float* b) {   // largest angle between matching rows
  double worst = 0;
  for (int r = 0; r < 3; ++r) {
    double la = 0, lb = 0, d = 0;
    for (int c = 0; c < 3; ++c) { la += a[r * 4 + c] * a[r * 4 + c]; lb += b[r * 4 + c] * b[r * 4 + c]; d += a[r * 4 + c] * b[r * 4 + c]; }
    double cs = d / std::sqrt(la * lb); if (cs > 1) cs = 1; if (cs < -1) cs = -1;
    worst = std::max(worst, std::acos(cs) * 180.0 / M_PI);
  }
  return worst;
}

struct Scenario {
  const char* name;
  double minutes;
  double driftCmPerMin;     // slow growth of the true offset (cm per minute, along the hand's up)
  double stepEverySec;      // a sudden change of the true relation every N s (0 = none)
  double stepCm, stepDeg;   // its size
  double swingPerMin;       // fast swings per minute (the arm trails the controller)
  double bobCm, bobHz;      // walking bob of the drawn hand
  double noiseMm;           // per-sample jitter of the drawn hand
  double scale;             // matrices' scale (world / hand size)
  int badEvery;             // every N samples the arm hand is non-finite (0 = never)
};

struct Result { double p50, p95, p99, maxSteady, maxAll, settleS; long relocks, eases; double axisMax, maxAbsRel; int bad; double nsPerCall; };

static Result run(const Scenario& sc, int verbose) {
  const double hz = 90.0, dt = 1.0 / hz;
  const long N = (long)(sc.minutes * 60.0 * hz);
  Pose p = {{0, 4, 0}, {0, 0, 1}, {0, 1, 0}};
  double vel[3] = {0, 0, 0};
  float trueRel[16]; make_rel(0, 0, sc.scale, 0, 0, 0, trueRel);
  double offUp = 0, offFwd = 0, rotDeg = 0;
  handprop::HandFollower hf; handprop::reset(&hf);
  handprop::HandDrift d = {}; handprop::reset(&d);
  std::vector<double> steadyGaps; steadyGaps.reserve(N);
  Result R = {}; R.settleS = 0;
  double swingLeft = 0, swingDir[3] = {0, 0, 0}, trail[3] = {0, 0, 0};
  double lastStepT = -1, worstSettle = 0; int inSettle = 0;
  double nextStep = sc.stepEverySec > 0 ? sc.stepEverySec : 1e18;
  double ns = 0; long calls = 0;
  for (long k = 0; k < N; ++k) {
    const double t = k * dt;
    // the true relation of the moment: slow drift + steps
    offUp = -sc.driftCmPerMin * (t / 60.0) / kCm;
    if (t >= nextStep) { nextStep += sc.stepEverySec; offFwd += (urand() < 0.5 ? -1 : 1) * sc.stepCm / kCm; rotDeg += (urand() < 0.5 ? -1 : 1) * sc.stepDeg; lastStepT = t; inSettle = 1; }
    make_rel(rotDeg, 0.3 * rotDeg, sc.scale, 0, offUp, offFwd, trueRel);
    // controller motion: slow wander, occasional fast swing
    if (swingLeft <= 0 && urand() < sc.swingPerMin / 60.0 * dt) { swingLeft = 0.35; for (int i = 0; i < 3; ++i) swingDir[i] = nrand(); norm(swingDir); }
    double speed = 0.4;   // ft/s wander
    for (int i = 0; i < 3; ++i) vel[i] = 0.98 * vel[i] + 0.02 * nrand() * speed;
    double v[3]; for (int i = 0; i < 3; ++i) v[i] = vel[i];
    if (swingLeft > 0) { for (int i = 0; i < 3; ++i) v[i] += swingDir[i] * 10.0; swingLeft -= dt; }   // ~3 m/s
    for (int i = 0; i < 3; ++i) p.grip[i] += v[i] * dt;
    for (int i = 0; i < 3; ++i) p.grip[i] += (i == 1 ? 4.0 : 0.0 - p.grip[i]) * 0.0; // keep
    p.grip[1] = std::min(6.0, std::max(2.0, p.grip[1]));
    p.fwd[0] += 0.01 * nrand(); p.fwd[1] += 0.01 * nrand(); p.fwd[1] = std::max(-0.8, std::min(0.8, p.fwd[1])); norm(p.fwd);   // a held controller never points its forward along its up
    // the arm trails the controller in fast moves (0.08 s behind)
    for (int i = 0; i < 3; ++i) trail[i] = 0.85 * trail[i] + 0.15 * (-v[i] * 0.08);
    float C[16];
    if (!controller(p, C)) { ++R.bad; continue; }   // the mod skips a frame whose controller frame is not usable
    float H[16]; handprop::place(trueRel, C, H);
    const double bob = sc.bobCm / kCm * std::sin(6.283185307 * sc.bobHz * t);
    H[13] += (float)bob;
    for (int i = 0; i < 3; ++i) H[12 + i] += (float)(trail[i] + nrand() * sc.noiseMm / 304.8);
    const int bad = sc.badEvery && (k % sc.badEvery) == 0;
    if (bad) { H[12] = NAN; ++R.bad; }
    // the mod: lock first (5 steady samples), then drift_step + place the gun on the controller
    auto t0 = std::chrono::steady_clock::now();
    if (!hf.locked) handprop::capture_hand(&hf, H, C);
    else handprop::drift_step(&hf, &d, H, C);
    auto t1 = std::chrono::steady_clock::now();
    ns += std::chrono::duration<double, std::nano>(t1 - t0).count(); ++calls;
    float G[16];
    if (!handprop::follow_hand(&hf, C, G)) continue;
    for (int i = 0; i < 16; ++i) if (!std::isfinite(G[i])) { printf("  NON-FINITE gun at %.1f s\n", t); R.maxAll = 1e9; return R; }
    if (bad) continue;
    float Hc[16]; for (int i = 0; i < 16; ++i) Hc[i] = H[i];
    for (int i = 0; i < 3; ++i) Hc[12 + i] -= (float)trail[i]; Hc[13] -= (float)bob;   // where the hand is without the moment's trail / bob
    const double gap = dist3(G, H) * kCm;
    const double gapTrue = dist3(G, Hc) * kCm;
    R.maxAll = std::max(R.maxAll, gap);
    R.axisMax = std::max(R.axisMax, axis_err_deg(G, H));
    for (int i = 0; i < 16; ++i) R.maxAbsRel = std::max(R.maxAbsRel, (double)std::fabs(hf.rel[i]));
    const int steadyNow = swingLeft <= 0 && std::sqrt(trail[0] * trail[0] + trail[1] * trail[1] + trail[2] * trail[2]) * kCm < 0.5;
    if (steadyNow && (lastStepT < 0 || t - lastStepT > 2.0)) { steadyGaps.push_back(gapTrue); R.maxSteady = std::max(R.maxSteady, gapTrue); }
    if (inSettle && gapTrue < 1.5 && steadyNow) { worstSettle = std::max(worstSettle, t - lastStepT); inSettle = 0; }
    if (verbose && k % (long)(60 * hz) == 0) printf("    t=%4.0f s gap %.1f cm (true offset %.1f cm up, %.1f cm fwd, %.0f deg) relocks %ld\n", t, gapTrue, offUp * kCm, offFwd * kCm, rotDeg, d.relocks);
  }
  std::sort(steadyGaps.begin(), steadyGaps.end());
  auto pct = [&](double q) { return steadyGaps.empty() ? 0.0 : steadyGaps[(size_t)(q * (steadyGaps.size() - 1))]; };
  R.p50 = pct(0.5); R.p95 = pct(0.95); R.p99 = pct(0.99);
  R.relocks = d.relocks; R.eases = d.eases; R.settleS = worstSettle; R.nsPerCall = ns / calls;
  return R;
}

int main(int argc, char** argv) {
  const int verbose = argc > 1;
  const Scenario S[] = {
    // name                         min  drift  stepEvery stepCm stepDeg swings bob  bobHz noise scale bad
    {"baseline (no drift)",          30,  0.0,   0,        0,     0,      2,     0,   0,    1.0,  1.0,  0},
    {"video: slow drift 2 cm/min",   30,  2.0,   0,        0,     0,      6,     0,   0,    1.0,  1.0,  0},
    {"level loads: 25 cm steps",     30,  0.0,   120,      25,    0,      6,     0,   0,    1.0,  1.0,  0},
    {"rotation steps 15 deg",        20,  0.0,   90,       5,     15,     4,     0,   0,    1.0,  1.0,  0},
    {"constant fast swings",         20,  1.0,   0,        0,     0,      60,    0,   0,    1.0,  1.0,  0},
    {"walking bob 3 cm 2 Hz",        20,  1.0,   0,        0,     0,      6,     3,   2,    1.0,  1.0,  0},
    {"heavy noise 5 mm",             20,  1.0,   0,        0,     0,      6,     0,   0,    5.0,  1.0,  0},
    {"world size 115 %",             20,  2.0,   150,      20,    5,      6,     1,   1.5,  1.0,  1.15, 0},
    {"world size 90 %",              20,  2.0,   150,      20,    5,      6,     1,   1.5,  1.0,  0.90, 0},
    {"bad arm frames (NaN)",         10,  2.0,   0,        0,     0,      6,     0,   0,    1.0,  1.0,  7},
    {"everything at once, 2 hours", 120,  1.0,   300,      30,    10,     20,    2,   1.8,  2.0,  1.05, 500},
  };
  int fails = 0;
  printf("%-30s %6s %6s %6s %8s %8s %7s %7s %6s %6s\n", "scenario", "p50", "p95", "p99", "maxStdy", "settle", "relock", "axis", "ns", "result");
  for (const auto& sc : S) {
    if (verbose) printf("  %s\n", sc.name);
    const Result r = run(sc, verbose);
    const int ok = r.maxAll < 1e8 && r.p95 < 3.5 && r.p99 < 5.0 && (sc.stepEverySec == 0 || r.settleS < 2.5) && r.maxAbsRel < 50.0;
    if (!ok) ++fails;
    printf("%-30s %5.1fcm %5.1fcm %5.1fcm %6.1fcm %6.2fs %7ld %6.1fd %6.0f %6s\n", sc.name, r.p50, r.p95, r.p99, r.maxSteady, r.settleS, r.relocks, r.axisMax, r.nsPerCall, ok ? "OK" : "FAIL");
  }
  printf(fails ? "STRESS: %d scenario(s) FAILED\n" : "STRESS: all scenarios OK\n", fails);
  return fails ? 1 : 0;
}
