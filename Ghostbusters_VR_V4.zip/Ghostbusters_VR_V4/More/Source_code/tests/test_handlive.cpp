// 1.7.66: handprop::Live - the PKE follows the game's live hold, small changes at once, big jumps only when they persist.
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "handprop.h"

static void I(float* m) { handprop::ident(m); }
static void Zrot(float* m, double a) { I(m); const float c=(float)cos(a), s=(float)sin(a); m[0]=c; m[1]=s; m[4]=-s; m[5]=c; }

int main() {
  handprop::Live lv; handprop::reset(&lv);
  float a[16], b[16], c[16];
  I(a); a[12] = 0.30f; a[13] = 0.0f; a[14] = 0.10f;          // 9 cm out, 3 cm up

  // nothing yet: no relation, and a null sample does not invent one
  assert(!handprop::live_update(&lv, nullptr, 0.25, 0.04, 8));
  assert(!lv.have);

  // first sample is taken at once
  assert(handprop::live_update(&lv, a, 0.25, 0.04, 8));
  assert(lv.have && lv.accepted == 1);

  // a meter coming out of the belt: many small steps are all followed at once (never frozen early)
  for (int i = 1; i <= 20; ++i) {
    I(b); b[12] = 0.30f - 0.01f * i; b[13] = 0.0f; b[14] = 0.10f;   // 0.3 cm per step toward the hand
    assert(handprop::live_update(&lv, b, 0.25, 0.04, 8));
    assert(fabs(lv.rel[12] - b[12]) < 1e-6);
  }
  assert(lv.jumps == 0 && lv.held == 0);

  // a one-frame glitch (view model rebuilt) is ignored, then the next normal sample is followed
  float good[16]; for (int i = 0; i < 16; ++i) good[i] = lv.rel[i];
  I(c); c[12] = 3.0f; Zrot(c, 1.2); c[12] = 3.0f;
  assert(handprop::live_update(&lv, c, 0.25, 0.04, 8));
  for (int i = 0; i < 16; ++i) assert(fabs(lv.rel[i] - good[i]) < 1e-6);
  assert(lv.held == 1 && lv.jumps == 0);
  I(b); b[12] = good[12] + 0.01f; b[13] = good[13]; b[14] = good[14];
  assert(handprop::live_update(&lv, b, 0.25, 0.04, 8));
  assert(fabs(lv.rel[12] - b[12]) < 1e-6);

  // alternating glitches never build up a jump
  for (int i = 0; i < 20; ++i) {
    I(c); c[12] = 2.0f + 0.5f * (i & 1); c[13] = 0.3f * i;
    handprop::live_update(&lv, c, 0.25, 0.04, 8);
    I(b); b[12] = good[12]; b[13] = good[13]; b[14] = good[14];
    handprop::live_update(&lv, b, 0.25, 0.04, 8);
  }
  assert(lv.jumps == 0);

  // a real, lasting change (the game switches how it holds the meter) is followed after `run` identical samples
  I(c); c[12] = 0.9f; c[13] = 0.2f; c[14] = -0.1f;
  for (int i = 0; i < 7; ++i) { handprop::live_update(&lv, c, 0.25, 0.04, 8); assert(lv.jumps == 0); }
  handprop::live_update(&lv, c, 0.25, 0.04, 8);
  assert(lv.jumps == 1);
  assert(fabs(lv.rel[12] - 0.9f) < 1e-6);
  assert(lv.lastJumpFt > 0.25);

  // non-finite samples are not used
  float bad[16]; for (int i = 0; i < 16; ++i) bad[i] = c[i]; bad[3] = NAN;
  float before = lv.rel[12];
  handprop::live_update(&lv, bad, 0.25, 0.04, 8);
  assert(lv.rel[12] == before);

  // reset forgets everything (a new pull-out)
  handprop::reset(&lv);
  assert(!lv.have && lv.accepted == 0 && lv.jumps == 0);

  // mean_scale: rigid matrix is 1, a 1.3x scaled hand is 1.3
  float m[16]; I(m);
  assert(fabs(handprop::mean_scale(m) - 1.0) < 1e-6);
  m[0] = m[5] = m[10] = 1.3f;
  assert(fabs(handprop::mean_scale(m) - 1.3) < 1e-6);

  puts("PASS live PKE hold: small steps followed, glitches ignored, lasting jumps believed");

  // 1.7.67: a stretched hand (one axis 1.9x longer, as in the 1.7.66 log) gives back a clean frame; the rotation of the axes is kept
  {
    float h[16]; I(h); Zrot(h, 0.7); h[12] = 3.0f; h[13] = 4.0f; h[14] = -2.0f;
    float st[16]; for (int i = 0; i < 16; ++i) st[i] = h[i];
    for (int c = 0; c < 3; ++c) { st[0 * 4 + c] *= 1.03f; st[1 * 4 + c] *= 1.03f; st[2 * 4 + c] *= 1.9f; }
    assert(fabs(handprop::row_ratio(st) - 1.9 / 1.03) < 1e-4);
    assert(fabs(handprop::row_ratio(h) - 1.0) < 1e-5);
    float out[16];
    assert(handprop::rigid_frame(st, 1.03, out));
    for (int r = 0; r < 3; ++r) { assert(fabs(handprop::row_len(out, r) - 1.03) < 1e-4); for (int c = 0; c < 3; ++c) assert(fabs(out[r * 4 + c] - 1.03 * h[r * 4 + c]) < 1e-4); }
    assert(out[12] == 3.0f && out[13] == 4.0f && out[14] == -2.0f && out[15] == 1.0f);
    // the PKE placed through the stretched hand is stretched and pushed out; through the clean one it is not
    float rel[16]; I(rel); rel[12] = 0.0f; rel[13] = 0.0f; rel[14] = 0.42f;   // 12.8 cm along the hand's third axis
    float viaRaw[16], viaClean[16];
    handprop::place(rel, st, viaRaw); handprop::place(rel, out, viaClean);
    const double dRaw = sqrt((double)(viaRaw[12]-3)*(viaRaw[12]-3) + (double)(viaRaw[13]-4)*(viaRaw[13]-4) + (double)(viaRaw[14]+2)*(viaRaw[14]+2));
    const double dClean = sqrt((double)(viaClean[12]-3)*(viaClean[12]-3) + (double)(viaClean[13]-4)*(viaClean[13]-4) + (double)(viaClean[14]+2)*(viaClean[14]+2));
    assert(dRaw > 0.75 && fabs(dClean - 0.42 * 1.03) < 1e-3);
    // a mildly sheared hand is made perpendicular
    float sh[16]; for (int i = 0; i < 16; ++i) sh[i] = h[i];
    for (int c = 0; c < 3; ++c) sh[1 * 4 + c] += 0.15f * sh[0 * 4 + c];
    assert(handprop::rigid_frame(sh, 1.0, out));
    double d01 = 0, d02 = 0, d12 = 0;
    for (int c = 0; c < 3; ++c) { d01 += out[c] * out[4 + c]; d02 += out[c] * out[8 + c]; d12 += out[4 + c] * out[8 + c]; }
    assert(fabs(d01) < 1e-5 && fabs(d02) < 1e-5 && fabs(d12) < 1e-5);
    // mirrored / flat / not-finite matrices are refused
    float mir[16]; for (int i = 0; i < 16; ++i) mir[i] = h[i]; for (int c = 0; c < 3; ++c) mir[8 + c] = -mir[8 + c];
    assert(!handprop::rigid_frame(mir, 1.0, out));
    float flat[16]; for (int i = 0; i < 16; ++i) flat[i] = h[i]; for (int c = 0; c < 3; ++c) flat[8 + c] = 0.0f;
    assert(!handprop::rigid_frame(flat, 1.0, out));
    float nf[16]; for (int i = 0; i < 16; ++i) nf[i] = h[i]; nf[5] = NAN;
    assert(!handprop::rigid_frame(nf, 1.0, out));
    assert(!handprop::rigid_frame(h, 0.0, out));
  }
  puts("PASS rigid hand frame: stretch stripped, axes perpendicular, bad matrices refused");
  return 0;
}
