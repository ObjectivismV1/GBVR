#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "pkemath.h"
#include "weightmath.h"
int main() {
  pke::GripLock lock = {};
  double axes[3][3] = {{1,0,0},{0,1,0},{0,0,1}};
  double fresh[3] = {.1,-.2,.3}, out[3];
  pke::grip_step(&lock, nullptr, axes, 1, out);
  assert(out[0] == 0 && !lock.have);
  pke::grip_step(&lock, fresh, axes, 1, out);
  assert(lock.have && out[0] == .1 && out[1] == -.2 && out[2] == .3);
  // Animation offsets wander; the prop never follows them after calibration.
  for (int frame = 0; frame < 900; ++frame) {
    const double angle = frame * .01;
    axes[0][0] = cos(angle); axes[0][2] = -sin(angle);
    axes[2][0] = sin(angle); axes[2][2] = cos(angle);
    fresh[0] = sin(frame) * .5;
    pke::grip_step(&lock, frame % 2 ? fresh : nullptr, axes, 1, out);
    for (int axis = 0; axis < 3; ++axis)
      assert(fabs(pke::dot(out, axes[axis]) - lock.local[axis]) < 1e-12);
    // Hand-lock mode bypasses orientation AND position springs, even firing.
    double target[9], rotation[9], position[3];
    for (int i = 0; i < 9; ++i) target[i] = axes[i/3][i%3];
    weight::Params params = {0,1}; params.punish = 0;
    weight::State state = {}; weight::PosState pos = {}; weight::Out info = {};
    weight::step(&state, params, target, 1.0/90, 0, 1, 1, rotation, &info);
    weight::step_pos(&pos, 0, fresh, 1.0/90, 0, position);
    for (int i = 0; i < 9; ++i) assert(rotation[i] == target[i]);
    for (int i = 0; i < 3; ++i) assert(position[i] == fresh[i]);
    assert(info.lagDeg == 0 && info.recoilDeg == 0);
  }
  puts("PASS hand lock: fixed grip, no animation drift, direct 90 Hz pose");
}
