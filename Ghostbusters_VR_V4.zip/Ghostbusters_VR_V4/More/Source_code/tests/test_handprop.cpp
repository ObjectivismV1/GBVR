#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "handprop.h"

static void I(float* m) { handprop::ident(m); }
static void Zrot(float* m, double a) {
  I(m); const float c=(float)cos(a), s=(float)sin(a);
  m[0]=c; m[1]=s; m[4]=-s; m[5]=c;
}
static double near(double a,double b){return fabs(a-b)<1e-4;}
int main(){
  float hg[16], hf[16], pg[16], pf[16], rel[16], expect[16];
  I(hg); I(pg); hg[12]=10; hg[13]=2; hg[14]=-4;
  // game holds prop 0.25 ft ahead and rotated 25 deg relative to hand
  Zrot(rel, .43633231299); rel[12]=.25f; rel[13]=-.08f; rel[14]=.12f;
  handprop::mul34(pg, rel, hg);
  Zrot(hf, -1.0); hf[12]=4; hf[13]=8; hf[14]=3;
  assert(handprop::relative(pg,hg,expect));
  assert(handprop::place(expect,hf,pf));
  float want[16]; handprop::mul34(want,rel,hf);
  for(int i=0;i<16;++i) assert(near(pf[i],want[i]));

  // Lock only after a stable game relation, then ignore later animation/viewmodel drift.
  handprop::GripLock lk={};
  float out[16];
  for(int n=0;n<25;++n){
    float p[16]; handprop::mul34(p,rel,hg); p[12] += (n&1)?0.001f:0.0f;
    assert(handprop::step(&lk,p,hg,hf,out));
  }
  assert(lk.locked);
  // 1.7.175: a prop sliding into the hand (0.02 ft per sample, passes a sample-to-sample test) must NOT lock.
  { handprop::GripLock sl={}; float o2[16];
    for(int n=0;n<60;++n){ float r2[16]; for(int i=0;i<16;++i) r2[i]=rel[i]; r2[12]=0.40f-0.005f*n; float p[16]; handprop::mul34(p,r2,hg); handprop::step(&sl,p,hg,hf,o2); }
    assert(!sl.locked); }
  float locked[16]; for(int i=0;i<16;++i) locked[i]=out[i];
  float driftRel[16]; for(int i=0;i<16;++i) driftRel[i]=rel[i]; driftRel[12]+=1.0f; Zrot(driftRel,1.7); driftRel[12]=rel[12]+1.0f;
  float driftProp[16]; handprop::mul34(driftProp,driftRel,hg);
  assert(handprop::step(&lk,driftProp,hg,hf,out));
  for(int i=0;i<16;++i) assert(near(out[i],locked[i]));

  // Holster/re-equip is represented by no calls; the lock remains unchanged.
  assert(lk.locked);

  // Attachment follows the exact final prop transform.
  float tipRel[16], tipG[16], tipF[16], tipWant[16]; I(tipRel); tipRel[14]=2.0f;
  handprop::mul34(tipG,tipRel,pg);
  assert(handprop::map_part(tipG,pg,pf,tipF));
  handprop::mul34(tipWant,tipRel,pf);
  for(int i=0;i<16;++i) assert(near(tipF[i],tipWant[i]));
  // If the rig disappears, NEVER carry the prop directly from the controller.
  // Carry the game hand from the controller, then reapply the game's exact
  // prop->hand relationship. This preserves the real grip through streaming.
  float c0[16], c1[16], carriedHand[16], carried[16], expectedHand[16], expectedCarried[16];
  const float g0[3]={2,3,4}, f0[3]={0,0,1}, u0[3]={0,1,0};
  const float g1[3]={5,7,8}, f1[3]={1,0,0}, u1[3]={0,1,0};
  assert(handprop::tracked_frame(g0,f0,u0,c0));
  assert(handprop::tracked_frame(g1,f1,u1,c1));
  handprop::HandFollower follow={};
  for(int n=0;n<8;++n) assert(handprop::capture_hand(&follow,hf,c0));
  assert(follow.have && follow.locked);
  assert(handprop::follow_hand(&follow,c1,carriedHand));
  handprop::mul34(expectedHand,follow.rel,c1);
  for(int i=0;i<16;++i) assert(near(carriedHand[i],expectedHand[i]));
  assert(lk.havePrev);
  assert(handprop::place(lk.rel,carriedHand,carried));
  handprop::mul34(expectedCarried,lk.rel,carriedHand);
  for(int i=0;i<16;++i) assert(near(carried[i],expectedCarried[i]));
  assert(!handprop::tracked_frame(g0,f0,f0,c1));
  // 1.7.93: a prop that is not within reach of the hand is not a hold. The logs of players whose game starts in a cut-scene showed the gun 40.3 cm and 77.6 cm
  // from the hand being locked as "the grip"; the gun then floated that far from the hand all session.
  {
    handprop::GripLock fl={};
    float farRel[16], farProp[16], o2[16];
    const double farCm[3] = {40.3, 77.6, 120.0};
    for (int k=0;k<3;++k) {
      I(farRel); farRel[12]=(float)(farCm[k]/30.48); farRel[13]=0.0f; farRel[14]=0.0f;
      handprop::mul34(farProp,farRel,hg);
      for (int n=0;n<12;++n) assert(!handprop::step(&fl,farProp,hg,hf,o2));   // never placed, however long it stays
      assert(!fl.locked && !fl.havePrev && fl.stable==0);
    }
    assert(fl.tooFar==36);
    assert(near(fl.lastFarFt*30.48,120.0) || fabs(fl.lastFarFt*30.48-120.0)<0.01);
    // the hold arrives (10.1 cm, as in the logs): placed at once, locked after 20 steady samples (1.7.175)
    float nearRel[16], nearProp[16]; I(nearRel); nearRel[12]=(float)(10.1/30.48); nearRel[13]=0.02f;
    handprop::mul34(nearProp,nearRel,hg);
    for (int n=0;n<25;++n) assert(handprop::step(&fl,nearProp,hg,hf,o2));
    assert(fl.locked);
    float want2[16]; handprop::mul34(want2,nearRel,hf);
    for(int i=0;i<16;++i) assert(near(o2[i],want2[i]));
    // once locked, a later far sample (the gun going back to the holster) does not change the grip and is not counted as refused
    const long farNow = fl.tooFar;
    I(farRel); farRel[12]=2.55f; handprop::mul34(farProp,farRel,hg);
    assert(handprop::step(&fl,farProp,hg,hf,o2));
    for(int i=0;i<16;++i) assert(near(o2[i],want2[i]));
    assert(fl.tooFar==farNow);
    // the edge: a relation just inside the limit is a hold, just outside is not
    handprop::GripLock el={};
    I(farRel); farRel[12]=(float)(handprop::kMaxHoldFt-0.01); handprop::mul34(farProp,farRel,hg);
    assert(handprop::step(&el,farProp,hg,hf,o2));
    handprop::GripLock el2={};
    I(farRel); farRel[12]=(float)(handprop::kMaxHoldFt+0.01); handprop::mul34(farProp,farRel,hg);
    assert(!handprop::step(&el2,farProp,hg,hf,o2));
    // a not-a-number length is refused too (never placed)
    handprop::GripLock nl={};
    I(farRel); farRel[12]=0.0f/0.0f; handprop::mul34(farProp,farRel,hg);
    assert(!handprop::step(&nl,farProp,hg,hf,o2));
    // reset clears the counters
    handprop::reset(&fl); assert(fl.tooFar==0 && fl.lastFarFt==0.0 && !fl.locked);
  }
  {   // 1.7.143 drift_step: a locked hand<->controller relation eases back to the drawn hand
    float ctl[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 5,4,3,1};
    float hand[16]; for (int i = 0; i < 16; ++i) hand[i] = ctl[i];
    handprop::HandFollower hf; handprop::reset(&hf);
    for (int k = 0; k < 8; ++k) handprop::capture_hand(&hf, hand, ctl);
    assert(hf.locked);
    handprop::HandDrift d = {}; handprop::reset(&d);
    // the drawn hand is now 0.5 ft (15 cm) lower than the relation says, and steady
    float low[16]; for (int i = 0; i < 16; ++i) low[i] = hand[i]; low[13] -= 0.5f;
    int moved = 0;
    for (int k = 0; k < 19; ++k) moved += handprop::drift_step(&hf, &d, low, ctl);
    assert(moved == 0);                       // not before 20 steady samples
    for (int k = 0; k < 80; ++k) moved += handprop::drift_step(&hf, &d, low, ctl);
    assert(moved > 0 && d.relocks == 1);
    float placed[16]; assert(handprop::follow_hand(&hf, ctl, placed));
    assert(placed[13] < 3.53f && placed[13] > 3.49f);   // back in the hand (within about 1 cm)
    // a fast swing (the drawn hand jumps about every sample) does not move it
    handprop::HandDrift d2 = {}; handprop::reset(&d2);
    const float before = hf.rel[13];
    for (int k = 0; k < 60; ++k) { float sw[16]; for (int i = 0; i < 16; ++i) sw[i] = low[i]; sw[12] += (k % 2) ? 0.6f : -0.6f; handprop::drift_step(&hf, &d2, sw, ctl); }
    assert(hf.rel[13] == before && d2.relocks == 0);
    // a small difference (2 cm) is left alone
    handprop::HandDrift d3 = {}; handprop::reset(&d3);
    float near[16]; for (int i = 0; i < 16; ++i) near[i] = placed[i]; near[13] -= 0.065f;
    for (int k = 0; k < 60; ++k) handprop::drift_step(&hf, &d3, near, ctl);
    assert(d3.relocks == 0);
    // not locked: nothing happens
    handprop::HandFollower un; handprop::reset(&un); handprop::HandDrift d4 = {}; handprop::reset(&d4);
    assert(!handprop::drift_step(&un, &d4, low, ctl));
  }
  puts("PASS exact game-hand prop grip + hand-first streaming/holster continuity + far props are not locked");
}
