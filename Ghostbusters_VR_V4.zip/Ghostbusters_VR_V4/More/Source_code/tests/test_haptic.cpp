#include <stdio.h>
#include "hapticmath.h"
using namespace hap;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  Mixer m; m.reset();
  CHECK(m.level_now(0, 1.0) == 0.0);
  m.add(1, kSrcFireHold, 0.3, 10.0, 90);
  CHECK(m.level_now(1, 10.05) > 0.29 && m.level_now(1, 10.05) < 0.31);
  CHECK(m.level_now(0, 10.05) == 0.0);                 // other hand untouched
  CHECK(m.level_now(1, 10.2) == 0.0);                  // expired
  // strongest wins, second adds a quarter, never above 1
  m.add(1, kSrcFireKick, 0.9, 20.0, 50); m.add(1, kSrcFireHold, 0.3, 20.0, 90);
  double v = m.level_now(1, 20.01);
  CHECK(v > 0.9 + 0.07 && v <= 1.0);
  m.add(1, kSrcBlast, 1.0, 20.0, 50);
  CHECK(m.level_now(1, 20.01) == 1.0);
  // renewing does not count as a new start; a restart after expiry does
  m.reset();
  m.add(1, kSrcFireHold, 0.3, 30.0, 90); m.add(1, kSrcFireHold, 0.3, 30.05, 90); m.add(1, kSrcFireHold, 0.3, 30.1, 90);
  CHECK(m.starts[1][kSrcFireHold] == 1);
  m.add(1, kSrcFireHold, 0.3, 31.0, 90);
  CHECK(m.starts[1][kSrcFireHold] == 2);
  // stop
  m.stop(1, kSrcFireHold); CHECK(m.level_now(1, 31.01) == 0.0);
  // bad arguments are ignored
  m.add(2, 0, 1, 0, 10); m.add(0, 99, 1, 0, 10); m.add(0, -1, 1, 0, 10);
  // pulse length
  CHECK(pulse_us(0.0) == 0); CHECK(pulse_us(0.03) == 0);
  CHECK(pulse_us(1.0) == 3999); CHECK(pulse_us(2.0) == 3999);
  CHECK(pulse_us(0.5) == 1999);
  CHECK(pulse_us(0.05) == 300);                        // never shorter than 300 us
  // rumble
  CHECK(rumble_strength(0, 0) == 0.0); CHECK(rumble_strength(1000, 1000) == 0.0);
  CHECK(rumble_strength(2000, 0) > 0.3); CHECK(rumble_strength(65535, 0) > 0.99);
  // a 6 ms stream of 0.3 strength is a ~1.2 ms pulse = 20 % duty
  printf("0.3 strength -> %u us per pulse; 1.0 -> %u us\n", pulse_us(0.3), pulse_us(1.0));
  // 1.7.13 PKE proximity: stronger, faster and longer as the thing gets closer; nothing beyond 60 ft
  CHECK(prox_level(70.0) == 0.0 && prox_level(-1.0) == 0.0);
  CHECK(prox_level(50.0) < prox_level(30.0) && prox_level(30.0) < prox_level(10.0) && prox_level(10.0) < prox_level(1.0) && prox_level(0.0) <= 1.0001);
  CHECK(prox_period_s(50.0) > prox_period_s(20.0) && prox_period_s(20.0) > prox_period_s(2.0) && prox_period_s(0.0) >= 0.09);
  CHECK(prox_ms(55.0) < prox_ms(5.0) && prox_ms(0.0) <= 100);
  CHECK(src_name(kSrcGame)[0] == 'g' && src_name(99)[0] == '?');
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
