#include "../src/headmath.h"
#include <cstdio>
#include <cmath>
static void rotY(double t,float*o){double s=sin(t),c=cos(t);float r[9]={(float)c,0,(float)s,0,1,0,(float)-s,0,(float)c};for(int i=0;i<9;i++)o[i]=r[i];}
static void rotX(double t,float*o){double s=sin(t),c=cos(t);float r[9]={1,0,0,0,(float)c,(float)-s,0,(float)s,(float)c};for(int i=0;i<9;i++)o[i]=r[i];}
static void rotZ(double t,float*o){double s=sin(t),c=cos(t);float r[9]={(float)c,(float)-s,0,(float)s,(float)c,0,0,0,1};for(int i=0;i<9;i++)o[i]=r[i];}
int main(){
  int fails=0; float Y[9],L[9],yaw,pit,rol,H[9],R16[9];
  // 1) head yaw +10 deg after recenter at heading 37 deg must equal 0.16 F7 matrix
  float H0[9]; rotY(37*M_PI/180,H0); if(!make_yaw_reference(H0,Y)){puts("ref fail");return 1;}
  rotY((37+10)*M_PI/180,H); gbvr_head_to_engine(H,Y,L,&yaw,&pit,&rol); vm::local_yaw(10,R16);
  double e=0; for(int i=0;i<9;i++) e=fmax(e,fabs(L[i]-R16[i]));
  printf("yaw+10 vs 0.16 F7: err=%.2g  yaw=%.3f pitch=%.3f roll=%.3f\n",e,yaw,pit,rol); fails+= e>1e-6;
  // 2) recentered straight ahead -> identity
  gbvr_head_to_engine(H0,Y,L,&yaw,&pit,&rol); float I[9]; vm::identity(I); e=0; for(int i=0;i<9;i++) e=fmax(e,fabs(L[i]-I[i]));
  printf("recenter identity: err=%.2g\n",e); fails+= e>1e-6;
  // 3) look up 20 deg (OpenVR +X rotation) -> engine forward (0,0,1) tilts to +y
  float P[9],H2[9]; rotX(20*M_PI/180,P); vm::mul(H0,P,H2); gbvr_head_to_engine(H2,Y,L,&yaw,&pit,&rol);
  // engine forward after L = L*(0,0,1) = third column
  printf("pitch up 20: fwd=(%.3f,%.3f,%.3f) logged pitch=%.2f yaw=%.2f roll=%.2f det=%.6f\n",L[2],L[5],L[8],pit,yaw,rol,vm::det(L));
  fails += !(L[5]>0.33 && fabs(pit-20)<0.01 && fabs(yaw)<0.01);
  // 4) roll left 15 deg (OpenVR +Z rotation): engine up (col1) should tilt toward -x (left)
  float Rz[9],H3[9]; rotZ(15*M_PI/180,Rz); vm::mul(H0,Rz,H3); gbvr_head_to_engine(H3,Y,L,&yaw,&pit,&rol);
  printf("roll left 15: up=(%.3f,%.3f,%.3f) logged roll=%.2f\n",L[1],L[4],L[7],rol); fails += !(L[1]< -0.25 && fabs(rol-15)<0.01);
  // 5) pitch absolute: recenter while looking down 30 then look level -> pitch 0 (yaw-only reference)
  float Hd[9],Pd[9]; rotX(-30*M_PI/180,Pd); vm::mul(H0,Pd,Hd); make_yaw_reference(Hd,Y); gbvr_head_to_engine(H0,Y,L,&yaw,&pit,&rol);
  printf("recenter while looking down, then level: pitch=%.3f yaw=%.3f\n",pit,yaw); fails += fabs(pit)>0.01||fabs(yaw)>0.01;
  // 6) random combos: L always a proper rotation
  int bad=0; for(int k=0;k<2000;k++){float a[9],b[9],c[9],t[9],u[9];rotY(k*0.37,a);rotX(sin(k*0.11)*1.2,b);rotZ(cos(k*0.07)*0.8,c);vm::mul(a,b,t);vm::mul(t,c,u);
    if(make_yaw_reference(u,Y)){gbvr_head_to_engine(u,Y,L,&yaw,&pit,&rol); if(!vm::is_rotation(L,1e-4)) bad++;}}
  printf("random poses: non-rotation results=%d\n",bad); fails+=bad;
  printf(fails?"FAILED %d\n":"ALL PASS\n",fails); return fails;
}
