// 1.7.165 "stress test both (the gun tube and the ghost health) and make sure they work in all environments":
// every setting range a player can pick, every health, every physics state, every frame rate / headset rate, both eyes and any IPD, any distance, boss + ghost mixes,
// dark and bright places (readable over black and over white), and long sessions. Everything must stay finite, inside its buffer, inside its place, and readable.
#include <cstdio>
#include <cmath>
#include "fightmath.h"
#include "healthposmath.h"
static long fails = 0;
#define CHECK(c) do { if (!(c)) { if (fails < 20) printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static unsigned long long sd = 0xD1B54A32D192ED03ULL;
static double rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (double)(sd >> 11) / 9007199254740992.0; }
static float luma(const float* c) { return 0.2126f * c[0] + 0.7152f * c[1] + 0.0722f * c[2]; }
static hand::Vertex gv[gunbar::kMaxVerts];
static cord::V bv[12000];
int main() {
  // ---- 1. the gun tube: every place setting (gun_hp_fwd_cm 0..40, gun_hp_up_cm -10..15, gun_hp_side_cm -20..20), every health, physics, slosh, beat, time
  long meshes = 0, worstN = 0;
  for (int fwd = 0; fwd <= 40; fwd += 5) for (int up = -10; up <= 15; up += 5) for (int side = -20; side <= 20; side += 10) for (int h = 0; h <= 100; h += 4) {
    gunbar::Liquid s; s.reset(); gunbar::step(&s, h / 100.0, 0.01);
    s.sx = (rnd() - 0.5) * 2.0 * gunbar::kMaxTilt * 1.4; s.sy = (rnd() - 0.5) * 2.0 * gunbar::kMaxTilt * 1.4; s.slosh = rnd(); s.beat = rnd(); s.t = rnd() * 3600.0; s.agit = rnd();
    if (rnd() < 0.3) { s.lost = s.shown + rnd() * (1.0 - s.shown); }
    const float zc = (float)(-0.01 * fwd), yc = (float)(0.01 * up), xc = (float)(0.01 * side);
    const gunbar::Layout L = {xc, yc, zc, 0.085f};
    hand::Mesh m = {gv, 0, gunbar::kMaxVerts};
    const int n = gunbar::build(&m, L, s); ++meshes; if (n > worstN) worstN = n;
    CHECK(n > 0 && n % 3 == 0 && n < gunbar::kMaxVerts);
    CHECK((size_t)n * sizeof(hand::Vertex) <= (size_t)9000 * sizeof(cord::V));   // fits the draw buffer (kUiCap)
    for (int i = 0; i < n; ++i) {
      const hand::Vertex& q = gv[i];
      for (int k = 0; k < 3; ++k) CHECK(q.p[k] == q.p[k] && q.n[k] == q.n[k]);
      CHECK(fabs(q.p[0] - xc) < 0.012f && q.p[1] - yc > -0.004f && q.p[1] - yc < 0.014f && q.p[2] - zc < 0.075f && q.p[2] - zc > -0.075f);   // stays in its place on the gun
      for (int k = 0; k < 4; ++k) CHECK(q.c[k] >= 0.0f && q.c[k] <= 1.0f);
      CHECK(q.c[3] == 0.0f || q.c[3] == 1.0f);
    }
  }
  // readable in every place: the liquid glows (emissive, so a dark level does not hide it) and differs from the dark housing; the colour changes with health
  for (int h = 1; h <= 100; ++h) { float c[3]; gunbar::liquid_colour(h / 100.0, c); CHECK(luma(c) > 0.14f); }
  { float a[3], b[3]; gunbar::liquid_colour(1.0, a); gunbar::liquid_colour(0.1, b); CHECK(a[1] > a[0] && b[0] > b[1]); }   // green full, red low
  // frame rates and headset rates: 20..240 FPS, hitches, 6-hour sessions: the liquid and its physics stay sane
  { gunbar::Liquid s; s.reset(); double t = 0; long bad = 0; float P[12] = {1,0,0,0, 0,1,0,1.2f, 0,0,1,0};
    while (t < 6 * 3600.0) { const double hz = 20 + rnd() * 220; double dt = 1.0 / hz; if (rnd() < 0.0005) dt = 0.5 + rnd() * 3.0;
      const double a = rnd() * 6.283; P[0] = (float)cos(a * 0.05); P[2] = (float)sin(a * 0.05); P[8] = -P[2]; P[10] = P[0]; P[3] += (float)((rnd() - 0.5) * 0.01);
      gunbar::step(&s, rnd() < 0.002 ? rnd() : s.target, dt); gunbar::step_phys(&s, P, dt); t += dt;
      if (!(s.shown == s.shown && s.sx == s.sx && s.t >= 0 && s.t <= 3600.0 && s.beat >= 0 && s.beat <= 1.0 && s.shown >= 0 && s.shown <= 1)) ++bad; }
    CHECK(bad == 0); }
  printf("  gun tube: %ld meshes (all place settings x health x physics), most vertices %ld of %d; 6 h at 20..240 FPS ok\n", meshes, worstN, (int)gunbar::kMaxVerts);

  // ---- 2. the ghost health: health_size 30..300 %, ring or bars, vial or old look, both eyes with any IPD, any distance and place, ghost + boss mixes
  long builds = 0, worstB = 0, over = 0;
  fight::Bar bars[fight::kMaxBars]; gunbar::Liquid liq[fight::kMaxBars];
  for (int it = 0; it < 60000; ++it) {
    const int nb = 1 + (int)(rnd() * fight::kMaxBars);
    for (int i = 0; i < nb; ++i) {
      const double z = rnd() < 0.1 ? 0.36 + rnd() : (rnd() < 0.1 ? 100 + rnd() * 400 : 0.5 + rnd() * 60);
      bars[i].p[0] = (float)((rnd() - 0.5) * 5.0 * z); bars[i].p[1] = (float)((rnd() - 0.5) * 5.0 * z); bars[i].p[2] = (float)(rnd() < 0.05 ? -z : z);
      if (rnd() < 0.01) bars[i].p[(int)(rnd() * 3)] = NAN;
      const int boss = rnd() < 0.1;
      bars[i].radius = boss ? (float)(z * 0.075) : (float)(0.05 + rnd() * 4.0); bars[i].frac = (float)(rnd() * 1.2 - 0.1);
      bars[i].flags = (rnd() < 0.3 ? fight::kFlagFocus : 0u) | (boss ? fight::kFlagBoss : 0u) | (rnd() < 0.3 ? fight::kFlagRecent : 0u); bars[i].actor = i + 1;
      liq[i].reset(); gunbar::step(&liq[i], rnd(), 0.01); liq[i].slosh = rnd(); liq[i].t = rnd() * 3600; liq[i].beat = rnd();
    }
    fight::Look lk; lk.sizePct = 30 + rnd() * 270; lk.digitsFocus = 0; lk.focusDeg = 7; lk.ringStyle = rnd() < 0.4; lk.liquid = rnd() < 0.8; lk.liq = rnd() < 0.9 ? liq : nullptr;
    const double eyeX = (rnd() - 0.5) * 0.08;   // either eye, IPD up to 80 mm
    const int n = fight::build(bars, nb, eyeX, lk, bv, 12000); ++builds;
    if (n < 0) { ++over; continue; }
    if (n > worstB) worstB = n;
    CHECK(n % 3 == 0);
    for (int i = 0; i < n; ++i) { for (int k = 0; k < 3; ++k) CHECK(bv[i].p[k] == bv[i].p[k]); CHECK(bv[i].p[2] > 0.0f); for (int k = 0; k < 4; ++k) CHECK(bv[i].c[k] >= 0.0f && bv[i].c[k] <= 1.0f); }
  }
  {   // a crowd too big for the buffer: the nearest ghosts keep their health, the farthest are the ones left out
    for (int i = 0; i < fight::kMaxBars; ++i) { bars[i].p[0] = 0.1f * i; bars[i].p[1] = 0; bars[i].p[2] = (float)(2.0 + i); bars[i].radius = 2; bars[i].frac = 0.5f; bars[i].flags = fight::kFlagFocus; bars[i].actor = i + 1; }
    fight::Look lk; lk.sizePct = 300; lk.digitsFocus = 0; lk.focusDeg = 7; lk.ringStyle = 1; lk.liquid = 0; lk.liq = nullptr;
    const int n = fight::build(bars, fight::kMaxBars, 0.0, lk, bv, 12000);
    float zmin = 1e9f, zmax = 0; for (int i = 0; i < n; ++i) { if (bv[i].p[2] < zmin) zmin = bv[i].p[2]; if (bv[i].p[2] > zmax) zmax = bv[i].p[2]; }
    CHECK(n > 0 && fabs(zmin - 2.0f) < 0.01f && zmax < 2.0f + fight::kMaxBars - 1);
    printf("  crowd of 24 rings at 300 %%: drawn %d vertices, nearest kept (%.1f m), farthest left out (up to %.1f m drawn)\n", n, zmin, zmax);
  }
  CHECK(over == 0);   // 24 ghosts at the biggest size never overflow the buffer
  // readable over a black sky and over a white wall: the vial has a black glass body (shows on white) and a glowing rim in the health colour (shows on black)
  for (int h = 0; h <= 100; h += 5) {
    fight::Bar b[1]; b[0].p[0] = 0; b[0].p[1] = 0; b[0].p[2] = 5; b[0].radius = 1; b[0].frac = (float)(h / 100.0); b[0].flags = 0; b[0].actor = 1;
    fight::Look lk; lk.sizePct = 100; lk.digitsFocus = 0; lk.focusDeg = 7; lk.ringStyle = 0; lk.liquid = 1; lk.liq = nullptr;
    const int n = fight::build(b, 1, 0.0, lk, bv, 12000);
    float maxL = 0, minL = 1; for (int i = 0; i < n; ++i) { const float L = luma(bv[i].c); if (L > maxL) maxL = L; if (L < minL) minL = L; }
    CHECK(maxL > 0.25f && minL < 0.03f);
  }
  printf("  ghost health: %ld builds (1-24 ghosts and bosses, size 30-300 %%, ring/bars, vial/old, both eyes, 0.36-500 m, NaN, behind you), most vertices %ld of 12000, overflows %ld\n", builds, worstB, over);

  // ---- 3. following ghosts at every game frame rate, with the scan thinned (the mod skips up to several frames when the actor list is slow)
  { long bad = 0; double worst = 0;
    for (int run = 0; run < 200; ++run) {
      float a[3] = {0, 0, 0}, v[3] = {0, 0, 0}, o[3]; int64_t q = 0; const int64_t F = 1000000; int64_t now = 1000;
      double x = 0, vx = (rnd() - 0.5) * 40; const double hz = 20 + rnd() * 220; const int skip = (int)(rnd() * 6);
      for (int i = 0; i < 3000; ++i) { now += (int64_t)(F / hz); x += vx / hz; if (rnd() < 0.01) vx = (rnd() - 0.5) * 40; if (skip && (i % (skip + 1))) continue;
        const float tg[3] = {(float)x, 1.0f, 2.0f}; healthpos::step_v(a, v, &q, tg, now, F, o);
        if (!(o[0] == o[0])) ++bad; const double e = fabs(o[0] - tg[0]); if (e > 0.605) ++bad; if (e > worst) worst = e; } }
    CHECK(bad == 0);
    printf("  follow: 200 runs at 20..240 FPS with 0..5 skipped scans: broken %ld, worst distance %.2f ft\n", bad, worst); }
  printf("%s health in all environments, %ld failures\n", fails ? "FAIL" : "PASS", fails);
  return fails ? 1 : 0;
}
