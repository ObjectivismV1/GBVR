// 1.7.163 the health bar / ring follows a moving ghost (healthposmath.h step_v): no trailing at steady speed, smooth on shaky positions, snaps on jumps, finite always.
#include <cstdio>
#include <cmath>
#include "healthposmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static unsigned long long sd = 0x9E3779B97F4A7C15ULL;
static double rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (double)(sd >> 11) / 9007199254740992.0; }
int main() {
  const int64_t F = 1000000;
  for (int fpsI = 0; fpsI < 4; ++fpsI) {   // a ghost flying 20 ft/s: after half a second the marker is on it (old smoother: about 1.4 ft behind, capped 0.6)
    const double fps = fpsI == 0 ? 30 : fpsI == 1 ? 45 : fpsI == 2 ? 90 : 144;
    float a[3] = {0, 0, 0}, v[3] = {0, 0, 0}, o[3], ao[3] = {0, 0, 0}; int64_t q = 0, qo = 0; double newErr = 0, oldErr = 0;
    for (int i = 0; i < (int)(fps * 1.5); ++i) {
      const double t = i / fps; const float tg[3] = {(float)(20.0 * t), 3.0f, 1.0f};
      const int64_t now = 1000 + (int64_t)(t * F);
      healthpos::step_v(a, v, &q, tg, now, F, o); float oo[3]; healthpos::step(ao, &qo, tg, now, F, oo);
      if (t > 0.5) { newErr = fmax(newErr, fabs(o[0] - tg[0])); oldErr = fmax(oldErr, fabs(oo[0] - tg[0])); }
    }
    CHECK(newErr < 0.05);
    printf("  20 ft/s ghost at %3.0f FPS: marker behind by %.3f ft (before: %.3f)\n", fps, newErr, oldErr);
  }
  {   // a hovering ghost whose position shakes by +-0.15 ft: the marker shakes less
    float a[3] = {0, 0, 0}, v[3] = {0, 0, 0}, o[3]; int64_t q = 0; double inSum = 0, outSum = 0, prevIn = 0, prevOut = 0;
    for (int i = 0; i < 2000; ++i) {
      const float tg[3] = {(float)((rnd() - 0.5) * 0.3), 0, 0};
      healthpos::step_v(a, v, &q, tg, 1000 + (int64_t)i * F / 90, F, o);
      if (i > 10) { inSum += fabs(tg[0] - prevIn); outSum += fabs(o[0] - prevOut); }
      prevIn = tg[0]; prevOut = o[0];
    }
    CHECK(outSum < inSum * 0.6);
    printf("  shaky hover: frame-to-frame movement %.0f%% of the raw shake\n", 100.0 * outSum / inSum);
  }
  {   // jumps snap, pauses snap, NaN never gets in, a turn round at speed never overshoots by more than the lag cap
    float a[3] = {0, 0, 0}, v[3] = {0, 0, 0}, o[3]; int64_t q = 0;
    const float t0[3] = {0, 0, 0}, j[3] = {30, 0, 0}, n[3] = {NAN, 0, 0};
    healthpos::step_v(a, v, &q, t0, 1000, F, o); healthpos::step_v(a, v, &q, j, 1000 + F / 90, F, o); CHECK(o[0] == 30.0f && v[0] == 0.0f);
    healthpos::step_v(a, v, &q, n, 1000 + 2 * F / 90, F, o); CHECK(o[0] == o[0] && o[0] == 30.0f);
    healthpos::step_v(a, v, &q, t0, 1000 + F, F, o); CHECK(o[0] == 0.0f);
    long bad = 0; double worst = 0; int64_t now = 1000 + 2 * F;
    for (int i = 0; i < 2000000; ++i) {   // random flight, random frame rates, sudden turns
      const double dt = 1.0 / (20 + rnd() * 220); now += (int64_t)(dt * F);
      static double x = 0, vx = 0; if (rnd() < 0.01) vx = (rnd() - 0.5) * 60; x += vx * dt; if (rnd() < 0.0005) x += 50;
      const float tg[3] = {(float)x, (float)(rnd() * 0.1), 2.0f};
      healthpos::step_v(a, v, &q, tg, now, F, o);
      if (!(o[0] == o[0] && v[0] == v[0])) ++bad;
      const double e = fabs(o[0] - tg[0]); if (e > 0.605) ++bad; if (e > worst) worst = e;
    }
    CHECK(bad == 0);
    printf("HEALTHFOLLOW STRESS: 2,000,000 frames of random flight at 20..240 FPS: broken %ld, worst distance %.2f ft (cap 0.6)\n", bad, worst);
  }
  printf("%s health follow, %d failures\n", fails ? "FAIL" : "PASS", fails);
  return fails ? 1 : 0;
}
