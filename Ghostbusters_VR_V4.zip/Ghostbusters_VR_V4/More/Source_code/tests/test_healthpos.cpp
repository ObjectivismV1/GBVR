#include "healthposmath.h"
#include <cassert>
#include <cmath>
int main() {
  float p[3] = {}, out[3], a[3] = {0,0,0}, b[3] = {0.1f,0,0}, jump[3] = {20,0,0};
  int64_t q = 0;
  healthpos::step(p, &q, a, 1000, 1000, out);
  assert(out[0] == 0.0f);
  healthpos::step(p, &q, b, 1010, 1000, out);
  assert(out[0] > 0.0f && out[0] < 0.1f);
  healthpos::step(p, &q, jump, 1020, 1000, out);
  assert(out[0] == 20.0f); // teleport snaps to the target
  float fast[3] = {21.0f,0,0};
  healthpos::step(p, &q, fast, 1030, 1000, out);
  assert(std::fabs(out[0] - 21.0f) <= 0.6001f);
  healthpos::step(p, &q, a, 1500, 1000, out);
  assert(out[0] == 0.0f); // no stale smoothing across a pause
}
