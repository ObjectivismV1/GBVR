// 1.7.28 the hand-held game menu: placement, smoothing, hand choice, activation, button rectangle (heldmath.h)
#include <stdio.h>
#include <math.h>
#include "heldmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static void pose(float x, float y, float z, float* p) { for (int i = 0; i < 12; ++i) p[i] = 0; p[0] = p[5] = p[10] = 1; p[3] = x; p[7] = y; p[11] = z; }
static double dot3(const float* a, const float* b) { return (double)a[0] * b[0] + (double)a[1] * b[1] + (double)a[2] * b[2]; }
int main() {
  // ---- placement: left hand 0.45 m in front of the head and 0.5 m lower, to the left
  float hand[12], head[12], xf[12];
  pose(-0.25f, 1.05f, -0.45f, hand); pose(0.f, 1.6f, 0.f, head);
  CHECK(held::place_panel(hand, head, 0.16, 0.05, xf) == 1);
  float X[3] = {xf[0], xf[4], xf[8]}, Y[3] = {xf[1], xf[5], xf[9]}, Z[3] = {xf[2], xf[6], xf[10]};
  CHECK(fabs(dot3(X, X) - 1) < 1e-5 && fabs(dot3(Y, Y) - 1) < 1e-5 && fabs(dot3(Z, Z) - 1) < 1e-5);   // orthonormal
  CHECK(fabs(dot3(X, Y)) < 1e-5 && fabs(dot3(X, Z)) < 1e-5 && fabs(dot3(Y, Z)) < 1e-5);
  CHECK(fabs(X[1]) < 1e-6);                                  // the right edge is level: the panel never rolls
  CHECK(Y[1] > 0.7);                                         // upright
  { // faces the eyes: the normal points from the middle to the head
    float c[3] = {xf[3], xf[7], xf[11]};
    float d[3] = {head[3] - c[0], head[7] - c[1], head[11] - c[2]};
    double l = sqrt(dot3(d, d)); d[0] /= (float)l; d[1] /= (float)l; d[2] /= (float)l;
    CHECK(dot3(d, Z) > 0.9999);
    CHECK(fabs(c[1] - (1.05 + 0.16)) < 1e-5);                // 16 cm above the hand
    CHECK(l > 0.35 && l < 0.8);                              // held at a readable distance
  }
  // right is really on the viewer's right: looking from the head toward the panel (along -normal), +x is to the right of that view
  { // viewer forward f = -Z; right = f x up = (-Zz... ) check against the convention of vmenu::place_in_front: right = (-fz, 0, fx)
    const double fx = -Z[0], fz = -Z[2], l = sqrt(fx * fx + fz * fz);
    CHECK(fabs(X[0] - (-fz / l)) < 1e-5 && fabs(X[2] - (fx / l)) < 1e-5);
  }
  // same answer as place_in_front when the panel is straight ahead of a head that looks along -z
  { float pf[12], ph[12]; pose(0.f, 1.6f, -0.5f, ph); pose(0.f, 1.2f, 0.f, pf); (void)pf; (void)ph; }
  // ---- degenerate: hand at the head, or the panel directly above/below the eyes
  { float h2[12]; pose(0.f, 1.6f, 0.f, h2); CHECK(held::place_panel(h2, head, 0.0, 0.0, xf) == 0); }
  { float h2[12]; pose(0.f, 0.9f, 0.f, h2); CHECK(held::place_panel(h2, head, 0.0, 0.05, xf) == 0 || fabs(xf[2]) < 1e-3); }   // straight below the eyes: no usable "right"
  // ---- smoothing
  held::Smooth sm; held::smooth_reset(&sm);
  double t[3] = {0, 1, 0}, o[3];
  held::smooth_step(&sm, t, 0.011, 0.08, o); CHECK(o[1] == 1.0);                  // first value is taken as it is
  t[1] = 1.1; held::smooth_step(&sm, t, 0.011, 0.08, o);
  CHECK(o[1] > 1.0 && o[1] < 1.1);                                                 // moves toward it, not all at once
  for (int i = 0; i < 100; ++i) held::smooth_step(&sm, t, 0.011, 0.08, o);
  CHECK(fabs(o[1] - 1.1) < 1e-3);                                                  // and gets there
  t[0] = 3.0; held::smooth_step(&sm, t, 0.011, 0.08, o); CHECK(o[0] == 3.0);       // a jump of metres is taken at once
  held::smooth_step(&sm, t, 0.0, 0.08, o); CHECK(o[0] == 3.0);                      // no time = no change
  // ---- the hand
  CHECK(held::kHoldingHand == 0);   // the logical left hand (the support hand, also when left-handed)
  // ---- active only when everything is true
  CHECK(held::is_active(1, 1, 1, 1) == 1);
  for (int i = 0; i < 4; ++i) { int a[4] = {1, 1, 1, 1}; a[i] = 0; CHECK(held::is_active(a[0], a[1], a[2], a[3]) == 0); }
  // ---- 1.7.29 the request window (no paused flag: the 1.7.28 run showed the pause menu never sets it)
  CHECK(held::request_recent(10000, 0) == 0);                       // no request
  CHECK(held::request_recent(10000, 9000) == 1);                    // 1 s after
  CHECK(held::request_recent(10000, 10000 - held::kRequestWindowMs + 1) == 1);
  CHECK(held::request_recent(10000, 10000 - held::kRequestWindowMs) == 0);   // too old
  CHECK(held::request_recent(10000, 10500) == 0);                   // a request in the future is nonsense
  CHECK(held::request_recent(100, 0xFFFFFF00u) == 0 || held::request_recent(100, 0xFFFFFF00u) == 1);   // the tick count wrapping around does not crash
  CHECK(held::request_recent(300, 0xFFFFFF00u) == 1);               // ... and a request just before the wrap is still recent just after it
  // ---- 1.7.29 the pointing ray against the panel
  { float head[12] = {1,0,0,0, 0,1,0,1.6f, 0,0,1,0};
    float hand[12] = {1,0,0,-0.2f, 0,1,0,1.05f, 0,0,1,-0.4f};     // left hand in front of the chest, below the eyes
    float xf[12];
    CHECK(held::place_panel(hand, head, 0.15, 0.08, xf) == 1);
    const double wM = 0.36, hM = 0.36;
    // a pointer hand that aims exactly at the panel's middle: hits at 0.5, 0.5
    const double cx = xf[3], cy = xf[7], cz = xf[11];
    float ph[12] = {1,0,0,0.15f, 0,1,0,1.15f, 0,0,1,-0.2f};
    double dx = cx - ph[3], dy = cy - ph[7], dz = cz - ph[11];
    const double dl = sqrt(dx*dx + dy*dy + dz*dz);
    dx /= dl; dy /= dl; dz /= dl;
    // build a pose whose -z is d: z = -d; right = up x z; up = z x right
    const double zx = -dx, zy = -dy, zz = -dz;
    double rx = 0*zz - 1*zy, ry = 1*zx - 0*zz, rz = 0*zy - 0*zx;    // (0,1,0) x z
    const double rl = sqrt(rx*rx + ry*ry + rz*rz); rx /= rl; ry /= rl; rz /= rl;
    const double ux = zy*rz - zz*ry, uy = zz*rx - zx*rz, uz = zx*ry - zy*rx;
    ph[0]=(float)rx; ph[4]=(float)ry; ph[8]=(float)rz; ph[1]=(float)ux; ph[5]=(float)uy; ph[9]=(float)uz; ph[2]=(float)zx; ph[6]=(float)zy; ph[10]=(float)zz;
    double u = -1, v = -1, t = -1;
    CHECK(held::ray_hit(ph, xf, wM, hM, 0.05, &u, &v, &t) == 1);
    CHECK(fabs(u - 0.5) < 0.01 && fabs(v - 0.5) < 0.01 && fabs(t - dl) < 0.01);
    // moving the hand to the right moves the hit to the right (u grows), up moves it up (v shrinks: v counts from the top)
    float ph2[12]; for (int i = 0; i < 12; ++i) ph2[i] = ph[i];
    ph2[3] += 0.04f;   // 4 cm right, the same direction: the ray lands 4 cm to the right of where it did
    double u2, v2, t2;
    CHECK(held::ray_hit(ph2, xf, wM, hM, 0.05, &u2, &v2, &t2) == 1);
    CHECK(u2 > u + 0.02);   // the ray is slanted across the panel, so 4 cm of hand is a little over 4 cm on it: u grows
    float ph3[12]; for (int i = 0; i < 12; ++i) ph3[i] = ph[i];
    ph3[7] += 0.04f;
    CHECK(held::ray_hit(ph3, xf, wM, hM, 0.05, &u2, &v2, &t2) == 1);
    CHECK(v2 < v - 0.05);   // up is smaller v
    // far off the panel: no hit; just past the edge (inside the margin): clamped to the edge
    float ph4[12]; for (int i = 0; i < 12; ++i) ph4[i] = ph[i];
    ph4[3] += 0.50f;
    CHECK(held::ray_hit(ph4, xf, wM, hM, 0.05, &u2, &v2, &t2) == 0);
    // walk the hand to the right until the plain test (no margin) loses the panel: the same spot with a margin is held on the edge (the pointer does not blink out at the border)
    { float ph5[12]; for (int i = 0; i < 12; ++i) ph5[i] = ph[i];
      int lostAt = -1;
      for (int k = 1; k <= 1500 && lostAt < 0; ++k) { ph5[3] = ph[3] + 0.001f * (float)k; double a1, b1, c1; if (!held::ray_hit(ph5, xf, wM, hM, 0.0, &a1, &b1, &c1)) lostAt = k; }
      CHECK(lostAt > 0);
      ph5[3] = ph[3] + 0.001f * (float)lostAt;
      double a2 = -1, b2 = -1, c2 = -1;
      CHECK(held::ray_hit(ph5, xf, wM, hM, 0.10, &a2, &b2, &c2) == 1 && a2 >= 0.0 && a2 <= 1.0 && (a2 > 0.97 || a2 < 0.03 || b2 > 0.97 || b2 < 0.03));
    }
    // pointing away (backwards): no hit
    float ph6[12]; for (int i = 0; i < 12; ++i) ph6[i] = ph[i];
    ph6[2] = -ph6[2]; ph6[6] = -ph6[6]; ph6[10] = -ph6[10];
    CHECK(held::ray_hit(ph6, xf, wM, hM, 0.05, &u2, &v2, &t2) == 0);
    // a ray parallel to the panel: no hit; a degenerate panel size: no hit
    CHECK(held::ray_hit(ph, xf, 0.0, hM, 0.05, &u2, &v2, &t2) == 0);
  }
  // ---- 1.7.29 the right stick scrolls
  { double acc = 0; int n = 0;
    CHECK(held::scroll_notches(&acc, 0.2, 0.011) == 0);            // inside the dead zone
    for (int i = 0; i < 100; ++i) n += held::scroll_notches(&acc, 1.0, 0.01);   // full push for one second
    CHECK(n >= 6 && n <= 8);                                        // about 7 notches a second
    n = 0; acc = 0;
    for (int i = 0; i < 100; ++i) n += held::scroll_notches(&acc, -1.0, 0.01);
    CHECK(n <= -6 && n >= -8);                                      // the other way
    acc = 0.9; held::scroll_notches(&acc, 0.0, 0.01); CHECK(acc == 0.0);   // letting go forgets the fraction
    acc = 0; CHECK(held::scroll_notches(&acc, 1.0, 5.0) <= 1);      // a long frame (a hitch) does not fling the list
  }
  // ---- the button
  { const held::Rect01 r = held::banner_rect();
    CHECK(r.u0 > 0.1 && r.u1 < 0.9 && r.v0 > 0.85 && r.v1 <= 1.0 && r.u0 < r.u1 && r.v0 < r.v1);
    CHECK(held::banner_hit(0.5, 0.96) == 1 && held::banner_hit(0.5, 0.5) == 0 && held::banner_hit(0.1, 0.96) == 0 && held::banner_hit(0.5, 0.90) == 0);
    int x0, y0, x1, y1; held::banner_box(2880, 2880, &x0, &y0, &x1, &y1);
    CHECK(x0 > 0 && x1 < 2880 && y0 > 2400 && y1 <= 2880 && x1 - x0 > 900 && y1 - y0 > 100);
    // the pixel box and the hit test agree
    CHECK(held::banner_hit((double)(x0 + 1) / 2880.0, (double)(y0 + 1) / 2880.0) == 1 && held::banner_hit((double)(x0 - 20) / 2880.0, (double)(y0 + 1) / 2880.0) == 0);
  }
  // ---- 1.7.31 keep the panel away from the eyes
  { float head[12] = {1, 0, 0, 0.0f, 0, 1, 0, 1.6f, 0, 0, 1, 0.0f};
    // hand beside the head: the panel centre 0.25 m from the eyes -> pushed out to 0.55 m, same direction
    float xf[12] = {1, 0, 0, 0.20f, 0, 1, 0, 1.60f, 0, 0, 1, -0.15f};
    const double d0 = sqrt(0.20 * 0.20 + 0.15 * 0.15);
    CHECK(d0 < 0.3);
    CHECK(held::keep_away(head, 0.36, xf, 55.0) == 1);
    { const double dx = xf[3], dy = xf[7] - 1.6, dz = xf[11]; const double d = sqrt(dx * dx + dy * dy + dz * dz);
      CHECK(fabs(d - 0.55) < 1e-4);
      CHECK(fabs(dx / d - 0.20 / d0) < 1e-4 && fabs(dz / d - (-0.15) / d0) < 1e-4);   // same direction
    }
    // already far enough: untouched
    float xf2[12] = {1, 0, 0, 0.0f, 0, 1, 0, 1.6f, 0, 0, 1, -0.7f};
    CHECK(held::keep_away(head, 0.36, xf2, 55.0) == 0 && fabs(xf2[11] - (-0.7f)) < 1e-6);
    // off: untouched
    float xf3[12] = {1, 0, 0, 0.1f, 0, 1, 0, 1.6f, 0, 0, 1, -0.1f};
    CHECK(held::keep_away(head, 0.36, xf3, 0.0) == 0 && fabs(xf3[3] - 0.1f) < 1e-6);
    // a wide panel (the VR pages, 64 cm) keeps the same angular size: the distance grows with the width
    float xf4[12] = {1, 0, 0, 0.0f, 0, 1, 0, 1.6f, 0, 0, 1, -0.5f};
    CHECK(held::keep_away(head, 0.64, xf4, 55.0) == 1 && fabs(-xf4[11] - 0.55 * 0.64 / 0.36) < 1e-3);
    // the panel on top of the head (no direction): left alone
    float xf5[12] = {1, 0, 0, 0.0f, 0, 1, 0, 1.6f, 0, 0, 1, 0.0f};
    CHECK(held::keep_away(head, 0.36, xf5, 55.0) == 0);
    // the push keeps the panel facing the head: the panel's normal still points at the eyes
    float hand[12] = {1, 0, 0, 0.18f, 0, 1, 0, 1.55f, 0, 0, 1, -0.10f}, pxf[12];
    CHECK(held::place_panel(hand, head, 0.15, 0.08, pxf) == 1);
    const double n0[3] = {pxf[2], pxf[6], pxf[10]};
    held::keep_away(head, 0.36, pxf, 55.0);
    { const double ex = head[3] - pxf[3], ey = head[7] - pxf[7], ez = head[11] - pxf[11]; const double el = sqrt(ex * ex + ey * ey + ez * ez);
      CHECK(fabs(ex / el - n0[0]) < 1e-3 && fabs(ey / el - n0[1]) < 1e-3 && fabs(ez / el - n0[2]) < 1e-3); }
  }
  // 1.7.84: when do the menu pages open over the LIVE world (game frozen) instead of the game's own pause menu (3D drawing stops, only a still picture stays)?
  CHECK(held::live_wanted(1, 1, 0, 1) == 1);   // setting on, headset view, 3D view, game running
  CHECK(held::live_wanted(0, 1, 0, 1) == 0);   // setting off: the game's own menu
  CHECK(held::live_wanted(1, 0, 0, 1) == 0);   // no headset view
  CHECK(held::live_wanted(1, 1, 1, 1) == 0);   // already a flat screen (a cutscene, a menu, a loading screen): nothing live to show
  CHECK(held::live_wanted(1, 1, 0, 0) == 0);   // the game does not run (already paused / loading)
  printf(fails ? "test_held FAILED\n" : "test_held OK\n");
  return fails ? 1 : 0;
}
