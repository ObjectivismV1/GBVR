// 1.7.148 tests for hosemath.h (the game's hose bent to the drawn gun)
#include <cstdio>
#include <cmath>
#include "hosemath.h"

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)

static void rotY(double deg, double tx, double ty, double tz, float* m) {
  const double a = deg * 3.14159265358979 / 180.0, c = cos(a), s = sin(a);
  // row form of a turn about +y: x axis -> (c, 0, -s), z axis -> (s, 0, c)
  float r[16] = {(float)c, 0, (float)-s, 0,  0, 1, 0, 0,  (float)s, 0, (float)c, 0,  (float)tx, (float)ty, (float)tz, 1};
  for (int i = 0; i < 16; ++i) m[i] = r[i];
}
static double dist(const float* a, const float* b) { double d = 0; for (int i = 12; i < 15; ++i) d += (double)(a[i] - b[i]) * (a[i] - b[i]); return sqrt(d); }

int main() {
  // a hose: root at the pack, 10 segments of 0.2 along +z, plus a side bone off segment 3
  const int n = 12;
  int parent[n] = {-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 3};
  float world[n * 16];
  for (int i = 0; i < n; ++i) { rotY(0, 0, 0, 0.2 * i, world + 16 * i); }
  world[16 * 11 + 12] = 0.1f; world[16 * 11 + 14] = 0.6f;
  int chain[64];
  const int cn = hose::longest_chain(parent, n, chain, 64);
  CHECK(cn == 11 && chain[0] == 0 && chain[10] == 10);
  float w[n];
  const double L = hose::chain_weights(world, parent, n, chain, cn, 0, w);
  CHECK(fabs(L - 2.0) < 1e-5);
  CHECK(w[0] == 0.0f && w[10] == 1.0f && w[5] > 0.45f && w[5] < 0.55f && w[11] == w[3]);
  for (int i = 1; i <= 10; ++i) CHECK(w[i] >= w[i - 1]);   // smooth and growing to the gun end
  float wr[n]; hose::chain_weights(world, parent, n, chain, cn, 1, wr);
  CHECK(wr[0] == 1.0f && wr[10] == 0.0f);
  // bad skeletons
  int loop[3] = {-1, 2, 1};
  int scratch[64];
  CHECK(hose::longest_chain(loop, 3, scratch, 64) == 0);          // a loop
  int out_[3] = {-1, 7, 0};
  CHECK(hose::longest_chain(out_, 3, scratch, 64) == 0);          // a parent out of range
  int anyOrder[4] = {2, -1, 1, 0};                                // children before parents: 1 <- 2 <- 0 <- 3
  CHECK(hose::longest_chain(anyOrder, 4, scratch, 64) == 4 && scratch[0] == 1 && scratch[3] == 3);
  // the move: the game's gun at the hose end (0,0,2) facing +z; the drawn gun 0.5 higher, 0.3 right, turned 40 degrees
  float hoseGame[16], hoseDraw[16], gunGame[16], gunDraw[16];
  rotY(10, 5, 1, 3, hoseGame);           // hose model -> game world
  rotY(25, 5.2, 1.1, 3.4, hoseDraw);     // the body follow moved / turned it a little
  float gunModel[16]; rotY(0, 0, 0, 2, gunModel);
  // gunGame = gunModel x hoseGame
  double gm[16], hg[16], o[16]; hose::to44(gunModel, gm); hose::to44(hoseGame, hg); hose::mul44(gm, hg, o); for (int i = 0; i < 16; ++i) gunGame[i] = (float)o[i];
  float gunDrawModel[16]; rotY(40, 0.3, 0.5, 2.0, gunDrawModel);
  double gdm[16], hd[16]; hose::to44(gunDrawModel, gdm); hose::to44(hoseDraw, hd); hose::mul44(gdm, hd, o); for (int i = 0; i < 16; ++i) gunDraw[i] = (float)o[i];
  double Dm[16];
  CHECK(hose::model_move(hoseGame, hoseDraw, gunGame, gunDraw, Dm));
  // the gun end bone (equal to the game gun in model space) must land exactly on the drawn gun in model space
  float endOut[16];
  CHECK(hose::blend_bone(world + 16 * 10, Dm, 1.0, endOut));
  CHECK(dist(endOut, gunDrawModel) < 1e-4);
  for (int i = 0; i < 9; ++i) if (i % 4 != 3) CHECK(fabs(endOut[(i / 3) * 4 + i % 3] - gunDrawModel[(i / 3) * 4 + i % 3]) < 1e-4);
  // the pack end stays
  float rootOut[16]; CHECK(hose::blend_bone(world, Dm, 0.0, rootOut)); CHECK(dist(rootOut, world) < 1e-9);
  // the whole hose stays connected: neighbouring bones never jump apart (no segment longer than 2.5 x its rest length)
  float bent[n * 16];
  for (int i = 0; i < n; ++i) CHECK(hose::blend_bone(world + 16 * i, Dm, w[i], bent + 16 * i));
  for (int k = 1; k < cn; ++k) { const double seg = dist(bent + 16 * chain[k], bent + 16 * chain[k - 1]); CHECK(seg < 0.5 && seg > 0.05); }
  // half way: the turn is half (the axes stay unit length with no size change)
  float half[16]; CHECK(hose::blend_bone(world + 16 * 10, Dm, 0.5, half));
  const double ang = acos(fmax(-1.0, fmin(1.0, (double)half[0]))) * 180.0 / 3.14159265358979;
  CHECK(fabs(ang - 20.0) < 0.5);
  CHECK(fabs(sqrt((double)half[0] * half[0] + half[1] * half[1] + half[2] * half[2]) - 1.0) < 1e-4);
  // a half turn (180 degrees) still gives a finite, unit result
  float flip[16]; rotY(180, 0, 0, 0, flip);
  double Df[16]; hose::to44(flip, Df);
  float out[16]; CHECK(hose::blend_bone(world + 16 * 5, Df, 0.5, out));
  for (int i = 0; i < 16; ++i) CHECK(std::isfinite(out[i]));
  // non-invertible inputs are refused
  float zero[16] = {0}; CHECK(!hose::model_move(zero, hoseDraw, gunGame, gunDraw, Dm));
  if (!fails) printf("hose: ok\n");
  return fails ? 1 : 0;
}
