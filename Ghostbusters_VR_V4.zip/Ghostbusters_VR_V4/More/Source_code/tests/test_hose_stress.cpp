// 1.7.150 stress test for the game's hose bent to the drawn gun (hosemath.h bend / Keeper). Run by tests/run_all.sh.
// A 16-bone hose hangs from the pack and sways (the game's animation); the game's gun sits at its end. For 60000 frames (about 11 minutes at 90 Hz) the drawn gun
// wanders up to 3 ft and any angle away from the game's gun, the body follow turns the drawn hose, the game sometimes does not pose the hose again (pause), every
// frame is bent twice (two eyes), the PKE comes out (the hose end leaves the gun), and broken matrices are thrown in.
#include <cmath>
#include <cstdio>
#include <cstring>
#include <chrono>
#include <vector>
#include <algorithm>
#include "hosemath.h"

static unsigned g_seed = 777;
static double urand() { g_seed = g_seed * 1664525u + 1013904223u; return (g_seed >> 8) / 16777216.0; }
static double nrand() { double u = urand() + 1e-12, v = urand(); return std::sqrt(-2.0 * std::log(u)) * std::cos(6.283185307 * v); }

static void euler(double yaw, double pitch, double roll, double s, double tx, double ty, double tz, float* m) {
  const double cy = cos(yaw), sy = sin(yaw), cp = cos(pitch), sp = sin(pitch), cr = cos(roll), sr = sin(roll);
  // column form R = Ry * Rx * Rz, stored as rows (transpose)
  const double c[9] = {cy * cr + sy * sp * sr, -cy * sr + sy * sp * cr, sy * cp,  cp * sr, cp * cr, -sp,  -sy * cr + cy * sp * sr, sy * sr + cy * sp * cr, cy * cp};
  for (int r = 0; r < 3; ++r) for (int k = 0; k < 3; ++k) m[r * 4 + k] = (float)(c[k * 3 + r] * s);
  m[3] = m[7] = m[11] = 0; m[12] = (float)tx; m[13] = (float)ty; m[14] = (float)tz; m[15] = 1;
}
static void mulf(const float* a, const float* b, float* o) { double A[16], B[16], O[16]; hose::to44(a, A); hose::to44(b, B); hose::mul44(A, B, O); for (int i = 0; i < 16; ++i) o[i] = (float)O[i]; }
static int invf(const float* a, float* o) { double A[16], O[16]; hose::to44(a, A); if (!hose::inv_affine(A, O)) return 0; for (int i = 0; i < 16; ++i) o[i] = (float)O[i]; return 1; }
static double pdist(const float* a, const float* b) { double d = 0; for (int i = 12; i < 15; ++i) d += (double)(a[i] - b[i]) * (a[i] - b[i]); return std::sqrt(d); }

static const int N = 16;
static int g_parent[N], g_chain[N], g_cn;

// the game's animated hose in its model space at time t: hangs from the pack (origin), sags, sways; bone 15 is the gun end
static void game_hose(double t, float* pose) {
  for (int i = 0; i < N; ++i) {
    const double s = i / (double)(N - 1);
    const double x = 0.9 * s + 0.15 * std::sin(1.3 * t + 3.0 * s) * s * (1 - s) * 4.0;
    const double y = -1.6 * std::sin(3.14159 * s) * 0.6 + 0.6 * s + 0.08 * std::sin(2.1 * t + 5.0 * s) * s * (1 - s) * 4.0;
    const double z = 1.4 * s;
    euler(0.4 * s + 0.1 * std::sin(t), 0.3 * std::sin(3.14159 * s), 0.0, 1.0, x, y, z, pose + 16 * i);
  }
}

int main() {
  for (int i = 0; i < N; ++i) g_parent[i] = i - 1;
  g_cn = hose::longest_chain(g_parent, N, g_chain, N);
  if (g_cn != N) { printf("FAIL chain %d\n", g_cn); return 1; }
  static hose::Keeper keep; memset(&keep, 0, sizeof keep);
  float cache[N * 16], truth[N * 16];
  int fails = 0; long frames = 60000, bentFrames = 0, refusedFar = 0, refusedBad = 0, paused = 0;
  double maxEndErr = 0, maxPackErr = 0, maxEyeDiff = 0, maxAccum = 0, maxStepRatio = 0, maxStretch = 0, minStretch = 1e9, ns = 0; long calls = 0;
  std::vector<double> stretches;
  double gx = 0, gy = 0, gz = 0, gyaw = 0, gpitch = 0, groll = 0, vx = 0, vy = 0, vz = 0;
  float prevBent[N * 16]; int havePrev = 0; float prevGunDraw[16]; double prevT = -1;
  double t = 0; int pkeOut = 0;
  game_hose(0, truth); memcpy(cache, truth, sizeof cache);
  for (long f = 0; f < frames; ++f) {
    // the game poses the hose again on most frames (not while paused)
    const int pause = (f % 1500) > 1380;
    if (!pause) { t += 1.0 / 90.0; game_hose(t, truth); memcpy(cache, truth, sizeof cache); } else ++paused;
    if (f % 4000 == 3000) pkeOut = 1;
    if (f % 4000 == 3400) pkeOut = 0;
    // the hose's own matrices: game world, and drawn (the body follow turned / moved it)
    float hoseGame[16], hoseDraw[16];
    euler(0.3 + 0.2 * std::sin(0.1 * t), 0, 0, 1.0, 100 + 2 * std::sin(0.05 * t), 5, 200, hoseGame);
    euler(0.3 + 0.2 * std::sin(0.1 * t) + 0.5 * std::sin(0.23 * t), 0, 0, 1.0, 100.3 + 2 * std::sin(0.05 * t), 5.1, 199.8, hoseDraw);
    // the game's gun: at the hose's end bone (0.3 ft along it), in game world. With the PKE out the gun is stowed 4 ft away from the hose end.
    float gunLocal[16], gunModel[16], gunGame[16];
    euler(0.2, 0.1, 0, 1.0, 0.2, 0.1, 0.2, gunLocal);
    mulf(gunLocal, truth + 16 * (N - 1), gunModel);
    if (pkeOut) { gunModel[12] += 3.0f; gunModel[13] += 2.5f; gunModel[14] -= 1.0f; }
    mulf(gunModel, hoseGame, gunGame);
    // the drawn gun: wanders up to about 3 ft and any angle from where the game's gun would be drawn
    vx = 0.97 * vx + 0.03 * nrand() * 2.0; vy = 0.97 * vy + 0.03 * nrand() * 2.0; vz = 0.97 * vz + 0.03 * nrand() * 2.0;
    gx = std::max(-3.0, std::min(3.0, gx + vx / 90.0)); gy = std::max(-2.0, std::min(2.5, gy + vy / 90.0)); gz = std::max(-3.0, std::min(3.0, gz + vz / 90.0));
    gyaw += 0.02 * nrand(); gpitch = 0.995 * gpitch + 0.02 * nrand(); groll = 0.995 * groll + 0.02 * nrand();
    float off[16], gunDrawModel[16], gunDraw[16];
    euler(gyaw, gpitch, groll, 1.0, gx, gy, gz, off);
    mulf(gunModel, off, gunDrawModel);            // moved / turned in the hose's model space
    mulf(gunDrawModel, hoseDraw, gunDraw);
    // broken input now and then
    const int broken = (f % 997) == 500;
    float gunDrawUse[16]; memcpy(gunDrawUse, gunDraw, sizeof gunDraw);
    if (broken) { if (f & 1) gunDrawUse[5] = NAN; else memset(gunDrawUse, 0, sizeof gunDrawUse); }
    // eye 1 and eye 2
    float eye1[N * 16]; int r1 = 0, r2 = 0; double endFt = 0;
    auto t0 = std::chrono::steady_clock::now();
    r1 = hose::bend(&keep, cache, g_parent, N, g_chain, g_cn, hoseGame, hoseDraw, gunGame, gunDrawUse, 2.5, &endFt);
    auto t1 = std::chrono::steady_clock::now();
    ns += std::chrono::duration<double, std::nano>(t1 - t0).count(); ++calls;
    memcpy(eye1, cache, sizeof cache);
    r2 = hose::bend(&keep, cache, g_parent, N, g_chain, g_cn, hoseGame, hoseDraw, gunGame, gunDrawUse, 2.5, &endFt);
    for (int i = 0; i < N * 16; ++i) if (!std::isfinite(cache[i])) { printf("FAIL non-finite bone at frame %ld\n", f); return 1; }
    if (r1 != r2) { printf("FAIL the two eyes disagree (%d / %d) at frame %ld\n", r1, r2, f); ++fails; }
    for (int i = 0; i < N * 16; ++i) maxEyeDiff = std::max(maxEyeDiff, (double)std::fabs(cache[i] - eye1[i]));
    if (r1 != 1) {
      // refused: the cache must hold the game's own pose exactly (nothing hidden, nothing half bent)
      if (memcmp(cache, truth, sizeof cache) != 0) { printf("FAIL a refused bend did not leave the game's pose (frame %ld, r %d)\n", f, r1); ++fails; }
      if (r1 < 0) ++refusedFar; else ++refusedBad;
      if (pkeOut && r1 != -1) { printf("FAIL PKE out but not refused as 'far' (frame %ld)\n", f); ++fails; }
      if (!pkeOut && !broken) { printf("FAIL refused with good input (frame %ld, r %d, end %.2f ft)\n", f, r1, endFt); ++fails; }
      havePrev = 0;
      continue;
    }
    ++bentFrames;
    if (pkeOut || broken) { printf("FAIL bent with the PKE out / broken input (frame %ld)\n", f); ++fails; }
    // the pack end did not move
    maxPackErr = std::max(maxPackErr, pdist(cache, truth));
    // the gun end is where the game's hose end sits on the DRAWN gun: end x inv(gunModel) x gunDrawModel (model space)
    float iGun[16], rel[16], want[16];
    invf(gunModel, iGun); mulf(truth + 16 * (N - 1), iGun, rel); mulf(rel, gunDrawModel, want);
    maxEndErr = std::max(maxEndErr, pdist(cache + 16 * (N - 1), want));
    // no piling up: the same answer as bending the true game pose from scratch
    static hose::Keeper fresh; memset(&fresh, 0, sizeof fresh);
    float scratch[N * 16]; memcpy(scratch, truth, sizeof scratch);
    hose::bend(&fresh, scratch, g_parent, N, g_chain, g_cn, hoseGame, hoseDraw, gunGame, gunDraw, 2.5, nullptr);
    for (int i = 0; i < N * 16; ++i) maxAccum = std::max(maxAccum, (double)std::fabs(scratch[i] - cache[i]));
    // stretch of each segment against the game's own
    for (int k = 1; k < N; ++k) {
      const double a = pdist(cache + 16 * k, cache + 16 * (k - 1)), b = pdist(truth + 16 * k, truth + 16 * (k - 1));
      const double sr = a / b; stretches.push_back(sr); maxStretch = std::max(maxStretch, sr); minStretch = std::min(minStretch, sr);
    }
    // smooth in time: no bone moves much further in a frame than the gun did (plus the game's own sway)
    if (havePrev && prevT == t - 1.0 / 90.0) {
      const double gunMove = pdist(gunDraw, prevGunDraw) + 0.02;
      for (int k = 0; k < N; ++k) maxStepRatio = std::max(maxStepRatio, pdist(cache + 16 * k, prevBent + 16 * k) / gunMove);
    }
    memcpy(prevBent, cache, sizeof cache); memcpy(prevGunDraw, gunDraw, sizeof gunDraw); havePrev = 1; prevT = t;
  }
  std::sort(stretches.begin(), stretches.end());
  const double p50 = stretches[stretches.size() / 2], p99 = stretches[(size_t)(stretches.size() * 0.99)];
  printf("hose stress: %ld frames (%ld paused), bent %ld, kept the game's pose %ld (PKE out) + %ld (broken input)\n", frames, paused, bentFrames, refusedFar, refusedBad);
  printf("  gun end off the drawn gun: %.5f ft max | pack end moved: %.6f ft max | two eyes differ: %g | piling up: %g\n", maxEndErr, maxPackErr, maxEyeDiff, maxAccum);
  printf("  segment stretch (1 = the game's own length): median %.2f, 99%% %.2f, max %.2f, min %.2f | bone move per frame / gun move: %.2f max | %.0f ns a call\n", p50, p99, maxStretch, minStretch, maxStepRatio, ns / calls);
  if (maxEndErr > 2e-3) { printf("FAIL the gun end is off the gun\n"); ++fails; }
  if (maxPackErr > 1e-6) { printf("FAIL the pack end moved\n"); ++fails; }
  if (maxEyeDiff != 0.0) { printf("FAIL the two eyes got different hoses\n"); ++fails; }
  if (maxAccum > 1e-4) { printf("FAIL the bend piles up\n"); ++fails; }
  if (maxStepRatio > 3.0) { printf("FAIL the hose jumps\n"); ++fails; }
  if (bentFrames < frames * 0.8) { printf("FAIL too few frames bent\n"); ++fails; }
  printf(fails ? "HOSE STRESS: FAILED (%d)\n" : "HOSE STRESS: all OK\n", fails);
  return fails ? 1 : 0;
}
