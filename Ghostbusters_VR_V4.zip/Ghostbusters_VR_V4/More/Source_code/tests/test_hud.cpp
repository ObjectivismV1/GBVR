// Unit tests for the 0.29 overlay placement (src/hudmath.h).
// Build: g++ -std=c++17 -O1 -o tests/test_hud tests/test_hud.cpp && tests/test_hud
#include "../src/hudmath.h"
#include "../src/stereomath.h"
#include <cmath>
#include <cstdio>
static int fails;
static void check(const char* name, bool ok, double v = 0) { printf("%s %s (%.6g)\n", ok ? "PASS" : "FAIL", name, v); fails += !ok; }

int main() {
  // Quest 3 (0.21 log) and the 0.27 run: frame 3840 x 2160, F7 on (tanH 1.37638, tanV 1.42815), eyes +-35.34 mm
  const float L[2] = {-1.37638f, -0.83910f}, R[2] = {0.83910f, 1.37638f}, T[2] = {-1.42815f, -1.42815f}, B[2] = {0.96569f, 0.96569f};
  const double eyeX[2] = {-0.03534, 0.03534};
  const int W = 3840, H = 2160;
  const double tanH = 1.37638, tanV = 1.42815;
  hud::Xf x[2];
  for (int e = 0; e < 2; ++e) check(e ? "right eye parameters" : "left eye parameters", hud::make(W, H, tanH, tanV, eyeX[e], 100, 2.5, &x[e]), e);
  check("size 100 %: 60 degrees wide", fabs(2 * atan(x[0].a) * 180 / M_PI - 60.0) < 0.01, 2 * atan(x[0].a) * 180 / M_PI);
  check("keeps the overlay's own shape (16:9 in angle)", fabs(x[0].a / x[0].b - 16.0 / 9.0) < 1e-9, x[0].a / x[0].b);
  check("left eye moves it right, right eye left, by the same amount", x[0].dx > 0 && x[1].dx < 0 && fabs(x[0].dx + x[1].dx) < 1e-9, x[0].dx);
  check("2.5 m: 14.1 mrad per eye = about 19.7 px at this frame", fabs(x[0].dx - 0.014136 / tanH * W / 2) < 1e-6 && fabs(x[0].dx - 19.72) < 0.05, x[0].dx);
  // where does the overlay centre end up for each eye, in that eye's own view (tan)? both must see it straight ahead
  // of the head at 2.5 m: the left eye (at -e) looks +e/D to the right, the right eye -e/D
  for (int e = 0; e < 2; ++e) {
    double px = x[e].cx + x[e].dx;                         // frame pixel of the overlay centre
    double t = (px / W * 2 - 1) * tanH;                    // that pixel's tan in the eye's frustum
    check(e ? "right eye sees the overlay centre at -e/D" : "left eye sees the overlay centre at -e/D", fabs(t - (-eyeX[e] / 2.5)) < 1e-9, t);
  }
  // the two lines of sight meet 2.5 m in front of the head
  { double tl = -eyeX[0] / 2.5, tr = -eyeX[1] / 2.5; double D = (eyeX[1] - eyeX[0]) / (tl - tr);
    check("both lines of sight meet 2.5 m away", fabs(D - 2.5) < 1e-9, D); }
  // the whole overlay is inside both eyes' views (frame corners of the overlay in each eye's tan space)
  for (int e = 0; e < 2; ++e) {
    int l, t, w, h; hud::apply(x[e], 0, 0, W, H, &l, &t, &w, &h);
    double tl = ((double)l / W * 2 - 1) * tanH, tr = ((double)(l + w) / W * 2 - 1) * tanH;
    double tt = (1 - (double)t / H * 2) * tanV, tb = (1 - (double)(t + h) / H * 2) * tanV;   // up positive
    // OpenVR: left/right extents L/R; "top" negative = downward extent, "bottom" positive = upward extent
    bool inside = tl >= L[e] && tr <= R[e] && tt <= B[e] && tb >= T[e];
    check(e ? "right eye: the whole overlay is in view" : "left eye: the whole overlay is in view", inside, tr);
    check("overlay rectangle is the frame scaled by sx/sy", abs(w - (int)lround(x[e].sx * W)) <= 1 && abs(h - (int)lround(x[e].sy * H)) <= 1, w);
  }
  // a sub-rectangle (a subtitle box with its own viewport) moves exactly like the same pixels of the full overlay
  { int l1, t1, w1, h1, l2, t2, w2, h2;
    hud::apply(x[0], 0, 0, W, H, &l1, &t1, &w1, &h1);
    hud::apply(x[0], 960, 1700, 1920, 300, &l2, &t2, &w2, &h2);
    double ex = l1 + 960.0 * w1 / W, ey = t1 + 1700.0 * h1 / H;
    check("sub-viewport keeps its place inside the overlay (within a pixel)", fabs(l2 - ex) <= 1.0 && fabs(t2 - ey) <= 1.0, l2 - ex);
    check("sub-viewport keeps its size", abs(w2 - (int)lround(1920 * x[0].sx)) <= 1 && abs(h2 - (int)lround(300 * x[0].sy)) <= 1, w2); }
  // the reticle (virtual 640,360 = frame centre) ends up straight ahead at the overlay distance
  { int l, t, w, h; hud::apply(x[0], 0, 0, W, H, &l, &t, &w, &h);
    double c = l + w / 2.0; check("reticle: frame centre -> centre + shift", fabs(c - (W / 2.0 + x[0].dx)) <= 1.0, c); }
  // F7 off: tanH = aspect * tanV
  { hud::Xf y; int ok = hud::make(W, H, 2.53893, 1.42815, -0.03534, 100, 2.5, &y);
    check("F7 off works too", ok && fabs(y.sx - x[0].a / 2.53893) < 1e-12 && fabs(y.sy - x[0].sy) < 1e-12, ok ? y.sx : 0); }
  // limits
  { hud::Xf y; hud::make(W, H, tanH, tanV, -0.03534, 400, 2.5, &y);
    check("size limited so it stays inside both eyes", y.a + fabs(y.shift) <= hud::kMaxHalfWidth + 1e-12 && y.b <= hud::kMaxHalfHeight + 1e-12, y.a);
    hud::make(W, H, tanH, tanV, -0.03534, 100, 0.5, &y);
    check("very near overlay: still limited", y.a + fabs(y.shift) <= hud::kMaxHalfWidth + 1e-12, y.a); }
  { hud::Xf y; check("bad input refused", !hud::make(W, H, 0, tanV, 0.03, 100, 2.5, &y) && !hud::make(W, H, tanH, tanV, 0.5, 100, 2.5, &y) &&
                       !hud::make(W, H, tanH, tanV, 0.03, 100, 0.0, &y) && !hud::make(10, 10, tanH, tanV, 0.03, 100, 2.5, &y)); }
  { hud::Xf y; int l, t, w, h; hud::make(W, H, tanH, tanV, 0.03534, 100, 2.5, &y); hud::apply(y, 100, 100, 0, 0, &l, &t, &w, &h);
    check("empty rectangle stays at least 1 x 1", w >= 1 && h >= 1); }
  // a headset with a narrower nasal side: the overlay shrinks to stay inside it
  { hud::Xf y; int ok = hud::make(W, H, tanH, tanV, -0.03534, 130, 2.5, &y, 0.60, 0.95);
    check("narrow headset: overlay kept 5 % inside the smaller half-view", ok && y.a + fabs(y.shift) <= 0.60 * 0.95 + 1e-12, ok ? y.a : 0);
    ok = hud::make(W, H, tanH, tanV, -0.03534, 100, 2.5, &y, 0.83910, 0.96569);
    check("Quest 3 limits leave the 100 % overlay unchanged", ok && fabs(y.a - x[0].a) < 1e-12, ok ? y.a : 0);
    ok = hud::make(W, H, tanH, tanV, -0.03534, 100, 2.5, &y, 0.03, 0.03);
    check("implausible limits (below 0.2) are ignored, not obeyed", ok && fabs(y.a - x[0].a) < 1e-12, ok ? y.a : 0);
    ok = hud::make(W, H, tanH, tanV, -0.03534, 100, 0.2, &y, 0.21, 0.95);
    check("limits that leave almost nothing: refused rather than a dot", !ok, ok ? y.a : 0); }
  // text size in the headset: a 20-pixel (of 720) letter at size 100 %
  // a 20/720 letter at size 100 %: about 1 degree tall - like text on a big monitor at desk distance
  { double deg = 20.0 / 720.0 * 2 * x[0].b * 180 / M_PI; check("a 20/720 letter is about 1 degree tall at size 100 %", deg > 0.9 && deg < 1.2, deg);
    hud::Xf y; hud::make(W, H, tanH, tanV, -0.03534, 130, 2.5, &y);
    double deg2 = 20.0 / 720.0 * 2 * y.b * 180 / M_PI; check("size 130 %: about 1.3 degrees", deg2 > 1.2 && deg2 < 1.5, deg2); }
  // 0.30: round_i is written out (no C runtime floor in the DLL); it must equal floor(v + 0.5)
  {
    int bad = 0;
    double worst = 0;
    for (int k = -400000; k <= 400000; ++k) {
      double v = k * 0.01 + (k % 7) * 1e-4;
      if (hud::round_i(v) != (int)std::floor(v + 0.5)) { ++bad; worst = v; }
    }
    const double halves[] = {-2.5, -1.5, -0.5, 0.5, 1.5, 2.5, 3839.5, -0.4999999, 0.4999999};
    for (double v : halves) if (hud::round_i(v) != (int)std::floor(v + 0.5)) { ++bad; worst = v; }
    check("round_i == floor(v + 0.5) over -4000..4000 and at halves", bad == 0, worst);
    check("round_i clamps NaN / huge values instead of overflowing", hud::round_i(std::nan("")) == -1000000000 + 0 &&
          hud::round_i(1e300) == 1000000000 && hud::round_i(-1e300) == -1000000000);
  }
  // 1.7.82: the game's PKE ring must not be drawn on the flat 2D screen (cutscene, menu, video). The YouTuber's video shows it floating over the cutscenes.
  {
    // ring_allowed(ringAssist, hooksOk, flatScreen, pkeOut, pick, nativeRecent)
    check("ring: PKE out in the 3D world -> drawn", hud::ring_allowed(1, 1, 0, 1, 0, 0) == 1);
    check("ring: PKE out but a cutscene (flat screen) -> NOT drawn", hud::ring_allowed(1, 1, 1, 1, 0, 0) == 0);
    check("ring: flat screen beats a ghost pick and the game's own lock", hud::ring_allowed(1, 1, 1, 0, 1, 1) == 0);
    check("ring: flat screen hides it even when the probe's ring rules are off", hud::ring_allowed(0, 1, 1, 1, 0, 0) == 0 && hud::ring_allowed(1, 0, 1, 1, 0, 0) == 0);
    check("ring: probe rules off in the 3D world -> the game's own rules (drawn)", hud::ring_allowed(0, 1, 0, 0, 0, 0) == 1 && hud::ring_allowed(1, 0, 0, 0, 0, 0) == 1);
    check("ring: a ghost you look at -> drawn", hud::ring_allowed(1, 1, 0, 0, 1, 0) == 1);
    check("ring: the game's own lock just now -> drawn", hud::ring_allowed(1, 1, 0, 0, 0, 1) == 1);
    check("ring: nothing to show it on (no PKE, no ghost, no lock) -> not drawn", hud::ring_allowed(1, 1, 0, 0, 0, 0) == 0);
  }
  printf(fails ? "%d FAILED\n" : "ALL PASS\n", fails);
  return fails != 0;
}
