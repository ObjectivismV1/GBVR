// Host test for src/jpegenc.h: writes test pictures as JPEG; tests/check_jpeg.py
// decodes them with a reference decoder and compares.
// Build: g++ -std=c++17 -O1 -o test_jpeg tests/test_jpeg.cpp && ./test_jpeg OUTDIR && python3 tests/check_jpeg.py OUTDIR
#include "../src/jpegenc.h"
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>
static void wr(void* ctx, const uint8_t* d, uint32_t n) { fwrite(d, 1, n, (FILE*)ctx); }
static uint32_t rng = 12345;
static uint32_t rnd() { rng = rng * 1664525u + 1013904223u; return rng >> 8; }
static void make(int w, int h, int kind, std::vector<uint8_t>& px) {
  px.resize((size_t)w * h * 3);
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    uint8_t* p = &px[((size_t)y * w + x) * 3];
    if (kind == 0) { p[0] = (uint8_t)(x * 255 / (w > 1 ? w - 1 : 1)); p[1] = (uint8_t)(y * 255 / (h > 1 ? h - 1 : 1)); p[2] = (uint8_t)((x + y) & 255); }
    else if (kind == 1) { double v = 127 + 100 * sin(x * 0.07) * cos(y * 0.05); p[0] = (uint8_t)v; p[1] = (uint8_t)(255 - v); p[2] = (uint8_t)(128 + 60 * sin((x + y) * 0.11)); }
    else if (kind == 2) { int c = ((x / 16) ^ (y / 16)) & 1; p[0] = c ? 250 : 5; p[1] = c ? 5 : 250; p[2] = (uint8_t)(rnd() & 31); }  // hard edges + noise
    else if (kind == 3) { p[0] = p[1] = p[2] = 255; }   // flat white (long zero runs, DC only)
    else { p[0] = (uint8_t)rnd(); p[1] = (uint8_t)rnd(); p[2] = (uint8_t)rnd(); }  // noise (0xFF stuffing, long codes)
  }
}
int main(int argc, char** argv) {
  std::string dir = argc > 1 ? argv[1] : ".";
  struct { int w, h, kind, q; } cases[] = {{64, 64, 0, 90}, {640, 360, 1, 85}, {333, 217, 1, 85}, {17, 9, 0, 95}, {1, 1, 3, 80}, {256, 256, 2, 85},
                                           {200, 120, 3, 85}, {160, 96, 4, 100}, {160, 96, 4, 30}, {1920, 1080, 1, 82}, {7, 300, 2, 70}};
  int n = 0;
  for (auto& c : cases) {
    std::vector<uint8_t> px; make(c.w, c.h, c.kind, px);
    char name[256]; snprintf(name, sizeof(name), "%s/t%02d_%dx%d_k%d_q%d", dir.c_str(), n, c.w, c.h, c.kind, c.q);
    FILE* f = fopen((std::string(name) + ".jpg").c_str(), "wb");
    int ok = jpg::encode_rgb(px.data(), c.w, c.h, c.w * 3, c.q, wr, f);
    fclose(f);
    f = fopen((std::string(name) + ".rgb").c_str(), "wb"); fwrite(px.data(), 1, px.size(), f); fclose(f);
    printf("%s %s\n", ok ? "WROTE" : "FAIL", name);
    ++n;
  }
  // stride larger than the row
  { std::vector<uint8_t> px; make(100, 50, 1, px); std::vector<uint8_t> wide((size_t)400 * 50);
    for (int y = 0; y < 50; ++y) for (int i = 0; i < 300; ++i) wide[(size_t)y * 400 + i] = px[(size_t)y * 300 + i];
    FILE* f = fopen((dir + "/t99_100x50_k1_q85.jpg").c_str(), "wb"); jpg::encode_rgb(wide.data(), 100, 50, 400, 85, wr, f); fclose(f);
    f = fopen((dir + "/t99_100x50_k1_q85.rgb").c_str(), "wb"); fwrite(px.data(), 1, px.size(), f); fclose(f); }
  int bad = jpg::encode_rgb(nullptr, 10, 10, 30, 80, wr, nullptr) || jpg::encode_rgb((const uint8_t*)"x", 0, 10, 30, 80, wr, nullptr) ||
            jpg::encode_rgb((const uint8_t*)"x", 10, 10, 29, 80, wr, nullptr);
  printf("%s bad arguments rejected\n", bad ? "FAIL" : "PASS");
  return bad;
}
