#include <stdio.h>
#include <math.h>
#include "knockmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  CHECK(!knock::expired(0, 3000) && !knock::expired(2999, 3000) && knock::expired(3000, 3000));
  CHECK(knock::strength(-1, 3000) == 0.0 && knock::strength(3000, 3000) == 0.0 && knock::strength(10, 0) == 0.0);
  CHECK(fabs(knock::strength(60, 3000) - 0.5) < 1e-9);
  CHECK(knock::strength(1000, 3000) == 1.0);
  CHECK(knock::strength(1800, 3000) > 0.99 && fabs(knock::strength(2400, 3000) - 0.5) < 1e-9 && knock::strength(2999, 3000) < 0.01);
  CHECK(fabs(knock::walk_factor(1.0, 45) - 0.45) < 1e-9 && knock::walk_factor(0.0, 45) == 1.0);
  CHECK(knock::walk_factor(1.0, 0) >= 0.1 - 1e-9 && knock::walk_factor(1.0, 500) == 1.0);
  double y, p, my = 0;
  for (int i = 0; i < 300; ++i) { knock::sway(i * 0.01, 1.0, 4.0, &y, &p); if (fabs(y) > my) my = fabs(y); CHECK(fabs(y) <= 4.0 + 1e-9 && fabs(p) <= 4.0 + 1e-9); }
  CHECK(my > 1.5);
  knock::sway(1.0, 0.0, 4.0, &y, &p); CHECK(y == 0.0 && p == 0.0);
  printf(fails ? "FAILED\n" : "test_knock ok\n"); return fails;
}
