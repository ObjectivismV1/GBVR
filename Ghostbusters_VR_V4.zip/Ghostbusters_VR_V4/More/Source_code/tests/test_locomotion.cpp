// 1.7.193 stress test: walking on smooth floors, floor transitions, stairs up and down, walking into objects - the eye height follower (stairsmath.h), the gun tube's gap
// (gunshift.h, incl. the StillGate), and the carried trap (trapholdmath.h) must stay smooth and must not disturb the view model or the gun.
#include <initializer_list>
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "stairsmath.h"
#include "gunshift.h"
#include "trapholdmath.h"

static unsigned s_seed = 12345;
static double rnd() { s_seed = s_seed * 1664525u + 1013904223u; return ((s_seed >> 8) & 0xFFFF) / 65535.0 * 2.0 - 1.0; }

struct Eye { stairs::Ramp r; double t, out; void init(double y) { stairs::reset(r); t = 0; out = stairs::step(r, 0.0, y, 0.35, 0.06); }
  double go(double y, double hz) { t += 1.0 / hz; out = stairs::step(r, t, y, 0.35, 0.06); return out; } };

static void floors() {
  for (double hz : {45.0, 72.0, 90.0, 120.0}) {
    Eye e; e.init(3.0); double mx = 0, sumIn = 0, sumOut = 0; int n = 0;
    for (int i = 0; i < (int)(hz * 30); ++i) {   // 30 s on a smooth floor with 1 cm of noise and a small alternating seam bob (feet height of every step)
      const double y = 3.0 + 0.01 * rnd() + ((i / 8) % 2 ? 0.03 : -0.03);
      const double o = e.go(y, hz); if (i > 10) { mx = fmax(mx, fabs(o - 3.0)); sumIn += (y - 3.0) * (y - 3.0); sumOut += (o - 3.0) * (o - 3.0); ++n; }
    }
    printf("smooth floor %.0f Hz: worst eye error %.3f ft, rms in %.4f out %.4f\n", hz, mx, sqrt(sumIn / n), sqrt(sumOut / n));
    assert(mx < 0.06); assert(sumOut <= sumIn + 1e-12);   // the follower never adds shake
  }
}
static void transitions() {
  for (double hz : {45.0, 90.0})
    for (double h : {0.05, 0.12, 0.3, -0.12, -0.3, 0.5}) {
      Eye e; e.init(3.0); for (int i = 0; i < 40; ++i) e.go(3.0, hz);
      double prev = e.out, mxStep = 0, lo = 3.0, hi = 3.0;
      for (int i = 0; i < (int)(hz * 1.5); ++i) { const double o = e.go(3.0 + h, hz); mxStep = fmax(mxStep, fabs(o - prev)); prev = o; lo = fmin(lo, o); hi = fmax(hi, o); }
      printf("threshold %+.2f ft at %.0f Hz: biggest change per frame %.3f ft, range %.2f..%.2f, ends %.3f\n", h, hz, mxStep, lo, hi, prev);
      assert(mxStep <= fabs(h) * 0.9 + 1e-9);   // never a pop as big as the step itself (for a small curb a light ease)
      if (!(lo >= fmin(3.0, 3.0 + h) - 1e-9 && hi <= fmax(3.0, 3.0 + h) + 1e-9)) assert(lo >= fmin(3.0, 3.0 + h) - 1e-9 && hi <= fmax(3.0, 3.0 + h) + 1e-9);
      assert(fabs(prev - (3.0 + h)) < 0.02);   // settled
    }
  // a ramp (slope 10 deg at 5 ft/s)
  Eye e; e.init(3.0); double y = 3.0, prev = 3.0, mx = 0;
  for (int i = 0; i < 90 * 3; ++i) { y += 5.0 * 0.176 / 90; const double o = e.go(y, 90); if (i > 20) mx = fmax(mx, fabs(o - prev)); prev = o; assert(fabs(o - y) < 0.25); }
  printf("ramp: biggest change per frame %.4f ft (the slope itself is %.4f)\n", mx, 5.0 * 0.176 / 90); assert(mx < 5.0 * 0.176 / 90 * 1.2);
}
static void stairs_run() {
  for (int up = 0; up < 2; ++up) for (double rise : {0.5, 0.6, 0.7}) for (double per : {0.2, 0.3, 0.5}) for (double hz : {45.0, 90.0}) {
    Eye e; e.init(10.0); for (int i = 0; i < 40; ++i) e.go(10.0, hz);
    double y = 10.0, prev = e.out, mx = 0, gap = 0; int dips = 0; const int n = (int)(hz * 4.0); double nextStep = per;
    for (int i = 0; i < n; ++i) {
      if ((double)i / hz >= nextStep) { y += up ? rise : -rise; nextStep += per * (1.0 + 0.2 * rnd()); }   // uneven stair timing
      const double o = e.go(y, hz); mx = fmax(mx, fabs(o - prev)); gap = fmax(gap, fabs(o - y));
      if (up ? (o < prev - 0.002) : (o > prev + 0.002)) ++dips;   // the eye never goes against the direction of the climb
      prev = o;
    }
    assert(mx < 0.5 * rise);   // no stair-sized pop
    assert(gap <= 1.0 + 1e-9);
    assert(dips == 0);
  }
  printf("stairs up and down (rise 0.5..0.7 ft, a stair every 0.2..0.5 s, 45 and 90 Hz): no pops, no steps against the climb, eye within 1 ft of the feet\n");
}
static void bump_objects() {
  // walking into a crate / wall: the character is stopped, the feet height may blip by a few cm for a frame or two (collision push); the eye and everything hanging on it stays calm
  Eye e; e.init(3.0); for (int i = 0; i < 60; ++i) e.go(3.0, 90);
  double prev = e.out, mx = 0;
  for (int i = 0; i < 90; ++i) { const double blip = (i == 10 || i == 11) ? 0.04 : (i == 30 ? -0.03 : 0.0); const double o = e.go(3.0 + blip, 90); mx = fmax(mx, fabs(o - prev)); prev = o; }
  printf("walking into an object: eye moved at most %.4f ft per frame by a 4 cm feet blip\n", mx);
  assert(mx < 0.03);
  // stepping up onto a low object (0.4 ft) then off it
  Eye f; f.init(3.0); for (int i = 0; i < 60; ++i) f.go(3.0, 90); double p2 = f.out, m2 = 0;
  for (int i = 0; i < 270; ++i) { const double y = (i >= 40 && i < 160) ? 3.4 : 3.0; const double o = f.go(y, 90); m2 = fmax(m2, fabs(o - p2)); p2 = o; }
  assert(m2 < 0.4 * 0.9);
}
// the gun tube: the drawn muzzle's sample is a game tick old. A player walking (hand still in tracking space) must not make the learned gap swim.
static void tube_walking() {
  for (double walk : {0.0, 2.5, 5.0, 8.0})   // ft/s
    for (double age : {0.011, 0.022, 0.033}) {   // sample age s
      gunshift::Filter f; f.reset(); gunshift::StillGate g; g.reset();
      const float trueGap[3] = {0.03f, -0.02f, 0.06f};   // metres, controller frame
      double mxErr = 0, mxJump = 0; float prevLo[3] = {0, 0, 0}; int have = 0;
      const double hz = 90.0; double t = 0, worldZ = 0; long samples = 0;
      for (int i = 0; i < (int)(hz * 20); ++i) {
        t += 1.0 / hz;
        const double v = (i < hz * 4 || i > hz * 14) ? 0.0 : walk;   // stands, walks 10 s, stops (also a sudden stop = walking into a wall)
        worldZ += v / hz;
        if (i % 2 == 0) {   // a new game sample every other frame (45 Hz game)
          const double sw[3] = {0.0, 0.0, worldZ};
          const int still = g.step(sw, t, 0.25);
          // the stale sample: the muzzle is where it was `age` ago, so the measured gap carries the walked distance as an error (ft -> m)
          const float meas[3] = {trueGap[0], trueGap[1], (float)(trueGap[2] - v * age * 0.3048)};
          if (still) gunshift::feed(f, meas, 2.0 / hz);
        }
        if (f.have) { double e = sqrt(pow(f.lo[0] - trueGap[0], 2) + pow(f.lo[1] - trueGap[1], 2) + pow(f.lo[2] - trueGap[2], 2)); mxErr = fmax(mxErr, e);
          if (have) { double j = sqrt(pow(f.lo[0] - prevLo[0], 2) + pow(f.lo[1] - prevLo[1], 2) + pow(f.lo[2] - prevLo[2], 2)); mxJump = fmax(mxJump, j); }
          for (int k = 0; k < 3; ++k) prevLo[k] = f.lo[k]; have = 1; ++samples; }
      }
      // the same run without the gate shows what it fixes (the error scales with speed x age)
      gunshift::Filter u; u.reset(); double mxU = 0; t = 0; worldZ = 0;
      for (int i = 0; i < (int)(hz * 20); ++i) { t += 1.0 / hz; const double v = (i < hz * 4 || i > hz * 14) ? 0.0 : walk;
        if (i % 2 == 0) { const float meas[3] = {trueGap[0], trueGap[1], (float)(trueGap[2] - v * age * 0.3048)}; gunshift::feed(u, meas, 2.0 / hz); }
        if (u.have) mxU = fmax(mxU, sqrt(pow(u.lo[0] - trueGap[0], 2) + pow(u.lo[1] - trueGap[1], 2) + pow(u.lo[2] - trueGap[2], 2))); }
      printf("tube, walking %.1f ft/s, sample age %.0f ms: worst gap error %.1f mm gated (%.1f mm without the gate), biggest jump per frame %.2f mm\n", walk, age * 1000, mxErr * 1000, mxU * 1000, mxJump * 1000);
      assert(mxErr < 0.0015);       // the learned gap stays within 1.5 mm of the true one (the hand is still at the start)
      assert(mxJump < 0.002);       // and never jumps
      assert(mxErr <= mxU + 1e-9);
    }
}
// the carried trap follows every turn of the controller, stays a proper rotation, handle end at the fist
static void trap_hold() {
  const int uas[3] = {0, 1, 2};
  for (int ua : uas) for (double us : {1.0, -1.0}) for (double sf : {1.0, -1.0}) {
    double N[3] = {1, 0, 0}; double cprev[3][3]; int have = 0; double maxStepRad = 0;
    for (int k = 0; k < 20000; ++k) {   // sweep the controller through every orientation, including straight up and straight down (the poles)
      const double yaw = 0.0019 * k, pitch = 1.5707963 * sin(0.0011 * k) * 1.0, roll = 3.0 * sin(0.0007 * k);
      const double cy = cos(yaw), sy = sin(yaw), cp = cos(pitch), sp = sin(pitch), cr = cos(roll), sr = sin(roll);
      float fwd[3] = {(float)(cy * cp), (float)sp, (float)(sy * cp)};
      float up0[3] = {(float)(-cy * sp), (float)cp, (float)(-sy * sp)}, side[3] = {(float)(-sy), 0.0f, (float)cy};
      float up[3] = {(float)(cr * up0[0] + sr * side[0]), (float)(cr * up0[1] + sr * side[1]), (float)(cr * up0[2] + sr * side[2])};
      double c[3][3], d[3]; traphold::build(fwd, up, ua, us, sf, N, c, d);
      for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { assert(c[i][j] == c[i][j]); }
      for (int i = 0; i < 3; ++i) { double l = sqrt(c[i][0] * c[i][0] + c[i][1] * c[i][1] + c[i][2] * c[i][2]); assert(fabs(l - 1.0) < 1e-6); }
      for (int i = 0; i < 3; ++i) for (int j = i + 1; j < 3; ++j) assert(fabs(c[i][0] * c[j][0] + c[i][1] * c[j][1] + c[i][2] * c[j][2]) < 1e-6);
      // body direction is minus the controller's up
      const double ul = sqrt((double)up[0] * up[0] + (double)up[1] * up[1] + (double)up[2] * up[2]);
      assert(fabs(d[0] + up[0] / ul) < 1e-6 && fabs(d[1] + up[1] / ul) < 1e-6 && fabs(d[2] + up[2] / ul) < 1e-6);
      if (have) { double m = 0; for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) m = fmax(m, fabs(c[i][j] - cprev[i][j])); maxStepRad = fmax(maxStepRad, m); }
      for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) cprev[i][j] = c[i][j]; have = 1;
    }
    assert(maxStepRad < 0.05);   // no flips: a controller turn of a fraction of a degree never turns the trap by more
  }
  // a pure roll of the wrist turns the trap about its long axis by the same angle (fully rotatable)
  float fwd[3] = {0, 0, -1}, up[3] = {0, 1, 0}; double N[3] = {0, 0, -1}, c0[3][3], c1[3][3], d[3];
  traphold::build(fwd, up, 1, 1.0, 1.0, N, c0, d);
  const double a = 0.6; float up2[3] = {(float)sin(a), (float)cos(a), 0}, f2[3] = {0, 0, -1};
  traphold::build(f2, up2, 1, 1.0, 1.0, N, c1, d);
  const double dot = c0[1][0] * c1[1][0] + c0[1][1] * c1[1][1] + c0[1][2] * c1[1][2];
  assert(fabs(dot - cos(a)) < 1e-6);
  printf("trap hold: orthonormal for every controller turn incl. the poles, no flips (largest step %s), a wrist roll of %.0f deg turns the trap's body by %.0f deg\n", "< 0.05", a * 57.29578, acos(dot) * 57.29578);
}
int main() { floors(); transitions(); stairs_run(); bump_objects(); tube_walking(); trap_hold(); printf("locomotion stress tests passed\n"); return 0; }
