#include <stdio.h>
#include "weightmath.h"
// 1.7.177: one-handed looseness without firing: the gun lags more one-handed than two-handed, and firing=0 gives no kick/climb
int main() {
  int fails = 0;
  for (int hands = 0; hands < 2; ++hands) { (void)hands; }
  double lagOne = 0, lagTwo = 0;
  for (int two = 0; two < 2; ++two) {
    weight::State st = {}; weight::Params p = weight::locked_params(150.0, 150.0, 0, 0, 1, nullptr); p.looseOne = 1.0;
    double tgt[9] = {1,0,0, 0,1,0, 0,0,1}, out[9]; weight::Out wi = {};
    double worst = 0;
    for (int n = 0; n < 900; ++n) {
      const double a = (n < 450) ? 0.0 : 0.6;   // a 35 degree turn at 5 s
      double s, c; vm::dsincos(a, &s, &c);
      tgt[0] = c; tgt[2] = s; tgt[6] = -s; tgt[8] = c;
      weight::step(&st, p, tgt, 1.0 / 90, two, 0, 1, out, &wi);
      if (wi.lagDeg > worst) worst = wi.lagDeg;
      if (wi.recoilDeg > 0.0001 || wi.strain > 0.0001) { printf("FAIL firing-free: recoil %.3f strain %.3f\n", wi.recoilDeg, wi.strain); ++fails; }
    }
    (two ? lagTwo : lagOne) = worst;
  }
  printf("lag one hand %.2f deg, two hands %.2f deg\n", lagOne, lagTwo);
  if (!(lagOne > lagTwo)) { printf("FAIL one hand not looser\n"); ++fails; }
  printf("%s\n", fails ? "FAILED" : "ok");
  return fails ? 1 : 0;
}
