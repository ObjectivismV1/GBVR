#include "../src/vmath.h"
#include <cstdio>
#include <cmath>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
int main(int argc,char**argv){
  // trig check
  double ws=0; for(double x=-20;x<20;x+=0.0137){double s,c;vm::dsincos(x,&s,&c);ws=std::max(ws,std::max(std::fabs(s-std::sin(x)),std::fabs(c-std::cos(x))));}
  double wa=0; for(double y=-3;y<3;y+=0.071)for(double x=-3;x<3;x+=0.093){wa=std::max(wa,std::fabs(vm::datan2(y,x)-std::atan2(y,x)));}
  printf("sincos maxerr %.3g  atan2 maxerr %.3g\n",ws,wa);
  std::ifstream f(argv[1]); std::string line; double deg=0; std::vector<float> orig; int n=0; double worstOwn=0, worstLog=0;
  while(std::getline(f,line)){
    if(line.rfind("ENGINEYAW frame=",0)==0){ auto p=line.find("degrees="); deg=atof(line.c_str()+p+8);}
    auto parse=[&](const std::string&l){std::vector<float> v; auto p=l.find("floats=9,"); std::stringstream ss(l.substr(p+9)); std::string t; while(std::getline(ss,t,',')) v.push_back(strtof(t.c_str(),0)); return v;};
    if(line.rfind("YAWORIGINAL",0)==0) orig=parse(line);
    if(line.rfind("YAWAPPLIED",0)==0){ auto app=parse(line); float R[9],out[9]; vm::local_yaw(deg,R); vm::mul(orig.data(),R,out);
      double e=0; for(int i=0;i<9;i++) e=std::max(e,(double)std::fabs(out[i]-app[i]));
      double me=vm::yaw_math_error(orig.data(),app.data(),deg);
      printf("sample %d deg=%+.0f  ours-vs-0.16=%.3g  mathcheck(0.16 data)=%.3g  orig rot=%d det=%.6f\n",++n,deg,e,me,vm::is_rotation(orig.data()),vm::det(orig.data()));
      worstOwn=std::max(worstOwn,e); worstLog=std::max(worstLog,me);} }
  printf("samples=%d worst ours-vs-0.16 %.3g, worst 0.16 math %.3g (handoff: 5.98e-8)\n",n,worstOwn,worstLog);
}
