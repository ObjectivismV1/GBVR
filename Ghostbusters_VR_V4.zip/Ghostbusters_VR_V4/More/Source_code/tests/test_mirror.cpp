// 0.84 fingers and the PKE: same fake engine as test_armcore, with finger chains and the cloth_pke bones.
// (the first lines below are the original description) A fake skinned player model with the engine's memory layout (layout.h "0.57 skeleton") and the three engine functions
// the arm override calls, to run armcore.h end to end: bone indices by name, chains, the write loop, fingers below the
// hand, idempotence, stale cache, bad data.
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "armcore.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double fabs_(double x) { return x < 0 ? -x : x; }


enum { N = 35 };
static const char* kNames[N] = {"bone_pelvis", "bone_spine1", "bone_spine2", "bone_spine3", "bone_R_clavicle", "bone_R_upperArm", "bone_R_forearm", "bone_R_hand",
                                "bone_L_clavicle", "bone_L_upperArm", "bone_L_forearm", "bone_L_hand", "bone_head",
                                "bone_R_index1", "bone_R_index2", "bone_R_index3", "bone_R_index4", "bone_R_pinkie1", "bone_R_pinkie2", "bone_R_pinkie3", "bone_R_pinkie4",
                                "bone_R_thumb1", "bone_R_thumb2", "bone_R_thumb3", "bone_R_thumb4",
                                "bone_L_index1", "bone_L_index2", "bone_L_index3", "bone_L_index4", "bone_L_pinkie1", "bone_L_pinkie2", "bone_L_pinkie3", "bone_L_pinkie4",
                                "cloth_pke", "cloth_pke1"};
static const int kParent[N] = {-1, 0, 1, 2, 3, 4, 5, 6, 3, 8, 9, 10, 3, 7, 13, 14, 15, 7, 17, 18, 19, 7, 21, 22, 23, 11, 25, 26, 27, 11, 29, 30, 31, 0, 33};

struct Fake { uint8_t* actor; uint8_t* skel; uint8_t* local; float* world; int logs; };
static Fake F;
static void qset(uint8_t* l, const double* axis, double deg, double scale, const double* pos) {
  double h = deg * vm::kPi / 360.0, s, c;
  vm::dsincos(h, &s, &c);
  float* f = (float*)l;
  f[0] = (float)(axis[0] * s); f[1] = (float)(axis[1] * s); f[2] = (float)(axis[2] * s); f[3] = (float)c;
  f[4] = f[5] = f[6] = (float)scale;
  f[7] = (float)pos[0]; f[8] = (float)pos[1]; f[9] = (float)pos[2];
}
struct G {
  static void local(const void* l, float* out) {
    const float* f = (const float*)l;
    double x = f[0], y = f[1], z = f[2], w = f[3];
    double R[9] = {1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w),
                   2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w),
                   2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)};
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = (float)(R[c * 3 + r] * f[4 + r]);   // rows = images of the axes (row vectors)
    out[12] = f[7]; out[13] = f[8]; out[14] = f[9];
  }
  static void mul(float* out, const float* a, const float* b) {
    float t[16] = {0};
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) t[r * 4 + c] = a[r * 4] * b[c] + a[r * 4 + 1] * b[4 + c] + a[r * 4 + 2] * b[8 + c];
    for (int c = 0; c < 3; ++c) t[12 + c] = a[12] * b[c] + a[13] * b[4 + c] + a[14] * b[8 + c] + b[12 + c];
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 3; ++c) out[r * 4 + c] = t[r * 4 + c];
  }
  static void ensure(void* m) {
    int* state = (int*)((uint8_t*)m + layout::kOffModelState - layout::kOffActorModel + layout::kOffActorModel);   // M + 0x2b08
    if (*state > 0) return;
    for (int i = 0; i < N; ++i) {
      float tmp[16] = {0};
      local(F.local + 40 * i, tmp);
      if (kParent[i] < 0) { for (int k = 0; k < 16; ++k) F.world[i * 16 + k] = tmp[k]; }
      else mul(F.world + i * 16, tmp, F.world + kParent[i] * 16);
    }
    *state = 1;
  }
  static int readable(const void*, size_t, int) { return 1; }
  static int64_t clock() { static int64_t c; return ++c; }
  static void log(const char* fmt, ...) {
    ++F.logs;
    if (getenv("ARMLOG")) { va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap); printf("\n"); }
  }
};
typedef armcore::Core<G> Core;

static void* aligned16(size_t n) { return aligned_alloc(16, (n + 15u) & ~(size_t)15u); }

static void build() {
  F.actor = (uint8_t*)aligned16(0x10000);
  memset(F.actor, 0, 0x10000);
  uint8_t* M = F.actor + layout::kOffActorModel;
  F.skel = (uint8_t*)aligned16(0x8c + N * 0x4c + 64);
  memset(F.skel, 0, 0x8c + N * 0x4c + 64);
  F.local = (uint8_t*)aligned16(N * 40);
  memset(F.local, 0, N * 40);
  F.world = (float*)aligned16(N * 64);
  memset(F.world, 0, N * 64);
  *(int*)(F.skel + 0x88) = N;
  for (int i = 0; i < N; ++i) {
    strncpy((char*)F.skel + 0x8c + i * 0x4c, kNames[i], 0x17);
    *(int*)(F.skel + 0x8c + i * 0x4c + 0x1c) = kParent[i];
  }
  *(uint8_t**)(M + layout::kOffModelSkeleton) = F.skel;
  *(uint8_t**)(M + layout::kOffModelLocal) = F.local;
  *(float**)(M + layout::kOffModelWorld) = F.world;
  *(int*)(M + layout::kOffModelBoneCount) = N;
  *(int*)(M + layout::kOffModelState) = -1;
  int* idx = (int*)(F.actor + layout::kOffActorBoneIdx);
  idx[0] = 12; idx[1] = 3; idx[2] = 5; idx[3] = 9; idx[4] = 7; idx[5] = 11;
  const double X[3] = {1, 0, 0};
  const double p0[3] = {0, 3.0, 0}, p1[3] = {0, 0.4, 0}, cR[3] = {0.15, 0.2, 0}, uR[3] = {0.35, 0, 0}, fa[3] = {0, -1.0, 0}, ha[3] = {0, -0.9, 0};
  const double cL[3] = {-0.15, 0.2, 0}, uL[3] = {-0.35, 0, 0}, hd[3] = {0, 0.5, 0};
  qset(F.local + 0 * 40, X, 0, 1, p0);
  qset(F.local + 1 * 40, X, 0, 1, p1); qset(F.local + 2 * 40, X, 0, 1, p1); qset(F.local + 3 * 40, X, 0, 1, p1);
  qset(F.local + 4 * 40, X, 0, 1, cR); qset(F.local + 5 * 40, X, 10, 1, uR); qset(F.local + 6 * 40, X, -70, 1, fa); qset(F.local + 7 * 40, X, 15, 1, ha);
  qset(F.local + 8 * 40, X, 0, 1, cL); qset(F.local + 9 * 40, X, 10, 1, uL); qset(F.local + 10 * 40, X, -70, 1, fa); qset(F.local + 11 * 40, X, 15, 1, ha);
  qset(F.local + 12 * 40, X, 0, 1, hd);
  // fingers: knuckles at x = +-0.03 (index) / -+0.03 (pinkie), segments 0.08 long; the index is bent 25 degrees at its joints in the animation, the pinkie is straight
  const double seg[3] = {0, -0.08, 0};
  const double iR[3] = {-0.03, -0.1, 0}, pR[3] = {0.03, -0.1, 0}, tR[3] = {0.07, -0.05, 0.02};
  const double iL[3] = {0.03, -0.1, 0}, pL[3] = {-0.03, -0.1, 0};
  qset(F.local + 13 * 40, X, 0, 1, iR);  qset(F.local + 14 * 40, X, 25, 1, seg); qset(F.local + 15 * 40, X, 25, 1, seg); qset(F.local + 16 * 40, X, 0, 1, seg);
  qset(F.local + 17 * 40, X, 0, 1, pR);  qset(F.local + 18 * 40, X, 0, 1, seg);  qset(F.local + 19 * 40, X, 0, 1, seg);  qset(F.local + 20 * 40, X, 0, 1, seg);
  qset(F.local + 21 * 40, X, 0, 1, tR);  qset(F.local + 22 * 40, X, 20, 1, seg); qset(F.local + 23 * 40, X, 20, 1, seg); qset(F.local + 24 * 40, X, 0, 1, seg);
  qset(F.local + 25 * 40, X, 0, 1, iL);  qset(F.local + 26 * 40, X, 25, 1, seg); qset(F.local + 27 * 40, X, 25, 1, seg); qset(F.local + 28 * 40, X, 0, 1, seg);
  qset(F.local + 29 * 40, X, 0, 1, pL);  qset(F.local + 30 * 40, X, 0, 1, seg);  qset(F.local + 31 * 40, X, 0, 1, seg);  qset(F.local + 32 * 40, X, 0, 1, seg);
  const double pke0[3] = {0.35, 0.9, 0.3}, pke1[3] = {0, 0.1, 0.05};   // near the right hand once the arm swings forward
  qset(F.local + 33 * 40, X, 12, 1, pke0); qset(F.local + 34 * 40, X, 5, 1, pke1);
}

static void wp(const arm::Space& sp, int bone, double* w) { sp.point_world(F.world + bone * 16 + 12, w); }
static double dist(const double* a, const double* b) { double d[3] = {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; return arm::len(d); }
// the signed bend of joint j (0..2) of a finger chain along `ax`, degrees
static double bend(const arm::Space& sp, int hand, const int* b, int j, const double* ax) {
  double P[5][3], g[4][3];
  wp(sp, hand, P[0]);
  for (int k = 0; k < 4; ++k) wp(sp, b[k], P[k + 1]);
  for (int i = 0; i < 4; ++i) arm::sub(P[i + 1], P[i], g[i]);
  double x[3];
  arm::cross(g[j], g[j + 1], x);
  return vm::datan2(arm::dot(x, ax), arm::dot(g[j], g[j + 1])) * 180.0 / vm::kPi;
}

static void reset_pose() { *(int*)(F.actor + layout::kOffActorModel + layout::kOffModelState) = -1; G::ensure(F.actor + layout::kOffActorModel); }
static void refl(const double* v, const double* n, double* o) { const double k = 2.0 * arm::dot(v, n); for (int i = 0; i < 3; ++i) o[i] = v[i] - k * n[i]; }
static void lm(const arm::Space& sp, int h, int i, int p, double* fwd, double* across) {   // landmark directions of a hand
  double a[3], b[3], c[3];
  wp(sp, h, a); wp(sp, i, b); wp(sp, p, c);
  for (int k = 0; k < 3; ++k) fwd[k] = 0.5 * (b[k] + c[k]) - a[k];
  arm::sub(b, c, across);
  arm::unit(fwd, fwd); arm::unit(across, across);
}
static double angdeg(const double* a, const double* b) { double c = arm::dot(a, b); c = c > 1 ? 1 : (c < -1 ? -1 : c); return acos(c) * 180.0 / vm::kPi; }

int main() {
  build();
  uintptr_t actor = (uintptr_t)F.actor;
  float W2[16] = {0};
  {
    double ay[3] = {0, 1, 0}, R[9];
    weight::axis_angle(ay, 30.0 * vm::kPi / 180.0, R);
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) W2[r * 4 + c] = (float)(1.05 * R[c * 3 + r]);
    W2[12] = 5; W2[13] = 0; W2[14] = 2; W2[15] = 1;
  }
  arm::Space sp;
  CHECK(sp.set(W2));
  G::ensure(F.actor + layout::kOffActorModel);
  double H0[3], LH0[3];
  wp(sp, 7, H0); wp(sp, 11, LH0);
  ArmTargets t;
  memset(&t, 0, sizeof(t));
  // the wand turned 50 deg about a skew axis, and the controller frame (rdir/rup) tilted: the mirror plane is not axis aligned
  { double ax[3] = {0.3, 0.8, 0.5}; arm::unit(ax, ax); weight::axis_angle(ax, 50.0 * vm::kPi / 180.0, t.wandR); }
  for (int i = 0; i < 3; ++i) t.wandP0[i] = H0[i];
  t.grip[0] = H0[0] + 0.3; t.grip[1] = H0[1] + 0.2; t.grip[2] = H0[2] + 0.4;
  t.rightOn = 1; t.leftOn = 1; t.rdirOk = 1;
  { double d[3] = {0.25, 0.1, 0.96}, u[3] = {-0.1, 1.0, 0.1}; arm::unit(d, d); const double k = arm::dot(u, d); for (int i = 0; i < 3; ++i) u[i] -= k * d[i]; arm::unit(u, u); for (int i = 0; i < 3; ++i) { t.rdir[i] = d[i]; t.rup[i] = u[i]; } }
  t.lpos[0] = LH0[0] - 0.2; t.lpos[1] = LH0[1] + 0.3; t.lpos[2] = LH0[2] + 0.5;
  double fw[3] = {0.2, 0.1, 0.97}; arm::unit(fw, t.lfwd);
  t.lup[0] = 0; t.lup[1] = 1; t.lup[2] = 0;
  t.wristBackFt = 0.2; t.wristDownFt = 0.05; t.elbowDown = 1.0;
  double nrm[3]; arm::cross(t.rdir, t.rup, nrm); arm::unit(nrm, nrm);
  // reference: the right-handed pass (the right hand's gun-hold frame)
  double fR[3], aR[3];
  reset_pose();
  CHECK(Core::apply(actor, W2, &t) == 1);
  lm(sp, 7, 13, 17, fR, aR);
  // A: left-handed, free hand: the drawn LEFT hand (gun) must be the mirror image of the right hand's frame
  ArmTargets tm = t; tm.mirrorArms = 1;
  reset_pose();
  CHECK(Core::apply(actor, W2, &tm) == 1);
  double fL[3], aL[3], fRm[3], aRm[3];
  lm(sp, 11, 25, 29, fL, aL);
  refl(fR, nrm, fRm); refl(aR, nrm, aRm);
  const double eF = angdeg(fL, fRm), eA = angdeg(aL, aRm);
  printf("A: drawn left hand vs the mirror image of the right hand's gun hold: pointing %.2f deg, knuckle line %.2f deg (reach %d%%)\n", eF, eA, Core::st.dispReachX100[1]);
  CHECK((eF < 1.5 && eA < 1.5) || Core::st.dispReachX100[1] >= 99);
  // repeated pass on the same pose: unchanged (the second eye)
  { float b[N * 16]; memcpy(b, F.world, sizeof(b)); CHECK(Core::apply(actor, W2, &tm) == 1); CHECK(memcmp(b, F.world, sizeof(b)) == 0); }
  // B: support hand wrapping the barrel, the real hand on the player's RIGHT (= -rt): the drawn right hand is on that side, not across the gun
  {
    ArmTargets tw = tm;
    tw.fingersOn = 1; for (int h = 0; h < 2; ++h) for (int f = 0; f < 5; ++f) tw.curl[h][f] = 0.5;
    tw.gunLenFt = 1.0; tw.gunPosOk = 1; for (int i = 0; i < 3; ++i) tw.gunPos[i] = tw.grip[i];
    tw.underW = 1.0; tw.underFt = 0.15; tw.grabW = 1.0; tw.grabWrap = 1.0; tw.grabWrapDeg = 30.0; tw.grabOrbitDeg = 110.0; tw.grabOrbitFollow = 0.1;
    for (int i = 0; i < 3; ++i) tw.lpos[i] = tw.gunPos[i] + tw.rdir[i] * 0.5 - nrm[i] * 0.35 - tw.rup[i] * 0.1;
    reset_pose();
    CHECK(Core::apply(actor, W2, &tw) == 1);
    double Hr[3]; wp(sp, 7, Hr);
    double rel[3]; arm::sub(Hr, tw.gunPos, rel);
    const double side = arm::dot(rel, nrm);
    double rl[3]; arm::sub(tw.lpos, tw.gunPos, rl);
    printf("B: wrapped barrel: real hand lateral %.2f ft, drawn right hand lateral %.2f ft (same side = OK); reach %d%% / %d%%; wrist to real hand %.2f ft\n", arm::dot(rl, nrm), side, Core::st.dispReachX100[0], Core::st.dispReachX100[1], dist(Hr, tw.lpos));
    CHECK(side * arm::dot(rl, nrm) > 0.0 || Core::st.dispReachX100[0] >= 99);
    CHECK(Core::st.fingerNoAxis[0] == 0);
  }
  // C: the PKE bones stay where the right-handed pass puts them (on the gun-hold hand at the gun controller), not on the right arm drawn at the free controller
  {
    ArmTargets tp = t; tp.pkeAttach = 1;
    reset_pose();
    CHECK(Core::apply(actor, W2, &tp) == 1);
    double Pk0[3]; wp(sp, 33, Pk0);
    tp.mirrorArms = 1;
    reset_pose();
    CHECK(Core::apply(actor, W2, &tp) == 1);
    double Pk[3], Hr[3]; wp(sp, 33, Pk); wp(sp, 7, Hr);
    printf("C: PKE bone moved %.4f ft against the right-handed pass (drawn right hand is %.2f ft from the gun hold)\n", dist(Pk, Pk0), 0.0);
    CHECK(Core::st.pkeApplied[0] >= 1);
    CHECK(dist(Pk, Pk0) < 2e-3);
  }
  // D: the left hand drawn on the gun closes its fingers like the right hand does on the game's grip (same joint bends)
  {
    ArmTargets td = t; td.fingersOn = 1; td.origOn = 1; for (int i = 0; i < 16; ++i) td.origBody[i] = W2[i];
    td.gunWrap = 0.0; for (int f = 1; f < 5; ++f) { td.curl[0][f] = 0.7; td.curl[1][f] = 0.2; } td.curl[0][0] = td.curl[1][0] = -1;
    const int RI[4] = {13, 14, 15, 16}, RP[4] = {17, 18, 19, 20}, LI[4] = {25, 26, 27, 28}, LP[4] = {29, 30, 31, 32};
    auto axis = [&](int a, int b, int h, double* ax) { double pi3[3], pp3[3], across[3], fd[3], g1[3], pa[3], pb[3]; wp(sp, a, pi3); wp(sp, b, pp3); arm::sub(pi3, pp3, across); arm::unit(across, across); wp(sp, a, pa); wp(sp, a + 1, pb); arm::sub(pb, pa, g1); arm::unit(g1, fd); const double k = arm::dot(across, fd); for (int i = 0; i < 3; ++i) ax[i] = (h ? 1.0 : -1.0) * (across[i] - k * fd[i]); arm::unit(ax, ax); };
    reset_pose();
    CHECK(Core::apply(actor, W2, &td) == 1);
    double ax[3]; axis(13, 17, 0, ax);
    const double r1 = bend(sp, 7, RI, 1, ax), r2 = bend(sp, 7, RI, 2, ax), p1 = bend(sp, 7, RP, 1, ax);
    td.mirrorArms = 1;
    reset_pose();
    CHECK(Core::apply(actor, W2, &td) == 1);
    axis(25, 29, 1, ax);
    const double l1 = bend(sp, 11, LI, 1, ax), l2 = bend(sp, 11, LI, 2, ax), q1 = bend(sp, 11, LP, 1, ax);
    printf("D: right gun-hand index %.1f/%.1f pinkie %.1f, drawn left hand index %.1f/%.1f pinkie %.1f\n", r1, r2, p1, l1, l2, q1);
    CHECK(fabs_(r1 - l1) < 1.5 && fabs_(r2 - l2) < 1.5 && fabs_(p1 - q1) < 1.5);
  }
  if (fails) { printf("FAIL %d\n", fails); return 1; }
  printf("PASS mirror\n");
  return 0;
}
