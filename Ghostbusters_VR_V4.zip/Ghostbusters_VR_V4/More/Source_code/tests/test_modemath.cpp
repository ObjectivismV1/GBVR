// 0.69 the eye-height histogram (modemath.h)
#include <stdio.h>
#include "modemath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double fabs_(double x) { return x < 0 ? -x : x; }
int main() {
  modem::Hist h; h.init(3.5, 8.0);
  CHECK(h.mode() == 0.0);
  for (int i = 0; i < 30; ++i) h.add(5.0);
  CHECK(h.mode() == 0.0);          // not enough yet
  for (int i = 0; i < 30; ++i) h.add(5.0);
  printf("mode after 60 equal samples: %.3f\n", h.mode());
  CHECK(fabs_(h.mode() - 5.0) < 0.03);
  // a mean would be pulled to ~5.3: 60 standing samples (5.0 +- 0.01) and 40 odd ones (4.7 and 5.8 alternately)
  h.init(3.5, 8.0);
  unsigned r = 12345;
  for (int i = 0; i < 160; ++i) {
    r = r * 1103515245u + 12345u;
    double jitter = ((double)((r >> 16) & 0x7fff) / 32768.0 - 0.5) * 0.02;
    h.add(5.0 + jitter);
    if (i % 3 == 0) h.add((i / 3) % 2 ? 4.7 : 5.8);
  }
  float share = 0;
  double m = h.mode(&share);
  printf("mode with odd poses: %.3f (peak share %.0f%%)\n", m, share * 100.0);
  CHECK(fabs_(m - 5.0) < 0.03 && share > 0.5f);
  // the standing height changes (another suit): the old peak fades, the new one wins within ~10000 samples
  for (int i = 0; i < 9000; ++i) h.add(5.4);
  m = h.mode();
  printf("mode after the model changed: %.3f\n", m);
  CHECK(fabs_(m - 5.4) < 0.03);
  // out of range values are ignored
  int n = h.n;
  h.add(1.0); h.add(20.0); h.add(-3.0);
  CHECK(h.n == n);
  // a peak that straddles two bins is not split
  h.init(3.5, 8.0);
  for (int i = 0; i < 100; ++i) h.add(i % 2 ? 5.0124 : 5.0126);
  CHECK(fabs_(h.mode() - 5.0125) < 0.02);
  if (!fails) printf("PASS modemath\n");
  return fails ? 1 : 0;
}
