// 0.96 mod scan helpers: names, paths, dates, CRC.
#include <stdio.h>
#include <string.h>
#include "modscanmath.h"
using namespace modscan;

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

int main() {
  // CRC-32 of "123456789" is the standard check value 0xCBF43926; chunked updates give the same result
  {
    const char* s = "123456789";
    CHECK(crc32_update(0, (const uint8_t*)s, 9) == 0xCBF43926u);
    uint32_t c = crc32_update(0, (const uint8_t*)s, 4);
    c = crc32_update(c, (const uint8_t*)s + 4, 5);
    CHECK(c == 0xCBF43926u);
    CHECK(crc32_update(0, (const uint8_t*)"", 0) == 0u);
  }
  // text helpers
  CHECK(ieq("DXGI.dll", "dxgi.DLL"));
  CHECK(!ieq("dxgi.dll", "dxgi.dl"));
  CHECK(icontains("Ghostbusters Deluxe v0.83", "DELUXE"));
  CHECK(!icontains("abc", ""));
  CHECK(iends("Foo.ASI", ".asi"));
  CHECK(!iends(".asi", "xx.asi"));
  CHECK(strcmp(base_of("C:\\a\\b\\c.dll"), "c.dll") == 0);
  CHECK(strcmp(base_of("c.dll"), "c.dll") == 0);
  CHECK(strcmp(ext_of("a.b.TXT"), ".TXT") == 0);
  CHECK(strcmp(ext_of("noext"), "") == 0);
  CHECK(strcmp(ext_of("dir.v1\\noext"), "") == 0);
  CHECK(has_word("game_mod.ini", "mod"));
  CHECK(!has_word("models", "mod"));
  CHECK(!has_word("remodel.txt", "mod"));
  CHECK(has_word("Deluxe-patch.zip", "patch"));
  CHECK(has_word("mod", "mod"));

  // classification
  CHECK(classify("winmm.dll") & F_LOADER);
  CHECK(classify("C:\\g\\WINMM.DLL") & F_LOADER);
  CHECK(classify("GhostbustersNoIntro.asi") & F_ASI);
  CHECK(classify("dxgi.dll") & F_GFX);
  CHECK(classify("xinput1_3.dll") & F_INPUT);
  CHECK(classify("ReShade.ini") & F_MODNAME);
  CHECK(classify("ReShade.ini") & F_TEXT);
  CHECK(classify("dxvk.conf") & F_MODNAME);
  CHECK(classify("Ghostbusters Deluxe") & F_MODNAME);
  CHECK(classify("d3d11.dll") & F_OURS);
  CHECK(classify("gbvr_probe_0.96_x.log") & F_OURS);
  CHECK(classify("d3d11.dll.gbvr_backup_2026") & F_OURS);
  CHECK(classify("ghost.exe") & F_EXE);
  CHECK(!(classify("ghost.exe") & F_MODNAME));
  CHECK(classify("steam_api64.dll") == F_DLL);
  CHECK(classify("models") == 0);
  CHECK(!(classify("textures") & F_MODNAME));

  // levels: a graphics or input DLL next to ghost.exe is a likely conflict, deeper down it is not
  CHECK(level_of(classify("dxgi.dll"), 1) == 3);
  CHECK(level_of(classify("dxgi.dll"), 0) == 0);
  CHECK(level_of(classify("xinput1_3.dll"), 1) == 3);
  CHECK(level_of(classify("winmm.dll"), 1) == 2);
  CHECK(level_of(classify("GhostbustersNoIntro.asi"), 0) == 2);
  CHECK(level_of(classify("deluxe_readme.txt"), 0) == 1);
  CHECK(level_of(classify("d3d11.dll"), 1) == 0);
  CHECK(level_of(classify("steam_api64.dll"), 1) == 0);
  CHECK(what_is(classify("dxgi.dll"))[0] != 0);
  CHECK(strcmp(what_is(classify("d3d11.dll")), "probe") == 0);
  CHECK(what_is(classify("zzz")) [0] == 0);

  // paths
  const char* game = "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Ghostbusters The Video Game Remastered";
  const char* win = "C:\\WINDOWS";
  CHECK(under("C:\\Windows\\System32\\d3d11.dll", win));
  CHECK(under("c:/windows/system32/x.dll", win));
  CHECK(!under("C:\\WindowsApps\\x.dll", win));
  CHECK(!under("C:\\Windows", win));    // the folder itself is not "under" itself
  CHECK(under("C:\\a\\b.dll", "C:\\a\\"));
  CHECK(path_kind("C:\\Windows\\System32\\kernel32.dll", game, win) == P_SYSTEM);
  CHECK(path_kind("C:\\Windows\\System32\\DriverStore\\FileRepository\\nv_dispi.inf\\nvwgf2umx.dll", game, win) == P_DRIVER);
  CHECK(path_kind("C:\\Program Files (x86)\\Steam\\steamapps\\common\\Ghostbusters The Video Game Remastered\\winmm.dll", game, win) == P_GAME);
  CHECK(path_kind("C:\\Program Files (x86)\\Steam\\gameoverlayrenderer64.dll", game, win) == P_STEAM);
  CHECK(path_kind("C:\\Program Files (x86)\\Steam\\steamapps\\common\\SteamVR\\bin\\win64\\vrclient_x64.dll", game, win) == P_STEAM);
  CHECK(path_kind("C:\\Program Files\\NVIDIA Corporation\\x.dll", game, win) == P_DRIVER);
  CHECK(path_kind("C:\\Program Files (x86)\\RivaTuner Statistics Server\\Hooks\\RTSSHooks64.dll", game, win) == P_OTHER);
  CHECK(path_kind("C:\\Users\\a\\AppData\\Local\\Discord\\app-1\\discord_hook.dll", game, win) == P_OTHER);

  CHECK(overlay_hint("RTSSHooks64.dll"));
  CHECK(overlay_hint("gameoverlayrenderer64.dll"));
  CHECK(overlay_hint("graphics-hook64.dll"));
  CHECK(!overlay_hint("kernel32.dll"));
  CHECK(!overlay_hint("steam_api64.dll"));

  // days: 1970-01-01 is FILETIME 116444736000000000 (day 134774); 2024-05-27 and 2026-10-14 round-trip
  {
    CHECK(day_of(116444736000000000ull) == 134774);
    int y, m, d;
    ymd_from_day(134774, &y, &m, &d); CHECK(y == 1970 && m == 1 && d == 1);
    ymd_from_day(134774 + 19000, &y, &m, &d); CHECK(y == 2022 && m == 1 && d == 8);
    // 2024-05-27: days since 1970 = 19870
    ymd_from_day(134774 + 19870, &y, &m, &d); CHECK(y == 2024 && m == 5 && d == 27);
    // 2026-10-14: 20740
    ymd_from_day(134774 + 20740, &y, &m, &d); CHECK(y == 2026 && m == 10 && d == 14);
    // leap day
    ymd_from_day(134774 + 19782, &y, &m, &d); CHECK(y == 2024 && m == 2 && d == 29);
  }
  // day table: counts, ranking, overflow
  {
    DayTable t; t.clear();
    for (int i = 0; i < 10; ++i) t.add(100, 5);
    for (int i = 0; i < 3; ++i) t.add(200, 1000);
    t.add(300, 7);
    CHECK(t.n == 3);
    CHECK(t.files[t.rank(0)] == 10 && t.day[t.rank(0)] == 100 && t.bytes[t.rank(0)] == 50);
    CHECK(t.day[t.rank(1)] == 200 && t.bytes[t.rank(1)] == 3000);
    CHECK(t.day[t.rank(2)] == 300);
    CHECK(t.rank(3) == -1);
    DayTable u; u.clear();
    for (int i = 0; i < DayTable::kMax + 5; ++i) u.add(i, 1);
    CHECK(u.n == DayTable::kMax && u.overflow == 5);
    DayTable e; e.clear(); CHECK(e.rank(0) == -1);
  }

  // 0.97 file opens that matter for "did the mod load": anything under MODS, or a tweak.txt
  {
    CHECK(mod_path_hit("C:\\Games\\Ghostbusters\\MODS\\deluxe\\data\\tweak.txt") == 1);
    CHECK(mod_path_hit("C:\\Games\\Ghostbusters\\mods\\deluxe\\a.pod") == 1);
    CHECK(mod_path_hit("C:/Games/Ghostbusters/Mods/x.dds") == 1);
    CHECK(mod_path_hit("\\\\?\\C:\\g\\MODS") == 1);
    CHECK(mod_path_hit("MODS\\a.txt") == 0);   // a relative path with no leading separator is not matched (the game opens absolute paths)
    CHECK(mod_path_hit("C:\\g\\data\\tweak.txt") == 2);
    CHECK(mod_path_hit("tweak.txt") == 2);
    CHECK(mod_path_hit("C:\\g\\data\\mytweak.txt") == 0);
    CHECK(mod_path_hit("C:\\g\\MODSX\\a.txt") == 0);
    CHECK(mod_path_hit("C:\\g\\remods\\a.txt") == 0);
    CHECK(mod_path_hit("C:\\g\\W64ART.POD") == 0);
    CHECK(mod_path_hit((const char*)nullptr) == 0);
    CHECK(mod_path_hit(L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Ghostbusters The Video Game Remastered\\MODS\\deluxe\\data\\tweak.txt") == 1);
    CHECK(mod_path_hit(L"C:\\g\\TWEAK.TXT") == 2);
    CHECK(mod_path_hit(L"C:\\g\\W64SET.POD") == 0);
    wchar_t longp[600]; for (int i = 0; i < 599; ++i) longp[i] = L'a'; longp[599] = 0;
    CHECK(mod_path_hit(longp) == 0);
  }

  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails ? 1 : 0;
}
