#include <stdio.h>
#include <math.h>
#include <initializer_list>
#include "monitormath.h"
using namespace monitor;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

// An OpenVR-style pose (row-major 3x4, columns = right, up, back) for a head that looks along -z and is rolled by
// `rollLeft` radians (left ear down = positive), after a pitch (looking up = positive).
static void pose(double yaw, double pitch, double rollLeft, float* p) {
  // H = Ry(yaw) * Rx(pitch) * Rz(roll)
  double cy = cos(yaw), sy = sin(yaw), cp = cos(pitch), sp = sin(pitch), cr = cos(rollLeft), sr = sin(rollLeft);
  double Rz[9] = {cr, -sr, 0, sr, cr, 0, 0, 0, 1};
  double Rx[9] = {1, 0, 0, 0, cp, -sp, 0, sp, cp};
  double Ry[9] = {cy, 0, sy, 0, 1, 0, -sy, 0, cy};
  double A[9], H[9];
  for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { A[i * 3 + j] = 0; for (int k = 0; k < 3; ++k) A[i * 3 + j] += Rx[i * 3 + k] * Rz[k * 3 + j]; }
  for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) { H[i * 3 + j] = 0; for (int k = 0; k < 3; ++k) H[i * 3 + j] += Ry[i * 3 + k] * A[k * 3 + j]; }
  for (int i = 0; i < 3; ++i) { for (int j = 0; j < 3; ++j) p[i * 4 + j] = (float)H[i * 3 + j]; p[i * 4 + 3] = 0.f; }
}

int main() {
  const double deg = kPi / 180.0;
  // ---- roll from the pose: upright = 0; left ear down = positive; same value at any yaw and normal pitch
  {
    float p[12];
    pose(0, 0, 0, p);                       CHECK(fabs(roll_from_pose34(p)) < 1e-6);
    pose(0.7, 0, 0, p);                     CHECK(fabs(roll_from_pose34(p)) < 1e-6);
    pose(0, 0.5, 0, p);                     CHECK(fabs(roll_from_pose34(p)) < 1e-6);   // pitch alone is no roll
    pose(0, 0, 10 * deg, p);                CHECK(fabs(roll_from_pose34(p) - 10 * deg) < 1e-5);
    pose(2.0, 0, -20 * deg, p);             CHECK(fabs(roll_from_pose34(p) + 20 * deg) < 1e-5);
    pose(-1.0, 40 * deg, 15 * deg, p);      CHECK(fabs(roll_from_pose34(p) - 15 * deg) < 1e-5);
    pose(0.3, -50 * deg, -8 * deg, p);      CHECK(fabs(roll_from_pose34(p) + 8 * deg) < 1e-5);
    pose(0, 89.5 * deg, 30 * deg, p);       CHECK(fabs(roll_from_pose34(p)) < 1e-9);   // straight up: no reference, no turn
    pose(0, 80 * deg, 12 * deg, p);         { double r = roll_from_pose34(p); CHECK(r > 0 && r <= 12 * deg + 1e-9); }   // fading, never wrong-signed
  }
  // ---- the turn levels the horizon: the way the world's "up" points in the eye picture ends up straight up on the monitor
  {
    for (int fit = 0; fit <= 1; ++fit) {
      for (double rollDeg = -25; rollDeg <= 25.1; rollDeg += 5) {
        float p[12];
        pose(0.4, 0.2, rollDeg * deg, p);
        double r = roll_from_pose34(p);
        Window w; double m[4];
        make_window(fit, 100, 3840, 2880, fit ? 16.0 / 9.0 : 4.0 / 3.0, r, &w);
        make_matrix(w, 3840, 2880, r, m);
        // output point straight above the middle
        double su, sv;
        map_point(w, m, 0.5, 0.5 - 0.1, &su, &sv);
        double dx = (su - w.cx) * 3840, dy = -(sv - w.cy) * 2880;      // picture pixels, y up
        // the picture's own idea of "up" in its pixels: (right.y, up.y)
        double ux = p[4], uy = p[5];
        double cross = dx * uy - dy * ux, dot = dx * ux + dy * uy;
        CHECK(fabs(cross) < 1e-6 * (fabs(dot) + 1) );
        CHECK(dot > 0);
        // and a point to the right of the middle lies along the world's horizontal in the picture (perpendicular to "up")
        map_point(w, m, 0.5 + 0.1, 0.5, &su, &sv);
        double rx = (su - w.cx) * 3840, ry = -(sv - w.cy) * 2880;
        CHECK(fabs(rx * ux + ry * uy) < 1e-6 * (fabs(rx) + fabs(ry) + 1));
        CHECK(rx * uy - ry * ux > 0);   // to the right of "up", not to the left
      }
    }
  }
  // ---- no roll: the plain mapping
  {
    Window w; double m[4];
    make_window(0, 100, 3840, 2880, 4.0 / 3.0, 0, &w);
    make_matrix(w, 3840, 2880, 0, m);
    CHECK(w.sw == 1.0 && w.sh == 1.0 && w.cx == 0.5 && w.cy == 0.5);
    CHECK(m[0] == 1.0 && m[3] == 1.0 && fabs(m[1]) < 1e-12 && fabs(m[2]) < 1e-12);
    double su, sv;
    CHECK(map_point(w, m, 0.0, 0.0, &su, &sv) && fabs(su) < 1e-12 && fabs(sv) < 1e-12);
    CHECK(map_point(w, m, 1.0, 1.0, &su, &sv) && fabs(su - 1) < 1e-12 && fabs(sv - 1) < 1e-12);
  }
  // ---- fit 1: fills a 16:9 window with the full picture width, so the height is 3/4 of the picture; never stretched
  {
    Window w;
    int shrunk = make_window(1, 100, 3840, 2880, 16.0 / 9.0, 0, &w);
    CHECK(!shrunk && fabs(w.sw - 1.0) < 1e-12 && fabs(w.sh - 0.75) < 1e-9);
    CHECK(fabs((w.sw * 3840) / (w.sh * 2880) - 16.0 / 9.0) < 1e-9);       // same shape as the window
    // a window narrower than the picture keeps the height
    make_window(1, 100, 3840, 2880, 1.0, 0, &w);
    CHECK(fabs(w.sh - 1.0) < 1e-12 && fabs(w.sw - 0.75) < 1e-9);
    // zoom
    make_window(1, 70, 3840, 2880, 16.0 / 9.0, 0, &w);
    CHECK(fabs(w.sw - 0.7) < 1e-9 && fabs(w.sh - 0.525) < 1e-9);
    // out-of-range zoom is held to 30..100 (1.7.28: 50 -> 30)
    make_window(0, 10, 3840, 2880, 4.0 / 3.0, 0, &w);   CHECK(fabs(w.sw - 0.3) < 1e-12);
    make_window(0, 400, 3840, 2880, 4.0 / 3.0, 0, &w);  CHECK(fabs(w.sw - 1.0) < 1e-12);
  }
  // ---- fit 1 with a turn: the turned window stays inside the picture (nothing but picture is shown)
  {
    for (double rollDeg = -40; rollDeg <= 40.1; rollDeg += 4) {
      double r = rollDeg * deg;
      Window w; double m[4];
      make_window(1, 100, 3840, 2880, 16.0 / 9.0, r, &w);
      make_matrix(w, 3840, 2880, r, m);
      const double cs[5][2] = {{0, 0}, {1, 0}, {0, 1}, {1, 1}, {0.5, 0.5}};
      for (int i = 0; i < 5; ++i) {
        double su, sv;
        CHECK(map_point(w, m, cs[i][0], cs[i][1], &su, &sv) || 1);
        CHECK(su > -1e-9 && su < 1 + 1e-9 && sv > -1e-9 && sv < 1 + 1e-9);
      }
      CHECK(w.sw <= 1.0 + 1e-12 && w.sh <= 0.75 + 1e-12);
    }
    // a small turn costs only a small zoom
    Window w;
    make_window(1, 100, 3840, 2880, 16.0 / 9.0, 3 * deg, &w);
    CHECK(w.sw > 0.9);
    // whole picture (fit 0): the window is not shrunk (black corners instead), so everything stays in view
    make_window(0, 100, 3840, 2880, 4.0 / 3.0, 10 * deg, &w);
    CHECK(w.sw == 1.0 && w.sh == 1.0);
  }
  // ---- isotropic: a turn keeps squares square (the matrix is a rotation in picture pixels)
  {
    Window w; double m[4];
    double r = 17 * deg;
    make_window(0, 100, 3840, 2880, 4.0 / 3.0, r, &w);
    make_matrix(w, 3840, 2880, r, m);
    // columns in picture pixels: (m00*W, m10*H) and (m01*W, m11*H), per unit of output u / v (output units are the picture's own for fit 0)
    double a0 = m[0] * 3840, a1 = m[2] * 2880, b0 = m[1] * 3840, b1 = m[3] * 2880;
    CHECK(fabs(a0 * b0 + a1 * b1) < 1e-6);                                           // perpendicular
    CHECK(fabs(sqrt(a0 * a0 + a1 * a1) / 3840 - sqrt(b0 * b0 + b1 * b1) / 2880) < 1e-9);   // same length per unit of picture size
  }
  // ---- inscribed scale is 1 when it fits, and symmetric in the sign of the roll
  {
    CHECK(inscribed_scale(100, 50, 200, 200, 0.3) == 1.0);
    double a = inscribed_scale(1920, 1080, 1920, 1440, 0.2), b = inscribed_scale(1920, 1080, 1920, 1440, -0.2);
    CHECK(fabs(a - b) < 1e-12 && a < 1.0 && a > 0.5);
  }
  // ---- 1.4 the calm horizon follow
  {
    Calm c = {0, 0};
    const double d = 3.14159265358979 / 180.0;
    CHECK(calm_roll(&c, 1.4 * d, 0.01) == 0.0);                       // the head's resting tilt (1.4 degrees in the 1.3 log) is ignored: no black wedge
    for (int i = 0; i < 100; ++i) calm_roll(&c, 1.4 * d, 0.01);
    CHECK(fabs(c.sm) < 1e-12);
    double r = 0; for (int i = 0; i < 300; ++i) r = calm_roll(&c, 12.5 * d, 0.01);
    CHECK(fabs(r - 10.0 * d) < 0.02 * d);                             // 12.5 degrees follows as 10 (the dead zone is taken off)
    double r1 = calm_roll(&c, 40.0 * d, 0.01);                        // a big jump does not snap
    CHECK(r1 > 10.0 * d && r1 < 13.0 * d);
    for (int i = 0; i < 600; ++i) r = calm_roll(&c, 80.0 * d, 0.01);
    CHECK(fabs(r - 30.0 * d) < 1e-9);                                 // never more than 30 degrees
    for (int i = 0; i < 600; ++i) r = calm_roll(&c, -80.0 * d, 0.01);
    CHECK(fabs(r + 30.0 * d) < 1e-9);                                 // symmetric
    Calm q = {0, 0};
    CHECK(fabs(calm_roll(&q, 20.0 * d, 0.0) - 17.5 * d) < 1e-9);      // the first value is taken as it is (no swing from zero)
    calm_roll(&q, 0.0, 5.0);                                          // after a pause (over 0.5 s) it also jumps
    CHECK(q.sm == 0.0);
  }
  // 1.6: the window is always filled, whatever the size / shape of the PC window, the eye picture size and the head's roll: the source window has the SHAPE of the output (no bars, no stretch)
  // and stays inside the picture (no black corners)
  {
    const int sizes[][2] = {{800, 600}, {1024, 768}, {1280, 720}, {1280, 800}, {1366, 768}, {1600, 900}, {1920, 1080}, {1920, 1200}, {2560, 1080}, {2560, 1440}, {2560, 1600}, {3440, 1440},
                            {3840, 1080}, {3840, 2160}, {5120, 1440}, {5120, 2880}, {1080, 1920}, {900, 1600}, {720, 1280}, {600, 800}, {1000, 1000}, {7680, 4320}, {640, 360}, {300, 700}};
    const int tex[][2] = {{3840, 2880}, {2880, 2160}, {1920, 1440}, {2233, 2413}, {1280, 960}, {4096, 4096}};
    const double rolls[] = {0.0, 2.6 * deg, 5.0 * deg, 12.0 * deg, 30.0 * deg, -20.0 * deg};
    const int zooms[] = {50, 72, 100};
    int bad = 0, n = 0;
    for (auto& z : sizes) for (auto& t : tex) for (double r : rolls) for (int zoom : zooms) {
      Window w; const double va = (double)z[0] / (double)z[1];
      make_window(1, zoom, t[0], t[1], va, r, &w);
      double m[4]; make_matrix(w, t[0], t[1], r, m);
      ++n;
      const double shape = (w.sw * t[0]) / (w.sh * t[1]);
      if (fabs(shape - va) > 1e-6 * va) ++bad;                               // same shape as the output: filled, not stretched
      for (int c = 0; c < 4; ++c) {                                          // the four corners of the output come from inside the picture
        double su, sv; map_point(w, m, (c & 1) ? 1.0 : 0.0, (c & 2) ? 1.0 : 0.0, &su, &sv);
        if (su < -1e-6 || su > 1 + 1e-6 || sv < -1e-6 || sv > 1 + 1e-6) ++bad;
      }
      if (!(w.sw > 0.04 && w.sh > 0.04 && w.sw <= 1.0 + 1e-9 && w.sh <= 1.0 + 1e-9)) ++bad;
    }
    printf("fill check: %d cases, %d bad\n", n, bad);
    CHECK(bad == 0);
  }
  // ---- 1.7.28 the window shows a wanted field of view: zoom_for_hfov
  {
    Window w0;
    make_window(1, 100, 2880, 2880, 16.0 / 9.0, 0.0, &w0);   // the square eye picture in a 16:9 window: the full width is kept
    CHECK(fabs(w0.sw - 1.0) < 1e-9 && fabs(w0.sh - 0.5625) < 1e-9);
    const double tan110 = tan(55.0 * deg);                    // the picture the engine draws for the headset: 110 degrees
    int z = zoom_for_hfov(100.0, tan110, w0.sw);              // 100 degrees across: tan 50 / tan 55 = 0.8345
    CHECK(z >= 83 && z <= 84);
    Window w; make_window(1, z, 2880, 2880, 16.0 / 9.0, 0.0, &w);
    CHECK(fabs(2.0 * atan(w.sw * tan110) / deg - 100.0) < 0.6);             // what the window really shows across
    CHECK(zoom_for_hfov(110.0, tan110, w0.sw) == 100);                       // all of it
    CHECK(zoom_for_hfov(130.0, tan110, w0.sw) == 100);                       // wider than was drawn: all of it, nothing invented
    CHECK(zoom_for_hfov(60.0, tan110, w0.sw) == 40);                          // tan 30 / tan 55 = 0.404
    CHECK(zoom_for_hfov(40.0, tan110, w0.sw) == 30);                          // never below 30
    CHECK(zoom_for_hfov(0.0, tan110, w0.sw) == 0 && zoom_for_hfov(20.0, tan110, w0.sw) == 0);   // 0 = not used; below 30 degrees = nonsense
    CHECK(zoom_for_hfov(100.0, 0.0, w0.sw) == 0 && zoom_for_hfov(100.0, tan110, 0.0) == 0 && zoom_for_hfov(200.0, tan110, 1.0) == 0);
    // a window narrower than the picture: the base shows less than the full width, the wish is measured against that
    Window wn; make_window(1, 100, 2880, 2880, 0.5, 0.0, &wn);              // portrait window: sw = 0.5
    CHECK(fabs(wn.sw - 0.5) < 1e-9);
    int zn = zoom_for_hfov(60.0, tan110, wn.sw);
    Window wz; make_window(1, zn, 2880, 2880, 0.5, 0.0, &wz);
    CHECK(fabs(2.0 * atan(wz.sw * tan110) / deg - 60.0) < 1.5);
  }
  // 1.7.48: actual projection, not eye texture shape, keeps the monitor undistorted.
  {
    const double h = tan(55 * deg), v = tan(52 * deg), aspect = 16.0 / 9.0;
    Window w; double m[4];
    CHECK(projection_window(1, 100, h, v, aspect, 0, &w, m) == 0);
    CHECK(fabs(h * m[0] / aspect - v * m[3]) < 1e-9);
    CHECK(w.sw == 1.0 && w.sh < 0.7);
    const double oldWidth = 2 * atan(h * zoom_for_hfov(100, h, 1) * 0.01) / deg;
    const double newWidth = 2 * atan(h * zoom_for_hfov(115, h, 1) * 0.01) / deg;
    CHECK(newWidth > oldWidth + 9.0);
    lower_window(&w, m, down_shift(10, v, w));
    CHECK(w.cy > 0.5 && w.cy + m[3] * 0.5 <= 1.0 + 1e-9);
    CHECK(projection_window(1, 100, 0, v, aspect, 0, &w, m) == -1);
  }
  // The lowered crop remains within the source at any supported window shape/roll.
  {
    for (double aspect : {0.5625, 1.0, 4.0 / 3.0, 16.0 / 9.0, 21.0 / 9.0})
      for (double roll : {-30 * deg, -5 * deg, 0.0, 5 * deg, 30 * deg})
        for (int zoom : {60, 85, 100}) {
          Window w; double m[4];
          CHECK(projection_window(1, zoom, 1.35, 1.45, aspect, roll, &w, m) >= 0);
          lower_window(&w, m, down_shift(25, 1.45, w));
          for (int c = 0; c < 4; ++c) {
            double u, v; map_point(w, m, c & 1 ? 1 : 0, c & 2 ? 1 : 0, &u, &v);
            CHECK(u >= -1e-9 && u <= 1 + 1e-9 && v >= -1e-9 && v <= 1 + 1e-9);
          }
        }
  }
  // Real hand positions below a level headset move the monitor crop down only.
  {
    float head[12] = {1, 0, 0, 0, 0, 1, 0, 1.6f, 0, 0, 1, 0};
    float hand[3] = {0.20f, 1.05f, -0.65f};
    double u, v;
    CHECK(project_point(head, hand, -0.035, 1.4, 1.4, &u, &v));
    CHECK(u > 0.5 && v > 0.75);
    Window w; double m[4]; projection_window(1, 100, 1.4, 1.4, 16.0 / 9.0, 0, &w, m);
    const double shift = hand_shift(m, u, v, 0);
    CHECK(shift > 0);
    lower_window(&w, m, shift);
    const double outputY = 0.5 + (v - w.cy) / m[3];
    CHECK(outputY <= 0.85 + 1e-9);
    CHECK(hand_shift(m, 0.5, 0.4, 0.1) == 0.1);
    hand[2] = 0.5f; CHECK(!project_point(head, hand, 0, 1.4, 1.4, &u, &v));
    hand[2] = -0.65f; hand[0] = NAN; CHECK(!project_point(head, hand, 0, 1.4, 1.4, &u, &v));
    Framing f = {}; CHECK(smooth_down(&f, 0.1, 0.01) == 0.1);
    const double n = smooth_down(&f, 0.3, 0.01); CHECK(n > 0.1 && n < 0.12);
    for (int i = 0; i < 300; ++i) smooth_down(&f, 0.3, 0.01);
    CHECK(fabs(f.down - 0.3) < 1e-6);
  }
  if (!fails) printf("all ok\n");
  return fails ? 1 : 0;
}
