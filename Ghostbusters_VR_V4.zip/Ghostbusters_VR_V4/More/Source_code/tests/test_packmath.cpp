// 0.68 the pack follows the torso: bpack::apply on plain world matrices.
#include <stdio.h>
#include <math.h>
#include "packmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static void ident(float* M) { for (int i = 0; i < 16; ++i) M[i] = (i % 5 == 0) ? 1.f : 0.f; }
static void rotz(double deg, double* Q) {   // column form, turns x toward y
  double r = deg * vm::kPi / 180.0, s, c; vm::dsincos(r, &s, &c);
  Q[0] = c; Q[1] = -s; Q[2] = 0; Q[3] = s; Q[4] = c; Q[5] = 0; Q[6] = 0; Q[7] = 0; Q[8] = 1;
}
int main() {
  bpack::Motion m;
  for (int i = 0; i < 2; ++i) { for (int k = 0; k < 3; ++k) m.pv[i][k] = 0; weight::ident(m.Q[i]); }
  m.have = 0; m.drop = -0.5; m.shift[0] = m.shift[1] = m.shift[2] = 0;
  float M[16]; ident(M); M[12] = 1; M[13] = 4; M[14] = 2;
  CHECK(bpack::apply(m, M, 3) == 0 && M[13] == 4.f);                       // no record: untouched
  m.have = 1;
  CHECK(bpack::apply(m, M, 0) == 1 && fabs(M[13] - 3.5) < 1e-6 && M[12] == 1.f);   // drop only
  ident(M); M[12] = 1; M[13] = 4; M[14] = 2;
  m.drop = 0;
  CHECK(bpack::apply(m, M, 3) == 1 && fabs(M[12] - 1) < 1e-6 && fabs(M[13] - 4) < 1e-6);   // identity rotations: same place
  // 90 degrees about z through (0,3,0): the point (1,4,2) goes to (-1,3+1,2) = (-1,4,2)?? rel (1,1,2) -> (-1,1,2): world (-1,4,2)
  m.pv[0][0] = 0; m.pv[0][1] = 3; m.pv[0][2] = 0; rotz(90, m.Q[0]);
  ident(M); M[12] = 1; M[13] = 4; M[14] = 2;
  CHECK(bpack::apply(m, M, 1) == 1);
  printf("pos %.3f,%.3f,%.3f\n", M[12], M[13], M[14]);
  CHECK(fabs(M[12] + 1) < 1e-5 && fabs(M[13] - 4) < 1e-5 && fabs(M[14] - 2) < 1e-5);
  CHECK(fabs(M[0]) < 1e-5 && fabs(M[1] - 1) < 1e-5 && fabs(M[4] + 1) < 1e-5 && fabs(M[5]) < 1e-5);   // x row now points up, y row points -x
  // stage 2 off: only stage 1 rotates; stage bit 1 alone rotates about its own pivot
  m.pv[1][0] = 0; m.pv[1][1] = 0; m.pv[1][2] = 0; rotz(-90, m.Q[1]);
  ident(M); M[12] = 1; M[13] = 4; M[14] = 2;
  CHECK(bpack::apply(m, M, 1) == 1 && fabs(M[12] + 1) < 1e-5);
  ident(M); M[12] = 1; M[13] = 4; M[14] = 2;
  CHECK(bpack::apply(m, M, 3) == 1);
  printf("both: %.3f,%.3f,%.3f\n", M[12], M[13], M[14]);   // (-1,4,2) about the origin by -90: (x,y)->(y,-x) = (4,1,2)
  CHECK(fabs(M[12] - 4) < 1e-5 && fabs(M[13] - 1) < 1e-5 && fabs(M[14] - 2) < 1e-5);
  // 0.69 the shift of the whole body comes last (after the rotations)
  m.pv[1][0] = 0; m.pv[1][1] = 0; m.pv[1][2] = 0; weight::ident(m.Q[1]);
  m.shift[0] = 0.5; m.shift[1] = -0.25; m.shift[2] = 1.0;
  ident(M); M[12] = 1; M[13] = 4; M[14] = 2;
  CHECK(bpack::apply(m, M, 1) == 1);
  CHECK(fabs(M[12] - (-1 + 0.5)) < 1e-5 && fabs(M[13] - (4 - 0.25)) < 1e-5 && fabs(M[14] - 3.0) < 1e-5);
  m.shift[0] = m.shift[1] = m.shift[2] = 0; weight::ident(m.Q[0]); m.drop = 0;
  ident(M); M[12] = 1; M[13] = 4; M[14] = 2;
  CHECK(bpack::apply(m, M, 0) == 0 && fabs(M[13] - 4) < 1e-6);   // nothing to do
  m.shift[1] = -0.5;
  CHECK(bpack::apply(m, M, 0) == 1 && fabs(M[13] - 3.5) < 1e-6);   // shift alone
  m.shift[1] = 0; rotz(90, m.Q[0]); m.pv[0][1] = 3;
  // not finite: nothing is written
  ident(M); M[12] = 1; M[13] = 4; M[14] = 2;
  m.Q[0][0] = 1e39 * 1e39;
  float keep[16]; for (int i = 0; i < 16; ++i) keep[i] = M[i];
  CHECK(bpack::apply(m, M, 1) == 0);
  for (int i = 0; i < 16; ++i) CHECK(M[i] == keep[i]);
  if (!fails) printf("PASS packmath\n");
  return fails ? 1 : 0;
}
