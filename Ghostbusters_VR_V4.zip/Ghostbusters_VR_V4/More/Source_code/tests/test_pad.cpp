// Unit tests for padmath.h (0.33 controller -> Xbox pad).
#include <stdio.h>
#include <math.h>
#include "padmath.h"
using namespace pad;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static Hand H(float x, float y, float t, uint64_t p) { Hand h = {1, x, y, t, p}; return h; }
static uint64_t B(int b) { return 1ull << b; }
int main() {
  Config c = {18, 0, 1};
  // stick shaping
  int16_t x, y;
  shape_stick(0.1f, 0.1f, 0.18, &x, &y); CHECK(x == 0 && y == 0);
  shape_stick(1.0f, 0.0f, 0.18, &x, &y); CHECK(x == 32767 && y == 0);
  shape_stick(-1.0f, 0.0f, 0.18, &x, &y); CHECK(x == -32768);
  shape_stick(0.59f, 0.0f, 0.18, &x, &y); CHECK(x > 16000 && x < 16800);
  shape_stick(NAN, 0, 0.18, &x, &y); CHECK(x == 0 && y == 0);
  shape_stick(2.0f, 0.0f, 0.18, &x, &y); CHECK(x == 32767);
  // triggers
  CHECK(trigger8(0.04f) == 0); CHECK(trigger8(1.0f) == 255); CHECK(trigger8(2.0f) == 255); CHECK(trigger8(NAN) == 0);
  // build
  Hand none = {};
  State s = build(none, none, c); CHECK(s.buttons == 0 && s.rt == 0 && s.lx == 0);
  s = build(H(0, 1, 0, 0), H(1, 0, 1, 0), c);
  CHECK(s.ly == 32767 && s.rx == 32767 && s.rt == 255 && s.lt == 0);
  s = build(H(0, 0, 0, B(kVrA) | B(kVrMenu) | B(kVrStick)), H(0, 0, 0, B(kVrA) | B(kVrMenu) | B(kVrStick)), c);
  CHECK(s.buttons == (kX | kY | kLeftShoulder | kA | kB | kRightShoulder));
  // grip + stick = dpad, no turn
  // 0.50: the D-pad modifier is the LEFT grip with the left hand away from the wand; a right grip never stops turning
  Hand away = {1, 0, 0, 0, B(kVrGrip), 1}, near = {1, 0, 0, 0, B(kVrGrip), 0};
  s = build(away, H(0, 1, 0, 0), c); CHECK(s.buttons == kDpadUp && s.rx == 0 && s.ry == 0);
  s = build(near, H(1, 0, 0, 0), c); CHECK(s.buttons == 0 && s.rx == 32767);              // two-hand hold: still turns
  s = build(none, H(1, 0, 0, B(kVrGrip)), c); CHECK(s.buttons == 0 && s.rx == 32767);     // right grip: still turns
  s = build(away, H(-1, 0.2f, 0, 0), c); CHECK(s.buttons == kDpadLeft);
  s = build(away, H(0.3f, -0.2f, 0, 0), c); CHECK(s.buttons == 0);  // too small for a dpad press
  Config c2 = c; c2.dpadWithGrip = 0;
  s = build(away, H(1, 0, 0, 0), c2); CHECK(s.buttons == 0 && s.rx == 32767);
  // two-hand fire
  Config c3 = c; c3.twoHandFire = 1;
  s = build(H(0, 0, 1, 0), H(0, 0, 1, B(kVrGrip)), c3); CHECK(s.rt == 0 && s.lt == 255); // alt fire is never gated by two-hand primary fire
  s = build(H(0, 0, 1, B(kVrGrip)), H(0, 0, 1, 0), c3); CHECK(s.rt == 255 && s.lt == 255);   // 0.50: the left (off-hand) grip alone enables primary too
  // start
  s = with_start(State{}, H(0, 0, 0, B(kVrMenu))); CHECK(!(s.buttons & kStart));
  s = with_start(State{}, H(0, 0, 0, B(kVrMenu) | B(kVrGrip))); CHECK(s.buttons & kStart);
  // merge
  State a = {}; a.lx = 20000; a.buttons = kB; State b = {}; b.lx = 10; b.buttons = kA; b.rt = 7;
  State m = merge(a, b); CHECK(m.lx == 20000 && m.buttons == (kA | kB) && m.rt == 7);
  b.lx = -30000; m = merge(a, b); CHECK(m.lx == -30000);
  // packet tracker
  PacketTracker pt = {};
  State z = {}; uint32_t p1 = pt.next(z), p2 = pt.next(z); CHECK(p1 == p2 && p1 != 0);
  z.buttons = kA; uint32_t p3 = pt.next(z); CHECK(p3 != p2); CHECK(pt.next(z) == p3);
  // caps
  uint8_t cap[20]; fake_capabilities(cap);
  CHECK(cap[0] == 1 && cap[1] == 1 && cap[2] == 0 && cap[3] == 0);
  CHECK((cap[4] | (cap[5] << 8)) == 0xF3FF); CHECK(cap[6] == 255 && cap[7] == 255);
  CHECK((cap[8] | (cap[9] << 8)) == 0xFFC0); CHECK((cap[14] | (cap[15] << 8)) == 0xFFC0);
  CHECK((cap[16] | (cap[17] << 8)) == 255 && (cap[18] | (cap[19] << 8)) == 255);
  // rumble
  CHECK(rumble_to_pulse_us(0, 0) == 0); CHECK(rumble_to_pulse_us(1000, 1000) == 0);
  CHECK(rumble_to_pulse_us(65535, 0) == 3999 || rumble_to_pulse_us(65535, 0) == 3999);
  CHECK(rumble_to_pulse_us(30000, 40000) > 400 && rumble_to_pulse_us(30000, 40000) < 3999);
  // hand aim: identity level + identity hand -> forward = +z
  float I[9] = {1,0,0, 0,1,0, 0,0,1}, o[3];
  CHECK(hand_forward_world(I, I, 0, o)); CHECK(fabs(o[2] - 1) < 1e-5 && fabs(o[0]) < 1e-5);
  CHECK(hand_forward_world(I, I, 30, o)); CHECK(fabs(o[1] - 0.5) < 1e-4 && fabs(o[2] - 0.8660254) < 1e-4);
  CHECK(hand_forward_world(I, I, -30, o)); CHECK(o[1] < -0.49);
  float bad[9] = {0};
  CHECK(!hand_forward_world(I, bad, 0, o));
  // level yawed 90 deg right (forward column -> +x): forward becomes +x
  float Y[9] = {0,0,1, 0,1,0, -1,0,0};
  CHECK(hand_forward_world(Y, I, 0, o)); CHECK(fabs(o[0] - 1) < 1e-5 && fabs(o[2]) < 1e-5);
  // two-hand line
  float r[3] = {0.2f, 1.0f, 0.0f}, f[3] = {0.2f, 1.0f, 0.5f};
  CHECK(two_hand_line_world(I, r, f, 0.12, o)); CHECK(fabs(o[2] - 1) < 1e-5);
  CHECK(two_hand_line_world(Y, r, f, 0.12, o)); CHECK(fabs(o[0] - 1) < 1e-5);
  float f2[3] = {0.2f, 1.0f, 0.05f};
  CHECK(!two_hand_line_world(I, r, f2, 0.12, o));
  float f3[3] = {0.2f, 1.0f, 5.0f};
  CHECK(!two_hand_line_world(I, r, f3, 0.12, o));
  {  // holster zone: hip is 0.22 m to the right of the head and 0.55 m below it
    float head[12] = {1,0,0,0, 0,1,0,1.7f, 0,0,1,0};              // looking along -z
    float hand[12] = {1,0,0,0.22f, 0,1,0,1.15f, 0,0,1,0};
    CHECK(pad::holster_hit(head, hand, 0.22, 0.55, 0.16));
    hand[3] = -0.22f; CHECK(!pad::holster_hit(head, hand, 0.22, 0.55, 0.16));   // left hip: no
    hand[3] = 0.22f; hand[7] = 1.5f; CHECK(!pad::holster_hit(head, hand, 0.22, 0.55, 0.16));   // chest height: no
    float turned[12] = {0,0,-1,0, 0,1,0,1.7f, 1,0,0,0};            // head turned: forward = +x, right = +z? (yaw -90)
    float hip[12] = {1,0,0,0, 0,1,0,1.15f, 0,0,1,0}; hip[11] = 0.22f;   // 0.22 m along +z
    CHECK(pad::holster_hit(turned, hip, 0.22, 0.55, 0.16));
    pad::Holster h = {}; h.update(1, 0); CHECK(!h.holstered); h.update(0, 1); h.update(1, 1); CHECK(h.holstered);
    h.update(1, 1); CHECK(h.holstered); h.update(0, 1); h.update(1, 1); CHECK(!h.holstered);
  }
  {  // 0.45 pack zone: 0.22 m behind and 0.15 m below the head, radius 0.26, either side
    float head[12] = {1,0,0,0, 0,1,0,1.7f, 0,0,1,0};              // looking along -z, so behind = +z
    float hand[12] = {1,0,0,0.20f, 0,1,0,1.5f, 0,0,1,0.25f};      // over the right shoulder
    CHECK(pad::pack_hit(head, hand, 0.22, 0.15, 0.26));
    hand[3] = -0.20f; CHECK(pad::pack_hit(head, hand, 0.22, 0.15, 0.26));                // over the left shoulder
    hand[3] = 0.0f; hand[11] = -0.3f; hand[7] = 1.4f; CHECK(!pad::pack_hit(head, hand, 0.22, 0.15, 0.26));   // in front of the chest: no
    hand[11] = 0.0f; hand[7] = 1.4f; CHECK(!pad::pack_hit(head, hand, 0.22, 0.15, 0.26));    // right under the chin: no
    hand[11] = 0.25f; hand[7] = 0.9f; CHECK(!pad::pack_hit(head, hand, 0.22, 0.15, 0.26));   // behind but at the hips: no
    float turned[12] = {0,0,-1,0, 0,1,0,1.7f, 1,0,0,0};          // head turned (forward = +x): behind = -x
    float bk[12] = {1,0,0,-0.25f, 0,1,0,1.5f, 0,0,1,0};
    CHECK(pad::pack_hit(turned, bk, 0.22, 0.15, 0.26));
    bk[3] = 0.25f; CHECK(!pad::pack_hit(turned, bk, 0.22, 0.15, 0.26));                  // the same spot in front: no
    float up[12] = {1,0,0,0, 0,0,1,1.7f, 0,-1,0,0};              // looking straight down: no yaw, no answer
    CHECK(!pad::pack_hit(up, bk, 0.22, 0.15, 0.26));
  }
  // 0.46 game button numbers (bit i = the game's button i)
  CHECK(game_button_mask(0, 0, 0) == 0);
  CHECK(game_button_mask(kRightShoulder, 0, 0) == (1u << 7));            // Vent = RB = button 7
  CHECK(game_button_mask(kLeftShoulder, 0, 0) == (1u << 6));
  CHECK(game_button_mask(kA | kB | kX | kY, 0, 0) == ((1u << 2) | (1u << 1) | (1u << 3) | 1u));
  CHECK(game_button_mask(kDpadLeft | kDpadRight | kDpadUp | kDpadDown, 0, 0) == ((1u << 28) | (1u << 29) | (1u << 30) | (1u << 31)));
  CHECK(game_button_mask(0, 61, 0) == (1u << 4) && game_button_mask(0, 60, 60) == 0 && game_button_mask(0, 0, 255) == (1u << 5));
  CHECK(game_button_mask(kStart | kBack | kLeftThumb | kRightThumb, 0, 0) == ((1u << 8) | (1u << 9) | (1u << 10) | (1u << 11)));
  // 1.7.91 import-slot guard: repair only when another program stands in the slot, our hook is not being called, the game is in play, and not endlessly
  CHECK(guard_should_repatch(1, 1, 5, 5, 1, 0) == 0);      // our function is still there
  CHECK(guard_should_repatch(0, 0, 5, 5, 1, 0) == 0);      // the slot holds no code: leave it
  CHECK(guard_should_repatch(0, 1, 9, 5, 1, 0) == 0);      // the other function calls ours (calls rose): no loop
  CHECK(guard_should_repatch(0, 1, 5, 5, 0, 0) == 0);      // not in play yet
  CHECK(guard_should_repatch(0, 1, 5, -1, 1, 0) == 0);     // first check: baseline only
  CHECK(guard_should_repatch(0, 1, 5, 5, 1, 8) == 0);      // eight repairs are enough
  CHECK(guard_should_repatch(0, 1, 5, 5, 1, 0) == 1);      // replaced and never called: put ours in front
  // 1.7.92 DirectInput takeover: only when the VR pad is live for two checks, a DirectInput pad is open, the game reads no XInput, and it is not endless
  CHECK(di_takeover_should_arm(1, 2, 1, 7, 7, 0) == 1);     // live, DirectInput open, no reads since the last check: take over
  CHECK(di_takeover_should_arm(1, 2, 1, 9, 7, 0) == 0);     // the game does read XInput: leave everything
  CHECK(di_takeover_should_arm(1, 2, 0, 7, 7, 0) == 0);     // no DirectInput pad: nothing to close
  CHECK(di_takeover_should_arm(0, 2, 1, 7, 7, 0) == 0);     // the VR controllers are not making a pad
  CHECK(di_takeover_should_arm(1, 1, 1, 7, 7, 0) == 0);     // only the first check of a live pad: wait for the second
  CHECK(di_takeover_should_arm(1, 3, 1, 7, -1, 0) == 0);    // no baseline yet
  CHECK(di_takeover_should_arm(1, 9, 1, 0, 0, 5) == 1);     // the sixth try is still allowed
  CHECK(di_takeover_should_arm(1, 9, 1, 0, 0, 6) == 0);     // six tries are enough
  // 1.7.141: a HOTAS in slot 0: the game still reads XInput for slots 1-3, but never for slot 0
  CHECK(di_takeover_should_arm(1, 2, 1, 50, 20, 0) == 0);              // the old rule misses it
  CHECK(di_takeover_should_arm_slot0(1, 2, 1, 4, 4, 0) == 1);          // slot 0 is a DirectInput device and XInput slot 0 is never asked: take over
  CHECK(di_takeover_should_arm_slot0(1, 2, 1, 9, 4, 0) == 0);          // the game asks XInput for slot 0: the VR pad reaches it, leave everything
  CHECK(di_takeover_should_arm_slot0(1, 2, 0, 4, 4, 0) == 0);          // the device is in another slot: slot 0 is fine
  CHECK(di_takeover_should_arm_slot0(0, 2, 1, 4, 4, 0) == 0);          // controllers not making a pad
  CHECK(di_takeover_should_arm_slot0(1, 1, 1, 4, 4, 0) == 0);          // wait for the second check
  CHECK(di_takeover_should_arm_slot0(1, 2, 1, 4, -1, 0) == 0);         // no baseline
  CHECK(di_takeover_should_arm_slot0(1, 2, 1, 4, 4, 6) == 0);          // six tries are enough
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
