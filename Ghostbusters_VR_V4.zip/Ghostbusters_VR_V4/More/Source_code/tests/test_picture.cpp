// Unit tests for the 0.26 picture levels (src/picturemath.h), the world-size
// factor (src/stereomath.h) and a model of how the game picks its picture
// size from the display-mode list (ghost.exe 0x3F0C10 / 0x301800, see
// src/layout.h "Display modes").
// Build: g++ -std=c++17 -O1 -o tests/test_picture tests/test_picture.cpp && tests/test_picture
#include "../src/headmath.h"
#include "../src/stereomath.h"
#include "../src/picturemath.h"
#include <cmath>
#include <cstdio>
#include <vector>
static int fails;
static void check(const char* name, bool ok, double v = 0) { printf("%s %s (%.6g)\n", ok ? "PASS" : "FAIL", name, v); fails += !ok; }

struct Mode { uint32_t w, h; };

// Model of the game's mode record (0x3F0EE6..0x3F0FA7): distinct sizes of at
// least 640 x 480 in list order, at most 128 collected, the last 32 kept.
static std::vector<Mode> game_record(const std::vector<Mode>& list) {
  std::vector<Mode> seen;
  for (const Mode& m : list) {
    if (seen.size() >= 128) break;
    if (m.w < 640 || m.h < 480) continue;
    bool dup = false;
    for (const Mode& s : seen) if (s.w == m.w && s.h == m.h) dup = true;
    if (!dup) seen.push_back(m);
  }
  size_t keep = seen.size() > 32 ? 32 : seen.size();
  return std::vector<Mode>(seen.end() - keep, seen.end());
}

// Model of the selection (0x301880..0x3018E3 and 0x3B7E99..0x3B7F23): the
// wanted size, else the entry equal to the desktop size, else entry 0.
static Mode game_select(const std::vector<Mode>& rec, Mode wanted, Mode desktop) {
  int edi = 0, r8 = -1;
  for (int i = 0; i < (int)rec.size(); ++i) {
    if (rec[i].w == wanted.w && rec[i].h == wanted.h) { r8 = i; break; }
    if (rec[i].w == desktop.w && rec[i].h == desktop.h) r8 = i;
  }
  if (r8 != -1) edi = r8;
  return rec[edi];
}

// Model of the probe's answer to the game's two calls (modes.cpp).
static std::vector<Mode> probe_answer(int level, Mode desktop, const std::vector<Mode>& real) {
  uint32_t w, h;
  if (real.empty() || !picture::level_size(level, desktop.w, desktop.h, &w, &h)) return real;
  return {Mode{w, h}};
}

int main() {
  uint32_t w = 0, h = 0;
  // ---- level sizes on the tester's 2560 x 1440 monitor ----
  check("level 1 leaves the game alone", !picture::level_size(1, 2560, 1440, &w, &h));
  check("level 2 = 3840 x 2160", picture::level_size(2, 2560, 1440, &w, &h) && w == 3840 && h == 2160, w);
  check("level 3 = 3840 x 2880 (2880 lines, width limited to 3840)", picture::level_size(3, 2560, 1440, &w, &h) && w == 3840 && h == 2880, w);
  check("level 4 = 2880 x 2880", picture::level_size(4, 2560, 1440, &w, &h) && w == 2880 && h == 2880, w);
  check("level 0 / 5 leave the game alone", !picture::level_size(0, 2560, 1440, &w, &h) && !picture::level_size(5, 2560, 1440, &w, &h));
  // other monitors
  check("1920 x 1080 level 2 = 3840 x 2160", picture::level_size(2, 1920, 1080, &w, &h) && w == 3840 && h == 2160, w);
  check("1920 x 1200 level 2 = 3456 x 2160", picture::level_size(2, 1920, 1200, &w, &h) && w == 3456 && h == 2160, w);
  check("1920 x 1080 level 3 = 3840 x 2880", picture::level_size(3, 1920, 1080, &w, &h) && w == 3840 && h == 2880, w);
  check("1280 x 1024 (5:4) level 3 = 3600 x 2880", picture::level_size(3, 1280, 1024, &w, &h) && w == 3600 && h == 2880, w);
  check("3440 x 1440 level 2 limited to 3840 x 2160", picture::level_size(2, 3440, 1440, &w, &h) && w == 3840 && h == 2160, w);
  check("5120 x 1440 level 3 limited to 3840 x 2880", picture::level_size(3, 5120, 1440, &w, &h) && w == 3840 && h == 2880, h);
  check("portrait monitor left alone", !picture::level_size(2, 1440, 2560, &w, &h));
  check("tiny desktop left alone", !picture::level_size(2, 320, 200, &w, &h));
  bool even = true;
  for (uint32_t dw = 1024; dw <= 5120; dw += 7)
    for (int lv = 2; lv <= 4; ++lv)
      for (uint32_t dh = 600; dh <= 2160; dh += 60)
        if (picture::level_size(lv, dw, dh, &w, &h) && ((w | h) & 1 || w > 3840 || h > 2880 || w < 640 || h < 2160)) even = false;
  check("sizes are always even, at most 3840 wide and 2880 lines (the game's limits)", even);
  check("line limit matches the engine's two 1440-entry tables", picture::kMaxLines == 2880 && (0x2523A90 - 0x251E090) / 8 == 2880);

  // ---- pixels one eye gets (Quest 3 values from the 0.21 log) ----
  const float L[2] = {-1.37638f, -0.83910f}, R[2] = {0.83910f, 1.37638f}, T[2] = {-1.42815f, -1.42815f}, B[2] = {0.96569f, 0.96569f};
  double needH, needV; stereo::required_fov(L, R, T, B, &needH, &needV);
  auto eye_pixels = [&](uint32_t pw, uint32_t ph, bool wide, double* ex, double* ey) {
    double aspect = (double)pw / ph;                      // the game's aspect = width / height (0x2FA4C0)
    double tanV = wide ? needV : stereo::game_tan_v(needH, needV, aspect);
    double tanH = wide ? needH : tanV * aspect;
    float b[4]; int in = stereo::texture_bounds(L[0], R[0], T[0], B[0], tanH, tanV, b);
    *ex = (b[2] - b[0]) * pw; *ey = (b[3] - b[1]) * ph;
    return in;
  };
  double ex, ey;
  check("1440p (0.25): 1116 x 1206 per eye, as logged", eye_pixels(2560, 1440, false, &ex, &ey) && fabs(ex - 1116.5) < 1.5 && fabs(ey - 1206.5) < 1.5, ex);
  check("1440p with F7: 2060 wide, as logged", eye_pixels(2560, 1440, true, &ex, &ey) && fabs(ex - 2060) < 2, ex);
  check("level 2: 1674 x 1810 per eye", eye_pixels(3840, 2160, false, &ex, &ey) && fabs(ex - 1674.7) < 2 && fabs(ey - 1810) < 2, ey);
  check("level 2 with F7: 3090 wide", eye_pixels(3840, 2160, true, &ex, &ey) && fabs(ex - 3090) < 3, ex);
  check("level 3 (3840 x 2880): 2233 x 2413 per eye", eye_pixels(3840, 2880, false, &ex, &ey) && fabs(ex - 2233) < 3 && fabs(ey - 2413) < 3, ex);
  check("a 5120 x 2880 picture would give the same eye pixels for 33 % more work", eye_pixels(5120, 2880, false, &ex, &ey) && fabs(ex - 2233) < 3 && fabs(ey - 2413) < 3, ex);
  check("level 4 (square): both eyes inside, 2233 x 2413 per eye", eye_pixels(2880, 2880, false, &ex, &ey) && fabs(ex - 2233) < 3 && fabs(ey - 2413) < 3, ex);
  { // the right eye must fit as well in the square picture
    double tanV = stereo::game_tan_v(needH, needV, 1.0); float b[4];
    check("level 4: right eye inside too", stereo::texture_bounds(L[1], R[1], T[1], B[1], tanV, tanV, b) == 1, b[2]);
  }

  // ---- the game's own selection, with and without the probe's answer ----
  std::vector<Mode> real = {{640, 480}, {800, 600}, {1024, 768}, {1280, 720}, {1280, 720}, {1920, 1080}, {1920, 1080}, {2560, 1440}, {2560, 1440}};
  Mode desk = {2560, 1440};
  Mode sel = game_select(game_record(probe_answer(1, desk, real)), Mode{2560, 1440}, desk);
  check("level 1, saved 2560x1440: game keeps 2560 x 1440", sel.w == 2560 && sel.h == 1440, sel.w);
  sel = game_select(game_record(probe_answer(2, desk, real)), Mode{2560, 1440}, desk);
  check("level 2, saved 2560x1440: game takes 3840 x 2160", sel.w == 3840 && sel.h == 2160, sel.w);
  sel = game_select(game_record(probe_answer(2, desk, real)), Mode{3840, 2160}, desk);
  check("level 2 again (game saved 3840x2160): still 3840 x 2160", sel.w == 3840 && sel.h == 2160, sel.w);
  sel = game_select(game_record(probe_answer(4, desk, real)), Mode{3840, 2160}, desk);
  check("level 4 after level 2: game takes 2880 x 2880", sel.w == 2880 && sel.h == 2880, sel.w);
  sel = game_select(game_record(probe_answer(1, desk, real)), Mode{2880, 2880}, desk);
  check("back to level 1 (saved 2880x2880 not in the real list): desktop size", sel.w == 2560 && sel.h == 1440, sel.w);
  sel = game_select(game_record(real), Mode{3840, 2160}, desk);
  check("probe removed (saved 3840x2160 not in the real list): desktop size", sel.w == 2560 && sel.h == 1440, sel.w);
  check("no real modes: the probe adds nothing", probe_answer(2, desk, {}).empty());
  { // the record keeps the last 32 distinct sizes
    std::vector<Mode> many;
    for (uint32_t i = 0; i < 50; ++i) many.push_back(Mode{640 + 16 * i, 480 + 9 * i});
    auto rec = game_record(many);
    check("model: last 32 of 50 distinct sizes kept", rec.size() == 32 && rec[0].w == 640 + 16 * 18 && rec[31].w == 640 + 16 * 49, rec.size());
  }

  // ---- mouse pointer: window pixels <-> picture pixels ----
  check("pointer: same sizes = unchanged", picture::scale_coord(1234, 2560, 2560) == 1234);
  check("pointer: window corner 0 -> 0", picture::scale_coord(0, 2560, 3840) == 0);
  check("pointer: window middle -> picture middle", picture::scale_coord(1280, 2560, 3840) == 1920 && picture::scale_coord(720, 1440, 2880) == 1440);
  check("pointer: last window pixel stays inside the picture", picture::scale_coord(2559, 2560, 3840) == 3838 && picture::scale_coord(1439, 1440, 2880) == 2878);
  check("pointer: outside the window (captured mouse) stays outside", picture::scale_coord(-10, 2560, 3840) == -15 && picture::scale_coord(2600, 2560, 3840) == 3900);
  check("pointer: bad sizes = unchanged", picture::scale_coord(55, 0, 3840) == 55 && picture::scale_coord(55, 2560, 0) == 55);
  { // the game's own pointer move (picture middle) lands on the window middle, and reading it back gives the same picture point
    int wx = picture::scale_coord_back(3840 / 2, 3840, 2560), wy = picture::scale_coord_back(2880 / 2, 2880, 1440);
    check("pointer move: picture middle -> window middle", wx == 1280 && wy == 720, wx);
    check("pointer move: round trip", picture::scale_coord(wx, 2560, 3840) == 1920 && picture::scale_coord(wy, 1440, 2880) == 1440);
    bool inside = true, mono = true; int prev = -1;
    for (int x = 0; x < 2560; ++x) { int p = picture::scale_coord(x, 2560, 3840); if (p < 0 || p >= 3840) inside = false; if (p <= prev) mono = false; prev = p; }
    check("pointer: every window pixel maps inside the picture, in order", inside && mono);
    // window -> picture -> window is exact for every pixel and every level (a slider the game drags by
    // moving the pointer to where it just was must not creep)
    int bad = 0;
    const int pairs[5][2] = {{2560, 3840}, {1440, 2160}, {1440, 2880}, {2560, 2880}, {1920, 3840}};
    for (auto& pr : pairs)
      for (int x = 0; x < pr[0]; ++x)
        if (picture::scale_coord_back(picture::scale_coord(x, pr[0], pr[1]), pr[1], pr[0]) != x) ++bad;
    check("pointer: window -> picture -> window is exact", bad == 0, bad);
    check("pointer back: outside stays outside, bad sizes unchanged", picture::scale_coord_back(-15, 3840, 2560) == -10 && picture::scale_coord_back(7, 0, 5) == 7);
    // without the correction the pointer reached only this part of the picture:
    check("without correction: 67 % of level 2, 50 % of the lines of level 3", fabs(2560.0 / 3840 - 0.667) < 0.001 && 1440.0 / 2880 == 0.5);
  }

  // ---- 0.45 flat view: the 4:3 picture drawn in its own shape inside a 16:9 window ----
  {
    picture::View v;
    check("flat view: 3840x2880 in 2560x1440 -> 1920 x 1440 centred (bars of 320 each side)",
          picture::fit_view(3840, 2880, 2560, 1440, &v) == 1 && v.active && fabs(v.w - 1920) < 1e-9 && fabs(v.h - 1440) < 1e-9 && fabs(v.x - 320) < 1e-9 && fabs(v.y) < 1e-9);
    check("flat view: same shape (3840x2160 in 2560x1440) = nothing to do", picture::fit_view(3840, 2160, 2560, 1440, &v) == 0 && !v.active && v.w == 2560 && v.h == 1440);
    check("flat view: 1 % shape difference = nothing to do", picture::fit_view(2560, 1440, 2570, 1440, &v) == 0);
    check("flat view: wider picture in a narrower window -> bars above and below",
          picture::fit_view(2560, 1440, 1920, 1440, &v) == 1 && fabs(v.w - 1920) < 1e-9 && fabs(v.h - 1080) < 1e-9 && fabs(v.y - 180) < 1e-9 && fabs(v.x) < 1e-9);
    check("flat view: bad sizes = nothing to do", picture::fit_view(0, 2880, 2560, 1440, &v) == 0 && picture::fit_view(3840, 2880, 10, 1440, &v) == 0);
    picture::fit_view(3840, 2880, 2560, 1440, &v);
    check("flat view pointer: window middle -> picture middle", picture::view_to_picture(1280, v.x, v.w, 3840) == 1920 && picture::view_to_picture(720, v.y, v.h, 2880) == 1440);
    check("flat view pointer: left bar -> picture's left edge, right bar -> right edge",
          picture::view_to_picture(100, v.x, v.w, 3840) == 0 && picture::view_to_picture(2500, v.x, v.w, 3840) == 3839);
    check("flat view pointer: picture edges", picture::view_to_picture(320, v.x, v.w, 3840) == 0 && picture::view_to_picture(2239, v.x, v.w, 3840) >= 3838 && picture::view_to_picture(2239, v.x, v.w, 3840) <= 3839);
    check("flat view pointer: picture -> window", picture::picture_to_view(1920, v.x, v.w, 3840) == 1280 && picture::picture_to_view(0, v.x, v.w, 3840) == 320 &&
          picture::picture_to_view(1440, v.y, v.h, 2880) == 720);
    bool inside = true, mono = true; int prev = -1, bad = 0;
    for (int x = 320; x < 2240; ++x) {
      int pp = picture::view_to_picture(x, v.x, v.w, 3840);
      if (pp < 0 || pp >= 3840) inside = false;
      if (pp < prev) mono = false;
      prev = pp;
      if (picture::picture_to_view(pp, v.x, v.w, 3840) != x && picture::picture_to_view(pp, v.x, v.w, 3840) != x + 1) ++bad;   // exact or one pixel (the picture is bigger)
    }
    check("flat view pointer: every pixel inside the picture maps inside, in order", inside && mono);
    check("flat view pointer: window -> picture -> window is within a pixel", bad == 0, bad);
    check("flat view pointer: bad lengths unchanged", picture::view_to_picture(77, 0, 0, 3840) == 77 && picture::picture_to_view(77, 0, 0, 3840) == 77);
  }

  // ---- flat screen size ----
  check("16:9 picture: 3 m wide", fabs(picture::flat_screen_width(3840, 2160, 3.0f, 1.75f) - 3.0f) < 1e-6);
  check("square picture: 1.75 m wide and tall", fabs(picture::flat_screen_width(2880, 2880, 3.0f, 1.75f) - 1.75f) < 1e-6);
  check("4:3 picture (level 3): 2.33 m wide, 1.75 m tall", fabs(picture::flat_screen_width(3840, 2880, 3.0f, 1.75f) - 1.75f * 4 / 3) < 1e-5);
  check("no texture yet: default width", picture::flat_screen_width(0, 0, 3.0f, 1.75f) == 3.0f);

  // ---- world size ----
  check("world 100 % = real eye distance", stereo::world_factor(100) == 1.0);
  check("world 125 % = eyes 0.8 as far apart", fabs(stereo::world_factor(125) - 0.8) < 1e-12);
  check("0.25 behaved like world 91 %", fabs(stereo::world_factor(91) - 1.10) < 0.002, stereo::world_factor(91));
  check("limits 60..160", stereo::world_factor(10) == stereo::world_factor(60) && stereo::world_factor(900) == stereo::world_factor(160));
  { // eye separation in game feet at 100 %: 70.7 mm -> 0.232 ft; left/right symmetric
    double l = -0.03534 * stereo::kFeetPerMetre * stereo::world_factor(100), r = 0.03534 * stereo::kFeetPerMetre * stereo::world_factor(100);
    check("eye distance 0.232 ft at 100 %", fabs((r - l) - 0.2319) < 0.0005, r - l);
    check("0.25's logged eyeXFeet 0.1275 = 110 % of it", fabs(0.03534 * stereo::kFeetPerMetre * 1.10 - 0.1275) < 0.0002);
  }
  // ---- same moment: frame-time limit for the second eye ----
  check("same moment: normal speed = 8 ticks", stereo::same_moment_limit(1.0f, 8, 512) == 8 && stereo::same_moment_limit(0.97f, 8, 512) == 8);
  { bool ok = true;  // after the game's rounding at least 8 ticks are left, for every slow-motion scale that is accepted
    for (float sc = 0.02f; sc < 0.95f; sc += 0.003f) {
      int lim = stereo::same_moment_limit(sc, 8, 512);
      if (lim == 0) { if (8.0f / sc + 1.0f <= 512.0f) ok = false; continue; }
      int left = (int)((float)lim * sc);
      if (left < 7 || left > 9 || lim > 512) ok = false;
    }
    check("same moment: slow motion keeps 7..9 ticks after scaling", ok); }
  check("same moment: extreme slow motion / pause / bad values = feature skipped", stereo::same_moment_limit(0.01f, 8, 512) == 0 &&
        stereo::same_moment_limit(0.0f, 8, 512) == 0 && stereo::same_moment_limit(-1.0f, 8, 512) == 0 &&
        stereo::same_moment_limit(NAN, 8, 512) == 0 && stereo::same_moment_limit(INFINITY, 8, 512) == 0);
  check("same moment: fast forward = 8 ticks", stereo::same_moment_limit(2.0f, 8, 512) == 8);
  // ---- same moment: model of the game's main loop (layout.h) with the probe's two hooks ----
  // Loop iteration: simulate (step from the previous tick) -> wait for the render thread (previous frame is
  // presented; after a finished pair it waits for the headset) -> prepare the eye -> dispatch -> tick.
  struct Run { double gapTicks, worstGapTicks, speed; int shortTicks, skipped, doubleShort; long maxStep; int keys, keysSeen, keysLost, kept; };
  // keyEvery: a key release / mouse-wheel notch every keyEvery timer units (0 = none); keyRule: 1 = the probe
  // keeps the simulation while a key is marked (0.27 after review), 0 = leaves it out regardless (first 0.27 draft).
  // The game's input poll (after the camera prepare) releases marked keys, then pumps new ones; only a simulation
  // that runs while a key is marked sees it.
  auto run = [](int featureOn, int skipSimOn, float timeScale, int failEvery, int drainOn = 1, unsigned keyEvery = 0, int keyRule = 1) {
    const unsigned unitsPerSecond = 1179648, pairUnits = unitsPerSecond / 72;
    unsigned now = 5000000, last = now, nextVsync = now + pairUnits;
    long world = 0, stepTicks = 546, maxTicks = 4096, realStartWorld = 0;
    unsigned realStart = now;
    int phase = 0, skipSim = 0, prevShort = 0, pendingEye = 0;   // pendingEye: role of the frame handed to the render thread
    long worldAtFirst = 0; double gapSum = 0, worst = 0; int pairs = 0, shortTicks = 0, skipped = 0, doubleShort = 0, iter = 0;
    long maxStep = 0;
    int keys = 0, keysSeen = 0, keysLost = 0, kept = 0, marked = 0, shortLimitUsed = 0;
    unsigned lastPoll = now, nextKey = keyEvery ? now + keyEvery / 3 : 0;
    auto present = [&]() {   // the render thread finishes the frame it was given (the probe's Present hook runs)
      if (pendingEye == 1) { phase = 1; }                  // first eye shown: the next frame completes the pair
      else if (pendingEye == 2) { phase = 0; if (now < nextVsync) now = nextVsync; nextVsync += pairUnits; }  // pair: headset wait
      else if (pendingEye == 0) { phase = 0; }
      pendingEye = -1;                                     // nothing outstanding
    };
    for (; iter < 4000; ++iter) {
      // simulate (the probe's hook: left out for the second eye; after a second eye it first waits for the render thread)
      int simulate = 1;
      if (skipSim) {
        skipSim = 0;
        if (keyRule && marked > 0) { ++kept; last += (unsigned)shortLimitUsed * 18; }   // kept: its short step is real time
        else { ++skipped; simulate = 0; }
      }
      if (simulate) {
        if (featureOn && drainOn && pendingEye == 2) present();
        world += stepTicks; if (stepTicks > maxStep) maxStep = stepTicks;
        keysSeen += marked; marked = 0;                    // the game update reads the keys
        now += 1500;                                       // simulation takes about 1.3 ms
      }
      // wait for the render thread: the previous frame is presented now (unless that already happened)
      if (pendingEye != -1) present();
      // prepare
      int role = phase == 1 ? 2 : 1;
      int published = !(failEvery && iter % failEvery == failEvery - 1);   // now and then a frame is not an eye picture
      if (published) {
        if (role == 1) worldAtFirst = world;
        else { double g = (double)(world - worldAtFirst); gapSum += g; if (g > worst) worst = g; ++pairs; }
      }
      pendingEye = published ? role : 0;
      now += 2200;                                         // prepare + dispatch, about 1.9 ms
      // input poll: marked keys are released (lost if no simulation saw them), then new messages are pumped
      keysLost += marked; marked = 0;
      while (keyEvery && nextKey <= now) { ++keys; ++marked; nextKey += keyEvery; }
      lastPoll = now;
      // tick (the probe's hook)
      int tickRole = published ? role : 0;
      int limit = stereo::short_tick_limit(tickRole, featureOn, prevShort, timeScale, 8, 512);
      int wasShort = prevShort; prevShort = 0;
      unsigned savedLast = last;
      long ticks = (long)((now - last) / 18);
      long cap = limit > 0 ? limit : maxTicks;
      if (ticks > cap) ticks = cap;
      last = now;
      stepTicks = (long)((float)ticks * timeScale);        // the game's time scale, rounded down
      if (limit > 0) {
        skipSim = skipSimOn;
        shortLimitUsed = limit;
        last = savedLast + (skipSim ? 0u : (unsigned)limit * 18);   // a left-out simulation uses no time
        prevShort = 1; ++shortTicks;
        if (wasShort) ++doubleShort;
      }
    }
    Run r;
    r.gapTicks = pairs ? gapSum / pairs : 0; r.worstGapTicks = worst;
    r.speed = (double)(world - realStartWorld) / ((double)(now - realStart) / 18.0 * timeScale);
    r.shortTicks = shortTicks; r.skipped = skipped; r.doubleShort = doubleShort; r.maxStep = maxStep;
    r.keys = keys; r.keysSeen = keysSeen; r.keysLost = keysLost; r.kept = kept;
    (void)lastPoll;
    return r;
  };
  { Run off = run(0, 0, 1.0f, 0);
    check("loop model, feature off (0.24-0.26): the second eye is about 10 ms of game time after the first", off.gapTicks > 600 && off.gapTicks < 760, off.gapTicks * 1000.0 / 65536);
    check("loop model, feature off: game speed = real time", fabs(off.speed - 1.0) < 0.005, off.speed);
    Run on = run(1, 1, 1.0f, 0);
    check("loop model, same moment: both eyes of a pair show the same world state", on.worstGapTicks == 0, on.worstGapTicks);
    check("loop model, same moment: game speed = real time", fabs(on.speed - 1.0) < 0.005, on.speed);
    check("loop model, same moment: one short tick and one left-out simulation per pair", on.shortTicks > 1900 && abs(on.shortTicks - on.skipped) <= 1 && on.doubleShort == 0, on.shortTicks);
    check("loop model, same moment: the long step is one headset frame (910 ticks), far below the game's limit", on.maxStep > 880 && on.maxStep < 960, on.maxStep);
    Run noDrain = run(1, 1, 1.0f, 0, 0);
    check("loop model, same moment without the early wait: same result for time and state", noDrain.worstGapTicks == 0 && fabs(noDrain.speed - 1.0) < 0.005, noDrain.speed);
    Run tickOnly = run(1, 0, 1.0f, 0);
    check("loop model, short tick without leaving out the simulation: eyes 8 ticks (0.12 ms) apart", tickOnly.worstGapTicks == 8, tickOnly.worstGapTicks);
    Run slow = run(1, 1, 0.25f, 0);
    check("loop model, slow motion 0.25: same world state, speed kept", slow.worstGapTicks == 0 && fabs(slow.speed - 1.0) < 0.02, slow.speed);
    Run slowTick = run(1, 0, 0.25f, 0);
    check("loop model, slow motion without leaving out the simulation: step never zero (7..9 ticks)", slowTick.worstGapTicks >= 7 && slowTick.worstGapTicks <= 9, slowTick.worstGapTicks);
    Run flaky = run(1, 1, 1.0f, 7);
    check("loop model, every 7th frame not an eye picture: no two short ticks in a row, speed kept", flaky.doubleShort == 0 && fabs(flaky.speed - 1.0) < 0.01 && flaky.maxStep <= 4096, flaky.speed);
    check("loop model, flaky: pairs that do complete still match", flaky.worstGapTicks <= 1000, flaky.worstGapTicks);
    // keys: a mouse-wheel notch every 37 ms (scrolling), and a key release every 300 ms
    Run wheelOld = run(1, 1, 1.0f, 0, 1, 43648, 0);
    check("loop model, first 0.27 draft: most wheel notches were lost", wheelOld.keysLost * 10 > wheelOld.keys * 6, (double)wheelOld.keysLost / wheelOld.keys);
    Run wheel = run(1, 1, 1.0f, 0, 1, 43648, 1);
    check("loop model, keys: no wheel notch is lost", wheel.keys > 300 && wheel.keysLost == 0 && wheel.keysSeen == wheel.keys, wheel.keysLost);
    check("loop model, keys: game speed = real time", fabs(wheel.speed - 1.0) < 0.005, wheel.speed);
    check("loop model, keys: eyes at most the short step (8 ticks = 0.12 ms) apart", wheel.worstGapTicks <= 8, wheel.worstGapTicks);
    check("loop model, keys: simulations kept only when a key was waiting", wheel.kept > 0 && wheel.kept < wheel.shortTicks && wheel.kept + wheel.skipped >= wheel.shortTicks - 1, wheel.kept);
    Run typing = run(1, 1, 1.0f, 0, 1, 353894, 1);
    check("loop model, occasional key: none lost, nearly all pairs still exactly the same moment", typing.keysLost == 0 && typing.skipped * 10 > typing.shortTicks * 9, (double)typing.skipped / typing.shortTicks);
    Run noKeys = run(1, 1, 1.0f, 0);
    check("loop model, no keys: every second-eye simulation left out", noKeys.kept == 0 && noKeys.keys == 0, noKeys.kept);
  }
  check("short tick only after a first eye, with the feature on, never twice in a row",
        stereo::short_tick_limit(1, 1, 0, 1.0f, 8, 512) == 8 && stereo::short_tick_limit(2, 1, 0, 1.0f, 8, 512) == 0 &&
        stereo::short_tick_limit(0, 1, 0, 1.0f, 8, 512) == 0 && stereo::short_tick_limit(1, 0, 0, 1.0f, 8, 512) == 0 &&
        stereo::short_tick_limit(1, 1, 1, 1.0f, 8, 512) == 0);
  // movement between the eyes at 20 ft/s: 66 mm before (10.8 ms), nothing now
  check("movement between the eyes at 20 ft/s was 66 mm (the eyes are 71 mm apart)", fabs(20.0 * 0.0108 * 304.8 - 65.8) < 0.5);
  // ---- 1.7.117 explicit sizes by lines (laptops) ----
  {
    uint32_t w = 0, h = 0;
    check("lines 1080 on a 16:9 desktop = 1920x1080", picture::lines_size(1080, 2560, 1440, &w, &h) && w == 1920 && h == 1080, w);
    check("lines 1440 on 16:9 = 2560x1440", picture::lines_size(1440, 1920, 1080, &w, &h) && w == 2560 && h == 1440, w);
    check("lines 2160 equals level 2", picture::lines_size(2160, 3840, 2160, &w, &h) && w == 3840 && h == 2160, w);
    uint32_t w2 = 0, h2 = 0;
    check("lines 2880 equals level 3", picture::lines_size(2880, 1920, 1080, &w, &h) && picture::level_size(3, 1920, 1080, &w2, &h2) && w == w2 && h == h2, w);
    check("ultrawide 3440x1440 at 1080 lines is 2580 wide", picture::lines_size(1080, 3440, 1440, &w, &h) && w == 2580, w);
    check("too few / too many lines refused", !picture::lines_size(600, 1920, 1080, &w, &h) && !picture::lines_size(2882, 1920, 1080, &w, &h), 0);
    check("ladder up", picture::ladder_step(1080, 1) == 1440 && picture::ladder_step(1440, 1) == 1800 && picture::ladder_step(1800, 1) == 2160 && picture::ladder_step(2160, 1) == 2880 && picture::ladder_step(2880, 1) == 2880, 0);
    check("ladder down", picture::ladder_step(2880, -1) == 2160 && picture::ladder_step(1440, -1) == 1080 && picture::ladder_step(1080, -1) == 1080 && picture::ladder_step(900, -1) == 900, 0);
    { long pl = -1, lv = -1;
      picture::ladder_apply(1080, &pl, &lv); check("apply 1080: lines 1080, level 2", pl == 1080 && lv == 2, pl);
      picture::ladder_apply(1440, &pl, &lv); check("apply 1440: lines 1440, level 2", pl == 1440 && lv == 2, pl);
      picture::ladder_apply(2160, &pl, &lv); check("apply 2160: old level 2", pl == 0 && lv == 2, pl);
      picture::ladder_apply(2880, &pl, &lv); check("apply 2880: old level 3", pl == 0 && lv == 3, pl); }
    check("ladder from a monitor size between steps", picture::ladder_step(1600, 1) == 1800 && picture::ladder_step(1600, -1) == 1440, 0);
  }
  // ---- names ----
  check("names exist", picture::level_name(1)[0] && picture::level_name(2)[0] && picture::level_name(3)[0] && picture::level_name(4)[0]);
  printf(fails ? "%d FAILED\n" : "ALL PASS\n", fails);
  return fails != 0;
}
