// 0.94: the game's PKE turned onto the controller (pkemath.h)
#include <stdio.h>
#include <math.h>
#include "pkemath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

// a level pose that points along dir (heading / pitch), local axes: 0 = right, 1 = up, 2 = forward (the game's row convention: forward = row 2)
static void level_pose(double headingDeg, double pitchDeg, double u[3][3]) {
  const double h = headingDeg * M_PI / 180.0, p = pitchDeg * M_PI / 180.0;
  double f[3] = {cos(p) * sin(h), sin(p), cos(p) * cos(h)};
  double up0[3] = {0, 1, 0}, r[3];
  pke::cross(up0, f, r); pke::unit(r);
  double up[3]; pke::cross(f, r, up); pke::unit(up);
  for (int i = 0; i < 3; ++i) { u[0][i] = r[i]; u[1][i] = up[i]; u[2][i] = f[i]; }
}
static double det3(double u[3][3]) { double c[3]; pke::cross(u[0], u[1], c); return pke::dot(c, u[2]); }
static void check_rigid(double u[3][3], const char* what) {
  const double e = 1e-9;
  for (int j = 0; j < 3; ++j) if (fabs(pke::len(u[j]) - 1.0) > e) { printf("FAIL %s: axis %d length %.12f\n", what, j, pke::len(u[j])); ++fails; }
  for (int j = 0; j < 3; ++j) for (int k = j + 1; k < 3; ++k) if (fabs(pke::dot(u[j], u[k])) > e) { printf("FAIL %s: axes %d,%d not perpendicular\n", what, j, k); ++fails; }
}

int main() {
  // 1. the game's pose already points along the aim: nothing to swing, the axis is found, the front agrees
  {
    double u[3][3]; level_pose(30, 10, u);
    double dir[3] = {u[2][0], u[2][1], u[2][2]};
    pke::Axis ax = {0, 1, 0}; pke::Info info; double up[3];
    CHECK(pke::orient(u, dir, nullptr, 0.0, 0.0, &ax, &info, up));
    CHECK(ax.have && ax.axis == 2 && ax.sign == 1);
    CHECK(info.swingDeg < 1e-3);
    CHECK(pke::dot(u[2], dir) > 0.999999);
    check_rigid(u, "aligned");
    CHECK(det3(u) > 0.999999);
  }
  // 2. the controller points elsewhere: the front follows it exactly, the pose stays rigid and right-handed
  for (int hd = -170; hd <= 170; hd += 40) for (int pt = -80; pt <= 80; pt += 40) {
    double u[3][3]; level_pose(15, -5, u);
    pke::Axis ax = {0, 1, 0}; pke::Info info;
    // first frame fixes the axis from the game's own aim
    double d0[3] = {u[2][0], u[2][1], u[2][2]};
    pke::orient(u, d0, nullptr, 0.0, 0.0, &ax, &info, nullptr);
    double dir[3]; { double w[3][3]; level_pose(hd, pt, w); for (int i = 0; i < 3; ++i) dir[i] = w[2][i]; }
    double uu[3][3]; level_pose(15, -5, uu);
    CHECK(pke::orient(uu, dir, nullptr, 0.0, 0.0, &ax, &info, nullptr));
    CHECK(pke::dot(uu[2], dir) > 0.999999);
    check_rigid(uu, "swing");
    CHECK(det3(uu) > 0.999999);
  }
  // 3. roll: a controller twisted 40 degrees about the barrel turns the PKE the same way; no controller up = no roll
  {
    double u[3][3]; level_pose(0, 0, u);
    pke::Axis ax = {0, 1, 0}; pke::Info info;
    double dir[3] = {0, 0, 1}, up[3];
    double wup[3] = {sin(40 * M_PI / 180.0), cos(40 * M_PI / 180.0), 0};   // up tipped toward +x about the barrel
    CHECK(pke::orient(u, dir, wup, 0.0, 0.0, &ax, &info, up));
    CHECK(info.rolled);
    CHECK(fabs(fabs(info.rollDeg) - 40.0) < 1e-6);
    CHECK(pke::dot(u[1], wup) > 0.99999999);   // the pose's up IS the controller's up
    CHECK(pke::dot(up, wup) > 0.99999999);
    check_rigid(u, "roll"); CHECK(det3(u) > 0.999999);
    double u2[3][3]; level_pose(0, 0, u2); pke::Axis ax2 = {0, 1, 0};
    pke::orient(u2, dir, nullptr, 0.0, 0.0, &ax2, &info, nullptr);
    CHECK(!info.rolled && fabs(u2[1][1] - 1.0) < 1e-9);
  }
  // 4. pointing straight up: no roll reference, nothing blows up
  {
    double u[3][3]; level_pose(0, 0, u);
    pke::Axis ax = {2, 1, 1}; pke::Info info;
    double dir[3] = {0, 1, 0}, wup[3] = {1, 0, 0}, up[3];
    CHECK(pke::orient(u, dir, wup, 0.0, 0.0, &ax, &info, up));
    CHECK(pke::dot(u[2], dir) > 0.999999);
    check_rigid(u, "straight up");
    double d2[3] = {0, -1, 0};
    double v[3][3]; level_pose(0, 0, v);
    CHECK(pke::orient(v, d2, wup, 0.0, 0.0, &ax, &info, up));
    CHECK(pke::dot(v[2], d2) > 0.999999);
    check_rigid(v, "straight down");
  }
  // 5. the opposite direction (180 degrees swing) works
  {
    double u[3][3]; level_pose(0, 0, u);
    pke::Axis ax = {2, 1, 1}; pke::Info info;
    double dir[3] = {0, 0, -1};
    CHECK(pke::orient(u, dir, nullptr, 0.0, 0.0, &ax, &info, nullptr));
    CHECK(pke::dot(u[2], dir) > 0.999999);
    check_rigid(u, "180"); CHECK(det3(u) > 0.999999);
  }
  // 6. other model conventions: the pointing axis is found whichever local axis (and sign) it is
  for (int axis = 0; axis < 3; ++axis) for (int sign = -1; sign <= 1; sign += 2) {
    double base[3][3]; level_pose(50, 20, base);
    double u[3][3];
    // put the front on `axis` (sign), keep a right-handed frame
    for (int i = 0; i < 3; ++i) u[axis][i] = base[2][i] * sign;
    int a1 = (axis + 1) % 3, a2 = (axis + 2) % 3;
    for (int i = 0; i < 3; ++i) { u[a1][i] = base[0][i]; u[a2][i] = base[1][i]; }
    if (det3(u) < 0) for (int i = 0; i < 3; ++i) u[a2][i] = -u[a2][i];
    double dir[3] = {base[2][0], base[2][1], base[2][2]};
    pke::Axis ax = {0, 1, 0}; pke::Info info;
    CHECK(pke::orient(u, dir, nullptr, 0.0, 0.0, &ax, &info, nullptr));
    CHECK(ax.axis == axis && ax.sign == sign);
    CHECK(pke::dot(u[axis], dir) * sign > 0.999999);
  }
  // 7. tilt: the front goes DOWN by the angle, about the hand
  {
    double u[3][3]; level_pose(0, 0, u);
    pke::Axis ax = {2, 1, 1}; pke::Info info;
    double dir[3] = {0, 0, 1};
    CHECK(pke::orient(u, dir, nullptr, 0.0, 20.0 * M_PI / 180.0, &ax, &info, nullptr));
    CHECK(fabs(u[2][1] + sin(20.0 * M_PI / 180.0)) < 1e-9);   // y of the front = -sin(20)
    check_rigid(u, "tilt");
  }
  // 8. not found from a pose that does not point along the aim (the front stays local +Z until a clear reading); found later; then kept even when the pose is far off
  {
    double u[3][3]; level_pose(0, 0, u);
    pke::Axis ax = {0, 1, 0}; pke::Info info;
    double dir[3] = {0.70710678118654752, 0, 0.70710678118654752};   // 45 degrees off from the pose's front (and from its right axis)
    pke::orient(u, dir, nullptr, 0.0, 0.0, &ax, &info, nullptr);
    CHECK(!ax.have && !info.found);
    CHECK(pke::dot(u[2], dir) > 0.999999);   // local +Z was used
    double w[3][3]; level_pose(0, 0, w); double d2[3] = {0, 0, 1};
    pke::orient(w, d2, nullptr, 0.0, 0.0, &ax, &info, nullptr);
    CHECK(ax.have && info.found && ax.axis == 2);
    double v[3][3]; level_pose(0, 0, v); double d3[3] = {-1, 0, 0};
    pke::orient(v, d3, nullptr, 0.0, 0.0, &ax, &info, nullptr);
    CHECK(!info.found && ax.axis == 2 && pke::dot(v[2], d3) > 0.999999);
  }

  // ---- 0.97 look-at (front = local +Y, up = local +Z like the real model; its tip attachment is (0, 1.07, 0.03) in the model's axes) ----
  // a level pose with the front on local axis 1, the up on local axis 2, the side on local axis 0 (right-handed or mirrored: both must keep their handedness)
  auto model_pose = [&](double hd, double pt, int mirrored, double u[3][3]) {
    double b[3][3]; level_pose(hd, pt, b);
    for (int i = 0; i < 3; ++i) { u[1][i] = b[2][i]; u[2][i] = b[1][i]; u[0][i] = b[0][i] * (mirrored ? -1 : 1); }
  };
  for (int mirrored = 0; mirrored <= 1; ++mirrored) for (int hd = -170; hd <= 170; hd += 34) for (int pt = -80; pt <= 80; pt += 40) {
    double u[3][3]; model_pose(15, -5, mirrored, u);
    double u0[3][3]; for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) u0[j][i] = u[j][i];
    const double det0 = det3(u);
    double dir[3]; { double w[3][3]; level_pose(hd, pt, w); for (int i = 0; i < 3; ++i) dir[i] = w[2][i]; }
    // the controller's up: a roll of 25 degrees about its barrel
    double lvl[3][3]; level_pose(hd, pt, lvl);
    double wup[3]; { const double a = 25.0 * M_PI / 180.0; for (int i = 0; i < 3; ++i) wup[i] = lvl[1][i] * cos(a) + lvl[0][i] * sin(a); }
    pke::Frame fr = {1, 1, -1, 1, 0, {0, 0, 0}, 0}; pke::LookInfo li; double upo[3];
    CHECK(pke::look(u, dir, wup, 0.0, 0.0, &fr, &li, upo));
    CHECK(fr.front == 1 && fr.up == 2 && fr.usign == 1 && fr.have && li.upFound);   // the up axis was found from the level hold
    CHECK(pke::dot(u[1], dir) > 0.9999999);                                         // the front points along the controller
    CHECK(pke::dot(u[2], upo) > 0.9999999 && pke::dot(upo, wup) > 0.9999999);   // the up is the controller's up (across the barrel)
    check_rigid(u, "look");
    CHECK(det3(u) * det0 > 0.0);                                                      // handedness kept
    double R[9]; pke::rigid(u0, u, R);
    for (int j = 0; j < 3; ++j) {   // R takes every old axis onto the new one
      double v[3] = {0, 0, 0};
      for (int i = 0; i < 3; ++i) v[i] = R[i * 3] * u0[j][0] + R[i * 3 + 1] * u0[j][1] + R[i * 3 + 2] * u0[j][2];
      CHECK(fabs(v[0] - u[j][0]) < 1e-9 && fabs(v[1] - u[j][1]) < 1e-9 && fabs(v[2] - u[j][2]) < 1e-9);
    }
  }
  // look: no controller up = the pose stays level; the front of a pose that already points there does not move
  {
    double u[3][3]; model_pose(40, 20, 0, u);
    double dir[3] = {u[1][0], u[1][1], u[1][2]};
    pke::Frame fr = {1, 1, -1, 1, 0, {0, 0, 0}, 0}; pke::LookInfo li;
    CHECK(pke::look(u, dir, nullptr, 0.0, 0.0, &fr, &li, nullptr));
    CHECK(li.swingDeg < 1e-3);
    double b[3][3]; model_pose(40, 20, 0, b);
    for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) CHECK(fabs(u[j][i] - b[j][i]) < 1e-9);
  }
  // look: straight up / down with a controller up along the barrel (degenerate), then without: no NaN, the frame stays rigid
  {
    double dirs[2][3] = {{0, 1, 0}, {0, -1, 0}};
    for (int k = 0; k < 2; ++k) {
      double u[3][3]; model_pose(0, 0, 0, u);
      const double det0 = det3(u);
      pke::Frame fr = {1, 1, -1, 1, 0, {0, 0, 0}, 0}; pke::LookInfo li;
      double wup[3] = {0, 1, 0};
      CHECK(pke::look(u, dirs[k], wup, 0.0, 0.0, &fr, &li, nullptr));
      CHECK(pke::dot(u[1], dirs[k]) > 0.9999999);
      check_rigid(u, "look vertical");
      CHECK(det3(u) * det0 > 0.0);
    }
  }
  // look: tilt tips the front down, roll offset turns the up about the barrel, the 1.07 ft tip attachment ends up along the controller direction
  {
    double u[3][3]; model_pose(0, 0, 0, u);
    pke::Frame fr = {1, 1, -1, 1, 0, {0, 0, 0}, 0}; pke::LookInfo li;
    double dir[3] = {0, 0, 1};
    CHECK(pke::look(u, dir, nullptr, 0.0, 20.0 * M_PI / 180.0, &fr, &li, nullptr));
    CHECK(fabs(u[1][1] + sin(20.0 * M_PI / 180.0)) < 1e-9);
    check_rigid(u, "look tilt");
    double u2[3][3]; model_pose(0, 0, 0, u2); pke::Frame f2 = {1, 1, -1, 1, 0, {0, 0, 0}, 0};
    CHECK(pke::look(u2, dir, nullptr, 30.0 * M_PI / 180.0, 0.0, &f2, &li, nullptr));
    const double worldUp[3] = {0, 1, 0};
    CHECK(fabs(fabs(pke::dot(u2[2], worldUp)) - cos(30.0 * M_PI / 180.0)) < 1e-9);
    // the tip: local (0, 1.07, 0.03) -> world = sum_j local[j] * u[j]; 1.07 along the controller direction (the 0.03 is across)
    double tip[3] = {0, 0, 0}; const double loc[3] = {0.0, 1.07, 0.03};
    for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) tip[i] += loc[j] * u[j][i];
    CHECK(fabs(pke::dot(tip, dir) - (1.07 * cos(20.0 * M_PI / 180.0) + 0.03 * sin(20.0 * M_PI / 180.0))) < 1e-9);
  }
  // look: the frame is found even when the first reading is tilted (kept tentative until a clear level reading)
  {
    double u[3][3]; model_pose(0, 80, 0, u);   // pitched 80 degrees: the up axis points mostly forward, the reading is not clear
    pke::Frame fr = {1, 1, -1, 1, 0, {0, 0, 0}, 0}; pke::LookInfo li;
    double dir[3] = {0, 0, 1};
    CHECK(pke::look(u, dir, nullptr, 0.0, 0.0, &fr, &li, nullptr));
    CHECK(fr.up != fr.front);
    check_rigid(u, "look tentative");
  }
  // 0.98 the held, shared, time-eased slide
  {
    pke::ShiftState st; pke::shift_reset(&st);
    double out[3];
    const double f[3] = {0.40, 0.0, 0.0};
    pke::shift_step(&st, f, 1.0, 0.5, 0.5, 0.06, out);                       // first value: taken at once, at the share
    CHECK(fabs(out[0] - 0.20) < 1e-12 && out[1] == 0.0);
    pke::shift_step(&st, f, 1.0, 0.5, 0.5, 0.06, out); CHECK(fabs(out[0] - 0.20) < 1e-12);   // same instant: same answer
    pke::shift_step(&st, nullptr, 1.05, 0.5, 0.5, 0.06, out); CHECK(fabs(out[0] - 0.20) < 1e-9);   // the value is missing for 50 ms: the last good one is held
    pke::shift_step(&st, nullptr, 1.45, 0.5, 0.5, 0.06, out); CHECK(fabs(out[0] - 0.20) < 1e-3);   // still held at 0.45 s
    for (int i = 0; i < 40; ++i) pke::shift_step(&st, nullptr, 1.5 + 0.02 * i, 0.5, 0.5, 0.06, out);   // 0.5 s .. 1.28 s after the last good one
    CHECK(out[0] < 0.01);                                                    // faded out: the meter sits on the controller's grip point
    // a jump in the value does not jump the meter: it is eased with the time constant
    pke::ShiftState s2; pke::shift_reset(&s2);
    const double a[3] = {0.0, 0.0, 0.0}, b[3] = {0.50, 0.0, 0.0};
    pke::shift_step(&s2, a, 0.0, 1.0, 0.5, 0.06, out);
    pke::shift_step(&s2, b, 0.01, 1.0, 0.5, 0.06, out);
    CHECK(out[0] > 0.0 && out[0] < 0.10);                                    // one 10 ms step moves less than a fifth of the way
    for (int i = 0; i < 60; ++i) pke::shift_step(&s2, b, 0.02 + 0.01 * i, 1.0, 0.5, 0.06, out);
    CHECK(fabs(out[0] - 0.50) < 0.01);
    // share 0 = exactly the controller's point; a share above 1 is capped at 1; a time that goes backwards or a long gap does not blow up
    pke::ShiftState s3; pke::shift_reset(&s3);
    pke::shift_step(&s3, b, 5.0, 0.0, 0.5, 0.06, out); CHECK(out[0] == 0.0 && out[1] == 0.0 && out[2] == 0.0);
    pke::shift_step(&s3, b, 5.1, 3.0, 0.5, 0.06, out); CHECK(out[0] <= 0.50 + 1e-12);
    pke::shift_step(&s3, b, 4.0, 1.0, 0.5, 0.06, out); CHECK(out[0] >= 0.0 && out[0] <= 0.50 + 1e-12);
    pke::shift_step(&s3, b, 400.0, 1.0, 0.5, 0.06, out); CHECK(out[0] <= 0.50 + 1e-12);
    // a new hold starts from nothing after a reset
    pke::shift_reset(&s3); pke::shift_step(&s3, nullptr, 1.0, 1.0, 0.5, 0.06, out); CHECK(out[0] == 0.0);
  }
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
