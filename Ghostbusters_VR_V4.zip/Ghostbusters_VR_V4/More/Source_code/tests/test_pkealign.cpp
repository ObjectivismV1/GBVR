#include <initializer_list>
// 1.7.104 PKE alignment math (pkealignmath.h): the meter's long side is turned into the controller's centre plane, its pitch and roll are kept,
// the sideways offset of its centre is reported. No Windows, no game.
#include <stdio.h>
#include <math.h>
#include "pkealignmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
#define NEAR(a, b, e) do { if (!(fabs((a) - (b)) <= (e))) { printf("FAIL line %d: %s = %.5f, wanted %.5f +- %g\n", __LINE__, #a, (double)(a), (double)(b), (double)(e)); ++fails; } } while (0)

static const double kD = 3.14159265358979323846 / 180.0;
// rotation about an axis (unit) by an angle, row-major, v' = R v
static void rot(const double* ax, double deg, double* R) { weight::axis_angle(ax, deg * kD, R); }
static void mul(const double* A, const double* B, double* C) { for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) C[r * 3 + c] = A[r * 3] * B[c] + A[r * 3 + 1] * B[3 + c] + A[r * 3 + 2] * B[6 + c]; }
static double det(const double* M) { return M[0] * (M[4] * M[8] - M[5] * M[7]) - M[1] * (M[3] * M[8] - M[5] * M[6]) + M[2] * (M[3] * M[7] - M[4] * M[6]); }
static void check_rotation(const double* K) {
  double KT[9]; for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) KT[r * 3 + c] = K[c * 3 + r];
  double I[9]; mul(K, KT, I);
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) NEAR(I[r * 3 + c], r == c ? 1.0 : 0.0, 1e-9);
  NEAR(det(K), 1.0, 1e-9);
}

int main() {
  const double I3[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  const double X[3] = {1, 0, 0}, Y[3] = {0, 1, 0}, Z[3] = {0, 0, 1};
  double K[9];

  // 1. the long side already points along the controller's forward: nothing to do
  {
    double vh[3] = {1, 0, 0}, ph[3] = {0.1, 0.02, 0.0};
    pkealign::Result r = pkealign::solve(I3, vh, ph, 70.0, K);
    CHECK(r.ok == 1); NEAR(r.swingDeg, 0.0, 1e-9); NEAR(r.leanBeforeDeg, 0.0, 1e-6);
    for (int i = 0; i < 9; ++i) NEAR(K[i], I3[i], 1e-12);
    NEAR(r.latAfterFt, 0.0, 1e-9);
  }
  // 2. leaned 20 degrees to the left (about the up axis): turned straight, K stays a rotation
  {
    double R[9]; rot(Y, 20.0, R);                     // controller up axis
    double vh[3] = {1, 0, 0}, ph[3] = {0.0, 0.0, 0.0};
    pkealign::Result r = pkealign::solve(R, vh, ph, 70.0, K);
    CHECK(r.ok == 1); NEAR(fabs(r.leanBeforeDeg), 20.0, 1e-6); NEAR(r.leanAfterDeg, 0.0, 1e-6); NEAR(r.swingDeg, 20.0, 1e-6);
    check_rotation(K);
    double cf[3]; pkealign::mulv(K, vh, cf); NEAR(cf[2], 0.0, 1e-9); NEAR(cf[0], 1.0, 1e-9);
  }
  // 3. pitched 35 degrees up and leaned 15 degrees: the lean goes, the pitch stays
  {
    double Ry[9], Rz[9], R[9]; rot(Y, 15.0, Ry); rot(Z, 35.0, Rz); mul(Ry, Rz, R);
    double vh[3] = {1, 0, 0}, ph[3] = {0.05, 0.0, 0.03};
    pkealign::Result r = pkealign::solve(R, vh, ph, 70.0, K);
    CHECK(r.ok == 1); CHECK(fabs(r.leanBeforeDeg) > 10.0); NEAR(r.leanAfterDeg, 0.0, 1e-6);
    check_rotation(K);
    double cf[3]; pkealign::mulv(K, vh, cf); NEAR(cf[2], 0.0, 1e-9);
    NEAR(vm::datan2(cf[1], cf[0]) / kD, r.pitchDeg, 1e-6);       // the pitch in the centre plane did not change
    double c0[3]; pkealign::mulv(R, vh, c0);
    NEAR(vm::datan2(c0[1], c0[0]) / kD, r.pitchDeg, 1.5);        // and it is about what it was (the lean itself moves it a little)
  }
  // 4. the roll about the long axis is kept: another hand axis keeps its angle to the long side
  {
    double Ry[9], Rx[9], R[9]; rot(Y, -25.0, Ry); rot(X, 40.0, Rx); mul(Ry, Rx, R);   // roll 40 about the long side, lean 25
    double vh[3] = {1, 0, 0}, ph[3] = {0, 0, 0};
    pkealign::Result r = pkealign::solve(R, vh, ph, 70.0, K);
    CHECK(r.ok == 1); NEAR(r.leanAfterDeg, 0.0, 1e-6);
    double a0[3], a1[3], L0[3], L1[3];
    const double hy[3] = {0, 1, 0};
    pkealign::mulv(R, hy, a0); pkealign::mulv(K, hy, a1); pkealign::mulv(R, vh, L0); pkealign::mulv(K, vh, L1);
    NEAR(a0[0] * L0[0] + a0[1] * L0[1] + a0[2] * L0[2], a1[0] * L1[0] + a1[1] * L1[1] + a1[2] * L1[2], 1e-9);   // the angle between the two stays
  }
  // 5. the centre is reported sideways: before and after (the turn moves it too)
  {
    double R[9]; rot(Y, 30.0, R);
    double vh[3] = {1, 0, 0}, ph[3] = {0.0, 0.0, 0.2};
    pkealign::Result r = pkealign::solve(R, vh, ph, 70.0, K);
    CHECK(r.ok == 1);
    double p0[3], p1[3]; pkealign::mulv(R, ph, p0); pkealign::mulv(K, ph, p1);
    NEAR(r.latBeforeFt, p0[2], 1e-12); NEAR(r.latAfterFt, p1[2], 1e-12); NEAR(r.fwdFt, p1[0], 1e-12); NEAR(r.upFt, p1[1], 1e-12);
  }
  // 6. the long side lies across the controller (not a long axis): left alone
  {
    double vh[3] = {0, 0, 1};
    double ph[3] = {0, 0, 0};
    pkealign::Result r = pkealign::solve(I3, vh, ph, 70.0, K);
    CHECK(r.ok == 0); for (int i = 0; i < 9; ++i) NEAR(K[i], I3[i], 1e-12);
  }
  // 7. a turn bigger than the limit is not made
  {
    double R[9]; rot(Y, 60.0, R);
    double vh[3] = {1, 0, 0}, ph[3] = {0, 0, 0};
    pkealign::Result r = pkealign::solve(R, vh, ph, 40.0, K);
    CHECK(r.ok == 0); for (int i = 0; i < 9; ++i) NEAR(K[i], R[i], 1e-12);
    r = pkealign::solve(R, vh, ph, 70.0, K);
    CHECK(r.ok == 1); NEAR(r.swingDeg, 60.0, 1e-6);
  }
  // 8. bad input: not a unit axis, NaN-free output, K = K0
  {
    double vh[3] = {0, 0, 0}, ph[3] = {0, 0, 0};
    pkealign::Result r = pkealign::solve(I3, vh, ph, 70.0, K);
    CHECK(r.ok == 0); for (int i = 0; i < 9; ++i) NEAR(K[i], I3[i], 1e-12);
  }
  // 9. both signs of lean (left / right) end up in the centre plane, never doubled
  for (int sgn = -1; sgn <= 1; sgn += 2) {
    double R[9]; rot(Y, 12.0 * sgn, R);
    double vh[3] = {0.8, 0.6, 0.0}, ph[3] = {0, 0, 0};
    pkealign::Result r = pkealign::solve(R, vh, ph, 70.0, K);
    CHECK(r.ok == 1); NEAR(r.leanAfterDeg, 0.0, 1e-6); CHECK(r.swingDeg > 5.0 && r.swingDeg < 20.0);
    check_rotation(K);
  }
  // 10. 1.7.111 the pitch step: a long side 31.5 degrees above forward and 36 degrees leaned is brought to 0 above forward, centred, and the hand shift keeps the centre's forward / up
  {
    double R[9]; rot(Y, 36.6, R);
    const double pa = 31.5 * kD;
    double vh[3] = {cos(pa), sin(pa), 0.0}, ph[3] = {0.14, -0.22, -0.10};
    double K0[9]; for (int i = 0; i < 9; ++i) K0[i] = R[i];
    pkealign::Result r0 = pkealign::solve(K0, vh, ph, 70.0, K);                       // old behaviour: pitch kept
    double cf0[3] = {K[0] * vh[0] + K[1] * vh[1], K[3] * vh[0] + K[4] * vh[1], K[6] * vh[0] + K[7] * vh[1]};
    CHECK(r0.ok == 1); NEAR(r0.shiftFwdFt, 0.0, 1e-12); NEAR(r0.shiftUpFt, 0.0, 1e-12);
    pkealign::Result r = pkealign::solve_ex(K0, vh, ph, 70.0, 0.0, K);
    CHECK(r.ok == 1); NEAR(r.leanAfterDeg, 0.0, 1e-6); NEAR(r.pitchAfterDeg, 0.0, 1e-6);
    check_rotation(K);
    double cf[3] = {K[0] * vh[0] + K[1] * vh[1] + K[2] * vh[2], K[3] * vh[0] + K[4] * vh[1] + K[5] * vh[2], K[6] * vh[0] + K[7] * vh[1] + K[8] * vh[2]};
    NEAR(cf[0], 1.0, 1e-6); NEAR(cf[1], 0.0, 1e-6); NEAR(cf[2], 0.0, 1e-6);          // the long side lies straight along the controller's forward
    // after the shift the centre is where the lean-only solve left it (forward / up), the pitch step does not touch the sideways offset
    NEAR(r.fwdFt + r.shiftFwdFt, r0.fwdFt, 1e-9); NEAR(r.upFt + r.shiftUpFt, r0.upFt, 1e-9); NEAR(r.latAfterFt, r0.latAfterFt, 1e-9);
    // a target of +10 degrees
    pkealign::Result r10 = pkealign::solve_ex(K0, vh, ph, 70.0, 10.0, K);
    NEAR(r10.pitchAfterDeg, 10.0, 1e-6);
    // a hold already in the plane: only the pitch is turned
    double vh2[3] = {cos(20 * kD), sin(20 * kD), 0.0}, ph2[3] = {0.1, 0.0, 0.03};
    pkealign::Result r2 = pkealign::solve_ex(I3, vh2, ph2, 70.0, 0.0, K);
    CHECK(r2.ok == 1); NEAR(r2.pitchAfterDeg, 0.0, 1e-6); NEAR(r2.latAfterFt, 0.03, 1e-9); check_rotation(K);
    // "keep" (900 or more) changes nothing
    pkealign::Result rk = pkealign::solve_ex(I3, vh2, ph2, 70.0, 1.0e9, K);
    NEAR(rk.pitchAfterDeg, 20.0, 1e-6); NEAR(rk.shiftFwdFt, 0.0, 1e-12);
    (void)cf0;
  }
  // Reported upright hold: 78.6 degrees was outside the old pitch guard.
  for (double degrees : {78.6, 89.0, -89.0}) {
    const double pitch = degrees * kD;
    double vh[3] = {cos(pitch), sin(pitch), 0}, ph[3] = {0.1, -0.2, 0.08};
    const auto result = pkealign::solve_ex(I3, vh, ph, 70.0, 0.0, K);
    NEAR(result.pitchAfterDeg, 0.0, 1e-5); check_rotation(K);
    NEAR(result.fwdFt + result.shiftFwdFt, ph[0], 1e-6);
    NEAR(result.upFt + result.shiftUpFt, ph[1], 1e-6);
  }
  // 1.7.224: the hand turn is capped (25 deg); the meter keeps the rest of its lean, still a proper rotation
  for (double degrees : {57.0, 20.0, -40.0, 78.6}) {
    const double pitch = degrees * kD;
    double vh[3] = {cos(pitch), sin(pitch), 0}, ph[3] = {0.1, -0.2, 0.08};
    const auto result = pkealign::solve_ex(I3, vh, ph, 70.0, 0.0, K, 25.0);
    const double want = degrees > 25.0 ? degrees - 25.0 : degrees < -25.0 ? degrees + 25.0 : 0.0;
    NEAR(result.pitchAfterDeg, want, 1e-5); check_rotation(K);
    CHECK(result.swingDeg <= 25.0 + 1e-6 + 0.0 || result.swingDeg > 0.0);
    NEAR(result.fwdFt + result.shiftFwdFt, ph[0], 1e-6);
    NEAR(result.upFt + result.shiftUpFt, ph[1], 1e-6);
  }
  if (fails) { printf("%d failures\n", fails); return 1; }
  printf("pkealign: ok\n");
  return 0;
}
