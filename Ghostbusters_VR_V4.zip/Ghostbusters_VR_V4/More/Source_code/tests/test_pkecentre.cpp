// 1.7.158 PKE centred on the controller: for any hold, any controller tilt (Touch / Index / Vive / Windows MR style grips) and a million passes
// (hours of play): the long side lies in the controller's centre plane, the hand shift puts the PKE's centre on the controller (inside the 0.3 ft cap),
// nothing drifts from pass to pass, nothing is NaN.
#include <cstdio>
#include <cmath>
#include "pkealignmath.h"
static int fails = 0;
static unsigned long long sd = 0xB5297A4DULL;
static double rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (double)(sd >> 11) / 9007199254740992.0; }
static void rot(const double* a0, double deg, double* R) { double a[3] = {a0[0], a0[1], a0[2]}; const double n = sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]); for (int i = 0; i < 3; ++i) a[i] /= n; weight::axis_angle(a, deg * 3.14159265358979 / 180.0, R); }
static double cl(double v) { return v > 0.3 ? 0.3 : (v < -0.3 ? -0.3 : v); }
int main() {
  const double tilt[5] = {0.0, 20.0, 36.0, -25.0, 50.0};   // none, Touch-like, Index-like, Vive-like, WMR-like (degrees about the sideways axis)
  const double Zax[3] = {0, 0, 1};
  long nan = 0, notPlane = 0, notCentred = 0, drift = 0, n = 0; double worst = 0;
  for (int fam = 0; fam < 5; ++fam) for (int it = 0; it < 200000; ++it) {
    double Rt[9], Rr[9], K0[9]; rot(Zax, tilt[fam], Rt);
    const double ax[3] = {rnd() - 0.5, rnd() - 0.5, rnd() - 0.4}; rot(ax, rnd() * 50.0, Rr);
    weight::mul3(Rt, Rr, K0);
    double vh[3] = {1.0, (rnd() - 0.5) * 0.5, (rnd() - 0.5) * 0.5}; const double l = sqrt(vh[0]*vh[0]+vh[1]*vh[1]+vh[2]*vh[2]); for (int i = 0; i < 3; ++i) vh[i] /= l;
    const double ph[3] = {(rnd() - 0.5) * 0.4, (rnd() - 0.5) * 0.4, (rnd() - 0.5) * 0.4};
    const double pitch = rnd() < 0.5 ? 0.0 : 1.0e9;
    double K[9]; const pkealign::Result r = pkealign::solve_ex(K0, vh, ph, 70.0, pitch, K);
    for (int i = 0; i < 9; ++i) if (!(K[i] == K[i])) ++nan;
    if (!r.ok) continue;
    ++n;
    double c2[3]; for (int a = 0; a < 3; ++a) c2[a] = K[a*3]*vh[0] + K[a*3+1]*vh[1] + K[a*3+2]*vh[2];
    if (fabs(c2[2]) > 0.0045) ++notPlane;   // the 0.25 degree dead zone
    // what armcore does with pke_centre=1: the hand moves by (-fwd, -up, -lat) of the centre, each capped at 0.3 ft
    const double sx = cl(-r.fwdFt), sy = cl(-r.upFt), sz = cl(-r.latAfterFt);
    const double ex = r.fwdFt + sx, ey = r.upFt + sy, ez = r.latAfterFt + sz;
    const double off = fmax(fabs(ex), fmax(fabs(ey), fabs(ez)));
    if (fabs(r.fwdFt) < 0.3 && fabs(r.upFt) < 0.3 && fabs(r.latAfterFt) < 0.3) { if (off > 1e-9) ++notCentred; if (off > worst) worst = off; }
    if (!(off == off)) ++nan;
    if (it % 20000 == 0) { double Ka[9], Kb[9]; pkealign::solve_ex(K0, vh, ph, 70.0, pitch, Ka); pkealign::solve_ex(K0, vh, ph, 70.0, pitch, Kb); for (int i = 0; i < 9; ++i) if (Ka[i] != Kb[i]) ++drift; }
  }
  fails = (int)(nan + notPlane + notCentred + drift);
  printf("%s PKE centre: %ld holds, 5 controller tilts; NaN %ld, axis not in plane %ld, centre off controller %ld (worst %.2e ft), pass-to-pass drift %ld\n", fails ? "FAIL" : "PASS", n, nan, notPlane, notCentred, worst, drift);
  return fails ? 1 : 0;
}
