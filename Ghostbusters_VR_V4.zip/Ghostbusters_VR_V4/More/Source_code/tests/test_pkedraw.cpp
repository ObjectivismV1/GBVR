#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include "pkedrawmath.h"

static void rotY(float* m, double a, float x, float y, float z) {
  handprop::ident(m); const float c = (float)cos(a), s = (float)sin(a);
  m[0] = c; m[2] = -s; m[8] = s; m[10] = c; m[12] = x; m[13] = y; m[14] = z;
}
int main() {
  float game[16], hand[16], a[16], out[16], part[16], partHand[16], rel[16];
  rotY(game, 0.3, 10, 5, 2);
  rotY(hand, 1.1, 8, 4, 3);
  // the same matrix (tiny float noise) is the game's pose
  for (int i = 0; i < 16; ++i) a[i] = game[i];
  a[12] += 0.05f;
  assert(pkedraw::is_game_pose(a, game, 0.13, 0.004));
  // moved 0.3 ft: not the meter
  a[12] += 0.3f;
  assert(!pkedraw::is_game_pose(a, game, 0.13, 0.004));
  // turned 20 degrees: not the meter
  rotY(a, 0.3 + 0.35, 10, 5, 2);
  assert(!pkedraw::is_game_pose(a, game, 0.13, 0.004));
  // scaled 2x: not the meter
  for (int i = 0; i < 16; ++i) a[i] = game[i];
  for (int i = 0; i < 11; ++i) if ((i & 3) != 3) a[i] *= 2.0f;
  assert(!pkedraw::is_game_pose(a, game, 0.13, 0.004));
  // the meter itself carried: exactly the in-hand pose
  assert(pkedraw::carry(game, game, hand, out));
  for (int i = 0; i < 16; ++i) assert(fabs(out[i] - hand[i]) < 1e-4);
  // a part 0.2 ft along the meter's own x keeps that relation on the hand
  handprop::ident(rel); rel[12] = 0.2f;
  handprop::mul34(part, rel, game);
  assert(pkedraw::carry(part, game, hand, partHand));
  float expect[16]; handprop::mul34(expect, rel, hand);
  for (int i = 0; i < 16; ++i) assert(fabs(partHand[i] - expect[i]) < 1e-4);
  // census: a site is learned after kLearn exact matches, the table holds kSites callers
  pkedraw::Census c = {};
  pkedraw::Site* s = pkedraw::site(c, 0x1234);
  for (int i = 0; i < pkedraw::kLearn - 1; ++i) ++s->exact;
  assert(!pkedraw::learned(s));
  ++s->exact; assert(pkedraw::learned(s));
  assert(pkedraw::site(c, 0x1234) == s);
  for (int i = 0; i < 40; ++i) pkedraw::site(c, 0x5000 + i);
  assert(c.n == pkedraw::kSites && c.full > 0);
  printf("test_pkedraw ok\n");
  return 0;
}
