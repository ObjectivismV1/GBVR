#include <initializer_list>
#include <cstdio>
#include <cmath>
#include "pkeeasymath.h"
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { ++fails; std::printf("FAIL %s\n", msg); } } while (0)
int main() {
  using namespace pkeasy;
  CHECK(assisted_alignment(0.99f, -0.4f) == 0.99f, "offset story scan point retains native aim");
  CHECK(assisted_alignment(0.1f, 0.99f) == 0.99f, "tracked close-range aim still helps");
  for (float native : {-1.0f, 0.0f, 0.9511f, 1.0f})
    for (float tracked : {-1.0f, 0.0f, 0.9511f, 1.0f})
      CHECK(assisted_alignment(native, tracked) >= native, "assistance never lowers native aim");
  CHECK(close_alignment(0.3f, 1.0f, 4.0, 1) == 1.0f, "near reticle target accepts offset hand ray");
  CHECK(close_alignment(0.3f, 1.0f, 20.0, 1) == 0.3f, "far targets still require meter aim");
  CHECK(close_alignment(-0.3f, 1.0f, 4.0, 1) == -0.3f, "target behind meter is not assisted");
  CHECK(close_alignment(0.3f, 0.8f, 4.0, 1) == 0.3f, "looking away does not assist");
  CHECK(close_alignment(0.3f, 1.0f, 4.0, 0) == 0.3f, "close help can be disabled");
  {
    float origin[3] = {10, 4, -3}, direction[3] = {0, 0, 1}, target[3], alignment = 0;
    for (float distance : {0.02f, 0.2f, 1.0f, 4.3f, 50.0f}) {
      target[0] = origin[0]; target[1] = origin[1]; target[2] = origin[2] + distance;
      CHECK(controller_alignment(origin, direction, target, &alignment) && alignment > 0.9999f, "close/far target on tracked line stays aligned");
    }
    target[2] = origin[2] - 1;
    CHECK(controller_alignment(origin, direction, target, &alignment) && alignment < -0.999f, "target behind controller is rejected by cone");
    CHECK(!controller_alignment(origin, direction, origin, &alignment), "zero-distance target is not a valid direction");
    direction[2] = 0; CHECK(!controller_alignment(origin, direction, target, &alignment), "missing direction rejected");
    direction[2] = std::nanf(""); CHECK(!controller_alignment(origin, direction, target, &alignment), "bad direction rejected");
  }
  Cfg off = {0, 0, 35, 40}, easy = {1, 1, 35, 40}, manual = {1, 0, 35, 40};
  CHECK(std::fabs(cone_cos(18.0) - std::cos(18.0 * M_PI / 180)) < 1e-6, "cone cos 18");
  CHECK(std::fabs(cone_cos(40.0) - std::cos(40.0 * M_PI / 180)) < 1e-6, "cone cos 40");
  CHECK(game_cone_deg(off) == 18.0 && game_range_ft(off) == 15.0, "off = the game's own limits");
  CHECK(game_cone_deg(easy) == 40.0 && game_range_ft(easy) == 35.0, "easy widens");
  Cfg wild = {1, 1, 500, 5};
  CHECK(game_range_ft(wild) == 80.0 && game_cone_deg(wild) == 18.0, "clamped, never narrower than the game");
  Rec r = {1, 1, 30.0 * 30.0, std::cos(30 * M_PI / 180), 0.0, 1};
  CHECK(in_window(r, easy), "30 ft, 30 deg is inside");
  CHECK(!in_window(r, off), "30 ft is outside the game's own 15 ft");
  r.dist2 = 36.0 * 36.0; CHECK(!in_window(r, easy), "36 ft is outside 35 ft");
  r.dist2 = 20.0 * 20.0; r.align = std::cos(45 * M_PI / 180); CHECK(!in_window(r, easy), "45 deg is outside 40 deg");
  r.align = std::cos(35 * M_PI / 180); CHECK(in_window(r, easy), "35 deg is inside");
  CHECK(!want_input(r, easy, 0), "35 deg is too far off to START by itself (3/4 of 40 = 30)");
  CHECK(want_input(r, easy, 1), "35 deg keeps a running scan");
  r.align = std::cos(25 * M_PI / 180); CHECK(want_input(r, easy, 0), "25 deg, 20 ft starts by itself");
  CHECK(!want_input(r, manual, 0), "auto off: no input is made");
  CHECK(!want_input(r, off, 0), "easy off: no input is made");
  r.cooldown = 0.5; CHECK(!want_input(r, easy, 0), "cooldown blocks");
  r.cooldown = 0; r.visible = 0; CHECK(!want_input(r, easy, 0), "not visible blocks (the game's own wall rule)");
  r.visible = 1; r.equipped = 0; CHECK(!want_input(r, easy, 0), "not equipped blocks");
  r.equipped = 1; r.hasTarget = 0; CHECK(!want_input(r, easy, 0), "no target");
  r.hasTarget = 1; r.dist2 = 33.0 * 33.0; CHECK(!want_input(r, easy, 0), "33 ft is beyond 90 % of 35 to start"); CHECK(want_input(r, easy, 1), "33 ft keeps a scan");
  CHECK(std::fabs(align_deg(std::cos(33.0 * M_PI / 180)) - 33.0) < 0.01, "align_deg");
  CHECK(std::fabs(align_deg(1.0)) < 1e-6 && std::fabs(align_deg(-1.0) - 180.0) < 1e-6, "align_deg ends");
  CHECK(scan_rumble(1, 0.0, 1) > 0.1 && scan_rumble(1, 1.0, 1) > scan_rumble(1, 0.0, 1), "rumble grows with the bar");
  CHECK(scan_rumble(0, 0.0, 0) == 0.0 && scan_rumble(0, 0.0, 1) > 0.0, "a faint tick while in the window");
  // 1.6 ping rate floor
  CHECK(ping_rate(0.0, 1) == 0.5 && ping_rate(0.25, 1) == 0.5 && ping_rate(0.5, 1) == 0.5 && ping_rate(1.0, 1) == 1.0, "ping rate: never below 0.5 with the help");
  CHECK(ping_rate(0.0, 0) == 0.0 && ping_rate(0.25, 0) == 0.25, "ping rate: untouched with the help off");
  CHECK(rate_level(1.0) == 0 && rate_level(0.5) == 1 && rate_level(0.25) == 2 && rate_level(0.0) == -1, "rate -> level");
  CHECK(level_rate(0) == 1.0 && level_rate(1) == 0.5 && level_rate(2) == 0.25 && level_rate(-1) == 0.0, "level -> rate");
  { WhyIn w = {1, 0, 1, 0.0, 1, 0, 1, 100.0, 225.0, std::cos(5 * M_PI / 180), std::cos(10 * M_PI / 180)};
    CHECK(why_not(w) == kWhyOk, "all good scans");
    w.equipped = 0; CHECK(why_not(w) == kWhyNotEquipped, "not equipped first"); w.equipped = 1;
    w.ownerState = 2; CHECK(why_not(w) == kWhyOwnerBusy, "busy player"); w.ownerState = 0;
    w.hasTarget = 0; CHECK(why_not(w) == kWhyNoTarget, "no target"); w.hasTarget = 1;
    w.cooldown = 1.2; CHECK(why_not(w) == kWhyCooldown, "cooldown"); w.cooldown = 0.0;
    w.scannable = 0; CHECK(why_not(w) == kWhyNotScannable, "not scannable"); w.scannable = 1;
    w.blocked = 1; CHECK(why_not(w) == kWhyBlocked, "blocked"); w.blocked = 0;
    w.visible = 0; CHECK(why_not(w) == kWhyNoLine, "no line"); w.visible = 1;
    w.dist2 = 300.0; CHECK(why_not(w) == kWhyRange, "range"); w.dist2 = 100.0;
    w.align = std::cos(30 * M_PI / 180); CHECK(why_not(w) == kWhyCone, "cone");
    w.equipped = 0; w.scannable = 0; CHECK(why_not(w) == kWhyNotEquipped, "the first failing reason wins");
    CHECK(why_name(kWhyOk)[0] == 'w' && why_name(kWhyCone)[0] == 't' && why_name(99)[0] == '?', "names"); }
  // 1.7.83 close-range help: a hand-held meter is ~2 ft beside / below what you look at, so at arm's length the same 30 degree cone misses the thing
  { Cfg c30 = {1, 0, 50, 30};
    const double kSlack = 2.0;
    CHECK(std::fabs(close_cone_deg(2.0, kSlack) - 45.0) < 0.01, "2 ft away: atan(2/2) = 45 deg");
    CHECK(close_cone_deg(1.0, kSlack) > 62.0 && close_cone_deg(1.0, kSlack) < 64.0, "1 ft away: about 63 deg");
    CHECK(close_cone_deg(0.0, kSlack) == 70.0 && close_cone_deg(-3.0, kSlack) == 70.0, "on top of it / nonsense: the 70 degree cap");
    CHECK(close_cone_deg(0.2, kSlack) == 70.0, "very close is capped at 70 deg");
    CHECK(close_cone_deg(20.0, kSlack) < 6.0, "far away the close rule means nothing");
    CHECK(std::isnan(close_cone_deg(std::nan(""), kSlack)) == 0 && close_cone_deg(std::nan(""), kSlack) == 0.0, "NaN distance: no help (0)");
    CHECK(effective_cone_deg(c30, 20.0, 1) == 30.0, "a source 20 ft away: the setting's own cone");
    CHECK(effective_cone_deg(c30, 1e9, 1) == 30.0, "no source known: the setting's own cone");
    CHECK(std::fabs(effective_cone_deg(c30, 2.0, 1) - 45.0) < 0.01, "a source 2 ft from the meter: 45 deg");
    CHECK(effective_cone_deg(c30, 2.0, 0) == 30.0, "help off: the setting's own cone");
    Cfg off2 = {0, 0, 50, 30};
    CHECK(effective_cone_deg(off2, 1.0, 1) == 18.0, "easy scan off: the game's own 18 deg, help or not");
    Cfg big = {1, 0, 50, 60};
    CHECK(effective_cone_deg(big, 6.0, 1) == 60.0, "never narrower than the setting");
    CHECK(std::fabs(effective_cone_deg(c30, 3.0, 1) - 33.69) < 0.05, "3 ft: 33.7 deg (just starts to help)");
    // continuity: the cone never jumps as you move the meter
    double prev = effective_cone_deg(c30, 6.0, 1); int jump = 0;
    for (double d = 6.0; d > 0.05; d -= 0.01) { const double v = effective_cone_deg(c30, d, 1); if (v + 1e-9 < prev || v - prev > 1.0) ++jump; prev = v; }
    CHECK(jump == 0, "the cone grows smoothly and never shrinks as the meter gets closer");
  }
  std::printf(fails ? "pkeeasy: %d FAILED\n" : "pkeeasy: all passed\n", fails);
  return fails ? 1 : 0;
}
