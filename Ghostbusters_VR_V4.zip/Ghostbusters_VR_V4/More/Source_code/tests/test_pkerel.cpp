// 1.7.172 the PKE's hold on the controller (pkerelmath.h): exact round trip, rigid with the controller, bad poses never wipe a good hold, stress.
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "pkerelmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double rnd() { return rand() / (double)RAND_MAX; }
static void rvec(float* v, double s) { for (int i = 0; i < 3; ++i) v[i] = (float)((rnd() - 0.5) * 2.0 * s); }
static double d3(const float* a, const float* b) { return sqrt((a[0]-b[0])*(a[0]-b[0]) + (a[1]-b[1])*(a[1]-b[1]) + (a[2]-b[2])*(a[2]-b[2])); }
static double len(const float* a) { return sqrt((double)a[0]*a[0] + (double)a[1]*a[1] + (double)a[2]*a[2]); }
static double dot(const float* a, const float* b) { return (double)a[0]*b[0] + (double)a[1]*b[1] + (double)a[2]*b[2]; }
static void frame(float* grip, float* dir, float* up) {   // a random controller: any place, any direction, an up that is not along it
  rvec(grip, 800.0);
  do { rvec(dir, 1.0); } while (len(dir) < 0.2);
  do { rvec(up, 1.0); } while (len(up) < 0.2 || fabs(dot(up, dir)) / (len(up) * len(dir)) > 0.95);
}
int main() {
  using namespace pkerel;
  long n = 0; double worstPos = 0, worstAx = 0, worstRigid = 0;
  for (int it = 0; it < 200000; ++it, ++n) {
    float g[3], d[3], u[3]; frame(g, d, u);
    float M[16] = {0}; M[15] = 1;
    // a meter: three perpendicular axes with a scale 0.5..2, within 1.5 ft of the grip
    double B[9]; float d2[3], u2[3]; frame(M + 12, d2, u2); CHECK(basis(d2, u2, B));
    const double sc = 0.5 + rnd() * 1.5;
    for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) M[j * 4 + i] = (float)(B[j * 3 + i] * sc);
    float off[3]; rvec(off, 0.8); for (int i = 0; i < 3; ++i) M[12 + i] = g[i] + off[i];
    Rel r; r.ok = 0;
    CHECK(store(r, M, g, d, u) && r.ok);
    float O[16]; CHECK(pose(r, g, d, u, O));   // the same controller: the same pose back
    for (int i = 0; i < 3; ++i) { const double e = fabs(O[12 + i] - M[12 + i]); if (e > worstPos) worstPos = e; }
    for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) { const double e = fabs(O[j * 4 + i] - M[j * 4 + i]); if (e > worstAx) worstAx = e; }
    // another controller pose: rigid with it (distance to the grip, axis lengths, the angle of each axis to the controller's forward and up-plane)
    float g2[3], dd[3], uu[3]; frame(g2, dd, uu); float P[16]; CHECK(pose(r, g2, dd, uu, P));
    double e = fabs(d3(P + 12, g2) - d3(M + 12, g));
    for (int j = 0; j < 3; ++j) { e = fmax(e, fabs(len(P + j * 4) - len(M + j * 4))); e = fmax(e, fabs(dot(P + j * 4, dd) / len(dd) - dot(M + j * 4, d) / len(d))); }
    { float a[3] = {M[12]-g[0], M[13]-g[1], M[14]-g[2]}, b[3] = {P[12]-g2[0], P[13]-g2[1], P[14]-g2[2]}; e = fmax(e, fabs(dot(a, d) / len(d) - dot(b, dd) / len(dd))); }
    if (e > worstRigid) worstRigid = e;
  }
  printf("pkerel: %ld random holds | same controller: position off by at most %.5f ft, axes %.6f | moved controller: rigid within %.5f\n", n, worstPos, worstAx, worstRigid);
  CHECK(worstPos < 2e-3 && worstAx < 1e-4 && worstRigid < 2e-3);   // float precision at 800 ft from the origin
  {   // bad input never wipes a good hold and never writes M
    float g[3] = {10, 5, -3}, d[3] = {0, 0, 1}, u[3] = {0, 1, 0};
    float M[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 10.2f,5.1f,-2.9f,1};
    Rel r; r.ok = 0; CHECK(store(r, M, g, d, u));
    const Rel keep = r; volatile float z = 0; const float nan = z / z;
    float bad[16]; for (int i = 0; i < 16; ++i) bad[i] = M[i];
    bad[12] = 50; CHECK(!store(r, bad, g, d, u));                               // 40 ft from the grip (the game's own spot)
    bad[12] = M[12]; bad[0] = 1e-4f; bad[1] = bad[2] = 0; CHECK(!store(r, bad, g, d, u));   // the hidden (squashed) model
    bad[0] = nan; CHECK(!store(r, bad, g, d, u));
    const float zero[3] = {0, 0, 0}, nn[3] = {nan, 0, 1};
    CHECK(!store(r, M, g, zero, u) && !store(r, M, g, d, zero) && !store(r, M, g, d, d) && !store(r, M, nn, d, u) && !store(r, M, g, nn, u) && !store(r, nullptr, g, d, u));
    CHECK(r.ok && r.pos[0] == keep.pos[0] && r.pos[1] == keep.pos[1] && r.pos[2] == keep.pos[2] && r.ax[0] == keep.ax[0] && r.ax[8] == keep.ax[8]);
    float O[16]; for (int i = 0; i < 16; ++i) O[i] = 7;
    CHECK(!pose(r, g, zero, u, O) && !pose(r, g, d, d, O) && !pose(r, nn, d, u, O) && !pose(r, g, d, nn, O) && O[0] == 7 && O[12] == 7);
    Rel none; none.ok = 0; CHECK(!pose(none, g, d, u, O) && O[5] == 7);
    CHECK(pose(r, g, d, u, O) && fabs(O[12] - 10.2f) < 1e-5 && O[3] == 0 && O[15] == 1);
  }
  printf("%s\n", fails ? "FAILED" : "ok");
  return fails ? 1 : 0;
}
