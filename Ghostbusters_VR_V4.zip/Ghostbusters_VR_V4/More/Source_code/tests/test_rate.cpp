// 0.98 refresh-rate arithmetic for the log.
#include <stdio.h>
#include <math.h>
#include "ratemath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  using namespace rate;
  CHECK(fabs(period_ms(72.0) - 13.8889) < 1e-3 && fabs(period_ms(120.0) - 8.3333) < 1e-3 && period_ms(0.0) == 0.0);
  // the 0.97 log: work about 3 ms per pair at 72 Hz
  CHECK(fits(72.0, 3.0, kTailMs) && fits(90.0, 3.0, kTailMs) && fits(120.0, 3.0, kTailMs));   // 8.33 - 7.0 = 1.33 >= 0.5
  CHECK(!fits(120.0, 5.0, kTailMs) && fits(90.0, 5.0, kTailMs) && fits(72.0, 8.0, kTailMs) && !fits(72.0, 10.0, kTailMs));
  const int cand[4] = {120, 90, 80, 72};
  CHECK(best_fit(3.0, kTailMs, cand, 4) == 120);
  CHECK(best_fit(5.0, kTailMs, cand, 4) == 90);
  CHECK(best_fit(6.5, kTailMs, cand, 4) == 90);   // 11.11 - 10.5 = 0.61
  CHECK(best_fit(7.0, kTailMs, cand, 4) == 80);   // 12.5 - 11 = 1.5, but 90 Hz has only 0.11 left
  CHECK(best_fit(8.5, kTailMs, cand, 4) == 72);
  CHECK(best_fit(12.0, kTailMs, cand, 4) == 0);
  CHECK(!fits(0.0, 1.0, 1.0) && !fits(-5.0, 1.0, 1.0));
  CHECK(fabs(margin_ms(72.0, 3.0, 4.0) - 6.8889) < 1e-3);
  // sharpness: the 0.97 log had eye pictures of 2233 x 2413 against a recommendation of 2496 x 2688
  CHECK(fabs(area_ratio(2233, 2413, 2496, 2688) - 0.8031) < 1e-3);
  CHECK(fabs(side_ratio(2233, 2413, 2496, 2688) - 0.8962) < 1e-3);
  CHECK(area_ratio(0, 0, 2496, 2688) == 0.0 && area_ratio(100, 100, 0, 0) == 0.0 && side_ratio(100, 100, 0, 5) == 0.0);
  // the work budget follows the display period
  CHECK(fabs(work_budget_ms(90.0) - 11.111) < 1e-2 && fabs(work_budget_ms(72.0) - 13.889) < 1e-2 && fabs(work_budget_ms(120.0) - 8.333) < 1e-2);
  CHECK(work_budget_ms(0.0) == 11.1 && work_budget_ms(10.0) == 11.1 && work_budget_ms(1000.0) == 11.1);
  CHECK(work_budget_ms(45.0) <= 20.0 && work_budget_ms(300.0) >= 5.0);
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
