// 1.7.153 the FPS limit (ratecap.h): rules + a stress run of a simulated headset.
#include <cstdio>
#include <cmath>
#include "ratecap.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static unsigned long long s = 0x2545F4914F6CDD1DULL;
static double rnd() { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return (double)(s >> 11) / 9007199254740992.0; }
int main() {
  // the menu steps through every option and stops at both ends
  { int v = 0, n = 0; while (ratecap::next(v, 1) != v) { v = ratecap::next(v, 1); ++n; CHECK(ratecap::valid(v) == v); } CHECK(v == 120 && n == ratecap::kOptionCount - 1);
    while (ratecap::next(v, -1) != v) v = ratecap::next(v, -1); CHECK(v == 0);
    CHECK(ratecap::next(77, 1) == 45 && ratecap::next(-5, -1) == 0 && ratecap::valid(77) == 0 && ratecap::valid(1) == 0); }
  // 1.7.158: every menu click on any headset changes the real rate (never a repeat, never a silent no-limit), and the ends are reachable
  for (int hz10 = 500; hz10 <= 2400; hz10 += 7) {
    const double hz = hz10 / 10.0; int v = 0, steps = 0;
    for (;;) { const int nx = ratecap::next_for(hz, v, 1); if (nx == v) break; CHECK(nx != 0);
      CHECK((ratecap::divisor(hz, nx) > 1 || ratecap::fractional(hz, nx)) && (int)(ratecap::effective_fps(hz, nx) + 0.5) != (v ? (int)(ratecap::effective_fps(hz, v) + 0.5) : 0)); v = nx; if (++steps > 20) break; }
    CHECK(steps <= 8);
    int back = 0; while (ratecap::next_for(hz, v, -1) != v && back < 20) { v = ratecap::next_for(hz, v, -1); ++back; }
    CHECK(v == 0);
    CHECK(ratecap::next_for(hz, 0, -1) == 0);
  }
  CHECK(ratecap::next_for(0.0, 0, 1) == 45);   // rate unknown: plain list
  // divisors
  CHECK(ratecap::divisor(90.0, 0) == 1 && ratecap::divisor(90.0, 90) == 1 && ratecap::divisor(90.0, 120) == 1);
  CHECK(ratecap::divisor(90.0, 45) == 2 && ratecap::divisor(89.9, 45) == 2 && ratecap::divisor(90.1, 45) == 2);
  CHECK(ratecap::divisor(90.0, 60) == 2 && ratecap::divisor(90.0, 30) == 3 && ratecap::divisor(120.0, 60) == 2 && ratecap::divisor(120.0, 40) == 3 && ratecap::divisor(120.0, 30) == 4);
  CHECK(ratecap::divisor(72.0, 36) == 2 && ratecap::divisor(72.0, 45) == 2 && ratecap::divisor(72.0, 72) == 1 && ratecap::divisor(80.0, 40) == 2 && ratecap::divisor(144.0, 72) == 2);
  CHECK(ratecap::divisor(75.0, 36) == 2 && ratecap::divisor(60.0, 30) == 2 && ratecap::divisor(60.0, 45) == 2 && ratecap::divisor(144.0, 45) == 3 && ratecap::divisor(165.0, 80) == 2);   // Pico 75, WMR 60, Index 144 (48 FPS, within 10 % of 45), 165
  CHECK(ratecap::divisor(0.0, 45) == 1 && ratecap::divisor(-1.0, 45) == 1 && ratecap::divisor(1e9, 45) == 1 && ratecap::divisor(90.0, 77) == 1);
  { volatile double z = 0; CHECK(ratecap::divisor(z / z, 45) == 1 && ratecap::divisor(z / z, ratecap::kHalf) == 1); }
  // half rate / a third: the same on every headset
  for (int hz10 = 500; hz10 <= 2400; ++hz10) { CHECK(ratecap::divisor(hz10 / 10.0, ratecap::kHalf) == 2 && ratecap::divisor(hz10 / 10.0, ratecap::kThird) == 3); }
  CHECK(ratecap::divisor(0.0, ratecap::kHalf) == 1);   // unknown rate: nothing
  // every headset rate from 50 to 240 Hz in 0.01 steps x every number: never above the headset's rate, never more than 10 % over the limit, never under a sixth
  for (int hz100 = 5000; hz100 <= 24000; ++hz100) for (int i = 3; i < ratecap::kOptionCount; ++i) {
    const double hz = hz100 / 100.0; const int cap = ratecap::kOptions[i];
    const double eff = ratecap::effective_fps(hz, cap);
    CHECK(eff <= hz + 1e-9);
    if (ratecap::divisor(hz, cap) > 1 && ratecap::divisor(hz, cap) < 6) CHECK(eff <= cap * 1.1001);
    if (ratecap::divisor(hz, cap) > 1) CHECK(eff > cap * 0.5 - 1e-9 || ratecap::divisor(hz, cap) == 2);   // and not needlessly slow: at most one divisor step under the limit
    CHECK(eff >= hz / 6.0 - 1e-9);
  }
  // sleeps: none without a reference, none when the game was slow enough, never longer than N-1 headset frames
  const long long F = 10000000;   // ticks a second
  CHECK(ratecap::sleep_ticks(1000, 0, F, 90.0, 45) == 0);
  CHECK(ratecap::sleep_ticks(F, F + 5, F, 90.0, 45) == 0);                       // the clock went backwards
  CHECK(ratecap::sleep_ticks(F + F / 50, F, F, 90.0, 45) == 0);                  // 20 ms of work: already past the 1st headset frame
  { const long long t = ratecap::sleep_ticks(F + F / 200, F, F, 90.0, 45);       // 5 ms of work: sleep to 1.15 frames = 12.78 ms
    CHECK(llabs(t - (long long)(F * (1.15 / 90.0) - F / 200)) < 20); }
  CHECK(ratecap::sleep_ticks(F + 1, F, F, 90.0, 90) == 0 && ratecap::sleep_ticks(F + 1, F, F, 90.0, 0) == 0 && ratecap::sleep_ticks(F + 1, F, 0, 90.0, 45) == 0);
  // stress: a simulated headset. Vsync every 1/hz s; the wait ends on the next vsync after it is called; the game's work varies (also above one frame, with hitches).
  long bad = 0; long long frames = 0;
  for (int run = 0; run < 1300; ++run) {
    static const double rates[] = {60.0, 72.0, 75.0, 80.0, 90.0, 120.0, 144.0, 165.0, 89.91, 119.88, 71.93, 59.94, 100.0};
    const double hz = run < 650 ? rates[run % 13] : 50.0 + rnd() * 190.0;      // the usual headsets, then any rate at all
    const int cap = ratecap::kOptions[1 + (int)(rnd() * (ratecap::kOptionCount - 1))];
    const int n = ratecap::divisor(hz, cap);
    const double period = (double)F / hz;
    const double workBase = period * (0.15 + rnd() * 2.6);    // from light to much heavier than one headset frame
    const double phase = rnd() * period;
    long long now = F * 100 + (long long)(rnd() * 1e12), lastWaitEnd = 0; long gaps[16] = {0}; long total = 0; long long maxSleep = 0;
    for (int f = 0; f < 12000; ++f, ++frames) {
      double work = workBase * (0.85 + rnd() * 0.3);
      if (rnd() < 0.002) work += period * rnd() * 8.0;         // a hitch
      now += (long long)work;
      const long long sl = ratecap::sleep_ticks(now, lastWaitEnd, F, hz, cap);
      if (sl < 0 || sl > (long long)(period * (n - 1 + 0.15)) + 1) ++bad;
      if (sl > maxSleep) maxSleep = sl;
      now += sl + (long long)(rnd() * F * 0.0003);             // the sleep overshoots by up to 0.3 ms
      const long long k = (long long)(((double)now - phase) / period) + 1;      // the wait ends on the next headset frame
      const long long end = (long long)(phase + (double)k * period);
      if (lastWaitEnd) { const int g = (int)llround((double)(end - lastWaitEnd) / period); if (g < 1) ++bad; ++gaps[g > 15 ? 15 : g]; ++total; if (g < n) ++bad; }   // never faster than the limit
      lastWaitEnd = end; now = end;
    }
    // when the work fits inside N headset frames (minus the sleep's margin) almost every pair must land exactly N frames after the last one: steady
    if (workBase * 1.15 + F * 0.0003 < period * (n - 0.2) && n > 1) { if (gaps[n] < total * 0.985) { ++bad; printf("  not steady: hz %.2f cap %d n %d work %.2f frames: exact %ld of %ld\n", hz, cap, n, workBase / period, gaps[n], total); } }
    if (n == 1 && maxSleep != 0) ++bad;                         // no limit: never sleeps
  }
  // 1.7.172 recheck: the PACED limit exactly as stereo.cpp runs it (frames_for per pair -> sleep_ticks_n), on a simulated headset.
  // Rules: never faster than the limit over a run; whenever the PC can make the limit (its own rate is at least 8 % above it) the average IS the limit
  // (within 1.5 %), also with hitches and pairs that need two headset frames; a sleep never exceeds its pair's frames; a PC slower than the limit is
  // never slowed further (no sleep adds a frame); no limit within 10 % of the headset's rate.
  { long pbad = 0; long long ppairs = 0; int pruns = 0, held = 0, slow = 0; double worstUnder = 0;
    for (int run = 0; run < 1200; ++run) {
      static const double rates[] = {72.0, 80.0, 90.0, 120.0, 144.0, 89.91, 119.88, 71.93, 100.0, 75.0, 165.0};
      const double hz = run < 700 ? rates[run % 11] : 50.0 + rnd() * 190.0;
      const int cap = ratecap::kOptions[1 + (int)(rnd() * (ratecap::kOptionCount - 1))];
      const int paced = ratecap::fractional(hz, cap);
      if (hz / cap <= 1.10 && paced) ++pbad;                       // within 10 % of the headset's rate: never paced
      if (!paced) continue;
      ++pruns;
      const double period = (double)F / hz;
      const int kind = run % 3;                                    // 0 light work, 1 work around one headset frame (some pairs need two: the 71-of-90 PC), 2 heavy
      const double workBase = period * (kind == 0 ? 0.10 + rnd() * 0.55 : kind == 1 ? 0.80 + rnd() * 0.35 : 1.2 + rnd() * 1.6);
      const double phase = rnd() * period;
      // the same work, twice: without the limit (what the PC can do) and with it
      double fpsOf[2] = {0, 0}; long extra = 0;
      for (int limited = 0; limited < 2; ++limited) {
        unsigned long long seed = 88172645463325252ULL + (unsigned long long)run * 7919ULL;
        auto r2 = [&seed]() { seed ^= seed << 13; seed ^= seed >> 7; seed ^= seed << 17; return (double)(seed % 1000000) / 1000000.0; };
        long long now = F * 100, lastWaitEnd = 0, firstEnd = 0; long pairs = 0; ratecap::Pacer pc; pc.reset();
        for (int f = 0; f < 9000; ++f) {
          double work = workBase * (0.85 + r2() * 0.3);
          if (r2() < 0.002) work += period * r2() * 8.0;           // a hitch
          now += (long long)work;
          long long sl = 0; int nPair = 1;
          if (limited) {
            ++ppairs;
            nPair = ratecap::frames_for(pc, lastWaitEnd, F, hz, cap);
            if (nPair < 1 || nPair > 6 || !(pc.next == pc.next)) ++pbad;
            sl = ratecap::sleep_ticks_n(now, lastWaitEnd, F, hz, nPair);
            if (sl < 0 || sl > (long long)(period * (nPair - 1 + 0.15)) + 1) ++pbad;
            if (nPair == 1 && sl != 0) ++pbad;
            // a sleep only ever fills up to the pair's own frames: it never pushes the wait past frame nPair
            if (sl > 0 && lastWaitEnd && now + sl > lastWaitEnd + (long long)(period * (nPair - 1 + 0.16))) ++extra;
          }
          now += sl + (long long)(r2() * F * 0.0003);
          const long long k = (long long)(((double)now - phase) / period) + 1;
          const long long end = (long long)(phase + (double)k * period);
          if (lastWaitEnd) ++pairs; else firstEnd = end;
          lastWaitEnd = end; now = end;
        }
        fpsOf[limited] = (double)pairs * (double)F / (double)(lastWaitEnd - firstEnd);
      }
      if (extra) { ++pbad; printf("  a sleep ran past its pair: hz %.2f cap %d (%ld times)\n", hz, cap, extra); }
      if (fpsOf[1] > cap * 1.005) { ++pbad; printf("  paced too fast: hz %.2f cap %d -> %.2f\n", hz, cap, fpsOf[1]); }
      if (fpsOf[0] >= cap * 1.08) { ++held; const double under = 1.0 - fpsOf[1] / cap; if (under > worstUnder) worstUnder = under;
        if (fpsOf[1] < cap * 0.985) { ++pbad; printf("  paced not holding: hz %.2f cap %d: the PC makes %.1f without the limit but only %.2f with it (work %.2f frames)\n", hz, cap, fpsOf[0], fpsOf[1], workBase / period); } }
      else if (fpsOf[0] < cap * 0.97) { ++slow; if (fpsOf[1] < fpsOf[0] * 0.97) { ++pbad; printf("  a slow PC was slowed further: hz %.2f cap %d: %.1f -> %.1f\n", hz, cap, fpsOf[0], fpsOf[1]); } }
    }
    printf("PACED STRESS: %lld simulated pairs over %d paced runs (%d where the PC can make the limit: worst %.2f %% under it; %d where it cannot): rule breaks %ld\n", ppairs, pruns, held, worstUnder * 100.0, slow, pbad);
    bad += pbad; frames += ppairs;
    {   // the plain pattern with a perfect PC: 60 on 90 Hz = 2, 1, 2, 1 ...; and wrong inputs never crash, loop or sleep
      ratecap::Pacer pc; pc.reset(); long long last = F; int n2 = 0, n1 = 0;
      for (int i = 0; i < 1000; ++i) { const int n = ratecap::frames_for(pc, last, F, 90.0, 60); if (n == 2) ++n2; else if (n == 1) ++n1; else ++bad; last += (long long)(n * (double)F / 90.0); }
      CHECK(n1 == 500 && n2 == 500);
      volatile double z = 0;
      pc.reset(); CHECK(ratecap::frames_for(pc, 0, F, 90.0, 60) == 1 && ratecap::frames_for(pc, F, 0, 90.0, 60) == 1 && ratecap::frames_for(pc, F, F, z / z, 60) == 1 && ratecap::frames_for(pc, F, F, 90.0, 45) == 2 && ratecap::frames_for(pc, F, F, 90.0, 0) == 1);
      pc.next = z / z; pc.have = 1; { const int n = ratecap::frames_for(pc, F, F, 90.0, 60); CHECK(n >= 1 && n <= 2 && pc.next == pc.next); }
      pc.next = 1e30; pc.have = 1; { const int n = ratecap::frames_for(pc, F, F, 90.0, 60); CHECK(n >= 1 && n <= 3 && pc.next < 2.0 * F); }      // a far-future schedule: at most one pair + one frame
      pc.next = -1e30; pc.have = 1; { const int n = ratecap::frames_for(pc, F, F, 90.0, 60); CHECK(n == 1 && pc.next > 0.9 * F); }               // a far-past schedule: one frame made up, the rest forgotten
      CHECK(ratecap::sleep_ticks_n(F + 1, F, F, z / z, 2) == 0 && ratecap::sleep_ticks_n(F + 1, F, F, 0.0, 2) == 0);
    }
    CHECK(!ratecap::fractional(75.0, 72) && !ratecap::fractional(90.0, 90) && !ratecap::fractional(91.0, 90) && ratecap::fractional(100.0, 45) && ratecap::fractional(72.0, 50) && ratecap::fractional(90.0, 80));
    CHECK(ratecap::next_for(75.0, 60, 1) == 60);   // 72 on 75 Hz is not offered (no limit): 60 is the top step
  }
  // the headset does not report its rate: the plain timer. Never faster than the limit (on average and per pair), never a sleep over one interval.
  for (int run = 0; run < 200; ++run) {
    const int cap = ratecap::kOptions[3 + (int)(rnd() * (ratecap::kOptionCount - 3))];
    const long long iv = ratecap::interval_ticks(F, cap);
    long long now = F * 50, last = 0, first = 0; int pairs = 0;
    for (int f = 0; f < 5000; ++f, ++frames) {
      now += (long long)(F * (0.002 + rnd() * 0.02));
      const long long sl = ratecap::sleep_ticks_free(now, last, F, cap);
      if (sl < 0 || sl > iv) ++bad;
      now += sl;
      if (last && now - last < iv - 1) ++bad;
      last = now; if (!first) first = now; ++pairs;
    }
    if ((double)(pairs - 1) * F / (double)(last - first) > cap * 1.0001) ++bad;
    if (ratecap::sleep_ticks_free(F, F - 10, F, ratecap::kHalf) != 0) ++bad;   // half needs the rate: nothing
  }
  printf("RATECAP STRESS: %lld simulated pairs over 1500 runs (60 to 165 Hz headsets and random rates 50..240 Hz x every choice incl. half / a third x light-to-very-heavy work, hitches; and unknown-rate timer runs): rule breaks %ld\n", frames, bad);
  CHECK(bad == 0);
  if (!fails) printf("ratecap: ok\n");
  // 1.7.170: on 90 Hz every listed number below 90 is reachable, and paced numbers average out to the number
  { int v = 0, seen = 0; for (;;) { const int nx = ratecap::next_for(90.0, v, 1); if (nx == v) break; v = nx; ++seen; }
    printf("90 Hz menu reaches %d limits (last %d)\n", seen, v); CHECK(seen == 5 && v == 80); }
  CHECK(!ratecap::fractional(90.0, 45) && !ratecap::fractional(120.0, 60) && !ratecap::fractional(90.0, 0) && !ratecap::fractional(90.0, 90) && !ratecap::fractional(90.0, 120) && !ratecap::fractional(0.0, 60));
  CHECK(ratecap::fractional(90.0, 60) && ratecap::fractional(90.0, 72) && ratecap::fractional(90.0, 80) && (int)ratecap::effective_fps(90.0, 60) == 60);
  return fails ? 1 : 0;
}
