#include <stdio.h>
#include <math.h>
#include "rigmath.h"
using namespace rig;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

static void setj(Snap& s, int j, double r, double u, double f) { s.j[j][0] = (float)(r * s.fpm); s.j[j][1] = (float)(u * s.fpm); s.j[j][2] = (float)(f * s.fpm); s.ok[j] = 1; }

static Frame frame() {
  Frame f; for (unsigned i = 0; i < sizeof(f); ++i) ((char*)&f)[i] = 0;
  f.head[0] = 0; f.head[1] = 1.65; f.head[2] = 0;
  const double id[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  for (int i = 0; i < 9; ++i) f.Rh[i] = id[i];
  f.C[0] = -0.5; f.C[1] = 1.7; f.C[2] = -1.1;
  f.delta = vm::kPi; f.k = 0.4; f.fpm = 3.28084; f.floorY = 0;
  return f;
}
static Snap snap() {
  Snap s; s.clear(); s.have = 1; s.fpm = 3.28084f;
  setj(s, J_HEAD, 0, 0.02, -0.03); setj(s, J_NECK, 0, -0.1, -0.05); setj(s, J_SPINE3, 0, -0.25, -0.08); setj(s, J_SPINE1, 0, -0.5, -0.08);
  setj(s, J_PELVIS, 0, -0.85, -0.05);
  setj(s, J_CLAVR, 0.05, -0.2, -0.06); setj(s, J_SHR, 0.19, -0.22, -0.06); setj(s, J_ELR, 0.25, -0.45, 0.0); setj(s, J_WRR, 0.2, -0.5, 0.3);
  setj(s, J_CLAVL, -0.05, -0.2, -0.06); setj(s, J_SHL, -0.19, -0.22, -0.06); setj(s, J_ELL, -0.25, -0.45, 0.0); setj(s, J_WRL, -0.2, -0.5, 0.3);
  setj(s, J_HIPL, -0.1, -0.9, -0.05); setj(s, J_KNL, -0.1, -1.2, 0.0); setj(s, J_FTL, -0.1, -1.6, -0.02);
  setj(s, J_HIPR, 0.1, -0.9, -0.05); setj(s, J_KNR, 0.1, -1.2, 0.0); setj(s, J_FTR, 0.1, -1.6, -0.02);
  s.packOk = 1; s.pack[0] = -0.05f; s.pack[1] = -1.15f; s.pack[2] = -0.53f;
  s.packAx[0][0] = 1; s.packAx[1][1] = 1; s.packAx[2][2] = 1;
  s.hoseOk = 1; s.hose[0] = 0.25f; s.hose[1] = -1.84f; s.hose[2] = -0.58f;
  return s;
}

int main() {
  // game world -> the headset's axes
  {
    // headset turned 90 degrees to the left in the game world: forward = -x_world, right = +z_world... columns (right, up, forward)
    const double view[9] = {0, 0, -1,   0, 1, 0,   1, 0, 0};   // row r = world axis, column k = head axis: right=(0,0,1), up=(0,1,0), fwd=(-1,0,0)
    const double eye[3] = {10, 5, 3};
    const double P[3] = {10 - 2, 5 + 1, 3 + 0.5};    // 2 ahead (-x), 1 up, 0.5 to the right (+z)
    float o[3]; point_to_head(view, eye, P, o);
    CHECK(fabs(o[0] - 0.5) < 1e-5 && fabs(o[1] - 1.0) < 1e-5 && fabs(o[2] - 2.0) < 1e-5);
    const double D[3] = {0, 0, 7}; dir_to_head(view, D, o);
    CHECK(fabs(o[0] - 1.0) < 1e-5 && fabs(o[1]) < 1e-5 && fabs(o[2]) < 1e-5);
  }
  // mapping: from the front a point at the player's right shows on the viewer's left of the miniature; the eye is at C
  {
    Frame f = frame(); Mapper m(f);
    float a[3] = {(float)(0.2 * f.fpm), 0, 0}; double d[3];
    m.headax(a, d);
    printf("right 0.2 m, front view -> display offset %.3f,%.3f,%.3f\n", d[0] - f.C[0], d[1] - f.C[1], d[2] - f.C[2]);
    CHECK(fabs(d[0] - (f.C[0] - 0.2 * f.k)) < 1e-6); CHECK(fabs(d[1] - f.C[1]) < 1e-6); CHECK(fabs(d[2] - f.C[2]) < 1e-6);
    float u[3] = {0, (float)(0.5 * f.fpm), 0}; m.headax(u, d); CHECK(fabs(d[1] - (f.C[1] + 0.5 * f.k)) < 1e-6);
    float fw[3] = {0, 0, (float)(0.3 * f.fpm)}; m.headax(fw, d);   // 0.3 m ahead of the eye: towards the viewer after the 180 degree turn
    CHECK(fabs(d[2] - (f.C[2] + 0.3 * f.k)) < 1e-6);
    // from behind: no turn
    f.delta = 0; Mapper m0(f); m0.headax(a, d); CHECK(fabs(d[0] - (f.C[0] + 0.2 * f.k)) < 1e-6);
    // right side view: +90 degrees turns the figure's forward (-z) towards +x
    f.delta = vm::kPi / 2; Mapper m1(f); m1.headax(fw, d);
    CHECK(fabs(d[0] - (f.C[0] - 0.3 * f.k * -1.0 * 1.0)) < 1e-6 || fabs(d[0] - (f.C[0] + 0.3 * f.k)) < 1e-6 || fabs(d[0] - (f.C[0] - 0.3 * f.k)) < 1e-6);
    // tracking-space points use the same turn
    f.delta = vm::kPi; Mapper m2(f);
    double p[3] = {f.head[0] + 0.3, f.head[1] - 0.2, f.head[2] - 0.4}; m2.track(p, d);
    CHECK(fabs(d[0] - (f.C[0] - 0.3 * f.k)) < 1e-6 && fabs(d[1] - (f.C[1] - 0.2 * f.k)) < 1e-6 && fabs(d[2] - (f.C[2] + 0.4 * f.k)) < 1e-6);
  }
  // build: everything finite, within the cap, red eye dot sits at C, a gaze ball one metre ahead (scaled)
  {
    Frame f = frame(); Snap s = snap();
    f.haveR = f.haveL = 1; f.ctrlR[0] = 0.25; f.ctrlR[1] = 1.2; f.ctrlR[2] = -0.45; f.ctrlL[0] = -0.25; f.ctrlL[1] = 1.2; f.ctrlL[2] = -0.4; f.ctrlRAim[2] = -1.0;
    f.haveCord = 1; for (int i = 0; i < cord::kN; ++i) { f.cord[i][0] = 0.02 * i; f.cord[i][1] = 1.1 - 0.01 * i; f.cord[i][2] = 0.2 - 0.03 * i; }
    for (int k = 0; k < 3; ++k) { f.anchorA[k] = f.cord[0][k]; f.anchorB[k] = f.cord[cord::kN - 1][k]; }
    static cord::V buf[20000];
    int n = build(s, f, buf, 20000);
    printf("rig view: %d vertices\n", n);
    CHECK(n > 1000 && n < 12000 && n % 3 == 0);
    int bad = 0, red = 0;
    for (int i = 0; i < n; ++i) {
      for (int k = 0; k < 3; ++k) if (!vm::is_finite_f(buf[i].p[k]) || !vm::is_finite_f(buf[i].n[k])) ++bad;
      const double dx = buf[i].p[0] - f.C[0], dy = buf[i].p[1] - f.C[1], dz = buf[i].p[2] - f.C[2];
      if (buf[i].c[0] > 0.99f && buf[i].c[1] < 0.1f && buf[i].c[2] < 0.1f && sqrt(dx * dx + dy * dy + dz * dz) < 0.03) ++red;
      if (buf[i].c[3] != 1.0f) ++bad;
    }
    CHECK(bad == 0);
    CHECK(red > 100);   // the red sphere (192 vertices) round the eye point
    CHECK(build(s, f, buf, 100) == 0);   // too small a buffer: nothing
    // no snapshot: still the eye dot, floor and controllers
    Snap none; none.clear();
    int n2 = build(none, f, buf, 20000);
    CHECK(n2 > 100 && n2 < n);
    // the stick figure is the right size: the feet are 1.6 m * 0.4 below the eye point
    double lowest = 99; for (int i = 0; i < n; ++i) if (buf[i].p[1] < lowest) lowest = buf[i].p[1];
    for (int i = 0; i < n; ++i) if (buf[i].p[1] == (float)lowest) { printf("lowest vertex #%d at %.3f,%.3f,%.3f colour %.2f,%.2f,%.2f\n", i, buf[i].p[0], buf[i].p[1], buf[i].p[2], buf[i].c[0], buf[i].c[1], buf[i].c[2]); break; }
    printf("lowest point %.3f (floor tile at %.3f)\n", lowest, f.C[1] - f.head[1] * f.k);
    CHECK(lowest > f.C[1] - f.head[1] * f.k - 0.01);
  }
  printf(fails ? "rig: %d FAILED\n" : "rig: all ok\n", fails);
  return fails ? 1 : 0;
}
