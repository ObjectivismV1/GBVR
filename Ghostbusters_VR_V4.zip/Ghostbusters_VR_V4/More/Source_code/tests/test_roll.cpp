#include <stdio.h>
#include <math.h>
#include <string.h>
#include "armmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static unsigned g_seed = 12345;
static double rnd() { g_seed = g_seed * 1664525u + 1013904223u; return ((g_seed >> 8) & 0xFFFF) / 65535.0; }
static void rand_axis(double* a) {
  for (;;) { a[0] = rnd() * 2 - 1; a[1] = rnd() * 2 - 1; a[2] = rnd() * 2 - 1; double l = sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2]); if (l > 0.2 && l < 1.0) { for (int i = 0; i < 3; ++i) a[i] /= l; return; } }
}
static void rand_rot(double* R) { double a[3]; rand_axis(a); weight::axis_angle(a, (rnd() * 2 - 1) * 3.0, R); }
static double wrap(double x) { while (x > 3.14159265358979) x -= 6.28318530717959; while (x <= -3.14159265358979) x += 6.28318530717959; return x; }
int main() {
  // a pure turn about a is found exactly
  for (int t = 0; t < 200; ++t) {
    double a[3], R[9]; rand_axis(a);
    const double th = (rnd() * 2 - 1) * 3.0;
    weight::axis_angle(a, th, R);
    CHECK(fabs(arm::twist_about(R, a) - th) < 1e-9);
  }
  // a turn about a different axis perpendicular to a has no twist
  { double a[3] = {0, 0, 1}, ax[3] = {1, 0, 0}, R[9]; weight::axis_angle(ax, 1.2, R); CHECK(fabs(arm::twist_about(R, a)) < 1e-9); }
  // sharing: the forearm takes `share` of the hand's turn; what is left in the hand is (1 - share) of it (any swing included)
  for (int t = 0; t < 400; ++t) {
    double Qh[9], QF[9], a[3], Qt[9], QF2[9], R0[9], R2[9], QFt[9], QF2t[9];
    rand_rot(Qh); rand_rot(QF); rand_axis(a);
    const double share = (t % 5) * 0.25;
    weight::transpose3(QF, QFt); weight::mul3(Qh, QFt, R0);
    const double th = arm::twist_about(R0, a);
    const double g = arm::forearm_roll(Qh, QF, a, share, Qt);
    CHECK(fabs(g - th * share) < 1e-9);
    weight::mul3(Qt, QF, QF2);
    weight::transpose3(QF2, QF2t); weight::mul3(Qh, QF2t, R2);
    const double th2 = arm::twist_about(R2, a);
    CHECK(fabs(wrap(th2 - (1.0 - share) * th)) < 1e-7);
  }
  // share 0 changes nothing, share 1 leaves no twist
  { double Qh[9], QF[9], a[3], Qt[9]; rand_rot(Qh); rand_rot(QF); rand_axis(a);
    arm::forearm_roll(Qh, QF, a, 0.0, Qt);
    for (int i = 0; i < 9; ++i) CHECK(fabs(Qt[i] - ((i % 4 == 0) ? 1.0 : 0.0)) < 1e-12);
    double QF2[9], QF2t[9], R2[9]; arm::forearm_roll(Qh, QF, a, 1.0, Qt);
    weight::mul3(Qt, QF, QF2); weight::transpose3(QF2, QF2t); weight::mul3(Qh, QF2t, R2);
    CHECK(fabs(arm::twist_about(R2, a)) < 1e-7);
  }
  printf(fails ? "test_roll: %d FAILED\n" : "test_roll: all passed\n", fails);
  {   // 1.7.150: no flip anywhere when the hand turns all the way round the forearm, in both directions, and no memory to get stuck
    const double ax[3] = {0, 0, 1}, I3[9] = {1,0,0, 0,1,0, 0,0,1};
    arm::RollMemory m = {}; double Qt[9], Qh[9];
    double lastG = 0.0, maxStep = 0.0; int first = 1;
    for (int k = -7200; k <= 7200; ++k) {   // two whole turns each way, a tenth of a degree a frame
      const double ang = k * 0.1 * 3.14159265358979 / 180.0;
      weight::axis_angle(ax, ang, Qh);
      const double g = arm::forearm_roll_cont(Qh, I3, ax, 0.5, &m, 100.0 * 3.14159265358979 / 180.0, Qt);
      if (!first && std::fabs(g - lastG) > maxStep) maxStep = std::fabs(g - lastG);
      lastG = g; first = 0;
    }
    if (maxStep > 0.01) { printf("FAIL forearm roll jumps %.4f rad in one tenth of a degree\n", maxStep); return 1; }
    // the plain one does flip (what players saw)
    int oldFlips = 0; double lg = 0.0; first = 1;
    for (int k = 0; k <= 60; ++k) {
      const double ang = (150.0 + k) * 3.14159265358979 / 180.0;
      weight::axis_angle(ax, ang, Qh);
      const double g = arm::forearm_roll(Qh, I3, ax, 0.5, Qt);
      if (!first && std::fabs(g - lg) > 0.1) ++oldFlips;
      lg = g; first = 0;
    }
    if (oldFlips == 0) { printf("FAIL the old roll was expected to flip\n"); return 1; }
    // unchanged below 120 degrees: exactly the old share
    for (int d = -120; d <= 120; d += 15) {
      weight::axis_angle(ax, d * 3.14159265358979 / 180.0, Qh);
      const double gn = arm::forearm_roll_cont(Qh, I3, ax, 0.5, &m, 100.0 * 3.14159265358979 / 180.0, Qt), go = arm::forearm_roll(Qh, I3, ax, 0.5, Qt);
      if (std::fabs(gn - go) > 1e-9) { printf("FAIL roll changed at %d deg\n", d); return 1; }
    }
    // a glitch (a jump of 200 degrees in one frame, then back) leaves nothing behind: the same answer as before it
    weight::axis_angle(ax, 30.0 * 3.14159265358979 / 180.0, Qh);
    const double before = arm::forearm_roll_cont(Qh, I3, ax, 0.5, &m, 0.0, Qt);
    double Qg[9]; weight::axis_angle(ax, 230.0 * 3.14159265358979 / 180.0, Qg);
    arm::forearm_roll_cont(Qg, I3, ax, 0.5, &m, 0.0, Qt);
    const double after = arm::forearm_roll_cont(Qh, I3, ax, 0.5, &m, 0.0, Qt);
    if (std::fabs(before - after) > 1e-12) { printf("FAIL roll remembers a glitch\n"); return 1; }
    // capped
    weight::axis_angle(ax, 119.0 * 3.14159265358979 / 180.0, Qh);
    arm::RollMemory m2 = {};
    const double g2 = arm::forearm_roll_cont(Qh, I3, ax, 0.99, &m2, 100.0 * 3.14159265358979 / 180.0, Qt);
    if (std::fabs(g2 - 100.0 * 3.14159265358979 / 180.0) > 1e-6 || m2.capped != 1) { printf("FAIL cap %f\n", g2); return 1; }
  }

  return fails ? 1 : 0;
}
