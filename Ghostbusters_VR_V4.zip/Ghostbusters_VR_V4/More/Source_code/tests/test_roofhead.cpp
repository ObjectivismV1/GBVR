// 1.7.216: on the roof the picture is pitched down (sceneview::aim_down) and the head's own movement from the recenter point is pitched by the same turn.
// With an untouched headset pose the head moving forward by d must move the eye by d along the picture's forward axis (and sideways along its right axis), for any yaw / pitch.
// Also: the length of the head movement is kept, the turn is a pure rotation, a zero pitch changes nothing, everything stays finite.
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include "../src/vmath.h"
#include "../src/stereomath.h"
#include "../src/sceneviewmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { ++fails; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static double rnd() { return (double)rand() / RAND_MAX * 2.0 - 1.0; }
// 1.7.216: the roof view is centred and straight at placement for ANY head yaw / pitch the player had at that moment (incl. looking steeply up or down, where the old yaw fell back to 0)
static void ry_basis(double yaw, double pitchUp, float* m) {   // head basis: yaw about up, then pitched up by pitchUp (negative = down); columns: right, up, forward (engine layout: forward = m[2],m[5],m[8])
  float L[9]; stereo::level_basis(yaw, L);
  const double sp = std::sin(pitchUp), cp = std::cos(pitchUp);
  const double fwd[3] = {L[2] * cp, sp, L[8] * cp}, up[3] = {-L[2] * sp, cp, -L[8] * sp};
  m[0] = L[0]; m[3] = 0; m[6] = L[6];
  m[1] = (float)up[0]; m[4] = (float)up[1]; m[7] = (float)up[2];
  m[2] = (float)fwd[0]; m[5] = (float)fwd[1]; m[8] = (float)fwd[2];
}
static void placement_test() {
  srand(9);
  int bad = 0;
  for (int n = 0; n < 40000; ++n) {
    const double headYaw = rnd() * 3.14159265, headPitch = (n % 3 == 0) ? (rnd() < 0 ? -1.0 : 1.0) * (1.40 + 0.17 * (rnd() * 0.5 + 0.5)) : rnd() * 1.2;   // a third of the time almost straight up / down
    float m[9]; ry_basis(headYaw, headPitch, m);
    double hy = 0; CHECK(stereo::robust_heading(m, &hy));
    CHECK(std::fabs(stereo::angle_diff(hy, headYaw)) < 0.02 || headPitch > 1.5 || headPitch < -1.5);   // exact unless within 4.5 deg of vertical (the up column is the only clue there)
    if (std::fabs(stereo::angle_diff(hy, headYaw)) > 0.06) ++bad;
    sceneview::Station st; st.suppressed = 0;
    float normal[3] = {(float)(rnd() * 300), (float)(rnd() * 20), (float)(rnd() * 300)}, mouth[3] = {normal[0] + (float)(rnd() * 120 + 30), normal[1] - 200.f, normal[2] + (float)(rnd() * 120 + 30)};
    if (!st.place(1, 1, normal, mouth, 0.0, hy)) continue;
    float lv[9], view[9]; stereo::level_basis(st.yaw, lv);
    float pose[9]; ry_basis(hy, 0.0, pose);   // a head held level at the placement heading: straight ahead
    vm::mul(lv, pose, view);
    sceneview::aim_down(view, st.facingYaw, st.pitchDown);
    double tm[3] = {(double)st.mouth[0] - st.eye[0], (double)st.mouth[1] - st.eye[1], (double)st.mouth[2] - st.eye[2]};
    const double l = std::sqrt(tm[0]*tm[0] + tm[1]*tm[1] + tm[2]*tm[2]);
    const double dotv = (view[2]*tm[0] + view[5]*tm[1] + view[8]*tm[2]) / l;
    CHECK(dotv > 0.99999);          // looking exactly at the mouth
    CHECK(std::fabs(view[3]) < 1e-4);   // no roll: the right axis stays horizontal
  }
  CHECK(bad < 40000 / 3 / 8);
}
int main() {
  placement_test();
  srand(3);
  int worseBefore = 0;
  for (int n = 0; n < 50000; ++n) {
    const double yaw = rnd() * 3.14159265, pitch = (n % 5 == 0) ? 0.0 : (rnd() * 0.5 + 0.5) * 1.55, facing = yaw + rnd() * 0.3;
    float level[9], view[9], levelP[9];
    stereo::level_basis(yaw, level);
    for (int i = 0; i < 9; ++i) { view[i] = level[i]; levelP[i] = level[i]; }   // pose = identity: view = level
    sceneview::aim_down(view, facing, pitch);
    sceneview::aim_down(levelP, facing, pitch);
    CHECK(vm::is_rotation(view));
    {   // the forced-down view itself (unchanged by the head-movement fix): looking along the boss direction (head yaw 0 at placement), the straight-ahead axis points down by exactly the roof pitch
      float v2[9], l2[9]; stereo::level_basis(facing, l2); for (int k = 0; k < 9; ++k) v2[k] = l2[k];
      sceneview::aim_down(v2, facing, pitch);
      CHECK(std::fabs(v2[5] + std::sin(pitch)) < 1e-4);
      CHECK(std::fabs(v2[2] - std::sin(facing) * std::cos(pitch)) < 1e-4 && std::fabs(v2[8] - std::cos(facing) * std::cos(pitch)) < 1e-4);   // still toward the boss in the horizontal plane
    }
    float base[3] = {(float)(rnd() * 500), (float)(rnd() * 50), (float)(rnd() * 500)};
    float head[3] = {(float)(rnd() * 0.6), (float)(rnd() * 0.4), (float)(rnd() * 0.6)};
    float eyeP[3], eyeOld[3];
    stereo::eye_position(base, levelP, view, head, 0.0, eyeP);
    stereo::eye_position(base, level, view, head, 0.0, eyeOld);
    // wanted: base + view * head (the head moves in the picture's own axes)
    float want[3];
    for (int r = 0; r < 3; ++r) want[r] = base[r] + view[r * 3] * head[0] + view[r * 3 + 1] * head[1] + view[r * 3 + 2] * head[2];
    double dNew = 0, dOld = 0, lenP = 0, len0 = 0;
    for (int r = 0; r < 3; ++r) { const double a = eyeP[r] - want[r], b = eyeOld[r] - want[r]; dNew += a * a; dOld += b * b; const double x = eyeP[r] - base[r], y = eyeOld[r] - base[r]; lenP += x * x; len0 += y * y; }
    CHECK(std::sqrt(dNew) < 2e-3);                      // matches the picture's axes (float rounding at 500 ft)
    CHECK(std::fabs(std::sqrt(lenP) - std::sqrt(len0)) < 2e-3);   // same distance moved
    CHECK(std::isfinite(eyeP[0] + eyeP[1] + eyeP[2]));
    if (pitch == 0.0) CHECK(std::sqrt(dOld) < 2e-3);    // no pitch: nothing changes
    else if (pitch > 0.3 && std::sqrt(dOld) > 0.05) ++worseBefore;
  }
  CHECK(worseBefore > 5000);   // the old layout was visibly off in most pitched cases
  if (fails) { std::printf("%d failures\n", fails); return 1; }
  std::printf("roof head movement ok (old layout off in %d of 50000)\n", worseBefore);
  return 0;
}
