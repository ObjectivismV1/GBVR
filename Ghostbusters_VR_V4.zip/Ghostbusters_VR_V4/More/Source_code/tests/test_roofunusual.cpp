// 1.7.217: unusual inputs for the roof view helpers: NaN / infinite / zero / non-orthonormal head bases, absurd pitches, a placement with bad numbers, an eye pair where the roof view starts or ends between the eyes.
// Nothing may crash, return NaN as if it were good, or leave the station placed with a broken yaw.
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include "../src/vmath.h"
#include "../src/stereomath.h"
#include "../src/sceneviewmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { ++fails; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static double rnd() { return (double)rand() / RAND_MAX * 2.0 - 1.0; }
int main() {
  srand(21);
  const float nan = std::nanf(""), inf = INFINITY;
  const float odd[] = {nan, inf, -inf, 0.f, 1e30f, -1e30f, 1e-30f, 1.f, -1.f, 0.5f};
  int nOdd = (int)(sizeof(odd) / sizeof(odd[0]));
  long goodNan = 0, placedBad = 0, viewBad = 0;
  for (int n = 0; n < 200000; ++n) {
    float m[9];
    for (int i = 0; i < 9; ++i) m[i] = (n % 4 == 0) ? odd[rand() % nOdd] : (float)rnd();
    if (n % 9 == 0) memset(m, 0, sizeof(m));
    double hy = 123.0;
    const int ok = stereo::robust_heading(m, &hy);
    bool finiteIn = true; for (int i = 0; i < 9; ++i) if (!std::isfinite(m[i])) finiteIn = false;
    if (ok && !std::isfinite(hy)) ++goodNan;                       // a "good" heading must be a number
    if (ok) CHECK(std::fabs(hy) <= 3.2);
    if (!ok) CHECK(hy == 123.0);                                    // nothing written on failure
    // placement with these numbers
    sceneview::Station st; st.suppressed = 0;
    float normal[3] = {odd[rand() % nOdd], 3.f, (float)rnd() * 100}, mouth[3] = {(float)(rnd() * 100), -200.f, (float)(rnd() * 100)};
    if (n % 3 == 0) { normal[0] = (float)(rnd() * 100); }
    const double gy = (n % 5 == 0) ? (double)nan : rnd() * 3, hyaw = (n % 7 == 0) ? (double)inf : (ok ? hy : 0.0);
    if (st.place(1, 1, normal, mouth, gy, hyaw)) {
      if (!(std::isfinite(st.yaw) && std::isfinite(st.pitchDown) && std::isfinite(st.facingYaw) && std::isfinite(st.eye[0]) && std::isfinite(st.eye[1]) && std::isfinite(st.eye[2]))) ++placedBad;
    }
    // the view turn with absurd numbers must stay finite for finite input
    float v[9]; for (int i = 0; i < 9; ++i) v[i] = (float)rnd();
    const double ay = (n % 6 == 0) ? 1e6 : rnd() * 20, ap = (n % 4 == 0) ? (rnd() * 50) : (n % 8 == 1 ? 3.2 : rnd() * 1.6);
    sceneview::aim_down(v, ay, ap);
    for (int i = 0; i < 9; ++i) if (!std::isfinite(v[i])) ++viewBad;
    (void)finiteIn;
  }
  std::printf("heading NaN accepted: %ld, station placed with NaN: %ld, aim_down NaN from finite input: %ld\n", goodNan, placedBad, viewBad);
  CHECK(goodNan == 0);
  CHECK(placedBad == 0);
  CHECK(viewBad == 0);
  // the station placed, then released by walking, then placed again later: no stale data
  {
    sceneview::Station st; float normal[3] = {10.f, 5.f, 10.f}, mouth[3] = {60.f, -200.f, 60.f};
    CHECK(st.place(1, 1, normal, mouth, 0.0, 0.5));
    const double y0 = st.yaw, f0 = st.facingYaw;
    float far[3] = {20.f, 5.f, 20.f};
    CHECK(st.release_if_walking(far, 1));
    CHECK(!st.have && st.suppressed);
    CHECK(!st.place(1, 1, normal, mouth, 0.0, 0.5));            // not pinned again in this encounter
    st.suppressed = 0;
    CHECK(st.place(1, 1, normal, mouth, 0.0, 0.5));
    CHECK(std::fabs(st.yaw - y0) < 1e-12 && std::fabs(st.facingYaw - f0) < 1e-12);
  }
  // 40 ft to a mouth 10 ft away (too close) and 5000 ft away (too far) are refused
  {
    sceneview::Station st; float normal[3] = {0.f, 5.f, 0.f}, near_[3] = {5.f, -50.f, 5.f}, far_[3] = {5000.f, -50.f, 0.f};
    CHECK(!st.place(1, 1, normal, near_, 0.0, 0.0));
    CHECK(!st.place(1, 1, normal, far_, 0.0, 0.0));
  }
  if (fails) { std::printf("%d failures\n", fails); return 1; }
  std::printf("roof unusual inputs ok\n");
  return 0;
}
