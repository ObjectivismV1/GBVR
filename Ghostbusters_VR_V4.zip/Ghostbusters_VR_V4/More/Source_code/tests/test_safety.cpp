// 0.44 fail-safe decisions. Build: clang++ -std=c++17 -Isrc tests/test_safety.cpp
#include "safetymath.h"
#include <stdio.h>
#include <string.h>
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  using namespace safety;
  PrevRun none = {0, 0, 0, 0, 0, 0, 0};
  Plan p = plan(none);
  CHECK(!p.abnormal && p.newCount == 0 && !p.disableMenuFast && !p.pictureCap && !p.handModelOff);
  // first abnormal end while playing
  PrevRun a = {1, 0, 0, 1, 0, 0, 0};
  p = plan(a);
  CHECK(p.abnormal && p.newCount == 1 && p.disableMenuFast && p.disableDiag && p.pictureCap == 0 && !p.handModelOff);
  CHECK(!p.wandMoveOff && !p.bodyFollowOff && !p.armIkOff && !p.realModelsOff);   // 1.7.117: the first crash takes no hands / body / gun feature away
  // second in a row
  PrevRun b = {1, 1, 0, 1, 0, 0, 0};
  p = plan(b);
  CHECK(p.abnormal && p.newCount == 2 && p.pictureCap == 0 && !p.handModelOff && p.wandMoveOff && p.bodyFollowOff && p.armIkOff);
  // third and later
  PrevRun c3 = {1, 2, 0, 0, 0, 3, 0};
  p = plan(c3);
  CHECK(p.newCount == 3 && p.pictureCap == 2 && !p.handModelOff && p.disableMenuFast && !p.realModelsOff);
  PrevRun c = {1, 3, 0, 0, 0, 3, 0};
  p = plan(c);
  CHECK(p.newCount == 4 && p.pictureCap == 1 && p.handModelOff && p.disableMenuFast && p.realModelsOff);
  PrevRun c9 = {1, 9, 0, 0, 0, 0, 1};
  p = plan(c9);
  CHECK(p.newCount == 10 && p.pictureCap == 1 && p.handModelOff);
  // an end while closing is not a failure of playing: no change, count kept
  PrevRun e = {1, 1, 1, 0, 0, 0, 1};
  p = plan(e);
  CHECK(p.abnormal && p.newCount == 1 && !p.disableMenuFast && !p.pictureCap && !p.handModelOff);
  // ... unless a fatal error was recorded as well
  PrevRun ef = {1, 1, 1, 1, 0, 0, 0};
  p = plan(ef);
  CHECK(p.newCount == 2 && p.pictureCap == 0 && p.wandMoveOff);
  // a marker of a copy that is still running is left alone
  PrevRun f = {1, 3, 0, 0, 1, 5, 1};
  p = plan(f);
  CHECK(p.foreign && !p.abnormal && !p.disableMenuFast && !p.pictureCap && p.newCount == 3);

  // a run that just disappeared (killed from Steam / Task Manager), no fault, no problems, no restart: not counted, nothing changes
  PrevRun gone = {1, 0, 0, 0, 0, 0, 0};
  p = plan(gone);
  CHECK(p.abnormal && p.newCount == 0 && !p.disableMenuFast && !p.pictureCap);
  PrevRun gone2 = {1, 2, 0, 0, 0, 0, 0};
  p = plan(gone2);
  CHECK(p.newCount == 2 && !p.pictureCap && !p.handModelOff);          // the count stays, no new step
  // a restart of the PC after the run is evidence by itself (a freeze)
  PrevRun frozen = {1, 0, 0, 0, 0, 0, 1};
  p = plan(frozen);
  CHECK(p.newCount == 1 && p.disableMenuFast);
  // recorded problems are evidence by themselves
  PrevRun troubled = {1, 0, 0, 0, 0, 4, 0};
  p = plan(troubled);
  CHECK(p.newCount == 1 && p.disableMenuFast);
  // closing with a restart is still a closing problem
  PrevRun closeFreeze = {1, 0, 1, 0, 0, 0, 1};
  p = plan(closeFreeze);
  CHECK(p.newCount == 0 && !p.disableMenuFast);

  // PerfWatch
  PerfWatch w; w.reset();
  for (int i = 0; i < 4; ++i) CHECK(!w.update(200, 60.0, 900, 0, 0.3, 10.0, 11.1, 60));   // 4 bad reports: not yet
  CHECK(w.update(200, 60.0, 900, 0, 0.3, 10.0, 11.1, 60));                                  // 5th fires
  CHECK(!w.update(200, 60.0, 900, 0, 0.3, 10.0, 11.1, 60));                                 // only once
  w.reset();
  for (int i = 0; i < 4; ++i) w.update(200, 60.0, 900, 0, 0.3, 10.0, 11.1, 60);
  CHECK(!w.update(200, 89.0, 900, 0, 0.3, 10.0, 11.1, 60) && w.bad == 0);                   // recovery resets the count
  for (int i = 0; i < 20; ++i) CHECK(!w.update(200, 72.0, 720, 0, 0.3, 12.0, 13.9, 60));    // 72 of 72 is fine
  for (int i = 0; i < 20; ++i) CHECK(!w.update(3, 10.0, 900, 0, 0.3, 20.0, 11.1, 3));      // too few frames: no information
  w.reset();
  for (int i = 0; i < 5; ++i) w.update(9, 7.0, 900, 0, 0.3, 20.0, 11.1, 9);               // 0.56: 7 pairs/s (9 in an interval) is slow and counts
  CHECK(w.fired);
  w.reset();
  for (int i = 0; i < 20; ++i) CHECK(!w.update(200, 10.0, 900, 7, 0.3, 20.0, 11.1, 200));    // interval with a menu: no information
  for (int i = 0; i < 20; ++i) CHECK(!w.update(200, 10.0, 0, 0, 0.3, 10.0, 11.1, 60));      // compositor rate unknown: no information
  w.reset();
  for (int i = 0; i < 5; ++i) w.update(200, 76.0, 900, 0, 0.3, 10.0, 11.1, 60);             // 76 < 0.85*90 = 76.5: counts
  CHECK(w.fired);
  w.reset();
  for (int i = 0; i < 9; ++i) CHECK(!w.update(200, 77.0, 900, 0, 0.3, 10.0, 11.1, 60));    // 77 >= 76.5: fine
  w.reset();
  w.update(200, 30.0, 900, 0, 0.3, 10.0, 11.1, 60); w.update(200, 30.0, 900, 0, 0.3, 10.0, 11.1, 60); w.update(3, 30.0, 900, 0, 0.3, 20.0, 11.1, 3);
  CHECK(w.bad == 2);                                                   // a quiet interval keeps the count

  for (int i = 0; i < 20; ++i) CHECK(!w.update(200, 10.0, 900, 0, 8.0, 20.0, 11.1, 200));    // long waits: the compositor / headset is slow, not the game
  w.reset();
  for (int i = 0; i < 4; ++i) w.update(200, 40.0, 900, 0, 1.9, 10.0, 11.1, 60);
  CHECK(w.update(200, 40.0, 900, 0, 1.9, 10.0, 11.1, 60));                             // a wait under 2 ms still counts as the game being late

  // 1.7.63: low delivered FPS is not enough to sacrifice resolution when the game work itself fits comfortably.
  w.reset();
  for (int i = 0; i < 20; ++i) CHECK(!w.update(200, 45.0, 900, 0, 0.3, 7.0, 11.1, 0));
  CHECK(w.bad == 0 && !w.fired);
  // Reprojection plus real render pressure still triggers the safety fallback.
  w.reset();
  for (int i = 0; i < 4; ++i) CHECK(!w.update(200, 45.0, 900, 0, 0.3, 9.3, 11.1, 60));
  CHECK(w.update(200, 45.0, 900, 0, 0.3, 9.3, 11.1, 60));

  // stall schedule
  int st = 0, due = 0;
  for (int s = 1; s <= 700; ++s) due += stall_due(s, &st);
  CHECK(due == 8);                                                     // 5,10,20,40,80,160,320,640 once each
  CHECK(!stall_due(0, &st) && st == 0);                                // recovery resets
  CHECK(!stall_due(4, &st) && stall_due(5, &st) && !stall_due(5, &st));

  CHECK(menu_tick_sane(1) && menu_tick_sane(4096) && menu_tick_sane(65536) && !menu_tick_sane(0) && !menu_tick_sane(-5) && !menu_tick_sane(1 << 20));
  // marker round trip
  char m[256];
  snprintf(m, sizeof(m), GBVR_RUN_MARKER_FMT, 4242u, 2, "0.44", 3, 1, 0, 1, 2, "game-wand-tip");
  CHECK(find_number(m, "pid", 0) == 4242 && find_number(m, "count", 9) == 2 && find_number(m, "exiting", 9) == 0 &&
        find_number(m, "fault", 9) == 1 && find_number(m, "issues", 9) == 2 && find_number(m, "picture", 9) == 3 && find_number(m, "menufast", 9) == 1);
  CHECK(find_number(m, "missing", 7) == 7 && find_number("", "count", 5) == 5 && find_number("discount=4;", "count", 5) == 5);
  CHECK(find_number("count=;", "count", 5) == 5 && find_number("count=12\r\nexiting=1;", "exiting", 0) == 1);
  CHECK(find_number("pid=99999999999;", "pid", 0) > 0);   // huge numbers stop growing instead of overflowing
  PrevRun fromText = {1, find_number(m, "count", 0), find_number(m, "exiting", 0) != 0, find_number(m, "fault", 0) != 0, 0, find_number(m, "issues", 0), 0};
  p = plan(fromText);
  CHECK(p.abnormal && p.newCount == 3 && p.pictureCap == 2 && !p.handModelOff);
  printf(fails ? "%d FAILED\n" : "ALL PASS\n", fails);
  return fails ? 1 : 0;
}
