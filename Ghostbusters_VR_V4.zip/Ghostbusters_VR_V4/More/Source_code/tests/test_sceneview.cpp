#include "sceneviewmath.h"
#include "bodymath.h"
#include <cassert>

int main() {
  using sceneview::mode;
  assert(mode(2, 5, 1, 1, 1) == 0);       // regular player camera
  assert(mode(12, 60, 1, 1, 1) == 1);     // scripted camera pulled away
  assert(mode(12, 60, 1, 0, 1) == -1);    // follows a different Ghostbuster
  assert(mode(12, 60, 1, 1, 0) == -1);    // nonplayer target
  assert(mode(12, 60, 0, 1, 1) == -1);    // do not alter desktop views
  assert(mode(12, 2001, 1, 1, 1) == -1);  // implausible camera
  assert(mode(0.0 / 0.0, 60, 1, 1, 1) == -1);
  // 1.7.85: the scripted camera must not lock itself out. The "verified player" only updates while VR frames run, so a player the game
  // re-creates at a cut (new object) used to be refused for the whole scene. Same player = no verified player yet, the same object,
  // the object the last accepted frame followed, or the old verified object is gone.
  using sceneview::same_player;
  assert(same_player(0x100, 0, 0));           // nobody verified yet
  assert(same_player(0x100, 0x100, 1));       // the verified player itself
  assert(!same_player(0x200, 0x100, 1));      // another live Ghostbuster (a teammate in a cutscene): stays flat
  assert(same_player(0x200, 0x100, 0));       // the old verified object no longer exists: the game re-created the player
  assert(!same_player(0, 0x100, 0));          // no follow target is never the player
  assert(!same_player(0, 0, 0));
  sceneview::Encounter fight;
  assert(!fight.update(1, 2, 0, 0, 1)); // unrelated scripted camera: full body
  assert(!fight.update(1, 2, 3, 1, 0)); // boss present, rooftop view not started
  assert(fight.update(1, 2, 3, 1, 1));  // enter the rooftop fight
  assert(fight.update(1, 2, 3, 1, 0));  // normal-camera blip during fight: keep arms
  assert(fight.update(1, 2, 3, -1, 0)); // pause: keep the last view until the next scan
  assert(fight.update(1, 2, 3, 1, 0));  // resume with living boss: keep fight view
  assert(fight.update(1, 2, 0, 0, 1));  // boss fell / pointer vanished but scripted dialogue camera continues: KEEP the VR view model
  assert(fight.update(0, 2, 0, 0, 1));  // exact disappearance frame may have no published world: latch must survive
  assert(fight.update(0, 2, 0, 0, 0));  // one close-camera sample with world missing still cannot pop the model
  for (int i = 0; i < 10; ++i) assert(fight.update(1, 2, 0, 0, 0)); // short transition gaps cannot pop the body back
  assert(!fight.update(1, 2, 0, 0, 0)); // stable return to the close player camera finally restores full body
  assert(fight.update(1, 2, 3, 1, 1));  // retry
  assert(!fight.update(4, 2, 3, 1, 0)); // level change resets immediately
  assert(fight.update(4, 2, 3, 1, 1));
  assert(!fight.update(4, 5, 3, 1, 0)); // player respawn resets immediately
  assert(fight.update(4, 5, 3, 1, 1));
  sceneview::Station station;
  const float roof[3] = {0, 180, 100}, mouth[3] = {0, 110, 0};
  assert(station.place(3, 1, roof, mouth, 0.0, 0.0));
  assert(station.eye[1] == roof[1] + 1.25f); // only the VR view/model is lifted
  assert(station.eye[2] == 90.0f); // ten feet outward, past spawn cable
  assert(station.eye[0] == roof[0]);
  float facing[9];
  double sy, cy; vm::dsincos(station.yaw, &sy, &cy);
  assert(vm::dabs(sy) < 0.001 && cy < -0.99); // horizontally faces mouth
  float view[9];
  view[0] = (float)cy; view[1] = 0; view[2] = (float)sy;
  view[3] = 0; view[4] = 1; view[5] = 0;
  view[6] = (float)-sy; view[7] = 0; view[8] = (float)cy;
  sceneview::aim_down(view, station.facingYaw, station.pitchDown);
  assert(view[5] < -0.58f); // neutral physical head sees the lower boss
  assert(vm::is_rotation(view));
  float handLevel[9] = { (float)cy, 0, (float)sy, 0, 1, 0, (float)-sy, 0, (float)cy };
  sceneview::aim_down(handLevel, station.facingYaw, station.pitchDown);
  for (int i = 0; i < 9; ++i) assert(vm::dabs((double)handLevel[i] - view[i]) < 0.0001);
  station.offset(roof, 0.0);
  assert(station.delta[1] == 1.25f);
  assert(station.delta[2] == -10.0f);
  // The scene turn applies to the visible model; the original actor matrix
  // and its physics remain unchanged.
  float actorM[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}, modelM[16];
  body::Xf visual;
  const float feet[3] = {0, 0, 0}, noMove[3] = {0, 0, 0};
  visual.set(1.0, station.yawDelta, feet, noMove);
  visual.matrix(actorM, modelM);
  assert(modelM[10] < -0.99f && actorM[10] == 1.0f);
  const float wand[3] = {0, 175, 100}, grip[3] = {0, 176.25f, 90};
  assert(sceneview::nearby_rig(grip, wand, station.delta));
  const float badGrip[3] = {100, 105, 75};
  assert(!sceneview::nearby_rig(badGrip, wand, station.delta));
  const float nextRoof[3] = {1, 183, 101};
  station.offset(nextRoof, 0.2);
  assert(station.eye[1] == roof[1] + 1.25f); // game animation must not pull camera down
  assert(station.delta[1] == -1.75f);
  assert(!station.release_if_walking(nextRoof, 1)); // small movement and vertical animation are fine
  // A station readjustment/recenter must face the current Stay Puft focus, not the old heading.
  const float movedMouth[3] = {80, 110, 0};
  assert(station.place(3, 2, nextRoof, movedMouth, 0.2, 0.35));
  const double wantYaw = vm::datan2((double)movedMouth[0] - station.eye[0], (double)movedMouth[2] - station.eye[2]);
  assert(vm::dabs(station.facingYaw - wantYaw) < 0.000001);
  assert(vm::dabs((station.yaw + 0.35) - wantYaw) < 0.000001);
  const float tooNear[3] = {0, 110, 1};
  assert(!station.place(3, 1, tooNear, mouth, 0, 0)); // do not put eyes inside the boss
  const float invalid[3] = {0, 0.0f / 0.0f, 0};
  assert(!station.place(3, 1, roof, invalid, 0, 0));
  const float walked[3] = {nextRoof[0] + 4, nextRoof[1], nextRoof[2]};
  assert(!station.release_if_walking(walked, 0)); // scripted camera can move the actor without player input
  assert(station.release_if_walking(walked, 1));
  assert(!station.have && station.suppressed);
  assert(!station.place(3, 2, walked, movedMouth, 0, 0)); // cannot re-pin the view each frame
  station = sceneview::Station{}; // next encounter may use the scripted view again
  assert(station.place(3, 2, walked, movedMouth, 0, 0));
}
