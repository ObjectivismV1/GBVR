// Host test for src/shotmath.h (the diagnostic picture's shrinking) together
// with src/jpegenc.h: builds a picture the way shot.cpp does from a synthetic
// 3840 x 2160 frame and writes it as JPEG.
// Build: g++ -std=c++17 -O1 -o test_shot tests/test_shot.cpp && ./test_shot OUT.jpg
#include "../src/shotmath.h"
#include "../src/jpegenc.h"
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
static int fails;
static void check(const char* name, bool ok, double v = 0) { printf("%s %s (%.6g)\n", ok ? "PASS" : "FAIL", name, v); fails += !ok; }
static void wr(void* ctx, const uint8_t* d, uint32_t n) { fwrite(d, 1, n, (FILE*)ctx); }

int main(int argc, char** argv) {
  static int xr[2 * shot::kMaxTile];
  // ---- ranges ----
  int lo, hi;
  shot::cell_range(0, 8, 0, 4, 8, &lo, &hi); check("range: 8 -> 4, first cell = pixels 0,1", lo == 0 && hi == 2, hi);
  shot::cell_range(0, 8, 3, 4, 8, &lo, &hi); check("range: last cell = pixels 6,7", lo == 6 && hi == 8, lo);
  shot::cell_range(0, 4, 5, 8, 4, &lo, &hi); check("range: enlarging picks one pixel", lo == 2 && hi == 3, lo);
  shot::cell_range(-3, 5, 0, 2, 4, &lo, &hi); check("range: outside the picture is cut off", lo == 0 && hi == 1, hi);
  shot::cell_range(10, 20, 1, 2, 12, &lo, &hi); check("range: never past the end", lo >= 0 && hi <= 12 && lo < hi, lo);
  bool cover = true; int prev = 0;
  for (int i = 0; i < 960; ++i) { shot::cell_range(0, 3090.4, i, 960, 3840, &lo, &hi); if (lo > prev || hi <= lo || hi > 3840) cover = false; prev = hi; }
  check("range: 3090 -> 960 leaves no gaps", cover && prev >= 3090, prev);
  check("floor / ceil helpers", shot::ifloor(-0.5) == -1 && shot::ifloor(2.0) == 2 && shot::iceil(2.1) == 3 && shot::iceil(-0.5) == 0 && shot::iceil(3.0) == 3);

  // ---- averaging and byte order ----
  { uint8_t src[2 * 2 * 4] = {10, 20, 30, 255, 30, 40, 50, 255, 50, 60, 70, 255, 70, 80, 90, 255};
    uint8_t dst[3];
    shot::shrink(src, 2, 2, 8, 0, 0, 0, 2, 2, dst, 1, 1, 3, xr);
    check("average of four RGBA pixels", dst[0] == 40 && dst[1] == 50 && dst[2] == 60, dst[0]);
    shot::shrink(src, 2, 2, 8, 1, 0, 0, 2, 2, dst, 1, 1, 3, xr);
    check("BGRA source: red and blue exchanged", dst[0] == 60 && dst[1] == 50 && dst[2] == 40, dst[0]);
    uint8_t d4[2 * 2 * 3];
    shot::shrink(src, 2, 2, 8, 0, 0, 0, 2, 2, d4, 2, 2, 6, xr);
    check("same size = copy, not mirrored", d4[0] == 10 && d4[3] == 30 && d4[6] == 50 && d4[9] == 70, d4[3]);
    shot::shrink(src, 2, 2, 8, 0, 1, 0, 2, 2, dst, 1, 1, 3, xr);
    check("part of the picture: right column only", dst[0] == 50 && dst[1] == 60, dst[0]); }
  // row pitch larger than the row
  { std::vector<uint8_t> src(4 * 100, 0);
    for (int y = 0; y < 4; ++y) for (int x = 0; x < 4; ++x) src[y * 100 + x * 4] = (uint8_t)(y * 10 + x);
    uint8_t dst[4 * 4 * 3];
    shot::shrink(src.data(), 4, 4, 100, 0, 0, 0, 4, 4, dst, 4, 4, 12, xr);
    check("row pitch respected", dst[(3 * 4 + 2) * 3] == 32 && dst[(1 * 4 + 0) * 3] == 10, dst[(3 * 4 + 2) * 3]); }
  check("tile height: Quest 3 eye 2.2155 x 2.3938 -> 960 x 1037", shot::tile_height(960, 2.21548, 2.39384, 1088) == 1037, shot::tile_height(960, 2.21548, 2.39384, 1088));
  check("tile height: limited and safe for bad input", shot::tile_height(960, 1.0, 9.0, 1088) == 1088 && shot::tile_height(960, 0, 1, 1088) == 1088);

  // ---- a picture as shot.cpp builds it ----
  const int W = 3840, H = 2160, pitch = W * 4 + 64;
  std::vector<uint8_t> frame((size_t)pitch * H);
  for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {
    uint8_t* p = &frame[(size_t)y * pitch + (size_t)x * 4];
    double cx = (x - W * 0.5) / (W * 0.5), cy = (y - H * 0.5) / (H * 0.5);
    // circles that are round in ANGLE when the frame is tanH 1.37638 x tanV 1.42815 (F7 on): a test of the tile scale
    double ax = cx * 1.37638, ay = cy * 1.42815, r = sqrt(ax * ax + ay * ay);
    int ring = ((int)(r * 10)) & 1;
    p[0] = ring ? 230 : 40; p[1] = (uint8_t)(128 + 100 * cx); p[2] = (uint8_t)(128 + 100 * cy); p[3] = 255;
    if (x < 40 && y < 40) { p[0] = 255; p[1] = 255; p[2] = 0; }  // yellow mark: top left of the frame
  }
  const int TW = 960, PW = 1920;
  int th = shot::tile_height(TW, 2.21548, 2.39384, 1088), band = (int)((double)PW * H / W + 0.5);
  int PH = band + 3 * th;
  std::vector<uint8_t> pic((size_t)PW * PH * 3, 0);
  shot::shrink(frame.data(), W, H, pitch, 0, 0, 0, W, H, pic.data(), PW, band, PW * 3, xr);
  const double bl[4] = {0.0, 0.1619, 0.8048, 1.0}, br[4] = {0.1952, 0.1619, 1.0, 1.0};  // bounds logged by 0.26 with F7 on
  for (int row = 0; row < 3; ++row) for (int e = 0; e < 2; ++e) {
    const double* b = e ? br : bl;
    shot::shrink(frame.data(), W, H, pitch, 0, b[0] * W, b[1] * H, b[2] * W, b[3] * H,
                 &pic[((size_t)(band + row * th) * PW + (size_t)e * TW) * 3], TW, th, PW * 3, xr);
  }
  check("picture: yellow mark at the band's top left", pic[0] > 240 && pic[1] > 240 && pic[2] < 20, pic[0]);
  // the left eye looks straight ahead at u = 0.5 of the frame = 0.5/0.8048 of its tile; rings are centred there
  int cxTile = (int)(0.5 / 0.8048 * TW), cyTile = (int)((0.5 - 0.1619) / (1.0 - 0.1619) * th);
  // ring radius along x and y from the centre (first change of the red channel)
  auto red = [&](int x, int y) { return pic[((size_t)(band + y) * PW + x) * 3]; };
  int rx = 0, ry = 0;
  while (cxTile + rx < TW && (red(cxTile + rx, cyTile) > 128) == (red(cxTile, cyTile) > 128)) ++rx;
  while (cyTile + ry < th && (red(cxTile, cyTile + ry) > 128) == (red(cxTile, cyTile) > 128)) ++ry;
  check("picture: a ring that is round for the eye is round in the tile", abs(rx - ry) <= 1 && rx > 20, rx - ry);
  if (argc > 1) {
    FILE* f = fopen(argv[1], "wb");
    int ok = f && jpg::encode_rgb(pic.data(), PW, PH, PW * 3, 85, wr, f);
    if (f) { long sz = ftell(f); fclose(f); printf("wrote %s %dx%d %ld bytes\n", argv[1], PW, PH, sz); }
    check("picture encoded", ok);
  }
  printf(fails ? "%d FAILED\n" : "ALL PASS\n", fails);
  return fails != 0;
}
