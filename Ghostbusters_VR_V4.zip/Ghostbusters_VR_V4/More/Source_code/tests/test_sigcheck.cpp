// 1.7.187 the "same code" check for another build of the game (Epic): a full image is accepted, one changed byte / an unreadable place is not.
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "sigcheck.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static uint8_t* g_img; static size_t g_sz;
static int readable(const void* p) { const uint8_t* q = (const uint8_t*)p; return q >= g_img && q + 16 <= g_img + g_sz; }
int main() {
  uint32_t maxr = 0; for (int i = 0; i < sigtable::kCount; ++i) if (sigtable::kSamples[i].rva > maxr) maxr = sigtable::kSamples[i].rva;
  CHECK(sigtable::kCount > 300);
  g_sz = maxr + 64; g_img = (uint8_t*)calloc(g_sz, 1);
  for (int i = 0; i < sigtable::kCount; ++i) memcpy(g_img + sigtable::kSamples[i].rva, sigtable::kSamples[i].b, 16);   // samples overlap neighbours only if equal bytes (spaced >= 16 apart)
  int first = 0;
  CHECK(sigcheck::misses(g_img, readable, &first) == 0 && first == -1);
  const uint32_t r = sigtable::kSamples[sigtable::kCount / 2].rva;
  g_img[r + 7] ^= 1; CHECK(sigcheck::misses(g_img, readable, &first) == 1 && first == sigtable::kCount / 2); g_img[r + 7] ^= 1;
  g_img[sigtable::kSamples[3].rva] ^= 0x80; g_img[sigtable::kSamples[9].rva + 15] ^= 0x80; CHECK(sigcheck::misses(g_img, readable, &first) == 2 && first == 3);
  g_img[sigtable::kSamples[3].rva] ^= 0x80; g_img[sigtable::kSamples[9].rva + 15] ^= 0x80;
  g_sz = maxr - 100; CHECK(sigcheck::misses(g_img, readable, &first) >= 1);   // an image too short to hold the samples: not accepted
  g_sz = maxr + 64;
  // different content altogether (another game build): every place differs
  memset(g_img, 0x90, g_sz); CHECK(sigcheck::misses(g_img, readable, nullptr) > sigtable::kCount * 9 / 10);
  if (fails) { printf("%d FAILED\n", fails); return 1; }
  printf("ok: %d samples\n", sigtable::kCount); return 0;
}
