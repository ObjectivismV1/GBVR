#include <cstdio>
#include "solidmath.h"
int main() {
  int bad = 0;
  const double eye[3] = {10, 5.5, 20};
  double d[3];
  // in front of the chest, outside: no push
  double P1[3] = {10, 4.0, 21.5};   // yaw 0: forward = +z
  if (solid::push_out(eye, 0, 1.0, P1, 0.1, d)) { printf("FAIL outside pushed\n"); ++bad; }
  // inside the column, slightly forward of centre: pushed forward (+z), ends on the boundary
  double P2[3] = {10, 4.0, 19.9};
  if (!solid::push_out(eye, 0, 1.0, P2, 0.1, d) || d[2] <= 0 || vm::dabs(d[0]) > 1e-9) { printf("FAIL push dir %f %f\n", d[0], d[2]); ++bad; }
  double Q[3] = {P2[0] + d[0], P2[1], P2[2] + d[2]}, d2[3];
  if (solid::push_out(eye, 0, 1.0, Q, 0.1, d2) && (d2[0] * d2[0] + d2[2] * d2[2]) > 1e-6) { printf("FAIL not on boundary\n"); ++bad; }
  // beside, yaw 90 degrees: forward is +x
  double P3[3] = {10.2, 4.0, 20.1};
  if (!solid::push_out(eye, vm::kPi / 2, 1.0, P3, 0.1, d) || d[0] <= 0) { printf("FAIL yaw push %f %f\n", d[0], d[2]); ++bad; }
  // above the column and below it: none
  double P4[3] = {10, 5.4, 19.8}, P5[3] = {10, 2.0, 19.8};
  if (solid::push_out(eye, 0, 1.0, P4, 0.1, d) || solid::push_out(eye, 0, 1.0, P5, 0.1, d)) { printf("FAIL vertical\n"); ++bad; }
  // taper: at the very top edge the push is ~0
  double P6[3] = {10, 5.5 - 0.35 - 0.001, 19.9};
  solid::push_out(eye, 0, 1.0, P6, 0.1, d);
  if (vm::dabs(d[2]) > 0.01) { printf("FAIL taper %f\n", d[2]); ++bad; }
  // dead centre
  double P7[3] = {10, 4, 19.75};
  if (!solid::push_out(eye, 0, 1.0, P7, 0.1, d) || !(d[2] > 0.3)) { printf("FAIL centre\n"); ++bad; }
  printf(bad ? "solid FAILED\n" : "solid ok\n");
  return bad;
}
