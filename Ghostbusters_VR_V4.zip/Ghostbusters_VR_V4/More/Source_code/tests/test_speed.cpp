#include <stdio.h>
#include "speedmath.h"
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
  speed::Guard g; g.reset();
  double load[speed::P_COUNT] = {0, 0, 0, 0, 0, 0};
  // fast game: nothing fires even with big loads
  load[speed::P_MENU] = 200;
  for (int i = 0; i < 10; ++i) CHECK(g.update(load, 72, 1) == 0);
  // slow game, menu heavy for three windows -> fires on the third, once
  CHECK(g.update(load, 13, 1) == 0);
  CHECK(g.update(load, 13, 1) == 0);
  CHECK(g.update(load, 13, 1) == speed::P_MENU);
  CHECK(g.update(load, 13, 1) == 0);
  // a window with no measurement resets
  speed::Guard h; h.reset();
  load[speed::P_MENU] = 0; load[speed::P_ARMS] = 100; load[speed::P_BODY] = 150;
  CHECK(h.update(load, 10, 1) == 0); CHECK(h.update(load, 10, 1) == 0);
  CHECK(h.update(load, 10, 0) == 0);
  CHECK(h.update(load, 10, 1) == 0); CHECK(h.update(load, 10, 1) == 0);
  CHECK(h.update(load, 10, 1) == speed::P_BODY);          // the heavier one first
  CHECK(h.update(load, 10, 1) == speed::P_ARMS);          // then the other
  CHECK(h.update(load, 10, 1) == 0);
  // light parts never fire
  speed::Guard k; k.reset(); load[speed::P_ARMS] = 30; load[speed::P_BODY] = 30;
  for (int i = 0; i < 10; ++i) CHECK(k.update(load, 5, 1) == 0);
  if (!fails) printf("PASS speed\n");
  return fails;
}
