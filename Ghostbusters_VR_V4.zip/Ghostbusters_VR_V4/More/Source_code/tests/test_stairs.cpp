#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "stairsmath.h"

int main() {
  stairs::Ramp r; stairs::reset(r);
  // standing still: exactly the feet height
  double t = 0.0, e = 0.0;
  for (int i = 0; i < 100; ++i) { t += 1.0 / 90; e = stairs::step(r, t, 2.0, 0.35, 0.06); }
  assert(fabs(e - 2.0) < 1e-6);
  // a flight of stairs: 0.6 ft every 0.25 s (2.4 ft/s up). The eye must move smoothly: the biggest change in one frame much
  // smaller than a stair, and never more than 1 ft from the feet
  double prev = e, maxStep = 0.0, maxGap = 0.0, y = 2.0;
  for (int i = 0; i < 90 * 3; ++i) {
    t += 1.0 / 90;
    if (i % 22 == 0) y += 0.6;
    e = stairs::step(r, t, y, 0.35, 0.06);
    if (i > 30) { const double d = fabs(e - prev); if (d > maxStep) maxStep = d; }
    if (fabs(e - y) > maxGap) maxGap = fabs(e - y);
    prev = e;
  }
  printf("stairs: biggest eye change per frame %.3f ft (a stair is 0.6), biggest gap to the feet %.2f ft\n", maxStep, maxGap);
  assert(maxStep < 0.12);
  assert(maxGap <= 1.0 + 1e-9);
  // after the stairs end the eye settles on the feet
  for (int i = 0; i < 90; ++i) { t += 1.0 / 90; e = stairs::step(r, t, y, 0.35, 0.06); }
  assert(fabs(e - y) < 0.01);
  // a big jump (teleport) snaps
  t += 1.0 / 90; e = stairs::step(r, t, y + 10.0, 0.35, 0.06);
  assert(fabs(e - (y + 10.0)) < 1e-9);
  // lift for the speed boost: only going up
  assert(stairs::lift_for(0.0, 0.1, 0.05) == 0.0);
  assert(stairs::lift_for(-0.05, 0.1, 0.05) == 0.0);
  assert(stairs::lift_for(0.01, 0.2, 0.05) == 0.0);   // nearly flat
  const double l = stairs::lift_for(0.06, 0.1, 0.05);
  assert(l > 0.045 && l < 0.06);
  assert(stairs::lift_for(5.0, 0.1, 5.0) <= 0.6);
  stairs::reset(r); t = 0; stairs::step(r, t, 2.0, 0.5, 0.06);
  double minEye = 100, maxEye = -100;
  for (int i = 0; i < 180; ++i) {
    t += 1.0 / 90.0;
    double eye = stairs::step(r, t, 2.0 + (i & 1 ? 0.12 : -0.12), 0.5, 0.06);
    if (i > 90) { if (eye < minEye) minEye = eye; if (eye > maxEye) maxEye = eye; }
  }
  assert(maxEye - minEye < 0.07);
  t += 1.0 / 90.0; stairs::step(r, t, 2.7, 0.5, 0.06);
  assert(r.y[(r.head + stairs::kN - 1) % stairs::kN] == 2.7);
  t += 1.0 / 90.0; assert(stairs::step(r, t, 8.0, 0.5, 0.06) == 8.0);
  printf("test_stairs ok\n");
  return 0;
}
