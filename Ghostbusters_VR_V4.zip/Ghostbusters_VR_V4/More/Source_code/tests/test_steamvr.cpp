// 0.67 tests of the SteamVR health check's text handling (steamvrmath.h): the openvrpaths.vrpath reader, the steamvr.vrsettings scan
// (safe-mode / enable flags), the log filter and the error-code decisions (retry or not, what to tell the player).
#include <stdio.h>
#include <string.h>
#include "../src/steamvrmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

struct Got { int n; char sec[64][80]; char line[64][240]; };
static void sink(void* ctx, const char* section, const char* line) {
  Got* g = (Got*)ctx;
  if (g->n >= 64) return;
  strncpy(g->sec[g->n], section, 79); g->sec[g->n][79] = 0;
  strncpy(g->line[g->n], line, 239); g->line[g->n][239] = 0;
  ++g->n;
}

int main() {
  // ---- openvrpaths.vrpath (what SteamVR writes) ----
  const char* vrpath =
      "{\n\t\"config\" : \n\t[\n\t\t\"C:\\\\Program Files (x86)\\\\Steam\\\\config\"\n\t],\n"
      "\t\"external_drivers\" : null,\n\t\"jsonid\" : \"vrpathreg\",\n"
      "\t\"log\" : \n\t[\n\t\t\"C:\\\\Program Files (x86)\\\\Steam\\\\logs\"\n\t],\n"
      "\t\"runtime\" : \n\t[\n\t\t\"C:\\\\Program Files (x86)\\\\Steam\\\\steamapps\\\\common\\\\SteamVR\",\n\t\t\"D:\\\\other\"\n\t],\n"
      "\t\"version\" : 1\n}\n";
  char out[300];
  CHECK(svr::json_first_string(vrpath, "runtime", out, sizeof(out)));
  CHECK(strcmp(out, "C:\\Program Files (x86)\\Steam\\steamapps\\common\\SteamVR") == 0);
  CHECK(svr::json_first_string(vrpath, "config", out, sizeof(out)));
  CHECK(strcmp(out, "C:\\Program Files (x86)\\Steam\\config") == 0);
  CHECK(svr::json_first_string(vrpath, "log", out, sizeof(out)));
  CHECK(strcmp(out, "C:\\Program Files (x86)\\Steam\\logs") == 0);
  CHECK(!svr::json_first_string(vrpath, "nothere", out, sizeof(out)) && out[0] == 0);
  CHECK(!svr::json_first_string(vrpath, "external_drivers", out, sizeof(out)));   // null, not a string
  CHECK(svr::json_first_string("{\"log\":[\"C:/Steam/logs\"]}", "log", out, sizeof(out)) && strcmp(out, "C:\\Steam\\logs") == 0);   // forward slashes become backslashes
  char tiny[8];
  CHECK(svr::json_first_string(vrpath, "runtime", tiny, sizeof(tiny)) && strlen(tiny) == 7);   // cut, still terminated

  // ---- steamvr.vrsettings ----
  const char* vrs =
      "{\n"
      "   \"steamvr\" : {\n"
      "      \"activateMultipleDrivers\" : true,\n"
      "      \"forcedDriver\" : \"oculus\",\n"
      "      \"enableHomeApp\" : false,\n"
      "      \"supersampleScale\" : 1.0\n"
      "   },\n"
      "   \"driver_oculus\" : {\n"
      "      \"enable\" : false,\n"
      "      \"blocked_by_safe_mode\" : true\n"
      "   },\n"
      "   \"driver_vd\" : {\n"
      "      \"enable\" : true,\n"
      "      \"blocked_by_safe_mode\" : false\n"
      "   },\n"
      "   \"driver_lighthouse\" : {\n"
      "      \"blocked_by_safe_mode\" : true,\r\n"
      "      \"enable\" : false\r\n"
      "   },\n"
      "   \"dashboard\" : {\n"
      "      \"enableDashboard\" : true\n"
      "   }\n"
      "}\n";
  Got g; memset(&g, 0, sizeof(g));
  svr::SettingsSummary sum;
  svr::scan_vrsettings(vrs, (int)strlen(vrs), 60, sink, &g, &sum);
  CHECK(sum.blocked == 2);           // oculus + lighthouse (the false one does not count)
  CHECK(sum.off == 2);               // oculus + lighthouse enable=false
  CHECK(sum.sectionCount == 5);
  CHECK(strcmp(sum.driverSections, "driver_oculus driver_vd driver_lighthouse") == 0);
  bool sawForced = false, sawOculusBlocked = false, sawLighthouseOff = false, sawHome = false;
  for (int i = 0; i < g.n; ++i) {
    if (!strcmp(g.sec[i], "steamvr") && strstr(g.line[i], "forcedDriver")) sawForced = true;
    if (!strcmp(g.sec[i], "driver_oculus") && strstr(g.line[i], "blocked_by_safe_mode") && strstr(g.line[i], "true")) sawOculusBlocked = true;
    if (!strcmp(g.sec[i], "driver_lighthouse") && strstr(g.line[i], "\"enable\"") && strstr(g.line[i], "false") && !strchr(g.line[i], '\r')) sawLighthouseOff = true;
    if (strstr(g.line[i], "enableHomeApp")) sawHome = true;       // not an "enable" key: must not be reported
  }
  CHECK(sawForced && sawOculusBlocked && sawLighthouseOff && !sawHome);
  // the shown-lines cap
  memset(&g, 0, sizeof(g));
  svr::scan_vrsettings(vrs, (int)strlen(vrs), 2, sink, &g, &sum);
  CHECK(g.n == 2 && sum.shown == 2 && sum.blocked == 2);        // counted in full even when not all are shown
  // empty / junk input
  memset(&g, 0, sizeof(g));
  svr::scan_vrsettings("", 0, 60, sink, &g, &sum);
  CHECK(g.n == 0 && sum.blocked == 0 && sum.off == 0 && sum.driverSections[0] == 0);
  svr::scan_vrsettings("\x01\x02 junk without newlines", 22, 60, sink, &g, &sum);
  CHECK(g.n == 0);

  // ---- log filter: newest matching lines, in order ----
  char logtxt[4096];
  logtxt[0] = 0;
  for (int i = 0; i < 100; ++i) {
    char l[100];
    if (i % 10 == 0) snprintf(l, sizeof(l), "Mon Oct 12 - line %d: driver oculus failed to load\n", i);
    else snprintf(l, sizeof(l), "Mon Oct 12 - line %d: all fine\n", i);
    strcat(logtxt, l);
  }
  svr::Match keep[5]; int kept = 0;
  int total = svr::collect_matches(logtxt, (int)strlen(logtxt), svr::kLogWords, keep, 5, &kept);
  CHECK(total == 10 && kept == 5);
  CHECK(strncmp(keep[0].start, "Mon Oct 12 - line 50:", 21) == 0);
  CHECK(strncmp(keep[4].start, "Mon Oct 12 - line 90:", 21) == 0);
  total = svr::collect_matches(logtxt, 0, svr::kLogWords, keep, 5, &kept);
  CHECK(total == 0 && kept == 0);
  total = svr::collect_matches("An Add-On was BLOCKED because of a crash\r\nnothing here\r\n", 52, svr::kLogWords, keep, 5, &kept);
  CHECK(total == 1 && kept == 1 && svr::ci_has(keep[0].start, keep[0].len, "blocked"));
  char cl[40];
  svr::clean_line(cl, "   \tab\tc\r\nrest", 14, sizeof(cl));
  CHECK(strcmp(cl, "ab c") == 0);
  svr::clean_line(cl, "0123456789", 10, 5);
  CHECK(strcmp(cl, "0123") == 0);

  // ---- error codes ----
  CHECK(svr::ci_has("Hello World", 11, "o w") && !svr::ci_has("Hello", 5, "world"));
  CHECK(!svr::retryable(100) && !svr::retryable(105) && !svr::retryable(112) && !svr::retryable(168) && !svr::retryable(130));
  CHECK(svr::retryable(108) && svr::retryable(126) && svr::retryable(306) && svr::retryable(1114) && svr::retryable(436));
  CHECK(svr::max_attempts(1114) == 2 && svr::max_attempts(108) == 3 && svr::max_attempts(1200) == 3);
  CHECK(strstr(svr::hint_short(1114), "Oculus") && strstr(svr::hint_long(1114), "Manage Add-Ons"));
  CHECK(strstr(svr::hint_short(108), "headset") && strstr(svr::hint_long(121), "Virtual Desktop"));
  CHECK(strstr(svr::hint_short(436), "compositor") && strstr(svr::hint_short(205), "driver") && strstr(svr::hint_short(9999), "STEAMVR"));
  for (int e = 0; e < 1500; ++e) CHECK(svr::hint_short(e)[0] && svr::hint_long(e)[0] && strlen(svr::hint_short(e)) < 100);   // the short hint fits the status line

  if (fails) { printf("%d FAILED\n", fails); return 1; }
  printf("steamvr: all checks passed\n");
  return 0;
}
