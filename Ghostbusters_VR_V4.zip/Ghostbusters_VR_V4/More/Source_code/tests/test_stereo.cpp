// Unit tests for the 0.21 stereo math (src/stereomath.h, head position in src/headmath.h).
// Build: g++ -std=c++17 -O1 -o tests/test_stereo tests/test_stereo.cpp && tests/test_stereo
#include "../src/headmath.h"
#include "../src/stereomath.h"
#include <cmath>
#include <cstdio>
static int fails;
static void check(const char* name, bool ok, double v = 0) { printf("%s %s (%.6g)\n", ok ? "PASS" : "FAIL", name, v); fails += !ok; }
static void rotY(double t, float* o) { double s = sin(t), c = cos(t); float r[9] = {(float)c, 0, (float)s, 0, 1, 0, (float)-s, 0, (float)c}; for (int i = 0; i < 9; i++) o[i] = r[i]; }
static void rotX(double t, float* o) { double s = sin(t), c = cos(t); float r[9] = {1, 0, 0, 0, (float)c, (float)-s, 0, (float)s, (float)c}; for (int i = 0; i < 9; i++) o[i] = r[i]; }

// Model of the game's SetProjection for mode 0 (ghost.exe 0x302520): returns tanH, tanV.
static void game_projection(double zoom, double aspect, double* tanH, double* tanV) {
  double y = zoom;                      // xmm1
  if (aspect > 4.0 / 3.0) y = (4.0 / 3.0) / aspect * zoom;
  double x = y * aspect;                // xmm6
  *tanH = 1.0 / y;                      // 0x236BB54 = 1/scaleX
  *tanV = 1.0 / x;                      // 0x236BB58 = 1/scaleY
}

int main() {
  // ---- engine basis: logged sample from probe 0.20 (frame 1260) ----
  // SOURCEINPUT pitch=0.226168692 yaw=0.953896165; YAWORIGINAL = engine basis
  const float M[9] = {0.57850951f, 0.18291156f, 0.794902623f, 0, 0.974532723f, -0.224245444f, -0.815675676f, 0.129728124f, 0.563776433f};
  double yaw = 0.953896165;
  float L[9]; stereo::level_basis(yaw, L);
  check("level basis right column = engine right column", fabs(L[0] - M[0]) < 1e-6 && fabs(L[3] - M[3]) < 1e-6 && fabs(L[6] - M[6]) < 1e-6, L[0]);
  double fh = hypot(M[2], M[8]);
  check("level basis forward = engine forward flattened", fabs(L[2] - M[2] / fh) < 1e-6 && fabs(L[8] - M[8] / fh) < 1e-6 && L[5] == 0, L[2]);
  check("level basis is a rotation", vm::is_rotation(L, 1e-6), vm::det(L));
  double y2 = 0; int okYaw = stereo::basis_yaw(M, &y2);
  check("basis_yaw recovers the camera yaw field", okYaw && stereo::angle_diff(y2, yaw) < 1e-6, y2);
  float down[9] = {1, 0, 0, 0, 0, 1, 0, -1, 0};  // looking straight down
  check("basis_yaw rejects straight down", !stereo::basis_yaw(down, &y2));
  check("angle_diff wraps", fabs(stereo::angle_diff(3.1, -3.1) - (2 * M_PI - 6.2)) < 1e-9);

  // ---- eye position ----
  float base[3] = {10, 5, 20}, I[9], out[3]; vm::identity(I);
  stereo::eye_position(base, I, I, nullptr, -0.105, out);
  check("left eye is on the -right side (yaw 0: -x)", fabs(out[0] - 9.895f) < 1e-5 && out[1] == 5 && out[2] == 20, out[0]);
  float L90[9]; stereo::level_basis(M_PI / 2, L90);  // forward = +x, right = -z
  stereo::eye_position(base, L90, L90, nullptr, 0.105, out);
  check("right eye at yaw 90 deg is at -z", fabs(out[2] - 19.895f) < 1e-5 && fabs(out[0] - 10) < 1e-5, out[2]);
  // forward x right must be consistent with a left-handed frame: right = up x forward
  float f[3] = {L90[2], L90[5], L90[8]}, r[3] = {L90[0], L90[3], L90[6]};
  double cx = 1 * f[2] - 0 * f[1], cz = 0 * f[1] - 1 * f[0];  // (0,1,0) x forward
  check("right = up x forward (left-handed, like the engine)", fabs(cx - r[0]) < 1e-6 && fabs(cz - r[2]) < 1e-6, cx);
  // head rolled 90 deg to the left: the left eye is below the right eye
  float rollL[9] = {0, -1, 0, 1, 0, 0, 0, 0, 1};  // engine-local: right axis -> up... columns right,up,fwd
  float view[9]; vm::mul(I, rollL, view);
  float le[3], re[3];
  stereo::eye_position(base, I, view, nullptr, -0.105, le); stereo::eye_position(base, I, view, nullptr, 0.105, re);
  check("eye offset follows the head's own right axis (roll)", fabs(le[0] - re[0]) < 1e-6 && fabs(fabs(le[1] - re[1]) - 0.21) < 1e-5, le[1] - re[1]);
  // head position: 1 ft right, 2 ft up, 3 ft forward at yaw 90 (forward +x, right -z)
  float hp[3] = {1, 2, 3};
  stereo::eye_position(base, L90, L90, hp, 0, out);
  check("head position uses the level basis", fabs(out[0] - 13) < 1e-5 && fabs(out[1] - 7) < 1e-5 && fabs(out[2] - 19) < 1e-5, out[0]);

  // ---- head position from an OpenVR pose ----
  float H0[9], Y[9]; rotY(37 * M_PI / 180, H0); make_yaw_reference(H0, Y);
  float ref[3] = {0.5f, 1.6f, -0.3f};
  // unit vectors of the recentered frame in tracking space: right = Y*(1,0,0), forward = Y*(0,0,-1)
  float rightT[3] = {Y[0], Y[3], Y[6]}, fwdT[3] = {-Y[2], -Y[5], -Y[8]};
  float pose[12] = {0};
  for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) pose[i * 4 + j] = H0[i * 3 + j];
  for (int i = 0; i < 3; i++) pose[i * 4 + 3] = ref[i] + 0.10f * rightT[i] + 0.20f * fwdT[i] + (i == 1 ? 0.05f : 0);
  float hpos[3]; gbvr_head_pos_to_engine(pose, Y, ref, hpos);
  check("head 10 cm right / 5 cm up / 20 cm forward -> engine x,y,z", fabs(hpos[0] - 0.10) < 1e-5 && fabs(hpos[1] - 0.05) < 1e-5 && fabs(hpos[2] - 0.20) < 1e-5, hpos[2]);
  float Hc[9]; pose34_rotation(pose, Hc); double e = 0; for (int i = 0; i < 9; i++) e = fmax(e, fabs(Hc[i] - H0[i]));
  check("pose34_rotation", e == 0);

  // ---- field of view ----
  double tH, tV; game_projection(23.0 / 18.0, 2560.0 / 1440.0, &tH, &tV);
  check("game default 16:9: tanV 0.587 (60.8 deg), tanH 1.043 (92.4 deg)", fabs(tV - 0.58696) < 1e-4 && fabs(tH - 1.04348) < 1e-4, tV);
  // Rift S numbers quoted in OpenComposite's notes (raw order left,right,top,bottom): -0.965689 1.035530 -1.150368 1.000000
  // Quest-like asymmetric example for both eyes:
  float l[2] = {-1.376f, -0.839f}, rr[2] = {0.839f, 1.376f}, t[2] = {-1.428f, -1.428f}, b[2] = {0.966f, 0.966f};
  double nH, nV; stereo::required_fov(l, rr, t, b, &nH, &nV);
  check("required fov = largest edge of either eye", fabs(nH - 1.376) < 1e-6 && fabs(nV - 1.428) < 1e-6, nV);
  double aspect = tH / tV;
  double target = stereo::game_tan_v(nH, nV, aspect);
  check("16:9 frame: vertical need decides", fabs(target - 1.428) < 1e-6, target);
  check("tall frame: horizontal need decides", fabs(stereo::game_tan_v(1.376, 0.5, 1.0) - 1.376) < 1e-9);
  double zoom = 23.0 / 18.0, zoomOut = zoom * tV / target, tH1, tV1;
  game_projection(zoomOut, 2560.0 / 1440.0, &tH1, &tV1);
  check("zoom scaled by tanV0/target gives the target (engine model)", fabs(tV1 - target) < 1e-9 && fabs(tH1 - target * aspect) < 1e-9, tV1);
  game_projection(zoom * 0.9 * 0.9 / 0.9, 1.25, &tH, &tV);  // 5:4 window: other branch of the engine
  double z2 = zoom * 0.9 * tV / 1.3; game_projection(z2, 1.25, &tH1, &tV1);
  check("same rule in the engine's narrow-aspect branch", fabs(tV1 - 1.3) < 1e-9, tV1);

  // ---- texture bounds: every direction an eye can see lands on the same pixel of the game frame ----
  game_projection(zoomOut, 2560.0 / 1440.0, &tH, &tV);
  double worst = 0; int inside = 1;
  for (int eye = 0; eye < 2; eye++) {
    float bd[4]; inside &= stereo::texture_bounds(l[eye], rr[eye], t[eye], b[eye], tH, tV, bd);
    for (int i = 0; i <= 10; i++) for (int j = 0; j <= 10; j++) {
      double tx = l[eye] + (rr[eye] - l[eye]) * i / 10.0;            // tangent to the right
      double ty = t[eye] + (b[eye] - t[eye]) * j / 10.0;             // tangent upward ("top" raw value = lower edge)
      // where the game draws this direction (symmetric frustum, row 0 at the top)
      double gu = 0.5 + 0.5 * tx / tH, gv = 0.5 - 0.5 * ty / tV;
      // where the compositor samples for it: eye image u from left edge, v from the upper edge (ty = bottom raw)
      double eu = (tx - l[eye]) / (rr[eye] - l[eye]), ev = (b[eye] - ty) / (b[eye] - t[eye]);
      double su = bd[0] + eu * (bd[2] - bd[0]), sv = bd[1] + ev * (bd[3] - bd[1]);
      worst = fmax(worst, fmax(fabs(su - gu), fabs(sv - gv)));
    }
    printf("  eye %d bounds u %.4f..%.4f v %.4f..%.4f -> %d x %d px of 2560x1440\n", eye, bd[0], bd[2], bd[1], bd[3],
           (int)((bd[2] - bd[0]) * 2560), (int)((bd[3] - bd[1]) * 1440));
  }
  check("texture bounds map every eye direction to the game's pixel", worst < 1e-6 && inside, worst);
  float bd[4];
  check("bounds report a frame that is too small", !stereo::texture_bounds(-1.376, 0.839, -1.428, 0.966, 1.0, 0.587, bd) && bd[0] == 0 && bd[3] == 1);
  // more view downward than upward => the eye window sits low in the frame (larger v)
  stereo::texture_bounds(l[0], rr[0], t[0], b[0], tH, tV, bd);
  check("downward-heavy headset uses the lower part of the frame", (bd[1] + bd[3]) / 2 > 0.5, (bd[1] + bd[3]) / 2);
  float bdR[4]; stereo::texture_bounds(l[1], rr[1], t[1], b[1], tH, tV, bdR);
  check("left eye window is left of centre, right eye window right of centre",
        (bd[0] + bd[2]) / 2 < 0.5 && (bdR[0] + bdR[2]) / 2 > 0.5 && fabs((bd[0] + bd[2]) / 2 + (bdR[0] + bdR[2]) / 2 - 1) < 1e-6,
        (bdR[0] + bdR[2]) / 2);

  // ---- independent check of the top/bottom convention ----
  // Valve's documented ComposeProjection (OpenVR wiki, IVRSystem::GetProjectionRaw) builds the eye's own
  // projection from the raw values: idy = 1/(bottom - top), sy = bottom + top, P[1][1] = 2*idy,
  // P[1][2] = sy*idy, P[3][2] = -1 (OpenGL style: eye space y up, looking along -z, NDC y = +1 is the
  // top of the eye's picture). A point at up-tangent ty and depth d therefore lands at
  //   yNdc = (2*idy*(ty*d) + sy*idy*(-d)) / d = idy * (2*ty - sy)
  // The compositor shows a Direct3D texture with row vMin at the top of the eye's picture, so that point
  // is sampled at v = vMin + (1 - yNdc)/2 * (vMax - vMin). It must be the row where the game drew it.
  worst = 0;
  for (int eye = 0; eye < 2; eye++) {
    float q[4]; stereo::texture_bounds(l[eye], rr[eye], t[eye], b[eye], tH, tV, q);
    double idy = 1.0 / (b[eye] - t[eye]), sy = b[eye] + t[eye], idx = 1.0 / (rr[eye] - l[eye]), sx = rr[eye] + l[eye];
    for (double ty = -1.4; ty <= 0.95; ty += 0.05) for (double tx = l[eye]; tx <= rr[eye]; tx += 0.1) {
      double yNdc = idy * (2 * ty - sy), xNdc = idx * (2 * tx - sx);
      double sv = q[1] + (1 - yNdc) / 2 * (q[3] - q[1]), su = q[0] + (xNdc + 1) / 2 * (q[2] - q[0]);
      double gv = 0.5 - 0.5 * ty / tV, gu = 0.5 + 0.5 * tx / tH;   // game frame: symmetric frustum, row 0 = up
      worst = fmax(worst, fmax(fabs(sv - gv), fabs(su - gu)));
    }
  }
  check("bounds agree with Valve's ComposeProjection for the raw values", worst < 1e-6, worst);
  // and the straight-ahead direction (0,0) must be drawn at the centre of the game frame for both eyes
  {
    float q[4]; stereo::texture_bounds(l[0], rr[0], t[0], b[0], tH, tV, q);
    double idy = 1.0 / (b[0] - t[0]), sy = b[0] + t[0];
    double v0 = q[1] + (1 - idy * (0 - sy)) / 2 * (q[3] - q[1]);
    check("straight ahead is the centre row of the game frame", fabs(v0 - 0.5) < 1e-6, v0);
  }

  // ---- flat screen placement ----
  float Hh[9], Hp[9], Hq[9]; rotY(30 * M_PI / 180, Hh); rotX(-0.4, Hp); vm::mul(Hh, Hp, Hq);  // looking 30 deg left, a bit down
  float p34[12]; for (int i = 0; i < 3; i++) { for (int j = 0; j < 3; j++) p34[i * 4 + j] = Hq[i * 3 + j]; }
  p34[3] = 1; p34[7] = 1.5f; p34[11] = 2;
  float Ys[9], xf[12]; make_yaw_reference(Hq, Ys); stereo::flat_screen_transform(p34, Ys, 2.5, 0.1, xf);
  double fwd[3] = {-Hh[2], 0, -Hh[8]};  // level heading
  check("screen centre is 2.5 m along the level heading, 10 cm below eye level",
        fabs(xf[3] - (1 + 2.5 * fwd[0])) < 1e-5 && fabs(xf[7] - 1.4) < 1e-5 && fabs(xf[11] - (2 + 2.5 * fwd[2])) < 1e-5, xf[3]);
  double nrm[3] = {xf[2], xf[6], xf[10]}, toHead[3] = {1 - xf[3], 1.5 - xf[7], 2 - xf[11]};
  check("screen faces the viewer and is upright", nrm[0] * toHead[0] + nrm[1] * toHead[1] + nrm[2] * toHead[2] > 2.4 && fabs(xf[5] - 1) < 1e-6);

  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails;
}
