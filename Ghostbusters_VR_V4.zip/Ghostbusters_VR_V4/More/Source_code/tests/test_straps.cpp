#include <cstdio>
#include "vmath.h"
#include "cordmath.h"
#include "rigmath.h"
int main() {
  rig::Snap s; s.clear(); s.have = 1; s.fpm = 3.28084f;
  auto set = [&](int j, float r, float u, float f) { s.ok[j] = 1; s.j[j][0] = r; s.j[j][1] = u; s.j[j][2] = f; };
  set(rig::J_SHR, 0.55f, -0.8f, 0); set(rig::J_SHL, -0.55f, -0.8f, 0); set(rig::J_NECK, 0, -0.55f, 0); set(rig::J_SPINE3, 0, -1.2f, 0);
  s.packOk = 1; s.pack[0] = 0; s.pack[1] = -1.6f; s.pack[2] = -0.5f;
  const double head[3] = {0, 1.6, 0}, Rh[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  static cord::V v[800];
  int n = rig::build_straps(s, head, Rh, v, 800);
  int bad = 0;
  if (n <= 0 || n % 3) { printf("FAIL count %d\n", n); ++bad; }
  for (int i = 0; i < n; ++i) for (int k = 0; k < 3; ++k) if (!(v[i].p[k] == v[i].p[k]) || v[i].p[k] > 10 || v[i].p[k] < -10) { printf("FAIL vertex %d\n", i); ++bad; i = n; break; }
  // all inside a 2 m box around the head
  for (int i = 0; i < n; ++i) if (v[i].p[1] > 1.7 + 0.2 || v[i].p[1] < 0.3) { printf("FAIL height %f\n", v[i].p[1]); ++bad; break; }
  rig::Snap t = s; t.packOk = 0;
  if (rig::build_straps(t, head, Rh, v, 800) != 0) { printf("FAIL nopack\n"); ++bad; }
  t = s; t.ok[rig::J_SHL] = 0;
  if (rig::build_straps(t, head, Rh, v, 800) != 0) { printf("FAIL nosh\n"); ++bad; }
  if (rig::build_straps(s, head, Rh, v, 30) != 0) { printf("FAIL cap\n"); ++bad; }
  printf(bad ? "straps FAILED (%d)\n" : "straps ok (%d vertices)\n", bad ? bad : n);
  return bad;
}
