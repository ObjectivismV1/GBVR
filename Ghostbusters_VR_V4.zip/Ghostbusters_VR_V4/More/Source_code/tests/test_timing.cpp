#include <assert.h>
#include <stdio.h>
#include <limits>
#include "timingmath.h"
int main() {
  assert(!gbvr_frame_reused(0, 1));
  assert(!gbvr_frame_reused(4, 1));
  assert(!gbvr_frame_reused(12, 1));
  assert(gbvr_frame_reused(5, 1));
  assert(gbvr_frame_reused(6, 1));
  assert(gbvr_frame_reused(4, 2));
  assert(gbvr_display_hz10(0, 90) == 900);
  assert(gbvr_display_hz10(0, 96) == 960);
  assert(gbvr_display_hz10(0, 119.88f) == 1199);
  assert(!gbvr_display_hz10(1, 90));
  assert(!gbvr_display_hz10(0, std::numeric_limits<float>::quiet_NaN()));
  puts("PASS OpenVR timing: real display rate and reuse reasons");
}
