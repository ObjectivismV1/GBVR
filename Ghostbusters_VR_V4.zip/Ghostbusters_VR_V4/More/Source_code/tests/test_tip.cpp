// Unit tests for tipmath.h (0.41).
#include <stdio.h>
#include <math.h>
#include "tipmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double trip(const float* m) {   // row0 x row1 . row2
  double a[3] = {m[0], m[1], m[2]}, b[3] = {m[4], m[5], m[6]}, c[3] = {m[8], m[9], m[10]};
  double x[3] = {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
  return x[0] * c[0] + x[1] * c[1] + x[2] * c[2];
}
int main() {
  for (int a = 0; a < 3; ++a) for (int s = 0; s < 2; ++s) for (int h = 0; h < 2; ++h) {
    float m[16] = {0};
    m[0] = 1; m[5] = 1; m[10] = h ? -1.f : 1.f; m[12] = 5; m[13] = 6; m[14] = 7; m[15] = 1;   // identity or mirrored
    double d[3] = {0.3, 0.5, -0.8}; double l = sqrt(d[0]*d[0] + d[1]*d[1] + d[2]*d[2]); for (int j = 0; j < 3; ++j) d[j] /= l;
    double t0 = trip(m);
    CHECK(tipmath::rewrite_row(m, a, s ? -1.0 : 1.0, d));
    double sg = s ? -1.0 : 1.0;
    for (int j = 0; j < 3; ++j) CHECK(fabs(m[a * 4 + j] - sg * d[j]) < 1e-5);          // axis a is the aim
    CHECK(fabs(trip(m) - t0) < 1e-4);                                                    // handedness and scale kept
    double r0 = 0, r1 = 0, r2 = 0;
    for (int j = 0; j < 3; ++j) { r0 += m[j] * m[4 + j]; r1 += m[j] * m[8 + j]; r2 += m[4 + j] * m[8 + j]; }
    CHECK(fabs(r0) < 1e-5 && fabs(r1) < 1e-5 && fabs(r2) < 1e-5);                     // still orthogonal
    CHECK(m[12] == 5 && m[13] == 6 && m[14] == 7 && m[15] == 1);                       // translation untouched
  }
  // 0.45: the game measures the stream angles in the tip frame from row 2 (+Z): after rewriting row 2 to the aim, whatever
  // pose the game's matrix had, the aim must read as heading 0 / pitch 0 (the stream then goes straight along the aim).
  for (int k = 0; k < 40; ++k) {
    float m[16] = {0};
    // an arbitrary rotation: row 0 = -aim-ish idle pose (as learnt by 0.41), rows built orthonormal from a seed
    double a = 0.3 + 0.37 * k, b = 0.9 - 0.11 * k;
    double r0[3] = {cos(a) * cos(b), sin(b), sin(a) * cos(b)}, up[3] = {0.1, 1.0, 0.2};
    double r2[3] = {r0[1] * up[2] - r0[2] * up[1], r0[2] * up[0] - r0[0] * up[2], r0[0] * up[1] - r0[1] * up[0]};
    double l2 = sqrt(r2[0]*r2[0] + r2[1]*r2[1] + r2[2]*r2[2]); for (int j = 0; j < 3; ++j) r2[j] /= l2;
    double r1[3] = {r2[1] * r0[2] - r2[2] * r0[1], r2[2] * r0[0] - r2[0] * r0[2], r2[0] * r0[1] - r2[1] * r0[0]};
    for (int j = 0; j < 3; ++j) { m[j] = (float)r0[j]; m[4 + j] = (float)r1[j]; m[8 + j] = (float)r2[j]; }
    m[15] = 1;
    double d[3] = {sin(0.7 * k) * 0.8, cos(0.3 * k) * 0.5 - 0.1, -0.6 + 0.03 * k};
    double l = sqrt(d[0]*d[0] + d[1]*d[1] + d[2]*d[2]); for (int j = 0; j < 3; ++j) d[j] /= l;
    CHECK(tipmath::rewrite_row(m, 2, 1.0, d));
    double lx = d[0]*m[0] + d[1]*m[1] + d[2]*m[2], ly = d[0]*m[4] + d[1]*m[5] + d[2]*m[6], lz = d[0]*m[8] + d[1]*m[9] + d[2]*m[10];
    double heading = atan2(lx, lz), pitch = -atan2(ly, sqrt(lx*lx + lz*lz));
    CHECK(fabs(heading) < 1e-4 && fabs(pitch) < 1e-4 && lz > 0.9999);
  }
  { float m[16] = {0}; m[0] = m[5] = m[10] = 2; double d[3] = {1, 0, 0};              // scaled matrix, aim already along row 0
    CHECK(tipmath::rewrite_row(m, 0, 1.0, d)); CHECK(fabs(m[0] - 2) < 1e-5 && fabs(m[5] - 2) < 1e-5 && fabs(m[10] - 2) < 1e-5); }
  { float m[16] = {0}; double d[3] = {0, 0, 1}; CHECK(!tipmath::rewrite_row(m, 0, 1.0, d)); }   // zero matrix refused
  { float m[16] = {0}; m[0] = m[5] = m[10] = 1; m[1] = NAN; double d[3] = {0, 0, 1}; CHECK(!tipmath::rewrite_row(m, 0, 1.0, d)); }
  { // the learner picks the row that follows the aim, with its sign, and refuses when nothing follows it
    for (int a = 0; a < 3; ++a) for (int sg = 0; sg < 2; ++sg) {
      tipmath::Learner L; L.reset();
      for (int k = 0; k < 300; ++k) {
        double ang = k * 0.07;
        double aim[3] = {cos(ang), 0.2, sin(ang)}; double l = sqrt(aim[0]*aim[0] + aim[1]*aim[1] + aim[2]*aim[2]); for (int j = 0; j < 3; ++j) aim[j] /= l;
        float m[16] = {0}; m[0] = m[5] = m[10] = 1;                       // axes fixed ...
        float q = sg ? -1.f : 1.f; m[a * 4] = q * (float)aim[0]; m[a * 4 + 1] = q * (float)aim[1]; m[a * 4 + 2] = q * (float)aim[2]; // ... except row a, which follows the aim
        L.add(m, aim);
      }
      double b, s2; int best = L.decide(&b, &s2, 0.8, 0.3);
      CHECK(best == a + (sg ? 3 : 0));
      CHECK(b > 0.99);
    }
    tipmath::Learner N; N.reset();
    for (int k = 0; k < 300; ++k) { double aim[3] = {cos(k * 0.3), sin(k * 0.3), 0}; float m[16] = {0}; m[0] = m[5] = m[10] = 1; N.add(m, aim); }
    double b, s2; CHECK(N.decide(&b, &s2, 0.8, 0.3) < 0);                 // fixed axes, aim sweeping around: no winner
  }
  printf(fails ? "FAILED\n" : "ALL PASS\n");
  return fails != 0;
}
