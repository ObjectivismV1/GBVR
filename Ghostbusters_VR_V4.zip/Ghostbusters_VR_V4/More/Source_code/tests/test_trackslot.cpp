// 1.7.116 the enemy record table (trackslot.h): a known ghost keeps its slot, a new one takes a free slot, then the stalest one, and never one used in the same scan (a spare slot instead).
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "trackslot.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
struct Rec { uintptr_t id; int64_t useQ; int mark; };

int main() {
  const int N = 4;
  Rec t[N + 1]; memset(t, 0, sizeof(t));
  int fresh, ev, used;
  // 1. empty table: new ghosts take slots 0, 1, 2 in order; asking again gives the same slot, not fresh
  CHECK(trackslot::pick(t, N, 0x1000, 1, &fresh, &ev, &used) == 0 && fresh && !ev && used == 0);
  CHECK(trackslot::pick(t, N, 0x2000, 1, &fresh, &ev, &used) == 1 && fresh && !ev && used == 1);
  CHECK(trackslot::pick(t, N, 0x3000, 1, &fresh, &ev, &used) == 2 && fresh && !ev && used == 2);
  t[1].mark = 77;
  CHECK(trackslot::pick(t, N, 0x2000, 2, &fresh, &ev, &used) == 1 && !fresh && !ev && t[1].mark == 77 && t[1].useQ == 2);   // known: the record is kept, its use time moves on
  // 2. the table fills; a fifth ghost in a LATER scan takes the stalest slot (the one not used for the longest time), the others stay
  CHECK(trackslot::pick(t, N, 0x4000, 2, &fresh, &ev, &used) == 3 && fresh && !ev);
  t[0].useQ = 1; t[2].useQ = 1;                                  // 0x1000 and 0x3000 were last used at scan 1 (they left the list), 0x2000 / 0x4000 at scan 2
  t[2].mark = 5; t[0].mark = 9;
  const int s5 = trackslot::pick(t, N, 0x5000, 3, &fresh, &ev, &used);
  CHECK((s5 == 0 || s5 == 2) && fresh && ev && used == 4);        // one of the two stale slots
  CHECK(t[s5].id == 0x5000 && t[s5].useQ == 3);
  CHECK(t[1].mark == 77 && t[1].id == 0x2000 && t[3].id == 0x4000);   // the live ones were not touched
  // 3. every slot used in THIS scan and a new ghost comes: it gets the spare slot (index N); nobody's record is taken
  { Rec u2[N + 1]; memset(u2, 0, sizeof(u2));
    for (int i = 0; i < N; ++i) trackslot::pick(u2, N, 0x100 + i, 10, &fresh, &ev, &used);
    for (int i = 0; i < N; ++i) u2[i].mark = 100 + i;
    const int sp = trackslot::pick(u2, N, 0x900, 10, &fresh, &ev, &used);
    CHECK(sp == N && fresh && !ev);
    for (int i = 0; i < N; ++i) CHECK(u2[i].mark == 100 + i && u2[i].id == (uintptr_t)(0x100 + i));
    const int sp2 = trackslot::pick(u2, N, 0x901, 10, &fresh, &ev, &used);     // another one in the same scan: the spare again
    CHECK(sp2 == N && fresh);
  }
  // 4. a table too small for the enemies: the ghosts that got slots keep them from scan to scan (the 1.7.115 table made the two last ones reset each other each scan)
  { Rec u3[N + 1]; memset(u3, 0, sizeof(u3));
    const uintptr_t ids[6] = {0xA0, 0xB0, 0xC0, 0xD0, 0xE0, 0xF0};
    int stable = 1;
    for (int scan = 1; scan <= 20; ++scan) {
      for (int k = 0; k < 6; ++k) {
        const int sl = trackslot::pick(u3, N, ids[k], scan, &fresh, &ev, &used);
        if (k < N) { if (scan > 1 && fresh) stable = 0; if (scan == 1 && !fresh) stable = 0; if (sl != k) stable = 0; }
        else if (sl != N) stable = 0;
      }
    }
    CHECK(stable);
  }
  // 5. the long session: ghosts come and go (a new set every "level"): the old ones are replaced, nothing sticks for good
  { Rec u4[N + 1]; memset(u4, 0, sizeof(u4));
    int64_t now = 0; int bad = 0;
    for (int level = 0; level < 50; ++level) {
      for (int rep = 0; rep < 5; ++rep) {
        ++now;
        for (int k = 0; k < 3; ++k) {
          const uintptr_t id = 0x10000 + level * 0x100 + k * 0x10;
          const int sl = trackslot::pick(u4, N, id, now, &fresh, &ev, &used);
          if (sl == N) ++bad;                                   // the spare slot must not be needed: only 3 ghosts live at a time
          if (rep > 0 && fresh) ++bad;                          // within a level the records are kept
        }
      }
    }
    CHECK(bad == 0);
  }
  if (fails) { printf("%d failures\n", fails); return 1; }
  printf("trackslot: ok\n");
  return 0;
}
