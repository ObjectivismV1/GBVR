// 1.7.212: stress test of the math added in 1.7.209-211 that can be tested without the game:
// (1) trap-hand roll: rotates the glove's up about its pointing line, keeps it a unit vector perpendicular to the pointing line, never NaN, for any pointing/up incl. degenerate ones
// (2) look-down smoothstep used to release the 30 deg chest cap
// (3) wrap_pi signed difference
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include "../src/bodymath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { ++fails; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static void unit(double* v) { double l = std::sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]); if (l > 1e-12) for (int i = 0; i < 3; ++i) v[i] /= l; }
static double dot(const double* a, const double* b) { return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]; }
static void roll(const double* f, const double* u, double deg, double* o) {   // same formula as engine_hooks.cpp TRAPROLL
  const double sd[3] = {f[1]*u[2] - f[2]*u[1], f[2]*u[0] - f[0]*u[2], f[0]*u[1] - f[1]*u[0]};
  const double r = deg * 3.14159265358979 / 180.0, s = std::sin(r), c = std::cos(r);
  for (int i = 0; i < 3; ++i) o[i] = u[i] * c - sd[i] * s;
}
static void yaw(const double* f, const double* u, double deg, double* o) {   // same formula as engine_hooks.cpp TRAPROLL (1.7.212: the pointing line turns about the controller's up = the handle line)
  const double sd[3] = {f[1]*u[2] - f[2]*u[1], f[2]*u[0] - f[0]*u[2], f[0]*u[1] - f[1]*u[0]};
  const double r = deg * 3.14159265358979 / 180.0, s = std::sin(r), c = std::cos(r);
  for (int i = 0; i < 3; ++i) o[i] = f[i] * c - sd[i] * s;
}
static double dk_of(double pitchDeg) { double dk = (pitchDeg - 20.0) / 40.0; dk = dk < 0 ? 0 : (dk > 1 ? 1 : dk); return dk * dk * (3.0 - 2.0 * dk); }
int main() {
  srand(7);
  double maxErrLen = 0, maxErrPerp = 0, maxAngErr = 0; int bad = 0;
  for (int n = 0; n < 200000; ++n) {
    double f[3], u[3];
    for (int i = 0; i < 3; ++i) { f[i] = (rand() / (double)RAND_MAX) * 2 - 1; u[i] = (rand() / (double)RAND_MAX) * 2 - 1; }
    unit(f);
    const double k = dot(u, f); for (int i = 0; i < 3; ++i) u[i] -= k * f[i];   // controller up is perpendicular to its pointing
    double l = std::sqrt(dot(u, u)); if (l < 1e-6) continue; unit(u);
    double y[3]; yaw(f, u, 30.0, y);
    if (!std::isfinite(y[0] + y[1] + y[2]) || std::fabs(std::sqrt(dot(y, y)) - 1.0) > 1e-9 || std::fabs(dot(y, u)) > 1e-9 || std::fabs(std::acos(std::fmin(1.0, std::fmax(-1.0, dot(y, f)))) * 180.0 / 3.14159265358979 - 30.0) > 1e-6) ++bad;   // the handle line (up) never moves, the pointing turns exactly 30 deg
    double o[3]; roll(f, u, 30.0, o);
    if (!std::isfinite(o[0] + o[1] + o[2])) { ++bad; continue; }
    maxErrLen = std::fmax(maxErrLen, std::fabs(std::sqrt(dot(o, o)) - 1.0));
    maxErrPerp = std::fmax(maxErrPerp, std::fabs(dot(o, f)));
    maxAngErr = std::fmax(maxAngErr, std::fabs(std::acos(std::fmin(1.0, std::fmax(-1.0, dot(o, u)))) * 180.0 / 3.14159265358979 - 30.0));
  }
  std::printf("roll 30 deg over 200000 random poses: not finite %d, length error %.2e, tilt out of the plane %.2e, angle error %.2e deg\n", bad, maxErrLen, maxErrPerp, maxAngErr);
  CHECK(bad == 0 && maxErrLen < 1e-9 && maxErrPerp < 1e-9 && maxAngErr < 1e-6);
  { const double f[3] = {0, 0, 1}, u[3] = {0, 1, 0}; double o[3]; roll(f, u, 0.0, o); CHECK(std::fabs(o[0]) < 1e-12 && std::fabs(o[1] - 1) < 1e-12); roll(f, u, 90.0, o); CHECK(std::fabs(dot(o, u)) < 1e-9); }
  // the release of the chest cap
  CHECK(dk_of(0) == 0.0 && dk_of(20) == 0.0 && dk_of(60) == 1.0 && dk_of(89) == 1.0);
  double prev = 0; for (int p = 0; p <= 90; ++p) { const double d = dk_of(p); CHECK(d >= prev - 1e-12 && d >= 0 && d <= 1); prev = d; }
  // signed wrap
  CHECK(std::fabs(body::wrap_pi(3.5) - (3.5 - 2 * 3.14159265358979)) < 1e-9 && std::fabs(body::wrap_pi(-3.5) - (-3.5 + 2 * 3.14159265358979)) < 1e-9);
  const double lim = (130.0 - 100.0 * 1.0 * (1.0 - dk_of(10))) ; CHECK(std::fabs(lim - 30.0) < 1e-9);   // looking ahead the cap stays 30 deg
  const double lim2 = (130.0 - 100.0 * 1.0 * (1.0 - dk_of(70))); CHECK(std::fabs(lim2 - 130.0) < 1e-9);  // looking down it is released
  std::printf("%s\n", fails ? "FAILED" : "ok");
  return fails ? 1 : 0;
}
