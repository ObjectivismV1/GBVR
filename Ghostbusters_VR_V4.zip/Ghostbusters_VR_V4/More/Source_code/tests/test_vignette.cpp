// 1.7.22 comfort vignette math (vignettemath.h).
#include <stdio.h>
#include <math.h>
#include "vignettemath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

int main() {
  // 1. what the player does -> wanted level
  CHECK(vig::want(0, 0, 0, 0) == 0.0);
  CHECK(vig::want(0.15, 0.2, 0, 0) == 0.0);                 // inside the dead zones
  CHECK(vig::want(1.0, 0, 0, 0) > 0.7 && vig::want(1.0, 0, 0, 0) <= 0.76);
  CHECK(vig::want(1.0, 0, 1, 0) > vig::want(1.0, 0, 0, 0)); // sprint adds
  CHECK(vig::want(0, 0, 1, 0) == 0.0);                      // sprint without moving does nothing
  CHECK(vig::want(0, 1.0, 0, 0) > 0.8);                     // turning
  CHECK(vig::want(0, 0, 0, 1.0) == 1.0);                    // dash pulse
  CHECK(vig::want(1, 1, 1, 1) <= 1.0);

  // 2. easing: quick in, slow out, never past the target, setting scales it
  vig::State st = {0.0};
  double out = 0;
  for (int i = 0; i < 20; ++i) out = vig::step(&st, 1.0, 1.0 / 72.0, 1.0);     // 0.28 s
  CHECK(out > 0.7 && out < 1.0);
  for (int i = 0; i < 400; ++i) out = vig::step(&st, 1.0, 1.0 / 72.0, 1.0);
  CHECK(out > 0.99 && out <= 1.0);
  double held = out;
  for (int i = 0; i < 18; ++i) out = vig::step(&st, 0.0, 1.0 / 72.0, 1.0);     // 0.25 s out: still mostly there
  CHECK(out > 0.4 && out < held);
  for (int i = 0; i < 600; ++i) out = vig::step(&st, 0.0, 1.0 / 72.0, 1.0);
  CHECK(out == 0.0);
  st.level = 1.0;
  CHECK(vig::step(&st, 1.0, 0.01, 0.5) <= 0.5 + 1e-9);                         // strength 50 %
  CHECK(vig::step(&st, 1.0, 0.01, 0.0) == 0.0);                                // strength 0 = off
  st.level = 0.0; out = vig::step(&st, 1.0, 5.0, 1.0);                          // a huge dt is capped
  CHECK(out < 0.85);

  // 3. the shape: clear middle, dark rim, monotone, a light level never darkens the middle
  for (double lv = 0.1; lv <= 1.0; lv += 0.1) {
    CHECK(vig::darkness_at(lv, 0.0) == 0.0);
    double prev = 0;
    for (double r = 0; r <= 3.0; r += 0.05) { const double d = vig::darkness_at(lv, r); CHECK(d >= prev - 1e-12 && d <= 0.97 + 1e-12); prev = d; }
    CHECK(vig::darkness_at(lv, 3.0) == vig::max_dark(lv));
  }
  CHECK(vig::darkness_at(0.0, 1.5) == 0.0);
  CHECK(vig::darkness_at(0.1, 1.0) < 0.01);        // a gentle level leaves the visible circle alone
  CHECK(vig::darkness_at(1.0, 1.0) > 0.7);         // a full level is dark at the edge of the visible circle
  CHECK(vig::darkness_at(1.0, 0.45) < 0.01);       // ... but still clear in the middle
  CHECK(vig::max_dark(1.0) <= 0.97 && vig::max_dark(1.0) >= 0.9);   // never fully black: you can always see a bit

  // 4. the mesh
  static vig::Vert v[800];
  CHECK(vig::vertex_count() == 13 * 48 * 6);
  CHECK(vig::build(0.0, 0, 0, 1, 1, v, 4000) == 0);            // nothing to draw
  CHECK(vig::build(0.005, 0, 0, 1, 1, v, 4000) == 0);
  CHECK(vig::build(1.0, 0, 0, 0.0, 1, v, 4000) == 0);           // no window
  CHECK(vig::build(1.0, 0, 0, 1, 1, v, 100) == -1);             // buffer too small
  static vig::Vert big[4000];
  const int n = vig::build(1.0, 0.1, -0.05, 0.8, 0.9, big, 4000);
  CHECK(n == vig::vertex_count() && n % 3 == 0);
  CHECK(n <= 9000);                                             // fits the probe's vertex buffer
  int bad = 0; double maxd = 0, mind = 1;
  for (int i = 0; i < n; ++i) {
    if (!(big[i].c[0] >= 0.0f && big[i].c[0] <= 0.97001f) || big[i].c[3] != 1.0f || big[i].c[0] != big[i].c[1] || big[i].c[1] != big[i].c[2]) ++bad;
    if (big[i].c[0] > maxd) maxd = big[i].c[0];
    if (big[i].c[0] < mind) mind = big[i].c[0];
  }
  CHECK(bad == 0);
  CHECK(mind == 0.0 && maxd > 0.9);
  // the inner ring is centred where it was asked: average of the first ring's x/y
  double sx = 0, sy = 0; int cnt = 0;
  for (int i = 0; i < 48 * 6; ++i) { sx += big[i].p[0]; sy += big[i].p[1]; ++cnt; }
  CHECK(fabs(sx / cnt - 0.1) < 0.1 * 1.0 && fabs(sy / cnt + 0.05) < 0.1);
  // the outer ring reaches far past the picture
  double maxOuter = 0;
  for (int i = n - 48 * 6; i < n; ++i) { if (fabs(big[i].p[0]) > maxOuter) maxOuter = fabs(big[i].p[0]); }
  CHECK(maxOuter > 3.0);
  // inner circle at full level really is the clear radius (x extent of the first vertices)
  double xmax = -9;
  for (int i = 0; i < 48 * 6; ++i) if (big[i].p[0] > xmax) xmax = big[i].p[0];
  CHECK(fabs(xmax - (0.1 + 0.8 * vig::clear_radius(1.0))) < 0.6 * 0.8 * (vig::fade_width() / vig::kBands) + 0.02);

  if (!fails) printf("test_vignette: all pass\n");
  return fails ? 1 : 0;
}
