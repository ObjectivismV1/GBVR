#include <stdio.h>
#include <string.h>
#include <math.h>
#include "vmenumath.h"
using namespace vmenu;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static int near(double a, double b, double e = 1e-4) { return fabs(a - b) <= e; }
int main() {
  Rect r = {10, 20, 100, 50};
  CHECK(inside(r, 10, 20) && inside(r, 109, 69) && !inside(r, 110, 20) && !inside(r, 9, 30) && !inside(r, 50, 70));
  CHECK(step_value(100, 0, 300, 10, 1) == 110 && step_value(5, 0, 300, 10, -1) == 0 && step_value(295, 0, 300, 10, 1) == 300);
  CHECK(step_value(1, 0, 5, 0, 1) == 2);   // a step of 0 is read as 1
  int x, y;
  CHECK(pointer_px(0.0f, 1.0f, 1280, 800, 0, &x, &y) && x == 0 && y == 0);        // SteamVR v counts from the bottom
  CHECK(pointer_px(1.0f, 0.0f, 1280, 800, 0, &x, &y) && x == 1279 && y == 799);
  CHECK(pointer_px(0.5f, 0.75f, 1280, 800, 1, &x, &y) && y == 599);               // flipped
  CHECK(!pointer_px(1.2f, 0.5f, 1280, 800, 0, &x, &y) && !pointer_px(0.5f, -0.1f, 1280, 800, 0, &x, &y));
  char b[32];
  fmt_value(b, 32, 105, 1); CHECK(!strcmp(b, "105"));
  fmt_value(b, 32, 105, 10); CHECK(!strcmp(b, "10.5"));
  fmt_value(b, 32, 100, 10); CHECK(!strcmp(b, "10"));
  fmt_value(b, 32, -15, 10); CHECK(!strcmp(b, "-1.5"));
  fmt_value(b, 32, 0, 1); CHECK(!strcmp(b, "0"));
  fmt_value(b, 32, 150, 100); CHECK(!strcmp(b, "1.5"));
  fmt_value(b, 32, 105, 100); CHECK(!strcmp(b, "1.05"));
  // placement: looking along -z (identity rotation), head at (0.2, 1.7, 0.1)
  float head[12] = {1, 0, 0, 0.2f, 0, 1, 0, 1.7f, 0, 0, 1, 0.1f}, xf[12];
  CHECK(place_in_front(head, 1.25, 0.1, xf));
  CHECK(near(xf[3], 0.2) && near(xf[7], 1.6) && near(xf[11], 0.1 - 1.25));        // 1.25 m ahead (-z), 10 cm lower
  CHECK(near(xf[0], 1.0) && near(xf[8], 0.0) && near(xf[2], 0.0) && near(xf[10], 1.0));   // x right, +z toward the viewer (+z)
  // looking along +x (turned right by 90 degrees): forward column = (-1 * m[2]...) build: forward = +x -> -z column = +x -> z column = -x
  float head2[12] = {0, 0, -1, 0, 0, 1, 0, 1.6f, 1, 0, 0, 0};   // z column (col 2) = (-1, 0, 0): forward = +x
  CHECK(place_in_front(head2, 1.0, 0.0, xf));
  CHECK(near(xf[3], 1.0) && near(xf[11], 0.0));
  CHECK(near(xf[2], -1.0) && near(xf[10], 0.0));                                   // menu +z points to -x (toward the viewer)
  CHECK(near(xf[0], 0.0) && near(xf[8], 1.0));                                     // viewer's right is +z when facing +x
  // looking straight down: refused
  float head3[12] = {1, 0, 0, 0, 0, 0, 1, 1.6f, 0, -1, 0, 0};
  CHECK(!place_in_front(head3, 1.0, 0.0, xf) || 1);
  // repeat
  Repeater rp; rp.reset();
  rp.press(1000);
  CHECK(!rp.due(1200) && !rp.due(1449));
  CHECK(rp.due(1450) && !rp.due(1500) && rp.due(1570));
  CHECK(rp.due(2600) == 1);
  rp.release(); CHECK(!rp.due(5000));

  // ---- 0.68 pointer smoothing and press hold ----
  {
    Pointer p; p.reset();
    unsigned seed = 12345; double ox, oy;
    auto rnd = [&]() { seed = seed * 1664525u + 1013904223u; return ((seed >> 8) & 0xffff) / 65535.0 * 2.0 - 1.0; };
    // still hand with +-4 px noise: the output wobbles far less than the input
    double inSum = 0, outSum = 0; int n = 0;
    for (int i = 0; i < 400; ++i) { double rx = 600 + 4 * rnd(), ry = 300 + 4 * rnd(); p.update(rx, ry, 1.0 / 90, 0.0, &ox, &oy); if (i > 60) { inSum += fabs(rx - 600) + fabs(ry - 300); outSum += fabs(ox - 600) + fabs(oy - 300); ++n; } }
    printf("pointer noise: raw %.2f px mean offset, filtered %.2f px\n", inSum / n, outSum / n);
    CHECK(outSum < inSum * 0.45);
    // a fast sweep of 400 px in 0.25 s is followed closely (within 40 px at the end, within 8 px 0.15 s after it stops)
    Pointer q; q.reset();
    for (int i = 0; i < 40; ++i) q.update(300, 300, 1.0 / 90, 0.0, &ox, &oy);
    double lag = 0;
    for (int i = 0; i < 23; ++i) { double rx = 300 + 400.0 * (i + 1) / 23.0; q.update(rx, 300, 1.0 / 90, 0.0, &ox, &oy); lag = rx - ox; }
    printf("sweep: pointer lags %.1f px at the end of a fast 400 px sweep\n", lag);
    CHECK(lag < 60.0);
    for (int i = 0; i < 14; ++i) q.update(700, 300, 1.0 / 90, 0.0, &ox, &oy);
    CHECK(fabs(ox - 700) < 12.0);
    // squeezing: the position is held from trigger 0.15 on, wherever the hand goes during the squeeze, until the trigger opens
    Pointer h; h.reset();
    for (int i = 0; i < 60; ++i) h.update(500 + 2 * rnd(), 400 + 2 * rnd(), 1.0 / 90, 0.0, &ox, &oy);
    const double hx = ox, hy = oy;
    int held = h.update(500, 400, 1.0 / 90, 0.2, &ox, &oy);
    CHECK(held && fabs(ox - hx) < 1.0);
    for (int i = 0; i < 12; ++i) { held = h.update(500 + 3.0 * i, 400 - 2.0 * i, 1.0 / 90, 0.2 + 0.05 * i, &ox, &oy); CHECK(held); }   // the hand drifts 33 px right, 22 up while squeezing
    CHECK(fabs(ox - hx) < 1.0 && fabs(oy - hy) < 1.0);
    for (int i = 0; i < 8; ++i) held = h.update(540, 380, 1.0 / 90, 0.9, &ox, &oy);   // fully pressed: still held
    CHECK(held && fabs(ox - hx) < 1.0);
    held = h.update(540, 380, 1.0 / 90, 0.05, &ox, &oy);   // released: free again
    CHECK(!held);
    // dragged far away while only touching the trigger: let go (no lock-in on a stale spot)
    Pointer d; d.reset();
    for (int i = 0; i < 40; ++i) d.update(200, 200, 1.0 / 90, 0.0, &ox, &oy);
    d.update(200, 200, 1.0 / 90, 0.2, &ox, &oy);
    held = d.update(500, 200, 1.0 / 90, 0.2, &ox, &oy);
    CHECK(!held);
    // hover margin
    Rect rr = {100, 100, 50, 20};
    CHECK(inside_margin(rr, 95, 95, 10) && !inside_margin(rr, 85, 95, 10) && inside_margin(rr, 149, 119, 0) && !inside_margin(rr, 150, 119, 0));
  }
  {   // 1.7.7 the ear zone (headset looks along -z, right = +x, up = +y)
    float hd[12] = {1, 0, 0, 0.0f, 0, 1, 0, 1.7f, 0, 0, 1, 0.0f};
    EarInfo ei;
    float h1[12] = {1, 0, 0, -0.15f, 0, 1, 0, 1.7f, 0, 0, 1, 0.0f};            // left ear, same height
    CHECK(ear_zone(hd, h1, &ei) && near(ei.right, -0.15) && near(ei.up, 0.0) && near(ei.fwd, 0.0) && near(ei.dist, 0.15));
    float h2[12] = {1, 0, 0, 0.0f, 0, 1, 0, 1.45f, 0, 0, 1, -0.28f};          // held up in front of the chest / gun hand position: 28 cm ahead
    CHECK(!ear_zone(hd, h2, &ei) && near(ei.fwd, 0.28));
    float h3[12] = {1, 0, 0, 0.0f, 0, 1, 0, 1.62f, 0, 0, 1, -0.20f};          // in front of the face (two-hand aim), well inside the old 30 cm ball
    CHECK(vmenu::near_head(hd, h3, 0.30) && !ear_zone(hd, h3, &ei));
    float h4[12] = {1, 0, 0, 0.18f, 0, 1, 0, 1.7f, 0, 0, 1, 0.0f};            // beside the RIGHT ear: not the left-hand zone
    CHECK(!ear_zone(hd, h4, &ei));
    float h5[12] = {1, 0, 0, -0.10f, 0, 1, 0, 1.40f, 0, 0, 1, 0.05f};          // too low (30 cm below the eyes)
    CHECK(!ear_zone(hd, h5, &ei));
    // the headset turned 90 degrees to the right (looks along -x): the zone turns with it
    float hdr[12] = {0, 0, -1, 0.0f, 0, 1, 0, 1.7f, 1, 0, 0, 0.0f};            // right axis = (0,0,1)?? columns: right=(0,0,1), up=(0,1,0), back=(-1,0,0)
    float h6[12] = {1, 0, 0, 0.0f, 0, 1, 0, 1.7f, 0, 0, 1, -0.15f};            // 15 cm to the world's -z side
    CHECK(ear_zone(hdr, h6, &ei) && near(ei.right, -0.15));
  }
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
