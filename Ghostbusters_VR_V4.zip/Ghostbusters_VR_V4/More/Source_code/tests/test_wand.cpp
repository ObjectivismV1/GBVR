#include <stdio.h>
#include "wandmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static double fabs_(double x) { return x < 0 ? -x : x; }
// 4x4 row-vector product a x b (the game's 0x17210 for rotation + translation rows)
static void mul4(const float* a, const float* b, float* o) {
  float t[16];
  for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) {
    double s = 0; for (int k = 0; k < 4; ++k) s += (double)a[r * 4 + k] * b[k * 4 + c];
    t[r * 4 + c] = (float)s;
  }
  for (int i = 0; i < 16; ++i) o[i] = t[i];
}
static void rotm(const double* ax, double deg, float* m4, const float* t) {   // rotation in row-vector layout (rows = axes)
  double R[9]; weight::axis_angle(ax, deg * vm::kPi / 180.0, R);
  for (int i = 0; i < 16; ++i) m4[i] = 0;
  for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) m4[r * 4 + c] = (float)R[c * 3 + r];   // rows are the images of the unit vectors: transpose of the column form
  m4[12] = t[0]; m4[13] = t[1]; m4[14] = t[2]; m4[15] = 1;
}
int main() {
  double ax1[3] = {0.3, 0.9, 0.1}; double l = vm::dsqrt(ax1[0]*ax1[0] + ax1[1]*ax1[1] + ax1[2]*ax1[2]); for (int i = 0; i < 3; ++i) ax1[i] /= l;
  double ax2[3] = {1, 0, 0};
  float tW[3] = {10.0f, 4.5f, -3.0f}, tL[3] = {0.1f, 0.05f, 1.8f};
  float W[16], L[16], tipm[16], W2[16], tip2[16];
  rotm(ax1, 70.0, W, tW);                 // game wand: some orientation, at some place
  rotm(ax2, 20.0, L, tL);                 // tip attachment relative to the wand: 1.8 ft ahead along local z, a little tilted
  mul4(L, W, tipm);                       // tip world = local x W
  float grip[3] = {12.0f, 5.0f, -1.0f};
  float dir[3] = {0.0f, 0.6f, 0.8f};
  wand::Solve s;
  CHECK(wand::solve(W, tipm, grip, dir, &s));
  wand::apply_world(W, s, grip, W2);
  mul4(L, W2, tip2);                      // where the tip ends up with the new matrix
  printf("turn %.1f deg, moved %.2f ft, grip-to-tip %.3f ft\n", s.turnDeg, s.shiftFt, s.gripToTipFt);
  // the tip lands where solve() said
  for (int i = 0; i < 3; ++i) CHECK(fabs_(tip2[12 + i] - s.tip[i]) < 1e-3);
  // the new tip's forward (row 2) points along dir
  double f[3] = {tip2[8], tip2[9], tip2[10]}; double fl = vm::dsqrt(f[0]*f[0] + f[1]*f[1] + f[2]*f[2]);
  for (int i = 0; i < 3; ++i) CHECK(fabs_(f[i] / fl - dir[i]) < 1e-4);
  // the grip is where we asked; distance grip to tip is unchanged
  CHECK(fabs_(W2[12] - 12.0) < 1e-6 && fabs_(W2[13] - 5.0) < 1e-6 && fabs_(W2[14] + 1.0) < 1e-6);
  double d[3] = {tip2[12] - W2[12], tip2[13] - W2[13], tip2[14] - W2[14]};
  CHECK(fabs_(vm::dsqrt(d[0]*d[0] + d[1]*d[1] + d[2]*d[2]) - s.gripToTipFt) < 1e-3);
  // rigid: the matrix stays a rotation (axis row lengths unchanged)
  for (int r = 0; r < 3; ++r) { double a = W[r*4]*W[r*4] + W[r*4+1]*W[r*4+1] + W[r*4+2]*W[r*4+2], b = W2[r*4]*W2[r*4] + W2[r*4+1]*W2[r*4+1] + W2[r*4+2]*W2[r*4+2]; CHECK(fabs_(a - b) < 1e-4); }
  // already aligned: no turn, tip follows the grip shift only
  { float dirSame[3] = {tipm[8], tipm[9], tipm[10]}; wand::Solve s2; CHECK(wand::solve(W, tipm, W + 12, dirSame, &s2)); CHECK(s2.turnDeg < 0.1f); CHECK(s2.shiftFt < 1e-4f); }
  // opposite direction: half a turn, still consistent
  { float back[3] = {-tipm[8], -tipm[9], -tipm[10]}; wand::Solve s3; CHECK(wand::solve(W, tipm, grip, back, &s3)); CHECK(s3.turnDeg > 179.0f);
    float W3[16], t3[16]; wand::apply_world(W, s3, grip, W3); mul4(L, W3, t3);
    double f3[3] = {t3[8], t3[9], t3[10]}; double l3 = vm::dsqrt(f3[0]*f3[0] + f3[1]*f3[1] + f3[2]*f3[2]);
    double want[3] = {back[0], back[1], back[2]}; double lw = vm::dsqrt(want[0]*want[0] + want[1]*want[1] + want[2]*want[2]);
    for (int i = 0; i < 3; ++i) CHECK(fabs_(f3[i] / l3 - want[i] / lw) < 1e-3); }
  // bad input
  { wand::Solve s4; float zero[3] = {0, 0, 0}; CHECK(!wand::solve(W, tipm, grip, zero, &s4)); float tip0[16]; for (int i = 0; i < 16; ++i) tip0[i] = tipm[i]; tip0[12] = W[12]; tip0[13] = W[13]; tip0[14] = W[14]; CHECK(!wand::solve(W, tip0, grip, dir, &s4)); }
  // 0.58 roll: with the controller's up given, the new tip's up row (row 1) matches it; the barrel still points along dir
  {
    float upv[3] = {0.0f, 1.0f, 0.0f};
    double d1[3] = {dir[0], dir[1], dir[2]};
    // controller up = world up tilted (rolled) 50 degrees about the aim, perpendicular to dir
    double base[3] = {0.0, 0.8, -0.6}; // perpendicular to dir (0,0.6,0.8)
    double rr[9]; weight::axis_angle(d1, 50.0 * vm::kPi / 180.0, rr);
    double cu[3]; for (int k = 0; k < 3; ++k) cu[k] = rr[k*3]*base[0] + rr[k*3+1]*base[1] + rr[k*3+2]*base[2];
    float cuf[3] = {(float)cu[0], (float)cu[1], (float)cu[2]};
    (void)upv;
    wand::Solve sr;
    CHECK(wand::solve(W, tipm, grip, dir, &sr, cuf, 0.0));
    CHECK(sr.rolled);
    float W3[16], tip3[16];
    wand::apply_world(W, sr, grip, W3);
    mul4(L, W3, tip3);
    double f3[3] = {tip3[8], tip3[9], tip3[10]}, u3[3] = {tip3[4], tip3[5], tip3[6]};
    double fl3 = vm::dsqrt(f3[0]*f3[0] + f3[1]*f3[1] + f3[2]*f3[2]), ul3 = vm::dsqrt(u3[0]*u3[0] + u3[1]*u3[1] + u3[2]*u3[2]);
    for (int i = 0; i < 3; ++i) CHECK(fabs_(f3[i] / fl3 - dir[i]) < 1e-4);
    // the model's up is perpendicular to the barrel; its component along cu is ~1
    double dotu = (u3[0]*cu[0] + u3[1]*cu[1] + u3[2]*cu[2]) / ul3;
    printf("roll %.1f deg, up row . controller up = %.5f\n", sr.rollDeg, dotu);
    CHECK(dotu > 0.9999);
    for (int i = 0; i < 3; ++i) CHECK(fabs_(tip3[12 + i] - sr.tip[i]) < 1e-3);
    // a roll fix of 30 degrees turns the target up by 30 degrees about the barrel
    wand::Solve sf;
    CHECK(wand::solve(W, tipm, grip, dir, &sf, cuf, 30.0 * vm::kPi / 180.0));
    double diff = sf.rollDeg - sr.rollDeg; while (diff > 180) diff -= 360; while (diff < -180) diff += 360;
    CHECK(fabs_(fabs_(diff) - 30.0) < 0.05);
    // no up given: unchanged behaviour
    wand::Solve s0; CHECK(wand::solve(W, tipm, grip, dir, &s0)); CHECK(!s0.rolled);
  }
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
  return fails != 0;
}
