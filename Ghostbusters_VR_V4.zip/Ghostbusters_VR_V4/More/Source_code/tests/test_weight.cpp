#include <stdio.h>
#include "weightmath.h"
using namespace weight;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

// rotation about world up (y) by deg
static void yaw(double deg, double* r) { double up[3] = {0, 1, 0}; axis_angle(up, deg * vm::kPi / 180.0, r); }

// run n steps of dt with a target yawed by `deg` from identity; returns lag angle after `secs`
static double settle(double h, int two, double deg, double secs, double* lag10 = 0, int fire = 0) {
  State s; s.reset(); Params p = {h};
  double base[9]; ident(base);
  double out[9]; Out info;
  step(&s, p, base, 0.011, two, 0, 1, out, &info);
  if (fire) for (int k = 0; k < 20; ++k) step(&s, p, base, 0.011, two, 1, 1, out, &info);   // trigger down 0.22 s before the flick
  double tgt[9]; yaw(deg, tgt);
  double t = 0, lag = 0;
  while (t < secs) { step(&s, p, tgt, 0.011, two, fire, 1, out, &info); t += 0.011; if (lag10 && t < 0.1 && t + 0.011 >= 0.1) *lag10 = info.lagDeg; }
  return info.lagDeg;
}

int main() {
  // off: output equals input
  { State s; s.reset(); Params p = {0}; double t[9], o[9]; yaw(30, t); Out i; CHECK(step(&s, p, t, 0.01, 0, 1, 1, o, &i) == 0); for (int k = 0; k < 9; ++k) CHECK(o[k] == t[k]); }
  // angle helper
  { double a[9], b[9]; ident(a); yaw(40, b); double d = angle_between(a, b); CHECK(d > 39.99 && d < 40.01); }
  // a 30 degree flick: after 0.1 s one hand lags far more than two hands
  double l1 = 0, l2 = 0;
  settle(1.0, 0, 30, 0.3, &l1);
  settle(1.0, 1, 30, 0.3, &l2);
  printf("lag after 0.1 s: one hand %.1f, two hands %.1f degrees\n", l1, l2);
  CHECK(l1 > 0.5 && l1 < 4.0);   // 0.94 one hand idle: follows within about a tenth of a second (0.72: 2-8 degrees; the 0.93 player log said the gun came after the hand), still a little give
  CHECK(l2 < l1 * 0.8);      // two hands: less
  // given time both settle (sway/droop keep a small rest offset)
  double r1 = settle(1.0, 0, 30, 3.0), r2 = settle(1.0, 1, 30, 3.0);
  printf("after 3 s: one hand %.2f, two hands %.2f\n", r1, r2);
  CHECK(r1 < 4.0);
  CHECK(r2 < 1.5);
  // heavier = more lag, lighter = less
  double a = 0, b = 0, c = 0;
  settle(0.5, 0, 30, 0.3, &a); settle(1.0, 0, 30, 0.3, &b); settle(2.0, 0, 30, 0.3, &c);
  printf("lag at 0.1 s for 0.5 / 1.0 / 2.0: %.1f %.1f %.1f\n", a, b, c);
  CHECK(a < b && b < c);
  // no blow-up for a big dt and for a 180 degree turn
  { State s; s.reset(); Params p = {1.0}; double t[9], o[9]; Out i; yaw(179, t);
    double id[9]; ident(id); step(&s, p, id, 0.01, 0, 0, 1, o, &i);
    for (int k = 0; k < 400; ++k) step(&s, p, t, 0.05, k & 1, k % 3 == 0, 1, o, &i);
    for (int k = 0; k < 9; ++k) CHECK(vm::is_finite_f((float)o[k]));
    CHECK(i.lagDeg <= 30.0 + 1e-6); }
  // droop: pointing level, one hand settles lower than two hands
  { State s1, s2; s1.reset(); s2.reset(); Params p = {1.0}; double id[9], o1[9], o2[9]; ident(id); Out i1, i2;
    for (int k = 0; k < 600; ++k) { step(&s1, p, id, 0.011, 0, 0, 1, o1, &i1); step(&s2, p, id, 0.011, 1, 0, 1, o2, &i2); }
    double f1[3], f2[3]; forward_of(o1, f1); forward_of(o2, f2);
    printf("level forward y after 6 s: one hand %.4f, two hands %.4f (fatigue %.2f / %.2f)\n", f1[1], f2[1], i1.fatigue, i2.fatigue);
    CHECK(f1[1] < -0.012 && f1[1] > -0.09);   // one hand sags a few degrees (sin 3 deg = 0.052)
    CHECK(f2[1] > f1[1]);
    CHECK(f2[1] > -0.02);
    CHECK(i1.fatigue > 0.15 && i2.fatigue < 0.01); }
  // recoil: firing climbs (forward y rises) more with one hand
  { State s1, s2; s1.reset(); s2.reset(); Params p = {1.0}; double id[9], o1[9], o2[9]; ident(id); Out i1, i2;
    double base1 = 0, base2 = 0, peak1 = -9, peak2 = -9;
    for (int k = 0; k < 300; ++k) { step(&s1, p, id, 0.011, 0, 0, 1, o1, &i1); step(&s2, p, id, 0.011, 1, 0, 1, o2, &i2); }
    double f[3]; forward_of(o1, f); base1 = f[1]; forward_of(o2, f); base2 = f[1];
    for (int k = 0; k < 120; ++k) { step(&s1, p, id, 0.011, 0, 1, 1, o1, &i1); step(&s2, p, id, 0.011, 1, 1, 1, o2, &i2);
      forward_of(o1, f); if (f[1] > peak1) peak1 = f[1]; forward_of(o2, f); if (f[1] > peak2) peak2 = f[1]; }
    printf("recoil climb (sin): one hand %.4f, two hands %.4f\n", peak1 - base1, peak2 - base2);
    CHECK(peak1 - base1 > 0.008);
    CHECK((peak2 - base2) < (peak1 - base1) * 0.5); }
  // rotation stays a rotation
  { State s; s.reset(); Params p = {1.5}; double t[9], o[9]; Out i; yaw(10, t);
    for (int k = 0; k < 2000; ++k) { step(&s, p, t, 0.0138, k > 700, 1, 1, o, &i); }
    double c0 = o[0]*o[0] + o[3]*o[3] + o[6]*o[6], c1 = o[1]*o[1] + o[4]*o[4] + o[7]*o[7], dd = o[0]*o[1] + o[3]*o[4] + o[6]*o[7];
    CHECK(c0 > 0.9999 && c0 < 1.0001); CHECK(c1 > 0.9999 && c1 < 1.0001); CHECK(dd > -1e-4 && dd < 1e-4); }
    // 0.58 position inertia: trails a sweep (capped), catches up, firm with two hands, off at heaviness 0
  { PosState ps; ps.reset(); double t[3] = {0, 0, 0}, o[3]; double lagMax = 0;
    for (int k = 0; k < 20; ++k) step_pos(&ps, 1.5, t, 0.011, 0.0, o);
    for (int k = 0; k < 60; ++k) { t[0] += 1.0 * 0.011; double l = step_pos(&ps, 1.5, t, 0.011, 0.0, o); if (l > lagMax) lagMax = l; CHECK(l <= kPosCapM + 1e-9); }
    printf("position lag at 1 m/s one hand: max %.3f m (cap %.2f)\n", lagMax, kPosCapM);
    CHECK(lagMax > 0.015);   // 0.97: the cap is 2 cm (was 4 cm)
    double l = 0; for (int k = 0; k < 300; ++k) l = step_pos(&ps, 1.5, t, 0.011, 0.0, o);
    CHECK(l < 0.002);                                                    // stops: catches up
    PosState p2; p2.reset(); double t2[3] = {0, 0, 0}, o2[3], lag2 = 0;
    for (int k = 0; k < 20; ++k) step_pos(&p2, 1.5, t2, 0.011, 1.0, o2);
    for (int k = 0; k < 60; ++k) { t2[0] += 1.0 * 0.011; double q = step_pos(&p2, 1.5, t2, 0.011, 1.0, o2); if (q > lag2) lag2 = q; }
    printf("two hands: max %.3f m\n", lag2);
    CHECK(lag2 < lagMax * 0.6);
    PosState p3; p3.reset(); double t3[3] = {1, 2, 3}, o3[3];
    step_pos(&p3, 0.0, t3, 0.011, 0.0, o3); t3[0] = 2; step_pos(&p3, 0.0, t3, 0.011, 0.0, o3);
    CHECK(o3[0] == 2); }
  // 0.70: firing ONE-handed is heavier and shakier than just holding it with one hand; two hands stay firm
  { double idle = 0, fireLag = 0, idle2 = 0, fire2 = 0;
    settle(1.5, 0, 30, 0.3, &idle, 0); settle(1.5, 0, 30, 0.3, &fireLag, 1);
    printf("0.70 lag 0.1 s after a 30 degree flick, heaviness 1.5: idle %.1f, one-handed firing %.1f degrees\n", idle, fireLag);
    CHECK(fireLag > idle * 1.05);
    settle(1.5, 0, 90, 0.5, &idle2, 0); settle(1.5, 0, 90, 0.5, &fire2, 1);
    CHECK(fire2 >= idle2 * 0.95);
    // sway and climb: more while firing one-handed than idle one-handed, and much less with two hands
    State s1; s1.reset(); State s2; s2.reset(); State s3; s3.reset(); Params p = {1.5}; double base[9], o[9]; Out i1, i2, i3; ident(base);
    for (int k = 0; k < 300; ++k) { step(&s1, p, base, 0.011, 0, 0, 1, o, &i1); step(&s2, p, base, 0.011, 0, 1, 1, o, &i2); step(&s3, p, base, 0.011, 1, 1, 1, o, &i3); }
    printf("0.70 sway idle-1h %.2f, fire-1h %.2f, fire-2h %.2f; recoil fire-1h %.2f, fire-2h %.2f degrees\n", i1.swayDeg, i2.swayDeg, i3.swayDeg, i2.recoilDeg, i3.recoilDeg);
    CHECK(i2.swayDeg > i1.swayDeg * 2.0);
    CHECK(i3.swayDeg < i1.swayDeg * 0.5);
    CHECK(i2.recoilDeg > i3.recoilDeg * 3.0);
    CHECK(i2.swayDeg > 3.0);   // 0.74: punishing: about 3.6 degrees of wander at the default weight
    CHECK(i2.recoilDeg > 4.0);
    // a long hard sweep while firing one-handed never trails more than the one-hand cap
    State s; s.reset(); double t[9]; step(&s, p, base, 0.011, 0, 0, 1, o, &i1);
    double worst = 0;
    for (int k = 0; k < 400; ++k) { yaw(100.0 * (k % 40) / 40.0, t); step(&s, p, t, 0.011, 0, 1, 1, o, &i1); if (k > 30 && i1.lagDeg > worst) worst = i1.lagDeg; }
    printf("0.70 worst lag in a fast one-handed firing sweep: %.1f degrees\n", worst);
    CHECK(worst <= 36.0 + 1e-6);
    // heavier still means more lag, also while firing
    double a = 0, b = 0;
    settle(0.5, 0, 30, 0.3, &a, 1); settle(2.0, 0, 30, 0.3, &b, 1);
    CHECK(a < b); }
  // 0.74 the snap: the trigger kicks the muzzle up one-handed, much less with two hands, and it settles
  { State a; a.reset(); State b; b.reset(); Params p = {1.5}; double base[9], o[9]; Out ia, ib; ident(base);
    for (int k = 0; k < 120; ++k) { step(&a, p, base, 0.011, 0, 0, 1, o, &ia); step(&b, p, base, 0.011, 1, 0, 1, o, &ib); }
    double fa[3], fb[3]; forward_of(o, fb);
    step(&a, p, base, 0.011, 0, 0, 1, o, &ia); forward_of(o, fa); const double a0 = fa[1];
    step(&b, p, base, 0.011, 1, 0, 1, o, &ib); forward_of(o, fb); const double b0 = fb[1];
    step(&a, p, base, 0.011, 0, 1, 1, o, &ia); forward_of(o, fa);   // trigger goes down
    double pk1 = fa[1];
    for (int k = 0; k < 3; ++k) { step(&a, p, base, 0.011, 0, 1, 1, o, &ia); forward_of(o, fa); if (fa[1] > pk1) pk1 = fa[1]; }
    step(&b, p, base, 0.011, 1, 1, 1, o, &ib); forward_of(o, fb); double pk2 = fb[1];
    for (int k = 0; k < 3; ++k) { step(&b, p, base, 0.011, 1, 1, 1, o, &ib); forward_of(o, fb); if (fb[1] > pk2) pk2 = fb[1]; }
    pk1 -= a0; pk2 -= b0;
    printf("0.74 muzzle kick in the first 45 ms (sin of the climb): one hand %.4f, two hands %.4f\n", pk1, pk2);
    CHECK(pk1 > 0.02 && pk2 < pk1 * 0.3); }
  // 0.70 position: one-handed firing trails more than the two-handed one
  { PosState ps, p2; ps.reset(); p2.reset(); double t[3] = {0, 0, 0}, o[3], t2[3] = {0, 0, 0}, o2[3]; double lagMax = 0, lag2 = 0;
    for (int k = 0; k < 20; ++k) { step_pos(&ps, 1.5, t, 0.011, 0.0, o, 1.0); step_pos(&p2, 1.5, t2, 0.011, 1.0, o2, 1.0); }
    for (int k = 0; k < 60; ++k) { t[0] += 1.0 * 0.011; t2[0] += 1.0 * 0.011; double l = step_pos(&ps, 1.5, t, 0.011, 0.0, o, 1.0); if (l > lagMax) lagMax = l; l = step_pos(&p2, 1.5, t2, 0.011, 1.0, o2, 1.0); if (l > lag2) lag2 = l; }
    printf("0.70 position lag at 1 m/s firing: one hand %.3f m, two hands %.3f m\n", lagMax, lag2);
    CHECK(lagMax > 0.03 && lag2 < lagMax * 0.6); }
  // 0.94 twist lock: turning the wrist ABOUT the barrel is followed at once, the pointing keeps its weight
  {
    double fwdAx[3] = {0, 0, -1};   // OpenVR: the barrel is the negative z column
    double roll60[9]; axis_angle(fwdAx, 60.0 * vm::kPi / 180.0, roll60);
    double yaw30[9]; yaw(30, yaw30);
    double lagNo = 0, lagLock = 0, lagLockYaw = 0, lagNoYaw = 0;
    for (int pass = 0; pass < 2; ++pass) {
      State s; s.reset(); Params p = {1.0, pass ? 0.9 : 0.0};
      double base[9], out[9]; ident(base); Out info;
      step(&s, p, base, 0.011, 0, 0, 1, out, &info);
      for (int k = 0; k < 2; ++k) step(&s, p, roll60, 0.011, 0, 0, 1, out, &info);
      (pass ? lagLock : lagNo) = angle_between(roll60, out);
      State s2; s2.reset(); double out2[9]; Out info2;
      step(&s2, p, base, 0.011, 0, 0, 1, out2, &info2);
      for (int k = 0; k < 2; ++k) step(&s2, p, yaw30, 0.011, 0, 0, 1, out2, &info2);
      (pass ? lagLockYaw : lagNoYaw) = angle_between(yaw30, out2);
    }
    printf("0.94 a 60 degree wrist twist, 22 ms later: gun is %.1f degrees off without the twist lock, %.1f with it; a 30 degree sideways turn: %.1f without, %.1f with\n", lagNo, lagLock, lagNoYaw, lagLockYaw);
    CHECK(lagNo > 8.0);   // (the lag cap is 12 degrees)
    CHECK(lagLock < 2.0 && lagLock < lagNo * 0.25);
    CHECK(lagLockYaw > lagNoYaw * 0.9);   // the pointing itself is NOT locked by it (same weight with and without)
    // and it settles to exactly the hand with the lock on
    State s; s.reset(); Params p = {1.0, 1.0}; double base[9], out[9]; ident(base); Out info;
    step(&s, p, base, 0.011, 0, 0, 1, out, &info);
    for (int k = 0; k < 40; ++k) step(&s, p, roll60, 0.011, 0, 0, 1, out, &info);
    CHECK(angle_between(roll60, out) < 3.0);
  }
  // 0.95 more punishing one-handed: climb, shake and kick grow with the punish setting and with a long burst; two hands stay exactly as steady as before
  {
    double swayMax[3] = {0, 0, 0}, recMax[3] = {0, 0, 0}, sway2[3] = {0, 0, 0}, rec2[3] = {0, 0, 0}, strainEnd[3] = {0, 0, 0}, strain2[3] = {0, 0, 0}, kick[3] = {0, 0, 0};
    for (int q = 0; q < 3; ++q) {
      Params p = {1.0}; p.punish = (double)q;
      State a; a.reset(); State b; b.reset(); double base[9], o[9]; Out ia, ib; ident(base);
      for (int k = 0; k < 120; ++k) { step(&a, p, base, 0.011, 0, 0, 1, o, &ia); step(&b, p, base, 0.011, 1, 0, 1, o, &ib); }
      double f[3]; forward_of(o, f);
      step(&a, p, base, 0.011, 0, 0, 1, o, &ia); forward_of(o, f); const double rest = f[1];
      double pk = -9;
      for (int k = 0; k < 360; ++k) {
        step(&a, p, base, 0.011, 0, 1, 1, o, &ia); if (k < 4) { forward_of(o, f); if (f[1] > pk) pk = f[1]; }
        step(&b, p, base, 0.011, 1, 1, 1, o, &ib);
        if (ia.swayDeg > swayMax[q]) swayMax[q] = ia.swayDeg; if (ia.recoilDeg > recMax[q]) recMax[q] = ia.recoilDeg;
        if (ib.swayDeg > sway2[q]) sway2[q] = ib.swayDeg; if (ib.recoilDeg > rec2[q]) rec2[q] = ib.recoilDeg;
      }
      strainEnd[q] = ia.strain; strain2[q] = ib.strain; kick[q] = pk - rest;
    }
    printf("0.95 one-handed 4 s burst, punish 0/1/2: max sway %.1f/%.1f/%.1f, max climb %.1f/%.1f/%.1f degrees; kick (sin) %.3f/%.3f/%.3f; two hands sway %.2f/%.2f/%.2f; strain %.2f/%.2f/%.2f\n",
           swayMax[0], swayMax[1], swayMax[2], recMax[0], recMax[1], recMax[2], kick[0], kick[1], kick[2], sway2[0], sway2[1], sway2[2], strainEnd[0], strainEnd[1], strainEnd[2]);
    CHECK(swayMax[1] > swayMax[0] * 1.6 && swayMax[2] > swayMax[1] * 1.3);
    CHECK(recMax[1] > recMax[0] * 1.6 && recMax[2] > recMax[1] * 1.3);
    CHECK(kick[1] > kick[0] * 1.3);
    CHECK(sway2[1] < 0.2 && rec2[1] < 0.5);                                   // two hands: still steady
    CHECK(sway2[1] - sway2[0] < 0.005 && rec2[1] - rec2[0] < 0.005);          // ... and identical whatever the punish setting
    CHECK(strainEnd[1] > 0.95 && strain2[1] < 0.01);                          // the longer one-handed burst builds strain, two hands never do
    // strain eases off when the trigger is released
    State s; s.reset(); Params p = {1.0}; double base[9], o[9]; Out inf; ident(base);
    for (int k = 0; k < 120; ++k) step(&s, p, base, 0.011, 0, 0, 1, o, &inf);
    for (int k = 0; k < 360; ++k) step(&s, p, base, 0.011, 0, 1, 1, o, &inf);
    const double built = inf.strain;
    for (int k = 0; k < 300; ++k) step(&s, p, base, 0.011, 0, 0, 1, o, &inf);
    CHECK(built > 0.95 && inf.strain < 0.05);
    // a long hard sweep while firing one-handed stays inside the cap of 12 x (1 + 0.6 + 0.4 x punish)
    State sw; sw.reset(); double t[9]; step(&sw, p, base, 0.011, 0, 0, 1, o, &inf);
    double worst = 0;
    for (int k = 0; k < 400; ++k) { yaw(100.0 * (k % 40) / 40.0, t); step(&sw, p, t, 0.011, 0, 1, 1, o, &inf); if (k > 30 && inf.lagDeg > worst) worst = inf.lagDeg; }
    printf("0.95 worst lag in a fast one-handed firing sweep: %.1f degrees (cap 24)\n", worst);
    CHECK(worst <= 24.0 + 1e-6);
  }
  // 0.95 the PKE has a little weight: some inertia and give, never glued to the hand, never sluggish; no recoil
  {
    Params off = pke_params(0.0, 0.9);
    { State s; s.reset(); double t[9], o[9]; yaw(30, t); Out i; CHECK(step(&s, off, t, 0.01, 0, 0, 1, o, &i) == 0); for (int k = 0; k < 9; ++k) CHECK(o[k] == t[k]); }
    double lag50[3] = {0, 0, 0}, steady[3] = {0, 0, 0}, rest[3] = {0, 0, 0}, afterSettle[3] = {0, 0, 0}, capSeen[3] = {0, 0, 0};
    const double pcts[3] = {10.0, 40.0, 100.0};
    for (int q = 0; q < 3; ++q) {
      Params p = pke_params(pcts[q], 0.9);
      double base[9], o[9], tgt[9]; ident(base); yaw(30, tgt); Out i;
      State s; s.reset(); step(&s, p, base, 0.011, 0, 0, 1, o, &i);
      double t = 0, worstAfter = 0;
      for (int k = 0; k < 300; ++k) {
        step(&s, p, tgt, 0.011, 0, 0, 1, o, &i); t += 0.011;
        if (t >= 0.05 && t - 0.011 < 0.05) lag50[q] = i.lagDeg;
        if (t > 0.5 && i.lagDeg > worstAfter) worstAfter = i.lagDeg;
      }
      rest[q] = i.lagDeg; afterSettle[q] = worstAfter;
      State s2; s2.reset(); step(&s2, p, base, 0.011, 0, 0, 1, o, &i);
      double sum = 0; int n = 0;
      for (int k = 0; k < 60; ++k) { double tg[9]; yaw(180.0 * k * 0.011, tg); step(&s2, p, tg, 0.011, 0, 0, 1, o, &i); if (k > 25) { sum += i.lagDeg; ++n; } if (i.lagDeg > capSeen[q]) capSeen[q] = i.lagDeg; }
      steady[q] = sum / n;
      CHECK(i.recoilDeg == 0.0);
    }
    printf("0.95 PKE weight 10/40/100 %%: lag 50 ms into a 30 degree flick %.1f/%.1f/%.1f; steady 180 deg/s turn %.1f/%.1f/%.1f degrees behind (cap %.1f/%.1f/%.1f); at rest %.2f/%.2f/%.2f\n",
           lag50[0], lag50[1], lag50[2], steady[0], steady[1], steady[2], 4.0 + 0.8, 4.0 + 3.2, 4.0 + 8.0, rest[0], rest[1], rest[2]);
    CHECK(lag50[0] < lag50[1] && lag50[1] < lag50[2]);                       // heavier = more give
    CHECK(lag50[1] > 1.5 && lag50[1] < 6.0);                                 // the default: a little, not a lot
    CHECK(steady[1] > 3.0 && steady[1] <= 7.2 + 1e-6);                       // never more than its own cap behind a steady turn
    CHECK(capSeen[0] <= 4.8 + 1e-6 && capSeen[1] <= 7.2 + 1e-6 && capSeen[2] <= 12.0 + 1e-6);
    CHECK(rest[1] < 1.2 && afterSettle[1] < 1.5);                            // it settles onto the hand; at rest only a hair of droop / sway
    CHECK(steady[1] < 7.5 && steady[2] > steady[1]);
    // the trigger does nothing to it (the caller passes firing = 0), the gun's one-handed punishment is not applied
    { Params p = pke_params(40.0, 0.9); State s; s.reset(); double base[9], o[9]; Out i; ident(base);
      for (int k = 0; k < 360; ++k) step(&s, p, base, 0.011, 0, 0, 1, o, &i);
      CHECK(i.recoilDeg == 0.0 && i.swayDeg < 0.8 && i.strain == 0.0); }
    // position: it trails a quick sweep a little, never more than the position cap, and catches up
    { PosState ps; ps.reset(); Params p = pke_params(40.0, 0.9); double t[3] = {0, 0, 0}, o[3], mx = 0;
      for (int k = 0; k < 20; ++k) step_pos(&ps, p.heaviness, t, 0.011, 0.0, o, 0.0, p.punish);
      for (int k = 0; k < 60; ++k) { t[0] += 1.0 * 0.011; double l = step_pos(&ps, p.heaviness, t, 0.011, 0.0, o, 0.0, p.punish); if (l > mx) mx = l; }
      double l = 0; for (int k = 0; k < 300; ++k) l = step_pos(&ps, p.heaviness, t, 0.011, 0.0, o, 0.0, p.punish);
      printf("0.95 PKE position lag at 1 m/s: max %.3f m\n", mx);
      CHECK(mx > 0.01 && mx <= kPosCapM + 1e-9 && l < 0.002); }
  }
  // Locked controller pose is identical through firing/support press and
  // release changes: none of these transitions should kick the viewmodel.
  {
    State state; state.reset(); Params rigid = {0.0, 1.0}; rigid.punish = 0;
    double target[9], output[9]; Out info;
    for (int frame = 0; frame < 1000; ++frame) {
      yaw(frame % 360, target); state.reset();
      step(&state, rigid, target, 0.011, frame % 2, (frame / 3) % 2, 1, output, &info);
      for (int i = 0; i < 9; ++i) CHECK(output[i] == target[i]);
      CHECK(info.recoilDeg == 0 && info.swayDeg == 0 && info.lagDeg == 0);
    }
  }
  printf(fails ? "FAILED %d\n" : "ALL PASS\n", fails);
return fails != 0;
}
