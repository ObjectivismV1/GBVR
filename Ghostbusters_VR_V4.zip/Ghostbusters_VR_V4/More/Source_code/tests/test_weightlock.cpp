// 1.7.155 the gun's weight while the hand is locked to the controller (weight::locked_params + weight::step), and a long-play stress run.
#include <cstdio>
#include <cmath>
#include "weightmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)
static void rotY(double deg, double* r) { const double a = deg * 3.14159265358979 / 180.0, c = cos(a), s = sin(a); const double m[9] = {c, 0, s, 0, 1, 0, -s, 0, c}; for (int i = 0; i < 9; ++i) r[i] = m[i]; }
static unsigned long long sd = 0xC0FFEE1234ULL;
static double rnd() { sd ^= sd << 13; sd ^= sd >> 7; sd ^= sd << 17; return (double)(sd >> 11) / 9007199254740992.0; }
int main() {
  int rz = -1;
  // the PKE is rigid; the gun has weight and punishment; heft 0 switches the weight off; "held up" only counts while firing
  { weight::Params p = weight::locked_params(100, 150, 1, 1, 1, &rz); CHECK(p.heaviness == 0.0 && p.punish == 0.0 && rz == 0); }
  { weight::Params p = weight::locked_params(100, 150, 0, 0, 1, &rz); CHECK(p.heaviness == 1.0 && p.twistLock == 1.0 && p.punish == 1.5 && rz == 0); }
  { weight::Params p = weight::locked_params(100, 150, 0, 1, 1, &rz); CHECK(p.heaviness == 1.0 && rz == 1); }
  { weight::Params p = weight::locked_params(0, 150, 0, 1, 1, &rz); CHECK(p.heaviness == 0.0); }
  { volatile double z = 0; weight::Params p = weight::locked_params(z / z, z / z, 0, 1, 1, &rz); CHECK(p.heaviness == 0.0 && p.punish == 0.0); }
  { weight::Params p = weight::locked_params(1e9, 150, 0, 1, 1, &rz); CHECK(p.heaviness == 3.0); }
  const double dt = 1.0 / 90.0;
  double tgt[9], out[9]; rotY(0, tgt);
  weight::Out wi;
  // 1. the gun at rest in a still hand: within half a degree of the hand, for ever (10 minutes: nothing builds up - "floats away the more you play")
  { weight::State s; s.reset(); double worst = 0, last = 0;
    for (int i = 0; i < 90 * 600; ++i) { int rr; weight::Params p = weight::locked_params(100, 150, 0, 0, 1, &rr); weight::step(&s, p, tgt, dt, 0, 0, rr, out, &wi); if (i > 90 && wi.lagDeg > worst) worst = wi.lagDeg; last = wi.lagDeg; }
    printf("weightlock: resting one-handed for 10 minutes: gun off the hand's aim at most %.2f deg, at the end %.2f deg, tiredness %.2f\n", worst, last, wi.fatigue);
    CHECK(worst < 0.9 && wi.fatigue == 0.0); }
  // 2. a one-handed shot: the muzzle climbs and shakes (the punishment), clearly more than at rest and more than with two hands; after the shot it comes back
  double oneMax = 0, twoMax = 0, afterEnd = 0;
  { weight::State s; s.reset();
    for (int i = 0; i < 90 * 4; ++i) { int rr; weight::Params p = weight::locked_params(100, 150, 0, 1, 1, &rr); weight::step(&s, p, tgt, dt, 0, 1, rr, out, &wi); if (wi.lagDeg > oneMax) oneMax = wi.lagDeg; }
    for (int i = 0; i < 90 * 3; ++i) { int rr; weight::Params p = weight::locked_params(100, 150, 0, 0, 1, &rr); weight::step(&s, p, tgt, dt, 0, 0, rr, out, &wi); afterEnd = wi.lagDeg; } }
  { weight::State s; s.reset();
    for (int i = 0; i < 90 * 4; ++i) { int rr; weight::Params p = weight::locked_params(100, 150, 0, 1, 1, &rr); weight::step(&s, p, tgt, dt, 1, 1, rr, out, &wi); if (i > 60 && wi.lagDeg > twoMax) twoMax = wi.lagDeg; } }
  printf("weightlock: firing 4 s: one hand up to %.1f deg off the hand's aim, two hands up to %.1f deg; 3 s after the shot %.2f deg\n", oneMax, twoMax, afterEnd);
  CHECK(oneMax > 2.5 && oneMax < 25.0);
  CHECK(twoMax < oneMax * 0.5);
  CHECK(afterEnd < 0.9);
  // 3. the punishment setting matters: 0 is gentler than 150
  { double m0 = 0; weight::State s; s.reset();
    for (int i = 0; i < 90 * 4; ++i) { int rr; weight::Params p = weight::locked_params(100, 0, 0, 1, 1, &rr); weight::step(&s, p, tgt, dt, 0, 1, rr, out, &wi); if (wi.lagDeg > m0) m0 = wi.lagDeg; }
    CHECK(m0 < oneMax); }
  // 4. a quick turn of the wrist (90 degrees in 0.15 s) at rest: the gun trails a little (weight) and is back on the hand within 0.4 s
  { weight::State s; s.reset(); double trail = 0, endLag = 0;
    for (int i = 0; i < 180; ++i) { const double tt = i * dt; rotY(tt < 0.5 ? 0 : tt < 0.65 ? (tt - 0.5) / 0.15 * 90.0 : 90.0, tgt);
      int rr; weight::Params p = weight::locked_params(100, 150, 0, 0, 1, &rr); weight::step(&s, p, tgt, dt, 0, 0, rr, out, &wi);
      if (wi.lagDeg > trail) trail = wi.lagDeg; if (tt > 1.05) endLag = wi.lagDeg; }
    printf("weightlock: a 90 degree wrist flick: the gun trails by up to %.1f deg, %.2f deg 0.4 s later\n", trail, endLag);
    CHECK(trail > 3.0 && trail < 45.0 && endLag < 1.0); rotY(0, tgt); }
  // 5. stress: 2 hours of random play at random frame rates (20..240 FPS, hitches): random aim moves, trigger bursts, one / two hands, PKE in and out,
  //    settings changed on the way. Every result is a proper rotation, never further than 60 degrees from the hand, and at rest it always comes back.
  { weight::State s; s.reset(); long bad = 0, frames = 0; double yaw = 0, t = 0, worst = 0; int firing = 0, two = 0, pke = 0; double heft = 100, pun = 150;
    while (t < 7200.0) {
      double d = 1.0 / (20.0 + rnd() * 220.0); if (rnd() < 0.002) d += rnd() * 0.4;
      t += d; ++frames;
      if (rnd() < 0.01) firing = rnd() < 0.4; if (rnd() < 0.004) two = rnd() < 0.5; if (rnd() < 0.001) pke = rnd() < 0.3;
      if (rnd() < 0.0005) { heft = rnd() * 300.0; pun = rnd() * 200.0; }
      yaw += (rnd() - 0.5) * 400.0 * d * (rnd() < 0.05 ? 8.0 : 1.0);
      rotY(yaw, tgt);
      int rr; weight::Params p = weight::locked_params(heft, pun, pke, firing, 1, &rr);
      if (p.heaviness <= 0.001) s.reset();
      weight::step(&s, p, tgt, d, two, pke ? 0 : firing, rr, out, &wi);
      for (int i = 0; i < 9; ++i) if (!(out[i] == out[i]) || fabs(out[i]) > 1.0001) ++bad;
      const double l0 = sqrt(out[0] * out[0] + out[3] * out[3] + out[6] * out[6]); if (fabs(l0 - 1.0) > 1e-3) ++bad;
      if (!(wi.lagDeg >= 0.0) || wi.lagDeg > 60.0) ++bad;
      if (wi.lagDeg > worst) worst = wi.lagDeg;
    }
    // and at rest afterwards it settles on the hand
    for (int i = 0; i < 270; ++i) { int rr; weight::Params p = weight::locked_params(100, 150, 0, 0, 1, &rr); weight::step(&s, p, tgt, dt, 0, 0, rr, out, &wi); }
    if (wi.lagDeg > 0.9) ++bad;
    printf("WEIGHTLOCK STRESS: %ld frames (2 hours, 20..240 FPS): broken results %ld, furthest the gun ever was from the hand's aim %.1f deg, at rest afterwards %.2f deg\n", frames, bad, worst, wi.lagDeg);
    CHECK(bad == 0); }
  if (!fails) printf("weightlock: ok\n");
  return fails ? 1 : 0;
}
