// 1.7.215: the wrap-gripped left wrist cannot fold back past 55 deg. Same steps as armcore.h: rotate the hand's pointing toward the forearm by the excess,
// move the wrist round the palm point so the palm stays where it is. Random hands: after the turn the bend equals the limit (weight 1), never more than before,
// the palm point is unchanged, the hand frame stays a pure turn, never NaN; hands already inside the limit are untouched.
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include "../src/armmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { ++fails; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static double rnd() { return (double)rand() / RAND_MAX * 2.0 - 1.0; }
static void rv(double* v) { do { for (int i = 0; i < 3; ++i) v[i] = rnd(); } while (!arm::unit(v, v)); }
int main() {
  srand(5);
  const double lim = 55.0 * 3.14159265358979323846 / 180.0;
  int clamped = 0, untouched = 0;
  for (int n = 0; n < 200000; ++n) {
    double a1[3], fh[3], uh[3], ax[3], R[9], o0[3], o1[3], T[3];
    rv(a1); rv(fh); rv(uh); rv(T);
    const double back = 0.2 + 0.2 * (rnd() * 0.5 + 0.5), down = 0.05 * (rnd() * 0.5 + 0.5), ww = (n % 4 == 0) ? 0.5 : 1.0;
    double cs = arm::dot(a1, fh); cs = cs > 1.0 ? 1.0 : (cs < -1.0 ? -1.0 : cs);
    const double bend = std::atan2(std::sqrt(1.0 - cs * cs), cs);
    arm::cross(fh, a1, ax);
    if (bend > lim + 0.005 && arm::unit(ax, ax)) {
      ++clamped;
      weight::axis_angle(ax, (bend - lim) * ww, R);
      for (int i = 0; i < 3; ++i) o0[i] = fh[i] * back + uh[i] * down;
      arm::apply3(R, o0, o1);
      double Tn[3], pn[3], p0[3], f2[3];
      for (int i = 0; i < 3; ++i) { Tn[i] = (T[i] + o0[i]) - o1[i]; p0[i] = T[i] + o0[i]; pn[i] = Tn[i] + o1[i]; }
      for (int i = 0; i < 3; ++i) CHECK(std::fabs(p0[i] - pn[i]) < 1e-9);          // palm stays
      arm::apply3(R, fh, f2);
      CHECK(std::fabs(arm::len(f2) - 1.0) < 1e-9);
      double c2 = arm::dot(a1, f2); c2 = c2 > 1.0 ? 1.0 : (c2 < -1.0 ? -1.0 : c2);
      const double b2 = std::atan2(std::sqrt(1.0 - c2 * c2), c2);
      CHECK(std::fabs(b2 - (bend - (bend - lim) * ww)) < 1e-6);                    // the bend shrank by exactly the excess * weight
      CHECK(b2 <= bend + 1e-9);
      if (ww == 1.0) CHECK(std::fabs(b2 - lim) < 1e-6);
      CHECK(std::isfinite(Tn[0] + Tn[1] + Tn[2]));
    } else ++untouched;
  }
  CHECK(clamped > 1000 && untouched > 1000);
  if (fails) { std::printf("%d failures\n", fails); return 1; }
  std::printf("wrist limit ok (%d clamped, %d untouched)\n", clamped, untouched);
  return 0;
}
