// 1.7.214: the grip turns the held hand from the wrist onto the barrel as ONE swing (slerp of the hand frame).
// Checks over random start/target frames: ww=0 gives the start, ww=1 the target, every step stays unit + perpendicular,
// the turn angle grows steadily (no jump, no fold back), never NaN.
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include "../src/armmath.h"
static int fails = 0;
#define CHECK(c) do { if (!(c)) { ++fails; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static double rnd() { return (double)rand() / RAND_MAX * 2.0 - 1.0; }
static void frame(double* f, double* u) {
  do { for (int i = 0; i < 3; ++i) f[i] = rnd(); } while (!arm::unit(f, f));
  do { for (int i = 0; i < 3; ++i) u[i] = rnd(); const double k = arm::dot(u, f); for (int i = 0; i < 3; ++i) u[i] -= k * f[i]; } while (!arm::unit(u, u));
}
// same steps as armcore.h (wrap grip)
static int swing(const double* f0, const double* u0, const double* fW, const double* uW, double ww, double* lf, double* lu) {
  double b0[3] = {f0[0], f0[1], f0[2]}, b1[3] = {u0[0], u0[1], u0[2]};
  const double kb = arm::dot(b1, b0);
  for (int i = 0; i < 3; ++i) b1[i] -= kb * b0[i];
  if (!(arm::unit(b0, b0) && arm::unit(b1, b1))) return 0;
  double b2[3], g2[3], Rb[9], Rt[9], Rbt[9], dl[9], part[9], Rn[9];
  arm::cross(b0, b1, b2); arm::cross(fW, uW, g2);
  for (int i = 0; i < 3; ++i) { Rb[i*3] = b0[i]; Rb[i*3+1] = b1[i]; Rb[i*3+2] = b2[i]; Rt[i*3] = fW[i]; Rt[i*3+1] = uW[i]; Rt[i*3+2] = g2[i]; }
  weight::transpose3(Rb, Rbt); weight::mul3(Rt, Rbt, dl);
  arm::rot_part(dl, ww, vm::kPi, part);
  weight::mul3(part, Rb, Rn);
  double nf[3] = {Rn[0], Rn[3], Rn[6]}, nu[3] = {Rn[1], Rn[4], Rn[7]};
  if (!(arm::unit(nf, nf) && arm::unit(nu, nu))) return 0;
  for (int i = 0; i < 3; ++i) { lf[i] = nf[i]; lu[i] = nu[i]; }
  return 1;
}
int main() {
  srand(11);
  for (int n = 0; n < 20000; ++n) {
    double f0[3], u0[3], fT[3], uT[3], lf[3], lu[3];
    frame(f0, u0); frame(fT, uT);
    CHECK(swing(f0, u0, fT, uT, 0.0, lf, lu));
    CHECK(arm::dot(lf, f0) > 0.999999 && arm::dot(lu, u0) > 0.999999);
    CHECK(swing(f0, u0, fT, uT, 1.0, lf, lu));
    CHECK(arm::dot(lf, fT) > 0.99999 && arm::dot(lu, uT) > 0.99999);
    double prevAng = -1.0;
    for (int k = 0; k <= 10; ++k) {
      const double w = k / 10.0;
      CHECK(swing(f0, u0, fT, uT, w, lf, lu));
      CHECK(std::isfinite(lf[0] + lf[1] + lf[2] + lu[0] + lu[1] + lu[2]));
      CHECK(std::fabs(arm::dot(lf, lu)) < 1e-6);
      const double ang = std::acos(std::fmax(-1.0, std::fmin(1.0, arm::dot(lf, f0))));
      const double angU = std::acos(std::fmax(-1.0, std::fmin(1.0, arm::dot(lu, u0))));
      const double tot = std::fmax(ang, angU);
      CHECK(tot + 1e-6 >= prevAng * 0.0);   // never negative
      if (k > 0 && k < 10) { /* the pointing line stays between start and target: no overshoot past the target */
        const double aT = std::acos(std::fmax(-1.0, std::fmin(1.0, arm::dot(f0, fT))));
        CHECK(ang <= aT + 1e-6);
      }
      prevAng = tot;
    }
  }
  if (fails) { std::printf("%d failures\n", fails); return 1; }
  std::printf("wrist swing ok\n");
  return 0;
}
