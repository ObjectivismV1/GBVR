#!/usr/bin/env python3
"""Check every constant in src/layout.h against a ghost.exe and the 0.16 log.
usage: verify_layout.py ghost.exe [probe016.log]"""
import re, struct, sys
src = open(__file__.rsplit('/tests/', 1)[0] + '/src/layout.h').read()
consts = {m[0]: int(m[1], 16) for m in re.findall(r'(k\w+)\s*=\s*(0x[0-9A-Fa-f]+)u?;', src)}
arrays = {m[0]: bytes(int(x, 16) for x in re.findall(r'0x([0-9a-fA-F]{2})', m[1]))
          for m in re.findall(r'(kBytes\w+)\[16\]\s*=\s*\{([^}]*)\}', src)}
d = open(sys.argv[1], 'rb').read()
pe = struct.unpack_from('<I', d, 0x3c)[0]
ts = struct.unpack_from('<I', d, pe + 8)[0]
opt = pe + 24; soi = struct.unpack_from('<I', d, opt + 56)[0]; base = struct.unpack_from('<Q', d, opt + 24)[0]
nsec = struct.unpack_from('<H', d, pe + 6)[0]; optsz = struct.unpack_from('<H', d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = pe + 24 + optsz + 40 * i
    vs, va, rs, ra = struct.unpack_from('<IIII', d, o + 8); secs.append((va, vs, ra, rs))
def at(r, n):
    for va, vs, ra, rs in secs:
        if va <= r < va + rs: return d[ra + r - va: ra + r - va + n]
fails = 0
def check(name, ok, info=''):
    global fails; fails += not ok; print(('PASS ' if ok else 'FAIL ') + name, info)
check('timestamp', ts == consts['kExpectedTimeDateStamp'], hex(ts))
check('sizeOfImage', soi == consts['kExpectedSizeOfImage'], hex(soi))
import zlib
check('0.96 exe file size', len(d) == consts['kVanillaExeFileSize'], str(len(d)))
check('0.96 exe crc32', (zlib.crc32(d) & 0xffffffff) == consts['kVanillaExeCrc32'], '%08x' % (zlib.crc32(d) & 0xffffffff))
for fn, arr in [('kRvaCameraPrepare', 'kBytesCameraPrepare'), ('kRvaBasisSetter', 'kBytesBasisSetter'),
                ('kRvaVisibilityStage', 'kBytesVisibilityStage'), ('kRvaSetEye', 'kBytesSetEye'),
                ('kRvaMainSpatial', 'kBytesMainSpatial'), ('kRvaSetNearFar', 'kBytesSetNearFar'),
                ('kRvaSetProjection', 'kBytesSetProjection'), ('kRvaSetScales', 'kBytesSetScales'),
                ('kRvaAppTick', 'kBytesAppTick'), ('kRvaAppSimulate', 'kBytesAppSimulate'),
                ('kRvaStreamUpdate', 'kBytesStreamUpdate'), ('kRvaKnockBack', 'kBytesKnockBack'), ('kRvaStatsUnlock', 'kBytesStatsUnlock')]:
    check(fn + ' bytes', at(consts[fn], 16) == arrays[arr], hex(consts[fn]))
q = lambda r: struct.unpack('<Q', at(r, 8))[0] - base
vt = consts['kRvaCameraVtable']
check('vtable+0x40 == prepare', q(vt + 0x40) == consts['kRvaCameraPrepare'])
check('vtable+0x48 == visibility', q(vt + 0x48) == consts['kRvaVisibilityStage'])
# return addresses follow a call instruction to the expected target
def call_before(ret, target=None, indirect=None):
    b = at(ret - 5, 5)
    if target is not None and b[0] == 0xE8:
        return ret + struct.unpack('<i', b[1:])[0] == target
    b3 = at(ret - 3, 3)
    return indirect is not None and b3 == bytes([0xFF, 0x50, indirect])
check('prepare return follows call [rax+0x40]', call_before(consts['kRvaPrepareReturn'], indirect=0x40))
check('visibility return follows call [rax+0x48]', call_before(consts['kRvaVisibilityReturn'], indirect=0x48))
check('basis return follows call 0x3019F0', call_before(consts['kRvaBasisReturn'], target=consts['kRvaBasisSetter']))
check('set-eye return follows call SetEye', call_before(consts['kRvaSetEyeReturn'], target=consts['kRvaSetEye']))
check('near/far return follows call SetNearFar', call_before(consts['kRvaNearFarReturn'], target=consts['kRvaSetNearFar']))
check('spatial return follows call MainSpatial', call_before(consts['kRvaSpatialReturn'], target=consts['kRvaMainSpatial']))
check('projection return follows call SetProjection', call_before(consts['kRvaProjectionReturn'], target=consts['kRvaSetProjection']))
# Prepare loads the projection mode from camera+0x34 right before that call (mov edx,[rdi+0x34])
check('prepare projection mode arg is camera+0x34', at(0x455060, 3) == bytes([0x8b, 0x57, 0x34]))
# SetProjection stores 1/scaleY and 1/scaleX (movss [rip+x], xmm8 / xmm0)
ins = at(0x302616, 9)
check('SetProjection writes tanHalfFovV', ins[:5] == b'\xf3\x44\x0f\x11\x05' and 0x302616 + 9 + struct.unpack('<i', ins[5:9])[0] == consts['kRvaTanHalfFovV'])
ins = at(0x302632, 8)
check('SetProjection writes tanHalfFovH', ins[:4] == b'\xf3\x0f\x11\x05' and 0x302632 + 8 + struct.unpack('<i', ins[4:8])[0] == consts['kRvaTanHalfFovH'])
# renderer projection builder stores its first two arguments as P[0][0] and P[1][1]
check('projection matrix P[0][0] <- xmm8(=xmm0)', at(0x3F505D, 5) == bytes([0xf3, 0x44, 0x0f, 0x11, 0x05]))
check('projection matrix P[1][1] <- xmm7(=xmm1)', at(0x3F5066, 4) == bytes([0xf3, 0x0f, 0x11, 0x3d]))
# SetScales stores its two arguments to the scale globals (movss [rip+x], xmm0 / xmm1)
ins = at(0x30265B, 8)
check('SetScales writes scaleX from xmm0', ins[:4] == b'\xf3\x0f\x11\x05' and 0x30265B + 8 + struct.unpack('<i', ins[4:8])[0] == 0x236EDC4)
ins = at(0x302673, 8)
check('SetScales writes scaleY from xmm1', ins[:4] == b'\xf3\x0f\x11\x0d' and 0x302673 + 8 + struct.unpack('<i', ins[4:8])[0] == 0x236EDD4)
ins = at(0x30266B, 8)
check('SetScales writes 1/scaleX to tanHalfFovH', ins[:4] == b'\xf3\x0f\x11\x15' and 0x30266B + 8 + struct.unpack('<i', ins[4:8])[0] == consts['kRvaTanHalfFovH'])
ins = at(0x30267B, 8)
check('SetScales writes 1/scaleY to tanHalfFovV', ins[:4] == b'\xf3\x0f\x11\x1d' and 0x30267B + 8 + struct.unpack('<i', ins[4:8])[0] == consts['kRvaTanHalfFovV'])
check('SetScales ends right after (ret at 0x302683)', at(0x302683, 1) == b'\xc3')
check('app vtable +0x158 == App::Tick', q(consts['kRvaAppVtable'] + 0x158) == consts['kRvaAppTick'])
check('main loop calls [vtable+0x158] with the 120 FPS value', at(0x1F0608, 6) == bytes([0xff, 0x90, 0x58, 0x01, 0x00, 0x00]))
# the game's only DXGI import is CreateDXGIFactory and its import-table slot is where layout.h says
imp = struct.unpack_from('<I', d, opt + 112 + 8)[0]
found = None; dxgi_funcs = []
while True:
    oft, _, _, nm, ft = struct.unpack('<IIIII', at(imp, 20))
    if not nm: break
    name = at(nm, 32).split(b'\0')[0].decode().lower()
    i = 0
    while True:
        v = struct.unpack('<Q', at((oft or ft) + 8 * i, 8))[0]
        if not v: break
        fn = at((v & 0x7fffffff) + 2, 48).split(b'\0')[0].decode() if not v >> 63 else '#ord'
        if name == 'dxgi.dll':
            dxgi_funcs.append(fn)
            if fn == 'CreateDXGIFactory': found = ft + 8 * i
        i += 1
    imp += 20
check('dxgi.dll imports are exactly [CreateDXGIFactory]', dxgi_funcs == ['CreateDXGIFactory'], str(dxgi_funcs))
check('kRvaIatCreateDXGIFactory is that import slot', found == consts['kRvaIatCreateDXGIFactory'], hex(found or 0))
# the game calls it through a jmp thunk: jmp qword ptr [rip+x] at 0x70FB66 -> the slot; called at 0x3F2C59
ins = at(0x70FB66, 6)
check('CreateDXGIFactory thunk uses the slot', ins[:2] == b'\xff\x25' and 0x70FB66 + 6 + struct.unpack('<i', ins[2:])[0] == consts['kRvaIatCreateDXGIFactory'])
check('factory created at 0x3F2C59 via the thunk', call_before(0x3F2C5E, target=0x70FB66))
# Prepare passes camera+0x08 to SetEye (lea rcx,[rdi+0x8] right before the call)
check('prepare SetEye arg is camera+0x08', at(consts['kRvaSetEyeReturn'] - 9, 4) == bytes([0x48, 0x8d, 0x4f, 0x08]))
# VisibilityStage passes camera+0x6C as the query eye (lea rdx,[rcx+0x6c])
check('visibility spatial arg is camera+0x6C', at(0x450770, 4) == bytes([0x48, 0x8d, 0x51, 0x6c]))
# active camera pointer: render loop loads it right before call [rax+0x38]
ins = at(0x1F1DF6, 7)
check('active camera load at 0x1F1DF6', ins[:3] == b'\x48\x8b\x0d' and 0x1F1DF6 + 7 + struct.unpack('<i', ins[3:])[0] == consts['kRvaActiveCameraPtr'])
# setter stores basis element 0 to the global basis (movss [rip+x], xmm1 at 0x301A73)
ins = at(0x301A73, 8)
check('setter writes global basis', ins[:4] == b'\xf3\x0f\x11\x0d' and 0x301A73 + 8 + struct.unpack('<i', ins[4:])[0] == consts['kRvaGlobalBasis'])
# frame limiter: main loop compares the two settings bytes (cmp byte ptr [rip+x], 0 = 80 3D rel32 00)
for at_rva, key in [(0x1F05B6, 'kRvaLockTo30Hz'), (0x1F05D7, 'kRvaLockTo60Hz')]:
    ins = at(at_rva, 7)
    check(key + ' used by limiter', ins[:2] == b'\x80\x3d' and at_rva + 7 + struct.unpack('<i', ins[2:6])[0] == consts[key])
# ---- 0.26 display modes / picture size -------------------------------------------------
def import_name(slot):
    imp = struct.unpack_from('<I', d, opt + 112 + 8)[0]
    while True:
        oft, _, _, nm, ft = struct.unpack('<IIIII', at(imp, 20))
        if not nm: return None
        i = 0
        while True:
            v = struct.unpack('<Q', at((oft or ft) + 8 * i, 8))[0]
            if not v: break
            if ft + 8 * i == slot:
                return at(nm, 32).split(b'\0')[0].decode().lower() + '!' + at((v & 0x7fffffff) + 2, 48).split(b'\0')[0].decode()
            i += 1
        imp += 20
def rip_target(r, n, dispoff):
    return r + n + struct.unpack('<i', at(r + dispoff, 4))[0]
check('mode list count call is call [rax+0x40]', at(consts['kRvaModeListCallCount'], 3) == b'\xff\x50\x40')
check('mode list count return follows it', consts['kRvaModeListReturnCount'] == consts['kRvaModeListCallCount'] + 3)
check('mode list fill call is call [r10+0x40]', at(consts['kRvaModeListCallFill'], 4) == b'\x41\xff\x52\x40')
check('mode list fill return follows it', consts['kRvaModeListReturnFill'] == consts['kRvaModeListCallFill'] + 4)
check('count query passes pDesc = NULL (mov [rsp+0x20], r15 ; r15 = 0)', at(0x3F0E87, 5) == bytes([0x4c, 0x89, 0x7c, 0x24, 0x20]))
check('mode record: sizes below 640 x 480 skipped', at(0x3F0EFC, 7) == bytes([0x41, 0x81, 0xf9, 0x80, 0x02, 0x00, 0x00]) and at(0x3F0F08, 7) == bytes([0x41, 0x81, 0xf8, 0xe0, 0x01, 0x00, 0x00]))
check('mode record: stride 0x1c = sizeof(DXGI_MODE_DESC)', at(0x3F0F51, 4) == bytes([0x49, 0x83, 0xc2, 0x1c]))
# selection (three copies: start-up 0x3B7DD0, options 0x301800, window/device routine 0x48A550):
# wanted size, else desktop size, else entry 0
for name, zero, cmp_, wload, wl, hload, hl in [('options 0x301800', 0x301877, 0x3018DB, 0x30188E, 7, 0x30189C, 6),
                                               ('start-up 0x3B7DD0', 0x3B7E4D, 0x3B7F13, 0x3B7EB4, 6, 0x3B7EC2, 7)]:
    check(name + ': default entry index 0 (xor edi,edi)', at(zero, 2) == b'\x33\xff')
    check(name + ': cmp r8d,-1', at(cmp_, 4) == bytes([0x41, 0x83, 0xf8, 0xff]))
    check(name + ': wanted width read from kRvaWantedWidth', rip_target(wload, wl, wl - 4) == consts['kRvaWantedWidth'], hex(rip_target(wload, wl, wl - 4)))
    check(name + ': wanted height read from kRvaWantedHeight', rip_target(hload, hl, hl - 4) == consts['kRvaWantedHeight'], hex(rip_target(hload, hl, hl - 4)))
check('options 0x301800: cmovne edi,r8d', at(0x3018DF, 4) == bytes([0x41, 0x0f, 0x45, 0xf8]))
check('start-up 0x3B7DD0: cmovne edi,r8d', at(0x3B7F1F, 4) == bytes([0x41, 0x0f, 0x45, 0xf8]))
check('options 0x301800 calls InitDevice 0x3F2CE0', call_before(0x30194F, target=0x3F2CE0))
check('start-up 0x3B7DD0 calls InitDevice 0x3F2CE0', call_before(0x3B7F72, target=0x3F2CE0))
# third copy: r8d = -1, cmp r8d,-1 ; mov eax,r12d ; cmovne eax,r8d (r12d = 0 in this function)
check('window routine 0x48A550: or r8d,-1 before the loop', at(0x48A7FE, 4) == bytes([0x41, 0x83, 0xc8, 0xff]))
check('window routine: cmp r8d,-1 ; mov eax,r12d ; cmovne eax,r8d', at(0x48A85B, 11) == bytes([0x41, 0x83, 0xf8, 0xff, 0x41, 0x8b, 0xc4, 0x41, 0x0f, 0x45, 0xc0]))
check('window routine: wanted width/height read', rip_target(0x48A814, 7, 3) == consts['kRvaWantedWidth'] and rip_target(0x48A822, 6, 2) == consts['kRvaWantedHeight'])
check('window routine: result stored back to wanted width/height', rip_target(0x48A87F, 6, 2) == consts['kRvaWantedWidth'] and rip_target(0x48A885, 6, 2) == consts['kRvaWantedHeight'])
check('window routine: windowed-mode branch tests kRvaRunWindowed', rip_target(0x48A71D, 7, 3) == consts['kRvaRunWindowed'])
check('aspect function tests kRvaRunWindowed first', rip_target(0x2FA4DB, 7, 2) == consts['kRvaRunWindowed'])
# per-line tables: 2 x 1440 entries, one entry written per picture line (count = height from kRvaWantedHeight)
check('line tables span 2880 entries', (consts['kRvaLineTableEnd'] - consts['kRvaLineTable']) // 8 == 2880)
check('0x2FD160 loads the line count from kRvaWantedHeight', rip_target(0x2FD1C7, 7, 3) == consts['kRvaWantedHeight'])
check('0x2FD160 writes into kRvaLineTable', rip_target(0x2FD1D3, 7, 3) == consts['kRvaLineTable'])
check('0x2FD160 pads up to 1440 (0x5a0) lines only', at(0x2FD2E0, 5) == bytes([0xb9, 0xa0, 0x05, 0x00, 0x00]))
check('second table starts 1440 entries later', rip_target(0x302B59, 7, 3) == consts['kRvaLineTable'] + 1440 * 8)
# ---- 0.26 mouse ---------------------------------------------------------------------------
check('kRvaHandleMessage bytes', at(consts['kRvaHandleMessage'], 16) == arrays['kBytesHandleMessage'])
check('HandleMessage is called once, from the WH_GETMESSAGE hook', call_before(consts['kRvaHandleMessageRet'], target=consts['kRvaHandleMessage']))
check('hook proc tests wParam == 1 (PM_REMOVE) before it', at(0x457D77, 4) == bytes([0x48, 0x83, 0xfa, 0x01]))
check('WM_MOUSEMOVE stores LOWORD(lParam) to kRvaMouseX', at(0x4587A1, 4) == bytes([0x0f, 0xb7, 0x41, 0x18]) and rip_target(0x4587A5, 6, 2) == consts['kRvaMouseX'])
check('WM_MOUSEMOVE stores HIWORD(lParam) to kRvaMouseY', at(0x4587AB, 4) == bytes([0x0f, 0xb7, 0x41, 0x1a]) and rip_target(0x4587AF, 6, 2) == consts['kRvaMouseY'])
check('button messages store the same words (0x45B450)', at(0x45B465, 4) == bytes([0x0f, 0xb7, 0x41, 0x18]) and rip_target(0x45B469, 6, 2) == consts['kRvaMouseX'] and rip_target(0x45B473, 6, 2) == consts['kRvaMouseY'])
check('message range handled: 0x201..0x20C through a jump table', at(0x4587C6, 8) == bytes([0x05, 0xff, 0xfd, 0xff, 0xff, 0x83, 0xf8, 0x0b]))
check('wheel: ScreenToClient import', import_name(rip_target(0x458969, 6, 2)) == 'user32.dll!ScreenToClient', str(import_name(rip_target(0x458969, 6, 2))))
check('SetCursor 0x45CB50 stores x,y to kRvaMouseX/Y', rip_target(0x45CB5B, 6, 2) == consts['kRvaMouseX'] and rip_target(0x45CB61, 6, 2) == consts['kRvaMouseY'])
check('SetCursor calls ClientToScreen through kRvaIatClientToScreen', at(consts['kRvaSetCursorC2SReturn'] - 6, 2) == b'\xff\x15' and rip_target(consts['kRvaSetCursorC2SReturn'] - 6, 6, 2) == consts['kRvaIatClientToScreen'])
check('kRvaIatClientToScreen is user32.dll!ClientToScreen', import_name(consts['kRvaIatClientToScreen']) == 'user32.dll!ClientToScreen', str(import_name(consts['kRvaIatClientToScreen'])))
check('SetCursor then calls SetCursorPos', import_name(rip_target(0x45CB8B, 6, 2)) == 'user32.dll!SetCursorPos', str(import_name(rip_target(0x45CB8B, 6, 2))))
check('pointer centring passes picture width/2, height/2 to SetCursor', call_before(0x1F5986, target=0x45CB50) and rip_target(0x1F5963, 6, 2) == consts['kRvaWantedHeight'] and rip_target(0x1F5971, 6, 2) == consts['kRvaWantedWidth'])
check('mouse look: DirectInput GetDeviceState(0x10) at 0x45EF92', at(0x45EF8D, 8) == bytes([0xba, 0x10, 0x00, 0x00, 0x00, 0xff, 0x50, 0x48]))
check('InitDevice: existing swap chain -> SetResolutionBorderlessWindow 0x3EE780', call_before(0x3F2D20, target=0x3EE780))
check('borderless: ResizeBuffers = call [r10+0x68]', at(0x3EE8A9, 4) == bytes([0x41, 0xff, 0x52, 0x68]))
check('borderless: width/height args from the size record', at(0x3EE8A0, 4) == bytes([0x44, 0x8b, 0x4e, 0x04]) and at(0x3EE8A4, 3) == bytes([0x44, 0x8b, 0x06]))
check('borderless: GetMonitorInfoA import', import_name(rip_target(0x3EE983, 6, 2)) == 'user32.dll!GetMonitorInfoA', str(import_name(rip_target(0x3EE983, 6, 2))))
check('borderless: SetWindowPos import', import_name(rip_target(0x3EE9B8, 6, 2)) == 'user32.dll!SetWindowPos', str(import_name(rip_target(0x3EE9B8, 6, 2))))
check('aspect function reads width/height of the wanted size', rip_target(0x2FA4E4, 8, 4) == consts['kRvaWantedWidth'] and rip_target(0x2FA4EC, 8, 4) == consts['kRvaWantedHeight'])
check('SetProjection calls the aspect function', call_before(0x30258C, target=0x2FA4C0))
# ---- 0.27 main loop order ("same moment") ------------------------------------------------
check('app vtable +0x108 == App::Simulate', q(consts['kRvaAppVtable'] + 0x108) == consts['kRvaAppSimulate'])
check('main loop calls [vtable+0x108] (simulate), return = kRvaAppSimulateRet', at(consts['kRvaAppSimulateRet'] - 6, 6) == bytes([0xff, 0x90, 0x08, 0x01, 0x00, 0x00]))
check('main loop skips it while paused (cmp byte [rbx+kAppPaused],0 at 0x1F02D0)', at(0x1F02D0, 7) == bytes([0x80, 0xbb]) + struct.pack('<I', consts['kAppPaused']) + b'\x00')
check('then: wait for the render thread: lea rcx,[kRvaRenderQueue] ; call kRvaWaitQueue', call_before(0x1F039C, target=consts['kRvaWaitQueue']) and rip_target(0x1F0390, 7, 3) == consts['kRvaRenderQueue'])
check('the same wait is used elsewhere in the loop (0x1F047F, 0x1F04B8)', call_before(0x1F0484, target=consts['kRvaWaitQueue']) and rip_target(0x1F0478, 7, 3) == consts['kRvaRenderQueue'] and call_before(0x1F04BD, target=consts['kRvaWaitQueue']))
check('WaitQueue takes the queue in rcx and loops until it is empty', at(consts['kRvaWaitQueue'], 9) == bytes([0x40, 0x53, 0x48, 0x83, 0xec, 0x20, 0x48, 0x8b, 0x01]))
check('render job function 0x1F9B70 calls the draw stage 0x1F1E30', call_before(0x1F9B8C, target=0x1F1E30))
check('then: camera prepare / scene (0x1F1D00)', call_before(0x1F03B0, target=0x1F1D00))
check('then: render job dispatched (0x3DC6A0)', call_before(0x1F042E, target=0x3DC6A0))
check('then: App::Tick = call [vtable+0x158] at 0x1F0608', at(0x1F0608, 6) == bytes([0xff, 0x90, 0x58, 0x01, 0x00, 0x00]))
check('order in the loop body: simulate < wait < prepare < dispatch < tick', 0x1F038A < 0x1F0397 < 0x1F03AB < 0x1F0429 < 0x1F0608)
check('loop closes after the tick (jmp back to 0x1F02A4)', at(0x1F0622, 1) == b'\xe9' and 0x1F0622 + 5 + struct.unpack('<i', at(0x1F0623, 4))[0] == 0x1F02A4)
check('Simulate divides 1 by the time step (divss xmm0,[rbx+kAppStep])', at(0x1F0A71, 8) == bytes([0xf3, 0x0f, 0x5e, 0x83]) + struct.pack('<I', consts['kAppStep']))
check('Simulate is the only thing between the pause test and the wait that the hook leaves out', call_before(0x1F0384, target=0x282E30))
# ---- 0.27 frame timer ("same moment") ---------------------------------------------------
check('App::Tick calls the frame timer first', call_before(0x1F1C5F, target=consts['kRvaFrameTimer']))
check('timer: minimum = 1179648 / fps', struct.unpack('<f', at(rip_target(0x2D9CFA, 8, 4), 4))[0] == 1179648.0)
check('timer: elapsed = now - app[kAppLastTick]', at(0x2D9D27, 6) == bytes([0x2b, 0x8b]) + struct.pack('<I', consts['kAppLastTick']))
check('timer: app[kAppLastTick] = now', at(0x2D9D3B, 6) == bytes([0x89, 0x83]) + struct.pack('<I', consts['kAppLastTick']))
check('timer: ticks = elapsed / 18 (imul 0x38E38E39, sar 2)', at(0x2D9D50, 5) == bytes([0xb8, 0x39, 0x8e, 0xe3, 0x38]) and at(0x2D9D5E, 3) == bytes([0xc1, 0xfa, 0x02]) and consts['kTimerUnitsPerTick'] == 18)
check('timer: ticks limited by kRvaMaxFrameTicks (cmp + cmovg)', rip_target(0x2D9D7D, 6, 2) == consts['kRvaMaxFrameTicks'] and at(0x2D9D83, 3) == bytes([0x0f, 0x4f, 0x15]) and rip_target(0x2D9D83, 7, 3) == consts['kRvaMaxFrameTicks'])
check('timer: ticks stored to kRvaFrameTicks', rip_target(0x2D9D8A, 6, 2) == consts['kRvaFrameTicks'])
check('timer: step stored to app[kAppRawStep] and app[kAppStep]', at(0x2D9DAF, 8) == bytes([0xf3, 0x0f, 0x11, 0x83]) + struct.pack('<I', consts['kAppRawStep']) and at(0x2D9DC7, 8) == bytes([0xf3, 0x0f, 0x11, 0x83]) + struct.pack('<I', consts['kAppStep']))
check('ticks -> seconds factor is 1/65536', struct.unpack('<f', at(0x7BEDF4, 4))[0] == 1.0 / 65536)
check('default longest frame = 4096 ticks', struct.unpack('<i', at(consts['kRvaMaxFrameTicks'], 4))[0] == 4096)
check('App::Tick stores the scaled ticks back and the scaled step to app[kAppStep]', rip_target(0x1F1CD2, 6, 2) == consts['kRvaFrameTicks'] and at(0x1F1CE7, 8) == bytes([0xf3, 0x0f, 0x11, 0x83]) + struct.pack('<I', consts['kAppStep']))
check('App::Tick keeps the unscaled step in app[kAppRawStep]', at(0x1F1C8A, 8) == bytes([0xf3, 0x0f, 0x11, 0x8b]) + struct.pack('<I', consts['kAppRawStep']))
# every instruction that addresses kRvaMaxFrameTicks rip-relatively: only the timer's two per frame, three initialisers
hits = []
text_va, text_vs, text_ra, text_rs = secs[0]
blob = d[text_ra:text_ra + text_rs]
target = consts['kRvaMaxFrameTicks']
for off in range(0, len(blob) - 4):
    disp = struct.unpack_from('<i', blob, off)[0]
    if text_va + off + 4 + disp == target: hits.append(text_va + off)
# (three more byte patterns match by accident: "cmp dword [width], 1920" at 0x2BB235 / 0x2BB58A / 0x2BBA09 carries an
#  immediate after the displacement, so its real target is kRvaWantedWidth)
accident = {0x2BB237, 0x2BB58C, 0x2BBA0B}
check('the three accidental matches really address the width variable', all(rip_target(a - 2, 10, 2) == consts['kRvaWantedWidth'] and at(a - 2, 2) == b'\x81\x3d' for a in accident))
check('kRvaMaxFrameTicks is addressed from 5 places only (2 in the timer)', sorted(set(hits) - accident) == sorted([0x8982, 0x2D7E33, 0x2D9D7F, 0x2D9D86, 0x2DD46E]), ' '.join(hex(h) for h in hits))
# ---- 0.27 review: input poll and deferred key releases --------------------------------------
check('main loop: input poll 0x45A450 called at kRvaInputPollCall', call_before(consts['kRvaInputPollCall'] + 5, target=consts['kRvaInputPoll']))
check('main loop order: simulate < camera prepare < input poll < tick', consts['kRvaAppSimulateRet'] < 0x1F03AB < consts['kRvaInputPollCall'] < 0x1F0608 and call_before(0x1F03B0, target=0x1F1D00))
check('input poll: releases keys marked 1 in kRvaKeyReleasePending', at(0x45A483, 3) == bytes([0x83, 0xbc, 0x83]) and struct.unpack('<I', at(0x45A486, 4))[0] == consts['kRvaKeyReleasePending'] and at(0x45A48A, 1) == b'\x01')
check('input poll: key bytes at 0x2523F00, 600 (0x258) entries', struct.unpack('<I', at(0x45A499, 4))[0] == 0x2523F00 and at(0x45A4A7, 6) == bytes([0x48, 0x3d, 0x58, 0x02, 0x00, 0x00]) and consts['kKeyCount'] == 0x258)
check('input poll: clears every mark, then pumps the messages (0x45AA30)', struct.unpack('<I', at(0x45A4A0, 4))[0] == consts['kRvaKeyReleasePending'] and call_before(0x45A4C5, target=0x45AA30))
check('key release (deferred) marks the key with 1', at(0x458D17, 3) == bytes([0xc7, 0x84, 0x81]) and struct.unpack('<I', at(0x458D1A, 4))[0] == consts['kRvaKeyReleasePending'] and struct.unpack('<I', at(0x458D1E, 4))[0] == 1)
check('mouse wheel up: pseudo-key 0x20F down and release-pending in one message', rip_target(0x458991, 7, 2) == 0x2523F00 + 0x20F and rip_target(0x458998, 10, 2) == consts['kRvaKeyReleasePending'] + 4 * 0x20F)
check('mouse wheel down: pseudo-key 0x210 down and release-pending', rip_target(0x4589AA, 7, 2) == 0x2523F00 + 0x210 and rip_target(0x4589B1, 10, 2) == consts['kRvaKeyReleasePending'] + 4 * 0x210)
check('frame timer stores the unlimited real step at app+kAppRealStep (movss [rbx+0x1b4], xmm0)', at(0x2D9D75, 8) == bytes([0xf3, 0x0f, 0x11, 0x83]) + struct.pack('<I', consts['kAppRealStep']))
# ---- 0.28 own body ------------------------------------------------------------------------
def rtti_name(vt):
    col = q(vt - 8)
    td = struct.unpack('<I', at(col + 12, 4))[0]
    return at(td + 16, 64).split(b'\0')[0].decode(errors='replace')
check('kRvaGhostbusterVtable is CGhostbuster (RTTI)', rtti_name(consts['kRvaGhostbusterVtable']) == '.?AVCGhostbuster@@', rtti_name(consts['kRvaGhostbusterVtable']))
check('mirrors-only slot = vtable + 0x8C0 and holds kRvaMirrorOnly', consts['kRvaMirrorOnlySlot'] == consts['kRvaGhostbusterVtable'] + 0x8C0 and q(consts['kRvaMirrorOnlySlot']) == consts['kRvaMirrorOnly'])
check('kRvaMirrorOnly bytes', at(consts['kRvaMirrorOnly'], 16) == arrays['kBytesMirrorOnly'])
check('mirrors-only check: local player test, then goggles blend +0x247C4 >= 1.0', call_before(0xD35DE, target=0x2DD600) and at(0xD35FF, 8) == bytes([0xf3, 0x0f, 0x10, 0x83, 0xc4, 0x47, 0x02, 0x00]) and struct.unpack('<f', at(rip_target(0xD3607, 7, 3), 4))[0] == 1.0)
for key in ['kRvaMirrorOnlyRetBody', 'kRvaMirrorOnlyRetPack', 'kRvaMirrorOnlyRetHose', 'kRvaMirrorOnlyRetWand']:
    check(key + ' follows call [rax+0x8c0]', at(consts[key] - 6, 6) == bytes([0xff, 0x90, 0xc0, 0x08, 0x00, 0x00]))
check('kRvaMirrorOnlyRetBody2 follows call [rdx+0x8c0]', at(consts['kRvaMirrorOnlyRetBody2'] - 6, 6) == bytes([0xff, 0x92, 0xc0, 0x08, 0x00, 0x00]))
check('body item stores the answer in its draw block (mov [rdi+0x1c], al)', at(consts['kRvaMirrorOnlyRetBody'], 3) == bytes([0x88, 0x47, 0x1c]))
check('kRvaCameraRender bytes', at(consts['kRvaCameraRender'], 16) == arrays['kBytesCameraRender'])
check('camera vtable +0x38 = kRvaCameraRender', q(consts['kRvaCameraVtable'] + 0x38) == consts['kRvaCameraRender'])
check('main loop calls the active camera [vtable+0x38], returning to kRvaCameraRenderRet', at(consts['kRvaCameraRenderRet'] - 3, 3) == bytes([0xff, 0x50, 0x38]) and rip_target(0x1F1DF6, 7, 3) == consts['kRvaActiveCameraPtr'])
check('camera render: context reset, prepare [+0x40], visibility [+0x48], then tail-jump [+0x90] (the traversal runs inside the call)', call_before(0x450DE8, target=0x3042E0) and at(0x450DF1, 3) == bytes([0xff, 0x50, 0x40]) and at(0x450DFD, 3) == bytes([0xff, 0x50, 0x48]) and at(0x450E13, 7) == bytes([0x48, 0xff, 0xa0, 0x90, 0x00, 0x00, 0x00]))
check('draw-time decision 0xEEC70: pass 8 / mirror view (+0x180D8) test', at(consts['kRvaDrawPredicate'], 7) == bytes([0x45, 0x8b, 0x08, 0x41, 0x83, 0xf9, 0x08]) and at(0xEEC99, 8) == bytes([0x48, 0x83, 0xb8, 0xd8, 0x80, 0x01, 0x00, 0x00]))
# ---- 0.30 own shadow, wand, thigh piece --------------------------------------------------------
check('kRvaMirrorOnlyRetBody2b follows call [rdx+0x8c0] and stores al at block+0x11', at(consts['kRvaMirrorOnlyRetBody2b'] - 6, 6) == bytes([0xff, 0x92, 0xc0, 0x08, 0x00, 0x00]) and at(consts['kRvaMirrorOnlyRetBody2b'], 4) == bytes([0x88, 0x46, consts['kBody2BlockFlag'], 0x48]) or at(consts['kRvaMirrorOnlyRetBody2b'], 3) == bytes([0x88, 0x46, consts['kBody2BlockFlag']]))
check('first extra-body item also stores al at block+0x11', at(consts['kRvaMirrorOnlyRetBody2'], 3) == bytes([0x88, 0x46, consts['kBody2BlockFlag']]))
check('extra body pass shows sub-mesh actor+0xCE04 = part_thigh_R_0x (names at 0x73D658/6A8/6D0)', all(at(a, 15).startswith(b'part_thigh_R_0') for a in (0x73D658, 0x73D6A8, 0x73D6D0)))
check('pack / hose / wand store the answer as a byte (mov [rbx+0x40],al / [rdi+0x14],al / [rbx+0x14],al)', at(consts['kRvaMirrorOnlyRetPack'], 3) == bytes([0x88, 0x43, 0x40]) and at(consts['kRvaMirrorOnlyRetHose'], 3) == bytes([0x88, 0x47, 0x14]) and at(consts['kRvaMirrorOnlyRetWand'], 3) == bytes([0x88, 0x43, 0x14]))
check('kRvaDrawPredicate bytes', at(consts['kRvaDrawPredicate'], 16) == arrays['kBytesDrawPredicate'])
check('kRvaBody2DrawCallback bytes', at(consts['kRvaBody2DrawCallback'], 16) == arrays['kBytesBody2DrawCallback'])
callers = [int(x, 16) for x in re.search(r'kRvaDrawPredicateCalls\[4\]\s*=\s*\{([^}]*)\}', src)[1].split(',')]
def e8_target(c):
    b = at(c, 5); return b[0] == 0xE8 and c + 5 + struct.unpack('<i', b[1:])[0]
check('the four listed calls call the draw rule', all(e8_target(c) == consts['kRvaDrawPredicate'] for c in callers))
# every direct call / jump / address in .text that reaches the draw rule or the extra callback
tva, tvs, tra, trs = [x for x in secs if x[0] == 0x1000][0]
text = d[tra:tra + trs]
def rel_refs(target):
    out = []
    for m in re.finditer(rb'[\xe8\xe9]', text):
        i = m.start()
        if i + 5 <= len(text) and tva + i + 5 + struct.unpack_from('<i', text, i + 1)[0] == target: out.append(tva + i)
    return out
def lea_refs(target):
    out = []
    for m in re.finditer(rb'[\x48\x4c]\x8d[\x05\x0d\x15\x1d\x25\x2d\x35\x3d]', text):
        i = m.start()
        if i + 7 <= len(text) and tva + i + 7 + struct.unpack_from('<i', text, i + 3)[0] == target: out.append(tva + i)
    return out
pr = rel_refs(consts['kRvaDrawPredicate']); pl = lea_refs(consts['kRvaDrawPredicate'])
check('the draw rule is called only from the four listed places (no other call, jump or address taken)', sorted(pr) == sorted(callers) and not pl, [hex(x) for x in pr + pl])
check('each caller passes its stored byte: movzx edx, byte [rbx+0x1c] / [rbp+0x40] / [rbx+0x14] / [rbx+0x14], then one 4-byte rcx load, then the call', [at(c - 8, 4).hex() for c in callers] == ['0fb6531c', '0fb65540', '0fb65314', '0fb65314'] and all(at(c - 4, 2) in (b'\x48\x8b', b'\x49\x8b') for c in callers), [(at(c - 8, 8).hex()) for c in callers])
cl = lea_refs(consts['kRvaBody2DrawCallback']); cr = rel_refs(consts['kRvaBody2DrawCallback'])
check('the extra-body callback is only registered by the extra body pass (lea at 0x10B772 / 0x10B7D6)', sorted(cl) == [0x10B772, 0x10B7D6] and not cr, [hex(x) for x in cl + cr])
check('extra-body callback: block = [[ctx+0x68]+0x78], flag test at block+0x11, mirror view at [ctx+0x80]+0x180D8, pass at [ctx]', at(0x10F392, 8) == bytes([0x48, 0x8b, 0x41, 0x68, 0x48, 0x8b, 0x70, 0x78]) and at(0x10F3A3, 4) == bytes([0x80, 0x7e, 0x11, 0x00]) and at(0x10F3A9, 7) == bytes([0x48, 0x8b, 0x81, 0x80, 0x00, 0x00, 0x00]) and at(0x10F3BA, 3) == bytes([0x83, 0x39, 0x08]))
check('its skip path returns without drawing (jne to the epilogue 0x10F63D)', at(0x10F3BD, 2) == bytes([0x0f, 0x85]) and 0x10F3BD + 6 + struct.unpack('<i', at(0x10F3BF, 4))[0] == 0x10F63D)
check('draw rule offsets: pass [r8], view [r8+0x80], mirror +0x180D8', at(0xEEC92, 7) == bytes([0x49, 0x8b, 0x80, 0x80, 0x00, 0x00, 0x00]) and consts['kDrawCtxView'] == 0x80 and consts['kViewMirror'] == 0x180D8 and consts['kPassShadow'] == 8)
# ---- 0.32 head aim ---------------------------------------------------------------------------
check('kRvaAimFieldSet bytes', at(consts['kRvaAimFieldSet'], 16) == arrays['kBytesAimFieldSet'], hex(consts['kRvaAimFieldSet']))
wr = [int(x, 16) for x in re.findall(r'0x([0-9A-Fa-f]+)', re.search(r'kRvaAimWrapperCalls\[8\]\s*=\s*\{([^}]*)\}', src)[1])]
check('wrapper call list has 8 entries', len(wr) == 8, [hex(x) for x in wr])
check('each listed player-aim store is a call to the wrapper 0x76DC0', all(call_before(c + 5, target=consts['kRvaAimWrapper']) for c in wr))
wref = rel_refs(consts['kRvaAimWrapper']); wlea = lea_refs(consts['kRvaAimWrapper'])
check('the wrapper is called from exactly those 8 places (no other call, jump or address taken)', sorted(wref) == sorted(wr) and not wlea, [hex(x) for x in wref + wlea])
sref = rel_refs(consts['kRvaAimFieldSet']); slea = lea_refs(consts['kRvaAimFieldSet'])
check('the field setter 0x76D20 is reached only through the wrapper (jmp at 0x76E48 / 0x76E6C) and one call at 0x70DB8', sorted(sref) == [0x70DB8, 0x76E48, 0x76E6C] and not slea, [hex(x) for x in sref + slea])
check('setter: field = actor + 0xB584 (mov rax,[rcx-0xB584] ; add rcx,-0xB584 ; vtable call)', at(0x76D35, 7) == bytes([0x48, 0x8b, 0x81, 0x7c, 0x4a, 0xff, 0xff]) and at(0x76D45, 7) == bytes([0x48, 0x81, 0xc1, 0x7c, 0x4a, 0xff, 0xff]) and at(0x76D4F, 2) == bytes([0xff, 0x10]))
check('setter stores three floats at [field], +4, +8 after marking the property dirty', at(0x76D93, 12) == bytes([0x8b, 0x06, 0x41, 0x89, 0x06, 0x8b, 0x46, 0x04, 0x41, 0x89, 0x46, 0x04]) and at(0x76D9F, 3) == bytes([0x8b, 0x46, 0x08]) and at(0x76DA7, 4) == bytes([0x41, 0x89, 0x46, 0x08]))
check('wrapper: rcx += 0xB584 and it compares/stores through the setter', at(0x76DC5, 7) == bytes([0x48, 0x81, 0xc1, 0x84, 0xb5, 0x00, 0x00]) and consts['kAimDirOffset'] == 0xB584 and at(0x76E48, 1) == b'\xe9' and at(0x76E6C, 1) == b'\xe9')
check('getter 0x76E80 returns [actor+0xB584..+0xB58C]', at(0x76E86, 6) == bytes([0x8b, 0x81, 0x84, 0xb5, 0x00, 0x00]) and at(0x76E91, 6) == bytes([0x8b, 0x81, 0x88, 0xb5, 0x00, 0x00]) and at(0x76E9A, 6) == bytes([0x8b, 0x81, 0x8c, 0xb5, 0x00, 0x00]))
check('the proton stream update reads the aim through the getter (lea rdx,[rsp+0x40] ; mov rcx,rbx ; call 0x76E80 at 0xE659A)', at(0xE6592, 8) == bytes([0x48, 0x8d, 0x54, 0x24, 0x40, 0x48, 0x8b, 0xcb]) and call_before(consts['kRvaAimStreamRead'] + 5, target=consts['kRvaAimGetter']) and consts['kRvaAimStreamRead'] == 0xE659A)
check('stream update: no lock-on target (actor+0xB550 == 0) -> end = muzzle + aim * length (xmm6/xmm8/xmm7 <- [rsp+0x40..0x48], times [0xDD2DD0])', at(0xE67FA, 7) == bytes([0x48, 0x8b, 0x93, 0x50, 0xb5, 0x00, 0x00]) and at(0xE6A87, 18) == bytes([0xf3, 0x0f, 0x10, 0x7c, 0x24, 0x48, 0xf3, 0x44, 0x0f, 0x10, 0x44, 0x24, 0x44, 0xf3, 0x0f, 0x10, 0x74, 0x24]) and rip_target(0xE6A9A, 8, 4) == 0xDD2DD0)
check('default aim {0,0,1} at 0xDD4F40 (the getter falls back to it)', at(0xDD4F40, 12) == bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x80, 0x3f]) and rip_target(0x76EF1, 8, 4) == 0xDD4F40)
check('aim angles: the player-aim code turns aimPitch [rsi=+0x24898] and aimHeading [rdi=+0x24870] into a matrix with 0x3DD40 (stores at 0xDB7EA / 0xDB7F0, call at 0xDB7FB) and passes row [rbp-0x14/-0x20/-0x8] as the vector to the wrapper (store to [rsp+0x68..0x70] at 0xDB958, wrapper call at 0xDBA02)', at(0xDB7EA, 12) == bytes([0xf3, 0x0f, 0x11, 0x44, 0x24, 0x40, 0xf3, 0x0f, 0x11, 0x4c, 0x24, 0x44]) and call_before(0xDB800, target=0x3DD40) and at(0xDB958, 36) == bytes.fromhex('f30f1045ecf30f1055e0f30f104df8f30f11442 46c0f5ac2f30f11542468f30f114c2470'.replace(' ', '')) and at(0xDB9F3, 15) == bytes.fromhex('4c8d05f64a6900488bcb488d542468'))
# ---- 0.33 gamepad -----------------------------------------------------------------------------
def import_ordinal(slot):
    imp = struct.unpack_from('<I', d, opt + 112 + 8)[0]
    while True:
        oft, _, _, nm, ft = struct.unpack('<IIIII', at(imp, 20))
        if not nm: return None
        i = 0
        while True:
            v = struct.unpack('<Q', at((oft or ft) + 8 * i, 8))[0]
            if not v: break
            if ft + 8 * i == slot:
                return at(nm, 32).split(b'\0')[0].decode().lower(), (v & 0xffff) if v >> 63 else None
            i += 1
        imp += 20
for key, n in [('kRvaIatXInputGetState', 2), ('kRvaIatXInputSetState', 3), ('kRvaIatXInputGetCaps', 4)]:
    check('%s is xinput1_3.dll ordinal %d' % (key, n), import_ordinal(consts[key]) == ('xinput1_3.dll', n), str(import_ordinal(consts[key])))
def iat_thunk(slot):   # jmp [rip+x] stub for an import (the game calls these, not the slot directly)
    va, buf = text_bytes_for_scan()
    i = buf.find(b'\xff\x25')
    while i >= 0:
        if va + i + 6 + struct.unpack_from('<i', buf, i + 2)[0] == slot: return va + i
        i = buf.find(b'\xff\x25', i + 1)
def call_sites(target):
    va, buf = text_bytes_for_scan()
    out = []
    i = buf.find(b'\xe8')
    while i >= 0:
        if i + 5 <= len(buf) and va + i + 5 + struct.unpack_from('<i', buf, i + 1)[0] == target: out.append(va + i)
        i = buf.find(b'\xe8', i + 1)
    return out
def text_bytes_for_scan():
    va, vs, ra, rs = secs[0]
    return va, d[ra:ra + rs]
thunks = {}
for key in ['kRvaIatXInputGetState', 'kRvaIatXInputSetState', 'kRvaIatXInputGetCaps']:
    thunks[key] = iat_thunk(consts[key])
    cs = call_sites(thunks[key]) if thunks[key] else []
    check('%s: jmp [slot] thunk at %s, called from %d sites' % (key, hex(thunks[key] or 0), len(cs)), thunks[key] is not None and len(cs) >= 1, str([hex(c) for c in cs[:4]]))
pd = [r for r in call_sites(thunks['kRvaIatXInputGetCaps']) if consts['kRvaPadDetect'] <= r < consts['kRvaPadDetect'] + 0x100]
pd2 = [r for r in call_sites(thunks['kRvaIatXInputGetState']) if consts['kRvaPadDetect'] <= r < consts['kRvaPadDetect'] + 0x100]
check('pad detection function 0x45D7B0 calls GetCapabilities and GetState', len(pd) >= 1 and len(pd2) >= 1, str([hex(c) for c in pd + pd2]))

# ---- 1.7.92 DirectInput pads ------------------------------------------------------------------
check('kRvaPadDisconnect bytes', at(consts['kRvaPadDisconnect'], 16) == arrays['kBytesPadDisconnect'])
check('kRvaPadScan bytes', at(consts['kRvaPadScan'], 16) == arrays['kBytesPadScan'])
_scan = at(consts['kRvaPadScan'], 0x140)
_di_ref = [i for i in range(len(_scan) - 7) if _scan[i:i+3] == bytes([0x48, 0x8d, 0x35]) and consts['kRvaPadScan'] + i + 7 + struct.unpack_from('<i', _scan, i + 3)[0] == consts['kRvaDiDevices']]
check('the pad scan 0x460480 walks the DirectInput device array (lea rsi,[kRvaDiDevices]) and skips XInput for a slot that has one (cmp [rsi],rbp; jne)', len(_di_ref) == 1 and _scan[_di_ref[0] + 7:_di_ref[0] + 11] == bytes([0x48, 0x39, 0x2e, 0x75]), str(_di_ref))
_sc_calls = [r for r in call_sites(thunks['kRvaIatXInputGetState']) if consts['kRvaPadScan'] <= r < consts['kRvaPadScan'] + 0x100]
check('the pad scan calls XInputGetState, the detection kRvaPadDetect and the disconnect kRvaPadDisconnect', len(_sc_calls) == 1 and consts['kRvaPadDetect'] in [r + 5 + struct.unpack_from('<i', at(r + 1, 4))[0] for r in range(consts['kRvaPadScan'], consts['kRvaPadScan'] + 0x100) if at(r, 1) == b'\xe8'] and consts['kRvaPadDisconnect'] in [r + 5 + struct.unpack_from('<i', at(r + 1, 4))[0] for r in range(consts['kRvaPadScan'], consts['kRvaPadScan'] + 0x100) if at(r, 1) == b'\xe8'])
_det = at(consts['kRvaPadDetect'], 0x1A0)
check('the detection sets the slot flag kRvaPadXFlags (mov byte [rdi+rbp+flags],1 near its end)', bytes([0xc6, 0x84, 0x2f]) + struct.pack('<I', consts['kRvaPadXFlags']) + b'\x01' in at(consts['kRvaPadDetect'], 0x260))
TIP_CALLERS = sorted(int(x, 16) for x in re.search(r'kRvaTipCallers\[6\]\s*=\s*\{([^}]*)\}', src)[1].split(','))
# ---- 0.34 wand tip --------------------------------------------------------------------------
check('attach-matrix function kRvaAttachMatrix starts with the expected bytes', at(consts['kRvaAttachMatrix'], 16) == arrays['kBytesAttachMatrix'])
check('prop-get helper kRvaPropGet starts with the expected bytes', at(consts['kRvaPropGet'], 16) == arrays['kBytesPropGet'])
check('the 6 callers of kRvaAttachMatrix are exactly kRvaTipCallers', sorted(call_sites(consts['kRvaAttachMatrix'])) == TIP_CALLERS, str([hex(x) for x in call_sites(consts['kRvaAttachMatrix'])]))
check('kRvaTipString is "tip"', at(consts['kRvaTipString'], 4) == b'tip\0')
check('the stream update asks for "tip" (lea r8,[rip+x] at 0xE63E9) and gets the matrix at [rbp+0x3A0] (lea rdx at 0xE63F0)', rip_target(0xE63E9, 7, 3) == consts['kRvaTipString'] and at(0xE63F0, 7) == bytes([0x48, 0x8d, 0x95, 0xa0, 0x03, 0x00, 0x00]))
check('the muzzle is read from the matrix translation: movss xmm2,[rbp+0x3D0] at 0xE644E', at(0xE644E, 8) == bytes([0xf3, 0x0f, 0x10, 0x95, 0xd0, 0x03, 0x00, 0x00]))
check('attach matrix = bone matrix x actor world matrix [actor+0x24718] (lea r8 at 0xD3CD4, call 0x17210 at 0xD3CE3)', at(0xD3CD4, 7) == bytes([0x4c, 0x8d, 0x87, 0x18, 0x47, 0x02, 0x00]))
# ---- 0.45 stream axis ------------------------------------------------------------------------
check('vec-to-angles function kRvaVecToAngles starts with the expected bytes', at(consts['kRvaVecToAngles'], 16) == arrays['kBytesVecToAngles'])
check('the stream update calls kRvaVecToAngles and returns to kRvaStreamAnglesReturn', call_before(consts['kRvaStreamAnglesReturn'], target=consts['kRvaVecToAngles']))
check('vec-to-angles stores heading at out[1] (movss [rbx+4],xmm8 at 0x320084) and pitch at out[0] (movss [rbx],xmm0 at 0x320090)', at(0x320084, 6) == bytes([0xf3, 0x44, 0x0f, 0x11, 0x43, 0x04]) and at(0x320090, 4) == bytes([0xf3, 0x0f, 0x11, 0x03]))
check('stream update: the local hit point is normalised (call 0x1D4F0 at 0xE6BDC) before the angle call at 0xE6BE9', call_before(0xE6BE1, target=0x1D4F0) and call_before(0xE6BEE, target=consts['kRvaVecToAngles']))
check('stream update: the limited angles go to the angles-to-matrix function 0x3DD40 (call at 0xE6CC2)', call_before(0xE6CC7, target=0x3DD40))
check('euler-from-matrix 0x2C6BE0 reads row 2 (m[8],m[9],m[10]) for pitch / heading: movss xmm13,[rcx+0x20] at 0x2C6C33, xmm6=[rdi+0x24] at 0x2C6C91, xmm14=[rdi+0x28] at 0x2C6CE4',
      at(0x2C6C33, 6) == bytes([0xf3, 0x44, 0x0f, 0x10, 0x69, 0x20]) and at(0x2C6C91, 5) == bytes([0xf3, 0x0f, 0x10, 0x77, 0x24]) and at(0x2C6CE4, 6) == bytes([0xf3, 0x44, 0x0f, 0x10, 0x77, 0x28]))
check('angles-to-vector 0x3220A0 stores its third result (z, the forward axis) at out[2] (movss [rdi+8],xmm1 at 0x32213C)', at(0x32213C, 5) == bytes([0xf3, 0x0f, 0x11, 0x4f, 0x08]))
check('orthonormalise 0x2C7940 keeps row 2 as the master axis: first loads are movss xmm7,[rcx+0x20] / xmm8,[rcx+0x24] / xmm9,[rcx+0x28]',
      at(0x2C7956, 5) == bytes([0xf3, 0x0f, 0x10, 0x79, 0x20]) and at(0x2C7963, 6) == bytes([0xf3, 0x44, 0x0f, 0x10, 0x41, 0x24]) and at(0x2C7972, 6) == bytes([0xf3, 0x44, 0x0f, 0x10, 0x49, 0x28]))
# ---- 0.35 button getters ---------------------------------------------------------------------
for fn, arr in [('kRvaBtnPressed', 'kBytesBtnPressed'), ('kRvaBtnHeld2', 'kBytesBtnHeld2'), ('kRvaBtnHeld', 'kBytesBtnHeld')]:
    check(fn + ' bytes', at(consts[fn], 16) == arrays[arr])
check('button array pointer 0xDD36D8 is read by the held getter (mov rax,[rip+x] at 0x297290)', rip_target(0x297290, 7, 3) == consts['kRvaBtnArrayPtr'])
# ---- 1.7.8 the player's character update (speed boost hook)
check('kRvaCharUpdate bytes', at(consts['kRvaCharUpdate'], 16) == arrays['kBytesCharUpdate'])
# 1.7.9 the goggles
check('kRvaIsGoggles bytes', at(consts['kRvaIsGoggles'], 16) == arrays['kBytesIsGoggles'])
check('kRvaHudSetGoggles bytes', at(consts['kRvaHudSetGoggles'], 16) == arrays['kBytesHudSetGoggles'])
for nm in ('kRetGogHud', 'kRetGogHudFrame', 'kRetGogRender'):
    r = consts[nm]; b5 = at(r - 5, 5)
    ok = b5 is not None and b5[0] == 0xE8 and (r + struct.unpack('<i', b5[1:])[0]) == consts['kRvaIsGoggles']
    check(nm + ' follows a call to isGogglesActive', ok, hex(r))
# the three sites pass the answer to HUD::setGoggles (the two HUD sites) / into the render flag
check('HUD site 1 calls setGoggles', at(consts['kRetGogHud'] + 10, 5)[0] == 0xE8 and (consts['kRetGogHud'] + 15 + struct.unpack('<i', at(consts['kRetGogHud'] + 11, 4))[0]) == consts['kRvaHudSetGoggles'])
check('HUD site 2 calls setGoggles', at(consts['kRetGogHudFrame'] + 10, 5)[0] == 0xE8 and (consts['kRetGogHudFrame'] + 15 + struct.unpack('<i', at(consts['kRetGogHudFrame'] + 11, 4))[0]) == consts['kRvaHudSetGoggles'])
check('inventory item 5 state test (0x10CAC0): cmp dword [rcx+8*rdx+0xcfe0], 2', at(0x10CAC0, 16)[7:15] == bytes([0x83,0xbc,0xd1,0xe0,0xcf,0x00,0x00,0x02]) or at(0x10CAC0, 16)[3:15] == bytes([0x83,0xbc,0xd1,0xe0,0xcf,0x00,0x00,0x02]) or bytes([0xe0,0xcf,0x00,0x00,0x02]) in at(0x10CAC0, 16))
check('UV debug byte is read by the draw command 0x16FD0', struct.unpack('<i', at(0x16FD0 + 2, 4))[0] + 0x16FD7 == consts['kRvaUvDebugByte'])
# ---- 0.36 controller type -------------------------------------------------------------------
for _n,_b in [('kRvaBindUpdate','kBytesBindUpdate'),('kRvaBindQ0','kBytesBindQ0'),('kRvaBindQ1','kBytesBindQ1'),('kRvaBindQ2','kBytesBindQ2')]:
    check(_n+' bytes', at(consts[_n],16)==arrays[_b])
check('kRvaSetControllerType bytes', at(consts['kRvaSetControllerType'], 16) == arrays['kBytesSetControllerType'])
check('kRvaGetControllerType = mov eax,[rcx+0x49200]; ret', at(consts['kRvaGetControllerType'], 16) == arrays['kBytesGetControllerType'])
# ---- 0.43 menu frame rate ---------------------------------------------------------------------
check('App constructor sets the cap flag: mov byte [rsi+0x4A9C0],1 at 0x1ED181 (offset = kAppFpsCapFlag)', at(0x1ED181, 7) == bytes([0xc6, 0x86]) + struct.pack('<I', consts['kAppFpsCapFlag']) + b'\x01')
check('App constructor sets the cap value: mov dword [rsi+0x4A9BC],30.0f at 0x1ED188 (offset = kAppFpsCapValue)', at(0x1ED188, 10) == bytes([0xc7, 0x86]) + struct.pack('<I', consts['kAppFpsCapValue']) + struct.pack('<f', 30.0))
check('App::Tick tests the flag and loads the cap: cmp byte [rcx+flag],0 at 0x1F1C46, movss xmm1,[rcx+value] at 0x1F1C52', at(0x1F1C46, 7) == bytes([0x80, 0xb9]) + struct.pack('<I', consts['kAppFpsCapFlag']) + b'\x00' and at(0x1F1C52, 8) == bytes([0xf3, 0x0f, 0x10, 0x89]) + struct.pack('<I', consts['kAppFpsCapValue']))
# ---- 0.29 overlay ---------------------------------------------------------------------------
for fn, arr in [('kRvaD3DViewport', 'kBytesD3DViewport'), ('kRvaHudDraw', 'kBytesHudDraw'), ('kRvaRingDraw', 'kBytesRingDraw'), ('kRvaTextFlush', 'kBytesTextFlush')]:
    check(fn + ' bytes', at(consts[fn], 16) == arrays[arr])
check('HUD::Draw has its call at kRvaHudDrawCall (after post-processing 0x41BE90 at 0x1FE5F1)', call_before(consts['kRvaHudDrawCall'] + 5, target=consts['kRvaHudDraw']) and call_before(0x1FE5F6, target=0x41BE90) and 0x1FE5F1 < consts['kRvaHudDrawCall'])
check('3D scene drawn before (0x451E10 at 0x1FE55D)', call_before(0x1FE562, target=0x451E10))
check('HUD::Draw flushes text at its start', call_before(0x253292, target=consts['kRvaTextFlush']))
check('the viewport slot is filled with kRvaD3DViewport (lea at 0x3B811B, store at 0x3B8122)', rip_target(0x3B811B, 7, 3) == consts['kRvaD3DViewport'] and rip_target(0x3B8122, 7, 3) == consts['kRvaViewportSlot'])
check('SetViewport 0x302200 calls through the slot', rip_target(0x302245, 7, 3) == consts['kRvaViewportSlot'])
check('D3D viewport: caches at kRvaViewportCache and calls RSSetViewports [ctx+0x160]', rip_target(0x3F58B3, 7, 3) == consts['kRvaViewportCache'] and at(0x3F5917, 6) == bytes([0xff, 0x90, 0x60, 0x01, 0x00, 0x00]))
check('health ring draw is the vtable entry at kRvaRingDrawSlot', q(consts['kRvaRingDrawSlot']) == consts['kRvaRingDraw'])
check('overlay vertex shaders map back-buffer pixels with cScreenCenter (so the Direct3D viewport places them)', d.count(b'Output.Pos.xy = (Input.vPos.xy - cScreenCenter.xy) * cScreenCenter.zw;') == 2)
if len(sys.argv) > 2:
    log = open(sys.argv[2], errors='replace').read()
    m = re.search(r'HOOK camera-prepare status=0 target=([0-9a-f]+)', log)
    lbase = int(m[1], 16) - consts['kRvaCameraPrepare']
    for name, key in [('basis', 'kRvaBasisSetter'), ('visibility-stage', 'kRvaVisibilityStage')]:
        t = int(re.search(r'HOOK %s status=0 target=([0-9a-f]+)' % name, log)[1], 16)
        check('0.16 log %s target' % name, t - lbase == consts[key])
    cam = int(re.search(r'SOURCEAUDIT .*? camera=([0-9a-f]+) context=([0-9a-f]+)', log)[2], 16)
    check('0.16 log render context', cam - lbase == consts['kRvaRenderContext'])
    check('0.16 log basis caller', 'callerRVA=%x' % consts['kRvaBasisReturn'] in log)
    check('0.16 log prepare caller', 'callerRVA=%x' % consts['kRvaPrepareReturn'] in log)
    check('0.16 log vtable', 'vtableRVA=%x' % consts['kRvaCameraVtable'] in log)
# 0.51 wand model: matrix product, the push call site, the draw callbacks and collectors
check('0.51 matrix product bytes', at(consts['kRvaMatMul'], 16) == arrays['kBytesMatMul'], hex(consts['kRvaMatMul']))
cs = at(consts['kRvaWandPushCall'], 5)
check('0.51 wand push call -> matrix product', cs[0] == 0xE8 and consts['kRvaWandPushCall'] + 5 + struct.unpack('<i', cs[1:])[0] == consts['kRvaMatMul'])
check('0.51 wand push return', consts['kRvaWandPushCall'] + 5 == consts['kRvaWandPushRet'])
# the push is followed by: lea rcx,[rdi+0x24718] before it (world matrix of the wand instance)
pre = at(consts['kRvaWandPushCall'] - 0x15, 0x15)
check('0.51 world matrix offset 0x24718 loaded before the push', struct.pack('<I', consts['kOffWandWorld']) in pre, pre.hex())
# wand collector 0xD3340 registers the wand draw callback 0xD3520 (lea r12,[rip+0x1ac])
col = at(0xD336D, 7)
check('0.51 wand collector registers callback 0xD3520', col[:3] == bytes([0x4c, 0x8d, 0x25]) and 0xD336D + 7 + struct.unpack('<i', col[3:])[0] == 0xD3520)
# 0.52 the other world-matrix products of the player's render function (body base, extras, hose)
for nm in ('Body', 'Extras', 'Hose'):
    call, ret = consts['kRva%sPushCall' % nm], consts['kRva%sPushRet' % nm]
    c = at(call, 5)
    check('0.52 %s push call -> matrix product' % nm, c[0] == 0xE8 and call + 5 + struct.unpack('<i', c[1:])[0] == consts['kRvaMatMul'])
    check('0.52 %s push return' % nm, call + 5 == ret)
pre = at(consts['kRvaExtrasPushCall'] - 0x11, 0x11)
check('0.52 extras matrix offset 0x246d8 loaded before the push', struct.pack('<I', consts['kOffExtrasWorld']) in pre, pre.hex())
pre = at(consts['kRvaHosePushCall'] - 0x10, 0x10)
check('0.52 hose matrix offset 0x24758 loaded before the push', struct.pack('<I', consts['kOffHoseWorld']) in pre, pre.hex())
# body base: the matrix is built on the stack from actor+0xF4 ... and the position actor+0x54 (lea rbx,[rcx+0x54])
pre = at(consts['kRvaBodyPushCall'] - 0xFF, 0xFF)
check('0.52 body base built from actor position +0x54 and basis +0xF4', b'\x48\x8d\x59\x54' in pre and struct.pack('<I', 0xF4) in pre, '')

# 0.57 skeleton: the bone code the arm override calls, and where the data lives
for fn, arr in [('kRvaModelEnsureWorld', 'kBytesModelEnsureWorld'), ('kRvaModelLocalToMatrix', 'kBytesModelLocalToMatrix'), ('kRvaModelMul34', 'kBytesModelMul34')]:
    check('0.57 %s bytes' % fn, at(consts[fn], 16) == arrays[arr], hex(consts[fn]))
loader = at(0x1FD40, 0x100)
for i, off in enumerate((0xcdc8, 0xcdcc, 0xcdd0, 0xcdd4, 0xcdd8, 0xcddc)):
    check('0.57 bone-index loader stores actor+0x%x' % off, struct.pack('<I', off) in loader)
check('0.57 loader asks the skeleton at actor+0x430', b'\x48\x81\xc1\x30\x04\x00\x00' in loader or b'\x48\x81\xc1\x30\x04' in loader, '')
bodyc = at(0xD2187, 0x20)
check('0.57 render pass loads the body model (lea r14,[rdi+0x430]) and calls the model render 0x15640', b'\x4c\x8d\xb7\x30\x04\x00\x00' in bodyc, bodyc.hex())
c = at(0xD219A, 5)
check('0.57 model render call 0x15640', c[0] == 0xE8 and 0xD219A + 5 + struct.unpack('<i', c[1:])[0] == 0x15640)
ens = at(0x30D450, 0x40)
check('0.57 EnsureWorld offsets 0x2ae8 0x2b00 0x7930 0x2b08', all(struct.pack('<I', o) in ens + at(0x30D410, 0x20) for o in (0x2ae8, 0x2b00, 0x7930, 0x2b08)))
# 0.94 the game's own PKE meter: hook targets, vtable slots, pose setters, player pointer
for fn, arr in [('kRvaPkeCollect', 'kBytesPkeCollect'), ('kRvaPkeUpdate', 'kBytesPkeUpdate'), ('kRvaPkeSetMatrix', 'kBytesPkeSetMatrix'), ('kRvaEntityAttachWorld', 'kBytesEntityAttachWorld')]:
    check('0.94 %s bytes' % fn, at(consts[fn], 16) == arrays[arr], hex(consts[fn]))
check('0.94 CPKEMeter vtable +0x80 == update', q(consts['kRvaPkeMeterVtable'] + 0x80) == consts['kRvaPkeUpdate'])
check('0.94 CPKEMeter vtable +0xE8 == collect', q(consts['kRvaPkeMeterVtable'] + 0xE8) == consts['kRvaPkeCollect'])
check('0.94 CPKEMeter vtable +0x240 returns the model instance (lea rax,[rcx+0x428])', at(q(consts['kRvaPkeMeterVtable'] + 0x240), 7) == bytes([0x48, 0x8d, 0x81, 0x28, 0x04, 0x00, 0x00]) or at(q(consts['kRvaPkeMeterVtable'] + 0x240), 8)[:3] == bytes([0x48, 0x8d, 0x81]))
st = at(consts['kRvaPkeSetMatrix'], 0x80)
check('0.94 set-matrix writes pose position at +0x4B8 and rotation at +0x4C4', struct.pack('<I', consts['kOffPkePos']) in st and struct.pack('<I', consts['kOffPkeRot']) in st)
check('0.94 player update (0xD6270) reads the PKE object at player+0x24D90', struct.pack('<I', consts['kOffPlayerPke']) in at(0xD6270, 0x400))
check('0.94 CPKESource vtable is not the PKE meter vtable', consts['kRvaPkeSourceVtable'] != consts['kRvaPkeMeterVtable'])
# 1.4 the game's real PKE scan rules and the goggle frame
for fn, arr in [('kRvaPkeScanOk', 'kBytesPkeScanOk'), ('kRvaPkeAlignInit', 'kBytesPkeAlignInit'), ('kRvaGoggleStateRead', 'kBytesGoggleStateRead')]:
    check('1.4 %s bytes' % fn, at(consts[fn], 16) == arrays[arr], hex(consts[fn]))
import math
ang = struct.unpack('<d', at(consts['kRvaPkeAlignAngle'], 8))[0]
check('1.4 scan cone angle constant is 18 degrees', abs(math.degrees(ang) - 18.0) < 1e-3, '%.4f deg' % math.degrees(ang))
ai = at(consts['kRvaPkeAlignInit'], 0x20)
# movss [rip+x], xmm1 stores the cos() result into the threshold global
k = ai.find(b'\xf3\x0f\x11\x0d')
check('1.4 the static initialiser stores the cone cosine in kRvaPkeAlignMin', k >= 0 and consts['kRvaPkeAlignInit'] + k + 8 + struct.unpack('<i', ai[k + 4:k + 8])[0] == consts['kRvaPkeAlignMin'])
sok = at(consts['kRvaPkeScanOk'], 0xC0)
check('1.4 scan_ok reads the state at +0x53C, the record slot +0x520, the visible flag +0x4FC and the alignment +0x500', all(struct.pack('<I', o) in sok for o in (0x53C, 0x520, 0x4FC, 0x500, 0x540)))
check('1.4 scan_ok compares the alignment with kRvaPkeAlignMin (comiss xmm0,[rip+x])', any(sok[i:i + 3] == b'\x0f\x2f\x05' and consts['kRvaPkeScanOk'] + i + 7 + struct.unpack('<i', sok[i + 3:i + 7])[0] == consts['kRvaPkeAlignMin'] for i in range(len(sok) - 7)))
gs = at(consts['kRvaGoggleStateRead'], 13)
check('1.4 goggle frame gate is mov eax,[rdi+0x448]; dec eax; cmp eax,1; ja', gs[:6] == bytes([0x8b, 0x87, 0x48, 0x04, 0, 0]) and gs[6:8] == bytes([0xff, 0xc8]) and gs[8:11] == bytes([0x83, 0xf8, 0x01]) and gs[11] == 0x77)
# 1.6 how a PKE scan adds progress: the ping, the rate, the level
for fn, arr in [('kRvaPkeScanPulse', 'kBytesPkeScanPulse'), ('kRvaPkeScanRate', 'kBytesPkeScanRate')]:
    check('1.6 %s bytes' % fn, at(consts[fn], 16) == arrays[arr], hex(consts[fn]))
import re as _re
def callsites(target, lo, n):
    b = at(lo, n); out = []
    for i in range(len(b) - 5):
        if b[i] == 0xE8 and lo + i + 5 + struct.unpack('<i', b[i + 1:i + 5])[0] == target: out.append(lo + i)
    return out
check('1.6 the update 0x141F60 pings the scan (call 0x1460D0) three times', len(callsites(consts['kRvaPkeScanPulse'], 0x141F60, 0x1B0)) == 3)
check('1.6 the update 0x141F60 asks scan_ok and compares the input byte +0x538', len(callsites(consts['kRvaPkeScanOk'], 0x141F60, 0x1B0)) >= 1 and bytes([0x38, 0x05, 0x00, 0x00]) in at(0x141F60, 0x1B0))
pu = at(consts['kRvaPkeScanPulse'], 0x300)
check('1.6 the ping asks the rate getter 0x145F20 and calls the target virtual +0x3E8 and +0x3E0', len(callsites(consts['kRvaPkeScanRate'], consts['kRvaPkeScanPulse'], 0x300)) == 1 and bytes([0xff, 0x90, 0xe8, 0x03, 0x00, 0x00]) in pu and bytes([0xff, 0x90, 0xe0, 0x03, 0x00, 0x00]) in pu)
check('1.6 the ping stores the cooldown at +0x540 and the flag at +0x544', bytes([0x40, 0x88, 0xab, 0x44, 0x05, 0x00, 0x00]) in pu and bytes([0xf3, 0x0f, 0x11, 0x83, 0x40, 0x05, 0x00, 0x00]) in pu)
check('1.6 the rate getter calls the level getter 0x145E00', len(callsites(consts['kRvaPkeScanLevel'], consts['kRvaPkeScanRate'], 0x20)) == 1)
lv = at(consts['kRvaPkeScanLevel'], 0x70)
check('1.6 the level getter reads the signal S at +0x534', struct.pack('<I', consts['kOffPkeSignal']) in lv)
rt = struct.unpack('<ffff', b''.join(at(a, 4) for a in (0x734ebc, 0x734eb8, 0x737734, 0x734ebc)))
check('1.6 ping rates are 1.0 / 0.5 / 0.25', abs(rt[0] - 1.0) < 1e-6 and abs(rt[1] - 0.5) < 1e-6 and abs(rt[2] - 0.25) < 1e-6, str(rt[:3]))
lvl = struct.unpack('<ffffff', b''.join(at(a, 4) for a in (0xdce5a4, 0xdce5a8, 0xdce5ac, 0xdce5b0, 0xdce5b4, 0xdce5b8)))
check('1.6 level thresholds are 40/80/140 and 48/96/168', lvl == (40.0, 80.0, 140.0, 48.0, 96.0, 168.0), str(lvl))
check('1.6 the update 0x141F60 reads the owner state at +0xD3E8 through 0xD0590 (mov eax,[rcx+0xd3e8]; ret)', at(0xd0590, 7) == bytes([0x8b, 0x81, 0xe8, 0xd3, 0x00, 0x00, 0xc3]) and len(callsites(0xd0590, 0x141F60, 0x1B0)) == 1)
# 1.5 the game's own health ring: update / focus getters
for fn, arr in [('kRvaRingUpdate', 'kBytesRingUpdate'), ('kRvaFocusHealth', 'kBytesFocusHealth'), ('kRvaFocusPos', 'kBytesFocusPos')]:
    check('1.5 %s bytes' % fn, at(consts[fn], 16) == arrays[arr], hex(consts[fn]))
ru = at(consts['kRvaRingUpdate'], 0x3C0)
def call_to(buf, base, target):
    for i in range(len(buf) - 5):
        if buf[i] == 0xE8 and base + i + 5 + struct.unpack('<i', buf[i + 1:i + 5])[0] == target:
            return True
    return False
check('1.5 the ring update asks the health getter 0xDE1E0 and the position getter 0xDE1F0', call_to(ru, consts['kRvaRingUpdate'], consts['kRvaFocusHealth']) and call_to(ru, consts['kRvaRingUpdate'], consts['kRvaFocusPos']))
check('1.5 the health getter reads player+0x24938 (movss xmm0,[rcx+0x24938]; ret)', at(consts['kRvaFocusHealth'], 9) == bytes([0xf3, 0x0f, 0x10, 0x81]) + struct.pack('<I', consts['kOffFocusHealth']) + b'\xc3')
fp = at(consts['kRvaFocusPos'], 0xC0)
check('1.5 the position getter reads the locked target at player+0x2E8 and copies target+0x54..0x5C', struct.pack('<I', consts['kOffLockTarget']) in fp and bytes([0x8b, 0x41, 0x54]) in fp and bytes([0x8b, 0x41, 0x58]) in fp and bytes([0x8b, 0x41, 0x5c]) in fp)
check('1.5 the ring draw 0x24D810 shows the ring through the state test 0x255680 and keeps the world target at ring+0x1A8', call_before(0x24D9FF + 5, target=0x255680) and struct.pack('<I', 0x1A8) in at(0x24D810, 0x200))
# 1.7 the game's sprint tuning values (the probe shortens the start delay and lifts the turn clamp) and the rest of the nearby tuning table
sp = struct.unpack('<ffff', at(0xDCCFF4, 16))
check('1.7 sprint tuning at 0xDCCFF4: start delay 0.55 s, max 5.0 s, blocked-after 2.5 s, turn clamp 65 deg/s', all(abs(a - b) < 1e-4 for a, b in zip(sp, (0.55, 5.0, 2.5, 65.0))), str(sp))
sl = struct.unpack('<ff', at(0xDCD22C, 4) + at(0xDCD278, 4))
check('1.7 slam meter increments at 0xDCD22C / 0xDCD278 are 0.25 / 0.25', abs(sl[0] - 0.25) < 1e-5 and abs(sl[1] - 0.25) < 1e-5, str(sl))
# 1.7.10 the stream's hit point: the aim getter's bytes, the two reads in the stream update and the view object's virtual call
check('1.7.10 kRvaAimGetter bytes', at(consts['kRvaAimGetter'], 16) == arrays['kBytesAimGetter'])
c = at(consts['kRvaStreamHitAimCall'], 5)
check('1.7.10 stream update 0xE6778 calls the aim getter and returns to 0xE677D', c[0] == 0xe8 and consts['kRvaStreamHitAimCall'] + 5 + struct.unpack('<i', c[1:])[0] == consts['kRvaAimGetter'] and consts['kRvaStreamHitAimCall'] + 5 == consts['kRvaStreamHitAimRet'])
v = at(consts['kRvaStreamViewHitCall'], 6)
check('1.7.10 stream update 0xE674F is call [rax+0x168] returning to 0xE6755', v[:2] == b'\xff\x90' and struct.unpack('<i', v[2:])[0] == consts['kOffViewHitSlot'] and consts['kRvaStreamViewHitCall'] + 6 == consts['kRvaStreamViewHitRet'])
# 1.7.30 mirrors that follow the headset: the builder, its only caller (camera vtable +0x50) and the Euler->basis call inside it
check('1.7.30 kRvaBuildMirrors bytes', at(consts['kRvaBuildMirrors'], 16) == arrays['kBytesBuildMirrors'])
check('1.7.30 kRvaEulerToBasis bytes', at(consts['kRvaEulerToBasis'], 16) == arrays['kBytesEulerToBasis'])
check('1.7.30 camera vtable+0x50 == the mirror caller 0x454530', q(vt + 0x50) == consts['kRvaBuildMirrorsCaller'])
check('1.7.30 the caller calls the builder and returns to 0x454553', call_before(consts['kRvaBuildMirrorsRet'], target=consts['kRvaBuildMirrors']))
check('1.7.30 the builder calls Euler->basis and returns to 0x4272AA', call_before(consts['kRvaBuildMirrorsEulerRet'], target=consts['kRvaEulerToBasis']))
b = at(consts['kRvaBuildMirrors'] + 0x7c, 0x30)   # after the call: movss xmm8,[rbx+8]; movss [rsp+44],xmm8; movss xmm10,[rbx+0xc]; ... [rbx+0x10]
check('1.7.30 right after the Euler call the builder reads the camera eye at cam+0x08 / 0x0C / 0x10', at(consts['kRvaBuildMirrorsEulerRet'], 6) == bytes([0xf3, 0x44, 0x0f, 0x10, 0x43, 0x08]) and at(consts['kRvaBuildMirrorsEulerRet'] + 13, 6) == bytes([0xf3, 0x44, 0x0f, 0x10, 0x53, 0x0c]) and at(consts['kRvaBuildMirrorsEulerRet'] + 26, 6) == bytes([0xf3, 0x44, 0x0f, 0x10, 0x5b, 0x10]))
check('1.7.30 the builder loads the camera from ctx[0] (mov rbx,[rdx]) and the Euler angles from cam+0x14 (lea rdx,[rbx+0x14])', at(consts['kRvaBuildMirrors'] + 0x89, 3) == bytes([0x48, 0x8b, 0x1a]) and at(consts['kRvaBuildMirrors'] + 0x8c, 4) == bytes([0x48, 0x8d, 0x53, 0x14]))
check('1.7.30 kViewType 0x180C4 sits beside kViewMirror 0x180D8 (the builder writes the view type there)', consts['kViewType'] == 0x180C4 and consts['kViewMirror'] == 0x180D8)

# 1.7.72: the PKE draw push and the slime blower (read from ghost.exe)
def call_to(r):   # e8 rel32 at r -> target RVA
    b = at(r, 5); return r + 5 + struct.unpack('<i', b[1:5])[0] if b and b[0] == 0xe8 else -1
def jmp_to(r):
    b = at(r, 5); return r + 5 + struct.unpack('<i', b[1:5])[0] if b and b[0] == 0xe9 else -1
check('1.7.72 MatPush bytes', at(consts['kRvaMatPush'], 16) == arrays['kBytesMatPush'])
check('1.7.72 entity push 0x2C2800 = lea r8,[rcx+0xF4]; lea rdx,[rcx+0x54]; jmp MatPush', at(0x2C2803, 7) == bytes.fromhex('4c8d81f4000000') and at(0x2C280A, 4) == bytes.fromhex('488d5154') and jmp_to(0x2C2811) == consts['kRvaMatPush'])
check('1.7.72 the PKE collect pushes its entity (0x110570 calls 0x2C2800) and its second pose twice (0x1411C8, 0x141236 call MatPush)', call_to(0x1105B4) == 0x2C2800 and call_to(0x1411C8) == consts['kRvaMatPush'] and call_to(0x141236) == consts['kRvaMatPush'] and call_to(0x1410F9) == 0x110570)
check('1.7.72 the player update sets the PKE entity through 0x2C3AB0 (head-locked pose) and the R_PKE pose through 0x141E60', call_to(0xD63F8) == 0x2C3AB0 and call_to(0xD6542) == consts['kRvaPkeSetMatrix'])
check('1.7.72 tether fire bytes', at(consts['kRvaTetherFire'], 16) == arrays['kBytesTetherFire'])
check('1.7.72 the tether update calls the fire logic (0xAADFF)', call_to(0xAADFF) == consts['kRvaTetherFire'])
check('1.7.72 the tether vtable: update +0x80 = 0xAAD80, attach getter used by the fire logic is 0x2C1E40', struct.unpack('<Q', at(consts['kRvaTetherVtable'] + 0x80, 8))[0] - 0x140000000 == 0xAAD80 and call_to(0xAB41C) == consts['kRvaEntityAttachWorld'])
check('1.7.72 the fire logic reads the game view at owner+0xB550 (mov rcx,[rdi+0x4A8]; mov rbx,[rcx+0xB550]) and calls the aim getter when it is 0', at(0xAB45B, 7) == bytes.fromhex('488b8fa8040000') and at(0xAB462, 7) == bytes.fromhex('488b9950b50000') and call_to(0xAB5E4) == consts['kRvaAimGetter'])
check('1.7.75 SetTransform bytes', at(consts['kRvaSetTransform'], 16) == arrays['kBytesSetTransform'])
check('1.7.75 the player update places the tether through vtable +0x58 (call [rax+0x58] at 0xD5C97, rcx = [player+0x24D98] loaded at 0xD5AD0)', at(0xD5C97, 3) == bytes.fromhex('ff5058') and consts['kRvaTetherPlaceRet'] == 0xD5C9A and at(0xD5AD0, 7) == bytes.fromhex('488bb3984d0200'))
check('1.7.75 the tether vtable +0x58 is SetTransform', struct.unpack('<Q', at(consts['kRvaTetherVtable'] + 0x58, 8))[0] - 0x140000000 == consts['kRvaSetTransform'])
check('1.7.75 allocInventory stores the tether at player+0x24D98', at(0xE26F7, 7) == bytes.fromhex('4889bb984d0200'))
check('1.7.76 tether rope step bytes', at(consts['kRvaTetherRopeStep'], 16) == arrays['kBytesTetherRopeStep'])
check('1.7.76 the player update calls the rope step with edx = 0 (0xD8BD5)', call_to(consts['kRvaTetherRopeCall']) == consts['kRvaTetherRopeStep'] and at(0xD8BCD, 2) == bytes.fromhex('33d2'))
check('1.7.76 rope step reads the manager at tether+0x5B8 (cmp [rcx+0x5b8],0), slots at manager+0x25FA8 stride 0x98 (attach 0x2886C0)', at(0xAAF85, 8) == bytes.fromhex('4883b9b805000000') and at(0x288704, 15) == bytes.fromhex('4863c34869c8980000004881c1a85f02'[:30]))
# 1.7.187 the "same code" samples (sigtable.h) are the analysed exe's bytes
sig = open(__file__.rsplit('/tests/', 1)[0] + '/src/sigtable.h').read()
rows = re.findall(r'\{0x([0-9A-F]{6}), \{([^}]*)\}\}', sig)
bad = [r for r, b in rows if at(int(r, 16), 16) != bytes(int(x, 16) for x in b.split(','))]
check('1.7.187 sigtable: %d code samples equal the exe' % len(rows), len(rows) > 300 and not bad, str(bad[:3]))
print('ALL PASS' if not fails else '%d FAILED' % fails)
sys.exit(1 if fails else 0)
