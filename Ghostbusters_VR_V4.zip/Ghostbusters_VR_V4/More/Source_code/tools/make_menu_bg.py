#!/usr/bin/env python3
"""0.69: turns the game's cover picture into the menu's background header (src/menu_bg.h).

The menu is 1280x800 (16:10). The cover is a tall poster, so a 16:10 slice of it is cut out (default: the logo and the four
Ghostbusters), blurred a little at menu size so it does not fight with the menu text, and shrunk to 256x160. The DLL stretches it back
up smoothly (a blurred picture needs no more detail than that).

Usage: python3 tools/make_menu_bg.py cover.png [--top 0.255] [--blur 7] [--mode crop|contain]
Writes src/menu_bg.h and tools/menu_bg_preview.png (the picture as the menu will use it, 1280x800).
"""
import sys, argparse, os
from PIL import Image, ImageFilter

ap = argparse.ArgumentParser()
ap.add_argument("cover")
ap.add_argument("--top", type=float, default=0.255, help="where the slice starts, as a fraction of the picture height (crop mode)")
ap.add_argument("--blur", type=float, default=7.0, help="Gaussian blur radius in menu pixels (1280x800)")
ap.add_argument("--mode", choices=["crop", "contain"], default="crop")
ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "menu_bg.h"))
ap.add_argument("--preview", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "menu_bg_preview.png"))
a = ap.parse_args()

W, H = 1280, 800
im = Image.open(a.cover).convert("RGBA")
bg = Image.new("RGB", im.size, (0, 0, 0))
bg.paste(im, mask=im.split()[3])   # transparent corners become black
im = bg
if a.mode == "crop":
    s = W / im.width
    big = im.resize((W, round(im.height * s)), Image.LANCZOS)
    y0 = max(0, min(big.height - H, round(big.height * a.top)))
    pic = big.crop((0, y0, W, y0 + H))
else:
    s = H / im.height
    small = im.resize((round(im.width * s), H), Image.LANCZOS)
    pic = Image.new("RGB", (W, H), (0, 0, 0))
    pic.paste(small, ((W - small.width) // 2, 0))
pic = pic.filter(ImageFilter.GaussianBlur(a.blur))
pic.save(a.preview)
small = pic.resize((256, 160), Image.LANCZOS)
raw = small.tobytes()
with open(a.out, "w") as f:
    f.write("// 0.69: the menu's background picture, made by tools/make_menu_bg.py (256x160, RGB, already blurred). Do not edit by hand.\n")
    f.write("#pragma once\n#define GBVR_MENU_BG_W 256\n#define GBVR_MENU_BG_H 160\n")
    f.write("static const unsigned char kMenuBg[256 * 160 * 3] = {\n")
    for i in range(0, len(raw), 36):
        f.write(",".join(str(b) for b in raw[i:i + 36]) + ",\n")
    f.write("};\n")
print("wrote", a.out, len(raw), "bytes of picture; preview", a.preview)
