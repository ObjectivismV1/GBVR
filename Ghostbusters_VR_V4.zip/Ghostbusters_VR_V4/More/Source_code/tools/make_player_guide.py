# Builds PLAYER_GUIDE.pdf (one page). usage: python3 make_player_guide.py out.pdf
import sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
H = ParagraphStyle('h', fontName='Helvetica-Bold', fontSize=15, leading=18, spaceAfter=1)
S = ParagraphStyle('s', fontName='Helvetica', fontSize=8.2, leading=10, textColor='#444444', spaceAfter=3)
T = ParagraphStyle('t', fontName='Helvetica-Bold', fontSize=9.6, leading=12, spaceBefore=5, spaceAfter=1)
B = ParagraphStyle('b', fontName='Helvetica', fontSize=8.5, leading=10.6, leftIndent=8, firstLineIndent=-8)
def bl(t): return Paragraph('&bull; ' + t, B)
doc = SimpleDocTemplate(sys.argv[1], pagesize=A4, leftMargin=15*mm, rightMargin=15*mm, topMargin=12*mm, bottomMargin=10*mm,
                        title='Ghostbusters VR - Player Guide (Version 4)', author='Ghostbusters VR mod')
x = [Paragraph('Ghostbusters VR: Player Guide', H),
     Paragraph('Version 4 (V4), build 1.7.226 &bull; right-handed Touch controls; the left-handed option is in VR settings &gt; Play', S),
     Paragraph('Start and move', T),
     bl('Run INSTALL.cmd after extracting the zip. Start SteamVR and connect the headset <b>before</b> launching the game. To update, run the new installer: settings are kept.'),
     bl('Left stick walk; click it to toggle sprint. Right stick flick = snap turn (VR settings &gt; Play &gt; Snap turn off = smooth turn). B jump; tap A interact. Crouch by ducking.'),
     Paragraph('Fight and gear', T),
     bl('Right trigger fire; <b>left trigger alternate fire</b> (the Boson Dart on the proton gun). With the PKE out, right trigger scans.'),
     bl('Right stick click = capture a ghost; while holding it, squeeze the left trigger fully = slam. (Play settings can make capture click-on / click-off.)'),
     bl('Two-hand aim: bring the left hand to the drawn gun and hold the left grip. Release the grip to return to one-hand aim.'),
     bl('X = trap: left hand at the left hip takes it, swing out and release to throw. Tap Y to take out / put away the PKE. Hold A, point with the right stick, release = weapon wheel.'),
     bl('Vent: hand over a shoulder plus grip. Holster / draw: right hand over the right shoulder, trigger and grip together. Story scenes may put the gun away for a while.'),
     bl('Hold Y: right stick = D-pad; right stick click = vent; right B = HUD on / off; right A = select / back.'),
     Paragraph('Menu and settings', T),
     bl('Left hand beside the left ear + left grip, hold still about half a second (or F12). Point with the right hand; trigger clicks; right stick scrolls; A closes.'),
     bl('VR SETTINGS (bottom of the menu): Start (measure height, recenter, objectives), Play (turn, sprint, handedness, seated, capture, comfort), View (enemy health, HUD, resolution, buzz), Help. F4 headset view; F9 recenter; Ctrl+F9 measure height.'),
     Paragraph('Other headsets and controllers', T),
     bl('The mod needs SteamVR. Made and played on Quest 3 (Touch controllers) through Virtual Desktop; every other headset and controller below is set up from SteamVR\'s own data and tested by computer only, so please report anything odd.'),
     bl('Pico, Rift S, Focus 3, Steam Frame: Touch-like layout (Steam Frame: D-pad buttons = face buttons, bumpers = extra triggers). Valve Index: thumbstick, not trackpad; quick right-grip tap = interact (A); left A = trap (X); left B = PKE (Y). Vive wands: trackpad = stick; lower click = A, other click = stick click; menu = B / Y. Windows MR: stick, trackpad click = A. Anything else: stick found automatically (controller_layout / stick_axis in gbvr_settings.txt can force it). Hand tracking is not supported: turn it off.'),
     Paragraph('If something is wrong', T),
     bl('Black view: SteamVR and the headset must be running before the game starts. Choppy: VR SETTINGS &gt; View &gt; Resolution, press &ndash;, restart the game. Two graphics cards: set ghost.exe to High performance in Windows graphics settings.'),
     bl('Bugs: close the game, double-click COLLECT_LOGS.cmd, send the zip from your Downloads folder plus a short video of the headset view. README.txt has the full install steps and troubleshooting.'),
     bl('Not tested in a headset yet in V4 build 1.7.226: steadier gun health bar, calmer PKE hand, Boson Dart change, off-hand grip, Stay Puft roof re-centre.')]
doc.build(x)
