GHOSTBUSTERS: THE VIDEO GAME REMASTERED - VR MOD
VERSION 4 (V4), build 1.7.226
=============================================================
An unofficial fan-made VR mod for the Steam version of the game. Not made by, or connected to, the game's makers or publisher.
You need to own the game. This download contains no game files.
It is an experimental hobby mod, updated often. It has bugs. Expect to report some (see "SOMETHING WRONG?").

WHAT YOU NEED
- Windows 10 or 11 and a PC that runs the game well (the mod draws the game twice, once per eye).
- The Steam version of "Ghostbusters: The Video Game Remastered", installed and started once without the mod.
- SteamVR (free, in Steam under Library > Tools) and a headset that works in it.
  The mod talks to SteamVR ONLY (OpenVR). It does not use OpenXR, so the headset's own OpenXR runtime (Meta, Virtual Desktop's VDXR, Pico, WMR)
  does not matter - but SteamVR must be installed and running, whatever headset or connection you use.
  Not supported: playing without SteamVR (OpenXR-only setups). The game then just stays flat on the monitor; the log says why.

HEADSETS - how each one reaches SteamVR
  Quest (Virtual Desktop)     start Virtual Desktop, connect, then pick SteamVR in its menu (not VDXR / not the Oculus-only mode).
  Quest (Air Link / Link)     Meta Quest Link app on the PC, connect the headset, then start SteamVR (Link > Settings > General: allow "Unknown sources" if SteamVR asks).
  Quest (Steam Link / ALVR)   connect, SteamVR starts with it.
  Valve Index, Vive, Pimax    start SteamVR (Pimax: also turn on "Parallel Projections" in the Pimax software).
  Windows Mixed Reality       install "Windows Mixed Reality for SteamVR" in Steam, then start SteamVR.
  Pico                        Pico Connect or Streaming Assistant, then SteamVR.
  Steam Frame / Galaxy XR     stream to the PC, SteamVR on the PC. (Running the Windows game on the Frame itself is untested.)

WHAT HAS BEEN TESTED ON REAL HARDWARE (honest list)
- Quest 3 + Quest Touch controllers, through Virtual Desktop and SteamVR at 90 Hz, on Windows 11: this is what the mod is built and played on.
- Everything else is written from SteamVR's own controller data and checked by automatic tests on a computer, not on the real headset.
  Reports so far: Galaxy XR + Virtual Desktop + SteamVR and Steam Frame (see "SOMETHING WRONG?" for the left-stick note).
  If your headset or controllers behave differently, please say which ones and send COLLECT_LOGS: the log records exactly what SteamVR reports (lines CONTROLLERLAYOUT, HEADSET).

CONTROLLERS
- Touch-style controllers (Quest, Rift, Pico, Focus 3, Steam Frame): the layout below, exactly.
- Valve Index: use the thumbstick, not the trackpad. Pushing the stick to the edge is not a click.
    Interact (A) = a QUICK tap of the right grip. Left A = X (trap). Left B = Y (PKE).
- Vive wands: the trackpad is the stick. Click the LOWER part of the pad = A (right: interact / weapon wheel, left: trap); click anywhere else = stick click. The menu button = B / Y.
- Windows Mixed Reality: the stick is read from the right input; clicking the trackpad = A.
- Anything else: the stick is found automatically from what SteamVR says about the controller. If it is wrong, controller_layout / stick_axis in gbvr_settings.txt can force it.
- Steam Frame: SteamVR gives the game the Touch layout, so the Frame's D-pad buttons act as the face buttons (left D-pad down = X trap, left D-pad left / up / right = Y,
  right X / Y / B = B) and the bumpers act as extra triggers.
- Hand tracking (no controllers) is NOT supported: turn it off (Quest and Virtual Desktop).

INSTALL (Windows, about 2 minutes)
1. Unzip the whole zip to a normal folder (right-click the zip > Extract All). Do NOT run anything from inside the zip.
2. Close the game if it is running.
3. Double-click INSTALL.cmd.
   - If Windows says "Windows protected your PC": click "More info", then "Run anyway".
   - It finds the game by itself (Steam, any library drive). If it cannot, it asks you for the game folder:
     in Steam right-click the game > Manage > Browse local files, copy the address-bar path and paste it.
   - If it asks for administrator permission, say yes (the game folder needs it).
   - It backs up anything it replaces, and prints NEXT STEPS when it is done.
4. Put the headset on, start SteamVR (Quest: Virtual Desktop / Air Link / Steam Link first), then start the game from Steam. VR starts by itself.

WHAT IS IN THIS FOLDER
  README.txt, PLAYER_GUIDE.pdf   this guide and the one-page controls list
  INSTALL.cmd / REMOVE.cmd       the two buttons you need (Windows)
  COLLECT_LOGS.cmd               packs the logs into one zip in Downloads, to send to me
  program_files                  the mod itself (do not edit; the installer copies it to the game)
  More                           extras: CHECK_INSTALL.cmd, Linux_SteamDeck, Source_code

UPDATE: unzip the new version and run its INSTALL.cmd again. It replaces the old one by itself. Your settings are kept.
REMOVE: double-click REMOVE.cmd. More\CHECK_INSTALL.cmd shows what is installed and anything that looks wrong.
If the installer says "not enough space on the disk": free a few hundred MB on the drive it names and run it again.
Linux / Steam Deck: see More\Linux_SteamDeck\README_LINUX.txt (the install scripts are tested, the mod inside Proton is not).

CONTROLS (Quest / Touch controllers, right-handed; VR settings > Play > Left-handed swaps the hands)
Move and look
- Walk: left stick. Sprint: click the left stick (click again to stop; VR settings > Play can make it hold-to-sprint).
- Turn: flick the right stick left or right (snap turn). Smooth turn: VR settings (F12 > VR SETTINGS) > Play > Snap turn off, then hold the right stick sideways.
- Jump: B (right). Interact (open, pick up, revive, use): tap A (right).
- Crouch: duck down in real life. Look around, lean and walk around the room for real; your body follows.
Fight (the gun is in your right hand)
- Fire: right trigger. Alternate fire (every weapon, the Boson Dart on the proton gun): left trigger. With the PKE meter out the right trigger scans.
- Steady aim / two-hand aim: put the left hand next to the drawn gun and hold the left grip. Release the grip to return to one-hand aim.
- Capture / wrangle a ghost: click the right stick (VR settings > Play > "Grab beam: click on, click off" makes it one click to grab, one to let go).
  Hold the grab, then squeeze the LEFT trigger all the way = slam.
- Ghost trap: press X (left). Hold your left hand at your left hip to take the trap in your hand, swing out and let go to throw it.
Gear
- Weapon wheel: hold A (right), push the right stick toward a weapon, let go.
- PKE meter: tap Y (left) to take it out, tap again to put it away.
- Vent the pack (overheat): put a hand over your shoulder and squeeze a grip.
- Put the gun on your back / take it again: right hand over your right shoulder, squeeze trigger AND grip together (the hand buzzes).
  The game decides when a gun may be held: in cut-scenes it goes on your back by itself and is back in your hand afterwards if you had it out.
- D-pad (choose a gadget, select): HOLD Y (left), then the right stick = D-pad, right stick click = vent, right B = HUD on / off, right A = select / back.
  Also: left grip held with the left hand held away from the gun + right stick = D-pad.
- Flashlight: the game's own light control. The mod does not aim it from your head.
Menu
- Open / close: left hand beside your left ear, squeeze the left grip, hold still half a second (or F12 on the keyboard). It opens the game's own pause menu in your left hand:
  point with the right hand, trigger = click, right stick = scroll, A = close.
- VR SETTINGS (the button at the bottom of that menu) has four pages: Start (measure / reset height, recenter, objectives), Play (turn, sprint, left-handed, seated, grab beam,
  comfort vignette), View (ghost health ring or bars, game HUD, Resolution, buzz strength) and Help. Everything you change is saved at once. Hold - or + to change fast.
Keyboard (game window)
- F4 = headset view on / off, F9 = recenter, Ctrl+F9 = measure my height, F12 = menu.

FIRST TIME
- Settings > Start > Measure my height (stand straight, look ahead). Reset my height puts it back.
- Seated play and Left-handed are on the Play page. Not sure about motion? Try Comfort vignette 40 to 70 and smooth turn off (snap).
- Everything you change is saved (gbvr_settings.txt in the game folder). Delete that file to go back to the defaults.
- Game choppy? View > Resolution, press - once or twice and restart the game.

YOUR SETTINGS (Steam, SteamVR, Virtual Desktop)
- Start the game with Play in Steam. Steam Input on or off both work. If sticks / buttons do nothing, try Steam > the game > Properties > Controller > Disable Steam Input.
- SteamVR running and the headset connected BEFORE the game starts. SteamVR's render resolution / supersampling and motion smoothing do not matter to the mod (it picks its own picture size).
- Virtual Desktop: 90 Hz is what it was made on (72 / 80 / 120 Hz should work but are untested). Use the controllers, not hand tracking.
  "Emulate Index controllers" can stay off; if you turn it on the mod finds the stick by itself (untested). The LEFT Menu button belongs to Virtual Desktop, the mod does not use it.
- Slow PC / laptop: lower the Resolution (F12 > VR SETTINGS > View > Resolution, press - once or twice, restart the game). Also lower Virtual Desktop's graphics quality and use 72 Hz.
- Two graphics cards (most gaming laptops): Windows Settings > System > Display > Graphics > add ghost.exe > Options > High performance, and the same card for SteamVR. Otherwise the headset stays black.
- Windows display scaling, monitor size and windowed / full screen should not matter. The mod writes what it finds to its log (lines ENVCHECK and ENVHINT).

WHAT IS NEW IN V4 (build 1.7.226)
- Hands: no hand animation on a weapon change, and none when you pull the left trigger (alternate fire / Boson Dart). Your hand and arm keep the pose they had just before and stay on the controller. Setting gun_hand_no_anim = 0 brings the game's animation back.
- PKE: it is no longer pulled around when it first comes out. Before, your hand was only tied to the controller after a very steady moment, which took up to 7 seconds if you moved; now that moment comes much sooner, and the PKE settles into place smoothly instead of jumping.
- Gun health bar: also keeps its place when a Boson Dart kicks the gun. It stays fixed on the gun while you walk and fire (it no longer follows the game's swaying gun) and does not re-adjust while you walk.
- PKE: your hand is turned much less to hold the meter, so it looks and feels more natural (setting pke_turn_max_deg, 25 by default).
- Boson Dart: the stream is let go for the game while you pull the left trigger (a best guess at why some darts did not shoot, not proven; dart_pause_stream = 0 turns it off).
- Off hand: picks its place round the gun barrel once and stays there (no twisting); the wrist bends as little as possible.
- Stay Puft roof fight: the view re-centres itself once if you rest more than 12 degrees off the boss.
- Not tested in a headset yet: everything in this list. Send COLLECT_LOGS (and a short video) if something is off. New log lines: DARTPAUSE, DARTLT, DARTTRACE, GUNTUBE, SCENELEFT, ROOFAUTO.
- The full list of every earlier change is in More\Source_code\docs\CHANGES_1.7.196.md, the old notes in More\Source_code\docs\README_HISTORY.txt.

KNOWN LIMITS
- Only the Steam game build it was made for is supported. The installer checks this and says so if your game is different.
- Epic Games Store copy: the installer finds it and the mod accepts a build with the same code; if it stays off, the log says where.
- The game decides when you may hold the gun (cut-scenes, forced walks, level changes). A knock-down does not put the gun away.
- The player life bar shows on the drawn proton, meson, boson and slime guns; it is hidden on the PKE, trap, light and holstered gear, and may be hidden in cut-scenes.
- Stay Puft roof fight: your view is fixed there (the game's own camera), so it can feel less sharp than normal play; the exact cause of the "unfocused" feeling is not found yet.
- The mod only adds files next to ghost.exe and turns off the game's 30 / 60 FPS limit in its settings.ini (a backup is kept).
  It does not change the game's own files or your saves. REMOVE.cmd puts everything back.
- Antivirus: the mod is a d3d11.dll that hooks the game (that is how every graphics mod works), so a virus scanner may warn about it. It is not a virus.
  The full source is in More\Source_code and can be built yourself (see More\Source_code\README_BUILD_1.7.120.txt). program_files\VERSION.txt lists the SHA-256 fingerprint of each installed file.

SOMETHING WRONG?
- Nothing happens at all: double-click More\CHECK_INSTALL.cmd. It names the problem (game not found, wrong game version, file changed by another mod).
- Black or flat picture in the headset: SteamVR must be running and the headset connected BEFORE you start the game. F4 in the game window switches the headset view on / off.
- Picture on the monitor but the headset stays black, and you have two graphics cards: see YOUR SETTINGS above (High performance card for ghost.exe).
- No hands at all: wake the controllers (press a button), turn OFF hand tracking (Quest and Virtual Desktop), check the batteries. The mod's log says so after 25 seconds (ENVHINT).
- No sound: check the game's volume in the Windows volume mixer (on Steam Link / Steam Frame also the PC's playback device), then send COLLECT_LOGS.
- Hands and head move but sticks / buttons do nothing in play: wait 2-3 s after the 3D picture appears (the mod then switches the game's controls to "gamepad"),
  click the game window on the monitor once, close programs that fake a gamepad (x360ce, DS4Windows), and if needed try Steam > the game > Properties > Controller > Disable Steam Input.
- The LEFT stick does not walk but the right stick turns and the buttons work (reported on Galaxy XR + Virtual Desktop + SteamVR; the Steam Frame D-pad / bumper mix-up may be the same thing):
  send COLLECT_LOGS, the CONTROLLERLAYOUT lines show which axis was read. controller_layout / stick_axis in gbvr_settings.txt can force it.
- The character stands still although you push the left stick (Times Square, after Stay Puft throws the sign): the mod plays the game's own knock-back and frees you after 2.5 s.
  If it still happens: close the game right after and send COLLECT_LOGS. Quick test: in gbvr_settings.txt set knock_comfort=0 and start again.
- The gun (or the PKE) floats away from your hand, mostly at the start of a level or after a cut-scene: close the game right after and send COLLECT_LOGS with a short video.
- The game crashed or something looks wrong: close the game, double-click COLLECT_LOGS.cmd. It puts one zip in your Downloads folder.
  Attach that zip when you report the problem, and say what you were doing and roughly when. A short phone video of the headset view helps a lot.
  The zip holds the mod logs, SteamVR / headset log files and a list of the game folder. No passwords, no save games.

PLAYER_GUIDE.pdf is a one-page list of the controls.

MENU SONG
- The song that plays while the game menu is open (program_files\bin\gbvr_menu_music.mp3) is used with the permission of the YouTube creator who made it.
  It is NOT covered by this mod's licence: do not re-use or re-upload it on its own. Delete the file for a silent menu.
