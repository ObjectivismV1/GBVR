# Ghostbusters VR probe - install / remove / check.
# Called by INSTALL.cmd, REMOVE.cmd and CHECK_INSTALL.cmd.
# Only ever deletes files it installed itself (tracked by SHA-256 in
# gbvr_manifest.txt). Anything it replaces is backed up and restored on removal.
param(
  [Parameter(Mandatory = $true)][ValidateSet('Install', 'Remove', 'Check', 'Collect')][string]$Action,
  [string]$GameDir = '',
  [switch]$Elevated
)
$ErrorActionPreference = 'Stop'
$PackageDir = Split-Path -Parent $PSScriptRoot
$Version = (Get-Content -LiteralPath (Join-Path $PackageDir 'VERSION.txt') -TotalCount 1).Trim()
$ExpectedExeHash = 'EA5EDECB590ACE8EFA2274DF354AD266ADA95A3100DBE6CABC5A5FB34A225038'
$ManifestName = 'gbvr_manifest.txt'

function Say($text, $color = 'Gray') { Write-Host $text -ForegroundColor $color }
function Hash($path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }

# 1.7.187 EPIC GAMES: where the Epic Games Launcher put the game. Reads only. Returns folders that hold ghost.exe (in the folder itself or up to 3 levels down).
function Find-EpicGameDirs {
  $found = New-Object System.Collections.Generic.List[string]
  function Test-Folder($f) {
    if (-not $f -or -not (Test-Path -LiteralPath $f)) { return }
    if (Test-Path -LiteralPath (Join-Path $f 'ghost.exe')) { $found.Add((Resolve-Path -LiteralPath $f).Path); return }
    foreach ($e in @(Get-ChildItem -LiteralPath $f -Recurse -Depth 3 -File -Filter 'ghost.exe' -ErrorAction SilentlyContinue | Select-Object -First 2)) { $found.Add($e.DirectoryName) }
  }
  # 1. the launcher's own records of installed games
  try {
    $man = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    if (Test-Path -LiteralPath $man) {
      foreach ($it in @(Get-ChildItem -LiteralPath $man -Filter '*.item' -File -ErrorAction SilentlyContinue)) {
        try {
          $j = Get-Content -LiteralPath $it.FullName -Raw | ConvertFrom-Json
          if (($j.DisplayName -match 'Ghostbusters') -or ($j.LaunchExecutable -match '(?i)ghost')) { Test-Folder $j.InstallLocation }
        } catch {}
      }
    }
  } catch {}
  try {
    $dat = Join-Path $env:ProgramData 'Epic\UnrealEngineLauncher\LauncherInstalled.dat'
    if (Test-Path -LiteralPath $dat) {
      $j = Get-Content -LiteralPath $dat -Raw | ConvertFrom-Json
      foreach ($i in @($j.InstallationList)) { if ($i.InstallLocation -match 'Ghostbusters') { Test-Folder $i.InstallLocation } }
    }
  } catch {}
  # 2. the usual places on every drive
  try {
    foreach ($dr in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | Where-Object { $_.Root -match '^[A-Za-z]:\\$' })) {
      foreach ($base in @('Program Files\Epic Games', 'Program Files (x86)\Epic Games', 'Epic Games', 'Games\Epic Games', 'Games', 'Epic')) {
        $b = Join-Path $dr.Root $base
        if (Test-Path -LiteralPath $b) { foreach ($g in @(Get-ChildItem -LiteralPath $b -Directory -Filter '*Ghostbusters*' -ErrorAction SilentlyContinue)) { Test-Folder $g.FullName } }
      }
    }
  } catch {}
  return @($found | Select-Object -Unique)
}

function Find-GameDir {
  if ($GameDir -and (Test-Path -LiteralPath (Join-Path $GameDir 'ghost.exe'))) { return (Resolve-Path -LiteralPath $GameDir).Path }
  foreach ($d in @($PackageDir, (Split-Path -Parent $PackageDir), (Split-Path -Parent (Split-Path -Parent $PackageDir)))) {   # 1.7.227: the package folder is now program_files inside the V4 folder
    if (Test-Path -LiteralPath (Join-Path $d 'ghost.exe')) { return $d }
  }
  $roots = @()
  try { $roots += (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath } catch {}
  try { $roots += (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction Stop).InstallPath } catch {}
  $libs = @()
  foreach ($r in $roots | Where-Object { $_ }) {
    $r = $r -replace '/', '\'
    $libs += $r
    $vdf = Join-Path $r 'steamapps\libraryfolders.vdf'
    if (Test-Path -LiteralPath $vdf) {
      foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) {
        $libs += ($m.Groups[1].Value -replace '\\\\', '\')
      }
    }
  }
  foreach ($lib in $libs | Select-Object -Unique) {
    $common = Join-Path $lib 'steamapps\common'
    if (-not (Test-Path -LiteralPath $common)) { continue }
    foreach ($g in Get-ChildItem -LiteralPath $common -Directory -ErrorAction SilentlyContinue) {
      if (Test-Path -LiteralPath (Join-Path $g.FullName 'ghost.exe')) { return $g.FullName }
    }
  }
  # 1.7.187: not in a Steam library: the Epic Games Store copy
  $epic = @(Find-EpicGameDirs)
  if ($epic.Count -ge 1) {
    Say 'Found the Epic Games Store copy of the game.' Green
    return $epic[0]
  }
  Say ''
  Say 'Could not find the game automatically.' Yellow
  Say 'In Steam: right-click the game > Manage > Browse local files, copy the folder path from the address bar.'
  Say 'In the Epic Games Launcher: Library > the three dots on the game > Manage > the folder icon next to "Installation".'
  $p = Read-Host 'and paste it here'
  $p = $p.Trim('"', ' ')
  if ($p -and (Test-Path -LiteralPath (Join-Path $p 'ghost.exe'))) { return $p }
  throw "ghost.exe was not found in '$p'."
}

function Ensure-Writable($dir) {
  $probe = Join-Path $dir ('gbvr_write_test_' + [guid]::NewGuid().ToString('N') + '.tmp')
  try { [IO.File]::WriteAllText($probe, 'x'); Remove-Item -LiteralPath $probe -Force; return $true } catch { return $false }
}

function Relaunch-Elevated($dir) {
  Say 'The game folder needs administrator rights. Windows will ask for permission...' Yellow
  $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"", '-Action', $Action, '-GameDir', "`"$dir`"", '-Elevated')
  $p = Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs -Wait -PassThru
  exit $p.ExitCode
}

function Read-Manifest($dir) {
  $path = Join-Path $dir $ManifestName
  $m = @{ Version = ''; Files = @(); Backups = @(); Settings = @() }
  if (-not (Test-Path -LiteralPath $path)) { return $null }
  foreach ($line in Get-Content -LiteralPath $path) {
    $parts = $line -split '\|'
    switch ($parts[0]) {
      'version' { $m.Version = $parts[1] }
      'file' { $m.Files += , @($parts[1], $parts[2]) }
      'backup' { $m.Backups += , @($parts[1], $parts[2]) }
      'setting' { $m.Settings += , @($parts[1], $parts[2], $parts[3]) }
    }
  }
  return $m
}

function Show-Logs($dir) {
  $places = @($dir, (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'GhostbustersVR_logs'),
              (Join-Path $env:USERPROFILE 'Documents\GhostbustersVR_logs')) | Select-Object -Unique
  $logs = foreach ($p in $places) { if (Test-Path -LiteralPath $p) { Get-ChildItem -LiteralPath $p -Filter 'gbvr_probe_*.log' -File } }
  $logs = $logs | Sort-Object LastWriteTime -Descending | Select-Object -First 3
  if ($logs) {
    Say 'Newest logs (send the top one after a test):'
    foreach ($l in $logs) { Say ("  " + $l.FullName + "  (" + $l.LastWriteTime + ")") }
  } else { Say 'No mod logs yet (they appear after the game starts with the mod installed).' }
}

# ---- Game settings (settings.ini in %LOCALAPPDATA%\<game title>\) ------------
function Read-IniText($path) {
  $bytes = [IO.File]::ReadAllBytes($path)
  if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) { $enc = [Text.Encoding]::Unicode }
  elseif ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { $enc = New-Object Text.UTF8Encoding($true) }
  else { $enc = [Text.Encoding]::Default }
  return @{ Text = [IO.File]::ReadAllText($path, $enc); Encoding = $enc }
}

function Get-IniValue($text, $key) {
  $m = [regex]::Match($text, '(?im)^[ \t]*' + [regex]::Escape($key) + '[ \t]*=[ \t]*([^\r\n]*)')
  if ($m.Success) { return $m.Groups[1].Value.Trim() } else { return $null }
}

function Set-IniValues($path, $pairs) {   # $pairs: array of @(key, value); only existing keys are changed
  $ini = Read-IniText $path
  $text = $ini.Text
  foreach ($kv in $pairs) {
    $pattern = '(?im)^([ \t]*' + [regex]::Escape($kv[0]) + '[ \t]*=[ \t]*)[^\r\n]*'
    $text = [regex]::Replace($text, $pattern, '${1}' + $kv[1])   # values are plain numbers
  }
  [IO.File]::WriteAllText($path, $text, $ini.Encoding)
}

function Find-SettingsIni {
  # The game uses %LOCALAPPDATA%\<title up to the first ':'>\settings.ini,
  # i.e. %LOCALAPPDATA%\GHOSTBUSTERS\settings.ini (strtok on the title in
  # ghost.exe at 0x241342). Other GHOSTBUSTERS* folders are checked as a
  # fallback; the file must contain the lockTo30Hz key to count.
  $root = $env:LOCALAPPDATA
  if (-not $root -or -not (Test-Path -LiteralPath $root)) { return $null }
  $cands = @(Join-Path $root 'GHOSTBUSTERS\settings.ini')
  $cands += Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like 'GHOSTBUSTERS*' } |
    ForEach-Object { Join-Path $_.FullName 'settings.ini' }
  foreach ($c in ($cands | Select-Object -Unique)) {
    if ((Test-Path -LiteralPath $c) -and ($null -ne (Get-IniValue (Read-IniText $c).Text 'lockTo30Hz'))) { return $c }
  }
  return $null
}

function Assert-GameClosed {
  $procs = @(Get-Process -Name 'ghost' -ErrorAction SilentlyContinue)
  if ($procs.Count -eq 0) { return }
  $withWindow = @($procs | Where-Object { $_.MainWindowHandle -ne [IntPtr]::Zero })
  if ($withWindow.Count -gt 0) {
    Say 'The game is running. Close it first (it saves its settings when it exits), then run this again.' Red
    if ($Elevated) { Read-Host 'Press Enter to close' | Out-Null }
    exit 1
  }
  # No window: a copy of the game that did not exit properly (this happened
  # after using the headset view of probe 0.21). It blocks installing and
  # starting the game, so it is closed here.
  Say 'A stuck copy of the game is still running in the background (no window). Closing it...' Yellow
  $procs | Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 2
  if (Get-Process -Name 'ghost' -ErrorAction SilentlyContinue) {
    Say 'It could not be closed. Restart the PC, then run this again.' Red
    if ($Elevated) { Read-Host 'Press Enter to close' | Out-Null }
    exit 1
  }
  Say 'Stuck copy closed.' Green
}

# Start-up safety files written by the probe (0.23+); a fresh install or a removal starts clean.
function Remove-StartupMarkers($dir) {
  foreach ($n in @('gbvr_start_pending.txt', 'gbvr_dxgi11_off.txt', 'gbvr_picture_off.txt', 'gbvr_run.txt', 'gbvr_health.txt')) {
    $p = Join-Path $dir $n
    if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue }
  }
}

# ---- 1.7.80: report zip with normal "/" names, VR readiness check ----------------------------
function New-ZipForwardSlash($srcDir, $zipPath) {
  # Compress-Archive of Windows PowerShell 5.1 writes "\" in the zip's file names; Mac, Linux and most zip tools then show flat files with
  # backslashes in their names. This writes normal "/" names so the report opens the same everywhere.
  Add-Type -AssemblyName System.IO.Compression
  if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
  $root = (Resolve-Path -LiteralPath $srcDir).Path.TrimEnd('\')
  $fs = [IO.File]::Open($zipPath, [IO.FileMode]::Create)
  try {
    $za = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
    try {
      foreach ($f in @(Get-ChildItem -LiteralPath $root -Recurse -File -Force)) {
        $rel = $f.FullName.Substring($root.Length + 1).Replace('\', '/')
        $e = $za.CreateEntry($rel, [IO.Compression.CompressionLevel]::Optimal)
        $es = $e.Open()
        try {
          $in = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
          try { $in.CopyTo($es) } finally { $in.Dispose() }
        } finally { $es.Dispose() }
      }
    } finally { $za.Dispose() }
  } finally { $fs.Dispose() }
}

function Show-VrReadiness {
  # Reads only. Tells a new player, before the first start, whether SteamVR is on this PC.
  $ok = $false
  try {
    $vp = Join-Path $env:LOCALAPPDATA 'openvr\openvrpaths.vrpath'
    if (Test-Path -LiteralPath $vp) {
      $j = Get-Content -LiteralPath $vp -Raw | ConvertFrom-Json
      $rt = @($j.runtime)[0]
      if ($rt -and (Test-Path -LiteralPath $rt)) { $ok = $true }
    }
  } catch {}
  if ($ok) { Say 'SteamVR: found on this PC.' Green }
  else {
    Say 'SteamVR was not found on this PC. The mod needs it:' Yellow
    Say '  Steam > Library > Tools > install "SteamVR", start it once, and make your headset work in it (Quest: Virtual Desktop, Air Link, Steam Link or ALVR; Pico: Pico Connect).' Yellow
    Say '  This is needed for EVERY headset: the mod uses SteamVR, not Meta / Pico / Windows MR runtimes on their own.' Yellow
    Say '  This also holds if you own the game on Epic: Steam and SteamVR are free, install them only for the headset.' Yellow
  }
}

# ---- 0.67: Downloads folder and SteamVR files for the report ---------------------------------
function Get-DownloadsFolder {
  # The real Downloads folder (it can be moved to another drive), then %USERPROFILE%\Downloads, then the Desktop as a last resort.
  try {
    if (-not ('GbvrKnownFolder' -as [type])) {
      Add-Type -ErrorAction Stop -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class GbvrKnownFolder {
  [DllImport("shell32.dll")]
  private static extern int SHGetKnownFolderPath([MarshalAs(UnmanagedType.LPStruct)] Guid rfid, uint dwFlags, IntPtr hToken, out IntPtr ppszPath);
  public static string Get(Guid id) {
    IntPtr p;
    if (SHGetKnownFolderPath(id, 0, IntPtr.Zero, out p) != 0) return null;
    try { return Marshal.PtrToStringUni(p); } finally { Marshal.FreeCoTaskMem(p); }
  }
}
'@
    }
    $d = [GbvrKnownFolder]::Get([Guid]'374DE290-123F-4565-9164-39C4925E467B')
    if ($d -and (Test-Path -LiteralPath $d)) { return $d }
  } catch {}
  $d = Join-Path $env:USERPROFILE 'Downloads'
  if (-not (Test-Path -LiteralPath $d)) { try { New-Item -ItemType Directory -Path $d -Force | Out-Null } catch {} }
  if (Test-Path -LiteralPath $d) { return $d }
  return [Environment]::GetFolderPath('Desktop')
}

function Copy-Tail($src, $dst, $lines) {
  # the last $lines lines of a text file (logs can be many MB)
  try {
    if (Test-Path -LiteralPath $src) {
      Get-Content -LiteralPath $src -Tail $lines -ErrorAction Stop | Set-Content -LiteralPath $dst -Encoding UTF8
      return $true
    }
  } catch {}
  return $false
}

function Collect-SteamVR($tmp) {
  # SteamVR's own settings and logs, so a "SteamVR blocked an add-on" problem can be read from the report. Reads only.
  $sv = Join-Path $tmp 'steamvr'
  New-Item -ItemType Directory -Path $sv -Force | Out-Null
  $state = New-Object System.Collections.Generic.List[string]
  $state.Add('Collected: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $runtime = $null; $config = $null; $logs = $null
  $n = 0
  try {
    $vp = Join-Path $env:LOCALAPPDATA 'openvr\openvrpaths.vrpath'
    if (Test-Path -LiteralPath $vp) {
      Copy-Item -LiteralPath $vp -Destination (Join-Path $sv 'openvrpaths.vrpath') -Force
      $n++
      $j = Get-Content -LiteralPath $vp -Raw | ConvertFrom-Json
      $runtime = @($j.runtime)[0]; $config = @($j.config)[0]; $logs = @($j.log)[0]
    } else { $state.Add('openvrpaths.vrpath: NOT FOUND (SteamVR has never run on this Windows account)') }
  } catch { $state.Add('openvrpaths.vrpath: could not be read: ' + $_) }
  try {
    $steam = $null
    try { $steam = ((Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath) -replace '/', '\' } catch {}
    if ($steam) {
      if (-not $runtime) { $runtime = Join-Path $steam 'steamapps\common\SteamVR' }
      if (-not $config) { $config = Join-Path $steam 'config' }
      if (-not $logs) { $logs = Join-Path $steam 'logs' }
    }
  } catch {}
  $state.Add("SteamVR runtime folder: $runtime")
  $state.Add("SteamVR config folder: $config")
  $state.Add("SteamVR log folder: $logs")
  try {
    if ($config) {
      $vs = Join-Path $config 'steamvr.vrsettings'
      if (Test-Path -LiteralPath $vs) { Copy-Item -LiteralPath $vs -Destination (Join-Path $sv 'steamvr.vrsettings') -Force; $n++ }
      else { $state.Add('steamvr.vrsettings: NOT FOUND') }
    }
  } catch { $state.Add('steamvr.vrsettings: could not be copied: ' + $_) }
  try {
    if ($logs -and (Test-Path -LiteralPath $logs)) {
      foreach ($name in @('vrserver.txt', 'vrstartup.txt', 'vrcompositor.txt', 'vrmonitor.txt', 'vrclient_ghost.txt', 'vrdashboard.txt')) {
        if (Copy-Tail (Join-Path $logs $name) (Join-Path $sv $name) 3000) { $n++ } else { $state.Add("$name : not found") }
      }
      $state.Add('Newest files in the SteamVR log folder:')
      Get-ChildItem -LiteralPath $logs -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 30 |
        ForEach-Object { $state.Add(('  {0}  {1} bytes  {2}' -f $_.Name, $_.Length, $_.LastWriteTime)) }
    }
  } catch { $state.Add('SteamVR logs: could not be read: ' + $_) }
  try {
    if ($runtime -and (Test-Path -LiteralPath $runtime)) {
      $drv = Join-Path $runtime 'drivers'
      if (Test-Path -LiteralPath $drv) {
        $names = @(Get-ChildItem -LiteralPath $drv -Directory -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
        $state.Add('SteamVR add-on folders (drivers): ' + ($names -join ', '))
      }
      foreach ($exe in @('bin\win64\vrserver.exe', 'bin\win64\vrclient_x64.dll')) {
        $fp = Join-Path $runtime $exe
        if (Test-Path -LiteralPath $fp) { $state.Add("$exe version: " + (Get-Item -LiteralPath $fp).VersionInfo.FileVersion) }
      }
    } else { $state.Add('SteamVR runtime folder not found on disk') }
  } catch { $state.Add('SteamVR add-ons: could not be listed: ' + $_) }
  try {
    $oc = Join-Path $env:ProgramFiles 'Oculus\Support\oculus-runtime'
    $state.Add('Oculus runtime folder present: ' + (Test-Path -LiteralPath $oc))
    try { $state.Add('Oculus registry Base: ' + (Get-ItemProperty 'HKLM:\SOFTWARE\Oculus VR, LLC\Oculus' -ErrorAction Stop).Base) } catch { $state.Add('Oculus registry Base: not set') }
  } catch {}
  try {
    $procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^(vr|steam|ovr|oculus|virtualdesktop|alvr|ghost)' } |
      Sort-Object Name | ForEach-Object { '{0} (pid {1})' -f $_.Name, $_.Id })
    $state.Add('Running VR-related programs: ' + ($procs -join ', '))
  } catch {}
  try {
    # Virtual Desktop keeps its own logs; the newest two text/log files of each of its folders
    $roots = @($env:APPDATA, $env:LOCALAPPDATA, $env:ProgramData) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
    foreach ($r in $roots) {
      $dirs = @(Get-ChildItem -LiteralPath $r -Directory -Filter 'Virtual Desktop*' -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
      foreach ($d in $dirs) {
        $files = @(Get-ChildItem -LiteralPath $d -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in @('.log', '.txt') } |
          Sort-Object LastWriteTime -Descending | Select-Object -First 2)
        foreach ($f in $files) { if (Copy-Tail $f.FullName (Join-Path $sv ('virtualdesktop_' + $f.Name)) 600) { $n++ } }
      }
    }
  } catch {}
  Set-Content -LiteralPath (Join-Path $sv 'steamvr_state.txt') -Value $state -Encoding UTF8
  return $n
}

# ---- 0.96: other mods in the game folder (Ghostbusters Deluxe, ReShade, ASI loaders ...) ----------------------------------
# Reads only. The probe works next to other mods; this is so the report (and you) can see what is there.
$ModLoaderNames = @('winmm.dll', 'version.dll', 'dsound.dll', 'dinput8.dll', 'dinput.dll', 'wininet.dll', 'msacm32.dll', 'msvfw32.dll', 'xlive.dll', 'vorbisfile.dll', 'ijl15.dll', 'wsock32.dll', 'ws2_32.dll', 'iphlpapi.dll', 'msimg32.dll', 'd3d8.dll')
$ModGfxNames = @('dxgi.dll', 'd3d9.dll', 'd3d10.dll', 'd3d10_1.dll', 'd3d12.dll', 'opengl32.dll', 'ddraw.dll')
$ModInputNames = @('xinput1_3.dll', 'xinput1_4.dll', 'xinput9_1_0.dll', 'xinput1_2.dll', 'xinput1_1.dll')
$ModNameRegex = '(?i)(reshade|sweetfx|dxvk|specialk|special_k|enbseries|deluxe|censor|asiloader|3dmigoto|(^|[^a-z0-9])(mod|mods|patch|fix|plugins|scripts|loader|unlocker)([^a-z0-9]|$))'

function Get-FileFacts($f) {
  try {
    $vi = $f.VersionInfo
    return ('version={0} company="{1}" product="{2}"' -f $vi.FileVersion, $vi.CompanyName, $vi.ProductName)
  } catch { return 'version=?' }
}

function Get-ModNotes($dir) {
  $lines = New-Object System.Collections.Generic.List[string]
  $warn = New-Object System.Collections.Generic.List[string]
  $ours = @{}
  try { $m = Read-Manifest $dir; if ($m) { foreach ($x in $m.Files) { $ours[$x[0].ToLowerInvariant()] = $x[1] } } } catch {}
  $top = @(Get-ChildItem -LiteralPath $dir -File -Force -ErrorAction SilentlyContinue)
  foreach ($f in $top) {
    $n = $f.Name.ToLowerInvariant()
    if ($n -like 'gbvr_*') { continue }
    if ($ours.ContainsKey($n)) {
      if ((Hash $f.FullName) -eq $ours[$n]) { continue }
      $lines.Add("$($f.Name): the mod installed this file, but it was CHANGED afterwards ($(Get-FileFacts $f))")
      $warn.Add("WARNING: $($f.Name) was replaced by something else after the mod was installed (a mod that brings its own copy?). Run INSTALL.cmd again.")
      continue
    }
    if ($n -eq 'd3d11.dll') {
      $lines.Add("d3d11.dll: not the mod's ($(Get-FileFacts $f))")
      $warn.Add('NOTE: a d3d11.dll from something else is in the game folder (ReShade / DXVK / another mod). INSTALL.cmd moves it to a backup file and puts it back on removal; both cannot be the game''s d3d11.dll at once.')
      continue
    }
    if ($n -like 'd3d11.dll.gbvr_backup_*') { $lines.Add("$($f.Name): the earlier d3d11.dll the mod moved aside (restored by REMOVE)"); continue }
    if ($ModGfxNames -contains $n) {
      $lines.Add("$($f.Name): graphics DLL ($(Get-FileFacts $f))")
      $warn.Add("WATCH: $($f.Name) next to ghost.exe is a graphics add-on (ReShade / DXVK / Special K style). It can work next to the mod, but if the headset picture fails, tell me this file is there.")
      continue
    }
    if ($ModInputNames -contains $n) {
      $lines.Add("$($f.Name): XInput DLL ($(Get-FileFacts $f))")
      $warn.Add("WATCH: $($f.Name) next to ghost.exe replaces the Windows controller DLL. The mod reads the controllers through it; if the controllers do nothing, tell me this file is there.")
      continue
    }
    if ($ModLoaderNames -contains $n) {
      $lines.Add("$($f.Name): loader-style DLL ($(Get-FileFacts $f)) - the intro-skip mod uses winmm.dll like this; fine")
      continue
    }
    if ($f.Extension -ieq '.asi') { $lines.Add("$($f.Name): ASI plugin ($(Get-FileFacts $f))"); continue }
    if ($n -match '\.(bak|orig|old)$' -or $n -like '*_original*' -or ($n -like 'ghost*.exe' -and $n -ne 'ghost.exe')) {
      $lines.Add("$($f.Name): looks like a saved copy of an original file ($($f.Length) bytes, $($f.LastWriteTime.ToString('yyyy-MM-dd')))")
      continue
    }
    if ($f.Name -match $ModNameRegex) { $lines.Add("$($f.Name): named like a mod file ($($f.Length) bytes, $($f.LastWriteTime.ToString('yyyy-MM-dd')))") }
  }
  foreach ($d in @(Get-ChildItem -LiteralPath $dir -Directory -Force -ErrorAction SilentlyContinue)) {
    if ($d.Name -match $ModNameRegex) { $lines.Add("folder $($d.Name): named like a mod folder") }
  }
  try {
    foreach ($a in @(Get-ChildItem -LiteralPath $dir -Recurse -Depth 2 -File -Force -Filter '*.asi' -ErrorAction SilentlyContinue | Select-Object -First 20)) {
      if ($a.DirectoryName -ne $dir.TrimEnd('\')) { $lines.Add("ASI plugin in a sub-folder: $($a.FullName.Substring($dir.TrimEnd('\').Length + 1))") }
    }
  } catch {}
  try {   # a second copy of the game next to this one (a stand-alone mod copy)
    $parent = Split-Path -Parent $dir
    if ($parent) {
      foreach ($sib in @(Get-ChildItem -LiteralPath $parent -Directory -ErrorAction SilentlyContinue | Select-Object -First 400)) {
        if ($sib.FullName.TrimEnd('\') -ne $dir.TrimEnd('\') -and (Test-Path -LiteralPath (Join-Path $sib.FullName 'ghost.exe'))) {
          $lines.Add("another game folder next to this one: $($sib.Name) (has ghost.exe; mod d3d11.dll there: $(Test-Path -LiteralPath (Join-Path $sib.FullName 'd3d11.dll')))")
          $warn.Add("NOTE: there is a second folder with ghost.exe ($($sib.Name)). The mod was put in the folder shown above. If your mod runs from the other folder, extract this zip INSIDE that folder first, then run INSTALL.cmd from there.")
        }
      }
    }
  } catch {}
  return [pscustomobject]@{ Lines = $lines; Warn = $warn }
}

function Collect-ModInfo($dir, $tmp) {
  $md = Join-Path $tmp 'mods'
  New-Item -ItemType Directory -Path $md -Force | Out-Null
  $count = 0
  $root = $dir.TrimEnd('\', '/')
  $sep = '[\\/]'
  # what the probe saw from inside the game (MODSCAN lines of the newest log)
  try {
    $newest = Get-ChildItem -LiteralPath $dir -Filter 'gbvr_probe_*.log' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($newest) {
      $ms = @(Select-String -LiteralPath $newest.FullName -Pattern 'MODSCAN' -SimpleMatch -ErrorAction SilentlyContinue | ForEach-Object { $_.Line })
      Set-Content -LiteralPath (Join-Path $md 'modscan_from_log.txt') -Value (@('From ' + $newest.Name) + $ms) -Encoding UTF8
      $count++
    }
  } catch {}
  # notes
  try {
    $mn = Get-ModNotes $dir
    $out = @('Game folder: ' + $dir, 'Collected: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    $ge = Get-Item -LiteralPath (Join-Path $dir 'ghost.exe') -ErrorAction SilentlyContinue
    if ($ge) { $out += ('ghost.exe: {0} bytes, written {1}, SHA-256 {2}, matches the analysed game: {3}' -f $ge.Length, $ge.LastWriteTime.ToString('yyyy-MM-dd HH:mm'), $exeHash, $exeOK) }
    $out += $mn.Lines
    $out += $mn.Warn
    Set-Content -LiteralPath (Join-Path $md 'mod_notes.txt') -Value $out -Encoding UTF8
    $count++
  } catch { Set-Content -LiteralPath (Join-Path $md 'mod_notes.txt') -Value ('mod notes failed: ' + $_) -Encoding UTF8 }
  # every file in the game folder: size and dates, plus which days files were written on (a Steam install is one burst, an unpacked mod another)
  $all = @()
  try {
    $all = @(Get-ChildItem -LiteralPath $dir -Recurse -File -Force -ErrorAction SilentlyContinue | Select-Object -First 60000)
    $csv = New-Object System.Collections.Generic.List[string]
    $csv.Add('path,bytes,modified_utc,created_utc')
    foreach ($f in $all) {
      $rel = $f.FullName.Substring([Math]::Min($root.Length + 1, $f.FullName.Length))
      $csv.Add(('"{0}",{1},{2},{3}' -f $rel.Replace('"', '""'), $f.Length, $f.LastWriteTimeUtc.ToString('yyyy-MM-dd HH:mm:ss'), $f.CreationTimeUtc.ToString('yyyy-MM-dd HH:mm:ss')))
    }
    Set-Content -LiteralPath (Join-Path $md 'game_inventory.csv') -Value $csv -Encoding UTF8
    $count++
    $sum = New-Object System.Collections.Generic.List[string]
    $sum.Add('Files per day they were last written (busiest 40 days):')
    $byDay = @($all | Group-Object -Property { $_.LastWriteTimeUtc.ToString('yyyy-MM-dd') } | Sort-Object -Property Count -Descending | Select-Object -First 40)
    foreach ($x in $byDay) {
      $mb = [math]::Round((($x.Group | Measure-Object -Property Length -Sum).Sum) / 1MB, 1)
      $sum.Add(('  {0}  {1,6} files  {2,9} MB' -f $x.Name, $x.Count, $mb))
    }
    $sum.Add('')
    $sum.Add('Per top-level folder:')
    $byTop = @($all | Group-Object -Property { $r = $_.FullName.Substring([Math]::Min($root.Length + 1, $_.FullName.Length)); $p = [regex]::Split($r, $sep); if ($p.Count -gt 1) { $p[0] } else { '(game folder itself)' } })
    foreach ($x in ($byTop | Sort-Object -Property Name)) {
      $mb = [math]::Round((($x.Group | Measure-Object -Property Length -Sum).Sum) / 1MB, 1)
      $old = ($x.Group | Measure-Object -Property LastWriteTimeUtc -Minimum).Minimum
      $new = ($x.Group | Measure-Object -Property LastWriteTimeUtc -Maximum).Maximum
      $sum.Add(('  {0}  {1} files  {2} MB  oldest {3}  newest {4}' -f $x.Name, $x.Count, $mb, $old.ToString('yyyy-MM-dd'), $new.ToString('yyyy-MM-dd')))
    }
    Set-Content -LiteralPath (Join-Path $md 'game_folder_summary.txt') -Value $sum -Encoding UTF8
    $count++
  } catch { Set-Content -LiteralPath (Join-Path $md 'game_folder_summary.txt') -Value ('summary failed: ' + $_) -Encoding UTF8 }
  # fingerprints of the files that decide behaviour (programs, settings, scripts)
  try {
    $hl = New-Object System.Collections.Generic.List[string]
    $hl.Add('SHA-256  bytes  modified  path')
    $budget = 800MB; $hn = 0
    $cands = @($all | Where-Object { $_.Extension -match '^\.(dll|exe|asi|ini|cfg|conf|lua|json|xml|toml)$' -and $_.Length -le 40MB } | Sort-Object -Property FullName)
    foreach ($f in $cands) {
      if ($hn -ge 400 -or $budget -le 0) { $hl.Add('(more files not hashed: limit reached)'); break }
      try {
        $h = (Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash
        $rel = $f.FullName.Substring([Math]::Min($root.Length + 1, $f.FullName.Length))
        $hl.Add(('{0}  {1}  {2}  {3}' -f $h, $f.Length, $f.LastWriteTimeUtc.ToString('yyyy-MM-dd'), $rel))
        $hn++; $budget -= $f.Length
      } catch {}
    }
    Set-Content -LiteralPath (Join-Path $md 'game_file_hashes.txt') -Value $hl -Encoding UTF8
    $count++
  } catch {}
  # the mod's own notes and settings (small text files), readme-like names first
  try {
    $docDir = Join-Path $md 'files'
    New-Item -ItemType Directory -Path $docDir -Force | Out-Null
    $docs = @($all | Where-Object {
        $r = $_.FullName.Substring([Math]::Min($root.Length + 1, $_.FullName.Length)); $depth = ([regex]::Split($r, $sep)).Count - 1
        $_.Length -le 512KB -and $_.Name -notlike 'gbvr_*' -and
        (($_.Extension -match '^\.(txt|md|nfo|ini|cfg|conf|log)$' -and $depth -le 3) -or ($_.Extension -match '^\.(xml|json|lua|toml)$' -and $depth -le 1))
      } | Sort-Object -Property @{ Expression = { if ($_.Name -match '(?i)readme|change|install|deluxe|mod|credit|release|notes|\.nfo$|\.ini$|\.cfg$') { 0 } else { 1 } } }, @{ Expression = { $_.LastWriteTime }; Descending = $true } |
      Select-Object -First 60)
    foreach ($f in $docs) {
      $rel = $f.FullName.Substring([Math]::Min($root.Length + 1, $f.FullName.Length))
      $flat = ([regex]::Replace($rel, $sep, '__'))
      Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $docDir $flat) -Force -ErrorAction SilentlyContinue
      $count++
    }
  } catch {}
  # 1.7.24: the Deluxe mod (and any other mod under MODS) keeps its numbers in small text files a little deeper (MODS\deluxe\world\en\ui.txt, data\tweak.txt): copy those too, so changes can be compared
  try {
    $docDir = Join-Path $md 'files'
    New-Item -ItemType Directory -Path $docDir -Force | Out-Null
    $modTxt = @($all | Where-Object {
        $r = $_.FullName.Substring([Math]::Min($root.Length + 1, $_.FullName.Length)); $parts = [regex]::Split($r, $sep)
        $parts.Count -ge 3 -and $parts[0] -ieq 'MODS' -and $parts.Count -le 7 -and $_.Length -le 300KB -and $_.Extension -match '^\.(txt|ini|cfg|xml|json)$'
      } | Select-Object -First 40)
    foreach ($f in $modTxt) {
      $rel = $f.FullName.Substring([Math]::Min($root.Length + 1, $f.FullName.Length))
      $flat = ([regex]::Replace($rel, $sep, '__'))
      $dest = Join-Path $docDir $flat
      if (-not (Test-Path -LiteralPath $dest)) { Copy-Item -LiteralPath $f.FullName -Destination $dest -Force -ErrorAction SilentlyContinue; $count++ }
    }
  } catch {}
  # Steam's record of this install (build, last update); only harmless keys
  try {
    $common = Split-Path -Parent $dir
    $steamapps = if ($common) { Split-Path -Parent $common } else { $null }
    if ($steamapps -and (Test-Path -LiteralPath $steamapps)) {
      $leaf = Split-Path -Leaf $dir
      foreach ($acf in @(Get-ChildItem -LiteralPath $steamapps -Filter 'appmanifest_*.acf' -File -ErrorAction SilentlyContinue)) {
        $t = Get-Content -LiteralPath $acf.FullName -Raw
        $im = [regex]::Match($t, '"installdir"\s+"([^"]+)"')
        if ($im.Success -and $im.Groups[1].Value -ieq $leaf) {
          $keep = @('appid', 'name', 'StateFlags', 'installdir', 'LastUpdated', 'SizeOnDisk', 'buildid', 'TargetBuildID', 'AutoUpdateBehavior', 'BytesToDownload', 'BytesDownloaded')
          $o = @('From ' + $acf.Name)
          foreach ($k in $keep) { $km = [regex]::Match($t, '"' + $k + '"\s+"([^"]*)"'); if ($km.Success) { $o += ('{0} = {1}' -f $k, $km.Groups[1].Value) } }
          Set-Content -LiteralPath (Join-Path $md 'steam_install_record.txt') -Value $o -Encoding UTF8
          $count++
        }
      }
    }
  } catch {}
  # 1.7.187 the Epic Games Launcher's record of this install (name, version, folder); only harmless keys
  try {
    $man = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    if (Test-Path -LiteralPath $man) {
      foreach ($it in @(Get-ChildItem -LiteralPath $man -Filter '*.item' -File -ErrorAction SilentlyContinue)) {
        try {
          $j = Get-Content -LiteralPath $it.FullName -Raw | ConvertFrom-Json
          if (($j.InstallLocation) -and ($dir.TrimEnd('\') -like ($j.InstallLocation.TrimEnd('\') + '*'))) {
            $o = @('From ' + $it.Name)
            foreach ($k in @('DisplayName', 'AppName', 'AppVersionString', 'LaunchExecutable', 'InstallLocation', 'InstallSize', 'CatalogNamespace', 'bIsIncompleteInstall')) { if ($null -ne $j.$k) { $o += ('{0} = {1}' -f $k, $j.$k) } }
            Set-Content -LiteralPath (Join-Path $md 'epic_install_record.txt') -Value $o -Encoding UTF8
            $count++
          }
        } catch {}
      }
    }
  } catch {}
  # the game's own settings folder (settings.ini and any log; save games are only listed)
  try {
    $gl = Join-Path $env:LOCALAPPDATA 'GHOSTBUSTERS'
    if (Test-Path -LiteralPath $gl) {
      $ll = New-Object System.Collections.Generic.List[string]
      foreach ($f in @(Get-ChildItem -LiteralPath $gl -Recurse -File -Force -ErrorAction SilentlyContinue | Select-Object -First 300)) {
        $ll.Add(('{0}  {1} bytes  {2}' -f $f.FullName.Substring([Math]::Min($gl.Length + 1, $f.FullName.Length)), $f.Length, $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))
        if ($f.Length -le 256KB -and $f.Extension -match '^\.(ini|log|txt|cfg)$') {
          Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $md ('gamedata__' + ([regex]::Replace($f.FullName.Substring([Math]::Min($gl.Length + 1, $f.FullName.Length)), $sep, '__')))) -Force -ErrorAction SilentlyContinue
        }
      }
      Set-Content -LiteralPath (Join-Path $md 'game_settings_folder_listing.txt') -Value $ll -Encoding UTF8
      $count++
    }
  } catch {}
  return $count
}

# ---------------------------------------------------------------------------
$dir = Find-GameDir
Say "Game folder: $dir"
$exeHash = Hash (Join-Path $dir 'ghost.exe')
$exeOK = $exeHash -eq $ExpectedExeHash
if ($exeOK) { Say 'ghost.exe: matches the analysed game version.' Green }
else {
  Say 'ghost.exe: this is not the Steam file the mod was analysed on (an Epic Games Store copy, or another patch).' Yellow
  Say '  That can be fine: when the game starts, the mod compares the game''s code with the analysed one. If it is the same, the mod runs;' Yellow
  Say '  if not, it stays switched off and the game runs normally. Start the game once, then run COLLECT_LOGS.cmd and send me the zip.' Yellow
  Say "  (file fingerprint: $exeHash)"
}

if ($Action -eq 'Collect') {
  # One zip in the Downloads folder with everything needed to see what went wrong. Reads only; changes nothing.
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $tmp = Join-Path $env:TEMP ("gbvr_report_" + $stamp)
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $places = @($dir, (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'GhostbustersVR_logs'), $env:TEMP) | Select-Object -Unique
  $n = 0
  foreach ($p in $places) {
    if (-not (Test-Path -LiteralPath $p)) { continue }
    $logs = Get-ChildItem -LiteralPath $p -Filter 'gbvr_probe_*.log' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 3
    foreach ($l in $logs) { Copy-Item -LiteralPath $l.FullName -Destination $tmp -Force; $n++ }
    # 0.88: the outside watcher's log (how the game ended, its own debug messages, DLL loads) and its small crash dump
    $wl = Get-ChildItem -LiteralPath $p -Filter 'gbvr_watch_*.log' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 3
    foreach ($w in $wl) { Copy-Item -LiteralPath $w.FullName -Destination $tmp -Force }
    $dmp = Join-Path $p 'gbvr_crash.dmp'
    if ((Test-Path -LiteralPath $dmp) -and ((Get-Item -LiteralPath $dmp).Length -lt 40MB)) { Copy-Item -LiteralPath $dmp -Destination $tmp -Force }
    # 0.74: the diagnostic pictures (rig view, F2 / Mark / saved by itself): the newest ten (0.75: wall pictures too)
    $pics = Get-ChildItem -LiteralPath $p -Filter 'gbvr_picture_*.jpg' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 14
    foreach ($pc in $pics) { Copy-Item -LiteralPath $pc.FullName -Destination $tmp -Force }
    foreach ($f in @('gbvr_last_crash.txt', 'gbvr_crumbs_last.txt', 'gbvr_crumbs.bin', 'gbvr_run.txt', 'gbvr_health.txt', 'gbvr_settings.txt', 'gbvr_manifest.txt', 'gbvr_start_pending.txt', 'gbvr_dxgi11_off.txt', 'gbvr_picture_off.txt')) {
      $fp = Join-Path $p $f
      if (Test-Path -LiteralPath $fp) { Copy-Item -LiteralPath $fp -Destination (Join-Path $tmp ((Split-Path -Leaf $p) + '_' + $f)) -Force }
    }
  }
  $fr = Join-Path $PackageDir 'gbvr_freeze_report.txt'
  if (Test-Path -LiteralPath $fr) { Copy-Item -LiteralPath $fr -Destination $tmp -Force }
  # Windows' own record of graphics driver resets / freezes in the last 3 days
  try {
    $s = (Get-Date).AddDays(-3)
    Get-WinEvent -FilterHashtable @{LogName='System';StartTime=$s} -ErrorAction SilentlyContinue |
      Where-Object { ($_.ProviderName -eq 'Display') -or ($_.ProviderName -like 'nvlddmkm*') -or ($_.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $_.Id -eq 41) -or ($_.ProviderName -like '*WHEA*') } |
      Select-Object -First 30 TimeCreated,ProviderName,Id,Message | Format-List | Out-File -Encoding utf8 (Join-Path $tmp 'windows_graphics_events.txt')
  } catch {}
  # 0.88: Windows' own note of WHY a program ended (Application Error / Windows Error Reporting): error code, faulting module, offset
  try {
    $s2 = (Get-Date).AddDays(-3)
    Get-WinEvent -FilterHashtable @{LogName='Application';StartTime=$s2} -ErrorAction SilentlyContinue |
      Where-Object { ($_.ProviderName -in @('Application Error','Windows Error Reporting','Application Hang')) -and ($_.Message -match 'ghost|d3d11|gbvr|Ghostbusters') } |
      Select-Object -First 20 TimeCreated,ProviderName,Id,Message | Format-List | Out-File -Encoding utf8 (Join-Path $tmp 'windows_app_events.txt')
  } catch {}
  try {
    $werRoots = @((Join-Path $env:ProgramData 'Microsoft\Windows\WER\ReportArchive'), (Join-Path $env:ProgramData 'Microsoft\Windows\WER\ReportQueue'),
                  (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\WER\ReportArchive'), (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\WER\ReportQueue'))
    $wk = 0
    foreach ($wr in $werRoots) {
      if (-not (Test-Path -LiteralPath $wr)) { continue }
      Get-ChildItem -LiteralPath $wr -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'ghost' } | Sort-Object LastWriteTime -Descending | Select-Object -First 3 | ForEach-Object {
        $rw = Join-Path $_.FullName 'Report.wer'
        if (Test-Path -LiteralPath $rw) { $wk++; Copy-Item -LiteralPath $rw -Destination (Join-Path $tmp ('wer_' + $wk + '_' + $_.Name + '.wer')) -Force -ErrorAction SilentlyContinue }
      }
    }
  } catch {}
  Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Select-Object Name,DriverVersion,DriverDate | Format-List | Out-File -Encoding utf8 (Join-Path $tmp 'graphics_driver.txt')
  # 0.67: SteamVR's own settings and logs (which add-on did it block, and why)
  $sn = 0
  try { $sn = Collect-SteamVR $tmp } catch { Say ('(SteamVR files could not be collected: ' + $_ + ')') Yellow }
  # 0.96: other mods in the game folder (Ghostbusters Deluxe, ReShade, ASI loaders ...)
  $mn = 0
  try { $mn = Collect-ModInfo $dir $tmp } catch { Say ('(Mod information could not be collected: ' + $_ + ')') Yellow }
  $dl = Get-DownloadsFolder
  $zip = Join-Path $dl ("gbvr_report_" + $stamp + ".zip")
  try { New-ZipForwardSlash $tmp $zip }
  catch { Say ('(Using the standard zip tool: ' + $_ + ')'); Compress-Archive -Path (Join-Path $tmp '*') -DestinationPath $zip -Force }
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Say ''
  Say "Done. Please send me this file ($n log(s), $sn SteamVR file(s) and $mn mod/game-folder file(s) inside):" Green
  Say "  $zip" Green
  Say '  (it is in your Downloads folder)'
  Say '  It holds the mod logs, your SteamVR / headset log files and a list of the files in the game folder. No passwords and no save games. You can open the zip and look before you send it.'
  try { Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $zip + '"') } catch {}
  exit 0
}

if ($Action -eq 'Check') {
  $m = Read-Manifest $dir
  if (-not $m) { Say 'V4 mod: not installed (no manifest).' }
  else {
    Say "V4 mod: version $($m.Version) installed."
    foreach ($f in $m.Files) {
      $p = Join-Path $dir $f[0]
      if (-not (Test-Path -LiteralPath $p)) { Say "  $($f[0]): MISSING" Red }
      elseif ((Hash $p) -eq $f[1]) { Say "  $($f[0]): OK" Green }
      else { Say "  $($f[0]): CHANGED by something else (another mod?)" Yellow }
    }
    foreach ($b in $m.Backups) { Say "  backup kept: $($b[1]) (original $($b[0]))" }
  }
  $other = Join-Path $dir 'd3d11.dll'
  if ((Test-Path -LiteralPath $other) -and -not $m) { Say 'Note: a d3d11.dll from something else is in the game folder.' Yellow }
  $ini = Find-SettingsIni
  if ($ini) {
    $t = (Read-IniText $ini).Text
    Say ("Game frame limit: lockTo30Hz=" + (Get-IniValue $t 'lockTo30Hz') + "  lockTo60Hz=" + (Get-IniValue $t 'lockTo60Hz') + "  (0 and 0 = up to 120 FPS)")
  } else { Say 'Game settings.ini not found (start the game once to create it).' }
  $gp = @(Get-Process -Name 'ghost' -ErrorAction SilentlyContinue)
  if ($gp.Count -gt 0) {
    if (@($gp | Where-Object { $_.MainWindowHandle -ne [IntPtr]::Zero }).Count -gt 0) { Say 'The game is running right now.' }
    else { Say 'A stuck copy of the game is running in the background (no window). INSTALL or REMOVE will close it.' Yellow }
  }
  if (Test-Path -LiteralPath (Join-Path $dir 'gbvr_dxgi11_off.txt')) { Say 'Note: gbvr_dxgi11_off.txt is present - the headset picture is switched off (a start failed). Reinstalling clears it.' Yellow }
  if (Test-Path -LiteralPath (Join-Path $dir 'gbvr_picture_off.txt')) { Say 'Note: gbvr_picture_off.txt is present - the bigger (sharper) picture is switched off (a start with it failed). Reinstalling, or pressing Insert in the game, clears it.' Yellow }
  foreach ($nm in @('gbvr_last_crash.txt', 'gbvr_run.txt', 'gbvr_health.txt')) {
    if (Test-Path -LiteralPath (Join-Path $dir $nm)) { Say "Note: $nm is present - an earlier run did not end cleanly. Double-click COLLECT_LOGS.cmd to gather everything to send me." Yellow }
  }
  try {
    $mnotes = Get-ModNotes $dir
    if ($mnotes.Lines.Count -gt 0) { Say 'Other mods / loaders in the game folder (the mod works next to them):'; foreach ($l in $mnotes.Lines) { Say ('  ' + $l) } }
    else { Say 'Other mods / loaders in the game folder: none found.' }
    foreach ($w in $mnotes.Warn) { Say ('  ' + $w) Yellow }
  } catch {}
  Show-Logs $dir
  exit 0
}

if (-not (Ensure-Writable $dir)) { Relaunch-Elevated $dir }

if ($Action -eq 'Remove') {
  Assert-GameClosed
  $m = Read-Manifest $dir
  if (-not $m) { Say 'Nothing to remove: no mod manifest in the game folder.' ; exit 0 }
  foreach ($st in $m.Settings) {
    $ini = $st[2]
    if ($ini -and (Test-Path -LiteralPath $ini)) {
      $cur = Get-IniValue (Read-IniText $ini).Text $st[0]
      if ($cur -eq '0') { Set-IniValues $ini @(, @($st[0], $st[1])); Say "Restored game setting $($st[0])=$($st[1])" }
      else { Say "Kept game setting $($st[0])=$cur (changed since install)." Yellow }
    }
  }
  foreach ($f in $m.Files) {
    $p = Join-Path $dir $f[0]
    if (Test-Path -LiteralPath $p) {
      if ((Hash $p) -eq $f[1]) { Remove-Item -LiteralPath $p -Force; Say "Removed $($f[0])" }
      else { Say "Kept $($f[0]): it was changed after install, so it is not ours to delete." Yellow }
    }
  }
  foreach ($b in $m.Backups) {
    $orig = Join-Path $dir $b[0]; $bak = Join-Path $dir $b[1]
    if ((Test-Path -LiteralPath $bak) -and -not (Test-Path -LiteralPath $orig)) {
      Move-Item -LiteralPath $bak -Destination $orig; Say "Restored original $($b[0])"
    }
  }
  Remove-Item -LiteralPath (Join-Path $dir $ManifestName) -Force
  Remove-StartupMarkers $dir
  Say 'V4 mod removed. Your logs were kept.' Green
  if ($Elevated) { Read-Host 'Press Enter to close' | Out-Null }
  exit 0
}

# ---- Install ----------------------------------------------------------------
Assert-GameClosed
$old = Read-Manifest $dir
if ($old) {
  Say "Removing the previously installed mod $($old.Version) first..."
  foreach ($f in $old.Files) {
    $p = Join-Path $dir $f[0]
    if ((Test-Path -LiteralPath $p) -and ((Hash $p) -eq $f[1])) { Remove-Item -LiteralPath $p -Force }
  }
}
$binDir = Join-Path $PackageDir 'bin'
try { Get-ChildItem -LiteralPath $binDir -File | Unblock-File -ErrorAction SilentlyContinue } catch {}   # 1.7.80: files from a downloaded zip carry a 'from the internet' mark; remove it so Windows does not block the DLLs
$toInstall = Get-ChildItem -LiteralPath $binDir -File
$backups = @()
if ($old) { $backups = $old.Backups }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
foreach ($f in $toInstall) {
  $dest = Join-Path $dir $f.Name
  if ((Test-Path -LiteralPath $dest) -and ((Hash $dest) -eq (Hash $f.FullName))) {
    Say "$($f.Name) is already the same file; keeping it."
    continue
  }
  if (Test-Path -LiteralPath $dest) {
    $bakName = "$($f.Name).gbvr_backup_$stamp"
    Move-Item -LiteralPath $dest -Destination (Join-Path $dir $bakName)
    $backups += , @($f.Name, $bakName)
    Say "Existing $($f.Name) was moved to $bakName (restored on removal)." Yellow
    if ($f.Name -eq 'd3d11.dll') { Say '  If this was the old ChatGPT 0.16 probe, please send that backup file to Claude too.' Yellow }
  }
  Copy-Item -LiteralPath $f.FullName -Destination $dest
}
# Game settings this probe needs (tools\settings_to_apply.txt, key=value lines).
# Only the listed keys change; their original values are recorded and put back
# on removal. A full copy of settings.ini is also kept as a backup.
$settingLines = @()
$wanted = Join-Path $PSScriptRoot 'settings_to_apply.txt'
$oldSettings = @{}
if ($old) { foreach ($st in $old.Settings) { $oldSettings[$st[0]] = $st } }
if (Test-Path -LiteralPath $wanted) {
  $ini = Find-SettingsIni
  if (-not $ini) {
    Say 'Game settings file not found. That is OK: the mod switches the 30 FPS limit off by itself while the game runs.' Green
  } else {
    Copy-Item -LiteralPath $ini -Destination "$ini.gbvr_backup_$stamp"
    $text = (Read-IniText $ini).Text
    $pairs = @()
    foreach ($line in Get-Content -LiteralPath $wanted) {
      if ($line -notmatch '^\s*([^=#\s]+)\s*=\s*(\S*)\s*$') { continue }
      $key = $Matches[1]; $val = $Matches[2]
      $cur = Get-IniValue $text $key
      if ($null -eq $cur) { Say "Game setting $key not found in settings.ini; left unchanged." Yellow; continue }
      $orig = if ($oldSettings.ContainsKey($key)) { $oldSettings[$key][1] } else { $cur }
      $settingLines += "setting|$key|$orig|$ini"
      $pairs += , @($key, $val)
      Say "Game setting $key=$val (was $cur; original $orig restored on removal)"
    }
    if ($pairs.Count -gt 0) { Set-IniValues $ini $pairs }
  }
} elseif ($old) {
  foreach ($st in $old.Settings) { $settingLines += "setting|$($st[0])|$($st[1])|$($st[2])" }
}
$lines = @("version|$Version")
foreach ($f in $toInstall) { $lines += "file|$($f.Name)|$(Hash (Join-Path $dir $f.Name))" }
foreach ($b in $backups) { $lines += "backup|$($b[0])|$($b[1])" }
$lines += $settingLines
Set-Content -LiteralPath (Join-Path $dir $ManifestName) -Value $lines -Encoding ASCII
Remove-StartupMarkers $dir
Say "V4 (build $Version) installed." Green
try {
  $mnotes = Get-ModNotes $dir
  if ($mnotes.Lines.Count -gt 0) { Say 'Other mods / loaders in the game folder (the mod works next to them):'; foreach ($l in $mnotes.Lines) { Say ('  ' + $l) } }
  foreach ($w in $mnotes.Warn) { Say ('  ' + $w) Yellow }
} catch {}
if (-not $exeOK) { Say 'Reminder: this ghost.exe is not the Steam file; the mod checks the game code at start and stays off if it is different (COLLECT_LOGS.cmd after one start tells me which).' Yellow }
Say ''
Show-VrReadiness
Say ''
Say 'NEXT STEPS' Cyan
Say ' 1. Put your headset on and start SteamVR (Quest: open Virtual Desktop, Air Link or Steam Link, connect, then SteamVR).'
Say ' 2. Start the game from Steam. VR starts by itself; the game picture appears in the headset.'
Say ' 3. Controls: open PLAYER_GUIDE.pdf. Open the in-game menu with F12, or your left grip with the left hand beside your left ear.'
Say ' 4. If anything is wrong: close the game, double-click COLLECT_LOGS.cmd and send the zip it puts in your Downloads folder.'
Say ' To go back to the normal game at any time: double-click REMOVE.cmd.'
if ($Elevated) { Read-Host 'Press Enter to close' | Out-Null }
